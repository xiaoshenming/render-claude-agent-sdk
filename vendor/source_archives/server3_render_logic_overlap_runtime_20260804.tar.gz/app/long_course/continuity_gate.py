"""Static continuity gates for internal long-course segments."""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from typing import Any


INTRO_PATTERNS = [
    "同学们好",
    "今天我们学习",
    "本节课我们从头开始",
    "欢迎来到本节课",
]

OUTRO_PATTERNS = [
    "最后总结",
    "本课到这里",
    "完整回顾",
    "今天的内容就讲完了",
]

VOICEOVER_COVERAGE_RATIO = 0.92


@dataclass(frozen=True)
class GateResult:
    ok: bool
    code: str
    details: dict[str, Any] = field(default_factory=dict)


def extract_voiceover_texts(code: str) -> list[str]:
    """Extract static voiceover text from generated Manim code."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []
    return _extract_voiceover_texts_from_tree(tree)


def extract_voiceover_joined_text(code: str) -> str:
    return "\n".join(extract_voiceover_texts(code))


def validate_segment_continuity(
    code: str,
    contract: dict[str, Any],
    bible: dict[str, Any] | None,
) -> GateResult:
    tree_result = _parse_code(code)
    if isinstance(tree_result, GateResult):
        return tree_result

    text = "\n".join(_extract_voiceover_texts_from_tree(tree_result))
    if not bool(contract.get("allow_course_opening")):
        hit = _matching_patterns(
            text,
            _merged_patterns(
                INTRO_PATTERNS,
                bible,
                "intro_forbidden_after_segment_1",
            ),
        )
        if hit:
            return GateResult(
                False,
                "segment_forbidden_course_opening",
                {"patterns": hit},
            )

    if not bool(contract.get("allow_course_final_summary")):
        hit = _matching_patterns(
            text,
            _merged_patterns(
                OUTRO_PATTERNS,
                bible,
                "final_outro_forbidden_before_last_segment",
            ),
        )
        if hit:
            return GateResult(
                False,
                "segment_forbidden_course_final_summary",
                {"patterns": hit},
            )

    return GateResult(True, "segment_continuity_ok", {})


def validate_voiceover_coverage(
    code: str,
    required_voiceover_chars: int,
) -> GateResult:
    tree_result = _parse_code(code)
    if isinstance(tree_result, GateResult):
        return tree_result

    actual_chars = sum(len(text) for text in _extract_voiceover_texts_from_tree(tree_result))
    required_chars = int(max(required_voiceover_chars, 0) * VOICEOVER_COVERAGE_RATIO)
    if actual_chars < required_chars:
        return GateResult(
            False,
            "voiceover_coverage_too_low",
            {
                "actual_chars": actual_chars,
                "required_chars": required_chars,
            },
        )

    return GateResult(
        True,
        "voiceover_coverage_ok",
        {
            "actual_chars": actual_chars,
            "required_chars": required_chars,
        },
    )


def _parse_code(code: str) -> ast.AST | GateResult:
    try:
        return ast.parse(code)
    except SyntaxError as exc:
        return GateResult(
            False,
            "segment_code_parse_error",
            {
                "message": exc.msg,
                "lineno": exc.lineno,
                "offset": exc.offset,
            },
        )


def _extract_voiceover_texts_from_tree(tree: ast.AST) -> list[str]:
    texts: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not _is_voiceover_call(node):
            continue

        keyword_text = _keyword_text(node, "text")
        if keyword_text is not None:
            texts.append(keyword_text)
            continue

        positional_text = _first_positional_text(node)
        if positional_text is not None:
            texts.append(positional_text)
    return texts


def _is_voiceover_call(node: ast.Call) -> bool:
    func = node.func
    if not isinstance(func, ast.Attribute):
        return False
    return func.attr in {"voiceover", "short_voiceover"}


def _keyword_text(node: ast.Call, keyword_name: str) -> str | None:
    for keyword in node.keywords:
        if keyword.arg == keyword_name:
            return _static_string(keyword.value)
    return None


def _first_positional_text(node: ast.Call) -> str | None:
    if not node.args:
        return None
    return _static_string(node.args[0])


def _static_string(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        parts: list[str] = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
                continue
            return None
        return "".join(parts)
    return None


def _matching_patterns(text: str, patterns: list[str]) -> list[str]:
    return [pattern for pattern in patterns if pattern and pattern in text]


def _merged_patterns(
    defaults: list[str],
    bible: dict[str, Any] | None,
    key: str,
) -> list[str]:
    patterns = list(defaults)
    extra = (bible or {}).get(key)
    if isinstance(extra, list):
        patterns.extend(str(item) for item in extra if item)
    return list(dict.fromkeys(patterns))


__all__ = [
    "GateResult",
    "INTRO_PATTERNS",
    "OUTRO_PATTERNS",
    "extract_voiceover_joined_text",
    "extract_voiceover_texts",
    "validate_segment_continuity",
    "validate_voiceover_coverage",
]
