"""Internal long-course render helpers."""
