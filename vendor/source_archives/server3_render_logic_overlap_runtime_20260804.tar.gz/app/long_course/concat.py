"""FFmpeg concat helpers for internal long-course segments."""

from __future__ import annotations

import json
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


Runner = Callable[[list[str]], Any]


@dataclass(frozen=True)
class SegmentMediaInfo:
    path: str
    duration_sec: float
    has_audio: bool


@dataclass(frozen=True)
class ConcatResult:
    output_path: str
    segment_count: int
    segment_durations_sec: list[float]
    total_duration_sec: float


class LongCourseConcatError(RuntimeError):
    def __init__(self, code: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(code)
        self.code = code
        self.details = details or {}


def probe_segment_media(
    path: str | Path,
    *,
    runner: Runner = subprocess.run,
) -> SegmentMediaInfo:
    segment_path = Path(path)
    if not segment_path.is_file():
        raise LongCourseConcatError(
            "segment_file_missing",
            {"path": str(segment_path)},
        )

    completed = runner(
        [
            "ffprobe",
            "-v",
            "error",
            "-print_format",
            "json",
            "-show_streams",
            "-show_format",
            str(segment_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if getattr(completed, "returncode", 1) != 0:
        raise LongCourseConcatError(
            "ffprobe_failed",
            {
                "path": str(segment_path),
                "stderr": getattr(completed, "stderr", ""),
            },
        )

    payload = _loads_ffprobe_json(getattr(completed, "stdout", ""), segment_path)
    streams = payload.get("streams") or []
    duration = _extract_duration(payload)
    has_audio = any(stream.get("codec_type") == "audio" for stream in streams)

    if duration <= 0:
        raise LongCourseConcatError(
            "segment_duration_missing",
            {"path": str(segment_path), "duration_sec": duration},
        )
    if not has_audio:
        raise LongCourseConcatError(
            "segment_audio_missing",
            {"path": str(segment_path)},
        )

    return SegmentMediaInfo(
        path=str(segment_path),
        duration_sec=duration,
        has_audio=has_audio,
    )


def concat_long_course_segments(
    segment_paths: Iterable[str | Path],
    output_path: str | Path,
    *,
    runner: Runner = subprocess.run,
) -> ConcatResult:
    paths = [Path(path) for path in segment_paths]
    if not paths:
        raise LongCourseConcatError("segment_list_empty", {})

    infos = [probe_segment_media(path, runner=runner) for path in paths]
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    list_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".txt",
            prefix="long_course_concat_",
            encoding="utf-8",
            delete=False,
        ) as concat_file:
            list_path = Path(concat_file.name)
            for path in paths:
                concat_file.write(_concat_file_line(path))

        completed = runner(
            [
                "ffmpeg",
                "-y",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(list_path),
                "-c",
                "copy",
                str(output),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if getattr(completed, "returncode", 1) != 0:
            raise LongCourseConcatError(
                "ffmpeg_concat_failed",
                {
                    "output_path": str(output),
                    "stderr": getattr(completed, "stderr", ""),
                },
            )
    finally:
        if list_path is not None:
            list_path.unlink(missing_ok=True)

    durations = [info.duration_sec for info in infos]
    return ConcatResult(
        output_path=str(output),
        segment_count=len(infos),
        segment_durations_sec=durations,
        total_duration_sec=sum(durations),
    )


def _loads_ffprobe_json(value: str, segment_path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(value or "{}")
    except json.JSONDecodeError as exc:
        raise LongCourseConcatError(
            "ffprobe_invalid_json",
            {"path": str(segment_path), "message": str(exc)},
        ) from exc
    if not isinstance(payload, dict):
        raise LongCourseConcatError(
            "ffprobe_invalid_json",
            {"path": str(segment_path)},
        )
    return payload


def _extract_duration(payload: dict[str, Any]) -> float:
    raw_duration = (payload.get("format") or {}).get("duration")
    try:
        return float(raw_duration)
    except (TypeError, ValueError):
        return 0.0


def _concat_file_line(path: Path) -> str:
    resolved = str(path.resolve())
    escaped = resolved.replace("'", "'\\''")
    return f"file '{escaped}'\n"


__all__ = [
    "ConcatResult",
    "LongCourseConcatError",
    "SegmentMediaInfo",
    "concat_long_course_segments",
    "probe_segment_media",
]
