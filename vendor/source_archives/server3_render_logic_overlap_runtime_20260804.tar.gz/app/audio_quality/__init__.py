"""归档前音频质量旁路观测模块。"""

from .dispatch import dispatch_audio_quality_observation

__all__ = ["dispatch_audio_quality_observation"]
