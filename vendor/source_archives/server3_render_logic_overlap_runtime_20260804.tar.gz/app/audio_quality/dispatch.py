"""在归档前把最终视频投递给独立 STT observer；永远 fail-open。"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any

from app.core.config import settings

from .expected_text import extract_expected_voiceover

logger = logging.getLogger(__name__)


async def dispatch_audio_quality_observation(
    *, task_data: dict[str, Any], code: str, video_path: str
) -> bool:
    if not settings.AUDIO_QUALITY_OBSERVER_ENABLED or not task_data.get("enable_tts"):
        return False
    try:
        result_path = await asyncio.to_thread(_write_spool, task_data, code, video_path)
        from app.workers.task_dispatcher import log_render_quality_event

        await log_render_quality_event(
            "pre_archive_audio_quality_dispatched",
            task_data,
            payload={
                "schema_version": "mathpi.audio-quality.v1",
                "status": "queued",
                "fail_open": True,
            },
            evidence={},
            source="audio_quality_observer",
        )
        result = await _wait_result(result_path)
        await log_render_quality_event(
            str(result["event_type"]),
            task_data,
            payload=dict(result.get("payload") or {}),
            evidence=dict(result.get("evidence") or {}),
            source="audio_quality_observer",
        )
        return result["event_type"] == "pre_archive_audio_quality_completed"
    except Exception as exc:  # noqa: BLE001 - observer cannot block archive.
        logger.warning("STT observer 投递失败但继续归档: job=%s error=%s", task_data.get("job_id"), exc)
        try:
            from app.audio_quality.contract import failed_payload
            from app.workers.task_dispatcher import log_render_quality_event

            await log_render_quality_event(
                "pre_archive_audio_quality_failed",
                task_data,
                payload=failed_payload(f"{type(exc).__name__}: {exc}"),
                evidence={},
                source="audio_quality_observer",
            )
        except Exception:
            pass
        return False


def _write_spool(task_data: dict[str, Any], code: str, video_path: str) -> Path:
    source = Path(video_path).resolve(strict=True)
    root = Path(settings.AUDIO_QUALITY_SPOOL_DIR).resolve()
    pending = root / "pending"
    media = root / "media"
    results = root / "results"
    pending.mkdir(parents=True, exist_ok=True)
    media.mkdir(parents=True, exist_ok=True)
    results.mkdir(parents=True, exist_ok=True)
    job_id = _safe_id(task_data.get("job_id"))
    attempt_id = _safe_id(task_data.get("attempt_id") or "attempt")
    stem = f"{job_id}-{attempt_id}"
    target = media / f"{stem}{source.suffix or '.mp4'}"
    if target.exists():
        target.unlink()
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)
    payload = {
        "job_id": job_id,
        "user_id": str(task_data.get("user_id") or "")[:64],
        "request_id": str(task_data.get("request_id") or "")[:64],
        "trace_id": str(task_data.get("trace_id") or "")[:64],
        "attempt_id": str(task_data.get("attempt_id") or "")[:64],
        "retry_count": int(task_data.get("retry_count", 0) or 0),
        "video_path": str(target),
        "result_path": str(results / f"{stem}.json"),
        "expected_text": extract_expected_voiceover(code),
        "pronunciation_manifest": task_data.get("pronunciation_manifest"),
    }
    temporary = pending / f".{stem}.json.tmp"
    ready = pending / f"{stem}.json"
    temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    temporary.replace(ready)
    return Path(payload["result_path"])


async def _wait_result(result_path: Path, timeout_seconds: float = 300.0) -> dict[str, Any]:
    deadline = asyncio.get_running_loop().time() + timeout_seconds
    while asyncio.get_running_loop().time() < deadline:
        if result_path.is_file():
            try:
                return json.loads(result_path.read_text(encoding="utf-8"))
            finally:
                result_path.unlink(missing_ok=True)
        await asyncio.sleep(0.2)
    raise TimeoutError(f"STT observer timeout after {timeout_seconds:.0f}s")


def _safe_id(value: Any) -> str:
    result = "".join(char for char in str(value or "") if char.isalnum() or char in "-_")
    if not result:
        raise ValueError("missing safe job identifier")
    return result[:96]
