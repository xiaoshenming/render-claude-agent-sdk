"""文件队列驱动的独立 STT observer 服务。"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import signal
from pathlib import Path
from typing import Any

from app.core.config import settings
from .analyzer import analyze_video
from .contract import failed_payload

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("audio-quality-observer")


class Observer:
    def __init__(self, root: Path, poll_seconds: float) -> None:
        self.root = root
        self.pending = root / "pending"
        self.processing = root / "processing"
        self.poll_seconds = poll_seconds
        self.stopping = False
        self.pending.mkdir(parents=True, exist_ok=True)
        self.processing.mkdir(parents=True, exist_ok=True)

    async def run(self) -> None:
        logger.info("STT observer started root=%s", self.root)
        while not self.stopping:
            item = self._claim_one()
            if item is None:
                await asyncio.sleep(self.poll_seconds)
                continue
            await self._process(item)

    def stop(self) -> None:
        self.stopping = True

    def _claim_one(self) -> Path | None:
        for source in sorted(self.pending.glob("*.json")):
            target = self.processing / source.name
            try:
                source.replace(target)
                return target
            except FileNotFoundError:
                continue
        return None

    async def _process(self, item: Path) -> None:
        video_path: Path | None = None
        task: dict[str, Any] = {}
        try:
            task = json.loads(item.read_text(encoding="utf-8"))
            video_path = Path(str(task["video_path"])).resolve(strict=True)
            if self.root not in video_path.parents:
                raise ValueError("video path is outside observer spool")
            payload, evidence = await asyncio.to_thread(
                analyze_video,
                str(video_path),
                expected_text=str(task.get("expected_text") or ""),
                model_name=settings.AUDIO_QUALITY_MODEL,
                max_findings=settings.AUDIO_QUALITY_MAX_FINDINGS,
                pronunciation_manifest=task.get("pronunciation_manifest"),
            )
            self._write_result(
                task,
                event_type="pre_archive_audio_quality_completed",
                payload=payload,
                evidence=evidence,
            )
            logger.info("STT completed job=%s risks=%s", task.get("job_id"), payload["summary"])
        except Exception as exc:  # noqa: BLE001 - persist failure and continue queue.
            logger.exception("STT failed-open job=%s", task.get("job_id"))
            self._write_result(
                task,
                event_type="pre_archive_audio_quality_failed",
                payload=failed_payload(f"{type(exc).__name__}: {exc}"),
                evidence={},
            )
        finally:
            item.unlink(missing_ok=True)
            if video_path is not None:
                video_path.unlink(missing_ok=True)

    def _write_result(
        self,
        task: dict[str, Any],
        *,
        event_type: str,
        payload: dict[str, Any],
        evidence: dict[str, Any],
    ) -> None:
        result_path = Path(str(task["result_path"])).resolve()
        if self.root not in result_path.parents:
            raise ValueError("result path is outside observer spool")
        result_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = result_path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps({
                "event_type": event_type,
                "payload": payload,
                "evidence": evidence,
            }, ensure_ascii=False),
            encoding="utf-8",
        )
        temporary.replace(result_path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--spool-dir", default=settings.AUDIO_QUALITY_SPOOL_DIR)
    parser.add_argument("--poll-seconds", type=float, default=1.0)
    args = parser.parse_args()
    observer = Observer(Path(args.spool_dir).resolve(), args.poll_seconds)
    loop = asyncio.new_event_loop()
    for signum in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(signum, observer.stop)
    loop.run_until_complete(observer.run())


if __name__ == "__main__":
    main()
