"""Provider-neutral token usage extraction for LLM responses."""

from typing import Any

import litellm


def get_value(obj: Any, key: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def raw_usage_dict(obj: Any) -> dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return {
            str(key): value
            for key, value in obj.items()
            if isinstance(value, (str, int, float, bool, type(None), dict, list))
        }
    if hasattr(obj, "model_dump"):
        try:
            dumped = obj.model_dump()
            if isinstance(dumped, dict):
                return dumped
        except Exception:
            pass
    raw: dict[str, Any] = {}
    for key in (
        "total_tokens", "prompt_tokens", "completion_tokens", "input_tokens",
        "output_tokens", "prompt_tokens_details", "input_tokens_details",
        "completion_tokens_details", "output_tokens_details",
        "cache_read_input_tokens", "cache_creation_input_tokens",
        "_cache_read_input_tokens", "_cache_creation_input_tokens",
        "prompt_cache_hit_tokens", "prompt_cache_miss_tokens", "promptTokenCount",
        "candidatesTokenCount", "totalTokenCount", "cachedContentTokenCount",
        "cached_tokens", "cache_creation_tokens", "reasoning_tokens",
    ):
        value = getattr(obj, key, None)
        if value is not None:
            raw[key] = (
                raw_usage_dict(value)
                if not isinstance(value, (str, int, float, bool, list, dict))
                else value
            )
    return raw


def extract_usage_info(response) -> dict:
    result = {
        "total_tokens": 0, "input_tokens": 0, "output_tokens": 0,
        "cache_read_tokens": 0, "cache_creation_tokens": 0,
        "cache_miss_tokens": 0, "provider_usage_raw": {},
    }
    usage = get_value(response, "usage")
    usage_metadata = get_value(response, "usage_metadata") or get_value(
        response, "usageMetadata"
    )
    if not usage and not usage_metadata:
        return result

    result["provider_usage_raw"] = {
        **raw_usage_dict(usage), **raw_usage_dict(usage_metadata)
    }
    input_tokens = (
        get_value(usage, "prompt_tokens")
        if get_value(usage, "prompt_tokens") is not None
        else get_value(usage, "input_tokens")
    ) or 0
    input_tokens = input_tokens or get_value(
        usage_metadata, "promptTokenCount", 0
    ) or 0
    output_tokens = (
        get_value(usage, "completion_tokens")
        if get_value(usage, "completion_tokens") is not None
        else get_value(usage, "output_tokens")
    ) or 0
    output_tokens = output_tokens or get_value(
        usage_metadata, "candidatesTokenCount", 0
    ) or 0
    result["input_tokens"] = input_tokens
    result["output_tokens"] = output_tokens
    result["total_tokens"] = (
        get_value(usage, "total_tokens", 0)
        or get_value(usage_metadata, "totalTokenCount", 0)
        or (input_tokens + output_tokens)
    )

    cache_read = 0
    cache_creation = 0
    prompt_details = get_value(usage, "prompt_tokens_details") or get_value(
        usage, "input_tokens_details"
    )
    if prompt_details:
        cache_read = max(cache_read, get_value(prompt_details, "cached_tokens", 0) or 0)
        cache_creation = max(
            cache_creation,
            get_value(prompt_details, "cache_creation_tokens", 0) or 0,
        )
    cache_read = max(cache_read, get_value(usage, "cache_read_input_tokens", 0) or 0)
    cache_creation = max(
        cache_creation, get_value(usage, "cache_creation_input_tokens", 0) or 0
    )
    cache_read = max(cache_read, get_value(usage, "_cache_read_input_tokens", 0) or 0)
    cache_creation = max(
        cache_creation, get_value(usage, "_cache_creation_input_tokens", 0) or 0
    )
    cache_read = max(cache_read, get_value(usage, "prompt_cache_hit_tokens", 0) or 0)
    cache_read = max(
        cache_read, get_value(usage_metadata, "cachedContentTokenCount", 0) or 0
    )
    result["cache_read_tokens"] = cache_read
    result["cache_creation_tokens"] = cache_creation
    result["cache_miss_tokens"] = get_value(usage, "prompt_cache_miss_tokens", 0) or 0
    output_details = get_value(usage, "completion_tokens_details") or get_value(
        usage, "output_tokens_details"
    )
    reasoning_tokens = get_value(output_details, "reasoning_tokens", 0) or 0
    if reasoning_tokens:
        result["reasoning_tokens"] = reasoning_tokens
    return result


def merge_usage_info(target: dict, usage_info: dict) -> None:
    for key, value in (usage_info or {}).items():
        if value or key not in target:
            target[key] = value


def usage_info_with_trace_context(
    usage_info: dict, trace_usage_context: dict | None
) -> dict:
    merged = dict(usage_info or {})
    if not isinstance(trace_usage_context, dict):
        return merged
    for key in ("prompt_segments", "cache_metrics", "prompt_firewall"):
        value = trace_usage_context.get(key)
        if value is not None and key not in merged:
            merged[key] = value
    return merged


def safe_completion_cost(response) -> float:
    try:
        return float(litellm.completion_cost(completion_response=response) or 0.0)
    except Exception:
        return 0.0
