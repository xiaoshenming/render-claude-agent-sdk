"""Normalize and concatenate rendered video slices."""
import logging
import os
from typing import Any, Callable, List, Optional
from app.services.ffmpeg_media import (
    _has_audio,
    _media_duration,
    _normalize_target_resolution,
    _normalize_timeout,
    _probe_media,
    _stream_summary,
    _video_duration,
    _video_filter,
)

logger = logging.getLogger(__name__)
_AUDIO_FILTER = "aresample=async=1:first_pts=0,apad"
facade_provider: Callable[[], Any] | None = None

async def concat_slices(
    slice_mp4_paths: List[str],
    output_path: str,
    *,
    require_audio: bool = False,
    allow_missing_audio_paths: Optional[set[str]] = None,
    target_resolution: tuple[int, int] | list[int] | None = None,
) -> bytes:
    """逐切片归一化时间轴后用 FFmpeg concat filter 拼接。"""
    normalized_target_resolution = _normalize_target_resolution(target_resolution)
    valid_paths: list[str] = []
    valid_probes: list[dict] = []
    invalid_slices: list[str] = []
    allowed_missing_audio_paths = {
        os.path.abspath(path)
        for path in (allow_missing_audio_paths or set())
    }

    total_duration = 0.0
    for p in slice_mp4_paths:
        if not os.path.exists(p):
            invalid_slices.append(f"{os.path.basename(p)}: 文件不存在")
            continue
        fsize = os.path.getsize(p)
        if fsize < 1024:
            invalid_slices.append(
                f"{os.path.basename(p)}: 文件过小({fsize}B)")
            continue
        try:
            probe = await _probe_media(p)
            total_duration += _media_duration(probe)
            logger.info(
                f"[SLICE] [{facade_provider()._ts()}] probe {os.path.basename(p)}: "
                f"{_stream_summary(probe)}")
        except Exception:
            invalid_slices.append(
                f"{os.path.basename(p)}: ffprobe 超时")
            continue
        valid_paths.append(p)
        valid_probes.append(probe)

    if invalid_slices:
        logger.warning(
            f"[SLICE] [{facade_provider()._ts()}] concat 前校验: "
            f"{len(invalid_slices)} 个无效切片被跳过: "
            f"{'; '.join(invalid_slices[:5])}")
    if not valid_paths:
        raise Exception(
            f"所有 {len(slice_mp4_paths)} 个切片均无效，"
            f"无法拼接: {'; '.join(invalid_slices[:3])}")

    audio_flags = [_has_audio(probe) for probe in valid_probes]
    has_audio = any(audio_flags)
    if require_audio and not has_audio:
        raise Exception("TTS任务未检测到任何音频流，拒绝写入成功视频")
    if require_audio:
        missing_audio_paths = [
            path
            for path, has_slice_audio in zip(valid_paths, audio_flags)
            if not has_slice_audio
        ]
        disallowed_missing_audio_slices = [
            os.path.basename(path)
            for path in missing_audio_paths
            if os.path.abspath(path) not in allowed_missing_audio_paths
        ]
        if disallowed_missing_audio_slices:
            raise Exception(
                "TTS任务存在无音频切片，拒绝写入成功视频: "
                f"{'; '.join(disallowed_missing_audio_slices[:5])}"
            )
        if missing_audio_paths:
            logger.warning(
                f"[SLICE] [{facade_provider()._ts()}] TTS任务存在无音频切片，"
                "将仅对允许复用的源切片补入静音音轨后拼接: "
                f"{'; '.join(os.path.basename(p) for p in missing_audio_paths[:5])}"
            )

    filter_parts: list[str] = []
    concat_inputs: list[str] = []
    for index, probe in enumerate(valid_probes):
        duration = max(_video_duration(probe), 0.001)
        filter_parts.append(
            f"[{index}:v:0]"
            f"{_video_filter(normalized_target_resolution)}"
            f"[v{index}]"
        )
        concat_inputs.append(f"[v{index}]")
        if has_audio:
            if _has_audio(probe):
                filter_parts.append(
                    f"[{index}:a:0]{_AUDIO_FILTER},"
                    f"atrim=0:{duration:.6f},asetpts=PTS-STARTPTS[a{index}]"
                )
            else:
                filter_parts.append(
                    f"anullsrc=r=48000:cl=stereo,"
                    f"atrim=0:{duration:.6f},asetpts=PTS-STARTPTS[a{index}]"
                )
            concat_inputs.append(f"[a{index}]")

    filter_parts.append(
        "".join(concat_inputs)
        + f"concat=n={len(valid_paths)}:v=1:a={1 if has_audio else 0}"
        + ("[v][a]" if has_audio else "[v]")
    )

    cmd = [
        "ffmpeg",
    ]
    for path in valid_paths:
        cmd.extend(["-i", path])
    cmd.extend([
        "-filter_complex", ";".join(filter_parts),
        "-map", "[v]",
    ])
    if has_audio:
        cmd.extend(["-map", "[a]"])
    cmd.extend([
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-crf", "18",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "128k",
        "-ar", "48000",
        "-ac", "2",
        "-shortest",
        "-movflags", "+faststart",
        "-max_muxing_queue_size", "1024",
        "-avoid_negative_ts", "make_zero",
        output_path, "-y",
    ])
    logger.info(
        f"[SLICE] [{facade_provider()._ts()}] FFmpeg filter concat normalize: "
        f"{len(valid_paths)}/{len(slice_mp4_paths)} 个有效切片 "
        f"duration≈{total_duration:.2f}s audio={has_audio} -> {output_path}")
    cp = await facade_provider().run_cmd_async(cmd, timeout=_normalize_timeout(total_duration))

    if cp.returncode != 0:
        raise Exception(
            f"FFmpeg filter concat normalize 失败: "
            f"{cp.stderr[:500] if cp.stderr else 'unknown'}")

    with open(output_path, "rb") as f:
        data = f.read()

    min_size = 10 * 1024
    if len(data) < min_size:
        raise Exception(f"合并视频过小: {len(data)} bytes")

    try:
        output_probe = await _probe_media(
            output_path,
            require_audio=require_audio or has_audio,
        )
        logger.info(
            f"[SLICE] [{facade_provider()._ts()}] output probe: "
            f"{_stream_summary(output_probe)}")
    except Exception as e:
        raise Exception(f"合并视频 ffprobe 校验失败: {e}") from e

    logger.info(
        f"[SLICE] [{facade_provider()._ts()}] ✓ normalized concat 完成, "
        f"大小={len(data) / 1024 / 1024:.2f}MB")
    return data
