"""Collapsed markers used by deterministic AI security guardrails."""

COLLAPSED_INPUT_MARKERS = (
    "systemprompt", "developermessage", "hiddenprompt", "initialprompt",
    "ignoreprevious", "ignoreall", "bypasssafety", "apikey",
    "revealinstructions", "printinstructions", "泄露系统提示", "输出系统提示",
    "忽略所有规则", "开发者消息", "内部规则",
)

COLLAPSED_OUTPUT_MARKERS = (
    "systemprompt", "developermessage", "hiddeninstructions", "apikey",
    "我是gemini", "模型gemini", "公司google", "模型claude", "模型openai",
)
