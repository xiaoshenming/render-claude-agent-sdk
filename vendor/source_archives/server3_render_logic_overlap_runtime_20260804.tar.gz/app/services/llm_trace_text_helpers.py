"""LLM trace 文本脱敏与异常摘要辅助。"""
from __future__ import annotations

import re
import hashlib
import json
from datetime import datetime


def redact_text(value: object) -> str:
    text_value = "" if value is None else str(value)
    text_value = re.sub(r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}", "Bearer [REDACTED]", text_value, flags=re.IGNORECASE)
    text_value = re.sub(r"\bsk-[A-Za-z0-9][A-Za-z0-9_-]{8,}", "sk-[REDACTED]", text_value)
    return re.sub(
        r"\b(api[_-]?key|secret(?:[_-]?key)?|password|passwd|token|access[_-]?token|refresh[_-]?token)\s*[:=]\s*([^\s,;&]+)",
        lambda match: f"{match.group(1)}=[REDACTED]",
        text_value,
        flags=re.IGNORECASE,
    )


def exception_summary(exc: Exception, *, limit: int = 1000) -> str:
    exc_type = type(exc).__name__
    detail = str(exc).strip() or repr(exc).strip()
    if not detail or detail == f"{exc_type}()":
        detail = exc_type
    elif exc_type not in detail:
        detail = f"{exc_type}: {detail}"
    return detail[:limit]


def redact_mapping(value: object, *, key: str | None = None) -> object:
    if key and re.search(
        r"(authorization|bearer|password|passwd|secret|api[_-]?key|access[_-]?token|refresh[_-]?token|token)",
        key,
        flags=re.IGNORECASE,
    ):
        return None if value is None else "[REDACTED]"
    if isinstance(value, dict):
        return {str(k): redact_mapping(v, key=str(k)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact_mapping(item) for item in value]
    if isinstance(value, str):
        return "<image>" if value.startswith("data:image/") else redact_text(value)
    return value


def coerce_messages(messages: object) -> list[dict]:
    if not isinstance(messages, list):
        return []
    result = []
    for item in messages:
        if isinstance(item, dict):
            result.append({
                "role": redact_text(item.get("role") or "user"),
                "content": redact_mapping(item.get("content", "")),
            })
        else:
            result.append({"role": "user", "content": redact_text(item)})
    return result


def messages_to_text(messages: list[dict]) -> str:
    parts = []
    for item in messages:
        content = item.get("content", "")
        content_text = json.dumps(content, ensure_ascii=False, default=str) if isinstance(content, (dict, list)) else str(content or "")
        parts.append(f"{item.get('role') or 'user'}: {content_text}")
    return "\n\n".join(parts)


def messages_for_es_index(messages: list[dict]) -> list[dict]:
    result = []
    for item in messages:
        content = redact_mapping(item.get("content", ""))
        content_text = json.dumps(content, ensure_ascii=False, default=str) if isinstance(content, (dict, list)) else redact_text(content)
        result.append({"role": redact_text(item.get("role") or "user"), "content": content_text})
    return result


def trace_content_hash(*parts: object) -> str:
    raw = "\n\n".join(str(part or "") for part in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def iso(value: object) -> str | None:
    return value.isoformat() if isinstance(value, datetime) else None


def trace_max_text_chars(config_value, default: int) -> int:
    try:
        value = int(config_value("LLM_MESSAGE_TRACE_MAX_TEXT_CHARS", default))
    except (TypeError, ValueError):
        value = default
    return max(1000, value)


def truncate_text(value: object, max_chars: int) -> tuple[str, bool]:
    text_value = "" if value is None else str(value)
    if len(text_value) <= max_chars:
        return text_value, False
    return text_value[:max_chars], True
