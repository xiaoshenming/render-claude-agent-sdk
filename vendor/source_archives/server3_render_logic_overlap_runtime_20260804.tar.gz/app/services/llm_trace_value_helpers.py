"""LLM 追踪字段的标识、哈希与序列化辅助。"""
from __future__ import annotations

import hashlib
import json


def bounded_identifier(value: object, *, max_length: int, default: str | None = None) -> str | None:
    if value in (None, ""):
        return default
    text_value = str(value)
    if len(text_value) <= max_length:
        return text_value
    digest = hashlib.sha256(text_value.encode("utf-8")).hexdigest()[:12]
    prefix_length = max(0, max_length - len(digest) - 1)
    return f"{text_value[:prefix_length]}-{digest}"


def hash_prompt(prompt_content: str) -> str:
    return hashlib.sha256(prompt_content.encode("utf-8")).hexdigest()[:16]


def hash_text(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def slug(value: str | None, *, default: str = "unknown") -> str:
    import re
    text_value = str(value or default).strip().lower()
    text_value = re.sub(r"[^a-z0-9]+", "_", text_value).strip("_")
    return text_value or default


def is_retryable(error_type: str | None, error_message: str | None, keywords: tuple[str, ...]) -> bool:
    text_value = f"{error_type or ''} {error_message or ''}".lower()
    return any(keyword in text_value for keyword in keywords)


def json_param(value: dict | None) -> str:
    return json.dumps(value or {}, ensure_ascii=False, default=str)


def json_nullable_param(value: object) -> str | None:
    return None if value is None else json.dumps(value, ensure_ascii=False, default=str)


def dict_or_empty(value: object) -> dict:
    return value.copy() if isinstance(value, dict) else {}
