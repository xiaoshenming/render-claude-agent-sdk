"""LLM backend data model and provider request configuration."""

from dataclasses import dataclass
from typing import Any, List, Optional

from app.core.config import settings
from app.services.llm_responses_adapters import messages_to_responses_input

DEFAULT_GPT_REASONING_EFFORT = "none"
FALLBACK_GPT_REASONING_EFFORT = "high"
GPT5_HIGH_REASONING_CALL_TYPES = frozenset({
    "generate_stream", "llm_stream", "modify_slice",
})


@dataclass
class LLMBackend:
    name: str
    priority: int
    model: str
    api_base: str
    keys: List[str]
    fallback: bool = False
    timeout: Optional[int] = None
    extra_body: Optional[dict[str, Any]] = None
    reasoning_effort: Optional[str] = None
    reasoning_summary: Optional[str] = None
    text_verbosity: Optional[str] = None
    use_responses_api: Optional[bool] = None
    allowed_openai_params: Optional[List[str]] = None

    def resolved_api_base(self) -> Optional[str]:
        if not self.api_base:
            return None
        base = self.api_base.rstrip("/")
        model = self.model.lower()
        if (
            (model.startswith("openai/") or ("/" not in model and model.startswith("gpt")))
            and not base.endswith("/v1")
        ):
            base += "/v1"
        return base

    @property
    def model_id(self) -> str:
        return self.model.split("/", 1)[-1]

    @property
    def is_openai_gpt(self) -> bool:
        model = self.model.lower()
        return self.model_id.lower().startswith("gpt") and (
            model.startswith("openai/") or "/" not in model
        )

    @property
    def is_openai_gpt5(self) -> bool:
        model = self.model.lower()
        return self.model_id.lower().startswith("gpt-5") and (
            model.startswith("openai/") or "/" not in model
        )

    @property
    def uses_responses_api(self) -> bool:
        if self.is_openai_gpt:
            return True
        return bool(self.use_responses_api) if self.use_responses_api is not None else False

    @property
    def effective_reasoning_effort(self) -> Optional[str]:
        if self.reasoning_effort:
            return self.reasoning_effort
        return DEFAULT_GPT_REASONING_EFFORT if self.is_openai_gpt5 else None

    @property
    def effective_reasoning_summary(self) -> Optional[str]:
        if self.reasoning_summary:
            return self.reasoning_summary
        return "detailed" if self.is_openai_gpt5 else None

    @property
    def effective_text_verbosity(self) -> Optional[str]:
        if self.text_verbosity:
            return self.text_verbosity
        return "high" if self.is_openai_gpt5 else None

    @property
    def temperature(self) -> Optional[float]:
        if self.model.startswith("anthropic/"):
            return None
        model_id = self.model.lower().split("/", 1)[-1]
        if model_id.startswith("gpt-5") or self.model.startswith("gemini/"):
            return 1.0
        return settings.LLM_TEMPERATURE

    @property
    def effective_timeout(self) -> int:
        return self.timeout if self.timeout else settings.LLM_TIMEOUT

    def litellm_extra_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}
        if self.extra_body:
            kwargs["extra_body"] = self.extra_body
        if self.effective_reasoning_effort:
            kwargs["reasoning_effort"] = self.effective_reasoning_effort
        if self.allowed_openai_params:
            kwargs["allowed_openai_params"] = self.allowed_openai_params
        return kwargs

    def litellm_temperature_kwargs(self) -> dict[str, float]:
        return {} if self.temperature is None else {"temperature": self.temperature}

    def reasoning_effort_for_call_type(self, call_type: str | None) -> Optional[str]:
        normalized = str(call_type or "").strip()
        if (
            self.is_openai_gpt5 and not self.reasoning_effort
            and normalized in GPT5_HIGH_REASONING_CALL_TYPES
        ):
            return FALLBACK_GPT_REASONING_EFFORT
        return self.effective_reasoning_effort

    def responses_create_kwargs(
        self, messages: list, max_output_tokens: int, call_type: str | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self.model_id,
            "input": messages_to_responses_input(messages),
            "max_output_tokens": max_output_tokens,
        }
        if prompt_cache_key:
            kwargs["prompt_cache_key"] = str(prompt_cache_key)
        if prompt_cache_retention in {"in-memory", "24h"}:
            kwargs["prompt_cache_retention"] = prompt_cache_retention
        effort = self.reasoning_effort_for_call_type(call_type)
        if effort:
            reasoning: dict[str, Any] = {"effort": effort}
            if self.effective_reasoning_summary and effort != "none":
                reasoning["summary"] = self.effective_reasoning_summary
            kwargs["reasoning"] = reasoning
        if self.effective_text_verbosity:
            kwargs["text"] = {"verbosity": self.effective_text_verbosity}
        return kwargs
