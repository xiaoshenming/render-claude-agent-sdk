"""错误代码采集器 — 把渲染管线各阶段产生的"出错代码"上传到 COS 并入库。

调用方式：
    from app.services.failed_code_recorder import record_failed_code
    await record_failed_code(
        job_id=job_id,
        code=src_text,
        source="syntax_fix",      # 必填：哪一步产生的失败代码
        scene_name="Scene_03",    # 可选
        attempt=2,                # 可选
        error_type="SyntaxError", # 可选
        error_message=str(exc),   # 可选
        stage="LLM_FIX",          # 可选
    )

特点：
- COS 路径自带 source 标签（codes/failed/{source}/job_xxx_scene_n_aN.py），方便人工排查
- 同一 job + scene + source + attempt + 同一份代码只入库一次（DB 层 UNIQUE 约束兜底）
- repair_candidate 被成功修复前的代码也会收录；它才是 admin 里要看的"错误代码"
- 永远不抛异常，只记日志 — 错误代码采集不能影响主流程
"""
from __future__ import annotations

import hashlib
import logging
import time
import uuid
from typing import Optional

from sqlalchemy import text

from app.database.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


def _ts() -> str:
    return time.strftime("%H:%M:%S")


def _ulid_like() -> str:
    return uuid.uuid4().hex[:26].upper()


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_segment(value: Optional[str], default: str = "unknown") -> str:
    if not value:
        return default
    cleaned = "".join(
        c if c.isalnum() or c in ("_", "-") else "_" for c in value
    )
    return cleaned[:64] or default


async def record_failed_code(
    *,
    job_id: str,
    code: str | bytes | None,
    source: str,
    scene_name: Optional[str] = None,
    attempt: int = 0,
    error_type: Optional[str] = None,
    error_message: Optional[str] = None,
    stage: Optional[str] = None,
) -> Optional[str]:
    """采集一份错误代码 → COS + DB。返回 code_url 或 None（被跳过/出错时）。"""
    if not code:
        return None
    if isinstance(code, str):
        data = code.encode("utf-8", errors="replace")
    else:
        data = code
    if len(data) < 10:  # 太短没意义
        return None

    sha = _sha256(data)

    # COS Key 带 source 前缀方便分类
    src_seg = _safe_segment(source, "misc")
    scene_seg = _safe_segment(scene_name, "no_scene")
    cos_key = (
        f"codes/failed/{src_seg}/job_{job_id}/"
        f"{scene_seg}_a{attempt:02d}_{sha[:8]}.py"
    )

    # 上传 COS
    code_url: Optional[str] = None
    try:
        from app.services.storage_service import storage_service
        code_url = await storage_service.upload_file(
            cos_key,
            data,
            content_type="text/x-python; charset=utf-8",
        )
    except Exception as e:
        logger.warning(
            f"[FAILED_CODE] [{_ts()}] COS 上传失败 job={job_id} "
            f"source={source}: {e}"
        )
        return None

    if not code_url:
        return None

    # 写库（去重：同 job + scene + source + attempt + sha 直接跳过）
    try:
        session = AsyncSessionLocal()
        try:
            existing = (await session.execute(
                text(
                    "SELECT id FROM failed_code_records "
                    "WHERE job_id = :job_id "
                    "AND source = :source "
                    "AND attempt = :attempt "
                    "AND code_sha256 = :sha "
                    "AND (scene_name = :scene_name OR (scene_name IS NULL AND :scene_name IS NULL)) "
                    "LIMIT 1"
                ),
                {
                    "job_id": job_id,
                    "source": source[:64],
                    "attempt": int(attempt or 0),
                    "sha": sha,
                    "scene_name": (scene_name or None),
                },
            )).first()
            if existing:
                logger.debug(
                    f"[FAILED_CODE] [{_ts()}] 已存在同 event+sha 记录，跳过 "
                    f"job={job_id} scene={scene_name or '-'} "
                    f"source={source} attempt={attempt} sha={sha[:8]}"
                )
                return code_url

            await session.execute(
                text(
                    """
                    INSERT INTO failed_code_records (
                        id, job_id, scene_name, source, stage, attempt,
                        error_type, error_message,
                        code_url, code_size, code_sha256, created_at
                    ) VALUES (
                        :id, :job_id, :scene_name, :source, :stage, :attempt,
                        :error_type, :error_message,
                        :code_url, :code_size, :sha, NOW()
                    )
                    """
                ),
                {
                    "id": _ulid_like(),
                    "job_id": job_id,
                    "scene_name": (scene_name or None),
                    "source": source[:64],
                    "stage": (stage or None),
                    "attempt": int(attempt or 0),
                    "error_type": (error_type or None),
                    "error_message": (
                        error_message[:2000] if error_message else None
                    ),
                    "code_url": code_url,
                    "code_size": len(data),
                    "sha": sha,
                },
            )
            await session.commit()
            logger.info(
                f"[FAILED_CODE] [{_ts()}] ✓ 收录 job={job_id} "
                f"source={source} scene={scene_name or '-'} "
                f"attempt={attempt} size={len(data)}"
            )
        finally:
            await session.close()
    except Exception as e:
        # UNIQUE 冲突 / 数据库异常都视为非致命
        logger.warning(
            f"[FAILED_CODE] [{_ts()}] DB 写入失败 job={job_id} "
            f"source={source}: {e}"
        )

    return code_url
