"""LLM backend health and cooldown registry."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from app.core.config import settings
from app.services import backend_health_storage as storage


UTC = timezone.utc
DEFAULT_BACKEND_HEALTH_STATE_FILE = "/tmp/mathpi_render_backend_health.json"
DEFAULT_MAX_COOLDOWN_MULTIPLIER = 8


def _int_setting(name: str, fallback: int) -> int:
    try:
        return int(getattr(settings, name, fallback) or fallback)
    except (TypeError, ValueError):
        return fallback


def _scaled_cooldown_seconds(
    *,
    failure_count: int,
    failure_threshold: int,
    cooldown_seconds: int,
) -> int:
    base_seconds = max(1, int(cooldown_seconds or 1))
    threshold = max(1, int(failure_threshold or 1))
    failures_over_threshold = max(0, int(failure_count or 0) - threshold)
    multiplier = 2 ** min(failures_over_threshold, 3)
    configured_max = _int_setting(
        "LLM_BACKEND_HEALTH_MAX_COOLDOWN_SECONDS",
        base_seconds * DEFAULT_MAX_COOLDOWN_MULTIPLIER,
    )
    max_seconds = max(base_seconds, configured_max)
    return min(base_seconds * multiplier, max_seconds)


def _effective_failure_count(record: BackendHealthRecord) -> int:
    return max(int(record.failure_count or 0), len(record.sample_errors or []))


@dataclass(frozen=True, slots=True)
class BackendHealthKey:
    backend_name: str
    model: str
    call_type: str


@dataclass(slots=True)
class BackendHealthRecord:
    failure_count: int = 0
    last_error_type: str | None = None
    last_error_at: datetime | None = None
    cooldown_until: datetime | None = None
    cooldown_until_monotonic: float = 0.0
    sample_errors: list[str] = field(default_factory=list)

    def is_cooling_down(self, *, now_monotonic: float | None = None) -> bool:
        if self.cooldown_until is not None:
            return self.cooldown_until > datetime.now(UTC)
        now = time.monotonic() if now_monotonic is None else now_monotonic
        return self.cooldown_until_monotonic > now


class BackendHealthRegistry:
    def __init__(self) -> None:
        self._records: dict[BackendHealthKey, BackendHealthRecord] = {}

    def _state_file(self):
        return storage.state_file(settings, DEFAULT_BACKEND_HEALTH_STATE_FILE)

    def _key(self, backend_name: str, model: str, call_type: str) -> BackendHealthKey:
        return BackendHealthKey(
            backend_name=str(backend_name or "unknown"),
            model=str(model or "unknown"),
            call_type=str(call_type or "llm_call"),
        )

    def _key_id(self, key: BackendHealthKey) -> str:
        return "\t".join([key.backend_name, key.model, key.call_type])

    def _mapping_to_record(self, mapping: dict[str, Any] | None) -> BackendHealthRecord:
        return storage.mapping_to_record(mapping, BackendHealthRecord)

    def _record_to_mapping(self, record: BackendHealthRecord) -> dict[str, Any]:
        return storage.record_to_mapping(record)

    def _locked_state(self, *, write: bool):
        return storage.locked_state(
            write=write,
            settings_obj=settings,
            default_state_file=DEFAULT_BACKEND_HEALTH_STATE_FILE,
        )

    def clear(self) -> None:
        self._records.clear()
        path = self._state_file()
        if path is not None:
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            try:
                path.with_name(f"{path.name}.lock").unlink()
            except FileNotFoundError:
                pass

    def cooldown_payload(
        self,
        *,
        backend_name: str,
        model: str,
        call_type: str,
        now_monotonic: float | None = None,
    ) -> dict[str, Any] | None:
        key = self._key(backend_name, model, call_type)
        record = self._records.get(key)
        with self._locked_state(write=False) as state:
            if state is not None:
                record = self._mapping_to_record(
                    state.get("records", {}).get(self._key_id(key))
                )
                self._records[key] = record
        if record is not None:
            self._extend_persistent_cooldown(record)
        if record is None or not record.is_cooling_down(now_monotonic=now_monotonic):
            return None
        now = time.monotonic() if now_monotonic is None else now_monotonic
        if record.cooldown_until is not None:
            remaining = max(0, int((record.cooldown_until - datetime.now(UTC)).total_seconds()))
        else:
            remaining = max(0, int(record.cooldown_until_monotonic - now))
        return {
            "backend_name": key.backend_name,
            "model": key.model,
            "call_type": key.call_type,
            "cooldown_until": record.cooldown_until.isoformat()
            if record.cooldown_until
            else None,
            "cooldown_remaining_sec": remaining,
            "failure_count": record.failure_count,
            "last_error_type": record.last_error_type,
            "backend_skip_reason": "model_backend_cooldown",
        }

    def record_success(self, *, backend_name: str, model: str, call_type: str) -> None:
        key = self._key(backend_name, model, call_type)
        record = self._records.get(key)
        with self._locked_state(write=True) as state:
            if state is not None:
                record = self._mapping_to_record(
                    state.get("records", {}).get(self._key_id(key))
                )
        if record is None:
            return
        record.failure_count = 0
        record.cooldown_until = None
        record.cooldown_until_monotonic = 0.0
        self._records[key] = record
        with self._locked_state(write=True) as state:
            if state is not None:
                state["records"][self._key_id(key)] = self._record_to_mapping(record)

    def record_failure(
        self,
        *,
        backend_name: str,
        model: str,
        call_type: str,
        error_type: str,
        error_message: str,
        transient: bool,
        failure_threshold: int,
        cooldown_seconds: int,
        sample_limit: int = 5,
    ) -> BackendHealthRecord:
        key = self._key(backend_name, model, call_type)
        with self._locked_state(write=True) as state:
            if state is None:
                record = self._records.setdefault(key, BackendHealthRecord())
            else:
                record = self._mapping_to_record(
                    state.get("records", {}).get(self._key_id(key))
                )
                self._records[key] = record
            self._record_failure(
                record,
                error_type=error_type,
                error_message=error_message,
                transient=transient,
                failure_threshold=failure_threshold,
                cooldown_seconds=cooldown_seconds,
                sample_limit=sample_limit,
            )
            if state is not None:
                state["records"][self._key_id(key)] = self._record_to_mapping(record)
        return record

    def _record_failure(
        self,
        record: BackendHealthRecord,
        *,
        error_type: str,
        error_message: str,
        transient: bool,
        failure_threshold: int,
        cooldown_seconds: int,
        sample_limit: int,
    ) -> None:
        record.last_error_type = str(error_type or "Exception")
        record.last_error_at = datetime.now(UTC)
        message = str(error_message or "")[:300]
        if message:
            record.sample_errors = [*record.sample_errors[-(sample_limit - 1):], message]
        if transient:
            record.failure_count += 1
            effective_failure_count = _effective_failure_count(record)
            if effective_failure_count >= max(1, int(failure_threshold or 1)):
                seconds = _scaled_cooldown_seconds(
                    failure_count=effective_failure_count,
                    failure_threshold=failure_threshold,
                    cooldown_seconds=cooldown_seconds,
                )
                record.cooldown_until_monotonic = time.monotonic() + seconds
                record.cooldown_until = datetime.now(UTC) + timedelta(seconds=seconds)
        else:
            record.failure_count = 0

    def _extend_persistent_cooldown(self, record: BackendHealthRecord) -> None:
        if record.last_error_at is None:
            return
        if (
            record.cooldown_until is not None
            and record.cooldown_until > datetime.now(UTC)
        ):
            return
        failure_threshold = _int_setting("LLM_BACKEND_HEALTH_FAILURE_THRESHOLD", 2)
        effective_failure_count = _effective_failure_count(record)
        if effective_failure_count < max(1, failure_threshold):
            return
        cooldown_seconds = _int_setting("LLM_BACKEND_HEALTH_COOLDOWN_SECONDS", 300)
        seconds = _scaled_cooldown_seconds(
            failure_count=effective_failure_count,
            failure_threshold=failure_threshold,
            cooldown_seconds=cooldown_seconds,
        )
        extended_until = record.last_error_at + timedelta(seconds=seconds)
        if extended_until <= datetime.now(UTC):
            return
        record.cooldown_until = extended_until
        remaining = max(0.0, (extended_until - datetime.now(UTC)).total_seconds())
        record.cooldown_until_monotonic = time.monotonic() + remaining

    def snapshot(self) -> list[dict[str, Any]]:
        with self._locked_state(write=False) as state:
            if state is not None:
                for key_id, mapping in state.get("records", {}).items():
                    try:
                        backend_name, model, call_type = key_id.split("\t", 2)
                    except ValueError:
                        continue
                    key = self._key(backend_name, model, call_type)
                    self._records[key] = self._mapping_to_record(mapping)
        rows: list[dict[str, Any]] = []
        for key, record in self._records.items():
            rows.append({
                "backend_name": key.backend_name,
                "model": key.model,
                "call_type": key.call_type,
                "cooldown_until": record.cooldown_until.isoformat()
                if record.cooldown_until
                else None,
                "failure_count": record.failure_count,
                "last_error_type": record.last_error_type,
                "last_error_at": record.last_error_at.isoformat()
                if record.last_error_at
                else None,
                "sample_errors": list(record.sample_errors),
            })
        return rows


backend_health_registry = BackendHealthRegistry()
