"""Persistent storage helpers for backend health records."""

import fcntl
import json
import os
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

UTC = timezone.utc
DEFAULT_STATE_FILE = "/tmp/mathpi_render_backend_health.json"


def state_file(settings_obj, default_state_file: str = DEFAULT_STATE_FILE) -> Path:
    path = str(
        getattr(settings_obj, "LLM_BACKEND_HEALTH_STATE_FILE", default_state_file)
        or default_state_file
    ).strip()
    if path.lower() in {"0", "false", "none", "off", "disabled"}:
        path = default_state_file
    return Path(path)


def mapping_to_record(mapping: dict[str, Any] | None, record_type):
    record = record_type()
    if not mapping:
        return record
    record.failure_count = int(mapping.get("failure_count") or 0)
    record.last_error_type = mapping.get("last_error_type")
    for field_name in ("last_error_at", "cooldown_until"):
        if mapping.get(field_name):
            try:
                setattr(record, field_name, datetime.fromisoformat(str(mapping[field_name])))
            except ValueError:
                setattr(record, field_name, None)
    if record.cooldown_until is not None:
        remaining = max(0.0, (record.cooldown_until - datetime.now(UTC)).total_seconds())
        record.cooldown_until_monotonic = time.monotonic() + remaining
    record.sample_errors = list(mapping.get("sample_errors") or [])[-5:]
    return record


def record_to_mapping(record) -> dict[str, Any]:
    return {
        "failure_count": record.failure_count,
        "last_error_type": record.last_error_type,
        "last_error_at": record.last_error_at.isoformat() if record.last_error_at else None,
        "cooldown_until": (
            record.cooldown_until.isoformat() if record.cooldown_until else None
        ),
        "sample_errors": list(record.sample_errors),
    }


@contextmanager
def locked_state(*, write: bool, settings_obj, default_state_file: str):
    path = state_file(settings_obj, default_state_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_name(f"{path.name}.lock")
    with lock_path.open("a+", encoding="utf-8") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX if write else fcntl.LOCK_SH)
        try:
            raw = path.read_text(encoding="utf-8").strip()
        except FileNotFoundError:
            raw = ""
        try:
            state = json.loads(raw) if raw else {"records": {}}
        except json.JSONDecodeError:
            state = {"records": {}}
        state.setdefault("records", {})
        yield state
        if write:
            tmp_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
            with tmp_path.open("w", encoding="utf-8") as handle:
                json.dump(state, handle, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path, path)
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
