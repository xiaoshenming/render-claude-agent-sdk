"""Image and membership watermark renderers."""
import logging
import os
from typing import Any, Callable
from app.services.ffmpeg_watermark_text import (_clamp_opacity,_positive_int,_positive_float,_resolve_watermark_image_path,_overlay_position)

logger = logging.getLogger(__name__)
_AUDIO_FILTER = "aresample=async=1:first_pts=0,apad"
facade_provider: Callable[[], Any] | None = None

async def apply_aigc_visible_watermark(
    input_bytes: bytes,
    output_dir: str,
    job_id: str,
    config: dict,
) -> bytes:
    """烧录 AIGC 合规显性水印，与会员图片水印保持独立。"""
    config = config or {}
    return await draw_image_watermark(
        input_bytes=input_bytes,
        output_dir=output_dir,
        job_id=f"{job_id}_aigc_visible",
        image_path=_resolve_watermark_image_path(
            config.get("image_path"),
            "ai-hecheng-02-tech.png",
        ),
        opacity=_clamp_opacity(config.get("opacity", 0.86), 0.86),
        margin=_positive_int(config.get("margin", 24), 24),
        position=str(config.get("position") or "bottom_right"),
        scale_ratio=_positive_float(config.get("scale_ratio", 0.085), 0.085),
    )


async def draw_image_watermark(
    *,
    input_bytes: bytes,
    output_dir: str,
    job_id: str,
    image_path: str,
    opacity: float = 0.86,
    margin: int = 24,
    position: str = "bottom_right",
    scale_ratio: float = 0.085,
) -> bytes:
    """对视频叠加图片水印，返回处理后的字节流。"""
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"水印图片不存在: {image_path}")
    os.makedirs(output_dir, exist_ok=True)
    tmp_input = os.path.join(output_dir, f"video_{job_id}_image_raw.mp4")
    tmp_output = os.path.join(output_dir, f"video_{job_id}_image_wm.mp4")
    try:
        with open(tmp_input, "wb") as f:
            f.write(input_bytes)

        safe_opacity = _clamp_opacity(opacity, 0.86)
        safe_margin = _positive_int(margin, 24)
        safe_scale_ratio = _positive_float(scale_ratio, 0.085)
        pos = _overlay_position(str(position or ""), safe_margin)
        vf = (
            f"[1:v]scale=-1:ih*{safe_scale_ratio}/1[wm_scaled];"
            f"[wm_scaled]format=rgba,"
            f"colorchannelmixer=aa={safe_opacity}[wm];"
            f"[0:v][wm]overlay={pos},format=yuv420p[v]"
        )
        cmd = [
            "ffmpeg",
            "-i",
            tmp_input,
            "-i",
            image_path,
            "-filter_complex",
            vf,
            "-map",
            "[v]",
            "-map",
            "0:a:0?",
            "-af",
            _AUDIO_FILTER,
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-b:a",
            "128k",
            "-ar",
            "48000",
            "-ac",
            "2",
            "-shortest",
            "-map_metadata",
            "0",
            "-movflags",
            "+faststart+use_metadata_tags",
            "-max_muxing_queue_size",
            "1024",
            "-avoid_negative_ts",
            "make_zero",
            tmp_output,
            "-y",
        ]
        cp = await facade_provider().run_cmd_async(cmd, timeout=180)
        if cp.returncode != 0:
            raise Exception(
                "FFmpeg image watermark failed: "
                f"{cp.stderr[:300] if cp.stderr else 'unknown'}"
            )

        with open(tmp_output, "rb") as f:
            result = f.read()

        logger.info(
            f"[IMAGE_WATERMARK] [{facade_provider()._ts()}] 图片水印叠加完成, "
            f"大小={len(result) / 1024 / 1024:.2f}MB"
        )
        return result
    finally:
        for p in [tmp_input, tmp_output]:
            try:
                os.remove(p)
            except OSError:
                pass


async def apply_watermark(
    input_bytes: bytes,
    output_dir: str,
    job_id: str,
    wm_config: dict,
    assets_base_dir: str,
) -> bytes:
    """对视频叠加图片水印，返回处理后的字节流。

    失败时抛出异常（调用方负责降级处理）。
    """
    wm_config = wm_config if isinstance(wm_config, dict) else {}
    os.makedirs(output_dir, exist_ok=True)
    tmp_input = os.path.join(output_dir, f"video_{job_id}_raw.mp4")
    tmp_output = os.path.join(output_dir, f"video_{job_id}_wm.mp4")
    try:
        with open(tmp_input, "wb") as f:
            f.write(input_bytes)

        wm_style = wm_config.get("style", "light")
        wm_dir = os.path.join(assets_base_dir, "assets", "watermarks")
        wm_path = os.path.join(
            wm_dir,
            "watermark_dark.png" if wm_style == "dark" else "watermark_light.png",
        )
        if not os.path.exists(wm_path):
            raise FileNotFoundError(f"水印图片不存在: {wm_path}")

        opacity = wm_config.get("opacity", 0.3)
        position = wm_config.get("position", "bottom_right")
        margin = wm_config.get("margin", 20)
        scale_ratio = wm_config.get("scale_ratio", 0.05)

        position_map = {
            "bottom_right": f"W-w-{margin}:H-h-{margin}",
            "bottom_left": f"{margin}:H-h-{margin}",
            "top_right": f"W-w-{margin}:{margin}",
            "top_left": f"{margin}:{margin}",
        }
        pos = position_map.get(position, position_map["bottom_right"])

        vf = (
            f"[1:v]scale=-1:ih*{scale_ratio}/1[wm_scaled];"
            f"[wm_scaled]format=rgba,"
            f"colorchannelmixer=aa={opacity}[wm];"
            f"[0:v][wm]overlay={pos},format=yuv420p[v]"
        )
        cmd = [
            "ffmpeg", "-i", tmp_input, "-i", wm_path,
            "-filter_complex", vf,
            "-map", "[v]",
            "-map", "0:a:0?",
            "-af", _AUDIO_FILTER,
            "-c:v", "libx264",
            "-preset", "veryfast",
            "-crf", "18",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac",
            "-b:a", "128k",
            "-ar", "48000",
            "-ac", "2",
            "-shortest",
            "-movflags", "+faststart",
            "-max_muxing_queue_size", "1024",
            "-avoid_negative_ts", "make_zero",
            tmp_output, "-y",
        ]
        cp = await facade_provider().run_cmd_async(cmd, timeout=180)
        if cp.returncode != 0:
            raise Exception(
                f"FFmpeg watermark failed: "
                f"{cp.stderr[:200] if cp.stderr else 'unknown'}")

        with open(tmp_output, "rb") as f:
            result = f.read()

        logger.info(
            f"[WATERMARK] [{facade_provider()._ts()}] 水印叠加完成, "
            f"大小={len(result) / 1024 / 1024:.2f}MB")
        return result
    finally:
        for p in [tmp_input, tmp_output]:
            try:
                os.remove(p)
            except OSError:
                pass
