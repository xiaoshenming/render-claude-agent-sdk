"""Streaming watchdogs, exceptions, and response extraction."""

import asyncio
import time
from types import SimpleNamespace
from typing import Any, Optional

from app.core.config import settings
from app.services.llm_usage import extract_usage_info, get_value, merge_usage_info


class LLMEmptyResponseError(RuntimeError):
    def __init__(self, message: str, usage_info: Optional[dict] = None):
        super().__init__(message)
        self.usage_info = usage_info or {}


class LLMStreamTimeoutError(TimeoutError):
    def __init__(self, message: str, usage_info: Optional[dict] = None):
        super().__init__(message)
        self.usage_info = usage_info or {}


class LLMStreamIncompleteError(RuntimeError):
    def __init__(self, message: str, usage_info: Optional[dict] = None):
        super().__init__(message)
        self.usage_info = usage_info or {}


class LLMProviderCancelledError(RuntimeError):
    def __init__(self, message: str, usage_info: Optional[dict] = None):
        super().__init__(message)
        self.usage_info = usage_info or {}


def stream_timeout_setting(name: str, fallback_timeout: int, *, config=settings) -> int:
    try:
        value = int(getattr(config, name, 0) or 0)
    except (TypeError, ValueError):
        value = 0
    if value > 0:
        return value
    try:
        fallback = int(fallback_timeout or 0)
    except (TypeError, ValueError):
        fallback = 0
    return max(1, fallback or int(getattr(config, "LLM_TIMEOUT", 120) or 120))


def stream_first_content_timeout(fallback_timeout: int, *, config=settings) -> int:
    explicit = stream_timeout_setting("LLM_STREAM_FIRST_CONTENT_TIMEOUT", 0, config=config)
    configured = int(getattr(config, "LLM_STREAM_FIRST_CONTENT_TIMEOUT", 0) or 0)
    if configured > 0:
        return explicit
    timeout = stream_timeout_setting("LLM_STREAM_FIRST_CONTENT_TIMEOUT", fallback_timeout, config=config)
    try:
        cap = int(getattr(config, "LLM_STREAM_FIRST_CONTENT_TIMEOUT_CAP", 180) or 0)
    except (TypeError, ValueError):
        cap = 180
    return max(1, min(timeout, cap)) if cap > 0 else timeout


def stream_idle_timeout(fallback_timeout: int, *, config=settings) -> int:
    return stream_timeout_setting("LLM_STREAM_IDLE_TIMEOUT", fallback_timeout, config=config)


def stream_open_timeout(fallback_timeout: int, *, config=settings) -> int:
    configured = stream_timeout_setting("LLM_STREAM_OPEN_TIMEOUT", 0, config=config)
    try:
        raw = int(getattr(config, "LLM_STREAM_OPEN_TIMEOUT", 0) or 0)
    except (TypeError, ValueError):
        raw = 0
    return configured if raw > 0 else stream_first_content_timeout(fallback_timeout, config=config)


def responses_stream_client_timeout(fallback_timeout: int, *, config=settings) -> int:
    try:
        configured = int(getattr(config, "LLM_RESPONSES_STREAM_TIMEOUT", 900) or 0)
    except (TypeError, ValueError):
        configured = 900
    try:
        fallback = int(fallback_timeout or 0)
    except (TypeError, ValueError):
        fallback = 0
    if configured <= 0:
        configured = fallback
    return max(1, configured, fallback or int(getattr(config, "LLM_TIMEOUT", 120) or 120))


def task_cancellation_requested() -> bool:
    task = asyncio.current_task()
    return bool(task and task.cancelling())


def cancelled_error_message(exc: BaseException, *, local: bool) -> str:
    message = str(exc).strip()
    if message:
        return message
    if local:
        return "LLM task cancelled by local request, timeout, or budget guard"
    return "LLM call cancelled by provider or relay"


async def next_stream_item(
    stream: Any, *, deadline: float, timeout_seconds: int,
    stream_started: bool, usage_info: dict,
) -> Any:
    remaining = deadline - time.monotonic()
    phase = "idle" if stream_started else "first content"
    if remaining <= 0:
        raise LLMStreamTimeoutError(
            f"LLM stream {phase} timeout after {timeout_seconds}s", dict(usage_info)
        )
    try:
        return await asyncio.wait_for(anext(stream), timeout=remaining)
    except asyncio.TimeoutError as exc:
        raise LLMStreamTimeoutError(
            f"LLM stream {phase} timeout after {timeout_seconds}s", dict(usage_info)
        ) from exc


async def await_stream_open(awaitable: Any, *, timeout_seconds: int, usage_info: dict) -> Any:
    try:
        return await asyncio.wait_for(awaitable, timeout=timeout_seconds)
    except asyncio.TimeoutError as exc:
        raise LLMStreamTimeoutError(
            f"LLM stream open timeout after {timeout_seconds}s", dict(usage_info)
        ) from exc


def extract_message_content(response) -> tuple[str, Any]:
    usage_info = extract_usage_info(response)
    choices = getattr(response, "choices", None) or []
    if not choices:
        raise LLMEmptyResponseError("LLM response contains no choices", usage_info)
    choice = choices[0]
    content = getattr(getattr(choice, "message", None), "content", None) or ""
    finish_reason = getattr(choice, "finish_reason", None)
    if not str(content).strip():
        raise LLMEmptyResponseError("LLM response content is empty", usage_info)
    return content, finish_reason


def collect_stream_usage(chunk, stream_usage: dict) -> None:
    usage = get_value(chunk, "usage")
    if usage:
        merge_usage_info(stream_usage, extract_usage_info(SimpleNamespace(usage=usage)))
