"""智能视频标题命名服务。

通过独立标题 LLM 管线根据用户原始 prompt 生成简洁、贴切的视频标题（≤15 字）。
禁止把 prompt 首句、开头字幕或描述前缀直接当作标题。
"""
from __future__ import annotations

import logging
import re
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


_SYSTEM_PROMPT = (
    "你是数学教学视频的『标题命名助手』。\n"
    "用户会给你一段题目 / 知识点描述，你必须输出**一个**简短、专业、像教辅章节名的视频标题。\n\n"
    "【硬性要求】\n"
    "1. 4~12 个汉字，单行，不带任何标点 / 引号 / 序号 / emoji / 括号 / 冒号；\n"
    "2. 直接概括**核心数学知识点**或**题型**，不要复述题面、不要带『讲解』『教程』『视频』『解析』等冗余词；\n"
    "3. **严禁**输出『片段』『环节』『步骤』『审题』『切入』『分析』『解答』『总结』等 Scene/切片层名词；\n"
    "4. **严禁**输出 Scene_xx_、片段 1、第一步、Step 1 这类编号或脚手架名；\n"
    "5. 只输出最终标题，不要解释、不要候选列表。\n\n"
    "【优秀示例】\n"
    "  输入：求证 a²+b²=c² 的几何意义\n"
    "  输出：勾股定理几何证明\n\n"
    "  输入：等腰三角形的两条腰相等吗\n"
    "  输出：等腰三角形性质\n\n"
    "  输入：直角三角形有哪些核心性质\n"
    "  输出：直角三角形三要素\n\n"
    "  输入：函数 y=sin x 的图像有什么特征\n"
    "  输出：正弦函数图像\n\n"
    "【反例（禁止输出）】\n"
    "  ❌ 片段 1：审题与切入\n"
    "  ❌ 第一步：分析题目\n"
    "  ❌ Scene_01_Intro\n"
    "  ❌ 数学讲解视频"
)


# 标题反模式：命中任意一条则视为无效，触发回退
_BAD_TITLE_PATTERNS = [
    r'片段', r'环节', r'步骤', r'第[一二三四五六七八九十\d]+[步段节]',
    r'^Scene[_\s]', r'^step\s*\d', r'审题', r'切入',
    r'^片', r'^解答$', r'^分析$', r'^总结$', r'^引入$', r'^开场$',
    r'^Intro$', r'^Outline$',
    r'生成.*视频', r'制作.*视频', r'创建.*视频', r'输出.*视频',
    r'视频', r'字幕', r'开头', r'直观地展示', r'请你', r'请生成',
    r'\d+\s*秒', r'秒左右', r'教学视频', r'讲解视频',
]


def _is_bad_title(s: str) -> bool:
    if not s:
        return True
    for p in _BAD_TITLE_PATTERNS:
        if re.search(p, s, re.IGNORECASE):
            return True
    # 含半角/全角冒号说明像 "片段1：xxx" 这种结构（正常标题不应有）
    if '：' in s or ':' in s:
        return True
    return False


def _sanitize(raw: str, *, max_chars: int = 15) -> str:
    if not raw:
        return ""
    s = raw.strip().splitlines()[0]
    # 剥离常见 markdown 包裹
    s = re.sub(r'^\s*[#>*\-]+\s*', '', s)
    s = re.sub(r'^\s*\d+[\.\)、]\s*', '', s)
    s = re.sub(r'^[\s"\'`“”《》【】（）()\[\]\-—–·:：]+|[\s"\'`“”《》【】（）()\[\]\-—–·。.!?！？:：]+$', '', s)
    s = s.replace('"', '').replace("'", '').replace('`', '')
    return s[:max_chars]


def _csv_values(raw: str | None) -> list[str]:
    return [item.strip() for item in (raw or "").split(",") if item.strip()]


def _title_backend_name(model: str) -> str:
    model_id = (model or "qwen-flash").split("/", 1)[-1].strip().lower()
    if model_id in {"qwen-flash", "qwen3.5-flash"}:
        return "title-qwen-flash"
    compact = re.sub(r"[^a-z0-9]+", "-", model_id).strip("-")
    return f"title-{compact or 'model'}"


def _build_title_llm_manager():
    """Build the dedicated title LLM manager without touching render backends."""
    from app.services.llm_service import _Backend, _LLMManager, _compose_backend_model

    api_base = (settings.TITLE_API_BASE or settings.QWEN_API_BASE or "").strip()
    keys = _csv_values(settings.TITLE_API_KEY) or _csv_values(settings.QWEN_API_KEYS)
    protocol = (settings.TITLE_PROTOCOL or "openai").strip()
    model = (settings.TITLE_MODEL or "qwen-flash").strip()

    if not api_base or not keys:
        raise ValueError("TITLE_API_BASE/TITLE_API_KEY 未配置")

    manager = _LLMManager()
    manager._backends = [
        _Backend(
            name=_title_backend_name(model),
            priority=1,
            model=_compose_backend_model(protocol, model),
            api_base=api_base,
            keys=keys,
            timeout=int(settings.TITLE_TIMEOUT or 30),
            fallback=False,
        )
    ]
    return manager


async def generate_smart_title(
    prompt: str,
    *,
    fallback_code: str = "",
    job_id: Optional[str] = None,
) -> str:
    """根据用户 prompt 智能生成视频标题。

    必须优先调用独立标题 LLM；失败时使用保守默认标题。
    不再用 prompt 首句、描述前缀或开头字幕兜底，避免把用户指令误当标题。

    Args:
        prompt: 用户原始输入
        fallback_code: 兼容旧调用签名，标题生成不再依赖代码兜底
        job_id: 当前渲染任务 ID，用于 llm_call_logs 追踪
    """
    from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input

    prompt = guard_ai_user_input(prompt, scenario="render_title")
    cleaned_prompt = (prompt or "").strip()
    # 去除常见的切片/大纲污染（防止 LLM 把 "片段1：审题与切入" 误当标题）
    if cleaned_prompt:
        cleaned_lines = []
        for ln in cleaned_prompt.splitlines():
            if re.search(r'(片段|环节|步骤|Scene[_\s]\d|第[一二三四五六七八九十\d]+[步段节])', ln, re.IGNORECASE):
                continue
            cleaned_lines.append(ln)
        cleaned_prompt = '\n'.join(cleaned_lines).strip() or cleaned_prompt

    # LLM 智能命名（非阻塞主流程：捕获所有异常）。
    # 标题必须来自独立 title manager，禁止 prompt 首句/前缀抢跑。
    if cleaned_prompt:
        try:
            llm_mgr = _build_title_llm_manager()
            messages = [
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": cleaned_prompt[:500]},
            ]
            response, backend = await llm_mgr.call(
                messages=messages,
                max_tokens=64,
                retry_budget=1,
                trace_job_id=job_id or "unknown",
                trace_call_type="title",
                trace_prompt_version="smart_title",
                trace_prompt_content=f"{_SYSTEM_PROMPT}\n\n{cleaned_prompt[:500]}",
            )
            content = ""
            try:
                content = response.choices[0].message.content or ""
            except Exception:
                content = ""
            title = _sanitize(content)
            if title and not _is_bad_title(title):
                title = guard_ai_output(title, scenario="render_title_output")
                logger.info(f"[TITLE] LLM={backend} 生成标题: {title!r}")
                return title
            logger.warning(
                f"[TITLE] LLM 返回不合格标题 {content!r} → {title!r}，使用默认标题"
            )
        except Exception as e:
            logger.warning(f"[TITLE] LLM 智能命名失败，使用默认标题: {e}")

    return "Shuxuepai动画视频"
