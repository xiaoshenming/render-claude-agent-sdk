"""OpenAI Responses API response and stream adapters."""

from types import SimpleNamespace
from typing import Any

from app.services.llm_usage import extract_usage_info, get_value, merge_usage_info


def messages_to_responses_input(messages: list) -> list[dict[str, Any]]:
    inputs = []
    for message in messages or []:
        if isinstance(message, dict):
            role = str(message.get("role") or "user")
            content = message.get("content", "")
        else:
            role = str(getattr(message, "role", "") or "user")
            content = getattr(message, "content", "")
        inputs.append({"role": role, "content": content})
    return inputs


def extract_responses_output_text(response: Any) -> str:
    output_text = get_value(response, "output_text")
    if isinstance(output_text, str) and output_text.strip():
        return output_text
    texts = []
    for item in get_value(response, "output", []) or []:
        for part in get_value(item, "content", []) or []:
            text = get_value(part, "text")
            if text:
                texts.append(str(text))
    return "".join(texts)


def responses_finish_reason(response: Any) -> str:
    status = get_value(response, "status")
    details = get_value(response, "incomplete_details")
    reason = "stop" if status in (None, "completed") else str(status)
    if details and get_value(details, "reason"):
        reason = str(get_value(details, "reason"))
    return reason


def adapt_responses_response(response: Any, model: str) -> Any:
    return SimpleNamespace(
        choices=[SimpleNamespace(
            message=SimpleNamespace(content=extract_responses_output_text(response)),
            finish_reason=responses_finish_reason(response),
        )],
        usage=get_value(response, "usage"),
        model=get_value(response, "model", model),
        raw_response=response,
    )


def collect_responses_stream_usage(response: Any, stream_usage: dict) -> None:
    if not response:
        return
    merge_usage_info(
        stream_usage,
        extract_usage_info(SimpleNamespace(usage=get_value(response, "usage"))),
    )
    finish_reason = responses_finish_reason(response)
    if finish_reason:
        stream_usage["finish_reason"] = finish_reason


def responses_stream_delta(event: Any) -> str:
    if get_value(event, "type") != "response.output_text.delta":
        return ""
    return str(get_value(event, "delta", "") or "")


def responses_stream_error(event: Any) -> str:
    event_type = str(get_value(event, "type", "") or "")
    if event_type not in {"response.failed", "response.error", "error"}:
        return ""
    error = get_value(event, "error")
    if error:
        return str(error)
    response = get_value(event, "response")
    response_error = get_value(response, "error") if response else None
    return str(response_error or event_type or "Responses API stream failed")
