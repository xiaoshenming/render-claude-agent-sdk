"""LLM 调用追踪器 — 记录每次 LLM API 调用的完整链路信息。

集成方式：在 llm_service._LLMManager.call() / call_stream() 完成后调用。
元数据写入 llm_call_logs 表；脱敏输入/输出 transcript 稳定写入
llm_transcript_artifacts，Elasticsearch/OpenSearch 作为可检索 raw trace。
"""
import hashlib
import json
import logging
import os
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from app.core.config import settings
from sqlalchemy import text

from app.core.structured_logging import get_log_context
from app.database.database import AsyncSessionLocal
from app.services.llm_trace_text_helpers import (
    redact_text, exception_summary, redact_mapping, coerce_messages,
    messages_to_text, messages_for_es_index, trace_content_hash, iso,
    trace_max_text_chars, truncate_text,
)
from app.services.llm_trace_value_helpers import (
    bounded_identifier, hash_prompt, hash_text, slug, is_retryable,
    json_param, json_nullable_param, dict_or_empty,
)
from app.services.llm_trace_security_helpers import (
    redact_transcript_text, quality_error_code, is_retryable_error,
)
from app.services.llm_trace_usage_helpers import (
    artifact_selected_skills as _artifact_selected_skills,
    artifact_skill_block_refs as _artifact_skill_block_refs,
    safe_prompt_segments as _safe_prompt_segments,
)

try:
    import httpx
except Exception:  # pragma: no cover - httpx is present in runtime images
    httpx = None

logger = logging.getLogger(__name__)

BEIJING_TZ = timezone(timedelta(hours=8))
MESSAGE_TRACE_INDEX = "mathpi-llm-message-traces"
MESSAGE_TRACE_MAX_TEXT_CHARS = 200_000

REDACTION_VERSION = "redaction.v1"
TRANSCRIPT_RETENTION_POLICY = "standard"


def _config_value(name: str, default: object = "") -> object:
    value = os.getenv(name)
    if value not in (None, ""):
        return value
    return getattr(settings, name, default)
def _generate_request_id() -> str:
    return str(uuid.uuid4())
def _quality_error_code(error_type: str | None) -> str:
    return quality_error_code(error_type, _slug)
def _is_retryable(error_type: str | None, error_message: str | None) -> bool:
    return is_retryable_error(error_type, error_message, is_retryable)
def _safe_prompt_segments_for_log(usage_info: dict) -> dict:
    return _safe_prompt_segments(
        usage_info,
        dict_or_empty=_dict_or_empty,
        hash_prompt=_hash_prompt,
    )
def _cache_metrics_for_log(usage_info: dict) -> dict:
    cache_metrics = _dict_or_empty(usage_info.get("cache_metrics"))
    cache_read_tokens = _int_or_zero(usage_info.get("cache_read_tokens"))
    cache_creation_tokens = _int_or_zero(usage_info.get("cache_creation_tokens"))
    cache_miss_tokens = _int_or_zero(usage_info.get("cache_miss_tokens"))
    cache_metrics.update(
        {
            "cache_read_tokens": cache_read_tokens,
            "cache_creation_tokens": cache_creation_tokens,
            "cache_miss_tokens": cache_miss_tokens,
            "cache_hit": cache_read_tokens > 0,
        }
    )
    return cache_metrics
def _prompt_firewall_for_log(usage_info: dict) -> dict:
    prompt_firewall = _dict_or_empty(usage_info.get("prompt_firewall"))
    if not prompt_firewall:
        return {}
    safe = dict(prompt_firewall)
    issues = safe.get("issues")
    if isinstance(issues, list):
        safe["issues"] = [str(issue)[:200] for issue in issues[:20]]
        safe["issue_count"] = len(issues)
    return safe
def _metric_value(
    cache_metrics: dict,
    prompt_segments: dict,
    key: str,
) -> str | None:
    value = cache_metrics.get(key) or prompt_segments.get(key)
    if value in (None, ""):
        return None
    return str(value)[:64]
def _render_skill_os_usage_summary(usage_info: dict) -> dict:
    cache_metrics = _dict_or_empty(usage_info.get("cache_metrics"))
    prompt_segments = _dict_or_empty(usage_info.get("prompt_segments"))
    prompt_firewall = _dict_or_empty(usage_info.get("prompt_firewall"))
    summary: dict[str, object] = {}

    for key in (
        "stable_prefix_hash",
        "skill_chain_hash",
        "dynamic_payload_hash",
        "cache_key",
    ):
        value = cache_metrics.get(key) or prompt_segments.get(key)
        if value not in (None, ""):
            summary[key] = value

    schema_version = prompt_segments.get("schema_version")
    if schema_version not in (None, ""):
        summary["prompt_segments_schema_version"] = schema_version

    if "ok" in prompt_firewall:
        summary["prompt_firewall_ok"] = bool(prompt_firewall.get("ok"))
    mode = prompt_firewall.get("mode")
    if mode not in (None, ""):
        summary["prompt_firewall_mode"] = mode
    fallback = prompt_firewall.get("fallback") or prompt_firewall.get(
        "fallback_template"
    )
    if fallback not in (None, ""):
        summary["prompt_firewall_fallback"] = fallback
    issues = prompt_firewall.get("issues")
    if isinstance(issues, list):
        summary["prompt_firewall_issue_count"] = len(issues)

    return summary
def _provider_usage_raw_with_render_skill_os(usage_info: dict) -> dict:
    provider_usage_raw = _dict_or_empty(usage_info.get("provider_usage_raw"))
    render_skill_os = _render_skill_os_usage_summary(usage_info)
    if render_skill_os:
        provider_usage_raw["render_skill_os"] = render_skill_os
    return provider_usage_raw
def _string_or_none(value: object) -> str | None:
    if value is None or value == "":
        return None
    if isinstance(value, dict):
        value = value.get("type") or json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
        )
    return str(value)[:50]
def _int_or_zero(value: object) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0
def _trace_max_text_chars() -> int:
    return trace_max_text_chars(_config_value, MESSAGE_TRACE_MAX_TEXT_CHARS)
def _truncate_text(value: object, *, limit: int | None = None) -> tuple[str, bool]:
    max_chars = _trace_max_text_chars() if limit is None else max(1, int(limit))
    return truncate_text(value, max_chars)

