import aio_pika
import logging
import asyncio
from app.core.config import normalize_max_concurrent_tasks, settings

logger = logging.getLogger(__name__)


class RabbitMQService:
    """RabbitMQ 服务（仅用于消费）"""

    def __init__(self):
        self.connection = None
        self.channel = None
        self._lock = asyncio.Lock()
        self._prefetch_count: int | None = None

    def _normalize_prefetch_count(self, prefetch_count: int | None = None) -> int:
        raw_prefetch_count = (
            settings.MAX_CONCURRENT_TASKS
            if prefetch_count is None
            else prefetch_count
        )
        normalized_prefetch_count = normalize_max_concurrent_tasks(
            raw_prefetch_count)
        if normalized_prefetch_count != raw_prefetch_count:
            logger.warning(
                "MAX_CONCURRENT_TASKS=%s 非法，RabbitMQ prefetch 回退为 %s",
                raw_prefetch_count,
                normalized_prefetch_count,
            )
        return normalized_prefetch_count

    async def connect(self, *, prefetch_count: int | None = None):
        """连接 RabbitMQ"""
        async with self._lock:
            normalized_prefetch_count = self._normalize_prefetch_count(
                prefetch_count)
            if self.connection and not self.connection.is_closed:
                if (
                    self.channel
                    and not getattr(self.channel, "is_closed", False)
                    and self._prefetch_count != normalized_prefetch_count
                ):
                    await self.channel.set_qos(
                        prefetch_count=normalized_prefetch_count)
                    self._prefetch_count = normalized_prefetch_count
                    logger.info(
                        "RabbitMQ qos updated: prefetch_count=%s",
                        normalized_prefetch_count,
                    )
                return

            try:
                self.connection = await aio_pika.connect_robust(
                    settings.RABBITMQ_URL,
                    timeout=10
                )
                self.channel = await self.connection.channel(
                    publisher_confirms=True,
                    on_return_raises=True,
                )
                # 设置预取计数，必须和 VideoWorker 实际信号量一致。
                # runtime_config 可能在 worker 初始化后刷新 settings，不能让
                # RabbitMQ 预取超过当前进程真正可处理的任务数。
                await self.channel.set_qos(prefetch_count=normalized_prefetch_count)
                self._prefetch_count = normalized_prefetch_count
                logger.info(
                    "RabbitMQ connected for consuming: prefetch_count=%s",
                    normalized_prefetch_count,
                )
            except Exception as e:
                logger.error(f"Failed to connect to RabbitMQ: {e}")
                raise

    async def close(self):
        """关闭连接"""
        async with self._lock:
            if self.connection:
                await self.connection.close()
                self.connection = None
                self.channel = None
                self._prefetch_count = None
                logger.info("RabbitMQ connection closed")


# 全局实例
rabbitmq_service = RabbitMQService()
