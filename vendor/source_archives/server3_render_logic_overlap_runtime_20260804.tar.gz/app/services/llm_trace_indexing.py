"""LLM trace indexing helper."""
from __future__ import annotations
from typing import Any
async def index_llm_message_trace(document: dict) -> dict[str, str | None]:
    """Best-effort Elasticsearch/OpenSearch indexing for message transcripts."""
    import os, uuid
    from app.services.llm_call_tracer import MESSAGE_TRACE_INDEX, _config_value, _exception_summary, httpx, logger
    url = str(_config_value("LLM_MESSAGE_TRACE_ES_URL", "") or "").strip().rstrip("/")
    if not url:
        return {"status": "skipped", "document_id": None, "error_message": None}
    if httpx is None:
        return {
            "status": "failed",
            "document_id": None,
            "error_message": "httpx unavailable",
        }
    index_name = (
        _config_value("LLM_MESSAGE_TRACE_ES_INDEX", "")
        or os.getenv("ELASTICSEARCH_LLM_MESSAGE_TRACE_INDEX")
        or MESSAGE_TRACE_INDEX
    )
    index_name = str(index_name).strip()
    document_id = str(document.get("id") or uuid.uuid4())
    timeout = float(_config_value("LLM_MESSAGE_TRACE_ES_TIMEOUT", 2.0) or 2.0)
    headers = {"Content-Type": "application/json"}
    api_key = str(_config_value("LLM_MESSAGE_TRACE_ES_API_KEY", "") or "").strip()
    if api_key:
        headers["Authorization"] = f"ApiKey {api_key}"
    auth = None
    username = str(_config_value("LLM_MESSAGE_TRACE_ES_USERNAME", "") or "").strip()
    password = str(_config_value("LLM_MESSAGE_TRACE_ES_PASSWORD", "") or "").strip()
    if username or password:
        auth = (username, password)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.put(
                f"{url}/{index_name}/_doc/{document_id}",
                headers=headers,
                auth=auth,
                json=document,
            )
            response.raise_for_status()
        return {
            "status": "indexed",
            "document_id": document_id,
            "error_message": None,
        }
    except Exception as exc:
        error_message = _exception_summary(exc)
        logger.warning("[LLM_TRACE] ES index failed: %s", error_message)
        return {
            "status": "failed",
            "document_id": document_id,
            "error_message": error_message,
        }


    from app.services.llm_call_tracer import (
        _trace_content_hash, _messages_for_es_index, _trace_max_text_chars,
        _truncate_text, index_llm_message_trace,
    )
async def _index_message_trace(
    self,
    *,
    call_log_id: str,
    backend_name: str,
    model: str,
    usage_info: dict,
    output_text: Optional[str],
    success: bool,
    error_type: Optional[str],
    error_message: Optional[str],
    latency_ms: int,
    started_at: datetime,
    ended_at: datetime,
) -> None:
    response_text = usage_info.get("response_text")
    if response_text in (None, "") and output_text not in (None, ""):
        response_text = output_text
    input_messages = list(self._request_messages or [])
    if not input_messages and response_text in (None, ""):
        return
    output_text_raw = _redact_text(response_text) if response_text is not None else ""
    input_text_raw = _messages_to_text(input_messages)
    input_text, input_truncated = _truncate_text(input_text_raw)
    output_text, output_truncated = _truncate_text(output_text_raw)
    output_messages = (
        [{"role": "assistant", "content": output_text}]
        if output_text
        else []
    )
    search_text = "\n\n".join(part for part in (input_text, output_text) if part)
    content_sha256 = _trace_content_hash(input_text, output_text)
    ended_at_iso = _iso(ended_at)
    document = {
        "id": call_log_id,
        "llm_call_log_id": call_log_id,
        "job_id": self.job_id,
        "request_id": self.request_id,
        "trace_id": self.trace_id,
        "attempt_id": self.attempt_id,
        "call_type": self.call_type,
        "backend_name": backend_name,
        "model": model,
        "prompt_version": self.prompt_version,
        "prompt_hash": self._prompt_hash,
        "input_messages": _messages_for_es_index(input_messages),
        "input_text": input_text,
        "output_messages": output_messages,
        "output_text": output_text,
        "search_text": search_text,
        "raw_response_metadata": {
            "success": success,
            "provider_success": bool(
                usage_info.get("provider_success", success)
            ),
            "semantic_acceptance_success": bool(
                usage_info.get("semantic_acceptance_success", success)
            ),
            "finish_reason": _string_or_none(usage_info.get("finish_reason")),
            "quality_result": _string_or_none(usage_info.get("quality_result")),
            "response_format": _string_or_none(
                usage_info.get("response_format") or self.response_format
            ),
            "input_tokens": usage_info.get("input_tokens", 0),
            "output_tokens": usage_info.get("output_tokens", 0),
            "cache_read_tokens": usage_info.get("cache_read_tokens", 0),
            "cache_creation_tokens": usage_info.get("cache_creation_tokens", 0),
            "cache_miss_tokens": usage_info.get("cache_miss_tokens", 0),
            "retry_count": _int_or_zero(usage_info.get("retry_count", self.retry_count)),
            "latency_ms": latency_ms,
            "error_type": error_type,
            "error_message": _redact_text(error_message) if error_message else None,
        },
        "content_sha256": content_sha256,
        "redaction_status": "redacted",
        "truncated": input_truncated or output_truncated,
        "storage_backend": "elasticsearch",
        "started_at": _iso(started_at),
        "ended_at": ended_at_iso,
        "created_at": ended_at_iso,
        "@timestamp": ended_at_iso,
    }
    await index_llm_message_trace(document)
