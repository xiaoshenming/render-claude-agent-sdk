"""Job status reads and terminal transition writes."""
import logging
from datetime import datetime
from typing import Optional

logger=logging.getLogger(__name__)

class JobStatusWriteError(RuntimeError):
    """Raised when a job status write fails before the transition result is known."""


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


# ─────────────────────────── 查询 ───────────────────────────

async def is_job_cancelled(job_id: str) -> bool:
    """检查任务是否已被终止（状态不再是 PENDING/PROCESSING）。"""
    try:
        status = await get_job_status(job_id)
        return bool(status and status not in ("PENDING", "PROCESSING"))
    except Exception as e:
        logger.warning(f"[CANCEL-CHECK] 检查任务状态失败: {e}")
        return False


async def get_job_status(job_id: str) -> Optional[str]:
    """读取任务当前状态；读取异常时抛出以触发消息重投。"""
    from app.services import internal_api_client

    api_status = await internal_api_client.get_video_job_status(job_id)
    if api_status is not None:
        return api_status
    raise JobStatusWriteError(
        f"internal API get_video_job_status failed: job={job_id}"
    )


# ─────────────────────────── 状态流转 ───────────────────────────

async def update_job_status(
    job_id: str,
    status: str,
    error_message: str = None,
    refund_points: int = 0,
    error_type: str = None,
    error_stage: str = None,
    retry_count: int = None,
    llm_fix_count: int = 0,
    render_fix_count: int = 0,
    total_tokens: int = 0,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    failed_code_url: Optional[str] = None,
    pipeline_mode: str | None = None,
    slice_count: int | None = None,
) -> bool:
    """更新任务状态，FAILED 时带终态保护。返回 True 表示状态更新真的发生了。"""
    logger.debug(f"update_job_status: job={job_id} status={status}")
    if status == "PROCESSING":
        from app.services import internal_api_client

        api_result = await internal_api_client.mark_video_job_processing(job_id)
        if api_result is True:
            logger.info(f"Job {job_id} -> PROCESSING via internal API")
            return True
        if api_result is False:
            logger.warning(
                f"Job {job_id} not in PENDING, skip PROCESSING via internal API")
            return False
        raise JobStatusWriteError(
            f"internal API mark_video_job_processing failed: job={job_id}"
        )
    if status == "FAILED":
        from app.services import internal_api_client

        payload = {
            "error_message": error_message or "",
            "refund_points": refund_points,
            "error_type": error_type,
            "error_stage": error_stage,
            "retry_count": retry_count or 0,
            "failed_code_url": failed_code_url,
            "llm_fix_count": llm_fix_count,
            "render_fix_count": render_fix_count,
            "total_tokens": total_tokens,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_read_tokens": cache_read_tokens,
            "cache_creation_tokens": cache_creation_tokens,
            "pipeline_mode": pipeline_mode,
            "slice_count": slice_count or 0,
        }
        api_result = await internal_api_client.complete_video_job_failure(
            job_id,
            payload,
        )
        if api_result is True or api_result == "changed":
            logger.info(f"Job {job_id} -> FAILED via internal API")
            return True
        if api_result is False or api_result == "already_terminal":
            logger.warning(
                f"Job {job_id} not in PENDING/PROCESSING, skip FAILED via internal API")
            return False
        logger.error(
            f"internal API complete_video_job_failure failed: job={job_id}"
        )
        return False
    logger.error(
        "Render job_repository cannot update unsupported status %s directly: job=%s",
        status,
        job_id,
    )
    return False


# ─────────────────────────── SUCCESS 写入 ───────────────────────────
