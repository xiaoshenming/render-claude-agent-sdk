"""Shared retrying HTTP transport for Render internal API calls."""

import logging
from typing import Any, Awaitable, Callable

import httpx

logger = logging.getLogger(__name__)


async def request_with_retry(
    *,
    method: str,
    url: str,
    headers: dict[str, str],
    timeout: int,
    attempts: int,
    operation: str,
    job_id: str,
    payload: dict[str, Any] | None,
    client_type: Any,
    sleep: Callable[[float], Awaitable[Any]],
) -> Any | None:
    for attempt in range(1, attempts + 1):
        try:
            async with client_type(timeout=timeout) as client:
                call = getattr(client, method)
                kwargs = {"headers": headers}
                if payload is not None:
                    kwargs["json"] = payload
                response = await call(url, **kwargs)
            if 200 <= response.status_code < 300:
                return response
            logger.warning(
                "[INTERNAL-API] %s status_failed: job=%s status=%s attempt=%s/%s",
                operation,
                job_id,
                response.status_code,
                attempt,
                attempts,
            )
            if response.status_code != 429 and not 500 <= response.status_code < 600:
                return None
        except httpx.HTTPError as exc:
            logger.warning(
                "[INTERNAL-API] %s request_failed: job=%s error_type=%s attempt=%s/%s",
                operation,
                job_id,
                type(exc).__name__,
                attempt,
                attempts,
            )
        except Exception as exc:
            logger.warning(
                "[INTERNAL-API] %s unexpected_failed: job=%s error_type=%s attempt=%s/%s",
                operation,
                job_id,
                type(exc).__name__,
                attempt,
                attempts,
            )
        if attempt < attempts:
            await sleep(min(0.2 * attempt, 1.0))
    return None
