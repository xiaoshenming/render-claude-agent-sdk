"""OpenAI Responses API client calls with reasoning fallback."""

import logging
from typing import Any, Callable

from app.services.llm_responses_adapters import adapt_responses_response

logger = logging.getLogger(__name__)


class ResponsesClientAdapter:
    def __init__(
        self,
        *,
        client_type: Any,
        stream_timeout: Callable[[int], int],
        should_retry_high: Callable[[Exception, dict[str, Any]], bool],
        with_high_reasoning: Callable[[dict[str, Any]], dict[str, Any]],
        default_reasoning_effort: str,
    ) -> None:
        self.client_type = client_type
        self.stream_timeout = stream_timeout
        self.should_retry_high = should_retry_high
        self.with_high_reasoning = with_high_reasoning
        self.default_reasoning_effort = default_reasoning_effort

    def _client(self, backend: Any, key: str, *, streaming: bool) -> Any:
        if self.client_type is None:
            raise RuntimeError("openai SDK is not available for Responses API backend")
        timeout = backend.effective_timeout
        if streaming:
            timeout = self.stream_timeout(timeout)
        return self.client_type(
            api_key=key,
            base_url=backend.resolved_api_base(),
            timeout=timeout,
            max_retries=0,
        )

    @staticmethod
    def _request_kwargs(
        backend: Any,
        messages: list,
        max_output_tokens: int,
        trace_call_type: str | None,
        prompt_cache_kwargs: dict[str, str] | None,
    ) -> dict[str, Any]:
        return backend.responses_create_kwargs(
            messages=messages,
            max_output_tokens=max_output_tokens,
            call_type=trace_call_type,
            **(prompt_cache_kwargs or {}),
        )

    async def call(
        self,
        *,
        backend: Any,
        key: str,
        messages: list,
        max_output_tokens: int,
        trace_call_type: str | None = None,
        prompt_cache_kwargs: dict[str, str] | None = None,
    ) -> Any:
        client = self._client(backend, key, streaming=False)
        kwargs = self._request_kwargs(
            backend, messages, max_output_tokens, trace_call_type, prompt_cache_kwargs
        )
        try:
            response = await client.responses.create(**kwargs)
        except Exception as exc:
            if not self.should_retry_high(exc, kwargs):
                raise
            logger.warning(
                "Responses API rejected reasoning.effort=%s for backend=%s; retrying with high",
                self.default_reasoning_effort,
                backend.name,
            )
            response = await client.responses.create(**self.with_high_reasoning(kwargs))
        return adapt_responses_response(response, backend.model_id)

    async def call_stream(self, **kwargs: Any) -> Any:
        backend = kwargs["backend"]
        client = self._client(backend, kwargs["key"], streaming=True)
        request_kwargs = self._request_kwargs(
            backend,
            kwargs["messages"],
            kwargs["max_output_tokens"],
            kwargs.get("trace_call_type"),
            kwargs.get("prompt_cache_kwargs"),
        )
        try:
            return await client.responses.create(**request_kwargs, stream=True)
        except Exception as exc:
            if not self.should_retry_high(exc, request_kwargs):
                raise
            logger.warning(
                "Responses API stream rejected reasoning.effort=%s for backend=%s; retrying with high",
                self.default_reasoning_effort,
                backend.name,
            )
            return await client.responses.create(
                **self.with_high_reasoning(request_kwargs), stream=True
            )
