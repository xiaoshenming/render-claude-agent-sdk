"""Build and resolve canonical video timeline manifests."""

from __future__ import annotations

import copy
import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from typing import Any

from app.services import ffmpeg_service


SCHEMA_VERSION = 1
TIMEBASE = "seconds"
PRECISION_MS = 10
FPS = 30
MIN_DRIFT_THRESHOLD_SEC = 0.25
_EPSILON = 1e-6

__all__ = [
    "_copy_items", "_first_float", "_get", "_nonnegative_float",
    "_normalize_bookmarks", "_normalize_windows", "_normalize_words",
    "_parent_manifest_id", "_parent_slices_by_index", "_positive_float",
    "_round_seconds", "_slice_index", "_timing_source_start_sec",
    "compute_manifest_hash",
]


def _round_seconds(value: float) -> float:
    return round(float(value), 3)


def _finite_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(result):
        return None
    return result


def _nonnegative_float(value: Any) -> float | None:
    result = _finite_float(value)
    if result is None or result < 0:
        return None
    return result


def _positive_float(value: Any) -> float | None:
    result = _finite_float(value)
    if result is None or result <= 0:
        return None
    return result


def _get(source: Any, *keys: str, default: Any = None) -> Any:
    for key in keys:
        if isinstance(source, Mapping) and key in source:
            return source[key]
        if not isinstance(source, Mapping) and hasattr(source, key):
            return getattr(source, key)
    return default


def _first_float(source: Any, *keys: str) -> float | None:
    for key in keys:
        value = _nonnegative_float(_get(source, key))
        if value is not None:
            return value
    return None


def _slice_index(source: Any, fallback: int) -> int:
    value = _get(source, "slice_index", "index", default=fallback)
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _copy_items(primary: Any, fallback: Any, key: str) -> list[dict[str, Any]]:
    value = _get(primary, key)
    if value is None:
        value = _get(fallback, key)
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [copy.deepcopy(item) for item in value if isinstance(item, Mapping)]


def _timing_source_start_sec(
    primary: Any,
    fallback: Any,
    key: str,
    *,
    global_start_sec: float,
) -> float:
    if _get(primary, key) is None and fallback is not None:
        fallback_start = _nonnegative_float(_get(fallback, "global_start_sec"))
        if fallback_start is not None:
            return fallback_start
    return global_start_sec


def _parent_manifest_id(parent_manifest: Mapping[str, Any] | None) -> str | None:
    if not parent_manifest:
        return None
    return _get(parent_manifest, "manifest_id", "id")


def _parent_slices_by_index(
    parent_manifest: Mapping[str, Any] | None,
) -> dict[int, Mapping[str, Any]]:
    if not parent_manifest:
        return {}
    slices = _get(parent_manifest, "slices", default=[])
    if not isinstance(slices, Sequence) or isinstance(slices, (str, bytes)):
        return {}
    result: dict[int, Mapping[str, Any]] = {}
    for fallback, item in enumerate(slices):
        if isinstance(item, Mapping):
            result[_slice_index(item, fallback)] = item
    return result


async def _probe_duration_sec(path: str | None) -> float | None:
    """Return ffprobe media duration, or None when the path cannot be probed."""
    if not path:
        return None
    try:
        probe = await ffmpeg_service._probe_media(path)
        return _positive_float(ffmpeg_service._media_duration(probe))
    except Exception:
        return None


def _normalize_bookmarks(
    bookmarks: list[dict[str, Any]],
    *,
    global_start_sec: float,
    source_global_start_sec: float | None = None,
) -> list[dict[str, Any]]:
    source_start = global_start_sec if source_global_start_sec is None else source_global_start_sec
    normalized: list[dict[str, Any]] = []
    for bookmark in bookmarks:
        item = copy.deepcopy(bookmark)
        local_time = _first_float(item, "local_time_sec", "time_sec")
        if local_time is None:
            global_time = _first_float(item, "global_time_sec", "timestamp_sec")
            if global_time is not None:
                local_time = max(0.0, global_time - source_start)
        if local_time is not None:
            item["local_time_sec"] = _round_seconds(local_time)
            item["global_time_sec"] = _round_seconds(global_start_sec + local_time)
        normalized.append(item)
    return normalized


def _normalize_words(
    words: list[dict[str, Any]],
    *,
    global_start_sec: float,
    source_global_start_sec: float | None = None,
) -> list[dict[str, Any]]:
    source_start = global_start_sec if source_global_start_sec is None else source_global_start_sec
    normalized: list[dict[str, Any]] = []
    for word in words:
        item = copy.deepcopy(word)
        local_start = _first_float(item, "local_start_sec", "start_sec")
        local_end = _first_float(item, "local_end_sec", "end_sec")
        if local_start is None:
            global_start = _first_float(item, "global_start_sec")
            if global_start is not None:
                local_start = max(0.0, global_start - source_start)
        if local_end is None:
            global_end = _first_float(item, "global_end_sec")
            if global_end is not None:
                local_end = max(0.0, global_end - source_start)
        if local_start is not None:
            item["local_start_sec"] = _round_seconds(local_start)
            item["global_start_sec"] = _round_seconds(global_start_sec + local_start)
        if local_end is not None:
            item["local_end_sec"] = _round_seconds(local_end)
            item["global_end_sec"] = _round_seconds(global_start_sec + local_end)
        normalized.append(item)
    return normalized


def _normalize_windows(
    windows: list[dict[str, Any]],
    *,
    global_start_sec: float,
    source_global_start_sec: float | None = None,
) -> list[dict[str, Any]]:
    source_start = global_start_sec if source_global_start_sec is None else source_global_start_sec
    normalized: list[dict[str, Any]] = []
    for window in windows:
        item = copy.deepcopy(window)
        local_start = _first_float(item, "local_start_sec", "start_sec")
        local_end = _first_float(item, "local_end_sec", "end_sec")

        if local_start is None:
            global_start = _first_float(item, "global_start_sec")
            if global_start is not None:
                local_start = max(0.0, global_start - source_start)
        if local_end is None:
            global_end = _first_float(item, "global_end_sec")
            if global_end is not None:
                local_end = max(0.0, global_end - source_start)

        if local_start is not None:
            item["local_start_sec"] = _round_seconds(local_start)
            item["global_start_sec"] = _round_seconds(global_start_sec + local_start)
        if local_end is not None:
            item["local_end_sec"] = _round_seconds(local_end)
            item["global_end_sec"] = _round_seconds(global_start_sec + local_end)
        normalized.append(item)
    return normalized


def compute_manifest_hash(manifest: Mapping[str, Any]) -> str:
    """Hash the canonical manifest JSON without the mutable hash field."""
    canonical = copy.deepcopy(dict(manifest))
    canonical.pop("manifest_hash", None)
    encoded = json.dumps(
        canonical,
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()
