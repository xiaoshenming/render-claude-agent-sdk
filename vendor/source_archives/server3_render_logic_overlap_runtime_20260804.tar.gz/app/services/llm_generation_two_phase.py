"""Two-phase outline and single-scene generation helpers."""
import json
import logging
import re
from typing import Optional, Tuple
import litellm
from app.services.ai_guardrails import guard_ai_output, guard_ai_payload, guard_ai_user_input

logger=logging.getLogger(__name__)


def _facade():
    from app.services import llm_generation

    return llm_generation


def _facade_mgr():
    return _facade()._mgr()


def extract_usage_details(response):
    return _facade().extract_usage_details(response)

async def generate_outline(
    user_prompt: str,
    job_id: Optional[str] = None,
) -> Tuple[dict, float, int]:
    """Phase 1: generate a storyboard outline JSON from user prompt.
    Returns (outline_dict, cost_usd, total_tokens).
    """
    user_prompt = guard_ai_user_input(user_prompt, scenario="render_outline")
    from app.prompts.outline_prompt import OUTLINE_PROMPT

    prompt = OUTLINE_PROMPT.replace("__USER_PROMPT__", user_prompt)
    messages = [{"role": "user", "content": prompt}]

    response, _ = await _facade_mgr().call(
        messages=messages,
        max_tokens=4096,
        retry_budget=2,
        trace_job_id=job_id or "unknown",
        trace_call_type="generate_outline",
        trace_prompt_version="two_phase",
        trace_prompt_content=prompt,
    )

    content = response.choices[0].message.content or ""
    try:
        cost = litellm.completion_cost(completion_response=response)
    except Exception:
        cost = 0.0
    usage_info = extract_usage_details(response)
    tokens = usage_info["total_tokens"]
    logger.info(
        f"[TWO-PHASE] Outline tokens={tokens} "
        f"(in={usage_info['input_tokens']}, out={usage_info['output_tokens']}, "
        f"cache_read={usage_info['cache_read_tokens']}, "
        f"cache_create={usage_info['cache_creation_tokens']})")
    # Extract JSON from response
    json_match = re.search(r'\{[\s\S]*\}', content)
    if not json_match:
        raise ValueError("LLM 未返回有效 JSON")
    outline = json.loads(json_match.group())
    guard_ai_payload(outline, scenario="render_outline_output")
    return outline, cost, tokens


def _strip_duplicate_definitions(scene_code: str, expected_class: str) -> str:
    """Remove duplicate GlobalConfig / BaseConfigScene / imports that LLM
    sometimes outputs despite being told not to.  Keep only the target
    Scene class definition."""
    lines = scene_code.split("\n")
    # Find the line where the expected Scene class starts
    target_start = None
    for i, line in enumerate(lines):
        if re.match(rf"^class\s+{re.escape(expected_class)}\s*\(", line):
            target_start = i
            break
    if target_start is None:
        # Fallback: find any class Scene_XX
        for i, line in enumerate(lines):
            if re.match(r"^class\s+Scene_\d+", line):
                target_start = i
                break
    if target_start is not None and target_start > 0:
        # Everything before the target class is likely duplicate defs
        stripped = "\n".join(lines[target_start:])
        return stripped.strip()
    return scene_code


async def generate_single_scene(
    outline: dict,
    scene_info: dict,
    base_class_code: str,
    color_scheme: int,
    scene_prompt_override: str = "",
    job_id: Optional[str] = None,
    voice_type: str = "system",
    cosyvoice_id: str = "",
) -> Tuple[str, str, float, int]:
    """Phase 2: generate a single Scene class from outline.

    Returns (scene_name, scene_code, cost_usd, total_tokens).
    """
    guard_ai_payload(outline, scenario="render_scene_outline")
    guard_ai_payload(scene_info, scenario="render_scene_info")

    if scene_prompt_override:
        scene_prompt_text = scene_prompt_override
    else:
        from app.prompts.scene_prompt import SCENE_PROMPT
        scene_prompt_text = SCENE_PROMPT

    # 注入 TTS 配音文本写作规范（按 voice_type 分发，与 generate_manim_code 一致）
    if "__TTS_VOICE_GUIDE__" in scene_prompt_text:
        from app.prompts.tts_voice_guide import get_tts_voice_guide
        scene_prompt_text = scene_prompt_text.replace(
            "__TTS_VOICE_GUIDE__",
            get_tts_voice_guide(voice_type=voice_type, cosyvoice_id=cosyvoice_id),
        )

    prompt = (
        scene_prompt_text
        .replace("__OUTLINE_JSON__",
                 json.dumps(outline, ensure_ascii=False, indent=2))
        .replace("__SCENE_NAME__", scene_info["name"])
        .replace("__SCENE_PURPOSE__", scene_info["purpose"])
        .replace("__SCENE_OBJECTS__",
                 ", ".join(scene_info.get("key_objects", [])))
        .replace("__SCENE_MATH__",
                 scene_info.get("math_content", ""))
        .replace("__REHYDRATION_FROM__",
                 scene_info.get("rehydration_from") or "无")
        .replace("__BASE_CLASS__", base_class_code)
    )
    messages = [{"role": "user", "content": prompt}]

    response, _ = await _facade_mgr().call(
        messages=messages,
        max_tokens=8192,
        retry_budget=2,
        trace_job_id=job_id or "unknown",
        trace_call_type="generate_scene",
        trace_prompt_version="two_phase",
        trace_prompt_content=prompt,
    )

    content = response.choices[0].message.content or ""
    try:
        cost = litellm.completion_cost(completion_response=response)
    except Exception:
        cost = 0.0
    usage_info = extract_usage_details(response)
    tokens = usage_info["total_tokens"]
    # Extract python code block
    code_match = re.search(
        r'```python\s*(.*?)```', content, re.DOTALL)
    scene_code = (code_match.group(1).strip()
                  if code_match else content.strip())
    # Strip duplicate GlobalConfig/BaseConfigScene/imports from LLM output
    scene_code = _strip_duplicate_definitions(
        scene_code, scene_info["name"])
    guard_ai_output(scene_code, scenario="render_scene_code_output")
    return scene_info["name"], scene_code, cost, tokens
