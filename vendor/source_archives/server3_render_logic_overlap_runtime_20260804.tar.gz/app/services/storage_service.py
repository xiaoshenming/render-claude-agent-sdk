import asyncio
import logging
import mimetypes
from urllib.parse import urlparse

from qcloud_cos import CosConfig, CosS3Client

from app.core.config import settings

logger = logging.getLogger(__name__)


class StorageService:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(StorageService, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, "_client_signature"):
            self._client_signature = None
            self.client = None
            self.region = ""
            self.bucket = ""

    def _current_signature(self) -> tuple[str, str, str, str]:
        return (
            settings.TENCENT_COS_SECRET_ID,
            settings.TENCENT_COS_SECRET_KEY,
            settings.TENCENT_COS_REGION,
            settings.TENCENT_COS_BUCKET,
        )

    def reload(self) -> None:
        self._client_signature = None
        self.client = None

    def _public_url(self, file_path: str) -> str:
        normalized_path = file_path.lstrip("/")
        public_base_url = settings.TENCENT_COS_PUBLIC_BASE_URL.strip().rstrip("/")
        if public_base_url:
            return f"{public_base_url}/{normalized_path}"
        return f"https://{self.bucket}.cos.{self.region}.myqcloud.com/{normalized_path}"

    def _ensure_client(self) -> CosS3Client:
        signature = self._current_signature()
        if not all(signature):
            raise RuntimeError("COS 配置未加载，请先在配置中心填写腾讯云 COS 凭据")
        if self.client is not None and self._client_signature == signature:
            return self.client
        secret_id, secret_key, self.region, self.bucket = signature
        config = CosConfig(
            Region=self.region,
            SecretId=secret_id,
            SecretKey=secret_key,
            Scheme='https',
            Timeout=max(1, int(getattr(settings, "TENCENT_COS_TIMEOUT", 180))),
        )
        self.client = CosS3Client(config)
        self._client_signature = signature
        logger.info("腾讯云对象存储服务已初始化。")
        return self.client

    async def upload_file(
        self,
        file_path: str,
        file_data: bytes,
        *,
        content_type: str | None = None,
        cache_control: str | None = None,
    ) -> str:
        """
        使用 put_object 将内存中的文件数据上传到腾讯云COS。

        Args:
            file_path: 文件在存储桶中的完整路径 (Key)，例如 "avatars/user1/abc.png"
            file_data: 文件的二进制数据 (bytes)

        Returns:
            上传成功后文件的公开访问 URL
        """
        try:
            # SDK 的 put_object 是同步阻塞方法，必须使用 asyncio.to_thread 运行
            client = self._ensure_client()
            logger.debug("正在上传文件到 COS: %s/%s", self.bucket, file_path)
            put_kwargs = {
                "Bucket": self.bucket,
                "Body": file_data,
                "Key": file_path,
                "EnableMD5": False,
            }
            resolved_content_type = content_type or mimetypes.guess_type(file_path)[0]
            if resolved_content_type:
                put_kwargs["ContentType"] = resolved_content_type
            if cache_control:
                put_kwargs["CacheControl"] = cache_control

            await asyncio.to_thread(client.put_object, **put_kwargs)

            url = self._public_url(file_path)
            logger.debug("文件上传成功: %s", url)
            return url
        except Exception as e:
            logger.error("腾讯云COS上传失败: %s", e)
            raise Exception("文件上传到云存储失败。")

    async def delete_file(self, file_url: str):
        """
        从腾讯云COS中删除一个文件。

        Args:
            file_url: 要删除文件的完整公开访问 URL
        """
        if not file_url:
            return

        try:
            # 从 URL 中解析出 Key (文件路径)
            parsed_url = urlparse(file_url)
            key = parsed_url.path.lstrip('/')

            if not key:
                logger.warning("无法从 URL 中解析出有效的文件路径进行删除: %s", file_url)
                return

            # SDK 的 delete_object 也是同步的，同样需要 to_thread
            client = self._ensure_client()
            logger.debug("正在从 COS 删除文件: %s/%s", self.bucket, key)
            await asyncio.to_thread(
                client.delete_object,
                Bucket=self.bucket,
                Key=key
            )
            logger.debug("文件 %s 已从 COS 删除。", key)
        except Exception as e:
            # 即使删除失败，也只打印日志，不应中断用户的操作流程
            logger.error("腾讯云COS文件删除失败: %s", e)


# 创建一个全局可用的服务实例
storage_service = StorageService()
