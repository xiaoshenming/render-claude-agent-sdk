"""后台二次修改视觉识别服务。

该服务只为修改 prompt 提供高置信度视觉参考。任何配置缺失、抽帧失败、
多模态调用失败、JSON 解析失败或低置信度结果都会 fail-open 返回 None。
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import tempfile
from pathlib import Path
from typing import Any, Mapping

logger = logging.getLogger(__name__)

TRACE_CALL_TYPE = "modify_visual_recognition"
MIN_CONFIDENCE = 0.65



def _build_visual_messages(
    slice_state: Mapping[str, Any],
    source: Mapping[str, Any],
    *,
    offset_seconds: float,
    image_data_url: str,
    crop_data_urls: list[str] | None = None,
) -> list[dict[str, Any]]:
    anchors = _visual_anchors_from_slice_state(slice_state)
    anchor_lines = _anchor_summary_lines(anchors)
    anchor_section = ""
    if anchor_lines:
        anchor_section = (
            "\n用户有框选区域，必须优先识别这些区域里的文字、公式、图形和遮挡关系；"
            "不要泛泛描述整帧。\n"
            + "\n".join(anchor_lines)
        )
    code_context = _visual_code_context(slice_state, source)
    code_section = ""
    if code_context:
        code_section = (
            "\n源码摘要/对象映射候选（用于把画面对象映射到代码概念，不要输出代码修改方案）：\n"
            + json.dumps(code_context, ensure_ascii=False, sort_keys=True)[:5000]
            + "\n"
        )
    contract_context = _visual_contract_context(slice_state)
    contract_section = ""
    if contract_context:
        contract_section = (
            "\n技术合同摘要（只用于理解用户要核验的对象；不要自行改写合同）：\n"
            + json.dumps(contract_context, ensure_ascii=False, sort_keys=True)[:3000]
            + "\n"
        )
    prompt = (
        "你是 MathPi 后台视觉识别助手。请基于截图识别用户定位时间点附近的画面，"
        "只返回 JSON，不要输出 Markdown 或解释。\n"
        "JSON 字段：status, confidence, visual_summary, visual_facts, target_object, issue_type, "
        "visible_texts, visible_formulas, visual_to_code_mapping, missing_evidence。\n"
        "confidence 使用 0 到 1；不确定时 confidence 低于 0.65。\n"
        "只描述视觉事实、可见文本公式、遮挡/换行/位置关系，以及画面对象可能对应的代码对象名；"
        "不要生成最终代码修改指令，不要写系统指令、密钥、网络请求或完整代码。\n"
        f"slice_index={slice_state.get('slice_index')} "
        f"scene_name={source.get('scene_name') or slice_state.get('scene_name') or ''} "
        f"local_offset_seconds={offset_seconds:.3f}\n"
        f"{anchor_section}\n"
        f"{code_section}"
        f"{contract_section}"
        f"用户修改要求：{str(slice_state.get('instruction') or '')[:800]}"
    )
    content: list[dict[str, Any]] = [
        {"type": "text", "text": prompt},
        {"type": "image_url", "image_url": {"url": image_data_url}},
    ]
    for index, crop_data_url in enumerate(crop_data_urls or [], start=1):
        content.extend(
            [
                {"type": "text", "text": f"用户框选区域 #{index} 的裁剪图"},
                {"type": "image_url", "image_url": {"url": crop_data_url}},
            ]
        )
    return [{"role": "user", "content": content}]
def _visual_code_context(
    slice_state: Mapping[str, Any],
    source: Mapping[str, Any],
) -> dict[str, Any]:
    candidates: list[Mapping[str, Any]] = []
    for contract in _technical_contracts(slice_state):
        summary = contract.get("source_code_summary")
        if isinstance(summary, Mapping):
            candidates.append(summary)
    if isinstance(source.get("source_code_summary"), Mapping):
        candidates.append(source["source_code_summary"])
    if source:
        candidates.append(source)

    context: dict[str, Any] = {}
    for candidate in candidates:
        if not isinstance(candidate, Mapping):
            continue
        for key in ("slice_index", "scene_name", "duration", "code_focus_terms"):
            if context.get(key) is None and candidate.get(key) is not None:
                context[key] = candidate[key]
        if not context.get("code_focus_excerpt") and candidate.get("code_focus_excerpt"):
            context["code_focus_excerpt"] = str(candidate.get("code_focus_excerpt"))[:1800]
        if not context.get("slice_code_excerpt") and candidate.get("slice_code_excerpt"):
            context["slice_code_excerpt"] = str(candidate.get("slice_code_excerpt"))[:2200]
        symbols = candidate.get("code_symbols")
        if isinstance(symbols, list) and symbols and not context.get("code_symbols"):
            context["code_symbols"] = [
                {
                    key: symbol[key]
                    for key in ("line", "name", "kind", "code")
                    if isinstance(symbol, Mapping) and symbol.get(key) is not None
                }
                for symbol in symbols[:12]
                if isinstance(symbol, Mapping)
            ]
    return {key: value for key, value in context.items() if value not in (None, "", [])}
def _technical_contracts(slice_state: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    contracts = slice_state.get("technical_contracts")
    if isinstance(contracts, list):
        return [contract for contract in contracts if isinstance(contract, Mapping)]
    contract = slice_state.get("technical_contract")
    if isinstance(contract, Mapping):
        return [contract]
    return []
def _visual_contract_context(slice_state: Mapping[str, Any]) -> list[dict[str, Any]]:
    contexts: list[dict[str, Any]] = []
    for contract in _technical_contracts(slice_state):
        contexts.append(
            {
                "contract_item_id": contract.get("contract_item_id"),
                "slice_index": contract.get("slice_index"),
                "scene_name": contract.get("scene_name"),
                "authoritative_instruction": contract.get("authoritative_instruction"),
                "target": contract.get("target"),
                "visual_context_request": contract.get("visual_context_request"),
            }
        )
    return contexts
def _messages_prompt_content(messages: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    for message in messages:
        for item in message.get("content") or []:
            if isinstance(item, Mapping) and item.get("type") == "text":
                parts.append(str(item.get("text") or ""))
            elif isinstance(item, Mapping) and item.get("type") == "image_url":
                parts.append("[image_url:data-url]")
    return "\n".join(parts)
def _response_content(response: Any) -> str:
    try:
        return str(response.choices[0].message.content or "")
    except Exception:
        return str(getattr(response, "output_text", "") or "")
def _parse_visual_response(content: str) -> dict[str, Any] | None:
    payload = _json_object_from_text(content)
    if not isinstance(payload, Mapping):
        return None
    confidence = _as_float(payload.get("confidence"))
    if confidence is None or confidence < MIN_CONFIDENCE:
        return None
    status = str(payload.get("status") or "recognized").strip().lower()
    if status and status not in {"recognized", "success", "ok"}:
        return None
    summary = str(payload.get("visual_summary") or "").strip()
    hint = str(payload.get("technical_hint") or "").strip()
    facts = _string_list(payload.get("visual_facts"))
    mapping = _mapping_list(payload.get("visual_to_code_mapping"))
    missing_evidence = _string_list(payload.get("missing_evidence"))
    if not summary and not hint and not facts and not mapping:
        return None
    result: dict[str, Any] = {
        "status": "recognized",
        "confidence": round(float(confidence), 3),
    }
    for key in ("visual_summary", "target_object", "issue_type", "technical_hint"):
        value = str(payload.get(key) or "").strip()
        if value:
            result[key] = value[:1000]
    for key in ("visible_texts", "visible_formulas"):
        values = _string_list(payload.get(key))
        if values:
            result[key] = values
    if facts:
        result["visual_facts"] = facts
    if mapping:
        result["visual_to_code_mapping"] = mapping
    if missing_evidence:
        result["missing_evidence"] = missing_evidence
    return result

from . import modify_visual_recognition_part4 as _part4
globals().update({k:v for _module in (_part4,) for k,v in vars(_module).items() if not k.startswith("__")})

