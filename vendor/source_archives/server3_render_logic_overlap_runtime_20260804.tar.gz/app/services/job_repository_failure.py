"""Failed generated-code collection and upload."""
import logging
from pathlib import Path
from typing import Optional

from .job_repository_status import _ts

logger=logging.getLogger(__name__)

def _collect_failed_code_bytes(
    job_id: str,
    manim_media_root: str,
) -> Optional[bytes]:
    job_dir = Path(manim_media_root) / f"job_{job_id}"
    script_path = job_dir / "script.py"
    if script_path.exists():
        return script_path.read_bytes()

    scene_scripts = sorted(job_dir.glob("script_*.py"))
    if not scene_scripts:
        return None

    parts = [
        "# MathPi failed render partial code",
        f"# job_id: {job_id}",
        "",
    ]
    for path in scene_scripts:
        parts.append(f"# ===== {path.name} =====")
        parts.append(path.read_text(encoding="utf-8", errors="replace").rstrip())
        parts.append("")
    return "\n".join(parts).encode("utf-8")


def _fallback_code_bytes(fallback_code: str | bytes | None) -> Optional[bytes]:
    if isinstance(fallback_code, bytes):
        return fallback_code if fallback_code.strip() else None
    if isinstance(fallback_code, str) and fallback_code.strip():
        return fallback_code.encode("utf-8")
    return None


async def upload_failed_code(
    job_id: str,
    manim_media_root: str,
    *,
    persist_job_url: bool = False,
    fallback_code: str | bytes | None = None,
    error_type: str | None = None,
    error_stage: str | None = None,
    error_message: str | None = None,
    scene_name: str | None = None,
    attempt: int = 0,
) -> Optional[str]:
    """失败时上传生成的代码到 COS 并写入 failed_code_url 字段。

    同时把这份"最终失败代码"以 source=final_failure 收录到 failed_code_records，
    与中间过程失败代码统一存档便于后续分析。
    """
    try:
        file_data = _collect_failed_code_bytes(job_id, manim_media_root)
        if file_data is None:
            file_data = _fallback_code_bytes(fallback_code)
        if file_data is None:
            return None
        from app.services.storage_service import storage_service
        cos_key = f"codes/job_{job_id}_failed.py"
        code_url = await storage_service.upload_file(
            cos_key,
            file_data,
            content_type="text/x-python; charset=utf-8",
        )
        if code_url:
            if persist_job_url:
                logger.warning(
                    "[FINAL_FAIL] [%s] direct failed_code_url persistence is "
                    "disabled; send URL through internal failure callback: job=%s",
                    _ts(),
                    job_id,
                )
            logger.info(
                f"[FINAL_FAIL] [{_ts()}] 失败代码已上传: {code_url}")

            # 也写入 failed_code_records 统一存档
            try:
                from app.services.failed_code_recorder import record_failed_code
                await record_failed_code(
                    job_id=job_id,
                    code=file_data,
                    source="final_failure",
                    scene_name=scene_name,
                    attempt=attempt,
                    error_type=error_type,
                    error_message=error_message,
                    stage=error_stage or "JOB_FINALIZE",
                )
            except Exception as e:
                logger.warning(
                    f"[FINAL_FAIL] [{_ts()}] failed_code_records 收录失败: {e}")
            return code_url
    except Exception as e:
        logger.warning(
            f"[FINAL_FAIL] [{_ts()}] 上传失败代码异常: {e}")
    return None


# ─────────────────────────── 切片持久化 ───────────────────────────
