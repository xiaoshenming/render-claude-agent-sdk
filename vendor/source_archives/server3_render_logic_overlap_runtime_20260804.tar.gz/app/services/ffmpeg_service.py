"""ffmpeg_service — FFmpeg 相关操作模块。

从 video_worker.py 提取的 FFmpeg 命令执行、水印叠加、切片拼接等操作。
"""
import asyncio
import logging
import subprocess
from datetime import datetime
from typing import List, Optional

from app.services import ffmpeg_concat as _concat
from app.services import ffmpeg_media as _media
from app.services import ffmpeg_metadata as _metadata
from app.services import ffmpeg_watermark_image as _watermark_image
from app.services import ffmpeg_watermark_text as _watermark_text

logger = logging.getLogger(__name__)
NORMALIZED_FPS = 30
_VIDEO_FILTER = f"fps={NORMALIZED_FPS},setpts=N/({NORMALIZED_FPS}*TB),format=yuv420p"
_AUDIO_FILTER = "aresample=async=1:first_pts=0,apad"
UNIFIED_SOCIAL_CREDIT_CODE = "91440300MADNE8DE7Y"
AIGC_METADATA_FIELD_ORDER = (
    "AIGC",
    "Label",
    "ContentProducer",
    "ProduceID",
    "ReservedCode",
    "ContentPropagator",
    "PropagateID",
    "MaterialMD5",
    "ContentMD5",
    "GeneratedAt",
    "ContentType",
    "UserUniqueID",
)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


# ─────────────────────────── 命令执行器 ───────────────────────────

async def run_cmd_async(
    cmd: List[str], timeout: Optional[int] = None,
) -> subprocess.CompletedProcess:
    """异步执行命令，不阻塞事件循环。"""
    logger.debug(f"Executing command: {' '.join(cmd)}; timeout={timeout}")
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout)
            cp = subprocess.CompletedProcess(
                cmd, proc.returncode,
                stdout.decode(), stderr.decode())
            logger.debug(
                f"Cmd returncode={cp.returncode}, "
                f"stdout(len)={len(cp.stdout or '')}, "
                f"stderr(len)={len(cp.stderr or '')}")
            return cp
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise subprocess.TimeoutExpired(cmd, timeout)
        except asyncio.CancelledError:
            if proc.returncode is None:
                proc.kill()
                await proc.wait()
            raise
    except subprocess.TimeoutExpired:
        raise
    except Exception:
        logger.exception(f"Command execution failed: {' '.join(cmd)}")
        raise


def run_cmd(
    cmd: List[str], timeout: Optional[int] = None,
) -> subprocess.CompletedProcess:
    """同步执行命令（仅用于简单快速的命令）。"""
    logger.debug(f"Executing command: {' '.join(cmd)}; timeout={timeout}")
    try:
        cp = subprocess.run(
            cmd, capture_output=True,
            text=True, timeout=timeout, check=False)
        logger.debug(
            f"Cmd returncode={cp.returncode}, "
            f"stdout(len)={len(cp.stdout or '')}, "
            f"stderr(len)={len(cp.stderr or '')}")
        return cp
    except Exception:
        logger.exception(f"Command execution failed: {' '.join(cmd)}")
        raise


for _module in (_media, _metadata, _watermark_text, _watermark_image, _concat):
    _module.facade_provider = lambda: __import__(__name__, fromlist=["*"])

NORMALIZED_FPS = _media.NORMALIZED_FPS
_VIDEO_FILTER = f"fps={NORMALIZED_FPS},setpts=N/({NORMALIZED_FPS}*TB),format=yuv420p"
_AUDIO_FILTER = "aresample=async=1:first_pts=0,apad"
UNIFIED_SOCIAL_CREDIT_CODE = _metadata.UNIFIED_SOCIAL_CREDIT_CODE
AIGC_METADATA_FIELD_ORDER = _metadata.AIGC_METADATA_FIELD_ORDER

_parse_float = _media._parse_float
_normalize_target_resolution = _media._normalize_target_resolution
_video_filter = _media._video_filter
_probe_media = _media._probe_media
_media_duration = _media._media_duration
_video_duration = _media._video_duration
_has_audio = _media._has_audio
_audio_duration = _media._audio_duration
_stream_summary = _media._stream_summary
probe_media_summary = _media.probe_media_summary
_normalize_timeout = _media._normalize_timeout

_metadata_text = _metadata._metadata_text
_metadata_component = _metadata._metadata_component
_normalize_content_type = _metadata._normalize_content_type
_normalize_generated_at = _metadata._normalize_generated_at
build_aigc_metadata_values = _metadata.build_aigc_metadata_values
build_aigc_metadata_args = _metadata.build_aigc_metadata_args
inject_aigc_metadata = _metadata.inject_aigc_metadata

_clamp_opacity = _watermark_text._clamp_opacity
_positive_int = _watermark_text._positive_int
_positive_float = _watermark_text._positive_float
_render_base_dir = _watermark_text._render_base_dir
_resolve_watermark_image_path = _watermark_text._resolve_watermark_image_path
_overlay_position = _watermark_text._overlay_position
_escape_drawtext_value = _watermark_text._escape_drawtext_value
_drawtext_fontfile = _watermark_text._drawtext_fontfile
_drawtext_position = _watermark_text._drawtext_position
draw_text_watermark = _watermark_text.draw_text_watermark

draw_image_watermark = _watermark_image.draw_image_watermark
apply_aigc_visible_watermark = _watermark_image.apply_aigc_visible_watermark
apply_watermark = _watermark_image.apply_watermark
concat_slices = _concat.concat_slices
