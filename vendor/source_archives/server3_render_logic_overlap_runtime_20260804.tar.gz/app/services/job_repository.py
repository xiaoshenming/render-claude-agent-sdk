"""Public compatibility facade for Render job persistence."""
# ruff: noqa: F401
import asyncio
import logging

from .job_repository_status import JobStatusWriteError, _ts, get_job_status, is_job_cancelled, update_job_status
from .job_repository_success import persist_renderable_raw_code_url, update_database_success
from .job_repository_failure import _collect_failed_code_bytes, _fallback_code_bytes, upload_failed_code

logger=logging.getLogger(__name__)

async def get_slice_duration(mp4_path: str) -> float:
    """用 ffprobe 读取视频时长。"""
    cmd = (
        f'ffprobe -v error -show_entries format=duration '
        f'-of csv=p=0 "{mp4_path}"'
    )
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return float(stdout.decode().strip())
    except Exception:
        return 0.0


async def upload_and_register_slices(
    job_id: str,
    user_id: str,
    scene_names: list,
    slice_mp4_paths: list,
    full_code: str,
) -> list[dict]:
    """上传切片 MP4 到 COS，并优先通过 WebAPI 注册切片。"""
    from app.services import internal_api_client
    from app.services.storage_service import storage_service
    from app.workers.validation.code_validator import extract_scene_standalone_code

    slices_data = []
    timeline_slices = []
    for i, (scene_name, mp4_path) in enumerate(
        zip(scene_names, slice_mp4_paths)
    ):
        with open(mp4_path, "rb") as f:
            mp4_bytes = f.read()
        cos_key = f"slices/{user_id}/{job_id}/slice_{i}.mp4"
        video_url = await storage_service.upload_file(
            cos_key,
            mp4_bytes,
            content_type="video/mp4",
            cache_control="public, max-age=31536000",
        )
        scene_code = extract_scene_standalone_code(full_code, scene_name)
        duration = await get_slice_duration(mp4_path)
        item = {
            "slice_index": i,
            "scene_name": scene_name,
            "slice_code": scene_code,
            "video_url": video_url,
            "duration": duration,
        }
        slices_data.append(item)
        timeline_slices.append({**item, "local_mp4_path": mp4_path})

    if await internal_api_client.register_video_slices(job_id, slices_data):
        logger.info(
            f"[SLICE] 切片记录已通过 internal API 创建: "
            f"job={job_id}, count={len(slices_data)}")
        return timeline_slices

    raise RuntimeError(
        f"internal API register_video_slices failed: job={job_id}"
    )

__all__=["JobStatusWriteError","get_job_status","get_slice_duration","is_job_cancelled","persist_renderable_raw_code_url","update_database_success","update_job_status","upload_and_register_slices","upload_failed_code"]
