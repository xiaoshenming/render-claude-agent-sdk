"""AIGC metadata construction and MP4 remuxing."""
import hashlib
import json
import logging
import os
import re
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

logger = logging.getLogger(__name__)
UNIFIED_SOCIAL_CREDIT_CODE = "91440300MADNE8DE7Y"
AIGC_METADATA_FIELD_ORDER = ("AIGC","Label","ContentProducer","ProduceID","ReservedCode","ContentPropagator","PropagateID","MaterialMD5","ContentMD5","GeneratedAt","ContentType","UserUniqueID")
facade_provider: Callable[[], Any] | None = None

def _metadata_text(value: Any, fallback: str) -> str:
    text = str(value or "").strip()
    return text or fallback


def _metadata_component(value: Any, fallback: str) -> str:
    text = _metadata_text(value, fallback)
    cleaned = re.sub(r"[^0-9A-Za-z_-]+", "_", text)
    return cleaned.strip("_") or fallback


def _normalize_content_type(value: Any) -> str:
    text = _metadata_text(value, "MP4").upper()
    if text in {"VIDEO/MP4", "MP4"}:
        return "MP4"
    return text


def _normalize_generated_at(value: Any) -> tuple[str, str]:
    if isinstance(value, datetime):
        original = value.isoformat()
        if value.tzinfo is not None:
            return value.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ"), original
        return value.strftime("%Y%m%d%H%M%S"), original
    text = str(value or "").strip()
    if text:
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if parsed.tzinfo is not None:
                return parsed.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ"), text
            return parsed.strftime("%Y%m%d%H%M%S"), text
        except ValueError:
            return _metadata_component(text, "unknown-time"), text
    now = datetime.now(timezone.utc)
    return now.strftime("%Y%m%dT%H%M%SZ"), now.isoformat(timespec="seconds")


def build_aigc_metadata_values(
    input_bytes: bytes,
    job_id: str,
    context: Mapping[str, Any] | None,
) -> dict[str, str]:
    """Build deterministic AIGC metadata values for MP4 remuxing."""
    context = context or {}
    material_md5 = hashlib.md5(input_bytes).hexdigest()
    user_id = _metadata_component(context.get("user_id"), "unknown-user")
    generated_at_part, generated_at = _normalize_generated_at(
        context.get("generated_at")
    )
    content_type = _normalize_content_type(context.get("content_type"))
    content_type_id = content_type.lower()
    produce_id_input = json.dumps(
        {
            "content_type": content_type,
            "generated_at": generated_at,
            "material_md5": material_md5,
            "user_id": user_id,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    produce_id = f"{user_id}:{generated_at_part}:{content_type_id}:{material_md5}"
    return {
        "AIGC": "1",
        "Label": "1",
        "ContentProducer": UNIFIED_SOCIAL_CREDIT_CODE,
        "ProduceID": produce_id,
        "ReservedCode": "4",
        "ContentPropagator": UNIFIED_SOCIAL_CREDIT_CODE,
        "PropagateID": produce_id,
        "MaterialMD5": material_md5,
        "ContentMD5": material_md5,
        "GeneratedAt": generated_at,
        "ContentType": content_type_id,
        "UserUniqueID": user_id,
        "_ProduceIDInput": produce_id_input,
    }


def build_aigc_metadata_args(
    input_bytes: bytes,
    job_id: str,
    context: Mapping[str, Any] | None,
) -> list[str]:
    values = build_aigc_metadata_values(input_bytes, job_id, context)
    aigc_payload = "AIGC:" + ";".join(
        f"{field}={values[field]}"
        for field in AIGC_METADATA_FIELD_ORDER
        if field != "AIGC"
    )
    args = ["-metadata", f"AIGC={aigc_payload}"]
    for field in AIGC_METADATA_FIELD_ORDER:
        if field == "AIGC":
            continue
        args.extend(["-metadata", f"{field}={values[field]}"])
    return args


async def inject_aigc_metadata(
    input_bytes: bytes,
    output_dir: str,
    job_id: str,
    context: Mapping[str, Any] | None,
) -> bytes:
    """Write AIGC metadata into an MP4 via stream-copy remuxing."""
    os.makedirs(output_dir, exist_ok=True)
    tmp_input = os.path.join(output_dir, f"video_{job_id}_aigc_raw.mp4")
    tmp_output = os.path.join(output_dir, f"video_{job_id}_aigc.mp4")
    try:
        with open(tmp_input, "wb") as f:
            f.write(input_bytes)

        cmd = [
            "ffmpeg", "-i", tmp_input,
            "-map", "0:v:0",
            "-map", "0:a?",
            "-c", "copy",
            "-movflags", "+faststart+use_metadata_tags",
            "-max_muxing_queue_size", "1024",
            "-avoid_negative_ts", "make_zero",
            *build_aigc_metadata_args(input_bytes, job_id, context),
            tmp_output, "-y",
        ]
        cp = await facade_provider().run_cmd_async(cmd, timeout=90)
        if cp.returncode != 0:
            raise Exception(
                f"FFmpeg AIGC metadata injection failed: "
                f"{cp.stderr[:300] if cp.stderr else 'unknown'}"
            )

        with open(tmp_output, "rb") as f:
            result = f.read()

        logger.info(
            f"[AIGC_METADATA] [{facade_provider()._ts()}] 元数据写入完成, "
            f"大小={len(result) / 1024 / 1024:.2f}MB"
        )
        return result
    finally:
        for p in [tmp_input, tmp_output]:
            try:
                os.remove(p)
            except OSError:
                pass
