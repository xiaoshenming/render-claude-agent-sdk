"""Successful job completion and renderable-code persistence."""
import logging

from .job_repository_status import _ts

logger=logging.getLogger(__name__)

async def update_database_success(
    job_id: str,
    user_id: str,
    video_url: str,
    code_url: str,
    cost: float,
    title: str = "",
    description: str = "",
    has_watermark: bool = False,
    aigc_clean_video_url: str | None = None,
    aigc_watermarked_video_url: str | None = None,
    aigc_display_variant: str | None = None,
    aigc_visible_watermark_applied: bool = False,
    aigc_metadata_injected: bool = False,
    pipeline_mode: str = None,
    slice_count: int = 0,
    llm_fix_count: int = 0,
    render_fix_count: int = 0,
    total_tokens: int = 0,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    retry_count: int = 0,
    timeline_manifest: dict | None = None,
) -> bool:
    """写入视频记录 + 更新任务 SUCCESS。带终态保护和 3 次重试。"""
    logger.info(f"[DB] [{_ts()}] 开始写入数据库: job={job_id}")
    from app.services import internal_api_client

    payload = {
        "user_id": user_id,
        "video_url": video_url,
        "aigc_clean_video_url": aigc_clean_video_url,
        "aigc_watermarked_video_url": aigc_watermarked_video_url,
        "aigc_display_variant": aigc_display_variant,
        "aigc_visible_watermark_applied": aigc_visible_watermark_applied,
        "aigc_metadata_injected": aigc_metadata_injected,
        "code_url": code_url,
        "cost": cost,
        "title": title,
        "description": description,
        "has_watermark": has_watermark,
        "pipeline_mode": pipeline_mode,
        "slice_count": slice_count,
        "retry_count": retry_count or 0,
        "llm_fix_count": llm_fix_count,
        "render_fix_count": render_fix_count,
        "total_tokens": total_tokens,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_tokens": cache_read_tokens,
        "cache_creation_tokens": cache_creation_tokens,
    }
    if timeline_manifest is not None:
        payload["timeline_manifest"] = timeline_manifest
    api_result = await internal_api_client.complete_video_job_success(
        job_id,
        payload,
    )
    if api_result is True:
        logger.info(
            f"[DB] [{_ts()}] SUCCESS 已通过 internal API 写回: job={job_id}"
        )
        return True
    if api_result is False:
        logger.warning(
            f"[DB] [{_ts()}] SUCCESS internal API 终态保护跳过: job={job_id}"
        )
        return False
    raise RuntimeError(
        f"internal API complete_video_job_success failed: job={job_id}"
    )


async def persist_renderable_raw_code_url(
    job_id: str,
    renderable_raw_code_url: str,
    *,
    retry_count: int = 0,
) -> bool:
    """Persist the COS URL for the renderable source before logic review."""
    if not renderable_raw_code_url:
        return False

    from app.services import internal_api_client

    api_result = await internal_api_client.update_video_job_renderable_raw_code_url(
        job_id,
        renderable_raw_code_url,
        retry_count=retry_count,
    )
    if api_result is True:
        logger.info(
            "[RAW-CODE] [%s] renderable raw code URL persisted: job=%s",
            _ts(),
            job_id,
        )
        return True
    if api_result is False:
        logger.warning(
            "[RAW-CODE] [%s] renderable raw code URL write skipped: job=%s",
            _ts(),
            job_id,
        )
        return False
    logger.warning(
        "[RAW-CODE] [%s] renderable raw code URL write failed: job=%s",
        _ts(),
        job_id,
    )
    return False


# ─────────────────────────── 失败代码上传 ───────────────────────────
