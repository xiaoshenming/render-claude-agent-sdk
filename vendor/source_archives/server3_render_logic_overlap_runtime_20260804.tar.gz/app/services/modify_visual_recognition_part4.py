"""后台二次修改视觉识别服务。

该服务只为修改 prompt 提供高置信度视觉参考。任何配置缺失、抽帧失败、
多模态调用失败、JSON 解析失败或低置信度结果都会 fail-open 返回 None。
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import tempfile
from pathlib import Path
from typing import Any, Mapping

logger = logging.getLogger(__name__)

TRACE_CALL_TYPE = "modify_visual_recognition"
MIN_CONFIDENCE = 0.65



def _json_object_from_text(text: str) -> Mapping[str, Any] | None:
    raw = str(text or "").strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
        raw = re.sub(r"\s*```$", "", raw)
    try:
        data = json.loads(raw)
    except Exception:
        match = re.search(r"\{.*\}", raw, flags=re.DOTALL)
        if not match:
            return None
        try:
            data = json.loads(match.group(0))
        except Exception:
            return None
    return data if isinstance(data, Mapping) else None
def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip()[:300] for item in value if str(item or "").strip()]
def _mapping_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    mappings: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, Mapping):
            cleaned = {
                str(key): (
                    str(raw_value).strip()[:300]
                    if isinstance(raw_value, (str, int, float, bool))
                    else raw_value
                )
                for key, raw_value in item.items()
                if raw_value not in (None, "")
            }
            if cleaned:
                mappings.append(cleaned)
        elif str(item or "").strip():
            mappings.append({"description": str(item).strip()[:300]})
    return mappings[:8]
def _visual_recognition_lines(visual: Mapping[str, Any]) -> list[str]:
    lines: list[str] = []
    confidence = _as_float(visual.get("confidence"))
    if confidence is not None:
        lines.append(f"- confidence={confidence:.2f}")
    mapping = {
        "visual_summary": "画面摘要",
        "target_object": "识别目标",
        "issue_type": "问题类型",
        "technical_hint": "旧版视觉备注",
    }
    for key, label in mapping.items():
        value = str(visual.get(key) or "").strip()
        if value:
            lines.append(f"- {label}: {value[:500]}")
    texts = _string_list(visual.get("visible_texts"))
    if texts:
        lines.append("- 可见文字: " + "；".join(texts[:8]))
    formulas = _string_list(visual.get("visible_formulas"))
    if formulas:
        lines.append("- 可见公式: " + "；".join(formulas[:8]))
    facts = _string_list(visual.get("visual_facts"))
    if facts:
        lines.append("- 视觉事实: " + "；".join(facts[:8]))
    code_mapping = _mapping_list(visual.get("visual_to_code_mapping"))
    if code_mapping:
        mapping_text = "；".join(
            json.dumps(item, ensure_ascii=False, sort_keys=True)[:240]
            for item in code_mapping[:6]
        )
        lines.append("- 视觉到代码映射候选: " + mapping_text)
    missing = _string_list(visual.get("missing_evidence"))
    if missing:
        lines.append("- 缺失证据: " + "；".join(missing[:6]))
    return lines

