"""Render-side client for WebAPI internal endpoints."""

import asyncio
import logging
from functools import partial
from typing import Any

import httpx

from app.core.config import settings
from app.services.internal_api_transport import request_with_retry

logger = logging.getLogger(__name__)


def _url(job_id: str, suffix: str) -> str:
    base = settings.WEBAPI_INTERNAL_URL.rstrip("/")
    return f"{base}/api/v1/internal/render/jobs/{job_id}/{suffix}"


_register_slices_url = partial(_url, suffix="slices")
_complete_success_url = partial(_url, suffix="success")
_mark_processing_url = partial(_url, suffix="processing")
_job_status_url = partial(_url, suffix="status")
_complete_failure_url = partial(_url, suffix="failure")
_renderable_raw_code_url = partial(_url, suffix="renderable-raw-code")
_complete_modify_success_url = partial(_url, suffix="modify-success")


def _max_attempts() -> int:
    try:
        return max(1, int(settings.WEBAPI_INTERNAL_MAX_RETRIES))
    except (TypeError, ValueError):
        return 1


def _should_retry_status(status_code: int) -> bool:
    return status_code == 429 or 500 <= status_code < 600


def _internal_headers() -> dict[str, str]:
    token = settings.WEBAPI_INTERNAL_TOKEN
    return {"Authorization": f"Bearer {token}", "X-Internal-Token": token}


def _timeout() -> int:
    return max(1, int(settings.WEBAPI_INTERNAL_TIMEOUT or 10))


def _configured(operation: str, job_id: str) -> bool:
    if settings.WEBAPI_INTERNAL_URL and settings.WEBAPI_INTERNAL_TOKEN:
        return True
    logger.info("[INTERNAL-API] skip %s: config_missing job=%s", operation, job_id)
    return False


async def _request(
    method: str,
    url: str,
    *,
    operation: str,
    job_id: str,
    payload: dict[str, Any] | None = None,
):
    return await request_with_retry(
        method=method,
        url=url,
        headers=_internal_headers(),
        timeout=_timeout(),
        attempts=_max_attempts(),
        operation=operation,
        job_id=job_id,
        payload=payload,
        client_type=httpx.AsyncClient,
        sleep=asyncio.sleep,
    )


def _changed(response: Any) -> bool | None:
    if response is None:
        return None
    changed = response.json().get("changed")
    return changed if isinstance(changed, bool) else None


async def register_video_slices(job_id: str, slices: list[dict[str, Any]]) -> bool:
    if not _configured("register_video_slices", job_id):
        return False
    response = await _request(
        "post",
        _register_slices_url(job_id),
        operation="register_video_slices",
        job_id=job_id,
        payload={"job_id": job_id, "slices": slices},
    )
    return response is not None


async def mark_video_job_processing(job_id: str) -> bool | None:
    if not _configured("mark_video_job_processing", job_id):
        return None
    response = await _request(
        "post",
        _mark_processing_url(job_id),
        operation="mark_video_job_processing",
        job_id=job_id,
    )
    if response is None:
        return None
    body = response.json()
    if body.get("changed") is True:
        return True
    if body.get("changed") is False or body.get("heartbeat") is True:
        return False
    return None


async def update_video_job_renderable_raw_code_url(
    job_id: str,
    renderable_raw_code_url: str,
    *,
    retry_count: int = 0,
) -> bool | None:
    if not _configured("update_renderable_raw_code_url", job_id):
        return None
    response = await _request(
        "post",
        _renderable_raw_code_url(job_id),
        operation="update_renderable_raw_code_url",
        job_id=job_id,
        payload={
            "renderable_raw_code_url": renderable_raw_code_url,
            "retry_count": max(0, int(retry_count or 0)),
        },
    )
    return _changed(response)


async def complete_video_job_success(
    job_id: str, payload: dict[str, Any]
) -> bool | None:
    if not _configured("complete_video_job_success", job_id):
        return None
    response = await _request(
        "post",
        _complete_success_url(job_id),
        operation="complete_video_job_success",
        job_id=job_id,
        payload=payload,
    )
    return _changed(response)


async def get_video_job_status(job_id: str) -> str | None:
    if not _configured("get_video_job_status", job_id):
        return None
    response = await _request(
        "get", _job_status_url(job_id), operation="get_video_job_status", job_id=job_id
    )
    if response is None:
        return None
    status = response.json().get("status")
    return str(status) if status else None


async def complete_video_job_failure(job_id: str, payload: dict[str, Any]) -> str:
    if not _configured("complete_video_job_failure", job_id):
        return "failed"
    response = await _request(
        "post",
        _complete_failure_url(job_id),
        operation="complete_video_job_failure",
        job_id=job_id,
        payload=payload,
    )
    changed = _changed(response)
    if changed is True:
        return "changed"
    if changed is False:
        return "already_terminal"
    return "failed"


async def complete_video_modify_success(
    job_id: str, payload: dict[str, Any]
) -> bool | None:
    if not _configured("complete_video_modify_success", job_id):
        return None
    response = await _request(
        "post",
        _complete_modify_success_url(job_id),
        operation="complete_video_modify_success",
        job_id=job_id,
        payload=payload,
    )
    return _changed(response)
