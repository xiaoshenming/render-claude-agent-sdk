"""LLM compatibility facade for multi-backend failover."""

# ruff: noqa: E731, F401

import logging
import sys
from types import SimpleNamespace
from typing import Any, List

import litellm
try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover - dependency is present in runtime images
    AsyncOpenAI = None

from app.core.config import settings
from app.services.backend_health import backend_health_registry
from app.services.llm_call_tracer import LLMCallTracer
from app.services.llm_usage import (
    extract_usage_info as _extract_usage_info,
    get_value as _get_value,
    merge_usage_info as _merge_usage_info,  # noqa: F401 - compatibility export
    safe_completion_cost as _safe_completion_cost,
    usage_info_with_trace_context as _usage_info_with_trace_context,
)
from app.services.llm_stream_adapters import (
    LLMEmptyResponseError,
    LLMProviderCancelledError,
    LLMStreamIncompleteError,
    LLMStreamTimeoutError,
    await_stream_open as _await_stream_open,
    cancelled_error_message as _cancelled_error_message,
    collect_stream_usage as _collect_stream_usage,
    extract_message_content as _extract_message_content,
    next_stream_item as _next_stream_item,
    responses_stream_client_timeout as _responses_stream_client_timeout_impl,
    stream_first_content_timeout as _stream_first_content_timeout_impl,
    stream_idle_timeout as _stream_idle_timeout_impl,
    stream_open_timeout as _stream_open_timeout_impl,
    stream_timeout_setting as _stream_timeout_setting_impl,
    task_cancellation_requested as _task_cancellation_requested,
)
from app.services.llm_stream_runner import run_stream_call
from app.services.llm_responses_adapters import (
    adapt_responses_response as _adapt_responses_response,  # noqa: F401
    collect_responses_stream_usage as _collect_responses_stream_usage,
    extract_responses_output_text as _extract_responses_output_text,
    messages_to_responses_input as _messages_to_responses_input,  # noqa: F401
    responses_finish_reason as _responses_finish_reason,  # noqa: F401
    responses_stream_delta as _responses_stream_delta,
    responses_stream_error as _responses_stream_error,
)
from app.services.llm_backend_config import load_backends_from_raw
from app.services.llm_backend_model import (
    DEFAULT_GPT_REASONING_EFFORT,
    FALLBACK_GPT_REASONING_EFFORT,
    GPT5_HIGH_REASONING_CALL_TYPES,  # noqa: F401 - compatibility export
)
from app.services.llm_facade_backend import FacadeBackend
from app.services import llm_facade_policy as _facade_policy
from app.services.llm_manager_health import LLMManagerHealth
from app.services.llm_manager_facade import LLMManagerFacade
from app.services import llm_facade_dependencies as _facade_dependencies
from app.services.llm_error_policy import (
    ErrorAction as _ErrorAction,
    classify_error as _classify_error,
    is_generation_validation_error as _is_generation_validation_error,
    is_permanent_backend_unavailable as _is_permanent_backend_unavailable,
    should_cooldown_backend as _should_cooldown_backend,
)
from app.services.llm_nonstream_runner import run_nonstream_call
from app.services import llm_provider_policy as _provider_policy
from app.services.llm_responses_client import ResponsesClientAdapter
from app.services.llm_runtime_config import LLMRuntimeConfig


def _stream_timeout_setting(name: str, fallback_timeout: int) -> int:
    return _stream_timeout_setting_impl(name, fallback_timeout, config=settings)


def _stream_first_content_timeout(fallback_timeout: int) -> int:
    return _stream_first_content_timeout_impl(fallback_timeout, config=settings)


def _stream_idle_timeout(fallback_timeout: int) -> int:
    return _stream_idle_timeout_impl(fallback_timeout, config=settings)


def _stream_open_timeout(fallback_timeout: int) -> int:
    return _stream_open_timeout_impl(fallback_timeout, config=settings)


def _responses_stream_client_timeout(fallback_timeout: int) -> int:
    return _responses_stream_client_timeout_impl(fallback_timeout, config=settings)

logger = logging.getLogger(__name__)

DEFAULT_LLM_MAX_OUTPUT_TOKENS = _facade_policy.DEFAULT_MAX_OUTPUT_TOKENS
TRANSIENT_BACKEND_COOLDOWN_SECONDS = 120
QUALITY_MULTIMODAL_COOLDOWN_BYPASS_CALL_TYPES = _provider_policy.QUALITY_CALL_TYPES
_beijing_now = _facade_policy.beijing_now
_compose_backend_model = _facade_policy.compose_backend_model


def _configured_max_output_tokens() -> int:
    return _facade_policy.configured_max_output_tokens(settings)


def _truthy_setting(name: str, default: bool = False) -> bool:
    return _facade_policy.truthy_setting(settings, name, default)


def _backend_health_disabled() -> bool:
    return _truthy_setting("LLM_BACKEND_HEALTH_DISABLED", False)


def _bypass_backend_cooldown_for_call_type(call_type: str) -> bool:
    return call_type in QUALITY_MULTIMODAL_COOLDOWN_BYPASS_CALL_TYPES and _truthy_setting(
        "QUALITY_MULTIMODAL_BYPASS_BACKEND_COOLDOWN", False
    )


SUPPORTED_VOICES = {
    "zh-CN-XiaoxiaoMultilingualNeural",
    "zh-CN-XiaochenMultilingualNeural",
    "zh-CN-YunyiMultilingualNeural",
    "zh-CN-YunxiaoMultilingualNeural",
}

litellm.suppress_debug_info = True

_runtime_config = LLMRuntimeConfig(lambda: sys.modules[__name__])

_messages_to_prompt_content = _facade_policy.messages_to_prompt_content


_messages_for_provider = _provider_policy.messages_for_provider


def _responses_prompt_cache_kwargs(context: dict | None) -> dict[str, str]:
    return _provider_policy.responses_prompt_cache_kwargs(context, settings)


_trace_context_with_provider_cache_params = _provider_policy.with_provider_cache_params


def _quality_multimodal_reasoning_extra_body(
    call_type: str | None,
    trace_usage_context: dict | None,
) -> dict[str, Any]:
    return _provider_policy.quality_reasoning_extra_body(
        call_type,
        trace_usage_context,
        settings,
    )


def _litellm_extra_kwargs_for_call(
    backend: "_Backend",
    *,
    call_type: str | None,
    trace_usage_context: dict | None,
) -> dict[str, Any]:
    return _provider_policy.litellm_extra_kwargs(
        backend,
        call_type,
        trace_usage_context,
        settings,
    )


_trace_context_with_quality_provider_policy = (
    _provider_policy.with_quality_provider_policy
)

def _should_retry_with_high_reasoning(exc: Exception, request_kwargs: dict) -> bool:
    return _facade_policy.should_retry_with_high_reasoning(
        exc, request_kwargs, FALLBACK_GPT_REASONING_EFFORT
    )


def _with_high_reasoning(request_kwargs: dict) -> dict:
    return _facade_policy.with_high_reasoning(
        request_kwargs, FALLBACK_GPT_REASONING_EFFORT
    )


def _nonstream_dependencies() -> SimpleNamespace:
    return _facade_dependencies.nonstream_dependencies(sys.modules[__name__])


def _stream_dependencies() -> SimpleNamespace:
    return _facade_dependencies.stream_dependencies(sys.modules[__name__])


# ---------------------------------------------------------------------------
# Backend definition & loading
# ---------------------------------------------------------------------------


_Backend = FacadeBackend
_Backend.config_provider = lambda: settings


def _load_backends_from_raw(raw: str, config_name: str) -> List[_Backend]:
    return load_backends_from_raw(
        raw,
        config_name,
        backend_type=_Backend,
        compose_model=_compose_backend_model,
    )





_repair_llm_backends_raw = lambda: _runtime_config.raw("repair", "REPAIR_LLM_BACKENDS_JSON")
get_fast_pre_repair_llm_backends_json = lambda: _runtime_config.raw("fast_pre_repair")
_modify_llm_backends_raw = lambda: _runtime_config.raw("modify", "MODIFY_LLM_BACKENDS_JSON")
_modify_visual_llm_backends_raw = lambda: _runtime_config.raw("modify_visual")
_skill_driver_llm_backends_raw = lambda: _runtime_config.raw("skill_driver")
get_quality_multimodal_llm_backends_json = lambda: _runtime_config.raw("quality_multimodal")
_load_repair_backends = lambda: _runtime_config.load_required(
    "repair", "REPAIR_LLM_BACKENDS_JSON", "REPAIR_LLM_BACKENDS_JSON"
)
_load_modify_backends = lambda: _runtime_config.load_required(
    "modify", "MODIFY_LLM_BACKENDS_JSON", "MODIFY_LLM_BACKENDS_JSON"
)
_load_modify_visual_backends = lambda: _runtime_config.load_required(
    "modify_visual", "llm.render.modify_visual_backends"
)
_load_skill_driver_backends = lambda: _runtime_config.load_required(
    "skill_driver", "llm.render.skill_driver_backends"
)
_load_quality_multimodal_backends = lambda: _runtime_config.load_required(
    "quality_multimodal", "llm.render.quality_multimodal_backends"
)
_load_backends = _runtime_config.load_main


class _LLMManager(LLMManagerFacade):
    def __init__(self, backend_loader=None):
        super().__init__(lambda: sys.modules[__name__], backend_loader)


_llm_manager = _LLMManager()
_repair_llm_manager = _LLMManager(_load_repair_backends)
_modify_llm_manager = _LLMManager(_load_modify_backends)
_modify_visual_llm_manager = _LLMManager(_load_modify_visual_backends)
_skill_driver_llm_manager = _LLMManager(_load_skill_driver_backends)
_quality_multimodal_llm_manager = _LLMManager(_load_quality_multimodal_backends)

get_llm_manager = lambda: _llm_manager
is_repair_llm_manager_configured = lambda: bool(_repair_llm_backends_raw())
is_modify_llm_manager_configured = lambda: bool(_modify_llm_backends_raw())
has_modify_visual_llm_backends = lambda: bool(_modify_visual_llm_backends_raw())
is_skill_driver_llm_manager_configured = lambda: bool(_skill_driver_llm_backends_raw())


def get_repair_llm_manager():
    return _repair_llm_manager if is_repair_llm_manager_configured() else _llm_manager


def get_modify_llm_manager():
    if is_modify_llm_manager_configured():
        return _modify_llm_manager
    return get_repair_llm_manager()


get_skill_driver_llm_manager = lambda: _skill_driver_llm_manager
get_modify_visual_llm_manager = lambda: _modify_visual_llm_manager
get_quality_multimodal_llm_manager = lambda: _quality_multimodal_llm_manager
set_runtime_llm_backends_json = lambda raw: _runtime_config.set("main", raw, _llm_manager)
set_runtime_repair_llm_backends_json = lambda raw: _runtime_config.set("repair", raw, _repair_llm_manager)
set_runtime_fast_pre_repair_llm_backends_json = lambda raw: _runtime_config.set("fast_pre_repair", raw)
set_runtime_modify_llm_backends_json = lambda raw: _runtime_config.set(
    "modify", raw, _modify_llm_manager
)
set_runtime_modify_visual_llm_backends_json = lambda raw: _runtime_config.set(
    "modify_visual", raw, _modify_visual_llm_manager
)
set_runtime_skill_driver_llm_backends_json = lambda raw: _runtime_config.set(
    "skill_driver", raw, _skill_driver_llm_manager
)
set_runtime_quality_multimodal_llm_backends_json = lambda raw: _runtime_config.set(
    "quality_multimodal", raw, _quality_multimodal_llm_manager
)



# ---------------------------------------------------------------------------
# Backward-compatible re-exports
# ---------------------------------------------------------------------------
from app.services.llm_generation import (  # noqa: F401, E402
    extract_usage_details,
    generate_manim_code,
    generate_manim_code_stream,
    generate_outline,
    generate_single_scene,
)
