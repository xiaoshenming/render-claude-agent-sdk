"""Backend compatibility type with call-time configuration lookup."""

from typing import Any, Callable

from app.services.llm_backend_model import LLMBackend


class FacadeBackend(LLMBackend):
    config_provider: Callable[[], Any] | None = None

    @property
    def temperature(self):
        if self.model.startswith("anthropic/"):
            return None
        model_id = self.model.lower().split("/", 1)[-1]
        if model_id.startswith("gpt-5") or self.model.startswith("gemini/"):
            return 1.0
        return type(self).config_provider().LLM_TEMPERATURE

    @property
    def effective_timeout(self) -> int:
        return self.timeout if self.timeout else type(self).config_provider().LLM_TIMEOUT
