"""Serialization and classification helpers for render error collection."""

from __future__ import annotations

import hashlib
import json
from os import PathLike
import re
from typing import Any


SEVERITY_WEIGHT = {
    "CRITICAL": 4,
    "ERROR": 3,
    "WARNING": 2,
    "INFO": 1,
}

QUALITY_ERROR_PREFIX_BY_CATEGORY = {
    "LLM_GENERATION": "LLM",
    "CODE_PARSE": "CODE",
    "CODE_TRUNCATION": "CODE",
    "MANIM_RENDER": "RENDER",
    "FFMPEG": "RENDER",
    "UPLOAD": "STORAGE",
    "ENVIRONMENT": "RENDER",
    "FIX_LOOP": "CODE",
    "COMPONENT_REUSE": "CODE",
    "PIPELINE": "RENDER",
    "CONTAINER": "RENDER",
    "TIMEOUT": "RENDER",
    "RATE_LIMIT": "LLM",
    "TTS_CONNECTION": "TTS",
    "TTS_PROVIDER_ERROR": "TTS",
    "TTS_AUDIO_MISSING": "TTS",
    "TTS_SYNC_DRIFT": "TTS",
    "SERIALIZATION": "API",
    "DATABASE": "DB",
    "MQ": "MQ",
    "QUEUE": "MQ",
    "RABBITMQ": "MQ",
    "RETRY_FAILURE": "MQ",
    "IMAGE_IN_CODE": "CODE",
    "SOLVE_PIPELINE": "RENDER",
    "QUALITY_REJECTED": "QUALITY",
}

RETRYABLE_QUALITY_KEYWORDS = (
    "timeout",
    "rate limit",
    "quota",
    "retry",
    "requeue",
    "nack",
    "connection",
    "network",
    "rabbitmq",
    "超时",
    "限流",
    "重试",
    "网络",
    "连接",
)


def slug(value: str | None, *, default: str = "unknown") -> str:
    text_value = str(value or default).strip().lower()
    text_value = re.sub(r"[^a-z0-9]+", "_", text_value).strip("_")
    return text_value or default


def quality_error_code(category: str | None, stage: str | None) -> str:
    category_value = str(category or "PIPELINE").upper()
    if category_value == "QUALITY_REJECTED":
        return "QUALITY_REJECTED"
    if "LAYOUT" in category_value or "LAYOUT" in str(stage or "").upper():
        prefix = "LAYOUT"
    elif "TTS" in category_value or "TTS" in str(stage or "").upper():
        prefix = "TTS"
    else:
        prefix = QUALITY_ERROR_PREFIX_BY_CATEGORY.get(category_value, "RENDER")
    if prefix == "MQ" and category_value in {"MQ", "QUEUE", "RABBITMQ"}:
        return f"MQ_{slug(stage or category_value).upper()}"
    if prefix == "DB":
        return f"DB_{slug(stage or category_value).upper()}"
    suffix = slug(category_value).upper()
    if prefix == "TTS" and suffix.startswith("TTS_"):
        return suffix
    return f"{prefix}_{suffix}"


def quality_error_stage(category: str | None, stage: str | None) -> str:
    return slug(stage or category, default="render")


def quality_error_retryable(category: str | None, message: str | None) -> bool:
    text_value = f"{category or ''} {message or ''}".lower()
    return any(keyword in text_value for keyword in RETRYABLE_QUALITY_KEYWORDS)


def quality_error_suggestion(error_code: str, retryable: bool) -> str:
    if error_code == "QUALITY_REJECTED":
        return "这是质量门主动拦截，保留证据并优化生成/修复规则，不按基础设施告警处理。"
    if error_code.startswith("TTS_"):
        return "检查 TTS 服务、音频生成、字幕同步和最终视频音轨证据。"
    if retryable:
        return "先保留证据并允许有限重试，重复出现时进入人工复核。"
    if error_code.startswith("LAYOUT_"):
        return "复核布局报告、截图和自动修复结果，回写布局规则。"
    if error_code.startswith("CODE_"):
        return "查看 failed_code_records 和静态扫描结果，优化代码生成或修复策略。"
    if error_code.startswith("STORAGE_"):
        return "检查 COS 上传、对象存在性、签名和访问链路。"
    if error_code.startswith("DB_"):
        return "检查视频记录、任务状态、result_video_id 和数据库事务回写证据。"
    return "按 job_id、request_id 和 render_log_id 回查渲染链路证据。"


def json_safe_snapshot(
    value: Any,
    *,
    max_depth: int = 4,
    max_items: int = 50,
    _seen: set[int] | None = None,
) -> Any:
    """Return a bounded JSON-safe snapshot, never a live runtime object."""
    if _seen is None:
        _seen = set()
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, PathLike):
        return str(value)
    if isinstance(value, BaseException):
        return {"type": type(value).__name__, "message": str(value)[:1000]}
    if max_depth <= 0:
        return {"type": type(value).__name__, "repr": repr(value)[:500]}

    value_id = id(value)
    if value_id in _seen:
        return {"type": type(value).__name__, "repr": "[circular]"}
    _seen.add(value_id)
    try:
        if isinstance(value, dict):
            items = list(value.items())[:max_items]
            return {
                str(key): json_safe_snapshot(
                    item,
                    max_depth=max_depth - 1,
                    max_items=max_items,
                    _seen=_seen,
                )
                for key, item in items
            }
        if isinstance(value, (list, tuple, set)):
            return [
                json_safe_snapshot(
                    item,
                    max_depth=max_depth - 1,
                    max_items=max_items,
                    _seen=_seen,
                )
                for item in list(value)[:max_items]
            ]
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return {"type": type(value).__name__, "repr": repr(value)[:500]}
    finally:
        _seen.discard(value_id)


def json_param(value: dict | None) -> str:
    return json.dumps(json_safe_snapshot(value or {}), ensure_ascii=False)


def bounded_identifier(
    value: object,
    *,
    max_length: int,
    default: str | None = None,
) -> str | None:
    if value in (None, ""):
        return default
    text_value = str(value)
    if len(text_value) <= max_length:
        return text_value
    digest = hashlib.sha256(text_value.encode("utf-8")).hexdigest()[:12]
    prefix_length = max(0, max_length - len(digest) - 1)
    return f"{text_value[:prefix_length]}-{digest}"


def classify_exception_severity(exc: Exception) -> str:
    msg = str(exc).lower()
    if any(
        keyword in msg
        for keyword in (
            "connection refused",
            "database",
            "rabbitmq",
            "out of memory",
            "disk full",
        )
    ):
        return "CRITICAL"
    if any(
        keyword in msg
        for keyword in ("timeout", "truncat", "manim", "ffmpeg", "render", "llm", "api")
    ):
        return "ERROR"
    if any(keyword in msg for keyword in ("deprecated", "fallback", "retry")):
        return "WARNING"
    return "ERROR"


def classify_render_error(error_message: str) -> str:
    msg = error_message.lower()
    rules = (
        (("音频缺失", "未检测到任何音频", "missing audio", "no audio"), "TTS_AUDIO_MISSING"),
        (("字幕不同步", "sync drift", "out of sync"), "TTS_SYNC_DRIFT"),
        (("tts", "voiceover", "cosyvoice", "azure tts", "配音", "语音"), "TTS_PROVIDER_ERROR"),
        (("llm", "claude", "openai", "gemini", "model"), "LLM_GENERATION"),
        (("truncat", "截断", "incomplete", "# end"), "CODE_TRUNCATION"),
        (("indent", "syntax", "parse", "ast"), "CODE_PARSE"),
        (("manim", "scene", "mobject", "animation"), "MANIM_RENDER"),
        (("ffmpeg", "audio", "video", "concat"), "FFMPEG"),
        (("upload", "cos", "storage"), "UPLOAD"),
        (("import", "module", "package", "no module", "pip install"), "ENVIRONMENT"),
        (("fix loop", "修复循环", "still failing"), "FIX_LOOP"),
        (("timeout", "超时", "timed out"), "TIMEOUT"),
        (("container", "docker", "worker"), "CONTAINER"),
        (("rate limit", "quota", "cost limit", "429", "too many requests"), "RATE_LIMIT"),
        (("json serializable", "serialize", "serializ"), "SERIALIZATION"),
        (("retry", "重试", "requeue", "nack"), "RETRY_FAILURE"),
        (("imagemobject", "image_file", "load image", "png", "jpg", "svg_file", "svgmobject"), "IMAGE_IN_CODE"),
        (("solve", "解题", "figure", "static_code"), "SOLVE_PIPELINE"),
    )
    for keywords, category in rules:
        if any(keyword in msg for keyword in keywords):
            return category
    return "PIPELINE"
