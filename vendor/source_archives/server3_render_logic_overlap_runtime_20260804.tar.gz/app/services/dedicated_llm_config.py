from __future__ import annotations

import asyncio
import os
import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from typing import Any

from app.services.llm_call_tracer import LLMCallTracer as DefaultLLMCallTracer

_LIMITERS: dict[tuple[str, int], tuple[int, asyncio.Semaphore]] = {}
DEFAULT_GPT_REASONING_EFFORT = "none"
FALLBACK_GPT_REASONING_EFFORT = "high"
BEIJING_TZ = timezone(timedelta(hours=8))


def _beijing_now() -> datetime:
    return datetime.now(BEIJING_TZ)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


def _route_env(env_prefix: str, suffix: str, global_name: str, default: int | float) -> int | float:
    route_value = os.getenv(f"{env_prefix}_{suffix}")
    if route_value is not None:
        return _env_float(f"{env_prefix}_{suffix}", float(default))
    global_value = os.getenv(global_name)
    if global_value is not None:
        return _env_float(global_name, float(default))
    return default


def _route_env_int(env_prefix: str, suffix: str, global_name: str, default: int) -> int:
    return max(1, int(_route_env(env_prefix, suffix, global_name, default)))


def _route_env_float(env_prefix: str, suffix: str, global_name: str, default: float) -> float:
    return max(0.0, float(_route_env(env_prefix, suffix, global_name, default)))


def _default_max_attempts(env_prefix: str) -> int:
    return 1 if env_prefix == "DIRECT_AUTO_PLANNING" else 3


def _api_base_with_v1(api_base: str | None) -> str | None:
    if not api_base:
        return None
    base = api_base.rstrip("/")
    return base if base.endswith("/v1") else f"{base}/v1"


def _get_limiter(limiter_key: str, max_concurrency: int) -> asyncio.Semaphore:
    loop_id = id(asyncio.get_running_loop())
    key = (limiter_key, loop_id)
    current = _LIMITERS.get(key)
    if current is None or current[0] != max_concurrency:
        current = (max_concurrency, asyncio.Semaphore(max_concurrency))
        _LIMITERS[key] = current
    return current[1]


