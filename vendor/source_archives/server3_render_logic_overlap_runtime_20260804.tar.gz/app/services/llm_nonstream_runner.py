"""Backend/key failover runner for non-streaming LLM calls."""

import asyncio
import logging
from typing import Any

from app.services.llm_nonstream_attempt import execute_nonstream_attempt
from app.services.llm_nonstream_context import NonstreamAttemptContext

logger = logging.getLogger(__name__)


async def run_nonstream_call(
    manager: Any,
    *,
    messages: list,
    max_tokens: int,
    retry_budget: int,
    trace_call_type: str,
    trace_usage_context: dict | None,
    tracer: Any,
    deps: Any,
):
    backends = manager._ordered_backends()
    last_exc: BaseException | None = None
    attempts: list[dict[str, Any]] = []
    for global_attempt in range(retry_budget):
        consecutive_failures = 0
        current_max_tokens = min(
            max_tokens + global_attempt * 2000,
            deps.configured_max_tokens(),
        )
        truncation_backends: set[str] = set()
        for backend in backends:
            if backend.name in truncation_backends:
                continue
            cooldown_payload = manager._cooldown_payload(backend, trace_call_type)
            if cooldown_payload:
                logger.info(
                    "LLM backend skipped by model cooldown: backend=%s model=%s call_type=%s",
                    backend.name,
                    backend.model,
                    trace_call_type,
                )
                attempts.append(
                    manager._cooldown_attempt(
                        backend,
                        trace_call_type,
                        cooldown_payload,
                    )
                )
                last_exc = RuntimeError("model_backend_cooldown")
                continue
            key_index = 0
            while key_index < len(backend.keys):
                prompt_cache_kwargs = (
                    deps.responses_cache(trace_usage_context)
                    if backend.uses_responses_api
                    else {}
                )
                provider_extra_kwargs = deps.extra_kwargs(
                    backend,
                    call_type=trace_call_type,
                    trace_usage_context=trace_usage_context,
                )
                active_context = deps.with_cache_context(
                    trace_usage_context,
                    prompt_cache_kwargs,
                )
                active_context = deps.with_provider_policy(
                    active_context,
                    provider_extra_kwargs,
                )
                attempt_deps = deps.for_attempt(
                    prompt_cache_kwargs=prompt_cache_kwargs,
                    provider_extra_kwargs=provider_extra_kwargs,
                )
                outcome = await execute_nonstream_attempt(
                    manager,
                    NonstreamAttemptContext(
                        backend=backend,
                        key=backend.keys[key_index],
                        key_index=key_index,
                        messages=deps.messages_for_provider(messages, backend=backend),
                        max_tokens=current_max_tokens,
                        global_attempt=global_attempt,
                        retry_budget=retry_budget,
                        call_type=trace_call_type,
                        trace_usage_context=active_context,
                    ),
                    attempt_deps,
                )
                attempts.append(outcome.attempt)
                if outcome.action == "success":
                    await manager._record_trace_attempts(tracer, attempts)
                    manager._mark_success(
                        backend.name,
                        model=backend.model,
                        call_type=trace_call_type,
                    )
                    return outcome.response, backend.name
                last_exc = outcome.exception
                if outcome.action == "local_cancel":
                    await manager._record_trace_attempts(tracer, attempts)
                    raise outcome.exception
                if outcome.truncated:
                    truncation_backends.add(backend.name)
                    break
                force = outcome.action == deps.next_backend and not isinstance(
                    outcome.exception,
                    deps.empty_response_error,
                )
                manager._mark_transient_failure(
                    backend,
                    outcome.exception,
                    call_type=trace_call_type,
                    force=force,
                )
                consecutive_failures += 1
                logger.warning(
                    "LLM error: backend=%s, key_index=%s, action=%s, consecutive_fails=%s, err=%s",
                    backend.name,
                    key_index,
                    outcome.action,
                    consecutive_failures,
                    outcome.exception,
                )
                if consecutive_failures >= 3:
                    await asyncio.sleep(min(2 ** (consecutive_failures - 3), 8))
                if outcome.action == deps.fail_fast:
                    await manager._record_trace_attempts(tracer, attempts)
                    raise outcome.exception
                if outcome.action == deps.next_key:
                    key_index += 1
                    continue
                break
        if global_attempt < retry_budget - 1:
            await asyncio.sleep(2**global_attempt)
    await manager._record_trace_attempts(tracer, attempts)
    raise last_exc or Exception("所有重试均失败")
