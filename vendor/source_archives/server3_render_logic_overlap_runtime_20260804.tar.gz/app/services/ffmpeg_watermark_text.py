"""Text watermark helpers and renderer."""
import logging
import os
from typing import Any, Callable

logger = logging.getLogger(__name__)
_AUDIO_FILTER = "aresample=async=1:first_pts=0,apad"
facade_provider: Callable[[], Any] | None = None

def _clamp_opacity(value: Any, default: float) -> float:
    try:
        opacity = float(value)
    except (TypeError, ValueError):
        return default
    return min(max(opacity, 0.0), 1.0)


def _positive_int(value: Any, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def _positive_float(value: Any, default: float) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def _render_base_dir() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(__file__)))


def _resolve_watermark_image_path(value: Any, default_filename: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        raw = default_filename
    if os.path.isabs(raw):
        return raw
    base_dir = _render_base_dir()
    if raw.startswith("assets/"):
        return os.path.join(base_dir, raw)
    return os.path.join(base_dir, "assets", "watermarks", raw)


def _overlay_position(position: str, margin: int) -> str:
    position_map = {
        "bottom_right": f"W-w-{margin}:H-h-{margin}",
        "bottom_left": f"{margin}:H-h-{margin}",
        "top_right": f"W-w-{margin}:{margin}",
        "top_left": f"{margin}:{margin}",
    }
    return position_map.get(position, position_map["bottom_right"])


def _escape_drawtext_value(value: str) -> str:
    return (
        str(value)
        .replace("\\", "\\\\")
        .replace("'", r"\'")
        .replace(":", r"\:")
        .replace("%", r"\%")
    )


def _drawtext_fontfile() -> str | None:
    for path in (
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/truetype/arphic/uming.ttc",
        "/usr/share/fonts/Adwaita/AdwaitaSans-Regular.ttf",
    ):
        if os.path.exists(path):
            return path
    return None


def _drawtext_position(position: str, margin: int) -> tuple[str, str]:
    position_map = {
        "bottom_right": (f"w-tw-{margin}", f"h-th-{margin}"),
        "bottom_left": (str(margin), f"h-th-{margin}"),
        "top_right": (f"w-tw-{margin}", str(margin)),
        "top_left": (str(margin), str(margin)),
    }
    return position_map.get(position, position_map["bottom_right"])


async def draw_text_watermark(
    *,
    input_bytes: bytes,
    output_dir: str,
    job_id: str,
    text: str,
    opacity: float = 0.72,
    margin: int = 24,
    position: str = "bottom_right",
) -> bytes:
    """对视频叠加固定文本水印，返回处理后的字节流。"""
    os.makedirs(output_dir, exist_ok=True)
    tmp_input = os.path.join(output_dir, f"video_{job_id}_text_raw.mp4")
    tmp_output = os.path.join(output_dir, f"video_{job_id}_text_wm.mp4")
    try:
        with open(tmp_input, "wb") as f:
            f.write(input_bytes)

        safe_text = _escape_drawtext_value(text or "AI合成")
        safe_opacity = _clamp_opacity(opacity, 0.72)
        safe_margin = _positive_int(margin, 24)
        x_pos, y_pos = _drawtext_position(str(position or ""), safe_margin)
        fontfile = _drawtext_fontfile()
        fontfile_part = f"fontfile='{fontfile}':" if fontfile else ""
        vf = (
            "drawtext="
            f"{fontfile_part}"
            f"text='{safe_text}':"
            f"fontcolor=white@{safe_opacity:.2f}:"
            "fontsize=max(18\\,h*0.035):"
            "box=1:"
            "boxcolor=black@0.36:"
            "boxborderw=8:"
            f"x={x_pos}:"
            f"y={y_pos},"
            "format=yuv420p"
        )
        cmd = [
            "ffmpeg",
            "-i",
            tmp_input,
            "-vf",
            vf,
            "-map",
            "0:v:0",
            "-map",
            "0:a:0?",
            "-af",
            _AUDIO_FILTER,
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "18",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-b:a",
            "128k",
            "-ar",
            "48000",
            "-ac",
            "2",
            "-shortest",
            "-movflags",
            "+faststart",
            "-max_muxing_queue_size",
            "1024",
            "-avoid_negative_ts",
            "make_zero",
            tmp_output,
            "-y",
        ]
        cp = await facade_provider().run_cmd_async(cmd, timeout=180)
        if cp.returncode != 0:
            raise Exception(
                "FFmpeg text watermark failed: "
                f"{cp.stderr[:300] if cp.stderr else 'unknown'}"
            )

        with open(tmp_output, "rb") as f:
            result = f.read()

        logger.info(
            f"[TEXT_WATERMARK] [{facade_provider()._ts()}] 文本水印叠加完成, "
            f"大小={len(result) / 1024 / 1024:.2f}MB"
        )
        return result
    finally:
        for p in [tmp_input, tmp_output]:
            try:
                os.remove(p)
            except OSError:
                pass
