"""Data contracts for one non-streaming LLM attempt."""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class NonstreamAttemptContext:
    backend: Any
    key: str
    key_index: int
    messages: list
    max_tokens: int
    global_attempt: int
    retry_budget: int
    call_type: str
    trace_usage_context: dict | None


@dataclass
class NonstreamAttemptOutcome:
    action: str
    attempt: dict[str, Any]
    response: Any = None
    exception: BaseException | None = None
    truncated: bool = False
