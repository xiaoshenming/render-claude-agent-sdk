"""LLM 生成函数 — 公共 API（generate_manim_code 等）"""
# ruff: noqa: F401  # Preserve public and monkeypatch compatibility imports.

import logging
from typing import AsyncGenerator, Optional, Tuple

import litellm

from app.core.config import settings
from app.prompts.common import generation_color_prompt
from app.prompts.prompt_factory import get_prompt_template
from app.prompts.prompt_compiler import PromptCompileInput
from app.enterprise_delivery.runtime_context import (
    apply_enterprise_prompt_trace_overlay,
)
from app.enterprise_delivery.llm_request_archive import (
    build_enterprise_llm_request_archive,
)
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services.llm_generation_contracts import (
    _block_first_assembly_enabled, _messages_for_compiled_prompt,
    _mgr, _no_template_assembly_enabled, _prompt_compiler_for_skill_context,
    _provider_cache_messages_enabled, _trace_usage_context_for_compiled_prompt,
    configured_max_output_tokens, extract_usage_details,
)
from app.services.llm_generation_two_phase import (
    _strip_duplicate_definitions,
    generate_outline,
    generate_single_scene,
)

logger = logging.getLogger(__name__)

async def generate_manim_code(
    provider: str,
    user_prompt: str,
    color_scheme: int,
    enable_tts: bool = False,
    tts_voice: str = "longxiaoxia_v3",
    voice_type: str = "system",
    cosyvoice_id: str = "",
    aspect_ratio: str = "16:9",
    max_retries: int | None = None,
    job_id: Optional[str] = None,
    selected_skills: list[str] | None = None,
    usage_collector: dict | None = None,
    planned_scene_count: int | None = None,
    minimum_scene_count: int | None = None,
    planned_scenes: list[dict] | None = None,
    skill_context: dict | None = None,
) -> Tuple[str, float, int]:
    """生成 Manim 代码（支持多 backend 主备切换）"""
    user_prompt = guard_ai_user_input(user_prompt, scenario="render_generate")

    retry_budget = (
        max_retries if max_retries is not None else settings.LLM_MAX_RETRIES
    )

    color_code = generation_color_prompt(
        color_scheme,
        skill_context=skill_context,
    )

    compile_result = _prompt_compiler_for_skill_context(
        skill_context
    ).compile_legacy_generation_prompt(
        PromptCompileInput(
            provider=provider,
            user_prompt=user_prompt,
            color_code=color_code,
            enable_tts=enable_tts,
            tts_voice=tts_voice,
            voice_type=voice_type,
            cosyvoice_id=cosyvoice_id,
            aspect_ratio=aspect_ratio,
            selected_skills=selected_skills,
            planned_scene_count=planned_scene_count,
            minimum_scene_count=minimum_scene_count,
            planned_scenes=planned_scenes,
            skill_context=skill_context,
            include_skill_prompt_blocks=bool(
                getattr(settings, "RENDER_SKILL_OS_INJECT_SKILL_BLOCKS", False)
            ),
            block_first_assembly=_block_first_assembly_enabled(),
            no_template_assembly=_no_template_assembly_enabled(),
        )
    )
    prompt_content = compile_result.prompt_content
    apply_enterprise_prompt_trace_overlay(
        compile_result.prompt_segments,
        compile_result.cache_metrics,
        skill_context,
    )
    trace_usage_context = _trace_usage_context_for_compiled_prompt(compile_result)
    messages = _messages_for_compiled_prompt(compile_result)
    llm_request_archive = build_enterprise_llm_request_archive(
        messages=messages,
        provider=provider,
        job_id=job_id,
        compile_result=compile_result,
        skill_context=skill_context,
    )
    if usage_collector is not None:
        usage_collector["prompt_segments"] = compile_result.prompt_segments
        usage_collector["cache_metrics"] = trace_usage_context["cache_metrics"]
        usage_collector["prompt_firewall"] = compile_result.firewall_report
        if llm_request_archive is not None:
            usage_collector["llm_request_messages"] = llm_request_archive

    response, backend_name = await _mgr().call(
        messages=messages,
        max_tokens=configured_max_output_tokens(),
        retry_budget=retry_budget,
        trace_job_id=job_id or "unknown",
        trace_call_type="generate",
        trace_prompt_version=provider,
        trace_prompt_content=prompt_content,
        trace_usage_context=trace_usage_context,
    )

    content = guard_ai_output(
        response.choices[0].message.content or "",
        scenario="render_manim_code_output",
    )
    finish_reason = getattr(response.choices[0], 'finish_reason', None)
    if finish_reason == "length":
        logger.warning(
            f"[generate_manim_code] LLM 输出因 max_tokens 截断! "
            f"backend={backend_name}, content_len={len(content)}")

    # 计算成本
    try:
        cost = litellm.completion_cost(completion_response=response)
    except Exception:
        cost = 0.0

    # 统计 token（详细）
    usage_info = extract_usage_details(response)
    tokens = usage_info["total_tokens"]
    if usage_collector is not None:
        usage_collector.update(usage_info)

    logger.info(
        f"LLM 生成成功: backend={backend_name}, len={len(content)}, "
        f"tokens={tokens} (in={usage_info['input_tokens']}, "
        f"out={usage_info['output_tokens']}, "
        f"cache_read={usage_info['cache_read_tokens']}, "
        f"cache_create={usage_info['cache_creation_tokens']})")
    return content, cost, tokens


async def generate_manim_code_stream(
    provider: str,
    user_prompt: str,
    color_scheme: int,
    enable_tts: bool = False,
    tts_voice: str = "longxiaoxia_v3",
    voice_type: str = "system",
    cosyvoice_id: str = "",
    aspect_ratio: str = "16:9",
    job_id: Optional[str] = None,
    usage_collector: dict = None,
    max_tokens: int | None = None,
    excluded_backend_names: set[str] | list[str] | tuple[str, ...] | None = None,
    attempt_collector: list[dict] | None = None,
    selected_skills: list[str] | None = None,
    planned_scene_count: int | None = None,
    minimum_scene_count: int | None = None,
    planned_scenes: list[dict] | None = None,
    skill_context: dict | None = None,
) -> AsyncGenerator[str, None]:
    """流式生成 Manim 代码。usage_collector 可选，流结束后写入 token 统计。"""
    user_prompt = guard_ai_user_input(user_prompt, scenario="render_generate_stream")

    color_code = generation_color_prompt(
        color_scheme,
        skill_context=skill_context,
    )

    compile_result = _prompt_compiler_for_skill_context(
        skill_context
    ).compile_legacy_generation_prompt(
        PromptCompileInput(
            provider=provider,
            user_prompt=user_prompt,
            color_code=color_code,
            enable_tts=enable_tts,
            tts_voice=tts_voice,
            voice_type=voice_type,
            cosyvoice_id=cosyvoice_id,
            aspect_ratio=aspect_ratio,
            selected_skills=selected_skills,
            planned_scene_count=planned_scene_count,
            minimum_scene_count=minimum_scene_count,
            planned_scenes=planned_scenes,
            skill_context=skill_context,
            include_skill_prompt_blocks=bool(
                getattr(settings, "RENDER_SKILL_OS_INJECT_SKILL_BLOCKS", False)
            ),
            block_first_assembly=_block_first_assembly_enabled(),
            no_template_assembly=_no_template_assembly_enabled(),
        )
    )
    prompt_content = compile_result.prompt_content
    apply_enterprise_prompt_trace_overlay(
        compile_result.prompt_segments,
        compile_result.cache_metrics,
        skill_context,
    )

    messages = _messages_for_compiled_prompt(compile_result)
    trace_usage_context = _trace_usage_context_for_compiled_prompt(compile_result)
    stream_usage = usage_collector if usage_collector is not None else {}
    stream_usage["prompt_segments"] = compile_result.prompt_segments
    stream_usage["cache_metrics"] = trace_usage_context["cache_metrics"]
    stream_usage["prompt_firewall"] = compile_result.firewall_report
    llm_request_archive = build_enterprise_llm_request_archive(
        messages=messages,
        provider=provider,
        job_id=job_id,
        compile_result=compile_result,
        skill_context=skill_context,
    )
    if llm_request_archive is not None:
        stream_usage["llm_request_messages"] = llm_request_archive

    async for chunk in _mgr().call_stream(
        messages=messages,
        max_tokens=max_tokens if max_tokens is not None else configured_max_output_tokens(),
        retry_budget=int(getattr(settings, "LLM_STREAM_RETRY_BUDGET", 3) or 3),
        usage_collector=stream_usage,
        trace_job_id=job_id or "unknown",
        trace_call_type="generate_stream",
        trace_prompt_version=provider,
        trace_prompt_content=prompt_content,
        trace_usage_context=trace_usage_context,
        attempt_collector=attempt_collector,
        excluded_backend_names=excluded_backend_names,
    ):
        guard_ai_output(chunk, scenario="render_manim_stream_output")
        yield chunk


# ---------------------------------------------------------------------------
# Two-phase generation helpers
# ---------------------------------------------------------------------------
