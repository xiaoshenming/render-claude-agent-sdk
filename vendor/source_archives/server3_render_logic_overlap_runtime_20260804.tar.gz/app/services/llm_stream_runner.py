"""Backend/key failover runner for buffered streaming LLM calls."""

import asyncio
import logging
from typing import Any, AsyncGenerator

from app.services.llm_stream_attempt import execute_stream_attempt
from app.services.llm_stream_context import StreamAttemptContext

logger = logging.getLogger(__name__)


def _excluded_attempt(backend: Any, call_type: str, round_index: int, now: Any) -> dict:
    return {
        "backend_name": backend.name,
        "model": backend.model,
        "success": False,
        "latency_ms": 0,
        "error_type": "BackendSemanticRetryExcluded",
        "error_message": "semantic_retry_excluded_backend",
        "usage_info": {
            "backend_skip_reason": "semantic_retry_excluded_backend",
            "call_type": call_type,
            "retry_count": round_index,
            "attempt_round": round_index + 1,
        },
        "started_at": now,
        "ended_at": now,
    }


def _apply_attempt_context(
    usage: dict,
    prompt_cache_kwargs: dict,
    quality_context: dict | None,
) -> None:
    if isinstance(quality_context, dict):
        for key in (
            "quality_multimodal_provider_extra_body",
            "quality_multimodal_reasoning_control",
        ):
            if key in quality_context:
                usage[key] = quality_context[key]
    if prompt_cache_kwargs:
        cache_metrics = dict(usage.get("cache_metrics") or {})
        cache_metrics.update(
            provider_cache_api="openai_responses",
            provider_prompt_cache_key=prompt_cache_kwargs.get("prompt_cache_key"),
            provider_prompt_cache_retention=prompt_cache_kwargs.get(
                "prompt_cache_retention"
            ),
        )
        usage["cache_metrics"] = cache_metrics


async def run_stream_call(
    manager: Any,
    *,
    messages: list,
    max_tokens: int,
    retry_budget: int,
    usage: dict,
    trace_collector: dict | None,
    attempts: list[dict],
    tracer: Any,
    trace_call_type: str,
    trace_usage_context: dict | None,
    excluded_backend_names: Any,
    deps: Any,
) -> AsyncGenerator[str, None]:
    try:
        max_rounds = max(1, int(retry_budget or 1))
    except (TypeError, ValueError):
        max_rounds = 1
    excluded = {str(name) for name in (excluded_backend_names or ()) if str(name).strip()}
    last_exc: BaseException | None = None
    for global_attempt in range(max_rounds):
        current_max_tokens = min(
            max_tokens + global_attempt * 2000,
            deps.configured_max_tokens(),
        )
        for backend in manager._ordered_backends():
            if backend.name in excluded:
                logger.info(
                    "LLM stream backend skipped for semantic retry: backend=%s "
                    "model=%s call_type=%s",
                    backend.name,
                    backend.model,
                    trace_call_type,
                )
                now = deps.now()
                attempts.append(
                    _excluded_attempt(backend, trace_call_type, global_attempt, now)
                )
                last_exc = RuntimeError("semantic_retry_excluded_backend")
                continue
            cooldown = manager._cooldown_payload(backend, trace_call_type)
            if cooldown:
                usage["backend_cooldown_skip_count"] = int(
                    usage.get("backend_cooldown_skip_count", 0) or 0
                ) + 1
                record = manager._cooldown_attempt(backend, trace_call_type, cooldown)
                record["usage_info"] = {
                    **record.get("usage_info", {}),
                    "retry_count": global_attempt,
                    "attempt_round": global_attempt + 1,
                }
                attempts.append(record)
                last_exc = RuntimeError("model_backend_cooldown")
                continue
            key_index = 0
            while key_index < len(backend.keys):
                cache_kwargs = (
                    deps.responses_cache(trace_usage_context)
                    if backend.uses_responses_api
                    else {}
                )
                extra_kwargs = deps.extra_kwargs(
                    backend,
                    call_type=trace_call_type,
                    trace_usage_context=trace_usage_context,
                )
                quality_context = deps.with_provider_policy(
                    trace_usage_context,
                    extra_kwargs,
                )
                _apply_attempt_context(
                    usage,
                    cache_kwargs,
                    quality_context,
                )
                outcome = await execute_stream_attempt(
                    manager,
                    StreamAttemptContext(
                        backend=backend,
                        key=backend.keys[key_index],
                        key_index=key_index,
                        messages=deps.messages_for_provider(messages, backend=backend),
                        max_tokens=current_max_tokens,
                        global_attempt=global_attempt,
                        max_rounds=max_rounds,
                        call_type=trace_call_type,
                        prompt_cache_kwargs=cache_kwargs,
                        provider_extra_kwargs=extra_kwargs,
                    ),
                    usage,
                    trace_collector,
                    deps,
                )
                attempts.append(outcome.attempt)
                if outcome.action == "success":
                    await manager._record_trace_attempts(tracer, attempts)
                    if usage.get("stream_missing_terminal_event"):
                        logger.info(
                            "LLM stream missing terminal event accepted without sticky "
                            "success: backend=%s model=%s call_type=%s",
                            backend.name,
                            backend.model,
                            trace_call_type,
                        )
                    else:
                        manager._mark_success(
                            backend.name,
                            model=backend.model,
                            call_type=trace_call_type,
                        )
                    for chunk in outcome.chunks:
                        yield chunk
                    return
                last_exc = outcome.exception
                if outcome.action == "local_cancel":
                    await manager._record_trace_attempts(tracer, attempts)
                    raise outcome.exception
                force = outcome.action == deps.next_backend and not isinstance(
                    outcome.exception,
                    deps.empty_response_error,
                )
                manager._mark_transient_failure(
                    backend,
                    outcome.exception,
                    call_type=trace_call_type,
                    force=force,
                )
                if outcome.chunks:
                    logger.warning(
                        "LLM stream discarded buffered partial content: backend=%s chunks=%s",
                        backend.name,
                        len(outcome.chunks),
                    )
                if outcome.action == deps.fail_fast:
                    await manager._record_trace_attempts(tracer, attempts)
                    raise outcome.exception
                if outcome.action == deps.next_key:
                    key_index += 1
                    continue
                break
        if global_attempt < max_rounds - 1:
            await asyncio.sleep(min(2**global_attempt, 8))
    await manager._record_trace_attempts(tracer, attempts)
    raise last_exc or Exception("所有 stream 重试均失败")
