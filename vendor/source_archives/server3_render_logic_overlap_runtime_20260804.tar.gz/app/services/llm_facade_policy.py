"""Small configuration-sensitive helpers used by the LLM compatibility facade."""

import json
from datetime import datetime, timedelta, timezone
from typing import Any

LITELLM_PROTOCOLS = {"openai", "anthropic", "gemini"}
DEFAULT_MAX_OUTPUT_TOKENS = 65536
BEIJING_TZ = timezone(timedelta(hours=8))


def beijing_now() -> datetime:
    return datetime.now(BEIJING_TZ)


def configured_max_output_tokens(config: Any) -> int:
    value = getattr(config, "LLM_MAX_OUTPUT_TOKENS", DEFAULT_MAX_OUTPUT_TOKENS)
    return max(1, int(value or DEFAULT_MAX_OUTPUT_TOKENS))


def truthy_setting(config: Any, name: str, default: bool = False) -> bool:
    value = getattr(config, name, default)
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def compose_backend_model(protocol: str | None, model: str) -> str:
    raw_model = str(model or "").strip()
    if "/" in raw_model:
        prefix, rest = raw_model.split("/", 1)
        if prefix in LITELLM_PROTOCOLS and rest:
            return raw_model
    protocol = str(protocol or "").strip()
    return f"{protocol}/{raw_model}" if protocol in LITELLM_PROTOCOLS and raw_model else raw_model


def messages_to_prompt_content(messages: list) -> str:
    parts = []
    for message in messages or []:
        if isinstance(message, dict):
            role, content = message.get("role", ""), message.get("content", "")
        else:
            role = getattr(message, "role", "")
            content = getattr(message, "content", "")
        if not isinstance(content, str):
            try:
                content = json.dumps(content, ensure_ascii=False, sort_keys=True)
            except Exception:
                content = str(content)
        parts.append(f"{role}:{content}")
    return "\n\n".join(parts)


def should_retry_with_high_reasoning(
    exc: Exception, request_kwargs: dict, fallback_effort: str
) -> bool:
    effort = str((request_kwargs.get("reasoning") or {}).get("effort", "")).lower()
    if not effort or effort == fallback_effort:
        return False
    text = str(exc).lower()
    return effort in text and any(
        marker in text
        for marker in ("reasoning", "effort", "invalid", "unsupported", "not supported")
    )


def with_high_reasoning(request_kwargs: dict, fallback_effort: str) -> dict:
    fallback = dict(request_kwargs)
    reasoning = dict(fallback.get("reasoning") or {})
    reasoning["effort"] = fallback_effort
    if fallback_effort != "none":
        reasoning.setdefault("summary", "detailed")
    fallback["reasoning"] = reasoning
    return fallback
