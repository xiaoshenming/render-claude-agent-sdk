"""LLM 调用追踪器 — 记录每次 LLM API 调用的完整链路信息。
集成方式：在 llm_service._LLMManager.call() / call_stream() 完成后调用。
元数据写入 llm_call_logs 表；脱敏输入/输出 transcript 稳定写入
llm_transcript_artifacts，Elasticsearch/OpenSearch 作为可检索 raw trace。
"""
import hashlib
import json
import logging
import os
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from app.core.config import settings
from sqlalchemy import text
from app.core.structured_logging import get_log_context
from app.database.database import AsyncSessionLocal
from app.services.llm_trace_text_helpers import (
    redact_text, exception_summary, redact_mapping, coerce_messages,
    messages_to_text, messages_for_es_index, trace_content_hash, iso,
    trace_max_text_chars, truncate_text,
)
from app.services.llm_trace_value_helpers import (
    bounded_identifier, hash_prompt, hash_text, slug, is_retryable,
    json_param, json_nullable_param, dict_or_empty,
)
from app.services.llm_trace_security_helpers import (
    redact_transcript_text, quality_error_code, is_retryable_error,
)
from app.services.llm_trace_usage_helpers import (
    artifact_selected_skills as _artifact_selected_skills,
    artifact_skill_block_refs as _artifact_skill_block_refs,
    safe_prompt_segments as _safe_prompt_segments,
)
try:
    import httpx
except Exception:  # pragma: no cover - httpx is present in runtime images
    httpx = None
logger = logging.getLogger(__name__)
BEIJING_TZ = timezone(timedelta(hours=8))
MESSAGE_TRACE_INDEX = "mathpi-llm-message-traces"
MESSAGE_TRACE_MAX_TEXT_CHARS = 200_000
REDACTION_VERSION = "redaction.v1"
TRANSCRIPT_RETENTION_POLICY = "standard"
_bounded_identifier = bounded_identifier
_hash_prompt = hash_prompt
_hash_text = hash_text
_redact_transcript_text = redact_transcript_text
_slug = slug
_json_param = json_param
_json_nullable_param = json_nullable_param
_dict_or_empty = dict_or_empty
_redact_text = redact_text
_redact_mapping = redact_mapping
_coerce_messages = coerce_messages
_messages_to_text = messages_to_text
_messages_for_es_index = messages_for_es_index
_trace_content_hash = trace_content_hash
_iso = iso
_exception_summary = exception_summary
async def index_llm_message_trace(document: dict) -> dict[str, str | None]:
    """Best-effort Elasticsearch/OpenSearch indexing for message transcripts."""
    url = str(_config_value("LLM_MESSAGE_TRACE_ES_URL", "") or "").strip().rstrip("/")
    if not url:
        return {"status": "skipped", "document_id": None, "error_message": None}
    if httpx is None:
        return {
            "status": "failed",
            "document_id": None,
            "error_message": "httpx unavailable",
        }
    index_name = (
        _config_value("LLM_MESSAGE_TRACE_ES_INDEX", "")
        or os.getenv("ELASTICSEARCH_LLM_MESSAGE_TRACE_INDEX")
        or MESSAGE_TRACE_INDEX
    )
    index_name = str(index_name).strip()
    document_id = str(document.get("id") or uuid.uuid4())
    timeout = float(_config_value("LLM_MESSAGE_TRACE_ES_TIMEOUT", 2.0) or 2.0)
    headers = {"Content-Type": "application/json"}
    api_key = str(_config_value("LLM_MESSAGE_TRACE_ES_API_KEY", "") or "").strip()
    if api_key:
        headers["Authorization"] = f"ApiKey {api_key}"
    auth = None
    username = str(_config_value("LLM_MESSAGE_TRACE_ES_USERNAME", "") or "").strip()
    password = str(_config_value("LLM_MESSAGE_TRACE_ES_PASSWORD", "") or "").strip()
    if username or password:
        auth = (username, password)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.put(
                f"{url}/{index_name}/_doc/{document_id}",
                headers=headers,
                auth=auth,
                json=document,
            )
            response.raise_for_status()
        return {
            "status": "indexed",
            "document_id": document_id,
            "error_message": None,
        }
    except Exception as exc:
        error_message = _exception_summary(exc)
        logger.warning("[LLM_TRACE] ES index failed: %s", error_message)
        return {
            "status": "failed",
            "document_id": document_id,
            "error_message": error_message,
        }
async def mark_latest_llm_call_semantic_rejected(
    *,
    job_id: str,
    backend_name: str | None = None,
    model: str | None = None,
    call_type: str = "generate_stream",
    error_type: str,
    error_message: str,
    quality_result: str = "agent_semantic_rejected",
) -> str | None:
    """Best-effort post-hoc semantic status update for buffered streams."""
    if not job_id:
        return None
    try:
        session = AsyncSessionLocal()
        try:
            filters = [
                "job_id = :job_id",
                "call_type = :call_type",
                "success = 1",
            ]
            params: dict[str, Any] = {
                "job_id": job_id,
                "call_type": call_type,
            }
            if backend_name:
                filters.append("backend_name = :backend_name")
                params["backend_name"] = backend_name
            if model:
                filters.append("model = :model")
                params["model"] = model
            row = (
                await session.execute(
                    text(
                        "SELECT id FROM llm_call_logs "
                        f"WHERE {' AND '.join(filters)} "
                        "ORDER BY COALESCE(ended_at, created_at) DESC "
                        "LIMIT 1"
                    ),
                    params,
                )
            ).first()
            if not row:
                return None
            call_log_id = str(row[0])
            await session.execute(
                text(
                    "UPDATE llm_call_logs "
                    "SET quality_result = :quality_result, "
                    "error_type = :error_type, "
                    "error_message = :error_message "
                    "WHERE id = :id"
                ),
                {
                    "id": call_log_id,
                    "quality_result": quality_result[:50],
                    "error_type": error_type[:50],
                    "error_message": error_message[:2000],
                },
            )
            await session.commit()
            return call_log_id
        finally:
            await session.close()
    except Exception as exc:
        logger.warning(
            "[LLM_TRACE] semantic status update failed: job_id=%s error=%s",
            job_id,
            _exception_summary(exc),
        )
        return None
from app.services.llm_trace_helpers import (
    _config_value, _generate_request_id, _quality_error_code, _is_retryable, _safe_prompt_segments_for_log, _cache_metrics_for_log, _prompt_firewall_for_log, _metric_value, _render_skill_os_usage_summary, _provider_usage_raw_with_render_skill_os, _string_or_none, _int_or_zero, _trace_max_text_chars, _truncate_text,
)
class LLMCallTracer:
    """LLM 调用追踪器 — 上下文管理器风格"""
    def __init__(
        self,
        job_id: str,
        call_type: str = "generate",
        prompt_version: Optional[str] = None,
        trace_id: Optional[str] = None,
        attempt_id: Optional[str] = None,
        retry_count: int = 0,
        response_format: Optional[str] = None,
    ):
        context = get_log_context()
        self.job_id = (
            job_id
            if job_id and job_id != "unknown"
            else (context.get("job_id") or "unknown")
        )
        self.call_type = call_type
        self.prompt_version = prompt_version
        self.request_id = _bounded_identifier(
            context.get("request_id") or _generate_request_id(),
            max_length=36,
            default=_generate_request_id(),
        )
        self.trace_id = _bounded_identifier(
            trace_id or context.get("trace_id") or None,
            max_length=64,
        )
        self.attempt_id = _bounded_identifier(
            attempt_id or context.get("attempt_id") or None,
            max_length=64,
        )
        self.retry_count = _int_or_zero(retry_count)
        self.response_format = response_format
        self._start_time: float = 0
        self._started_at_wall: datetime | None = None
        self._prompt_hash: Optional[str] = None
        self._prompt_content: Optional[str] = None
        self._request_messages: list[dict] = []
    def set_prompt_hash(self, prompt_content: str) -> None:
        self._prompt_content = prompt_content
        self._prompt_hash = _hash_prompt(prompt_content)
    def set_request_messages(self, messages: list) -> None:
        self._request_messages = _coerce_messages(messages)
    def start(self) -> str:
        """开始计时，返回 request_id"""
        self._start_time = time.monotonic()
        self._started_at_wall = datetime.now(BEIJING_TZ)
        return self.request_id
    def elapsed_ms(self) -> int:
        if self._start_time == 0:
            return 0
        return int((time.monotonic() - self._start_time) * 1000)
    async def record_success(self, *args, **kwargs):
        from app.services.llm_call_tracer_persistence import record_success as _impl
        return await _impl(self, *args, **kwargs)
    async def record_failure(self, *args, **kwargs):
        from app.services.llm_call_tracer_persistence import record_failure as _impl
        return await _impl(self, *args, **kwargs)
    async def record_attempts(self, *args, **kwargs):
        from app.services.llm_call_tracer_persistence import record_attempts as _impl
        return await _impl(self, *args, **kwargs)
    async def _write_log(self, *args, **kwargs):
        from app.services.llm_call_tracer_persistence_io import _write_log as _impl
        return await _impl(self, *args, **kwargs)
    async def _write_transcript_artifact(self, *args, **kwargs):
        from app.services.llm_call_tracer_persistence_io import _write_transcript_artifact as _impl
        return await _impl(self, *args, **kwargs)
    async def _index_message_trace(self, *args, **kwargs):
        from app.services.llm_trace_indexing import _index_message_trace as _impl
        return await _impl(self, *args, **kwargs)
