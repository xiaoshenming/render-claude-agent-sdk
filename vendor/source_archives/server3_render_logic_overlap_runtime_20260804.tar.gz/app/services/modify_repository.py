"""modify_repository — 修改任务数据库操作。

从 video_worker.py 提取的 modify 任务 SUCCESS 写入逻辑。
"""
import logging
from datetime import datetime

from sqlalchemy import text

from app.database.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]



# ─────────────────────────── Modify 写入 ───────────────────────────

async def get_job_source_slices(source_job_id: str) -> list[dict]:
    """Load source slices for a modify task by source generation job id."""
    if not source_job_id:
        return []

    session = AsyncSessionLocal()
    try:
        result = await session.execute(text("""
            SELECT
                slice_index,
                scene_name,
                slice_code,
                video_url,
                duration
            FROM video_slices
            WHERE job_id = :job_id
            ORDER BY slice_index
        """), {"job_id": source_job_id})
        return [dict(row) for row in result.mappings().all()]
    finally:
        await session.close()


def _build_slice_success_updates(
    modified_results: dict = None,
    source_slices: list = None,
) -> list[dict]:
    """构造修改任务成功后需要写回 SUCCESS 的切片数据。

    修改任务允许部分切片修改失败并降级复用源视频。最终拼接成功时，
    这些降级切片对应的 DB 行仍是 API 创建时的 PENDING 状态，也必须
    写回源切片的 code/url/duration。
    """
    updates_by_index = {}

    for source in source_slices or []:
        idx = source.get("slice_index")
        if idx is None:
            continue
        updates_by_index[int(idx)] = {
            "idx": int(idx),
            "code": source.get("slice_code") or "",
            "url": source.get("video_url") or "",
            "duration": source.get("duration") or 0,
        }

    for idx, mod_data in (modified_results or {}).items():
        updates_by_index[int(idx)] = {
            "idx": int(idx),
            "code": mod_data.get("code", ""),
            "url": mod_data.get("url", ""),
            "duration": mod_data.get("duration", 0),
        }

    return [
        updates_by_index[idx]
        for idx in sorted(updates_by_index)
    ]


async def update_modify_success(
    job_id: str,
    user_id: str,
    video_url: str,
    code_url: str,
    parent_video_id: str,
    version: int,
    total_tokens: int = 0,
    llm_fix_count: int = 0,
    render_fix_count: int = 0,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    aigc_clean_video_url: str | None = None,
    aigc_watermarked_video_url: str | None = None,
    aigc_display_variant: str | None = None,
    aigc_visible_watermark_applied: bool | None = None,
    aigc_metadata_injected: bool | None = None,
    modified_results: dict = None,
    source_slices: list = None,
    timeline_manifest: dict | None = None,
) -> bool:
    """修改任务完成 -> 创建新 Video + 更新 Job SUCCESS + 更新 slices。"""
    from app.services import internal_api_client

    slice_updates = _build_slice_success_updates(
        modified_results=modified_results,
        source_slices=source_slices,
    )
    api_result = await internal_api_client.complete_video_modify_success(
        job_id,
        {
            "user_id": user_id,
            "video_url": video_url,
            "code_url": code_url,
            "parent_video_id": parent_video_id or None,
            "version": version,
            "total_tokens": total_tokens,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_read_tokens": cache_read_tokens,
            "cache_creation_tokens": cache_creation_tokens,
            "llm_fix_count": llm_fix_count,
            "render_fix_count": render_fix_count,
            "aigc_clean_video_url": aigc_clean_video_url,
            "aigc_watermarked_video_url": aigc_watermarked_video_url,
            "aigc_display_variant": aigc_display_variant,
            "aigc_visible_watermark_applied": aigc_visible_watermark_applied,
            "aigc_metadata_injected": aigc_metadata_injected,
            "slices": [
                {
                    "slice_index": item["idx"],
                    "slice_code": item["code"],
                    "video_url": item["url"],
                    "duration": item["duration"],
                }
                for item in slice_updates
            ],
            "timeline_manifest": timeline_manifest,
        },
    )
    if api_result is True:
        logger.info(
            f"[DB] [{_ts()}] Modify success 已通过 internal API 写回: "
            f"job={job_id}")
        return True
    if api_result is False:
        logger.warning(
            f"[DB] [{_ts()}] Modify success internal API 终态保护跳过: "
            f"job={job_id}")
        return False
    raise RuntimeError(
        f"internal API complete_video_modify_success failed: job={job_id}"
    )
