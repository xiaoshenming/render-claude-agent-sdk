"""Classify LLM failures and decide backend cooldown eligibility."""

import re

from app.services.llm_stream_adapters import (
    LLMEmptyResponseError,
    LLMProviderCancelledError,
    LLMStreamIncompleteError,
    LLMStreamTimeoutError,
)


class ErrorAction:
    NEXT_KEY = "next_key"
    NEXT_BACKEND = "next_backend"
    FAIL_FAST = "fail_fast"


_NEXT_KEY = re.compile(
    r"(401|403|invalid.?api.?key|\bauth\b|authentication|permission.?denied|"
    r"unauthorized|invalid.?x-api-key|invalid.?grant|invalid.?token|expired.?token)",
    re.IGNORECASE,
)
_NEXT_BACKEND = re.compile(
    r"(timeout|timed?\s*out|connect|connection|network|\b5\d{2}\b|server.?error|"
    r"service.?unavailable|bad.?gateway|unsupported.?model|model.?not.?found|"
    r"deployment.?not.?found|route.?not.?found|does.?not.?exist|provider.?mismatch|"
    r"overloaded|capacity)",
    re.IGNORECASE,
)
_PROXY_PLATFORM = re.compile(
    r"(请别着急|compact.*clear|Claude\s*Code\s*客户端|no\s+Claude\s+account|"
    r"令牌状态不可用|No\s+available\s+channel\s+for\s+model|"
    r"temperature.*deprecated|invalid[_\s-]+argument|"
    r"(unsupported|unknown|invalid).{0,40}(parameter|param))",
    re.IGNORECASE,
)
_FAIL_FAST = re.compile(
    r"(content.?filter|content.?policy|safety|prompt.?too.?long|context.?length|"
    r"invalid.?request.?(?!.*model)|malformed|could.?not.?process)",
    re.IGNORECASE,
)
_TRANSIENT_COOLDOWN = re.compile(
    r"(Empty or invalid response from LLM endpoint|choices\s*[:=]\s*\[\]|"
    r"choices\"\s*:\s*\[\]|Error code:\s*525|unknown provider for model|"
    r"model_cooldown|cooling down|MidStreamFallbackError|stream_read_error|"
    r"bad_response_status_code|openai_error|Vertex_ai_betaException|stream.*closed|"
    r"GOAWAY|scanner_error|client_gone|context\s+cancell?ed|stream.*incomplete|"
    r"missing.*terminal)",
    re.IGNORECASE,
)
_GENERATION_VALIDATION = re.compile(
    r"(agent code-only generation produced (empty code|invalid Python|no Scene classes|"
    r"too few Scene classes|token truncated)|agent pre-render scan failed)",
    re.IGNORECASE,
)
_PERMANENT_UNAVAILABLE = re.compile(
    r"(No\s+available\s+channel\s+for\s+model|model[_\s.-]*not[_\s.-]*found|"
    r"unsupported.?model|unknown\s+provider\s+for\s+model|"
    r"Country,\s*region,\s*or\s*territory\s*not\s*supported|"
    r"insufficient[_\s.-]*user[_\s.-]*quota|remaining\s+quota\s+is\s+negative|"
    r"用户额度不足|余额不足)",
    re.IGNORECASE,
)


def classify_error(exc: Exception) -> str:
    message = str(exc)
    status = getattr(exc, "status_code", None)
    if _PROXY_PLATFORM.search(message):
        return ErrorAction.NEXT_BACKEND
    if status in (401, 403, 429) or _NEXT_KEY.search(message):
        return ErrorAction.NEXT_KEY
    if status is not None and 500 <= status < 600:
        return ErrorAction.NEXT_BACKEND
    if status in (400, 404) and not _NEXT_BACKEND.search(message):
        return ErrorAction.FAIL_FAST
    if _NEXT_BACKEND.search(message):
        return ErrorAction.NEXT_BACKEND
    if _FAIL_FAST.search(message):
        return ErrorAction.FAIL_FAST
    return ErrorAction.NEXT_BACKEND


def is_generation_validation_error(exc: Exception) -> bool:
    return bool(_GENERATION_VALIDATION.search(str(exc)))


def should_cooldown_backend(exc: Exception) -> bool:
    if is_generation_validation_error(exc):
        return False
    if isinstance(
        exc,
        (
            LLMEmptyResponseError,
            LLMStreamTimeoutError,
            LLMStreamIncompleteError,
            LLMProviderCancelledError,
        ),
    ):
        return True
    return bool(_TRANSIENT_COOLDOWN.search(str(exc)))


def is_permanent_backend_unavailable(exc: Exception) -> bool:
    return getattr(exc, "status_code", None) == 451 or bool(
        _PERMANENT_UNAVAILABLE.search(str(exc))
    )
