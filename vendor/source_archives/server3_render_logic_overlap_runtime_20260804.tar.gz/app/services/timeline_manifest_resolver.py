"""Validate and resolve canonical timeline manifests."""
# ruff: noqa: F403, F405
from collections.abc import Mapping, Sequence
from typing import Any
from app.services.timeline_manifest_core import *

FPS=30
MIN_DRIFT_THRESHOLD_SEC=0.25
_EPSILON=1e-6

def validate_duration_drift(
    manifest_or_slices: Mapping[str, Any] | Sequence[Mapping[str, Any]],
    final_duration_sec: float | None = None,
    *,
    fps: int = FPS,
    min_threshold_sec: float = MIN_DRIFT_THRESHOLD_SEC,
) -> dict[str, Any]:
    """Validate sum(slice.duration_sec) against final.duration_sec."""
    if isinstance(manifest_or_slices, Mapping):
        slices = _get(manifest_or_slices, "slices", default=[])
        final_duration = _first_float(manifest_or_slices.get("final") or {}, "duration_sec")
        if final_duration is None:
            final_duration = _nonnegative_float(final_duration_sec)
    else:
        slices = manifest_or_slices
        final_duration = _nonnegative_float(final_duration_sec)

    if not isinstance(slices, Sequence) or isinstance(slices, (str, bytes)):
        slices = []
    slice_total = sum(
        _nonnegative_float(_get(item, "duration_sec", "duration")) or 0.0
        for item in slices
    )
    slice_count = len(slices)
    threshold = max(
        float(min_threshold_sec),
        (2 / max(float(fps), 1.0)) * slice_count,
    )
    final_duration = final_duration if final_duration is not None else 0.0
    drift = abs(slice_total - final_duration)
    return {
        "ok": drift <= threshold + _EPSILON,
        "slice_total_duration_sec": _round_seconds(slice_total),
        "final_duration_sec": _round_seconds(final_duration),
        "drift_sec": _round_seconds(drift),
        "threshold_sec": _round_seconds(threshold),
        "slice_count": slice_count,
    }


def resolve_timestamp(
    manifest: Mapping[str, Any],
    timestamp_sec: float,
) -> dict[str, Any]:
    """Resolve a global timestamp to slice-local targeting metadata."""
    timestamp = _nonnegative_float(timestamp_sec)
    if timestamp is None:
        raise ValueError("timestamp_sec must be a nonnegative finite number")

    slices = list(_get(manifest, "slices", default=[]) or [])
    if not slices:
        raise ValueError("manifest has no slices")
    slices.sort(key=lambda item: _slice_index(item, 0))

    final_duration = _first_float(_get(manifest, "final", default={}), "duration_sec")
    target_slice = None
    if final_duration is not None and abs(timestamp - final_duration) <= _EPSILON:
        target_slice = slices[-1]
    else:
        for item in slices:
            start = _nonnegative_float(_get(item, "global_start_sec")) or 0.0
            end = _nonnegative_float(_get(item, "global_end_sec"))
            if end is None:
                duration = _nonnegative_float(_get(item, "duration_sec")) or 0.0
                end = start + duration
            if start <= timestamp < end:
                target_slice = item
                break
        if target_slice is None and final_duration is not None:
            last = slices[-1]
            last_end = _nonnegative_float(_get(last, "global_end_sec")) or 0.0
            if last_end <= timestamp <= final_duration + _EPSILON:
                target_slice = last

    if target_slice is None:
        raise ValueError("timestamp_sec is outside manifest timeline")

    slice_start = _nonnegative_float(_get(target_slice, "global_start_sec")) or 0.0
    slice_duration = _nonnegative_float(_get(target_slice, "duration_sec")) or 0.0
    local_offset = max(0.0, min(timestamp - slice_start, slice_duration))

    result = {
        "slice_index": _slice_index(target_slice, 0),
        "local_offset_seconds": _round_seconds(local_offset),
        "resolve_confidence": "slice_only",
        "timestamp_seconds": _round_seconds(timestamp),
    }

    window = _resolve_window(target_slice, timestamp, local_offset)
    if window is not None:
        _merge_window_result(result, window)
        return result

    bookmark = _resolve_bookmark(target_slice, slice_start, local_offset)
    if bookmark is not None:
        _merge_bookmark_result(result, bookmark)
        return result

    word = _resolve_word(target_slice, local_offset)
    if word is not None:
        _merge_word_result(result, word)
        return result

    return result


def _contains(start: float, end: float, value: float) -> bool:
    return start <= value < end or abs(value - end) <= _EPSILON


def _resolve_window(
    timeline_slice: Mapping[str, Any],
    timestamp: float,
    local_offset: float,
) -> Mapping[str, Any] | None:
    candidates: list[tuple[float, Mapping[str, Any]]] = []
    for window in _get(timeline_slice, "windows", default=[]) or []:
        if not isinstance(window, Mapping):
            continue
        global_start = _nonnegative_float(_get(window, "global_start_sec"))
        global_end = _nonnegative_float(_get(window, "global_end_sec"))
        local_start = _nonnegative_float(_get(window, "local_start_sec", "start_sec"))
        local_end = _nonnegative_float(_get(window, "local_end_sec", "end_sec"))

        if global_start is not None and global_end is not None:
            if not _contains(global_start, global_end, timestamp):
                continue
            span = max(global_end - global_start, 0.0)
        elif local_start is not None and local_end is not None:
            if not _contains(local_start, local_end, local_offset):
                continue
            span = max(local_end - local_start, 0.0)
        else:
            continue
        candidates.append((span, window))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def _resolve_bookmark(
    timeline_slice: Mapping[str, Any],
    slice_start_sec: float,
    local_offset: float,
) -> Mapping[str, Any] | None:
    candidates: list[tuple[float, Mapping[str, Any]]] = []
    for bookmark in _get(timeline_slice, "bookmarks", default=[]) or []:
        if not isinstance(bookmark, Mapping):
            continue
        local_time = _first_float(bookmark, "local_time_sec", "time_sec")
        if local_time is None:
            global_time = _first_float(bookmark, "global_time_sec", "timestamp_sec")
            if global_time is not None:
                local_time = max(0.0, global_time - slice_start_sec)
        if local_time is None:
            continue
        candidates.append((abs(local_offset - local_time), bookmark))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def _resolve_word(
    timeline_slice: Mapping[str, Any],
    local_offset: float,
) -> Mapping[str, Any] | None:
    candidates: list[tuple[int, float, Mapping[str, Any]]] = []
    for word in _get(timeline_slice, "words", default=[]) or []:
        if not isinstance(word, Mapping):
            continue
        local_start = _first_float(word, "local_start_sec", "start_sec")
        local_end = _first_float(word, "local_end_sec", "end_sec")
        if local_start is None and local_end is None:
            continue
        if local_start is None:
            local_start = local_end
        if local_end is None:
            local_end = local_start
        assert local_start is not None and local_end is not None
        if _contains(local_start, local_end, local_offset):
            distance = 0.0
            priority = 0
        else:
            center = (local_start + local_end) / 2
            distance = abs(local_offset - center)
            priority = 1
        candidates.append((priority, distance, word))
    if not candidates:
        return None
    candidates.sort(key=lambda item: (item[0], item[1]))
    return candidates[0][2]


def _merge_window_result(result: dict[str, Any], window: Mapping[str, Any]) -> None:
    result["resolve_confidence"] = "window"
    for key in ("window_id", "kind"):
        value = _get(window, key)
        if value is not None:
            result[key] = value
    target = _get(window, "target", default={}) or {}
    for key in ("sync_unit_id", "bookmark_mark"):
        value = _get(target, key)
        if value is None:
            value = _get(window, key)
        if value is not None:
            result[key] = value


def _merge_bookmark_result(
    result: dict[str, Any],
    bookmark: Mapping[str, Any],
) -> None:
    result["resolve_confidence"] = "bookmark"
    mark = _get(bookmark, "mark", "bookmark_mark")
    if mark is not None:
        result["bookmark_mark"] = mark
    sync_unit_id = _get(bookmark, "sync_unit_id")
    if sync_unit_id is not None:
        result["sync_unit_id"] = sync_unit_id


def _merge_word_result(result: dict[str, Any], word: Mapping[str, Any]) -> None:
    result["resolve_confidence"] = "word"
    index = _get(word, "index", "word_index")
    if index is not None:
        result["word_index"] = index
        result["word_index_start"] = index
        result["word_index_end"] = index
    text = _get(word, "text")
    if text is not None:
        result["word_text"] = text
