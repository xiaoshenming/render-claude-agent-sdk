"""Backend ordering and health-state collaborator for the LLM manager."""

import logging
from typing import Any, Callable

from app.services.llm_stream_adapters import LLMEmptyResponseError

logger = logging.getLogger(__name__)


class LLMManagerHealth:
    def __init__(
        self,
        owner: Any,
        *,
        config: Any,
        registry: Any,
        now: Callable[[], Any],
        health_disabled: Callable[[], bool],
        bypass_cooldown: Callable[[str], bool],
        generation_validation_error: Callable[[Exception], bool],
        permanent_backend_unavailable: Callable[[Exception], bool],
        should_cooldown: Callable[[Exception], bool],
    ) -> None:
        self.owner = owner
        self.config = config
        self.registry = registry
        self.now = now
        self.health_disabled = health_disabled
        self.bypass_cooldown = bypass_cooldown
        self.generation_validation_error = generation_validation_error
        self.permanent_backend_unavailable = permanent_backend_unavailable
        self.should_cooldown = should_cooldown

    def ordered_backends(self) -> list:
        backends = self.owner.backends
        if not self.owner._last_success:
            return backends
        head = [
            backend for backend in backends
            if backend.name == self.owner._last_success and not backend.fallback
        ]
        tail = [
            backend for backend in backends
            if backend.name != self.owner._last_success or backend.fallback
        ]
        return head + tail if head else backends

    def cooldown_payload(self, backend: Any, call_type: str) -> dict | None:
        if self.health_disabled() or self.bypass_cooldown(call_type):
            return None
        return self.registry.cooldown_payload(
            backend_name=backend.name,
            model=backend.model,
            call_type=call_type,
        )

    def cooldown_attempt(
        self, backend: Any, call_type: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        now = self.now()
        return {
            "backend_name": backend.name,
            "model": backend.model,
            "success": False,
            "latency_ms": 0,
            "error_type": "ModelBackendCooldown",
            "error_message": "model_backend_cooldown",
            "usage_info": {
                "backend_skip_reason": "model_backend_cooldown",
                "call_type": call_type,
                "cooldown_until": payload.get("cooldown_until"),
                "cooldown_remaining_sec": payload.get("cooldown_remaining_sec"),
                "failure_count": payload.get("failure_count"),
                "last_error_type": payload.get("last_error_type"),
            },
            "started_at": now,
            "ended_at": now,
        }

    def mark_success(
        self, name: str, *, model: str | None = None, call_type: str | None = None
    ) -> None:
        self.owner._backend_cooldowns.pop(name, None)
        if model and call_type:
            self.registry.record_success(
                backend_name=name, model=model, call_type=call_type
            )
        backend = next((item for item in self.owner.backends if item.name == name), None)
        if backend and backend.fallback:
            if self.owner._last_success != name:
                logger.info("[Sticky] %s 为 fallback backend，不记入 sticky", name)
            return
        if self.owner._last_success != name:
            logger.info(
                "[Sticky] 上次成功 backend 切换: %s → %s",
                self.owner._last_success,
                name,
            )
        self.owner._last_success = name

    def mark_transient_failure(
        self, backend: Any, exc: Exception, *, call_type: str, force: bool = False
    ) -> None:
        if self.health_disabled():
            return
        if self.generation_validation_error(exc):
            logger.info(
                "LLM generation validation error skipped backend cooldown: "
                "backend=%s model=%s call_type=%s err=%s",
                backend.name, backend.model, call_type, str(exc)[:240],
            )
            return
        if self.permanent_backend_unavailable(exc):
            logger.info(
                "LLM backend unavailable error skipped transient cooldown: "
                "backend=%s model=%s call_type=%s err=%s",
                backend.name, backend.model, call_type, str(exc)[:240],
            )
            return
        if not force and not self.should_cooldown(exc):
            return
        threshold = int(
            getattr(self.config, "LLM_BACKEND_HEALTH_FAILURE_THRESHOLD", 2) or 2
        )
        if force:
            threshold = 1
        elif isinstance(exc, LLMEmptyResponseError):
            threshold = int(
                getattr(self.config, "LLM_EMPTY_RESPONSE_HEALTH_FAILURE_THRESHOLD", 2)
                or 2
            )
        record = self.registry.record_failure(
            backend_name=backend.name,
            model=backend.model,
            call_type=call_type,
            error_type=type(exc).__name__,
            error_message=str(exc),
            transient=True,
            failure_threshold=threshold,
            cooldown_seconds=int(
                getattr(self.config, "LLM_BACKEND_HEALTH_COOLDOWN_SECONDS", 300)
                or 300
            ),
        )
        logger.info(
            "LLM backend transient failure recorded: backend=%s model=%s "
            "call_type=%s force=%s failure_count=%s state_file=%s",
            backend.name, backend.model, call_type, force,
            record.failure_count, self.registry._state_file(),
        )
        if record.is_cooling_down():
            self.owner._backend_cooldowns[backend.name] = record.cooldown_until_monotonic
            logger.warning(
                "LLM backend %s enters model/call_type cooldown until %s: %s",
                backend.name, record.cooldown_until, str(exc)[:240],
            )

    def reload(self, *, clear_health: bool = False) -> None:
        self.owner._backends = None
        self.owner._last_success = None
        self.owner._backend_cooldowns = {}
        if clear_health:
            self.registry.clear()
