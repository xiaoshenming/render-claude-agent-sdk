"""Execute and describe one non-streaming LLM backend/key attempt."""

import asyncio
import logging
import time
from typing import Any

from app.services.llm_nonstream_context import (
    NonstreamAttemptContext,
    NonstreamAttemptOutcome,
)

logger = logging.getLogger(__name__)


def _attempt_record(
    context: NonstreamAttemptContext,
    deps: Any,
    *,
    started_at: Any,
    started_clock: float,
    success: bool,
    usage_info: dict,
    output_text: str | None = None,
    response: Any = None,
    exception: BaseException | None = None,
    error_message: str | None = None,
    error_type: str | None = None,
) -> dict[str, Any]:
    record = {
        "backend_name": context.backend.name,
        "model": context.backend.model,
        "success": success,
        "latency_ms": int((time.monotonic() - started_clock) * 1000),
        "usage_info": deps.usage_with_context(
            usage_info,
            context.trace_usage_context,
        ),
        "started_at": started_at,
        "ended_at": deps.now(),
    }
    if output_text is not None:
        record["output_text"] = output_text
    if response is not None:
        record["cost_usd"] = deps.completion_cost(response)
    if exception is not None:
        record.update(
            error_type=error_type or type(exception).__name__,
            error_message=error_message if error_message is not None else str(exception),
        )
    return record


async def execute_nonstream_attempt(
    manager: Any,
    context: NonstreamAttemptContext,
    deps: Any,
) -> NonstreamAttemptOutcome:
    backend = context.backend
    started_at = deps.now()
    started_clock = time.monotonic()
    logger.info(
        "LLM call: backend=%s, key_index=%s/%s, round=%s/%s, model=%s, max_tokens=%s",
        backend.name,
        context.key_index,
        len(backend.keys),
        context.global_attempt + 1,
        context.retry_budget,
        backend.model,
        context.max_tokens,
    )
    try:
        if backend.uses_responses_api:
            response = await manager._call_responses_api(
                backend=backend,
                key=context.key,
                messages=context.messages,
                max_output_tokens=context.max_tokens,
                trace_call_type=context.call_type,
                prompt_cache_kwargs=deps.prompt_cache_kwargs,
            )
        else:
            response = await deps.acompletion(
                model=backend.model,
                messages=context.messages,
                timeout=backend.effective_timeout,
                max_tokens=context.max_tokens,
                api_key=context.key,
                api_base=backend.resolved_api_base(),
                num_retries=0,
                **backend.litellm_temperature_kwargs(),
                **deps.provider_extra_kwargs,
            )
        content, finish_reason = deps.extract_content(response)
        if finish_reason == "length":
            logger.warning(
                "LLM 输出因 max_tokens 截断: backend=%s, max_tokens=%s, len=%s",
                backend.name,
                context.max_tokens,
                len(content),
            )
        usage_info = deps.extract_usage(response)
        usage_info["retry_count"] = context.global_attempt
        if finish_reason:
            usage_info["finish_reason"] = finish_reason
        if (
            context.max_tokens >= 512
            and len(content) < 100
            and "```" not in content
            and finish_reason != "stop"
        ):
            exception = Exception(f"响应可能被截断，长度: {len(content)}")
            logger.warning(
                "响应疑似截断: backend=%s, len=%s, max_tokens=%s, finish_reason=%s",
                backend.name,
                len(content),
                context.max_tokens,
                finish_reason,
            )
            return NonstreamAttemptOutcome(
                action=deps.next_backend,
                exception=exception,
                truncated=True,
                attempt=_attempt_record(
                    context,
                    deps,
                    started_at=started_at,
                    started_clock=started_clock,
                    success=False,
                    usage_info=usage_info,
                    output_text=content,
                    exception=exception,
                    error_message=str(exception),
                    error_type="TruncatedResponse",
                ),
            )
        usage_info["response_text"] = content
        logger.info(
            "LLM success: backend=%s, elapsed_ms=%s, finish_reason=%s, content_len=%s",
            backend.name,
            int((time.monotonic() - started_clock) * 1000),
            finish_reason,
            len(content),
        )
        return NonstreamAttemptOutcome(
            action="success",
            response=response,
            attempt=_attempt_record(
                context,
                deps,
                started_at=started_at,
                started_clock=started_clock,
                success=True,
                usage_info=usage_info,
                output_text=content,
                response=response,
            ),
        )
    except asyncio.CancelledError as exception:
        local = deps.task_cancellation_requested()
        reported = exception if local else deps.provider_cancelled_error(
            "LLM call cancelled by provider or relay"
        )
        action = "local_cancel" if local else deps.next_backend
        usage_info = {"retry_count": context.global_attempt}
        return NonstreamAttemptOutcome(
            action=action,
            exception=reported,
            attempt=_attempt_record(
                context,
                deps,
                started_at=started_at,
                started_clock=started_clock,
                success=False,
                usage_info=usage_info,
                exception=reported,
                error_message=deps.cancelled_message(reported, local=local),
            ),
        )
    except Exception as exception:
        usage_info = {
            **(getattr(exception, "usage_info", {}) or {}),
            "retry_count": context.global_attempt,
        }
        return NonstreamAttemptOutcome(
            action=deps.classify_error(exception),
            exception=exception,
            attempt=_attempt_record(
                context,
                deps,
                started_at=started_at,
                started_clock=started_clock,
                success=False,
                usage_info=usage_info,
                exception=exception,
            ),
        )
