"""Build canonical timeline manifests."""
# ruff: noqa: F403, F405
import uuid
from collections.abc import Mapping, Sequence
from typing import Any, Callable
from app.services.timeline_manifest_core import *

SCHEMA_VERSION=1
TIMEBASE="seconds"
PRECISION_MS=10
facade_provider: Callable[[], Any] | None = None

async def build_timeline_manifest(
    video_id: str,
    job_id: str,
    slices: Sequence[Any],
    final_video_path: str | None = None,
    final_video_url: str | None = None,
    source_type: str = "generate",
    parent_manifest: Mapping[str, Any] | None = None,
    final_duration_sec: float | None = None,
    manifest_id: str | None = None,
) -> dict[str, Any]:
    """Build a timeline manifest from final media evidence and slice metadata."""
    parent_slices = _parent_slices_by_index(parent_manifest)
    ordered_slices = sorted(
        list(enumerate(slices or [])),
        key=lambda pair: _slice_index(pair[1], pair[0]),
    )

    manifest_slices: list[dict[str, Any]] = []
    current_start = 0.0

    for fallback, raw_slice in ordered_slices:
        slice_index = _slice_index(raw_slice, fallback)
        parent_slice = parent_slices.get(slice_index)
        mp4_path = _get(
            raw_slice,
            "mp4_path",
            "local_mp4_path",
            "video_path",
            "local_path",
            "path",
        )

        probed_duration = await facade_provider()._probe_duration_sec(mp4_path)
        if probed_duration is not None:
            duration = probed_duration
            duration_source = "ffprobe_slice_mp4"
        else:
            provided_duration = _first_float(
                raw_slice,
                "duration_sec",
                "duration",
                "video_duration_sec",
            )
            if provided_duration is not None:
                duration = provided_duration
                duration_source = "provided_slice_duration"
            else:
                duration = 0.0
                duration_source = "unknown"

        duration = _round_seconds(duration)
        global_start = _round_seconds(current_start)
        global_end = _round_seconds(current_start + duration)

        item: dict[str, Any] = {
            "slice_index": slice_index,
            "global_start_sec": global_start,
            "global_end_sec": global_end,
            "duration_sec": duration,
            "duration_source": duration_source,
        }

        for key in ("slice_id", "scene_name", "video_url"):
            value = _get(raw_slice, key)
            if value is None and parent_slice is not None:
                value = _get(parent_slice, key)
            if value is not None:
                item[key] = value

        for key in (
            "audio_present",
            "audio_filled_silence",
            "trim_head_sec",
            "trim_tail_sec",
        ):
            value = _get(raw_slice, key)
            if value is None and parent_slice is not None:
                value = _get(parent_slice, key)
            if value is not None:
                item[key] = value

        item["sync_units"] = _copy_items(raw_slice, parent_slice, "sync_units")
        item["bookmarks"] = _normalize_bookmarks(
            _copy_items(raw_slice, parent_slice, "bookmarks"),
            global_start_sec=global_start,
            source_global_start_sec=_timing_source_start_sec(
                raw_slice,
                parent_slice,
                "bookmarks",
                global_start_sec=global_start,
            ),
        )
        item["words"] = _normalize_words(
            _copy_items(raw_slice, parent_slice, "words"),
            global_start_sec=global_start,
            source_global_start_sec=_timing_source_start_sec(
                raw_slice,
                parent_slice,
                "words",
                global_start_sec=global_start,
            ),
        )
        item["windows"] = _normalize_windows(
            _copy_items(raw_slice, parent_slice, "windows"),
            global_start_sec=global_start,
            source_global_start_sec=_timing_source_start_sec(
                raw_slice,
                parent_slice,
                "windows",
                global_start_sec=global_start,
            ),
        )

        manifest_slices.append(item)
        current_start = global_end

    final_probe_duration = await facade_provider()._probe_duration_sec(final_video_path)
    if final_probe_duration is not None:
        final_duration = final_probe_duration
        final_duration_source = "ffprobe_final_mp4"
    else:
        provided_final_duration = _nonnegative_float(final_duration_sec)
        if provided_final_duration is not None:
            final_duration = provided_final_duration
            final_duration_source = "provided_final_duration"
        else:
            final_duration = sum(
                _nonnegative_float(item.get("duration_sec")) or 0.0
                for item in manifest_slices
            )
            final_duration_source = "sum_slice_duration"

    final_duration = _round_seconds(final_duration)
    final: dict[str, Any] = {
        "video_url": final_video_url,
        "duration_sec": final_duration,
        "video_duration_sec": final_duration,
        "duration_source": final_duration_source,
    }
    if final_video_url is None:
        final.pop("video_url")

    manifest: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "manifest_id": manifest_id or uuid.uuid4().hex[:26],
        "video_id": video_id,
        "job_id": job_id,
        "parent_manifest_id": _parent_manifest_id(parent_manifest),
        "manifest_hash": "",
        "timebase": TIMEBASE,
        "precision_ms": PRECISION_MS,
        "source_type": source_type,
        "final": final,
        "slices": manifest_slices,
        "global_start_sec": 0.0,
        "global_end_sec": final_duration,
        "duration_source": {
            "final": final_duration_source,
            "slices": [
                {
                    "slice_index": item["slice_index"],
                    "source": item["duration_source"],
                }
                for item in manifest_slices
            ],
        },
    }
    drift = facade_provider().validate_duration_drift(manifest)
    manifest["duration_drift"] = drift
    manifest["status"] = "VALID" if drift["ok"] else "INVALID"
    manifest["manifest_hash"] = compute_manifest_hash(manifest)
    return manifest
