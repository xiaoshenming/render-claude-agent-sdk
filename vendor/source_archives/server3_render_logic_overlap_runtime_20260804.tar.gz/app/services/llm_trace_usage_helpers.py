"""LLM trace 中 prompt segment 与 skill 元数据的安全归一化辅助。"""

from __future__ import annotations

from collections.abc import Callable


def safe_prompt_segments(usage_info: dict, *, dict_or_empty: Callable[[object], dict], hash_prompt: Callable[[str], str]) -> dict:
    prompt_segments = dict_or_empty(usage_info.get("prompt_segments"))
    if not prompt_segments:
        return {}
    safe: dict[str, object] = {}
    for key, value in prompt_segments.items():
        if key in {"stable_prefix", "skill_prefix"}:
            continue
        safe[key] = safe_dynamic_payload(value, hash_prompt=hash_prompt) if key == "dynamic_payload" else value
    skill_prefix = prompt_segments.get("skill_prefix")
    if isinstance(skill_prefix, str) and skill_prefix:
        skill_uris = [line.strip() for line in skill_prefix.splitlines() if line.strip().startswith("skill://")]
        if skill_uris:
            safe["skill_uris"] = skill_uris
    return safe


def safe_dynamic_payload(value: object, *, hash_prompt: Callable[[str], str]) -> dict:
    if not isinstance(value, dict):
        return {}
    sanitized: dict[str, object] = {}
    for key, item in value.items():
        if isinstance(item, dict) and any(field in item for field in ("hash", "length", "present", "slot", "type")):
            sanitized[str(key)] = {field: item.get(field) for field in ("slot", "type", "present", "length", "hash") if field in item}
            continue
        text_value = "" if item is None else str(item)
        sanitized[str(key)] = {"slot": str(key), "type": type(item).__name__, "present": bool(text_value), "length": len(text_value), "hash": hash_prompt(text_value) if text_value else ""}
    return sanitized


def artifact_selected_skills(prompt_segments: dict, cache_metrics: dict) -> list | None:
    assembly_manifest = prompt_segments.get("assembly_manifest")
    if isinstance(assembly_manifest, dict):
        selected = list_or_none(assembly_manifest.get("selected_skills"))
        if selected is not None:
            return selected
    selected = list_or_none(prompt_segments.get("selected_skills"))
    return selected if selected is not None else list_or_none(cache_metrics.get("selected_skills"))


def artifact_skill_block_refs(prompt_segments: dict) -> list | None:
    assembly_manifest = prompt_segments.get("assembly_manifest")
    if isinstance(assembly_manifest, dict):
        refs = list_or_none(assembly_manifest.get("block_refs"))
        if refs is not None:
            return refs
    refs = list_or_none(prompt_segments.get("skill_block_refs"))
    return refs if refs is not None else list_or_none(prompt_segments.get("skill_blocks"))


def list_or_none(value: object) -> list | None:
    return value if isinstance(value, list) else None
