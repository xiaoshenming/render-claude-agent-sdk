from __future__ import annotations

import asyncio
import time
from datetime import datetime
from typing import Any

from app.services.llm_call_tracer import LLMCallTracer as DefaultLLMCallTracer
from .dedicated_llm_config import *
from .dedicated_llm_config import _beijing_now, _env_int, _env_float, _route_env, _route_env_int, _route_env_float, _default_max_attempts, _api_base_with_v1, _get_limiter, DEFAULT_GPT_REASONING_EFFORT, FALLBACK_GPT_REASONING_EFFORT
from .dedicated_llm_response import _usage_from_response, _extract_response_text, _finish_reason_from_response, _merge_trace_usage_context, _response_format_name, _is_gpt_model, _is_gpt5_model, _messages_to_responses_input, _extract_responses_output_text, _adapt_responses_response, _responses_kwargs_from_chat_kwargs, _chat_kwargs_for_provider, _should_retry_with_high_reasoning, _with_high_reasoning, _is_retryable



def _build_tracer(
    *,
    tracer_cls: Any,
    job_id: str,
    call_type: str,
    prompt_version: str | None,
    prompt_content: str,
    response_format: str | None = None,
) -> Any:
    tracer_kwargs = {
        "job_id": job_id or "unknown",
        "call_type": call_type,
        "prompt_version": prompt_version,
    }
    if response_format:
        tracer_kwargs["response_format"] = response_format
    try:
        tracer = tracer_cls(**tracer_kwargs)
    except TypeError:
        tracer_kwargs.pop("response_format", None)
        tracer = tracer_cls(**tracer_kwargs)
    tracer.start()
    tracer.set_prompt_hash(prompt_content)
    return tracer


async def _record_success(
    tracer: Any,
    *,
    backend_name: str,
    model_name: str,
    response: Any,
    latency_ms: int,
    retry_count: int,
    response_format: str | None,
    trace_usage_context: dict[str, Any] | None = None,
    started_at: datetime | None = None,
    ended_at: datetime | None = None,
) -> None:
    try:
        usage_info = _usage_from_response(response)
        usage_info["retry_count"] = retry_count
        response_text = _extract_response_text(response)
        if response_text:
            usage_info["response_text"] = response_text
        if response_format:
            usage_info["response_format"] = response_format
        finish_reason = _finish_reason_from_response(response)
        if finish_reason:
            usage_info["finish_reason"] = finish_reason
        usage_info = _merge_trace_usage_context(usage_info, trace_usage_context)
        await tracer.record_success(
            backend_name=backend_name,
            model=model_name,
            usage_info=usage_info,
            latency_ms=latency_ms,
            started_at=started_at,
            ended_at=ended_at,
            output_text=response_text,
        )
    except Exception:
        pass


async def _record_failure(
    tracer: Any,
    *,
    backend_name: str,
    model_name: str,
    exc: Exception,
    latency_ms: int,
    retry_count: int,
    response_format: str | None,
    trace_usage_context: dict[str, Any] | None = None,
    started_at: datetime | None = None,
    ended_at: datetime | None = None,
) -> None:
    try:
        usage_info = {"retry_count": retry_count}
        if response_format:
            usage_info["response_format"] = response_format
        usage_info = _merge_trace_usage_context(usage_info, trace_usage_context)
        await tracer.record_failure(
            backend_name=backend_name,
            model=model_name,
            error_type=type(exc).__name__,
            error_message=f"{type(exc).__name__}: {exc}",
            usage_info=usage_info,
            latency_ms=latency_ms,
            started_at=started_at,
            ended_at=ended_at,
        )
    except Exception:
        pass


async def call_dedicated_chat_completion(
    *,
    job_id: str,
    call_type: str,
    prompt_version: str,
    prompt_content: str,
    backend_name: str,
    limiter_key: str,
    env_prefix: str,
    client_cls: Any,
    tracer_cls: Any = DefaultLLMCallTracer,
    api_key: str,
    api_base: str | None,
    model_name: str,
    timeout: float,
    request_kwargs: dict[str, Any],
    trace_usage_context: dict[str, Any] | None = None,
) -> Any:
    if client_cls is None:
        raise RuntimeError("openai SDK is not available for dedicated LLM route")

    max_attempts = _route_env_int(
        env_prefix,
        "MAX_ATTEMPTS",
        "DEDICATED_LLM_MAX_ATTEMPTS",
        _default_max_attempts(env_prefix),
    )
    max_concurrency = _route_env_int(
        env_prefix,
        "MAX_CONCURRENCY",
        "DEDICATED_LLM_MAX_CONCURRENCY",
        2,
    )
    retry_base_delay = _route_env_float(
        env_prefix,
        "RETRY_BASE_DELAY_SEC",
        "DEDICATED_LLM_RETRY_BASE_DELAY_SEC",
        1.0,
    )
    queue_timeout = _route_env_float(
        env_prefix,
        "QUEUE_TIMEOUT_SEC",
        "DEDICATED_LLM_QUEUE_TIMEOUT_SEC",
        max(60.0, timeout * 3),
    )

    tracer = _build_tracer(
        tracer_cls=tracer_cls,
        job_id=job_id,
        call_type=call_type,
        prompt_version=prompt_version,
        prompt_content=prompt_content,
        response_format=_response_format_name(request_kwargs),
    )
    limiter = _get_limiter(limiter_key, max_concurrency)

    acquired = False
    try:
        queue_started_at = _beijing_now()
        queue_started = time.monotonic()
        await asyncio.wait_for(limiter.acquire(), timeout=queue_timeout)
        acquired = True
    except Exception as exc:
        queue_ended_at = _beijing_now()
        await _record_failure(
            tracer,
            backend_name=backend_name,
            model_name=model_name,
            exc=exc,
            latency_ms=int((time.monotonic() - queue_started) * 1000),
            retry_count=0,
            response_format=_response_format_name(request_kwargs),
            trace_usage_context=trace_usage_context,
            started_at=queue_started_at,
            ended_at=queue_ended_at,
        )
        raise

    try:
        client = client_cls(
            api_key=api_key,
            base_url=_api_base_with_v1(api_base),
            timeout=timeout,
            max_retries=0,
        )
        last_exc: Exception | None = None
        response_format = _response_format_name(request_kwargs)
        use_responses_api = _is_gpt_model(model_name)
        for attempt in range(1, max_attempts + 1):
            attempt_started_at = _beijing_now()
            started = time.monotonic()
            try:
                if use_responses_api:
                    responses_kwargs = _responses_kwargs_from_chat_kwargs(request_kwargs, model_name)
                    raw_response = await asyncio.wait_for(
                        client.responses.create(**responses_kwargs),
                        timeout=timeout,
                    )
                    response = _adapt_responses_response(raw_response, model_name)
                else:
                    chat_kwargs = _chat_kwargs_for_provider(request_kwargs)
                    response = await asyncio.wait_for(
                        client.chat.completions.create(**chat_kwargs),
                        timeout=timeout,
                    )
                latency_ms = int((time.monotonic() - started) * 1000)
                attempt_ended_at = _beijing_now()
                await _record_success(
                    tracer,
                    backend_name=backend_name,
                    model_name=model_name,
                    response=response,
                    latency_ms=latency_ms,
                    retry_count=attempt - 1,
                    response_format=response_format,
                    trace_usage_context=trace_usage_context,
                    started_at=attempt_started_at,
                    ended_at=attempt_ended_at,
                )
                return response
            except Exception as exc:
                if use_responses_api and _should_retry_with_high_reasoning(exc, responses_kwargs):
                    fallback_started_at = _beijing_now()
                    started = time.monotonic()
                    try:
                        raw_response = await asyncio.wait_for(
                            client.responses.create(**_with_high_reasoning(responses_kwargs)),
                            timeout=timeout,
                        )
                        response = _adapt_responses_response(raw_response, model_name)
                        latency_ms = int((time.monotonic() - started) * 1000)
                        fallback_ended_at = _beijing_now()
                        await _record_success(
                            tracer,
                            backend_name=backend_name,
                            model_name=model_name,
                            response=response,
                            latency_ms=latency_ms,
                            retry_count=attempt - 1,
                            response_format=response_format,
                            trace_usage_context=trace_usage_context,
                            started_at=fallback_started_at,
                            ended_at=fallback_ended_at,
                        )
                        return response
                    except Exception as fallback_exc:
                        attempt_started_at = fallback_started_at
                        exc = fallback_exc
                last_exc = exc
                latency_ms = int((time.monotonic() - started) * 1000)
                attempt_ended_at = _beijing_now()
                await _record_failure(
                    tracer,
                    backend_name=backend_name,
                    model_name=model_name,
                    exc=exc,
                    latency_ms=latency_ms,
                    retry_count=attempt - 1,
                    response_format=response_format,
                    trace_usage_context=trace_usage_context,
                    started_at=attempt_started_at,
                    ended_at=attempt_ended_at,
                )
                if attempt >= max_attempts or not _is_retryable(exc):
                    raise
                if retry_base_delay > 0:
                    await asyncio.sleep(retry_base_delay * attempt)
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("dedicated LLM call did not run")
    finally:
        if acquired:
            limiter.release()
