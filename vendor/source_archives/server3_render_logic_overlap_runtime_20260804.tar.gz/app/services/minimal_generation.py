"""单一代码生成入口：固定模板加业务输入，产出原始 Manim 代码。"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from typing import Any

from app.core.config import settings
from app.prompts.common import generation_color_prompt
from app.prompts.prompt_factory import get_prompt_template
from app.prompts.tts_voice_guide import get_tts_voice_guide
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input


@dataclass(frozen=True, slots=True)
class GenerationArtifact:
    code: str
    raw_response: str
    messages: list[dict[str, str]]
    usage: dict[str, Any]


def build_messages(
    *,
    provider: str,
    prompt: str,
    color_scheme: int,
    enable_tts: bool,
    tts_voice: str,
    voice_type: str,
    cosyvoice_id: str,
    aspect_ratio: str,
) -> list[dict[str, str]]:
    """构造唯一生成合同，不做 planning、skills 或动态路由。"""
    user_input = guard_ai_user_input(prompt, scenario="render_generate_stream")
    template = get_prompt_template(provider, enable_tts, aspect_ratio)
    system_prompt = template.replace("主题：__USER_PROMPT__", "").replace(
        "__COLOR__", generation_color_prompt(color_scheme)
    )
    system_prompt = system_prompt.replace(
        "__TTS_VOICE_GUIDE__",
        get_tts_voice_guide(voice_type=voice_type, cosyvoice_id=cosyvoice_id)
        if enable_tts
        else "",
    )
    voice = cosyvoice_id if voice_type == "clone" and cosyvoice_id else tts_voice
    system_prompt = system_prompt.replace("__VOICE__", voice)
    if enable_tts:
        system_prompt += f"\n\n本任务配音音色固定为：{voice}。"
    system_prompt += (
        "\n\n输出合同：回答必须直接从 Python import 开始，只输出完整可执行源码，"
        "禁止在源码前后添加解释、计划或 Markdown 围栏。源码引用的每个全局配置名和"
        "颜色别名都必须先定义；禁止使用未定义的 BG、TEXT_COLOR 等裸别名。"
    )
    # 历史模板把题目槽放在模板内部；新合同强制题目仅作为 user message。
    system_prompt = system_prompt.replace("__USER_PROMPT__", "")
    return [
        {"role": "system", "content": system_prompt.strip()},
        {"role": "user", "content": user_input.strip()},
    ]


def extract_code(raw: str) -> str:
    text = raw.strip()
    blocks = re.findall(r"```(?:python)?\s*(.*?)```", text, re.I | re.S)
    code = "\n\n".join(block.strip() for block in blocks if block.strip()) or text
    code = _strip_leading_explanation(code)
    if not code:
        raise RuntimeError("generate_stream 未返回代码")
    return code


_PYTHON_STARTS = (
    "from manim import",
    "from manim_voiceover import",
    "import manim",
)


def _strip_leading_explanation(value: str) -> str:
    try:
        ast.parse(value)
        return value
    except SyntaxError:
        pass
    positions = [value.find(marker) for marker in _PYTHON_STARTS]
    starts = [position for position in positions if position >= 0]
    if not starts:
        return value
    candidate = value[min(starts) :].lstrip()
    return candidate or value


async def generate_source(**kwargs: Any) -> GenerationArtifact:
    job_id = str(kwargs.pop("job_id", "") or "unknown")
    messages = build_messages(**kwargs)
    usage: dict[str, Any] = {}
    chunks: list[str] = []
    from app.services.llm_service import _llm_manager

    async for chunk in _llm_manager.call_stream(
        messages=messages,
        max_tokens=max(1, int(getattr(settings, "LLM_MAX_OUTPUT_TOKENS", 65536))),
        retry_budget=int(getattr(settings, "LLM_STREAM_RETRY_BUDGET", 3) or 3),
        usage_collector=usage,
        trace_job_id=job_id,
        trace_call_type="generate_stream",
        trace_prompt_version=str(kwargs.get("provider") or "unknown"),
        trace_prompt_content="\n\n".join(item["content"] for item in messages),
    ):
        guard_ai_output(chunk, scenario="render_manim_stream_output")
        chunks.append(chunk)
    raw = "".join(chunks)
    code = extract_code(raw)
    # 这里只记录语法证据，不阻断；是否可执行由 Render Agent 决定。
    try:
        ast.parse(code)
    except SyntaxError as exc:
        usage["syntax_error"] = f"{exc.msg}@{exc.lineno}:{exc.offset}"
    return GenerationArtifact(code=code, raw_response=raw, messages=messages, usage=usage)
