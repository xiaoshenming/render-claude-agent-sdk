"""Mutable runtime backend configuration and manager routing."""

import logging
from typing import Any, Callable

logger = logging.getLogger(__name__)


class LLMRuntimeConfig:
    def __init__(self, facade: Callable[[], Any]):
        self._facade = facade
        self._raw = {
            "main": None,
            "repair": None,
            "fast_pre_repair": None,
            "modify": None,
            "modify_visual": None,
            "skill_driver": None,
            "quality_multimodal": None,
        }

    def raw(self, key: str, setting_name: str | None = None) -> str:
        value = self._raw[key]
        if value is None and setting_name:
            value = getattr(self._facade().settings, setting_name, "")
        return str(value or "").strip()

    def load_required(
        self, key: str, config_name: str, setting_name: str | None = None
    ) -> list:
        raw = self.raw(key, setting_name)
        if not raw:
            raise ValueError(f"{config_name} is not configured")
        return self._facade()._load_backends_from_raw(raw, config_name)

    def load_main(self) -> list:
        svc = self._facade()
        raw = self.raw("main", "LLM_BACKENDS_JSON")
        if raw:
            return svc._load_backends_from_raw(raw, "LLM_BACKENDS_JSON")
        keys = [
            key.strip()
            for key in str(svc.settings.CLAUDE_API_KEYS or "").split(",")
            if key.strip()
        ]
        if not keys:
            raise ValueError(
                "No LLM backends configured: set LLM_BACKENDS_JSON or CLAUDE_API_KEYS"
            )
        return [
            svc._Backend(
                name="legacy",
                priority=1,
                model=f"{svc.settings.CLAUDE_MODEL_PREFIX}/claude-sonnet-4-6",
                api_base=svc.settings.CLAUDE_API_BASE or "",
                keys=keys,
            )
        ]

    def set(self, key: str, raw: str | None, manager: Any = None) -> None:
        normalized = raw.strip() if raw else None
        if normalized == self._raw[key]:
            return
        self._raw[key] = normalized
        if manager is not None:
            manager.reload()
        logger.info("Runtime %s LLM backend config reloaded", key)
