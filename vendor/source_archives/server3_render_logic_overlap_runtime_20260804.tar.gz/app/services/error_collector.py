"""Render pipeline error buffer and evidence persistence."""

from __future__ import annotations

import json
import logging
import traceback
import uuid
from typing import Any, Dict, List, Optional

from sqlalchemy import text

from app.database.database import AsyncSessionLocal
from app.services.error_collector_support import (
    QUALITY_ERROR_PREFIX_BY_CATEGORY as QUALITY_ERROR_PREFIX_BY_CATEGORY,
    RETRYABLE_QUALITY_KEYWORDS as RETRYABLE_QUALITY_KEYWORDS,
    SEVERITY_WEIGHT,
    bounded_identifier as _bounded_identifier,
    classify_exception_severity as _classify_exception_severity,
    classify_render_error as classify_render_error,
    json_param as _json_param,
    json_safe_snapshot,
    quality_error_code as _quality_error_code,
    quality_error_retryable as _quality_error_retryable,
    quality_error_stage as _quality_error_stage,
    quality_error_suggestion as _quality_error_suggestion,
)

logger = logging.getLogger(__name__)


class ErrorCollector:
    """渲染管线错误采集器：内存缓冲并批量写入证据表。"""

    def __init__(
        self,
        job_id: str,
        request_id: Optional[str] = None,
        trace_id: Optional[str] = None,
        attempt_id: Optional[str] = None,
        video_id: Optional[str] = None,
    ):
        self.job_id = job_id
        self.request_id = _bounded_identifier(
            request_id or str(uuid.uuid4()),
            max_length=36,
        )
        self.trace_id = _bounded_identifier(trace_id, max_length=64)
        self.attempt_id = _bounded_identifier(attempt_id, max_length=64)
        self.video_id = video_id
        self._buffer: List[dict] = []

    def _add(
        self,
        severity: str,
        category: str,
        stage: Optional[str],
        message: str,
        stack_trace: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        duration_ms: Optional[int] = None,
    ) -> None:
        self._buffer.append(
            {
                "severity": severity,
                "category": category,
                "stage": stage,
                "message": message[:2000],
                "stack_trace": stack_trace[:5000] if stack_trace else None,
                "context": json_safe_snapshot(context or {}),
                "duration_ms": duration_ms,
            }
        )

    def critical(self, category: str, stage: str, message: str, **kwargs) -> None:
        self._add("CRITICAL", category, stage, message, **kwargs)

    def error(self, category: str, stage: str, message: str, **kwargs) -> None:
        self._add("ERROR", category, stage, message, **kwargs)

    def warning(self, category: str, stage: str, message: str, **kwargs) -> None:
        self._add("WARNING", category, stage, message, **kwargs)

    def info(self, category: str, stage: str, message: str, **kwargs) -> None:
        self._add("INFO", category, stage, message, **kwargs)

    def capture_exception(
        self,
        exc: Exception,
        category: str,
        stage: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._add(
            severity=_classify_exception_severity(exc),
            category=category,
            stage=stage,
            message=str(exc),
            stack_trace=traceback.format_exc(),
            context=context,
        )

    @property
    def has_errors(self) -> bool:
        return any(
            entry["severity"] in ("CRITICAL", "ERROR") for entry in self._buffer
        )

    @property
    def error_count(self) -> int:
        return sum(
            1
            for entry in self._buffer
            if entry["severity"] in ("CRITICAL", "ERROR")
        )

    @property
    def max_severity(self) -> str:
        if not self._buffer:
            return "INFO"
        return max(
            self._buffer,
            key=lambda entry: SEVERITY_WEIGHT.get(entry["severity"], 0),
        )["severity"]

    async def flush(self) -> int:
        """Persist buffered evidence; retain it and fail open when storage fails."""
        if not self._buffer:
            return 0

        entries = list(self._buffer)
        try:
            session = AsyncSessionLocal()
            try:
                for entry in entries:
                    render_log_id = str(uuid.uuid4()).replace("-", "")[:26]
                    context_json = (
                        json.dumps(
                            json_safe_snapshot(entry["context"]),
                            ensure_ascii=False,
                        )
                        if entry.get("context")
                        else None
                    )
                    await session.execute(
                        text(
                            """
                            INSERT INTO render_logs (
                                id, job_id, video_id, request_id,
                                trace_id, attempt_id,
                                severity, category, stage,
                                message, stack_trace, context,
                                duration_ms, created_at
                            ) VALUES (
                                :id, :job_id, :video_id, :request_id,
                                :trace_id, :attempt_id,
                                :severity, :category, :stage,
                                :message, :stack_trace, :context,
                                :duration_ms, NOW()
                            )
                            """
                        ),
                        {
                            "id": render_log_id,
                            "job_id": self.job_id,
                            "video_id": self.video_id,
                            "request_id": self.request_id,
                            "trace_id": self.trace_id,
                            "attempt_id": self.attempt_id,
                            **entry,
                            "context": context_json,
                        },
                    )
                    if entry["severity"] != "INFO":
                        await self._write_quality_event(
                            session,
                            entry=entry,
                            render_log_id=render_log_id,
                        )
                await session.commit()
                count = len(entries)
                self._buffer.clear()
                logger.debug(
                    "[ERROR_COLLECTOR] flushed %s logs for job=%s",
                    count,
                    self.job_id,
                )
            finally:
                await session.close()
        except Exception as exc:
            logger.warning("[ERROR_COLLECTOR] flush failed: %s", exc)
            return 0
        return count

    async def _write_quality_event(
        self,
        session,
        *,
        entry: dict[str, Any],
        render_log_id: str,
    ) -> None:
        error_code = _quality_error_code(entry.get("category"), entry.get("stage"))
        retryable = _quality_error_retryable(
            entry.get("category"),
            entry.get("message"),
        )
        await session.execute(
            text(
                """
                INSERT INTO quality_error_events (
                    id, source, error_code, error_stage,
                    severity, retryable, message, suggestion,
                    job_id, video_id, user_id, request_id,
                    trace_id, model_call_id, attempt_id,
                    payload, evidence, created_at
                ) VALUES (
                    :id, :source, :error_code, :error_stage,
                    :severity, :retryable, :message, :suggestion,
                    :job_id, :video_id, :user_id, :request_id,
                    :trace_id, :model_call_id, :attempt_id,
                    :payload, :evidence, NOW()
                )
                """
            ),
            {
                "id": str(uuid.uuid4()).replace("-", "")[:26],
                "source": "render",
                "error_code": error_code,
                "error_stage": _quality_error_stage(
                    entry.get("category"), entry.get("stage")
                ),
                "severity": entry["severity"].lower(),
                "retryable": retryable,
                "message": entry["message"],
                "suggestion": _quality_error_suggestion(error_code, retryable),
                "job_id": self.job_id,
                "video_id": self.video_id,
                "user_id": None,
                "request_id": self.request_id,
                "trace_id": self.trace_id,
                "model_call_id": None,
                "attempt_id": self.attempt_id,
                "payload": _json_param(
                    {
                        "category": entry.get("category"),
                        "stage": entry.get("stage"),
                        "duration_ms": entry.get("duration_ms"),
                    }
                ),
                "evidence": _json_param(
                    {
                        "render_log_id": render_log_id,
                        "context": entry.get("context") or {},
                        "stack_trace_present": bool(entry.get("stack_trace")),
                    }
                ),
            },
        )
