from __future__ import annotations

from typing import Any

from .dedicated_llm_config import (
    DEFAULT_GPT_REASONING_EFFORT,
    FALLBACK_GPT_REASONING_EFFORT,
)

def _usage_from_response(response: Any) -> dict[str, Any]:
    usage = getattr(response, "usage", None)
    if usage is None and isinstance(response, dict):
        usage = response.get("usage")

    def as_dict(value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if isinstance(value, dict):
            return value
        if hasattr(value, "model_dump"):
            return value.model_dump()
        if hasattr(value, "to_dict"):
            return value.to_dict()
        if hasattr(value, "__dict__"):
            return {
                key: item
                for key, item in vars(value).items()
                if not key.startswith("_")
            }
        return {}

    def int_value(*values: Any) -> int:
        for value in values:
            try:
                if value not in (None, ""):
                    return int(value or 0)
            except (TypeError, ValueError):
                continue
        return 0

    usage_dict = as_dict(usage)
    details = as_dict(
        usage_dict.get("input_tokens_details")
        or usage_dict.get("prompt_tokens_details")
    )
    cache_read_tokens = int_value(
        usage_dict.get("cache_read_tokens"),
        usage_dict.get("cache_read_input_tokens"),
        usage_dict.get("_cache_read_input_tokens"),
        usage_dict.get("prompt_cache_hit_tokens"),
        usage_dict.get("cachedContentTokenCount"),
        details.get("cached_tokens"),
        details.get("cache_read_input_tokens"),
    )
    cache_creation_tokens = int_value(
        usage_dict.get("cache_creation_tokens"),
        usage_dict.get("cache_creation_input_tokens"),
        usage_dict.get("_cache_creation_input_tokens"),
        details.get("cache_creation_tokens"),
        details.get("cache_creation_input_tokens"),
    )
    cache_miss_tokens = int_value(
        usage_dict.get("cache_miss_tokens"),
        usage_dict.get("prompt_cache_miss_tokens"),
    )
    if usage_dict:
        return {
            "input_tokens": int_value(
                usage_dict.get("prompt_tokens"),
                usage_dict.get("input_tokens"),
            ),
            "output_tokens": int_value(
                usage_dict.get("completion_tokens"),
                usage_dict.get("output_tokens"),
            ),
            "cache_read_tokens": cache_read_tokens,
            "cache_creation_tokens": cache_creation_tokens,
            "cache_miss_tokens": cache_miss_tokens,
            "provider_usage_raw": usage_dict,
        }
    return {
        "input_tokens": int(getattr(usage, "prompt_tokens", 0) or getattr(usage, "input_tokens", 0) or 0),
        "output_tokens": int(getattr(usage, "completion_tokens", 0) or getattr(usage, "output_tokens", 0) or 0),
        "cache_read_tokens": cache_read_tokens,
        "cache_creation_tokens": cache_creation_tokens,
        "cache_miss_tokens": cache_miss_tokens,
        "provider_usage_raw": usage_dict,
    }


def _finish_reason_from_response(response: Any) -> str | None:
    try:
        choice = response.choices[0]
        finish_reason = getattr(choice, "finish_reason", None)
    except Exception:
        finish_reason = None
    return str(finish_reason) if finish_reason else None


def _extract_response_text(response: Any) -> str:
    try:
        content = response.choices[0].message.content
    except Exception:
        content = None
    if isinstance(content, str):
        return content
    return _extract_responses_output_text(response)


def _response_format_name(request_kwargs: dict[str, Any]) -> str | None:
    response_format = request_kwargs.get("response_format")
    if isinstance(response_format, dict):
        return str(response_format.get("type") or "") or None
    return str(response_format) if response_format else None


def _is_gpt_model(model_name: str) -> bool:
    model = str(model_name or "").strip().lower()
    if "/" in model:
        model = model.split("/", 1)[1]
    return model.startswith("gpt")


def _is_gpt5_model(model_name: str) -> bool:
    model = str(model_name or "").strip().lower()
    if "/" in model:
        model = model.split("/", 1)[1]
    return model.startswith("gpt-5")


def _messages_to_responses_input(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    inputs: list[dict[str, Any]] = []
    for message in messages or []:
        role = str(message.get("role") or "user")
        inputs.append({"role": role, "content": message.get("content", "")})
    return inputs


def _extract_responses_output_text(response: Any) -> str:
    output_text = getattr(response, "output_text", None)
    if isinstance(output_text, str) and output_text.strip():
        return output_text
    if isinstance(response, dict):
        output_text = response.get("output_text")
        if isinstance(output_text, str) and output_text.strip():
            return output_text
        output = response.get("output") or []
    else:
        output = getattr(response, "output", None) or []
    texts: list[str] = []
    for item in output:
        content = item.get("content") if isinstance(item, dict) else getattr(item, "content", None)
        for part in content or []:
            text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
            if text:
                texts.append(str(text))
    return "".join(texts)


def _adapt_responses_response(response: Any, model_name: str) -> Any:
    status = response.get("status") if isinstance(response, dict) else getattr(response, "status", None)
    finish_reason = "stop" if status in (None, "completed") else str(status)
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=_extract_responses_output_text(response)),
                finish_reason=finish_reason,
            )
        ],
        usage=response.get("usage") if isinstance(response, dict) else getattr(response, "usage", None),
        model=response.get("model", model_name) if isinstance(response, dict) else getattr(response, "model", model_name),
        raw_response=response,
    )


def _responses_kwargs_from_chat_kwargs(request_kwargs: dict[str, Any], model_name: str) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "model": str(request_kwargs.get("model") or model_name).split("/", 1)[-1],
        "input": _messages_to_responses_input(request_kwargs.get("messages") or []),
    }
    max_output_tokens = request_kwargs.get("max_output_tokens") or request_kwargs.get("max_tokens")
    if max_output_tokens:
        kwargs["max_output_tokens"] = max_output_tokens
    if _is_gpt5_model(model_name):
        reasoning: dict[str, Any] = {"effort": DEFAULT_GPT_REASONING_EFFORT}
        if DEFAULT_GPT_REASONING_EFFORT != "none":
            reasoning["summary"] = "detailed"
        kwargs["reasoning"] = reasoning
        kwargs["text"] = {"verbosity": "high"}
    response_format = request_kwargs.get("response_format")
    if response_format:
        text_config = dict(kwargs.get("text") or {})
        if isinstance(response_format, dict):
            text_config["format"] = dict(response_format)
        else:
            text_config["format"] = {"type": str(response_format)}
        kwargs["text"] = text_config
    prompt_cache_key = request_kwargs.get("prompt_cache_key")
    if prompt_cache_key:
        kwargs["prompt_cache_key"] = str(prompt_cache_key)
    prompt_cache_retention = request_kwargs.get("prompt_cache_retention")
    if prompt_cache_retention in {"in-memory", "24h"}:
        kwargs["prompt_cache_retention"] = prompt_cache_retention
    return kwargs


def _chat_kwargs_for_provider(request_kwargs: dict[str, Any]) -> dict[str, Any]:
    kwargs = dict(request_kwargs)
    messages = []
    for message in kwargs.get("messages") or []:
        if not isinstance(message, dict):
            continue
        messages.append(
            {
                "role": str(message.get("role") or "user"),
                "content": message.get("content", ""),
            }
        )
    if messages:
        kwargs["messages"] = messages
    return kwargs


def _merge_trace_usage_context(
    usage_info: dict[str, Any],
    trace_usage_context: dict[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(trace_usage_context, dict):
        return usage_info
    merged = dict(usage_info)
    for key in ("prompt_segments", "cache_metrics", "prompt_firewall"):
        value = trace_usage_context.get(key)
        if value is not None:
            merged[key] = value
    return merged


def _should_retry_with_high_reasoning(exc: Exception, request_kwargs: dict[str, Any]) -> bool:
    reasoning = request_kwargs.get("reasoning") or {}
    effort = str(reasoning.get("effort", "")).lower()
    if not effort or effort == FALLBACK_GPT_REASONING_EFFORT:
        return False
    text = str(exc).lower()
    return effort in text and any(
        marker in text
        for marker in ("reasoning", "effort", "invalid", "unsupported", "not supported")
    )


def _with_high_reasoning(request_kwargs: dict[str, Any]) -> dict[str, Any]:
    fallback = dict(request_kwargs)
    reasoning = dict(fallback.get("reasoning") or {})
    reasoning["effort"] = FALLBACK_GPT_REASONING_EFFORT
    if FALLBACK_GPT_REASONING_EFFORT != "none":
        reasoning.setdefault("summary", "detailed")
    fallback["reasoning"] = reasoning
    return fallback


def _is_retryable(exc: Exception) -> bool:
    text = f"{type(exc).__name__}: {exc}".lower()
    return any(
        marker in text
        for marker in (
            "timeout",
            "temporarily",
            "too busy",
            "service_unavailable",
            "rate limit",
            "ratelimit",
            "429",
            "500",
            "502",
            "503",
            "504",
            "connection",
            "connect",
            "server error",
            "internalservererror",
        )
    )
