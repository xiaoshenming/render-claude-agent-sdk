"""Consume provider-specific streams into a safe in-memory buffer."""

import logging
import time
from typing import Any

logger = logging.getLogger(__name__)


async def consume_responses_stream(
    response: Any,
    *,
    backend: Any,
    usage: dict,
    chunks: list[str],
    deps: Any,
) -> list[str]:
    started = False
    first_timeout = deps.first_content_timeout(backend.effective_timeout)
    idle_timeout = deps.idle_timeout(backend.effective_timeout)
    deadline = time.monotonic() + first_timeout
    response_stream = response.__aiter__()
    terminal_seen = False
    while True:
        try:
            event = await deps.next_item(
                response_stream,
                deadline=deadline,
                timeout_seconds=idle_timeout if started else first_timeout,
                stream_started=started,
                usage_info=usage,
            )
        except StopAsyncIteration:
            break
        error_message = deps.responses_error(event)
        if error_message:
            raise RuntimeError(f"Responses API stream failed: {error_message}")
        event_type = str(deps.get_value(event, "type", "") or "")
        if event_type in {"response.completed", "response.incomplete"}:
            terminal_seen = True
            event_response = deps.get_value(event, "response")
            deps.collect_responses_usage(event_response, usage)
            if not started:
                completed_text = deps.responses_output(event_response)
                if completed_text:
                    started = True
                    chunks.append(completed_text)
            if usage.get("finish_reason") == "length":
                logger.warning(
                    "Responses API stream 输出因 max_tokens 截断: backend=%s",
                    backend.name,
                )
            continue
        text_delta = deps.responses_delta(event)
        if text_delta:
            started = True
            deadline = time.monotonic() + idle_timeout
            chunks.append(text_delta)
    if not terminal_seen:
        if started:
            usage.update(
                stream_missing_terminal_event=True,
                finish_reason="missing_terminal_event",
                quality_result="suspect_missing_terminal",
            )
            logger.warning(
                "Responses API stream ended without terminal event; passing buffered "
                "content to downstream validators: backend=%s chunks=%s",
                backend.name,
                len(chunks),
            )
        else:
            raise deps.incomplete_error(
                "Responses API stream ended without terminal event",
                usage_info=dict(usage),
            )
    finish_reason = usage.get("finish_reason")
    if finish_reason and finish_reason not in {"stop", "missing_terminal_event"}:
        raise deps.incomplete_error(
            f"Responses API stream incomplete: {finish_reason}",
            usage_info=dict(usage),
        )
    return chunks


async def consume_chat_stream(
    response: Any,
    *,
    backend: Any,
    usage: dict,
    chunks: list[str],
    deps: Any,
) -> list[str]:
    started = False
    first_timeout = deps.first_content_timeout(backend.effective_timeout)
    idle_timeout = deps.idle_timeout(backend.effective_timeout)
    deadline = time.monotonic() + first_timeout
    response_stream = response.__aiter__()
    while True:
        try:
            chunk = await deps.next_item(
                response_stream,
                deadline=deadline,
                timeout_seconds=idle_timeout if started else first_timeout,
                stream_started=started,
                usage_info=usage,
            )
        except StopAsyncIteration:
            break
        deps.collect_chat_usage(chunk, usage)
        choices = getattr(chunk, "choices", None) or []
        if not choices:
            continue
        choice = choices[0]
        delta = getattr(choice, "delta", None)
        if delta and delta.content:
            started = True
            deadline = time.monotonic() + idle_timeout
            chunks.append(delta.content)
        finish_reason = getattr(choice, "finish_reason", None)
        if finish_reason:
            usage["finish_reason"] = finish_reason
            if finish_reason == "length":
                logger.warning(
                    "LLM stream 输出因 max_tokens 截断: backend=%s",
                    backend.name,
                )
    return chunks
