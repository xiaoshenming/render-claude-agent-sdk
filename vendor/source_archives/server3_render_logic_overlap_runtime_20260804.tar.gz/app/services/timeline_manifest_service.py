"""Compatibility facade for canonical video timeline manifests."""

import sys

from app.services import timeline_manifest_builder as _builder
from app.services import timeline_manifest_core as _core
from app.services import timeline_manifest_resolver as _resolver

_builder.facade_provider = lambda: sys.modules[__name__]

SCHEMA_VERSION = _core.SCHEMA_VERSION
TIMEBASE = _core.TIMEBASE
PRECISION_MS = _core.PRECISION_MS
FPS = _core.FPS
MIN_DRIFT_THRESHOLD_SEC = _core.MIN_DRIFT_THRESHOLD_SEC
_EPSILON = _core._EPSILON

_round_seconds = _core._round_seconds
_finite_float = _core._finite_float
_nonnegative_float = _core._nonnegative_float
_positive_float = _core._positive_float
_get = _core._get
_first_float = _core._first_float
_slice_index = _core._slice_index
_copy_items = _core._copy_items
_timing_source_start_sec = _core._timing_source_start_sec
_parent_manifest_id = _core._parent_manifest_id
_parent_slices_by_index = _core._parent_slices_by_index
_probe_duration_sec = _core._probe_duration_sec
_normalize_bookmarks = _core._normalize_bookmarks
_normalize_words = _core._normalize_words
_normalize_windows = _core._normalize_windows
compute_manifest_hash = _core.compute_manifest_hash

build_timeline_manifest = _builder.build_timeline_manifest
validate_duration_drift = _resolver.validate_duration_drift
resolve_timestamp = _resolver.resolve_timestamp
_contains = _resolver._contains
_resolve_window = _resolver._resolve_window
_resolve_bookmark = _resolver._resolve_bookmark
_resolve_word = _resolver._resolve_word
_merge_window_result = _resolver._merge_window_result
_merge_bookmark_result = _resolver._merge_bookmark_result
_merge_word_result = _resolver._merge_word_result
