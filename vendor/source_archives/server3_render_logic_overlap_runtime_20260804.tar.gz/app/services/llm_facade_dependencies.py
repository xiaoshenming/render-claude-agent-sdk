"""Build call-time dependency views from the compatibility facade."""

from types import SimpleNamespace
from typing import Any


def nonstream_dependencies(svc: Any) -> SimpleNamespace:
    common = {
        "acompletion": svc.litellm.acompletion,
        "cancelled_message": svc._cancelled_error_message,
        "classify_error": svc._classify_error,
        "completion_cost": svc._safe_completion_cost,
        "empty_response_error": svc.LLMEmptyResponseError,
        "extract_content": svc._extract_message_content,
        "extract_usage": svc._extract_usage_info,
        "fail_fast": svc._ErrorAction.FAIL_FAST,
        "next_backend": svc._ErrorAction.NEXT_BACKEND,
        "next_key": svc._ErrorAction.NEXT_KEY,
        "now": svc._beijing_now,
        "provider_cancelled_error": svc.LLMProviderCancelledError,
        "task_cancellation_requested": svc._task_cancellation_requested,
        "usage_with_context": svc._usage_info_with_trace_context,
    }

    def for_attempt(**overrides: Any) -> SimpleNamespace:
        return SimpleNamespace(**{**common, **overrides})

    return SimpleNamespace(
        configured_max_tokens=svc._configured_max_output_tokens,
        empty_response_error=svc.LLMEmptyResponseError,
        extra_kwargs=svc._litellm_extra_kwargs_for_call,
        fail_fast=svc._ErrorAction.FAIL_FAST,
        for_attempt=for_attempt,
        messages_for_provider=svc._messages_for_provider,
        next_backend=svc._ErrorAction.NEXT_BACKEND,
        next_key=svc._ErrorAction.NEXT_KEY,
        responses_cache=svc._responses_prompt_cache_kwargs,
        with_cache_context=svc._trace_context_with_provider_cache_params,
        with_provider_policy=svc._trace_context_with_quality_provider_policy,
    )


def stream_dependencies(svc: Any) -> SimpleNamespace:
    return SimpleNamespace(
        acompletion=svc.litellm.acompletion,
        await_open=svc._await_stream_open,
        cancelled_message=svc._cancelled_error_message,
        classify_error=svc._classify_error,
        collect_chat_usage=svc._collect_stream_usage,
        collect_responses_usage=svc._collect_responses_stream_usage,
        configured_max_tokens=svc._configured_max_output_tokens,
        empty_response_error=svc.LLMEmptyResponseError,
        extra_kwargs=svc._litellm_extra_kwargs_for_call,
        fail_fast=svc._ErrorAction.FAIL_FAST,
        first_content_timeout=svc._stream_first_content_timeout,
        get_value=svc._get_value,
        idle_timeout=svc._stream_idle_timeout,
        incomplete_error=svc.LLMStreamIncompleteError,
        messages_for_provider=svc._messages_for_provider,
        next_backend=svc._ErrorAction.NEXT_BACKEND,
        next_item=svc._next_stream_item,
        next_key=svc._ErrorAction.NEXT_KEY,
        now=svc._beijing_now,
        open_timeout=svc._stream_open_timeout,
        provider_cancelled_error=svc.LLMProviderCancelledError,
        responses_cache=svc._responses_prompt_cache_kwargs,
        responses_delta=svc._responses_stream_delta,
        responses_error=svc._responses_stream_error,
        responses_output=svc._extract_responses_output_text,
        task_cancellation_requested=svc._task_cancellation_requested,
        with_provider_policy=svc._trace_context_with_quality_provider_policy,
    )
