"""Generic LLM manager whose compatibility symbols are supplied by its facade."""

import logging
from typing import Any, AsyncGenerator, Callable

from app.services.llm_manager_health import LLMManagerHealth
from app.services.llm_nonstream_runner import run_nonstream_call
from app.services.llm_responses_client import ResponsesClientAdapter
from app.services.llm_stream_runner import run_stream_call

logger = logging.getLogger(__name__)


class LLMManagerFacade:
    def __init__(self, facade: Callable[[], Any], backend_loader: Callable | None = None):
        self._facade = facade
        self._backend_loader = backend_loader
        self._backends = None
        self._last_success = None
        self._backend_cooldowns: dict[str, float] = {}

    @property
    def backends(self) -> list:
        if self._backends is None:
            loader = self._backend_loader or self._facade()._load_backends
            self._backends = loader()
        return self._backends

    def _health_controller(self) -> LLMManagerHealth:
        svc = self._facade()
        return LLMManagerHealth(
            self,
            config=svc.settings,
            registry=svc.backend_health_registry,
            now=svc._beijing_now,
            health_disabled=svc._backend_health_disabled,
            bypass_cooldown=svc._bypass_backend_cooldown_for_call_type,
            generation_validation_error=svc._is_generation_validation_error,
            permanent_backend_unavailable=svc._is_permanent_backend_unavailable,
            should_cooldown=svc._should_cooldown_backend,
        )

    def _ordered_backends(self) -> list:
        return self._health_controller().ordered_backends()

    def _cooldown_payload(self, backend: Any, call_type: str) -> dict | None:
        return self._health_controller().cooldown_payload(backend, call_type)

    def _cooldown_attempt(self, backend: Any, call_type: str, payload: dict) -> dict:
        return self._health_controller().cooldown_attempt(backend, call_type, payload)

    def _mark_success(
        self, name: str, *, model: str | None = None, call_type: str | None = None
    ) -> None:
        self._health_controller().mark_success(name, model=model, call_type=call_type)

    def _mark_transient_failure(
        self,
        backend: Any,
        exc: Exception,
        *,
        call_type: str,
        force: bool = False,
    ) -> None:
        self._health_controller().mark_transient_failure(
            backend, exc, call_type=call_type, force=force
        )

    def reload(self, *, clear_health: bool = False) -> None:
        self._health_controller().reload(clear_health=clear_health)

    def _build_tracer(self, *, messages: list, trace_enabled: bool, **trace: Any):
        if not trace_enabled:
            return None
        svc = self._facade()
        try:
            kwargs = {
                "job_id": trace.get("trace_job_id") or "unknown",
                "call_type": trace.get("trace_call_type") or "llm_call",
                "prompt_version": trace.get("trace_prompt_version"),
            }
            if trace.get("trace_response_format"):
                kwargs["response_format"] = trace["trace_response_format"]
            try:
                tracer = svc.LLMCallTracer(**kwargs)
            except TypeError:
                kwargs.pop("response_format", None)
                tracer = svc.LLMCallTracer(**kwargs)
            tracer.start()
            tracer.set_prompt_hash(
                trace.get("trace_prompt_content")
                if trace.get("trace_prompt_content") is not None
                else svc._messages_to_prompt_content(messages)
            )
            if hasattr(tracer, "set_request_messages"):
                tracer.set_request_messages(messages)
            return tracer
        except Exception as exc:
            logger.warning("[LLM_TRACE] 初始化失败: %s", exc)
            return None

    async def _record_trace_attempts(self, tracer: Any, attempts: list[dict]) -> None:
        if tracer is None or not attempts:
            return
        try:
            await tracer.record_attempts(list(attempts))
        except Exception as exc:
            logger.warning("[LLM_TRACE] 记录 attempts 失败: %s", exc)

    def _responses_client(self) -> ResponsesClientAdapter:
        svc = self._facade()
        return ResponsesClientAdapter(
            client_type=svc.AsyncOpenAI,
            stream_timeout=svc._responses_stream_client_timeout,
            should_retry_high=svc._should_retry_with_high_reasoning,
            with_high_reasoning=svc._with_high_reasoning,
            default_reasoning_effort=svc.DEFAULT_GPT_REASONING_EFFORT,
        )

    async def _call_responses_api(self, **kwargs: Any) -> Any:
        return await self._responses_client().call(**kwargs)

    async def _call_responses_api_stream(self, **kwargs: Any) -> Any:
        return await self._responses_client().call_stream(**kwargs)

    async def call(
        self,
        messages: list,
        max_tokens: int,
        retry_budget: int,
        trace_job_id: str | None = None,
        trace_call_type: str = "llm_call",
        trace_prompt_version: str | None = None,
        trace_prompt_content: str | None = None,
        trace_response_format: str | None = None,
        trace_usage_context: dict | None = None,
        trace_enabled: bool = True,
    ):
        svc = self._facade()
        tracer = self._build_tracer(
            messages=messages,
            trace_job_id=trace_job_id,
            trace_call_type=trace_call_type,
            trace_prompt_version=trace_prompt_version,
            trace_prompt_content=trace_prompt_content,
            trace_response_format=trace_response_format,
            trace_enabled=trace_enabled,
        )
        return await run_nonstream_call(
            self,
            messages=messages,
            max_tokens=max_tokens,
            retry_budget=retry_budget,
            trace_call_type=trace_call_type,
            trace_usage_context=trace_usage_context,
            tracer=tracer,
            deps=svc._nonstream_dependencies(),
        )

    async def call_stream(
        self,
        messages: list,
        max_tokens: int,
        retry_budget: int = 1,
        usage_collector: dict | None = None,
        trace_collector: dict | None = None,
        attempt_collector: list[dict] | None = None,
        trace_job_id: str | None = None,
        trace_call_type: str = "llm_stream",
        trace_prompt_version: str | None = None,
        trace_prompt_content: str | None = None,
        trace_response_format: str | None = None,
        trace_usage_context: dict | None = None,
        trace_enabled: bool = True,
        excluded_backend_names: Any = None,
    ) -> AsyncGenerator[str, None]:
        svc = self._facade()
        usage = usage_collector if usage_collector is not None else {}
        trace_context = trace_usage_context
        if isinstance(trace_context, dict):
            for key in ("prompt_segments", "cache_metrics", "prompt_firewall"):
                if key not in usage and key in trace_context:
                    usage[key] = trace_context[key]
        attempts = attempt_collector if attempt_collector is not None else []
        tracer = self._build_tracer(
            messages=messages,
            trace_job_id=trace_job_id,
            trace_call_type=trace_call_type,
            trace_prompt_version=trace_prompt_version,
            trace_prompt_content=trace_prompt_content,
            trace_response_format=trace_response_format,
            trace_enabled=trace_enabled,
        )
        async for chunk in run_stream_call(
            self,
            messages=messages,
            max_tokens=max_tokens,
            retry_budget=retry_budget,
            usage=usage,
            trace_collector=trace_collector,
            attempts=attempts,
            tracer=tracer,
            trace_call_type=trace_call_type,
            trace_usage_context=trace_context,
            excluded_backend_names=excluded_backend_names,
            deps=svc._stream_dependencies(),
        ):
            yield chunk
