"""统一 AI 安全护栏。

本模块只做确定性规则拦截，不调用额外模型。定位是补足内容安全审核之外的
Prompt Injection、上下文填充绕过、密钥/系统提示词探测和模型身份泄露防护。
"""
from __future__ import annotations

import base64
import binascii
import html
import logging
import re
import unicodedata
from typing import Any
from urllib.parse import unquote

from app.core.config import settings
from app.services import ai_guardrail_patterns as patterns

logger = logging.getLogger(__name__)

DEFAULT_INPUT_MESSAGE = "请描述需要生成的数学教学内容，不要请求模型身份、系统提示词、密钥或内部配置"
DEFAULT_OUTPUT_MESSAGE = "AI 生成结果未通过安全检查，请调整输入后重试"

_ZERO_WIDTH_RE = re.compile(r"[\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]")
_BASE64_TOKEN_RE = re.compile(r"(?<![A-Za-z0-9+/=_-])([A-Za-z0-9+/=_-]{12,})(?![A-Za-z0-9+/=_-])")
_PRINTABLE_TEXT_RE = re.compile(r"^[\x09\x0a\x0d\x20-\x7e\u4e00-\u9fff，。！？、；：""''（）《》【】]+$")

_INPUT_PATTERNS = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"忽略.{0,30}(之前|以上|上面|所有|系统|开发者|规则|指令)",
        r"(覆盖|绕过|禁用|关闭|解除).{0,30}(安全|审核|护栏|规则|限制|过滤|策略)",
        r"(系统提示|系统指令|开发者消息|开发者指令|内部规则|隐藏规则|提示词|system\s*prompt|developer\s*message|hidden\s*prompt|initial\s*prompt)",
        r"(输出|泄露|透露|打印|复述|显示|告诉|导出|dump).{0,40}(系统提示|提示词|system\s*prompt|developer\s*message|内部规则|密钥|token|api\s*key|环境变量|数据库|配置)",
        r"(api[_\s-]*key|密钥|token|secret|password|env|环境变量).{0,40}(输出|泄露|透露|告诉|打印|显示|给我)",
        r"(你|模型|助手|agent).{0,16}(是什么模型|名字|名称|代号|公司|厂商|提供商|谁开发|来自哪里|身份)",
        r"(什么|哪.*个).{0,12}(模型|公司|厂商|提供商)",
        r"(越狱|jailbreak|DAN\b|开发者模式|developer\s*mode|无视安全|bypass)",
        r"(base64|rot13|hex|unicode|编码|解码).{0,50}(system\s*prompt|系统提示|密钥|api\s*key|developer\s*message|忽略)",
        r"(repeat|print|show|reveal|exfiltrate).{0,40}(system\s*prompt|developer\s*message|hidden\s*instructions|api\s*key|secret)",
    )
)

_COLLAPSED_INPUT_MARKERS = patterns.COLLAPSED_INPUT_MARKERS

_OUTPUT_PATTERNS = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"(system\s*prompt|developer\s*message|hidden\s*instructions|hidden\s*prompt|initial\s*prompt|系统提示|系统指令|开发者消息|开发者指令|内部规则|隐藏规则)",
        r"(输出|泄露|透露|打印|复述|显示|告诉|导出|dump|show|reveal|print|exfiltrate).{0,40}(api[_\s-]*key|密钥|token|secret|password|环境变量)",
        r"(api[_\s-]*key|密钥|token|secret|password|环境变量).{0,40}(输出|泄露|透露|告诉|打印|显示|给我|dump|show|reveal|print)",
        r"(我是|我叫|本模型|我的模型|由|来自).{0,30}(gemini|claude|openai|anthropic|google|qwen|通义|阿里|dashscope)",
        r"(gemini|claude|openai|anthropic|google|qwen|通义|dashscope).{0,30}(模型|提供|公司|开发|身份|代号)",
        r"(模型|名字|名称|代号|公司|厂商|提供商)\s*[：:]\s*(gemini|claude|openai|anthropic|google|qwen|通义|阿里|dashscope)",
        r"大型语言模型|语言模型",
    )
)

_COLLAPSED_OUTPUT_MARKERS = patterns.COLLAPSED_OUTPUT_MARKERS


class AIGuardrailViolation(ValueError):
    """AI 护栏命中。"""

    def __init__(
        self,
        message: str,
        *,
        reason: str,
        scenario: str = "general",
        field: str = "text",
    ) -> None:
        super().__init__(message)
        self.reason = reason
        self.scenario = scenario
        self.field = field


def _enabled() -> bool:
    return bool(getattr(settings, "AI_GUARDRAIL_ENABLED", True))


def _strict_output_enabled() -> bool:
    return bool(getattr(settings, "AI_GUARDRAIL_STRICT_OUTPUT_ENABLED", True))


def _normalize(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", text or "")
    normalized = html.unescape(unquote(normalized))
    normalized = _ZERO_WIDTH_RE.sub("", normalized)
    return normalized.strip()


def _collapsed(text: str) -> str:
    return re.sub(r"[\W_]+", "", text.lower(), flags=re.UNICODE)


def _try_decode_base64(token: str) -> str | None:
    cleaned = token.strip().replace("-", "+").replace("_", "/")
    if len(cleaned) < 12:
        return None
    padding = "=" * ((4 - len(cleaned) % 4) % 4)
    try:
        decoded = base64.b64decode(cleaned + padding, validate=False)
        text = decoded.decode("utf-8", errors="ignore").strip()
    except (binascii.Error, UnicodeDecodeError, ValueError):
        return None
    if len(text) < 4 or len(text) > 500:
        return None
    if not _PRINTABLE_TEXT_RE.match(text):
        return None
    return text


def _text_variants(text: str) -> list[str]:
    normalized = _normalize(text)
    variants = [normalized]
    for token in _BASE64_TOKEN_RE.findall(normalized):
        decoded = _try_decode_base64(token)
        if decoded:
            variants.append(_normalize(decoded))
    return variants


def _custom_patterns() -> list[re.Pattern[str]]:
    raw = str(getattr(settings, "AI_GUARDRAIL_CUSTOM_BLOCK_PATTERNS", "") or "")
    patterns: list[re.Pattern[str]] = []
    for item in re.split(r"[\n|]+", raw):
        item = item.strip()
        if not item:
            continue
        try:
            patterns.append(re.compile(item, re.IGNORECASE))
        except re.error as exc:
            logger.warning("Invalid AI guardrail custom pattern ignored: %s", exc)
    return patterns


def _check_patterns(
    text: str,
    *,
    patterns: tuple[re.Pattern[str], ...],
    collapsed_markers: tuple[str, ...],
) -> str | None:
    for variant in _text_variants(text):
        lowered = variant.lower()
        for pattern in patterns:
            if pattern.search(lowered):
                return f"pattern:{pattern.pattern[:48]}"
        compact = _collapsed(variant)
        for marker in collapsed_markers:
            if marker in compact:
                return f"marker:{marker}"
        for pattern in _custom_patterns():
            if pattern.search(variant):
                return f"custom:{pattern.pattern[:48]}"
    return None


def _looks_like_context_overflow_attack(text: str) -> bool:
    normalized = _normalize(text)
    limit = int(getattr(settings, "AI_GUARDRAIL_CONTEXT_OVERFLOW_CHARS", 8000) or 8000)
    if len(normalized) < limit:
        return False
    tail = normalized[-2000:]
    if _check_patterns(
        tail,
        patterns=_INPUT_PATTERNS,
        collapsed_markers=_COLLAPSED_INPUT_MARKERS,
    ):
        return True
    repeated = re.search(r"(.{3,40})\1{20,}", normalized, re.DOTALL)
    return bool(repeated and _check_patterns(
        normalized,
        patterns=_INPUT_PATTERNS,
        collapsed_markers=_COLLAPSED_INPUT_MARKERS,
    ))


def guard_ai_user_input(
    text: str | None,
    *,
    scenario: str = "general",
    field: str = "text",
    public_message: str = DEFAULT_INPUT_MESSAGE,
) -> str:
    """校验用户传入 AI 的文本，返回 strip 后文本。"""
    value = (text or "").strip()
    if not _enabled() or not value:
        return value

    max_chars = int(getattr(settings, "AI_GUARDRAIL_INPUT_MAX_CHARS", 12000) or 12000)
    if len(value) > max_chars:
        raise AIGuardrailViolation(
            public_message,
            reason="input_too_long",
            scenario=scenario,
            field=field,
        )

    if _looks_like_context_overflow_attack(value):
        raise AIGuardrailViolation(
            public_message,
            reason="context_overflow_injection",
            scenario=scenario,
            field=field,
        )

    reason = _check_patterns(
        value,
        patterns=_INPUT_PATTERNS,
        collapsed_markers=_COLLAPSED_INPUT_MARKERS,
    )
    if reason:
        raise AIGuardrailViolation(
            public_message,
            reason=reason,
            scenario=scenario,
            field=field,
        )
    return value


def guard_ai_output(
    text: str | None,
    *,
    scenario: str = "general",
    field: str = "output",
    public_message: str = DEFAULT_OUTPUT_MESSAGE,
) -> str:
    """校验 AI 输出文本，返回原始文本。"""
    value = text or ""
    if not _enabled() or not _strict_output_enabled() or not value:
        return value

    reason = _check_patterns(
        value,
        patterns=_OUTPUT_PATTERNS,
        collapsed_markers=_COLLAPSED_OUTPUT_MARKERS,
    )
    if reason:
        raise AIGuardrailViolation(
            public_message,
            reason=reason,
            scenario=scenario,
            field=field,
        )
    return value


def guard_ai_payload(
    payload: Any,
    *,
    scenario: str = "general",
    public_message: str = DEFAULT_OUTPUT_MESSAGE,
    max_depth: int = 8,
) -> Any:
    """递归检查 AI 输出 payload 中的字符串。"""
    if not _enabled() or not _strict_output_enabled():
        return payload

    def walk(value: Any, path: str, depth: int) -> None:
        if depth > max_depth:
            return
        if isinstance(value, str):
            guard_ai_output(
                value,
                scenario=scenario,
                field=path,
                public_message=public_message,
            )
            return
        if isinstance(value, dict):
            for key, item in value.items():
                walk(item, f"{path}.{key}", depth + 1)
            return
        if isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, f"{path}[{index}]", depth + 1)

    walk(payload, "$", 0)
    return payload
