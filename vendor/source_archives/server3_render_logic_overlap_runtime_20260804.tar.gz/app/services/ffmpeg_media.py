"""Media probing and normalization helpers."""
import json
from typing import Any, Callable

NORMALIZED_FPS = 30
facade_provider: Callable[[], Any] | None = None

def _runner():
    return facade_provider().run_cmd_async

def _parse_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _normalize_target_resolution(
    target_resolution: tuple[int, int] | list[int] | None,
) -> tuple[int, int] | None:
    if target_resolution is None:
        return None
    if len(target_resolution) != 2:
        raise ValueError("target_resolution must contain width and height")
    width, height = int(target_resolution[0]), int(target_resolution[1])
    if width <= 0 or height <= 0:
        raise ValueError("target_resolution width and height must be positive")
    return width, height


def _video_filter(
    target_resolution: tuple[int, int] | list[int] | None = None,
) -> str:
    resolution = _normalize_target_resolution(target_resolution)
    filters = [
        f"fps={NORMALIZED_FPS}",
        f"setpts=N/({NORMALIZED_FPS}*TB)",
    ]
    if resolution:
        width, height = resolution
        filters.extend([f"scale={width}:{height}:flags=lanczos", "setsar=1"])
    filters.append("format=yuv420p")
    return ",".join(filters)


async def _probe_media(path: str, *, require_audio: bool = False) -> dict:
    """Return ffprobe stream/format metadata for diagnostics and validation."""
    probe_cmd = [
        "ffprobe", "-v", "error",
        "-show_entries",
        "format=duration:stream=index,codec_type,codec_name,duration,start_time,time_base,avg_frame_rate,sample_rate",
        "-of", "json", path,
    ]
    probe = await facade_provider().run_cmd_async(probe_cmd, timeout=10)
    if probe.returncode != 0:
        raise RuntimeError(probe.stderr[:300] if probe.stderr else "ffprobe failed")
    try:
        data = json.loads(probe.stdout or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"ffprobe json parse failed: {exc}") from exc
    streams = data.get("streams") or []
    video_stream = next((s for s in streams if s.get("codec_type") == "video"), None)
    if not video_stream:
        raise RuntimeError("missing video stream")
    if require_audio and not any(s.get("codec_type") == "audio" for s in streams):
        raise RuntimeError("missing audio stream")
    return data


def _media_duration(probe: dict) -> float:
    fmt = probe.get("format") or {}
    duration = _parse_float(fmt.get("duration"))
    if duration > 0:
        return duration
    return max((_parse_float(s.get("duration")) for s in probe.get("streams") or []), default=0.0)


def _video_duration(probe: dict) -> float:
    for stream in probe.get("streams") or []:
        if stream.get("codec_type") == "video":
            duration = _parse_float(stream.get("duration"))
            if duration > 0:
                return duration
    return _media_duration(probe)


def _has_audio(probe: dict) -> bool:
    return any(s.get("codec_type") == "audio" for s in probe.get("streams") or [])


def _audio_duration(probe: dict) -> float:
    return max(
        (
            _parse_float(stream.get("duration"))
            for stream in probe.get("streams") or []
            if stream.get("codec_type") == "audio"
        ),
        default=0.0,
    )


def _stream_summary(probe: dict) -> str:
    parts: list[str] = []
    for stream in probe.get("streams") or []:
        kind = stream.get("codec_type", "?")
        if kind == "video":
            parts.append(
                "v:"
                f"{stream.get('codec_name', '?')} "
                f"tb={stream.get('time_base', '?')} "
                f"fps={stream.get('avg_frame_rate', '?')} "
                f"start={stream.get('start_time', '?')} "
                f"dur={stream.get('duration', '?')}"
            )
        elif kind == "audio":
            parts.append(
                "a:"
                f"{stream.get('codec_name', '?')} "
                f"sr={stream.get('sample_rate', '?')} "
                f"tb={stream.get('time_base', '?')} "
                f"start={stream.get('start_time', '?')} "
                f"dur={stream.get('duration', '?')}"
            )
    return "; ".join(parts) or "no streams"


async def probe_media_summary(path: str, *, require_audio: bool = False) -> dict:
    """Return compact media evidence for quality_events."""
    probe = await _probe_media(path, require_audio=require_audio)
    video_duration = _video_duration(probe)
    audio_present = _has_audio(probe)
    audio_duration = _audio_duration(probe) if audio_present else 0.0
    return {
        "video_duration_sec": round(video_duration, 3),
        "audio_duration_sec": round(audio_duration, 3) if audio_present else None,
        "duration_delta_sec": (
            round(abs(video_duration - audio_duration), 3)
            if audio_present else None
        ),
        "audio_present": audio_present,
        "ffprobe_streams": _stream_summary(probe),
    }


def _normalize_timeout(total_duration: float) -> int:
    # Re-encoding is intentionally bounded, but longer videos need more than
    # the previous 120s concat-copy budget.
    return max(180, min(900, int(total_duration * 3 + 120)))
