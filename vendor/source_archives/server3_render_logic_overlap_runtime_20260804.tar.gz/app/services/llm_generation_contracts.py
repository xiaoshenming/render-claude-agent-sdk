"""LLM generation configuration and compiled-prompt helpers."""
# ruff: noqa: F401
from app.core.config import settings
from app.prompts.prompt_factory import get_prompt_template
from app.prompts.prompt_compiler import PromptCompiler

DEFAULT_LLM_MAX_OUTPUT_TOKENS=65536

def configured_max_output_tokens() -> int:
    value = getattr(settings, "LLM_MAX_OUTPUT_TOKENS", DEFAULT_LLM_MAX_OUTPUT_TOKENS)
    return max(1, int(value or DEFAULT_LLM_MAX_OUTPUT_TOKENS))


def _mgr():
    """Lazy accessor — avoids circular import with llm_service."""
    from app.services.llm_service import _llm_manager
    return _llm_manager


def _provider_cache_messages_enabled() -> bool:
    return bool(getattr(settings, "RENDER_SKILL_OS_PROVIDER_CACHE_MESSAGES", False))


def _block_first_assembly_enabled() -> bool:
    return bool(getattr(settings, "RENDER_SKILL_OS_BLOCK_FIRST_ASSEMBLY", False))


def _no_template_assembly_enabled() -> bool:
    return bool(getattr(settings, "RENDER_SKILL_OS_NO_TEMPLATE_ASSEMBLY", False))


def _prompt_compiler_for_skill_context(skill_context: dict | None):
    from app.services import llm_generation as facade

    if (
        isinstance(skill_context, dict)
        and skill_context.get("mode") == "enterprise_authoritative"
    ):
        from app.enterprise_delivery.prompt_compiler_v0211 import (
            PromptCompiler as EnterpriseV0211PromptCompiler,
        )

        return EnterpriseV0211PromptCompiler(template_resolver=facade.get_prompt_template)
    return PromptCompiler(template_resolver=facade.get_prompt_template)


def _messages_for_compiled_prompt(compile_result) -> list[dict]:
    from app.services import llm_generation as facade

    if compile_result.cache_metrics.get("assembly_mode") in {
        "block_first",
        "no_template_skill_graph",
    }:
        return list(compile_result.cacheable_messages)
    if facade._provider_cache_messages_enabled():
        return list(compile_result.cacheable_messages)
    return [{"role": "user", "content": compile_result.prompt_content}]


def _trace_usage_context_for_compiled_prompt(compile_result) -> dict:
    from app.services import llm_generation as facade

    cache_metrics = dict(compile_result.cache_metrics)
    cache_metrics["provider_cache_messages_enabled"] = facade._provider_cache_messages_enabled()
    return {
        "prompt_segments": compile_result.prompt_segments,
        "cache_metrics": cache_metrics,
        "prompt_firewall": compile_result.firewall_report,
    }


def extract_usage_details(response) -> dict:
    """从 LiteLLM response 提取详细 token 统计。

    返回 dict 包含:
        total_tokens, input_tokens, output_tokens,
        cache_read_tokens, cache_creation_tokens, cache_miss_tokens,
        provider_usage_raw
    """
    from app.services.llm_service import _extract_usage_info

    return _extract_usage_info(response)


# ---------------------------------------------------------------------------
# Public API — signature-compatible with the old version
# ---------------------------------------------------------------------------
