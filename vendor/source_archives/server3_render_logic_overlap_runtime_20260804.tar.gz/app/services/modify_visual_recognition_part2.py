"""后台二次修改视觉识别服务。

该服务只为修改 prompt 提供高置信度视觉参考。任何配置缺失、抽帧失败、
多模态调用失败、JSON 解析失败或低置信度结果都会 fail-open 返回 None。
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import tempfile
from pathlib import Path
from typing import Any, Mapping

logger = logging.getLogger(__name__)

TRACE_CALL_TYPE = "modify_visual_recognition"
MIN_CONFIDENCE = 0.65



def _video_source_from_source(source: Mapping[str, Any]) -> str:
    for key in (
        "local_video_path",
        "video_path",
        "mp4_path",
        "source_video_path",
        "video_url",
        "url",
    ):
        value = str(source.get(key) or "").strip()
        if value:
            return value
    return ""
def _resolve_offset_seconds(slice_state: Mapping[str, Any]) -> float:
    direct = _as_float(slice_state.get("local_offset_seconds"))
    if direct is not None:
        return max(0.0, direct)
    for annotation in slice_state.get("annotations") or []:
        if not isinstance(annotation, Mapping):
            continue
        value = _as_float(annotation.get("local_offset_seconds"))
        if value is not None:
            return max(0.0, value)
    for target in _target_items(slice_state.get("target")):
        value = _as_float(target.get("local_offset_seconds"))
        if value is not None:
            return max(0.0, value)
    for annotation in slice_state.get("annotations") or []:
        if not isinstance(annotation, Mapping):
            continue
        value = _as_float(annotation.get("timestamp_seconds"))
        if value is not None:
            return max(0.0, value)
    return 0.0
def _target_items(value: Any) -> list[Mapping[str, Any]]:
    if isinstance(value, Mapping):
        return [value]
    if isinstance(value, list):
        return [item for item in value if isinstance(item, Mapping)]
    return []
def _as_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
def _image_data_url(path: Path) -> str:
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"
def _visual_anchors_from_slice_state(slice_state: Mapping[str, Any]) -> list[dict[str, Any]]:
    anchors: list[dict[str, Any]] = []
    direct = slice_state.get("visual_anchors")
    if isinstance(direct, list):
        anchors.extend(dict(item) for item in direct if isinstance(item, Mapping))
    target = slice_state.get("target")
    if isinstance(target, Mapping):
        target_anchors = target.get("visual_anchors")
        if isinstance(target_anchors, list):
            anchors.extend(
                dict(item) for item in target_anchors if isinstance(item, Mapping)
            )
    annotations = slice_state.get("annotations")
    if isinstance(annotations, list):
        for annotation in annotations:
            if not isinstance(annotation, Mapping):
                continue
            annotation_anchors = annotation.get("visual_anchors")
            if isinstance(annotation_anchors, list):
                anchors.extend(
                    dict(item)
                    for item in annotation_anchors
                    if isinstance(item, Mapping)
                )
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for anchor in anchors:
        anchor_id = str(anchor.get("anchor_id") or "")
        rect = anchor.get("normalized_rect")
        key = anchor_id or json.dumps(rect, sort_keys=True, ensure_ascii=False)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(anchor)
    return deduped[:3]
def _anchor_summary_lines(anchors: list[dict[str, Any]]) -> list[str]:
    lines: list[str] = []
    for index, anchor in enumerate(anchors, start=1):
        rect = anchor.get("normalized_rect")
        parts = [f"用户框选区域 #{index}"]
        anchor_id = str(anchor.get("anchor_id") or "").strip()
        shape = str(anchor.get("shape") or "box").strip()
        if anchor_id:
            parts.append(f"anchor_id={anchor_id}")
        if shape:
            parts.append(f"shape={shape}")
        if isinstance(rect, Mapping):
            try:
                parts.append(
                    "rect="
                    f"x:{float(rect.get('x', 0)):.3f},"
                    f"y:{float(rect.get('y', 0)):.3f},"
                    f"w:{float(rect.get('width', 0)):.3f},"
                    f"h:{float(rect.get('height', 0)):.3f}"
                )
            except (TypeError, ValueError):
                pass
        if len(parts) > 1:
            lines.append(" ".join(parts))
    return lines
def _clamped_rect(anchor: Mapping[str, Any]) -> tuple[float, float, float, float] | None:
    rect = anchor.get("normalized_rect")
    if not isinstance(rect, Mapping):
        return None
    try:
        x = float(rect.get("x", 0.0))
        y = float(rect.get("y", 0.0))
        width = float(rect.get("width", 0.0))
        height = float(rect.get("height", 0.0))
    except (TypeError, ValueError):
        return None
    x = min(max(x, 0.0), 0.99)
    y = min(max(y, 0.0), 0.99)
    width = min(max(width, 0.01), 1.0 - x)
    height = min(max(height, 0.01), 1.0 - y)
    if width <= 0.0 or height <= 0.0:
        return None
    return x, y, width, height
async def _extract_anchor_crop_to_jpeg(
    frame_path: Path,
    anchor: Mapping[str, Any],
    output_path: Path,
) -> None:
    rect = _clamped_rect(anchor)
    if rect is None:
        raise ValueError("invalid_visual_anchor_rect")
    x, y, width, height = rect
    crop_filter = (
        f"crop=w=iw*{width:.6f}:h=ih*{height:.6f}:"
        f"x=iw*{x:.6f}:y=ih*{y:.6f}"
    )
    process = await asyncio.create_subprocess_exec(
        "ffmpeg",
        "-y",
        "-i",
        str(frame_path),
        "-vf",
        crop_filter,
        "-q:v",
        "2",
        str(output_path),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await process.communicate()
    if process.returncode != 0:
        message = stderr.decode("utf-8", errors="ignore")[:300]
        raise RuntimeError(f"ffmpeg_anchor_crop_failed:{message}")
async def _anchor_crop_data_urls(
    frame_path: Path,
    anchors: list[dict[str, Any]],
    *,
    temp_dir: Path,
) -> list[str]:
    crop_urls: list[str] = []
    for index, anchor in enumerate(anchors[:2], start=1):
        crop_path = temp_dir / f"anchor_{index}.jpg"
        try:
            await _extract_anchor_crop_to_jpeg(frame_path, anchor, crop_path)
            crop_urls.append(_image_data_url(crop_path))
        except Exception:
            logger.debug(
                "[MODIFY_VISUAL] anchor crop skipped: index=%s",
                index,
                exc_info=True,
            )
    return crop_urls

from . import modify_visual_recognition_part3 as _part3
from . import modify_visual_recognition_part4 as _part4
globals().update({k:v for _module in (_part3,_part4,) for k,v in vars(_module).items() if not k.startswith("__")})

