from __future__ import annotations

import re


RETRYABLE_ERROR_KEYWORDS = (
    "timeout", "rate_limit", "rate limit", "429", "quota", "connection",
    "network", "temporarily", "transient", "超时", "限流", "网络", "连接",
)
_COOKIE_RE = re.compile(r"(?im)\b((?:set-)?cookie\s*:\s*).+$")
_AUTH_BEARER_HEADER_RE = re.compile(r"(?im)\b(authorization\s*:\s*bearer\s+)[^\s,;]+")
_BEARER_RE = re.compile(r"(?i)\b(bearer\s+)[A-Za-z0-9._~+/=-]{8,}")
_SECRET_FIELD_RE = re.compile(
    r"(?i)\b(api[_-]?key|x-api-key|access[_-]?token|refresh[_-]?token|"
    r"id[_-]?token|token|password|passwd|pwd|secret)"
    r"(\s*[:=]\s*)([\"']?)[^\s,\"';]+([\"']?)"
)


def redact_transcript_text(value: object) -> str:
    text_value = "" if value is None else str(value)
    text_value = _COOKIE_RE.sub(r"\1[REDACTED]", text_value)
    text_value = _AUTH_BEARER_HEADER_RE.sub(r"\1[REDACTED]", text_value)
    text_value = _BEARER_RE.sub(r"\1[REDACTED]", text_value)

    def replace_secret(match: re.Match[str]) -> str:
        field, separator, quote, closing_quote = match.groups()
        return f"{field}{separator}{quote}[REDACTED]{closing_quote}"

    return _SECRET_FIELD_RE.sub(replace_secret, text_value)


def quality_error_code(error_type: str | None, slug) -> str:
    return f"LLM_{slug(error_type).upper()}"


def is_retryable_error(error_type: str | None, error_message: str | None, is_retryable) -> bool:
    return is_retryable(error_type, error_message, RETRYABLE_ERROR_KEYWORDS)
