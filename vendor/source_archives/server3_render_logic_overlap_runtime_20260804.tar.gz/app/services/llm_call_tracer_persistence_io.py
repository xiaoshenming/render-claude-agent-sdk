"""LLM 调用追踪器 — 记录每次 LLM API 调用的完整链路信息。
集成方式：在 llm_service._LLMManager.call() / call_stream() 完成后调用。
元数据写入 llm_call_logs 表；脱敏输入/输出 transcript 稳定写入
llm_transcript_artifacts，Elasticsearch/OpenSearch 作为可检索 raw trace。
"""
import hashlib
import json
import logging
import os
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
from app.core.config import settings
from sqlalchemy import text
from app.core.structured_logging import get_log_context
from app.database.database import AsyncSessionLocal
from app.services.llm_trace_text_helpers import (
    redact_text, exception_summary, redact_mapping, coerce_messages,
    messages_to_text, messages_for_es_index, trace_content_hash, iso,
    trace_max_text_chars, truncate_text,
)
from app.services.llm_trace_value_helpers import (
    bounded_identifier, hash_prompt, hash_text, slug, is_retryable,
    json_param, json_nullable_param, dict_or_empty,
)
from app.services.llm_trace_security_helpers import (
    redact_transcript_text, quality_error_code, is_retryable_error,
)
from app.services.llm_trace_usage_helpers import (
    artifact_selected_skills as _artifact_selected_skills,
    artifact_skill_block_refs as _artifact_skill_block_refs,
    safe_prompt_segments as _safe_prompt_segments,
)
try:
    import httpx
except Exception:  # pragma: no cover - httpx is present in runtime images
    httpx = None
logger = logging.getLogger(__name__)
BEIJING_TZ = timezone(timedelta(hours=8))
MESSAGE_TRACE_INDEX = "mathpi-llm-message-traces"
MESSAGE_TRACE_MAX_TEXT_CHARS = 200_000
REDACTION_VERSION = "redaction.v1"
TRANSCRIPT_RETENTION_POLICY = "standard"
_bounded_identifier = bounded_identifier
_hash_prompt = hash_prompt
_hash_text = hash_text
_redact_transcript_text = redact_transcript_text
_slug = slug
_json_param = json_param
_json_nullable_param = json_nullable_param
_dict_or_empty = dict_or_empty
_redact_text = redact_text
_redact_mapping = redact_mapping
_coerce_messages = coerce_messages
_messages_to_text = messages_to_text
_messages_for_es_index = messages_for_es_index
_trace_content_hash = trace_content_hash
_iso = iso
_exception_summary = exception_summary
async def index_llm_message_trace(document: dict) -> dict[str, str | None]:
    """Best-effort Elasticsearch/OpenSearch indexing for message transcripts."""
    url = str(_config_value("LLM_MESSAGE_TRACE_ES_URL", "") or "").strip().rstrip("/")
    if not url:
        return {"status": "skipped", "document_id": None, "error_message": None}
    if httpx is None:
        return {
            "status": "failed",
            "document_id": None,
            "error_message": "httpx unavailable",
        }
    index_name = (
        _config_value("LLM_MESSAGE_TRACE_ES_INDEX", "")
        or os.getenv("ELASTICSEARCH_LLM_MESSAGE_TRACE_INDEX")
        or MESSAGE_TRACE_INDEX
    )
    index_name = str(index_name).strip()
    document_id = str(document.get("id") or uuid.uuid4())
    timeout = float(_config_value("LLM_MESSAGE_TRACE_ES_TIMEOUT", 2.0) or 2.0)
    headers = {"Content-Type": "application/json"}
    api_key = str(_config_value("LLM_MESSAGE_TRACE_ES_API_KEY", "") or "").strip()
    if api_key:
        headers["Authorization"] = f"ApiKey {api_key}"
    auth = None
    username = str(_config_value("LLM_MESSAGE_TRACE_ES_USERNAME", "") or "").strip()
    password = str(_config_value("LLM_MESSAGE_TRACE_ES_PASSWORD", "") or "").strip()
    if username or password:
        auth = (username, password)
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.put(
                f"{url}/{index_name}/_doc/{document_id}",
                headers=headers,
                auth=auth,
                json=document,
            )
            response.raise_for_status()
        return {
            "status": "indexed",
            "document_id": document_id,
            "error_message": None,
        }
    except Exception as exc:
        error_message = _exception_summary(exc)
        logger.warning("[LLM_TRACE] ES index failed: %s", error_message)
        return {
            "status": "failed",
            "document_id": document_id,
            "error_message": error_message,
        }
async def mark_latest_llm_call_semantic_rejected(
    *,
    job_id: str,
    backend_name: str | None = None,
    model: str | None = None,
    call_type: str = "generate_stream",
    error_type: str,
    error_message: str,
    quality_result: str = "agent_semantic_rejected",
) -> str | None:
    """Best-effort post-hoc semantic status update for buffered streams."""
    if not job_id:
        return None
    try:
        session = AsyncSessionLocal()
        try:
            filters = [
                "job_id = :job_id",
                "call_type = :call_type",
                "success = 1",
            ]
            params: dict[str, Any] = {
                "job_id": job_id,
                "call_type": call_type,
            }
            if backend_name:
                filters.append("backend_name = :backend_name")
                params["backend_name"] = backend_name
            if model:
                filters.append("model = :model")
                params["model"] = model
            row = (
                await session.execute(
                    text(
                        "SELECT id FROM llm_call_logs "
                        f"WHERE {' AND '.join(filters)} "
                        "ORDER BY COALESCE(ended_at, created_at) DESC "
                        "LIMIT 1"
                    ),
                    params,
                )
            ).first()
            if not row:
                return None
            call_log_id = str(row[0])
            await session.execute(
                text(
                    "UPDATE llm_call_logs "
                    "SET quality_result = :quality_result, "
                    "error_type = :error_type, "
                    "error_message = :error_message "
                    "WHERE id = :id"
                ),
                {
                    "id": call_log_id,
                    "quality_result": quality_result[:50],
                    "error_type": error_type[:50],
                    "error_message": error_message[:2000],
                },
            )
            await session.commit()
            return call_log_id
        finally:
            await session.close()
    except Exception as exc:
        logger.warning(
            "[LLM_TRACE] semantic status update failed: job_id=%s error=%s",
            job_id,
            _exception_summary(exc),
        )
        return None
from app.services.llm_trace_helpers import (
    _config_value, _generate_request_id, _quality_error_code, _is_retryable, _safe_prompt_segments_for_log, _cache_metrics_for_log, _prompt_firewall_for_log, _metric_value, _render_skill_os_usage_summary, _provider_usage_raw_with_render_skill_os, _string_or_none, _int_or_zero, _trace_max_text_chars, _truncate_text,
)
async def record_attempts(self, attempts: list[dict]) -> None:
    """记录一次高层调用中的所有 backend 尝试。"""
    for attempt in attempts:
        if attempt.get('success'):
            await self.record_success(backend_name=attempt['backend_name'], model=attempt['model'], usage_info=attempt.get('usage_info') or {}, cost_usd=attempt.get('cost_usd', 0.0), latency_ms=attempt.get('latency_ms'), started_at=attempt.get('started_at'), ended_at=attempt.get('ended_at'), output_text=attempt.get('output_text'))
        else:
            await self.record_failure(backend_name=attempt['backend_name'], model=attempt['model'], error_type=attempt.get('error_type') or 'Exception', error_message=attempt.get('error_message') or '', usage_info=attempt.get('usage_info') or {}, latency_ms=attempt.get('latency_ms'), started_at=attempt.get('started_at'), ended_at=attempt.get('ended_at'), output_text=attempt.get('output_text'))
async def _write_log(self, *, backend_name: str, model: str, usage_info: dict, cost_usd: float, success: bool, error_type: Optional[str]=None, error_message: Optional[str]=None, latency_ms: Optional[int]=None, started_at: Optional[datetime]=None, ended_at: Optional[datetime]=None, output_text: Optional[str]=None) -> None:
    """写入 llm_call_logs 表"""
    safe_error_message = _redact_text(error_message) if error_message else None
    latency = self.elapsed_ms() if latency_ms is None else int(latency_ms)
    effective_ended_at = ended_at or datetime.now(BEIJING_TZ)
    effective_started_at = started_at or self._started_at_wall
    if effective_started_at is None:
        effective_started_at = effective_ended_at - timedelta(milliseconds=max(0, latency))
    try:
        session = AsyncSessionLocal()
        try:
            call_log_id = str(uuid.uuid4()).replace('-', '')[:26]
            prompt_segments = _safe_prompt_segments_for_log(usage_info)
            cache_metrics = _cache_metrics_for_log(usage_info)
            for key in ('stable_prefix_hash', 'skill_chain_hash', 'dynamic_payload_hash', 'cache_key'):
                if cache_metrics.get(key) and key not in prompt_segments:
                    prompt_segments[key] = cache_metrics[key]
            prompt_firewall = _prompt_firewall_for_log(usage_info)
            await session.execute(text('\n                    INSERT INTO llm_call_logs (\n                        id, job_id, request_id, trace_id, attempt_id,\n                        backend_name, model,\n                        prompt_hash, prompt_version, call_type,\n                        response_format, retry_count, finish_reason, quality_result,\n                        input_tokens, output_tokens,\n                        cache_read_tokens, cache_creation_tokens, cache_miss_tokens,\n                        provider_usage_raw,\n                        stable_prefix_hash, skill_chain_hash,\n                        dynamic_payload_hash, cache_key,\n                        prompt_segments, cache_metrics, prompt_firewall,\n                        cost_usd, latency_ms, success,\n                        error_type, error_message,\n                        started_at, ended_at, created_at\n                    ) VALUES (\n                        :id, :job_id, :request_id, :trace_id, :attempt_id,\n                        :backend_name, :model,\n                        :prompt_hash, :prompt_version, :call_type,\n                        :response_format, :retry_count, :finish_reason, :quality_result,\n                        :input_tokens, :output_tokens,\n                        :cache_read_tokens, :cache_creation_tokens, :cache_miss_tokens,\n                        :provider_usage_raw,\n                        :stable_prefix_hash, :skill_chain_hash,\n                        :dynamic_payload_hash, :cache_key,\n                        :prompt_segments, :cache_metrics, :prompt_firewall,\n                        :cost_usd, :latency_ms, :success,\n                        :error_type, :error_message,\n                        :started_at, :ended_at, NOW()\n                    )\n                '), {'id': call_log_id, 'job_id': self.job_id, 'request_id': self.request_id, 'trace_id': self.trace_id, 'attempt_id': self.attempt_id, 'backend_name': backend_name, 'model': model, 'prompt_hash': self._prompt_hash, 'prompt_version': self.prompt_version, 'call_type': self.call_type, 'response_format': _string_or_none(usage_info.get('response_format') or self.response_format), 'retry_count': _int_or_zero(usage_info.get('retry_count', self.retry_count)), 'finish_reason': _string_or_none(usage_info.get('finish_reason')), 'quality_result': _string_or_none(usage_info.get('quality_result') or ('accepted' if success else error_type)), 'input_tokens': usage_info.get('input_tokens', 0), 'output_tokens': usage_info.get('output_tokens', 0), 'cache_read_tokens': usage_info.get('cache_read_tokens', 0), 'cache_creation_tokens': usage_info.get('cache_creation_tokens', 0), 'cache_miss_tokens': usage_info.get('cache_miss_tokens', 0), 'provider_usage_raw': _json_param(_provider_usage_raw_with_render_skill_os(usage_info)), 'stable_prefix_hash': _metric_value(cache_metrics, prompt_segments, 'stable_prefix_hash'), 'skill_chain_hash': _metric_value(cache_metrics, prompt_segments, 'skill_chain_hash'), 'dynamic_payload_hash': _metric_value(cache_metrics, prompt_segments, 'dynamic_payload_hash'), 'cache_key': _metric_value(cache_metrics, prompt_segments, 'cache_key'), 'prompt_segments': _json_param(prompt_segments), 'cache_metrics': _json_param(cache_metrics), 'prompt_firewall': _json_param(prompt_firewall), 'cost_usd': cost_usd, 'latency_ms': latency, 'success': success, 'error_type': error_type, 'error_message': safe_error_message, 'started_at': effective_started_at, 'ended_at': effective_ended_at})
            if not success:
                code = _quality_error_code(error_type)
                retryable = _is_retryable(error_type, safe_error_message)
                await session.execute(text('\n                        INSERT INTO quality_error_events (\n                            id, source, error_code, error_stage,\n                            severity, retryable, message, suggestion,\n                            job_id, video_id, user_id, request_id,\n                            trace_id, model_call_id, attempt_id,\n                            payload, evidence, created_at\n                        ) VALUES (\n                            :id, :source, :error_code, :error_stage,\n                            :severity, :retryable, :message, :suggestion,\n                            :job_id, :video_id, :user_id, :request_id,\n                            :trace_id, :model_call_id, :attempt_id,\n                            :payload, :evidence, NOW()\n                        )\n                    '), {'id': str(uuid.uuid4()).replace('-', '')[:26], 'source': 'render', 'error_code': code, 'error_stage': 'llm', 'severity': 'error', 'retryable': retryable, 'message': safe_error_message, 'suggestion': '先检查模型后端、限流和网络状态，允许有限重试。' if retryable else '检查模型输出、JSON 约束、prompt 版本和证据包完整性。', 'job_id': self.job_id, 'video_id': None, 'user_id': None, 'request_id': self.request_id, 'trace_id': self.trace_id, 'model_call_id': call_log_id, 'attempt_id': self.attempt_id, 'payload': _json_param({'backend_name': backend_name, 'model': model, 'call_type': self.call_type, 'prompt_version': self.prompt_version, 'response_format': _string_or_none(usage_info.get('response_format') or self.response_format), 'retry_count': _int_or_zero(usage_info.get('retry_count', self.retry_count)), 'finish_reason': _string_or_none(usage_info.get('finish_reason')), 'input_tokens': usage_info.get('input_tokens', 0), 'output_tokens': usage_info.get('output_tokens', 0), 'latency_ms': latency, 'cost_usd': cost_usd}), 'evidence': _json_param({'llm_call_log_id': call_log_id, 'error_type': error_type, 'error_message': safe_error_message})})
            await session.commit()
            try:
                await self._index_message_trace(call_log_id=call_log_id, backend_name=backend_name, model=model, usage_info=usage_info, output_text=output_text, success=success, error_type=error_type, error_message=safe_error_message, latency_ms=latency, started_at=effective_started_at, ended_at=effective_ended_at)
            except Exception as exc:
                logger.warning('[LLM_TRACE] message trace ES write failed: %s', exc)
            logger.debug(f'[LLM_TRACE] logged: job={self.job_id}, req={self.request_id}, backend={backend_name}, success={success}, latency={latency}ms')
        finally:
            await session.close()
        await self._write_transcript_artifact(call_log_id=call_log_id, prompt_segments=prompt_segments, cache_metrics=cache_metrics, output_text=output_text)
        logger.debug(f'[LLM_TRACE] logged: job={self.job_id}, req={self.request_id}, backend={backend_name}, success={success}, latency={latency}ms')
    except Exception as e:
        logger.warning(f'[LLM_TRACE] 写入失败: {e}')
async def _write_transcript_artifact(self, *, call_log_id: str, prompt_segments: dict, cache_metrics: dict, output_text: Optional[str]) -> None:
    artifact_id = str(uuid.uuid4()).replace('-', '')[:26]
    input_text_redacted = _redact_transcript_text(self._prompt_content)
    output_text_redacted = _redact_transcript_text(output_text)
    search_text = '\n\n'.join((part for part in (input_text_redacted, output_text_redacted) if part))
    params = {'id': artifact_id, 'llm_call_log_id': call_log_id, 'job_id': self.job_id, 'trace_id': self.trace_id, 'attempt_id': self.attempt_id, 'call_type': self.call_type, 'prompt_hash': self._prompt_hash, 'response_hash': _hash_text(output_text_redacted), 'selected_skills': _json_nullable_param(_artifact_selected_skills(prompt_segments, cache_metrics)), 'skill_block_refs': _json_nullable_param(_artifact_skill_block_refs(prompt_segments)), 'prompt_segments': _json_param(prompt_segments), 'input_artifact_uri': f'db://llm_transcript_artifacts/{artifact_id}/input_text_redacted', 'output_artifact_uri': f'db://llm_transcript_artifacts/{artifact_id}/output_text_redacted', 'input_text_redacted': input_text_redacted, 'output_text_redacted': output_text_redacted, 'search_text': search_text, 'input_text_hash': _hash_text(input_text_redacted), 'output_text_hash': _hash_text(output_text_redacted), 'input_text_length': len(input_text_redacted), 'output_text_length': len(output_text_redacted), 'redaction_version': REDACTION_VERSION, 'retention_policy': TRANSCRIPT_RETENTION_POLICY}
    try:
        session = AsyncSessionLocal()
        try:
            await session.execute(text('\n                    INSERT INTO llm_transcript_artifacts (\n                        id, llm_call_log_id, job_id, trace_id, attempt_id,\n                        call_type, prompt_hash, response_hash,\n                        selected_skills, skill_block_refs, prompt_segments,\n                        input_artifact_uri, output_artifact_uri,\n                        input_text_redacted, output_text_redacted, search_text,\n                        input_text_hash, output_text_hash,\n                        input_text_length, output_text_length,\n                        redaction_version, retention_policy, created_at\n                    ) VALUES (\n                        :id, :llm_call_log_id, :job_id, :trace_id, :attempt_id,\n                        :call_type, :prompt_hash, :response_hash,\n                        :selected_skills, :skill_block_refs, :prompt_segments,\n                        :input_artifact_uri, :output_artifact_uri,\n                        :input_text_redacted, :output_text_redacted, :search_text,\n                        :input_text_hash, :output_text_hash,\n                        :input_text_length, :output_text_length,\n                        :redaction_version, :retention_policy, NOW()\n                    )\n                '), params)
            await session.commit()
        finally:
            await session.close()
    except Exception as exc:
        logger.warning(f'[LLM_TRACE] 转录 payload 写入失败: {exc}')
async def _write_log(self, *, backend_name: str, model: str, usage_info: dict, cost_usd: float, success: bool, error_type: Optional[str]=None, error_message: Optional[str]=None, latency_ms: Optional[int]=None, started_at: Optional[datetime]=None, ended_at: Optional[datetime]=None, output_text: Optional[str]=None) -> None:
    """写入 llm_call_logs 表"""
    safe_error_message = _redact_text(error_message) if error_message else None
    latency = self.elapsed_ms() if latency_ms is None else int(latency_ms)
    effective_ended_at = ended_at or datetime.now(BEIJING_TZ)
    effective_started_at = started_at or self._started_at_wall
    if effective_started_at is None:
        effective_started_at = effective_ended_at - timedelta(milliseconds=max(0, latency))
    try:
        session = AsyncSessionLocal()
        try:
            call_log_id = str(uuid.uuid4()).replace('-', '')[:26]
            prompt_segments = _safe_prompt_segments_for_log(usage_info)
            cache_metrics = _cache_metrics_for_log(usage_info)
            for key in ('stable_prefix_hash', 'skill_chain_hash', 'dynamic_payload_hash', 'cache_key'):
                if cache_metrics.get(key) and key not in prompt_segments:
                    prompt_segments[key] = cache_metrics[key]
            prompt_firewall = _prompt_firewall_for_log(usage_info)
            await session.execute(text('\n                    INSERT INTO llm_call_logs (\n                        id, job_id, request_id, trace_id, attempt_id,\n                        backend_name, model,\n                        prompt_hash, prompt_version, call_type,\n                        response_format, retry_count, finish_reason, quality_result,\n                        input_tokens, output_tokens,\n                        cache_read_tokens, cache_creation_tokens, cache_miss_tokens,\n                        provider_usage_raw,\n                        stable_prefix_hash, skill_chain_hash,\n                        dynamic_payload_hash, cache_key,\n                        prompt_segments, cache_metrics, prompt_firewall,\n                        cost_usd, latency_ms, success,\n                        error_type, error_message,\n                        started_at, ended_at, created_at\n                    ) VALUES (\n                        :id, :job_id, :request_id, :trace_id, :attempt_id,\n                        :backend_name, :model,\n                        :prompt_hash, :prompt_version, :call_type,\n                        :response_format, :retry_count, :finish_reason, :quality_result,\n                        :input_tokens, :output_tokens,\n                        :cache_read_tokens, :cache_creation_tokens, :cache_miss_tokens,\n                        :provider_usage_raw,\n                        :stable_prefix_hash, :skill_chain_hash,\n                        :dynamic_payload_hash, :cache_key,\n                        :prompt_segments, :cache_metrics, :prompt_firewall,\n                        :cost_usd, :latency_ms, :success,\n                        :error_type, :error_message,\n                        :started_at, :ended_at, NOW()\n                    )\n                '), {'id': call_log_id, 'job_id': self.job_id, 'request_id': self.request_id, 'trace_id': self.trace_id, 'attempt_id': self.attempt_id, 'backend_name': backend_name, 'model': model, 'prompt_hash': self._prompt_hash, 'prompt_version': self.prompt_version, 'call_type': self.call_type, 'response_format': _string_or_none(usage_info.get('response_format') or self.response_format), 'retry_count': _int_or_zero(usage_info.get('retry_count', self.retry_count)), 'finish_reason': _string_or_none(usage_info.get('finish_reason')), 'quality_result': _string_or_none(usage_info.get('quality_result') or ('accepted' if success else error_type)), 'input_tokens': usage_info.get('input_tokens', 0), 'output_tokens': usage_info.get('output_tokens', 0), 'cache_read_tokens': usage_info.get('cache_read_tokens', 0), 'cache_creation_tokens': usage_info.get('cache_creation_tokens', 0), 'cache_miss_tokens': usage_info.get('cache_miss_tokens', 0), 'provider_usage_raw': _json_param(_provider_usage_raw_with_render_skill_os(usage_info)), 'stable_prefix_hash': _metric_value(cache_metrics, prompt_segments, 'stable_prefix_hash'), 'skill_chain_hash': _metric_value(cache_metrics, prompt_segments, 'skill_chain_hash'), 'dynamic_payload_hash': _metric_value(cache_metrics, prompt_segments, 'dynamic_payload_hash'), 'cache_key': _metric_value(cache_metrics, prompt_segments, 'cache_key'), 'prompt_segments': _json_param(prompt_segments), 'cache_metrics': _json_param(cache_metrics), 'prompt_firewall': _json_param(prompt_firewall), 'cost_usd': cost_usd, 'latency_ms': latency, 'success': success, 'error_type': error_type, 'error_message': safe_error_message, 'started_at': effective_started_at, 'ended_at': effective_ended_at})
            if not success:
                code = _quality_error_code(error_type)
                retryable = _is_retryable(error_type, safe_error_message)
                await session.execute(text('\n                        INSERT INTO quality_error_events (\n                            id, source, error_code, error_stage,\n                            severity, retryable, message, suggestion,\n                            job_id, video_id, user_id, request_id,\n                            trace_id, model_call_id, attempt_id,\n                            payload, evidence, created_at\n                        ) VALUES (\n                            :id, :source, :error_code, :error_stage,\n                            :severity, :retryable, :message, :suggestion,\n                            :job_id, :video_id, :user_id, :request_id,\n                            :trace_id, :model_call_id, :attempt_id,\n                            :payload, :evidence, NOW()\n                        )\n                    '), {'id': str(uuid.uuid4()).replace('-', '')[:26], 'source': 'render', 'error_code': code, 'error_stage': 'llm', 'severity': 'error', 'retryable': retryable, 'message': safe_error_message, 'suggestion': '先检查模型后端、限流和网络状态，允许有限重试。' if retryable else '检查模型输出、JSON 约束、prompt 版本和证据包完整性。', 'job_id': self.job_id, 'video_id': None, 'user_id': None, 'request_id': self.request_id, 'trace_id': self.trace_id, 'model_call_id': call_log_id, 'attempt_id': self.attempt_id, 'payload': _json_param({'backend_name': backend_name, 'model': model, 'call_type': self.call_type, 'prompt_version': self.prompt_version, 'response_format': _string_or_none(usage_info.get('response_format') or self.response_format), 'retry_count': _int_or_zero(usage_info.get('retry_count', self.retry_count)), 'finish_reason': _string_or_none(usage_info.get('finish_reason')), 'input_tokens': usage_info.get('input_tokens', 0), 'output_tokens': usage_info.get('output_tokens', 0), 'latency_ms': latency, 'cost_usd': cost_usd}), 'evidence': _json_param({'llm_call_log_id': call_log_id, 'error_type': error_type, 'error_message': safe_error_message})})
            await session.commit()
            try:
                await self._index_message_trace(call_log_id=call_log_id, backend_name=backend_name, model=model, usage_info=usage_info, output_text=output_text, success=success, error_type=error_type, error_message=safe_error_message, latency_ms=latency, started_at=effective_started_at, ended_at=effective_ended_at)
            except Exception as exc:
                logger.warning('[LLM_TRACE] message trace ES write failed: %s', exc)
            logger.debug(f'[LLM_TRACE] logged: job={self.job_id}, req={self.request_id}, backend={backend_name}, success={success}, latency={latency}ms')
        finally:
            await session.close()
        await self._write_transcript_artifact(call_log_id=call_log_id, prompt_segments=prompt_segments, cache_metrics=cache_metrics, output_text=output_text)
        logger.debug(f'[LLM_TRACE] logged: job={self.job_id}, req={self.request_id}, backend={backend_name}, success={success}, latency={latency}ms')
    except Exception as e:
        logger.warning(f'[LLM_TRACE] 写入失败: {e}')
async def _write_transcript_artifact(self, *, call_log_id: str, prompt_segments: dict, cache_metrics: dict, output_text: Optional[str]) -> None:
    artifact_id = str(uuid.uuid4()).replace('-', '')[:26]
    input_text_redacted = _redact_transcript_text(self._prompt_content)
    output_text_redacted = _redact_transcript_text(output_text)
    search_text = '\n\n'.join((part for part in (input_text_redacted, output_text_redacted) if part))
    params = {'id': artifact_id, 'llm_call_log_id': call_log_id, 'job_id': self.job_id, 'trace_id': self.trace_id, 'attempt_id': self.attempt_id, 'call_type': self.call_type, 'prompt_hash': self._prompt_hash, 'response_hash': _hash_text(output_text_redacted), 'selected_skills': _json_nullable_param(_artifact_selected_skills(prompt_segments, cache_metrics)), 'skill_block_refs': _json_nullable_param(_artifact_skill_block_refs(prompt_segments)), 'prompt_segments': _json_param(prompt_segments), 'input_artifact_uri': f'db://llm_transcript_artifacts/{artifact_id}/input_text_redacted', 'output_artifact_uri': f'db://llm_transcript_artifacts/{artifact_id}/output_text_redacted', 'input_text_redacted': input_text_redacted, 'output_text_redacted': output_text_redacted, 'search_text': search_text, 'input_text_hash': _hash_text(input_text_redacted), 'output_text_hash': _hash_text(output_text_redacted), 'input_text_length': len(input_text_redacted), 'output_text_length': len(output_text_redacted), 'redaction_version': REDACTION_VERSION, 'retention_policy': TRANSCRIPT_RETENTION_POLICY}
    try:
        session = AsyncSessionLocal()
        try:
            await session.execute(text('\n                    INSERT INTO llm_transcript_artifacts (\n                        id, llm_call_log_id, job_id, trace_id, attempt_id,\n                        call_type, prompt_hash, response_hash,\n                        selected_skills, skill_block_refs, prompt_segments,\n                        input_artifact_uri, output_artifact_uri,\n                        input_text_redacted, output_text_redacted, search_text,\n                        input_text_hash, output_text_hash,\n                        input_text_length, output_text_length,\n                        redaction_version, retention_policy, created_at\n                    ) VALUES (\n                        :id, :llm_call_log_id, :job_id, :trace_id, :attempt_id,\n                        :call_type, :prompt_hash, :response_hash,\n                        :selected_skills, :skill_block_refs, :prompt_segments,\n                        :input_artifact_uri, :output_artifact_uri,\n                        :input_text_redacted, :output_text_redacted, :search_text,\n                        :input_text_hash, :output_text_hash,\n                        :input_text_length, :output_text_length,\n                        :redaction_version, :retention_policy, NOW()\n                    )\n                '), params)
            await session.commit()
        finally:
            await session.close()
    except Exception as exc:
        logger.warning(f'[LLM_TRACE] 转录 payload 写入失败: {exc}')
