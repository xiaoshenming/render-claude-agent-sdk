"""Provider message, cache, and reasoning policy helpers."""

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

QUALITY_CALL_TYPES = frozenset(
    {
        "quality_multimodal_review",
        "quality_scene_brief",
        "quality_review",
        "quality_repair",
        "quality_postcheck",
    }
)


def messages_for_provider(messages: list, *, backend: Any | None = None) -> list[dict]:
    model = str(getattr(backend, "model", "") or "").lower()
    include_cache = model.startswith(("anthropic/", "gemini/"))
    result = []
    for message in messages or []:
        if isinstance(message, dict):
            role = message.get("role") or "user"
            content = message.get("content") or ""
            cache_control = message.get("cache_control")
        else:
            role = getattr(message, "role", "user")
            content = getattr(message, "content", "")
            cache_control = getattr(message, "cache_control", None)
        item = {"role": str(role or "user"), "content": content}
        if include_cache and isinstance(cache_control, dict):
            item["cache_control"] = cache_control
        result.append(item)
    return result


def responses_prompt_cache_kwargs(context: dict | None, config: Any) -> dict[str, str]:
    metrics = context.get("cache_metrics") if isinstance(context, dict) else None
    cache_key = str(metrics.get("cache_key") or "").strip() if isinstance(metrics, dict) else ""
    if not cache_key:
        return {}
    retention = str(
        getattr(config, "RENDER_SKILL_OS_OPENAI_PROMPT_CACHE_RETENTION", "24h") or "24h"
    ).strip()
    if retention not in {"in-memory", "24h"}:
        retention = "24h"
    return {
        "prompt_cache_key": f"mathpi-render-skill-os-{cache_key}",
        "prompt_cache_retention": retention,
    }


def with_provider_cache_params(context: dict | None, kwargs: dict) -> dict | None:
    if not kwargs:
        return context
    merged = dict(context or {})
    metrics = dict(merged.get("cache_metrics") or {})
    metrics.update(
        provider_cache_api="openai_responses",
        provider_prompt_cache_key=kwargs.get("prompt_cache_key"),
        provider_prompt_cache_retention=kwargs.get("prompt_cache_retention"),
    )
    merged["cache_metrics"] = metrics
    return merged


def quality_reasoning_extra_body(
    call_type: str | None,
    context: dict | None,
    config: Any,
) -> dict[str, Any]:
    if str(call_type or "") not in QUALITY_CALL_TYPES:
        return {}
    raw = str(
        getattr(
            config,
            "QUALITY_REPAIR_MULTIMODAL_REASONING_EXTRA_BODY",
            '{"enable_thinking":false}',
        )
        or ""
    ).strip()
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("QUALITY_REPAIR_MULTIMODAL_REASONING_EXTRA_BODY invalid JSON")
        return {"enable_thinking": False}
    if not isinstance(parsed, dict):
        return {"enable_thinking": False}
    stage = str(context.get("stage") or "").strip() if isinstance(context, dict) else ""
    selected = (
        parsed.get(str(call_type or "")) or parsed.get(stage) or parsed.get("default") or {}
        if any(isinstance(value, dict) for value in parsed.values())
        else parsed
    )
    return dict(selected) if isinstance(selected, dict) else {"enable_thinking": False}


def litellm_extra_kwargs(backend: Any, call_type: str | None, context: dict | None, config: Any):
    kwargs = backend.litellm_extra_kwargs()
    override = quality_reasoning_extra_body(call_type, context, config)
    if override:
        body = dict(kwargs.get("extra_body") or {})
        body.update(override)
        kwargs["extra_body"] = body
    return kwargs


def with_quality_provider_policy(context: dict | None, kwargs: dict) -> dict | None:
    if not isinstance(context, dict):
        return context
    safe_keys = {
        "enable_thinking",
        "disable_thinking",
        "thinking_budget",
        "thinkingBudget",
        "reasoning_effort",
    }
    safe = {
        str(key): value
        for key, value in (kwargs.get("extra_body") or {}).items()
        if key in safe_keys and isinstance(value, (str, int, float, bool, type(None)))
    }
    merged = dict(context)
    if safe:
        merged["quality_multimodal_provider_extra_body"] = safe
        merged["quality_multimodal_reasoning_control"] = "extra_body"
    return merged
