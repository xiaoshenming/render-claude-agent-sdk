"""Compatibility facade for modify visual recognition service."""
from . import modify_visual_recognition_part1 as _part1
from . import modify_visual_recognition_part2 as _part2
from . import modify_visual_recognition_part3 as _part3
from . import modify_visual_recognition_part4 as _part4
for _module in (_part1,_part2,_part3,_part4):
    globals().update({k:v for k,v in vars(_module).items() if not k.startswith("__")})
