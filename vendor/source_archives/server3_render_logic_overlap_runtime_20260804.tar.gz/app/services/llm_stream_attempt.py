"""Execute and describe one buffered streaming LLM attempt."""

import asyncio
import logging
import time
from typing import Any

from app.services.llm_stream_context import StreamAttemptContext, StreamAttemptOutcome
from app.services.llm_stream_protocols import consume_chat_stream, consume_responses_stream

logger = logging.getLogger(__name__)


def _attempt_record(
    context: StreamAttemptContext,
    deps: Any,
    usage: dict,
    chunks: list[str],
    *,
    started_at: Any,
    started_clock: float,
    success: bool,
    exception: BaseException | None = None,
    local_cancel: bool = False,
) -> dict[str, Any]:
    text = "".join(chunks)
    attempt_usage = (
        (getattr(exception, "usage_info", dict(usage)) or {})
        if exception is not None
        else dict(usage)
    )
    record = {
        "backend_name": context.backend.name,
        "model": context.backend.model,
        "success": success,
        "latency_ms": int((time.monotonic() - started_clock) * 1000),
        "usage_info": {
            **attempt_usage,
            "retry_count": context.global_attempt,
            "attempt_round": context.global_attempt + 1,
        },
        "output_text": text,
        "started_at": started_at,
        "ended_at": deps.now(),
    }
    if success:
        record["usage_info"]["response_text"] = text
        record["cost_usd"] = 0.0
    else:
        message = (
            deps.cancelled_message(exception, local=local_cancel)
            if isinstance(exception, asyncio.CancelledError)
            or isinstance(exception, deps.provider_cancelled_error)
            else str(exception)
        )
        record.update(
            error_type=type(exception).__name__,
            error_message=message,
            output_text=text or message,
        )
    return record


async def execute_stream_attempt(
    manager: Any,
    context: StreamAttemptContext,
    usage: dict,
    trace_collector: dict | None,
    deps: Any,
) -> StreamAttemptOutcome:
    backend = context.backend
    chunks: list[str] = []
    started_at = deps.now()
    started_clock = time.monotonic()
    logger.info(
        "LLM stream call: backend=%s, key_index=%s/%s, round=%s/%s, model=%s, "
        "max_tokens=%s",
        backend.name,
        context.key_index,
        len(backend.keys),
        context.global_attempt + 1,
        context.max_rounds,
        backend.model,
        context.max_tokens,
    )
    usage.update(backend_name=backend.name, model=backend.model)
    if trace_collector is not None:
        trace_collector.update(backend_name=backend.name, model=backend.model)
    try:
        open_timeout = deps.open_timeout(backend.effective_timeout)
        if backend.uses_responses_api:
            response = await deps.await_open(
                manager._call_responses_api_stream(
                    backend=backend,
                    key=context.key,
                    messages=context.messages,
                    max_output_tokens=context.max_tokens,
                    trace_call_type=context.call_type,
                    prompt_cache_kwargs=context.prompt_cache_kwargs,
                ),
                timeout_seconds=open_timeout,
                usage_info=usage,
            )
            await consume_responses_stream(
                response,
                backend=backend,
                usage=usage,
                chunks=chunks,
                deps=deps,
            )
        else:
            response = await deps.await_open(
                deps.acompletion(
                    model=backend.model,
                    messages=context.messages,
                    timeout=backend.effective_timeout,
                    max_tokens=context.max_tokens,
                    api_key=context.key,
                    api_base=backend.resolved_api_base(),
                    num_retries=0,
                    stream=True,
                    stream_options={"include_usage": True},
                    **backend.litellm_temperature_kwargs(),
                    **context.provider_extra_kwargs,
                ),
                timeout_seconds=open_timeout,
                usage_info=usage,
            )
            await consume_chat_stream(
                response,
                backend=backend,
                usage=usage,
                chunks=chunks,
                deps=deps,
            )
        if not chunks:
            raise deps.empty_response_error(
                "LLM stream ended without content",
                usage_info=dict(usage),
            )
        logger.info(
            "LLM stream success: backend=%s, elapsed_ms=%s, finish_reason=%s",
            backend.name,
            int((time.monotonic() - started_clock) * 1000),
            usage.get("finish_reason"),
        )
        return StreamAttemptOutcome(
            action="success",
            chunks=chunks,
            attempt=_attempt_record(
                context,
                deps,
                usage,
                chunks,
                started_at=started_at,
                started_clock=started_clock,
                success=True,
            ),
        )
    except asyncio.CancelledError as exception:
        local = deps.task_cancellation_requested()
        reported = exception if local else deps.provider_cancelled_error(
            "LLM stream cancelled by provider or relay",
            usage_info=dict(usage),
        )
        return StreamAttemptOutcome(
            action="local_cancel" if local else deps.next_backend,
            exception=reported,
            chunks=chunks,
            attempt=_attempt_record(
                context,
                deps,
                usage,
                chunks,
                started_at=started_at,
                started_clock=started_clock,
                success=False,
                exception=reported,
                local_cancel=local,
            ),
        )
    except Exception as exception:
        return StreamAttemptOutcome(
            action=deps.classify_error(exception),
            exception=exception,
            chunks=chunks,
            attempt=_attempt_record(
                context,
                deps,
                usage,
                chunks,
                started_at=started_at,
                started_clock=started_clock,
                success=False,
                exception=exception,
            ),
        )
