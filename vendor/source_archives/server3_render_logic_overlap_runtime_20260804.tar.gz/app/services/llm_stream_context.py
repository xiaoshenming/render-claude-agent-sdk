"""Data contracts for one streaming LLM attempt."""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StreamAttemptContext:
    backend: Any
    key: str
    key_index: int
    messages: list
    max_tokens: int
    global_attempt: int
    max_rounds: int
    call_type: str
    prompt_cache_kwargs: dict
    provider_extra_kwargs: dict


@dataclass
class StreamAttemptOutcome:
    action: str
    attempt: dict[str, Any]
    chunks: list[str]
    exception: BaseException | None = None
