"""Parsing for DB- and environment-managed LLM backend JSON."""

import json
import logging
from collections.abc import Callable

from app.services.llm_backend_model import LLMBackend

logger = logging.getLogger(__name__)


def load_backends_from_raw(
    raw: str,
    config_name: str,
    *,
    backend_type: type[LLMBackend] = LLMBackend,
    compose_model: Callable[[str | None, str], str],
) -> list[LLMBackend]:
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        logger.error("%s 解析失败: %s", config_name, exc)
        raise ValueError(f"{config_name} is not valid JSON: {exc}") from exc
    if not isinstance(data, list) or not data:
        raise ValueError(f"{config_name} must be a non-empty JSON array")

    backends = []
    for index, item in enumerate(data):
        for key in ("name", "priority", "model", "keys"):
            if key not in item:
                raise ValueError(f"{config_name}[{index}] missing required field: {key}")
        if not isinstance(item.get("keys"), list):
            raise ValueError(f"{config_name}[{index}] 'keys' must be a list")
        keys = [key.strip() for key in item["keys"] if isinstance(key, str) and key.strip()]
        if not keys:
            raise ValueError(f"{config_name}[{index}] has no valid keys")
        allowed = item.get("allowed_openai_params") or []
        if not isinstance(allowed, list):
            raise ValueError(f"{config_name}[{index}] 'allowed_openai_params' must be a list")
        backends.append(backend_type(
            name=item["name"], priority=int(item["priority"]),
            model=compose_model(item.get("protocol"), item["model"]),
            api_base=item.get("api_base", ""), keys=keys,
            fallback=bool(item.get("fallback", False)),
            timeout=int(item["timeout"]) if item.get("timeout") else None,
            extra_body=item.get("extra_body") if isinstance(item.get("extra_body"), dict) else None,
            reasoning_effort=item.get("reasoning_effort") or None,
            reasoning_summary=item.get("reasoning_summary") or None,
            text_verbosity=item.get("text_verbosity") or None,
            use_responses_api=(
                bool(item["use_responses_api"])
                if item.get("use_responses_api") is not None else None
            ),
            allowed_openai_params=[str(param).strip() for param in allowed if str(param).strip()] or None,
        ))
    backends.sort(key=lambda backend: backend.priority)
    logger.info("Loaded %s %s backends: %s", len(backends), config_name, [b.name for b in backends])
    return backends
