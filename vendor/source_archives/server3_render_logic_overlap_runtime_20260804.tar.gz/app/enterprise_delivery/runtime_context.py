from __future__ import annotations

from typing import Any

from app.enterprise_delivery.single_source_input import (
    PROMPT_EXCLUDED_PREFIXES,
    PROMPT_SAFE_SKILL_IDS,
    enterprise_color_profile,
    enterprise_primary_skill,
    enterprise_prompt_skill_plan,
    unique_skill_ids,
)


ENTERPRISE_ROUTE = "enterprise_fastpre_v1"
ENTERPRISE_ASSEMBLY_MODE = "enterprise_no_template_skill_graph"


def _truthy_task_value(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on", "enabled"}
    return bool(value)


def enterprise_skill_context_from_task_data(
    task_data: dict[str, Any] | None,
    *,
    aspect_ratio: str,
    enable_tts: bool,
) -> dict[str, Any] | None:
    if not isinstance(task_data, dict):
        return None
    if not _truthy_task_value(task_data.get("_enterprise_delivery_enabled")):
        return None
    route = str(task_data.get("_enterprise_route") or "").strip()
    if route != ENTERPRISE_ROUTE:
        return None

    skill_plan = task_data.get("_enterprise_skill_plan")
    if not isinstance(skill_plan, dict):
        skill_plan = {}
    raw_skills = (
        skill_plan.get("selected_skill_ids")
        or task_data.get("_enterprise_selected_skill_ids")
        or []
    )
    audit_selected = unique_skill_ids(raw_skills)
    if enable_tts and "tts.sync_contract" not in audit_selected:
        audit_selected.append("tts.sync_contract")
    if not audit_selected:
        return None

    selected, excluded_prompt_skills = enterprise_prompt_skill_plan(audit_selected)
    if not selected:
        selected = ["manim-output-contract"]

    is_3d_route = any(
        skill_id in audit_selected
        for skill_id in (
            "render.manim_3d_scene_contract",
            "style.spatial_3d_clean",
            "color.3d_semantic_tokens",
        )
    )
    color_profile = enterprise_color_profile(task_data, is_3d_route=is_3d_route)

    derived_color_skills = (
        (
            color_profile.get("contrast_skill_id"),
            "enterprise_color_contrast_profile",
        ),
        (
            color_profile.get("three_d_skill_id"),
            "enterprise_color_3d_profile",
        ),
    )
    derived_reasons: dict[str, str] = {}
    for skill_id, reason in derived_color_skills:
        value = str(skill_id or "").strip()
        if not value:
            continue
        if value not in audit_selected:
            audit_selected.append(value)
        if (
            value in PROMPT_SAFE_SKILL_IDS
            or value.startswith("enterprise.")
        ) and value not in selected:
            selected.append(value)
        derived_reasons[value] = reason

    template_id = str(
        skill_plan.get("template_id") or task_data.get("_enterprise_template_id") or ""
    ).strip()
    primary_skill = enterprise_primary_skill(template_id, selected)
    profile_name = str(task_data.get("render_canvas_profile_name") or "").strip() or None
    try:
        from app.core.render_canvas_profile import get_render_canvas_profile

        render_canvas_profile = get_render_canvas_profile(
            aspect_ratio,
            profile_name=profile_name,
        ).to_prompt_contract()
    except Exception:
        render_canvas_profile = {}

    prompt_segments = task_data.get("_enterprise_prompt_segments")
    if not isinstance(prompt_segments, dict):
        prompt_segments = {}
    enterprise_assembly_mode = (
        str(prompt_segments.get("assembly_mode") or "").strip()
        or ENTERPRISE_ASSEMBLY_MODE
    )
    deterministic_scaffolds = task_data.get("_enterprise_deterministic_scaffolds")
    if not isinstance(deterministic_scaffolds, dict):
        deterministic_scaffolds = {}

    reasons = {skill_id: "enterprise_prompt_whitelist" for skill_id in selected}
    reasons.update(derived_reasons)
    return {
        "schema_version": "enterprise_skill_context.v1",
        "mode": "enterprise_authoritative",
        "router_version": route,
        "assembly_mode": enterprise_assembly_mode,
        "enterprise_assembly_mode": enterprise_assembly_mode,
        "primary_skill": primary_skill,
        "selected_skills": selected,
        "audit_selected_skills": audit_selected,
        "raw_selected_skills": audit_selected,
        "reasons": reasons,
        "risk_flags": [
            "enterprise_generate_role_skill_excluded"
            for _ in excluded_prompt_skills[:1]
        ],
        "excluded_generate_role_skills": [
            skill_id
            for skill_id in excluded_prompt_skills
            if skill_id.startswith(PROMPT_EXCLUDED_PREFIXES)
        ],
        "excluded_prompt_skill_ids": excluded_prompt_skills,
        "color_profile": color_profile,
        "render_canvas_profile": render_canvas_profile,
        "enterprise_case_id": task_data.get("_enterprise_case_id"),
        "enterprise_template_id": template_id,
        "enterprise_template_name": task_data.get("_enterprise_template_name"),
        "enterprise_secondary_route_id": task_data.get(
            "_enterprise_secondary_route_id"
        ),
        "enterprise_secondary_topic_type": task_data.get(
            "_enterprise_secondary_topic_type"
        ),
        "enterprise_logo_config": task_data.get("_enterprise_logo_config")
        if isinstance(task_data.get("_enterprise_logo_config"), dict)
        else {},
        "enterprise_contract_version": task_data.get("_enterprise_contract_version"),
        "enterprise_prompt_segments": prompt_segments,
        "enterprise_deterministic_scaffolds": deterministic_scaffolds,
        "enterprise_skill_plan": skill_plan,
        "enterprise_skill_driver_shadow": task_data.get(
            "_enterprise_skill_driver_shadow"
        )
        if isinstance(task_data.get("_enterprise_skill_driver_shadow"), dict)
        else {},
        "selection_source": (
            "task_data._enterprise_skill_plan.selected_skill_ids:"
            "enterprise_prompt_slimmed"
        ),
    }


def apply_enterprise_prompt_trace_overlay(
    prompt_segments: dict[str, Any],
    cache_metrics: dict[str, Any],
    skill_context: dict[str, Any] | None,
) -> None:
    if not isinstance(skill_context, dict):
        return
    if skill_context.get("mode") != "enterprise_authoritative":
        return

    enterprise_segments = skill_context.get("enterprise_prompt_segments")
    if not isinstance(enterprise_segments, dict):
        enterprise_segments = {}

    selected = list(skill_context.get("selected_skills") or [])
    base_assembly_mode = str(prompt_segments.get("assembly_mode") or "")
    prompt_segments["base_assembly_mode"] = base_assembly_mode
    enterprise_assembly_mode = (
        skill_context.get("enterprise_assembly_mode")
        or enterprise_segments.get("assembly_mode")
        or ENTERPRISE_ASSEMBLY_MODE
    )
    prompt_segments["assembly_mode"] = enterprise_assembly_mode
    prompt_segments["enterprise_assembly_mode"] = enterprise_assembly_mode
    prompt_segments["enterprise_route"] = ENTERPRISE_ROUTE
    prompt_segments["enterprise_mode"] = "authoritative"
    prompt_segments["enterprise_case_id"] = skill_context.get("enterprise_case_id")
    prompt_segments["enterprise_template_id"] = skill_context.get(
        "enterprise_template_id"
    )
    prompt_segments["enterprise_template_name"] = skill_context.get(
        "enterprise_template_name"
    )
    prompt_segments["enterprise_secondary_route_id"] = skill_context.get(
        "enterprise_secondary_route_id"
    )
    prompt_segments["enterprise_secondary_topic_type"] = skill_context.get(
        "enterprise_secondary_topic_type"
    )
    prompt_segments["enterprise_logo_config"] = skill_context.get(
        "enterprise_logo_config"
    )
    prompt_segments["enterprise_contract_version"] = skill_context.get(
        "enterprise_contract_version"
    )
    prompt_segments["selected_skills"] = selected
    prompt_segments["audit_selected_skills"] = list(
        skill_context.get("audit_selected_skills") or selected
    )
    prompt_segments["excluded_prompt_skill_ids"] = list(
        skill_context.get("excluded_prompt_skill_ids") or []
    )
    prompt_segments["selection_source"] = skill_context.get("selection_source")

    manifest = dict(prompt_segments.get("assembly_manifest") or {})
    manifest["base_assembly_mode"] = base_assembly_mode
    manifest["assembly_mode"] = prompt_segments["assembly_mode"]
    manifest["enterprise_assembly_mode"] = enterprise_assembly_mode
    manifest["prompt_id"] = "enterprise_fastpre_generation"
    manifest["selected_skills"] = selected
    manifest["audit_selected_skills"] = prompt_segments["audit_selected_skills"]
    manifest["excluded_prompt_skill_ids"] = prompt_segments["excluded_prompt_skill_ids"]
    manifest["selection_source"] = skill_context.get("selection_source")
    manifest["enterprise_template_id"] = prompt_segments.get("enterprise_template_id")
    manifest["enterprise_case_id"] = prompt_segments.get("enterprise_case_id")
    prompt_segments["assembly_manifest"] = manifest

    cache_metrics["enterprise_route"] = ENTERPRISE_ROUTE
    cache_metrics["enterprise_assembly_mode"] = prompt_segments["assembly_mode"]
    cache_metrics["enterprise_template_id"] = prompt_segments.get(
        "enterprise_template_id"
    )
    cache_metrics["enterprise_case_id"] = prompt_segments.get("enterprise_case_id")
