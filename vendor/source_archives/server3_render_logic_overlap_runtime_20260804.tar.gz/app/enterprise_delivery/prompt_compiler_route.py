from __future__ import annotations
from typing import Any
from .prompt_compiler_v0211 import *

class PromptCompilerRouteMixin:
    @staticmethod
    def _assembly_manifest(
        *,
        prompt_id: str,
        assembly_mode: str,
        selected_skills: list[str],
        skill_blocks: list[dict[str, Any]],
        stable_prefix_hash: str,
        skill_chain_hash: str,
        dynamic_payload_hash: str,
        cache_key: str,
        layout_broker: dict[str, Any] | None = None,
        color_profile: dict[str, Any] | None = None,
        topic_profile: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        block_refs: list[dict[str, Any]] = []
        retrieval_keys: list[str] = []
        for skill_id in selected_skills:
            retrieval_keys.append(f"skill:{skill_id}")

        for block in skill_blocks:
            skill_id = str(block.get("skill_id") or "")
            block_id = str(block.get("block_id") or "")
            if not skill_id or not block_id:
                continue
            block_ref = {
                "skill_id": skill_id,
                "skill_uri": str(block.get("skill_uri") or ""),
                "block_id": block_id,
                "hash": str(block.get("hash") or ""),
                "length": int(block.get("length") or 0),
                "tags": list(block.get("tags") or []),
                "failure_codes": list(block.get("failure_codes") or []),
                "scene_phases": list(block.get("scene_phases") or []),
                "object_types": list(block.get("object_types") or []),
                "repair_actions": list(block.get("repair_actions") or []),
                "quality_targets": list(block.get("quality_targets") or []),
                "eval_case_refs": list(block.get("eval_case_refs") or []),
            }
            block_refs.append(block_ref)
            retrieval_keys.append(f"block:{skill_id}/{block_id}")
            for failure_code in block_ref["failure_codes"]:
                retrieval_keys.append(f"failure_code:{failure_code}")
            for quality_target in block_ref["quality_targets"]:
                retrieval_keys.append(f"quality_target:{quality_target}")

        manifest = {
            "schema_version": "prompt_assembly_manifest.v1",
            "prompt_id": prompt_id,
            "assembly_mode": assembly_mode,
            "selected_skills": list(selected_skills),
            "stable_prefix_hash": stable_prefix_hash,
            "skill_chain_hash": skill_chain_hash,
            "dynamic_payload_hash": dynamic_payload_hash,
            "cache_key": cache_key,
            "block_refs": block_refs,
            "retrieval_keys": retrieval_keys,
        }
        if color_profile:
            manifest["color_profile"] = dict(color_profile)
            color_scheme = color_profile.get("color_scheme")
            if color_scheme:
                retrieval_keys.append(f"color_scheme:{color_scheme}")
            scheme_skill_id = str(color_profile.get("scheme_skill_id") or "")
            contrast_skill_id = str(color_profile.get("contrast_skill_id") or "")
            three_d_skill_id = str(color_profile.get("three_d_skill_id") or "")
            if scheme_skill_id:
                retrieval_keys.append(f"color_profile:{scheme_skill_id}")
            if contrast_skill_id:
                retrieval_keys.append(f"color_contrast:{contrast_skill_id}")
            if three_d_skill_id:
                retrieval_keys.append(f"color_3d:{three_d_skill_id}")
        if topic_profile:
            manifest["topic_profile"] = dict(topic_profile)
            topic_profile_id = str(topic_profile.get("id") or "")
            selected_topic_skill = str(topic_profile.get("selected_skill_id") or "")
            if topic_profile_id:
                retrieval_keys.append(f"topic_profile:{topic_profile_id}")
            if selected_topic_skill:
                retrieval_keys.append(f"topic_profile_skill:{selected_topic_skill}")
        if layout_broker:
            owner = str(layout_broker.get("owner_skill_id") or "")
            if owner:
                retrieval_keys.append(f"layout_owner:{owner}")
            for case_type in layout_broker.get("case_types") or []:
                retrieval_keys.append(f"layout_case:{case_type}")
            for zone in layout_broker.get("required_zones") or []:
                retrieval_keys.append(f"layout_zone:{zone}")
            for rule_ref in layout_broker.get("layout_rule_refs") or []:
                retrieval_keys.append(f"layout_rule:{rule_ref}")
            manifest["layout_broker"] = layout_broker

        manifest["retrieval_keys"] = list(dict.fromkeys(retrieval_keys))
        return manifest

    @staticmethod
    def _layout_broker_evidence(
        *,
        selected_skills: list[str],
        skill_blocks: list[dict[str, Any]],
        enable_tts: bool,
        aspect_ratio: str,
    ) -> dict[str, Any]:
        selected = set(selected_skills)
        case_types = PromptCompiler._layout_case_types(
            selected_skills=selected_skills,
            enable_tts=enable_tts,
            aspect_ratio=aspect_ratio,
        )
        required_zones = PromptCompiler._required_layout_zones(case_types)
        layout_rule_refs = PromptCompiler._layout_rule_refs(
            case_types=case_types,
            skill_blocks=skill_blocks,
        )
        candidate_owners = [
            skill_id
            for skill_id in (
                "layout-safe-area-contract",
                "summary-scene-layout",
                "formula-scene-layout",
                "geometry-scene-layout",
                "portrait-9-16-contract",
                "short-video-contract",
            )
            if skill_id in selected
        ]

        return {
            "schema_version": "layout_broker.v1",
            "mode": "warn_only",
            "owner_skill_id": "layout.composition_contract",
            "owner_reason": "priority_canonical_layout_owner",
            "conflicting_owner_skill_ids": [],
            "candidate_owner_skill_ids": candidate_owners,
            "case_types": case_types,
            "priority_required_skills": list(PRIORITY_LAYOUT_REQUIRED_SKILLS),
            "required_zones": required_zones,
            "zone_taxonomy": {
                zone: dict(LAYOUT_ZONE_TAXONOMY[zone])
                for zone in required_zones
                if zone in LAYOUT_ZONE_TAXONOMY
            },
            "layout_intent_contract": {
                "schema_version": "layout_intent_contract.v1",
                "owner_skill_id": "layout.composition_contract",
                "required_fields": [
                    "zone",
                    "anchor",
                    "scale",
                    "reserved_bbox",
                    "avoid",
                ],
                "required_for": [
                    "title",
                    "text",
                    "formula",
                    "diagram",
                    "label",
                    "caption",
                ],
                "dynamic_payload_allowed_in_stable_prefix": False,
            },
            "layout_rule_refs": layout_rule_refs,
            "stable_prefix_policy": {
                "raw_dynamic_payload_allowed": False,
                "dynamic_values_must_remain_in_dynamic_payload": True,
            },
        }

    @staticmethod
    def _layout_case_types(
        *,
        selected_skills: list[str],
        enable_tts: bool,
        aspect_ratio: str,
    ) -> list[str]:
        selected = set(selected_skills)
        case_types = {
            case_type
            for skill_id, case_type in LAYOUT_CASE_SKILL_MAP.items()
            if skill_id in selected
        }
        if enable_tts:
            case_types.add("tts")
        if str(aspect_ratio).strip() == "9:16":
            case_types.add("portrait")
        return [
            case_type
            for case_type in LAYOUT_CASE_TYPE_ORDER
            if case_type in case_types
        ]

    @staticmethod
    def _required_layout_zones(case_types: list[str]) -> list[str]:
        zones = ["title_zone", "content_zone"]
        for case_type in case_types:
            zones.extend(LAYOUT_ZONES_BY_CASE.get(case_type, []))
        zones.append("safe_margin")
        return list(dict.fromkeys(zones))

    @staticmethod
    def _layout_rule_refs(
        *,
        case_types: list[str],
        skill_blocks: list[dict[str, Any]],
    ) -> list[str]:
        rule_refs = list(LAYOUT_BASE_RULE_REFS)
        for case_type in case_types:
            rule_refs.extend(LAYOUT_RULE_REFS_BY_CASE.get(case_type, []))
        for block in skill_blocks:
            for failure_code in block.get("failure_codes") or []:
                if failure_code:
                    rule_refs.append(f"failure_code:{failure_code}")
            for quality_target in block.get("quality_targets") or []:
                if quality_target:
                    rule_refs.append(f"quality_target:{quality_target}")
        return list(dict.fromkeys(rule_refs))

