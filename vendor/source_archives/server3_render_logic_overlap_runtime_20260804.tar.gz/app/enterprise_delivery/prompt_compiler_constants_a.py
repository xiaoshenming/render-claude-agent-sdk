import re

PLACEHOLDER_RE = re.compile(r"__[A-Z0-9_]+__")
ROLE_MARKER_RE = re.compile(r"(?im)^\s*(system|assistant)\s*:")
LEGACY_PLACEHOLDERS = (
    "__COLOR__",
    "__USER_PROMPT__",
    "__TTS_VOICE_GUIDE__",
    "__VOICE__",
)
STABLE_REFERENCE_PLACEHOLDERS = {
    "__RENDER_CANVAS_PROFILE__",
}
PRIORITY_LAYOUT_REQUIRED_SKILLS = [
    "runtime.manim_helper_contract",
    "layout.composition_contract",
    "tts.sync_contract",
]
LAYOUT_CASE_TYPE_ORDER = [
    "summary",
    "formula",
    "geometry",
    "tts",
    "portrait",
    "short_video",
]
LAYOUT_CASE_SKILL_MAP = {
    "summary-scene-layout": "summary",
    "formula-scene-layout": "formula",
    "geometry-scene-layout": "geometry",
    "domain.geometry": "geometry",
    "visual.triangle_overlay": "geometry",
    "tts.sync_contract": "tts",
    "tts-sync-contract": "tts",
    "portrait-9-16-contract": "portrait",
    "short-video-contract": "short_video",
}
LAYOUT_ZONES_BY_CASE = {
    "summary": [],
    "formula": ["formula_zone"],
    "geometry": ["diagram_zone"],
    "tts": ["caption_zone"],
    "portrait": [],
    "short_video": ["caption_zone", "watermark_zone"],
}
LAYOUT_ZONE_TAXONOMY = {
    "title_zone": {
        "purpose": "scene_title",
        "owner": "layout.composition_contract",
    },
    "content_zone": {
        "purpose": "primary_teaching_content",
        "owner": "layout.composition_contract",
    },
    "formula_zone": {
        "purpose": "formula_steps",
        "owner": "layout.composition_contract",
    },
    "diagram_zone": {
        "purpose": "geometry_objects",
        "owner": "layout.composition_contract",
    },
    "caption_zone": {
        "purpose": "voiceover_or_short_caption",
        "owner": "layout.composition_contract",
    },
    "watermark_zone": {
        "purpose": "brand_or_platform_watermark",
        "owner": "layout.composition_contract",
    },
    "safe_margin": {
        "purpose": "frame_boundary_clearance",
        "owner": "layout.composition_contract",
    },
}
LAYOUT_RULE_REFS_BY_CASE = {
    "summary": ["rule.summary.blank_space_budget"],
    "formula": ["rule.formula.readability_contract"],
    "geometry": ["rule.geometry.label_quality_target"],
    "tts": ["rule.tts.audio_stream_required"],
    "portrait": ["rule.portrait.safe_band_contract"],
    "short_video": ["rule.short_video.rhythm_contract"],
}
LAYOUT_BASE_RULE_REFS = [
    "rule.prompt.dynamic_payload_not_in_stable_prefix",
    "rule.layout.unique_owner",
    "rule.layout.required_zones_declared",
    "rule.layout.intent_contract_required",
]
NO_TEMPLATE_VISIBLE_BLOCK_IDS = {
    "render.output.code_only",
    "render.output.single_scene_contract",
    "render.output.scene_count_contract",
    "render.output.no_markdown_fences",
    "color.base.semantic_tokens",
    "color.base.theme_scope",
    "color.contrast.light_theme",
    "color.contrast.dark_theme",
    "color.3d_semantic_tokens",
    "runtime.manim_helper.self_contained_helpers",
    "runtime.manim_helper.formula_boundary_contract",
    "runtime.manim_helper.manim019_api_contract",
    "runtime.manim_helper.helper_return_shape",
    "runtime.manim_helper.reveal_lifecycle",
    "layout.generation.priority_contract",
    "layout.generation.title_safe_area",
    "layout.generation.title_first_scene_order",
    "layout.generation.zone_manifest",
    "layout.generation.typography_hierarchy",
    "layout.generation.no_double_fit_scaling",
    "layout.generation.frame_density_budget",
    "router.topic_example.selection_limit",
    "layout.generation.panel_lifecycle",
    "layout.generation.progressive_reveal_contract",
    "layout.generation.visible_objects_lifecycle",
    "layout.generation.final_bbox_closure",
    "layout.composition.screen_budget_table",
    "layout.composition.text_stack_clearance",
    "layout.composition.terminal_density_guard",
    "layout.safe_box_numeric_bounds",
    "layout.next_to_edge_direction_guard",
    "layout.long_payload_handling",
    "layout.progressive_reveal",
    "layout.title_top_center",
    "tts.semantic_microbeat_kernel",
    "tts.timestamp_runtime_pattern",
    "tts.short_spoken_math",
    "style.dynamic_geometry_proof.palette",
    "style.dynamic_geometry_proof.typography",
    "formula.text_payload_contract",
    "formula.text_mathtex_boundary",
    "formula.proof_step_inline_math_positive_example",
    "formula.no_text_string_replace_for_tex",
    "formula.stepwise_derivation",
    "formula.scene_scope_budget",
    "geometry.define_objects_first",
    "geometry.label_anchor",
    "geometry.label_anchor.outside_offset",
    "geometry.label_anchor.collision_scan",
    "geometry.label_anchor.angle_wedge_clearance",
    "geometry.label_anchor.typed_anchor_examples",
    "geometry.label_anchor.panel_avoidance",
    "geometry.model_schema.shared_contract",
    "geometry.angle_mark.real_primitives",
    "geometry.transform_label_recheck",
    "geometry.transform.target_rebuild",
    "geometry.transform.correspondence_state_table",
    "geometry.transform.simple_motion_paths",
    "geometry.circle_theorem.arc_angle_tangent",
    "geometry.congruence.proof_step_back_reference",
    "geometry.helper_boundary.no_canvas_hallucination",
}
NO_TEMPLATE_VISIBLE_BLOCK_PREFIXES = (
    "color.scheme.",
    "summary.",
    "portrait.",
    "short_video.",
    "three_d.",
    "render.manim_2d",
    "render.manim_3d",
    "geometry.example.",
    "topic.example.",
)
NO_TEMPLATE_FULL_TEXT_BLOCK_PREFIXES = (
    "geometry.example.",
    "topic.example.",
)
NO_TEMPLATE_COMPACT_BLOCK_CHAR_LIMIT = 450
NO_TEMPLATE_COMPACT_KEEP_LINE_MARKERS = (
    "3d.solid_geometry_primitive_manifest",
    "script-level font-size tokens",
    "same semantic role must reuse the same token",
    "largest durable explanatory text should not exceed about 1.45x",
    "visible placeholder text or placeholder boxes cannot stand in for missing helpers",
    "Complex geometry must write named points",
    "Use FONT_BODY, FONT_FORMULA, FONT_LABEL, and FONT_CAPTION",
    "Object lifecycle contract",
    "the same text content appears once as one live object",
    "FadeOut the old object or update visible_objects/durable_objects",
    "one sentence and one visible action",
    "content coverage inventory",
    "panel lifecycle",
    "row.set_opacity(0)",
    "Write(proof_panel)",
    "FadeIn(proof_panel)",
    "Write(text_panel)",
    "FadeIn(text_panel)",
    "named by the narration",
    "prefer 5 to 6 complete teaching Scenes",
    "merge decorative outro",
    "post-voiceover self.wait(1)",
    "Write(panel) or FadeIn(VGroup",
    "Text/proof/formula row actions",
    "3D TTS scenes follow the same micro-beat contract",
    "Prefer 12-20 Chinese characters",
    "Narration layout-word rewrite rule",
    "VGroup visual atom boundary",
    "wait_until_bookmark",
)
COLOR_SCHEME_PROFILES = {
    "color.scheme.light_fresh": {
        "color_scheme": 1,
        "scheme_name": "light_fresh",
        "contrast_profile": "light",
    },
    "color.scheme.soft_academic": {
        "color_scheme": 2,
        "scheme_name": "soft_academic",
        "contrast_profile": "light",
    },
    "color.scheme.classic_black": {
        "color_scheme": 3,
        "scheme_name": "classic_black",
        "contrast_profile": "dark",
    },
    "color.scheme.deep_focus": {
        "color_scheme": 4,
        "scheme_name": "deep_focus",
        "contrast_profile": "dark",
    },
}
COLOR_CONTRAST_PROFILES = {
    "color.contrast.light_theme": "light",
    "color.contrast.dark_theme": "dark",
}
COLOR_3D_SKILL_ID = "color.3d_semantic_tokens"
TOPIC_PROFILE_SKILL_IDS = {
    "concept.cylinder_volume_derivation": "mathpi_3d_volume",
    "layout.non_geometry_card_timeline": "non_geometry_card",
}
