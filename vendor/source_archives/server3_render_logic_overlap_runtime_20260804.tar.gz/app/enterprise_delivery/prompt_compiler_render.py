from __future__ import annotations
from typing import Any
from .prompt_compiler_v0211 import *

class PromptCompilerRenderMixin:

    @staticmethod
    def _compact_no_template_block_text(block_id: str, text: str) -> str:
        if block_id.startswith(NO_TEMPLATE_FULL_TEXT_BLOCK_PREFIXES):
            return text
        if len(text) <= NO_TEMPLATE_COMPACT_BLOCK_CHAR_LIMIT:
            return text
        compact = text[:NO_TEMPLATE_COMPACT_BLOCK_CHAR_LIMIT].rstrip()
        retained_lines = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and any(
                marker in stripped for marker in NO_TEMPLATE_COMPACT_KEEP_LINE_MARKERS
            ):
                retained_lines.append(stripped)
        return (
            f"{compact}\n"
            + ("\n".join(retained_lines) + "\n" if retained_lines else "")
            + "[compact_no_template: full block retained in Skill OS catalog; "
            "only the first-pass summary is shown here.]"
        )

    @classmethod
    def _render_skill_prompt_prefix(
        cls,
        skill_blocks: list[dict[str, Any]],
        *,
        compact_no_template: bool = False,
    ) -> str:
        if not skill_blocks:
            return ""
        from app.agents.skills.prompt_blocks import resolve_skill_stable_blocks
        from app.agents.skills.registry import get_runtime_skill

        parts = ["## Render Skill OS Skill Blocks"]
        for descriptor in skill_blocks:
            try:
                skill = get_runtime_skill(str(descriptor["skill_id"]))
            except KeyError:
                continue
            block_text_by_id = {
                block["block_id"]: block["text"]
                for block in resolve_skill_stable_blocks(skill)
            }
            text = block_text_by_id.get(str(descriptor["block_id"]))
            if not text:
                continue
            if compact_no_template:
                text = cls._compact_no_template_block_text(
                    str(descriptor["block_id"]),
                    text,
                )
            parts.append(f"[{descriptor['skill_uri']}#{descriptor['block_id']}]\n{text}")
        return "\n\n".join(parts)

    @staticmethod
    def _cacheable_messages(
        stable_prefix: str,
        dynamic_bindings: str,
    ) -> list[dict[str, Any]]:
        if stable_prefix and dynamic_bindings:
            return [
                {
                    "role": "user",
                    "content": stable_prefix,
                    "segment_type": "stable_prefix",
                    "cache_control": {"type": "ephemeral"},
                },
                {
                    "role": "user",
                    "content": dynamic_bindings,
                    "segment_type": "dynamic_payload",
                },
            ]
        return [
            {
                "role": "user",
                "content": stable_prefix or dynamic_bindings,
                "segment_type": "legacy_full_prompt",
            }
        ]

    @staticmethod
    def _provider_cache_split(*, assembly_mode: str, message_count: int) -> str:
        if assembly_mode == "no_template_skill_graph" and message_count > 1:
            return "no_template_skill_graph"
        if assembly_mode == "block_first" and message_count > 1:
            return "block_first"
        return "stable_prefix" if message_count > 1 else "legacy_full_prompt"

    @staticmethod
    def _no_template_skill_graph_stable_prefix(*, skill_prompt_prefix: str) -> str:
        parts = [
            "## Render Skill OS No-Template Skill Graph",
            (
                "System contract: generate Manim 0.19 Python from the stable skill "
                "graph. Treat the next message as job-specific dynamic slots only."
            ),
            RUNTIME_HEADER_ABI_CONTRACT,
        ]
        if skill_prompt_prefix:
            parts.append(skill_prompt_prefix)
        parts.append(
            "\n".join(
                [
                    "## Output Schema / Return Discipline",
                    "Return discipline: output only executable Python for Manim.",
                    "For TTS jobs, the TTS Semantic Micro-Beat Kernel overrides style, layout examples, and geometry examples for timing structure. Ordinary first-pass TTS generation should use short voiceover blocks. Inherit BaseConfigScene, call self.setup_layout(), then call self.voiceover plus self.play_steps_evenly([animations_for_this_beat], tracker). Do not redefine the TTS runtime or timing helpers.",
                    "TTS sync minimum: planned_scenes.voiceover is the authoritative teacher narration content. voice_script_blocks are only voiceover slices plus visual mapping; sync_units are only visual anchors. Each block becomes one voiceover block with one spoken Chinese sentence copied from the supplied spoken_text, one visual_focus, and one semantic visual beat. Do not rewrite spoken_text from visual_action, single_action_name, teaching_claim, proof_row_text, diagram_support, layout words, or geometry operations. Prefer 12-20 Chinese characters when natural; 21-24 Chinese characters are acceptable; do not split a natural semantic beat just to hit the 12-20 range; split anything over 30 before code generation. A semantic beat may contain 1-3 tightly related local animations when they share one visual focus, such as play_steps_evenly([Create(line_ab), FadeIn(label_ab)], tracker) or play_steps_evenly([Indicate(target_angle), Write(row_angle)], tracker). Never write VGroup(Write(row_1), Write(row_2)), VGroup(FadeIn(dot), FadeIn(label)), VGroup(Create(line), Write(row)), or play_steps_evenly([VGroup(FadeIn(...), Write(...))], tracker). VGroup visual atom boundary: allowed small atoms include FadeIn(VGroup(dot_a, label_a)) when it is one local object; forbidden large atoms include FadeIn(diagram_group), Create(VGroup(circle, all_points, all_labels, chord, tangent)), Write(VGroup(row1, row2, row3)), and any full proof panel or multi-row summary. Do not hide a whole diagram, full proof panel, all labels, or a multi-row summary inside one VGroup action; split larger reveals into adjacent voiceover blocks. Do not merge multiple voice_script_blocks. Do not invent a long narration paragraph when voice_script_blocks are provided. Do not group adjacent sync_units into one large voiceover block; if only sync_units are supplied, treat them as visual timing anchors and create short matching voiceover blocks without inventing long narration paragraphs.",
                    "TTS narration language: do not read UI layout words such as right-side panel, left-side panel, screen right side, or write on the left. Narration layout-word rewrite rule: 右侧面板记录下 -> 记录下; 右侧写下 -> 写下; 屏幕左侧展示 -> 展示; 左边列出 -> 列出. Math direction words are allowed, such as right endpoint, outside the circle, or left side of the symmetry axis. Do not use post-voiceover self.wait(2); keep any static tail at or below 0.5 seconds.",
                    "TTS reveal lifecycle: build/fix layout first but do not show this Scene's new teaching content. self.add(...) is allowed only for background, previous entry_state, or already-taught objects listed by silent_context_objects. Every object listed by new_reveals, spoken_reveal_objects, new_object, reveal_targets, or visual_focus must appear inside the matching voiceover block with self.play_steps_evenly([animations_for_this_beat], tracker). Do not pre-add new rows, formulas, points, angle marks, labels, transformed images, or conclusions. Do not use dummy_text add then FadeOut as the first spoken event.",
                    "Panel reveal shape: rows=[row1,row2,formula]; text_panel/proof_panel=VGroup(*rows).arrange(...); fit parent panel first; then open one short voiceover per row. Text/formula row actions may use about 0.9-1.6 seconds; key proof/conclusion rows may use 1.2-1.8 seconds; geometry actions can stay around 0.6-1.0 seconds. A *_panel VGroup is a layout container only. Do not use Write(panel), FadeIn(proof_panel), FadeIn(text_panel), FadeIn(summary_panel), FadeIn(VGroup(...)), VGroup(Write(...)), VGroup(FadeIn(...)), VGroup(Create(...)), reveal_rows/play_reveal_sequence shortcuts, raw self.add reveals, raw multi-animation self.play calls inside voiceover, raw consecutive self.play calls inside voiceover, large unrelated AnimationGroup bundles, run_time=tracker.duration, tracker.duration remainder waits, wait-only voiceover blocks, post-voiceover self.wait(1), or post-voiceover self.wait(2). 3D TTS scenes follow the same micro-beat contract as 2D. Camera movement should be its own semantic beat, or pair only with a short label that names the same focus, and must be passed through self.play_steps_evenly([animations_for_this_beat], tracker); never use raw self.play(..., run_time=tracker.duration) or self.move_camera(..., run_time=tracker.duration - constant). Use no static tail longer than 0.5 seconds.",
                    "For TTS jobs, every generated Scene class must inherit BaseConfigScene; never inherit plain Scene when calling setup_layout, voiceover, play_steps_evenly, or play_synced_steps.",
                    "Do not invent a custom BaseConfigScene, GlobalConfig, runtime helper method, theme alias, or helper/base class that differs from the project runtime/header contract.",
                    "No markdown fences, no explanation, no slot markers.",
                ]
            )
        )
        parts.append(
            "\n".join(
                [
                    "## Scene Coverage Contract",
                    "The dynamic slots may include scene_output_contract, planned_scene_count, minimum_scene_count, and planned_scenes.",
                    "When planned_scenes are supplied, generate one concrete Scene class for each planned scene in the same order.",
                    "Do not collapse a multi-scene lesson into a three-part summary when the plan asks for more scenes.",
                    "The generated Scene class count must be at least minimum_scene_count and should match planned_scene_count when that can be done with complete scenes.",
                    "Content completeness has priority over decorative scene count: never output a half-finished final Scene. If TTS plus a long planned_scenes list would make the last outro/thanks scene thin or truncated, merge that outro into the preceding summary/transfer scene while still satisfying minimum_scene_count.",
                    "For TTS geometry lessons, prefer 5 to 6 complete teaching Scenes over 7 or 8 thin Scenes. A sparse summary/transfer Scene may include the closing sentence; do not create a separate low-content Outro just to match a decorative count.",
                    "Do not invent extra Scene classes beyond planned_scene_count; helper/base classes are owned by the project runtime/header.",
                    "Each planned scene should preserve its title, purpose, visual_description, math_content, approximate duration intent, and slice_visual_continuity fields.",
                    "For non-reset Scene_02+ planned_scenes, use primary_object_id, entry_state, exit_state, and motion_bridge as the continuity source: rebuild the entry_state silently, then animate only the local bridge.",
                ]
            )
        )
        return "\n\n".join(parts)

    def _block_first_stable_prefix(
        self,
        *,
        skill_prompt_prefix: str,
        template: str,
    ) -> str:
        parts = [
            "## Render Skill OS Block-First Assembly",
            "Use the stable skill blocks and base prompt skeleton below. "
            "Resolve only the dynamic slot bindings from the following message.",
            RUNTIME_HEADER_ABI_CONTRACT,
        ]
        if skill_prompt_prefix:
            parts.append(skill_prompt_prefix)
        parts.append(self._stable_template_skeleton(template))
        return "\n\n".join(parts)

    @staticmethod
    def _stable_template_skeleton(template: str) -> str:
        skeleton = template
        for placeholder in LEGACY_PLACEHOLDERS:
            skeleton = skeleton.replace(
                placeholder,
                f"{{{{DYNAMIC_SLOT:{placeholder.strip('_')}}}}}",
            )
        return "\n".join(
            [
                "## Render Skill OS Stable Prompt Skeleton",
                "The dynamic slot values are supplied in the next message. "
                "Apply them before generating Manim code; never output slot markers.",
                skeleton,
            ]
        )
