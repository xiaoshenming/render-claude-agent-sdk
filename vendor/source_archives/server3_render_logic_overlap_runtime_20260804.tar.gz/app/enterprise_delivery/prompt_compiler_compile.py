from .prompt_compiler_v0211 import *
class PromptCompilerCompileMixin:
        def compile_legacy_generation_prompt(self, compile_input):
            template = self.template_resolver(
                compile_input.provider,
                compile_input.enable_tts,
                compile_input.aspect_ratio,
            )
            legacy_prompt_content = (
                template
                .replace("__COLOR__", compile_input.color_code)
                .replace("__USER_PROMPT__", compile_input.user_prompt)
            )
            if compile_input.enable_tts:
                legacy_prompt_content = legacy_prompt_content.replace(
                    "__TTS_VOICE_GUIDE__",
                    get_tts_voice_guide(
                        voice_type=compile_input.voice_type,
                        cosyvoice_id=compile_input.cosyvoice_id,
                    ),
                )
            else:
                legacy_prompt_content = legacy_prompt_content.replace("__TTS_VOICE_GUIDE__", "")
            if (
                compile_input.enable_tts
                and compile_input.voice_type == "clone"
                and compile_input.cosyvoice_id
            ):
                from app.prompts.clone_voice_prompts import use_clone_voice_service
                legacy_prompt_content = use_clone_voice_service(legacy_prompt_content)
                legacy_prompt_content = legacy_prompt_content.replace(
                    "__VOICE__", "runtime_configured_outside_prompt"
                )
            elif compile_input.enable_tts:
                legacy_prompt_content = legacy_prompt_content.replace(
                    "__VOICE__", "runtime_configured_outside_prompt"
                )
            compact_planned_scenes = self._compact_planned_scenes(
                compile_input.planned_scenes
            )
            planned_scenes_for_prompt = normalize_enterprise_planned_scenes(
                compact_planned_scenes,
                skill_context=compile_input.skill_context,
                scaffold_ids=self._enterprise_deterministic_scaffold_ids(
                    compile_input.skill_context
                ),
            )
            scene_output_contract = self._scene_output_contract_from_compact(
                planned_scene_count=compile_input.planned_scene_count,
                minimum_scene_count=compile_input.minimum_scene_count,
                compact_scenes=planned_scenes_for_prompt,
            )
            render_canvas_profile_name = (
                compile_input.render_canvas_profile_name
                or self._render_canvas_profile_name_from_skill_context(
                    compile_input.skill_context
                )
            )
            render_canvas_profile = self._render_canvas_profile_contract(
                compile_input.aspect_ratio,
                profile_name=render_canvas_profile_name,
            )
            dynamic_payload_values = {
                "render_stack": self._render_stack_contract(compile_input.provider),
                "user_prompt": self._topic_without_provider_labels(compile_input.user_prompt),
                "color_code": compile_input.color_code,
                "enable_tts": compile_input.enable_tts,
                "tts_contract": self._tts_runtime_contract(
                    {"enable_tts": compile_input.enable_tts}
                ),
                "aspect_ratio": compile_input.aspect_ratio,
                "render_canvas_profile": render_canvas_profile,
                "scene_output_contract": scene_output_contract,
                "planned_scene_count": scene_output_contract.get("planned_scene_count", 0),
                "minimum_scene_count": scene_output_contract.get("minimum_scene_count", 0),
                "planned_scenes": planned_scenes_for_prompt,
            }
            dynamic_payload = self._dynamic_payload_descriptors(dynamic_payload_values)
            selected_skills = list(compile_input.selected_skills or [])
            profile_manifest = self._profile_manifest(
                selected_skills=selected_skills,
                skill_context=compile_input.skill_context,
            )
            all_skill_blocks = self._skill_block_descriptors(selected_skills)
            has_skill_blocks = bool(all_skill_blocks)
            if compile_input.no_template_assembly and has_skill_blocks:
                assembly_mode = "no_template_skill_graph"
            elif compile_input.block_first_assembly and has_skill_blocks:
                assembly_mode = "block_first"
            else:
                assembly_mode = "legacy_template"
            skill_blocks = (
                self._no_template_visible_skill_blocks(all_skill_blocks)
                if assembly_mode == "no_template_skill_graph"
                else all_skill_blocks
            )
            legacy_fallback_used = bool(
                compile_input.no_template_assembly and not has_skill_blocks
            )
            legacy_fallback_reason = (
                "no_selected_skill_blocks" if legacy_fallback_used else ""
            )
            template_family = (
                "no_template_skill_graph"
                if assembly_mode == "no_template_skill_graph"
                else "legacy_template"
            )
            block_first_fallback = (
                "no_selected_skill_blocks"
                if compile_input.block_first_assembly and not has_skill_blocks
                else ""
            )
            skill_prompt_prefix = (
                self._render_skill_prompt_prefix(
                    skill_blocks,
                    compact_no_template=(assembly_mode == "no_template_skill_graph"),
                )
                if (
                    compile_input.include_skill_prompt_blocks
                    or assembly_mode in {"block_first", "no_template_skill_graph"}
                )
                else ""
            )
            enterprise_scaffold_prefix = self._enterprise_deterministic_scaffold_prompt(
                compile_input.skill_context
            )
            if enterprise_scaffold_prefix:
                skill_prompt_prefix = (
                    f"{skill_prompt_prefix}\n\n{enterprise_scaffold_prefix}"
                    if skill_prompt_prefix
                    else enterprise_scaffold_prefix
                )
            dynamic_bindings = (
                self._no_template_dynamic_slot_bindings(dynamic_payload_values)
                if assembly_mode == "no_template_skill_graph"
                else self._dynamic_slot_bindings(dynamic_payload_values)
            )
            prompt_content = legacy_prompt_content
            if assembly_mode == "no_template_skill_graph":
                stable_prefix = self._no_template_skill_graph_stable_prefix(
                    skill_prompt_prefix=skill_prompt_prefix,
                )
                prompt_content = f"{stable_prefix}\n\n{dynamic_bindings}"
            elif assembly_mode == "block_first":
                stable_prefix = self._block_first_stable_prefix(
                    skill_prompt_prefix=skill_prompt_prefix,
                    template=template,
                )
            elif skill_prompt_prefix:
                stable_prefix = self._stable_template_skeleton(template)
                prompt_content = f"{skill_prompt_prefix}\n\n{legacy_prompt_content}"
                stable_prefix = f"{skill_prompt_prefix}\n\n{stable_prefix}"
            else:
                stable_prefix = self._stable_template_skeleton(template)
            if block_first_fallback or legacy_fallback_used:
                cacheable_messages = [
                    {
                        "role": "user",
                        "content": prompt_content,
                        "segment_type": "legacy_full_prompt",
                    }
                ]
            else:
                cacheable_messages = self._cacheable_messages(stable_prefix, dynamic_bindings)
            message_segments = [
                {
                    "role": message["role"],
                    "segment_type": message["segment_type"],
                    "hash": _hash_text(str(message.get("content") or "")),
                    "length": len(str(message.get("content") or "")),
                }
                for message in cacheable_messages
            ]
            skill_prefix = "\n".join(f"skill://{skill}@active" for skill in selected_skills)
            template_dynamic_slots = {
                name for name in LEGACY_PLACEHOLDERS if name in template
            }
            prompt_segments = {
                "schema_version": "prompt_segments.v1",
                "assembly_mode": assembly_mode,
                "block_first_requested": compile_input.block_first_assembly,
                "block_first_fallback": block_first_fallback,
                "no_template_requested": compile_input.no_template_assembly,
                "legacy_fallback_used": legacy_fallback_used,
                "legacy_fallback_reason": legacy_fallback_reason,
                "template_family": template_family,
                "stable_prefix": stable_prefix,
                "stable_prefix_hash": _hash_text(stable_prefix),
                "stable_prefix_len": len(stable_prefix),
                "legacy_preview_hash": _hash_text(legacy_prompt_content),
                "legacy_preview_len": len(legacy_prompt_content),
                "skill_prefix": skill_prefix,
                "skill_prefix_hash": _hash_text(skill_prefix),
                "skill_blocks": skill_blocks,
                "skill_blocks_full_count": len(all_skill_blocks),
                "skill_blocks_visible_count": len(skill_blocks),
                "skill_blocks_hidden_count": max(0, len(all_skill_blocks) - len(skill_blocks)),
                "skill_prompt_prefix_hash": _hash_text(skill_prompt_prefix),
                "skill_prompt_prefix_len": len(skill_prompt_prefix),
                "skill_prompt_prefix_injected": bool(skill_prompt_prefix),
                "enterprise_deterministic_scaffold_prefix_hash": _hash_text(
                    enterprise_scaffold_prefix
                )
                if enterprise_scaffold_prefix
                else "",
                "enterprise_deterministic_scaffold_prefix_len": len(
                    enterprise_scaffold_prefix
                ),
                "enterprise_deterministic_scaffold_ids": (
                    self._enterprise_deterministic_scaffold_ids(
                        compile_input.skill_context
                    )
                ),
                "enterprise_planned_scenes_normalized": is_enterprise_context(
                    compile_input.skill_context
                ),
                "skill_chain_hash": _json_hash(selected_skills),
                "dynamic_payload": dynamic_payload,
                "dynamic_payload_hash": _json_hash(dynamic_payload_values),
                "dynamic_payload_len": sum(
                    len(str(value)) for value in dynamic_payload_values.values()
                ),
                "scene_output_contract": scene_output_contract,
                "color_profile": profile_manifest["color_profile"],
                "topic_profile": profile_manifest["topic_profile"],
                "profile_manifest": profile_manifest,
                "dynamic_slot_names": [
                    name for name in LEGACY_PLACEHOLDERS if name in template_dynamic_slots
                ],
                "message_segments": message_segments,
                "prompt_hash": _hash_text(prompt_content),
            }
            prompt_segments["cache_key"] = _json_hash({
                "stable_prefix_hash": prompt_segments["stable_prefix_hash"],
                "skill_chain_hash": prompt_segments["skill_chain_hash"],
            })
            prompt_segments["layout_broker"] = self._layout_broker_evidence(
                selected_skills=selected_skills,
                skill_blocks=skill_blocks,
                enable_tts=compile_input.enable_tts,
                aspect_ratio=compile_input.aspect_ratio,
            )
            prompt_segments["assembly_manifest"] = self._assembly_manifest(
                prompt_id="legacy_generation",
                assembly_mode=assembly_mode,
                selected_skills=selected_skills,
                skill_blocks=skill_blocks,
                stable_prefix_hash=prompt_segments["stable_prefix_hash"],
                skill_chain_hash=prompt_segments["skill_chain_hash"],
                dynamic_payload_hash=prompt_segments["dynamic_payload_hash"],
                cache_key=prompt_segments["cache_key"],
                layout_broker=prompt_segments["layout_broker"],
                color_profile=profile_manifest["color_profile"],
                topic_profile=profile_manifest["topic_profile"],
            )
            cache_metrics = {
                "schema_version": "cache_metrics.v1",
                "assembly_mode": assembly_mode,
                "block_first_requested": compile_input.block_first_assembly,
                "block_first_fallback": block_first_fallback,
                "no_template_requested": compile_input.no_template_assembly,
                "legacy_fallback_used": legacy_fallback_used,
                "legacy_fallback_reason": legacy_fallback_reason,
                "template_family": template_family,
                "stable_prefix_hash": prompt_segments["stable_prefix_hash"],
                "skill_chain_hash": prompt_segments["skill_chain_hash"],
                "dynamic_payload_hash": prompt_segments["dynamic_payload_hash"],
                "cache_key": prompt_segments["cache_key"],
                "provider_cache_message_count": len(cacheable_messages),
                "provider_cache_stable_message_hash": (
                    message_segments[0]["hash"] if message_segments else ""
                ),
                "provider_cache_dynamic_message_hash": (
                    message_segments[1]["hash"] if len(message_segments) > 1 else ""
                ),
                "provider_cache_split": self._provider_cache_split(
                    assembly_mode=assembly_mode,
                    message_count=len(cacheable_messages),
                ),
            }
            firewall_report = self.firewall.lint_template_and_output(
                template=template,
                output=prompt_content,
                stable_prefix=stable_prefix,
                dynamic_values=self._firewall_dynamic_values(compile_input),
                messages=(
                    cacheable_messages
                    if assembly_mode in {"block_first", "no_template_skill_graph"}
                    else [{"role": "user", "content": prompt_content}]
                ),
                selected_skills=selected_skills,
                prompt_segments=prompt_segments,
            )
            return PromptCompileResult(
                prompt_content=prompt_content,
                cacheable_messages=cacheable_messages,
                prompt_segments=prompt_segments,
                cache_metrics=cache_metrics,
                firewall_report=firewall_report,
            )
