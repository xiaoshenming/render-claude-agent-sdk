from .prompt_compiler_v0211 import *
from .prompt_compiler_v0211 import _hash_text, _json_hash, REPAIR_CACHE_STABLE_PRIMER
from .prompt_firewall import PromptFirewall
def compile_cacheable_segmented_prompt(
    *,
    prompt_id: str,
    stable_prefix: str,
    dynamic_payload: str,
    selected_skills: list[str] | None = None,
    expected_skill_role: str = "generate",
    stable_primer: str = "",
    dynamic_payload_type: str = "dynamic_payload",
) -> PromptCompileResult:
    """Compile a prompt into stable/dynamic messages for provider caching."""
    from .prompt_compiler_v0211 import PromptCompiler
    selected = list(selected_skills or [])
    stable = str(stable_prefix or "").strip()
    primer = str(stable_primer or "").strip()
    if primer and primer not in stable:
        stable = f"{stable}\n\n{primer}" if stable else primer
    dynamic = str(dynamic_payload or "").strip()
    profile_manifest = PromptCompiler._profile_manifest(
        selected_skills=selected,
        skill_context=None,
    )
    prompt_content = f"{stable}\n\n{dynamic}" if stable and dynamic else stable or dynamic
    cacheable_messages = []
    if stable and dynamic:
        cacheable_messages = [
            {
                "role": "user",
                "content": stable,
                "segment_type": "stable_prefix",
                "cache_control": {"type": "ephemeral"},
            },
            {
                "role": "user",
                "content": dynamic,
                "segment_type": "dynamic_payload",
            },
        ]
    else:
        cacheable_messages = [
            {
                "role": "user",
                "content": prompt_content,
                "segment_type": "legacy_full_prompt",
            }
        ]

    skill_prefix = "\n".join(f"skill://{skill}@active" for skill in selected)
    stable_hash = _hash_text(stable)
    dynamic_hash = _hash_text(dynamic)
    skill_chain_hash = _json_hash(selected)
    message_segments = [
        {
            "role": message["role"],
            "segment_type": message["segment_type"],
            "hash": _hash_text(str(message.get("content") or "")),
            "length": len(str(message.get("content") or "")),
        }
        for message in cacheable_messages
    ]
    prompt_segments = {
        "schema_version": "prompt_segments.v1",
        "prompt_id": prompt_id,
        "stable_prefix": stable,
        "stable_prefix_hash": stable_hash,
        "stable_prefix_len": len(stable),
        "skill_prefix": skill_prefix,
        "skill_prefix_hash": _hash_text(skill_prefix),
        "skill_chain_hash": skill_chain_hash,
        "selected_skills": selected,
        "dynamic_payload": {
            "type": dynamic_payload_type,
            "length": len(dynamic),
            "hash": dynamic_hash,
        },
        "dynamic_payload_hash": dynamic_hash,
        "dynamic_payload_len": len(dynamic),
        "color_profile": profile_manifest["color_profile"],
        "topic_profile": profile_manifest["topic_profile"],
        "profile_manifest": profile_manifest,
        "message_segments": message_segments,
        "prompt_hash": _hash_text(prompt_content),
    }
    prompt_segments["cache_key"] = _json_hash(
        {
            "prompt_id": prompt_id,
            "stable_prefix_hash": stable_hash,
            "skill_chain_hash": skill_chain_hash,
        }
    )
    prompt_segments["assembly_manifest"] = PromptCompiler._assembly_manifest(
        prompt_id=prompt_id,
        assembly_mode="segmented_prompt",
        selected_skills=selected,
        skill_blocks=[],
        stable_prefix_hash=stable_hash,
        skill_chain_hash=skill_chain_hash,
        dynamic_payload_hash=dynamic_hash,
        cache_key=prompt_segments["cache_key"],
        color_profile=profile_manifest["color_profile"],
        topic_profile=profile_manifest["topic_profile"],
    )
    cache_metrics = {
        "schema_version": "cache_metrics.v1",
        "stable_prefix_hash": stable_hash,
        "skill_chain_hash": skill_chain_hash,
        "dynamic_payload_hash": dynamic_hash,
        "cache_key": prompt_segments["cache_key"],
        "selected_skills": selected,
        "provider_cache_message_count": len(cacheable_messages),
        "provider_cache_stable_message_hash": (
            message_segments[0]["hash"] if message_segments else ""
        ),
        "provider_cache_dynamic_message_hash": (
            message_segments[1]["hash"] if len(message_segments) > 1 else ""
        ),
        "provider_cache_split": (
            "stable_prefix" if len(cacheable_messages) > 1 else "legacy_full_prompt"
        ),
    }
    firewall_report = PromptFirewall().lint_template_and_output(
        template=stable,
        output=prompt_content,
        stable_prefix=stable,
        dynamic_values=[dynamic],
        messages=cacheable_messages,
        selected_skills=selected,
        prompt_segments=prompt_segments,
        expected_skill_role=expected_skill_role,
    )
    return PromptCompileResult(
        prompt_content=prompt_content,
        cacheable_messages=cacheable_messages,
        prompt_segments=prompt_segments,
        cache_metrics=cache_metrics,
        firewall_report=firewall_report,
    )


def compile_cacheable_repair_prompt(
    *,
    prompt_id: str,
    stable_prefix: str,
    dynamic_payload: str,
    selected_skills: list[str] | None = None,
    expected_skill_role: str = "repair",
) -> PromptCompileResult:
    """Compile repair prompts into stable/dynamic messages for provider caching."""
    return compile_cacheable_segmented_prompt(
        prompt_id=prompt_id,
        stable_prefix=stable_prefix,
        dynamic_payload=dynamic_payload,
        selected_skills=selected_skills,
        expected_skill_role=expected_skill_role,
        stable_primer=REPAIR_CACHE_STABLE_PRIMER
        if expected_skill_role == "repair"
        else "",
        dynamic_payload_type="repair_payload",
    )
