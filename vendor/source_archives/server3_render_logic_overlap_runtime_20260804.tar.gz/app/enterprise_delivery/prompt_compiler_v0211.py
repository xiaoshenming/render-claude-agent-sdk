"""Prompt compiler primitives for Render Skill OS.

The first compiler path deliberately preserves the legacy prompt bytes while
making the stable/dynamic boundaries observable for cache and skill routing.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re
from typing import Any, Callable

from app.prompts.header_runtime_fragments import RUNTIME_HEADER_ABI_CONTRACT
from app.prompts.prompt_factory import get_prompt_template
from app.prompts.tts_voice_guide import get_tts_voice_guide
from app.enterprise_delivery.single_source_input import (
    is_enterprise_context,
    normalize_enterprise_planned_scenes,
)


def _hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def _json_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return _hash_text(payload)


@dataclass(slots=True)
class PromptCompileInput:
    provider: str
    user_prompt: str
    color_code: str
    enable_tts: bool
    tts_voice: str
    voice_type: str
    cosyvoice_id: str
    aspect_ratio: str
    selected_skills: list[str] | None = None
    include_skill_prompt_blocks: bool = False
    block_first_assembly: bool = False
    no_template_assembly: bool = False
    planned_scene_count: int | None = None
    minimum_scene_count: int | None = None
    planned_scenes: list[dict[str, Any]] | None = None
    skill_context: dict[str, Any] | None = None
    render_canvas_profile_name: str | None = None


@dataclass(slots=True)
class PromptCompileResult:
    prompt_content: str
    cacheable_messages: list[dict[str, Any]]
    prompt_segments: dict[str, Any]
    cache_metrics: dict[str, Any]
    firewall_report: dict[str, Any]

from .prompt_compiler_constants_a import *
from .prompt_compiler_constants_b import *
from .prompt_firewall import PromptFirewall
from .prompt_compiler_context import PromptCompilerContextMixin
from .prompt_compiler_profile import PromptCompilerProfileMixin
from .prompt_compiler_normalize import PromptCompilerNormalizeMixin
from .prompt_compiler_contract import PromptCompilerContractMixin
from .prompt_compiler_render import PromptCompilerRenderMixin
from .prompt_compiler_route import PromptCompilerRouteMixin
from .prompt_compiler_compile import PromptCompilerCompileMixin
from .prompt_compiler_cache import (compile_cacheable_segmented_prompt, compile_cacheable_repair_prompt)

class PromptCompiler(
    PromptCompilerContextMixin,
    PromptCompilerProfileMixin,
    PromptCompilerNormalizeMixin,
    PromptCompilerContractMixin,
    PromptCompilerRenderMixin,
    PromptCompilerRouteMixin,
    PromptCompilerCompileMixin,
):
    """Compile legacy prompts without changing the rendered prompt content."""

    def __init__(
        self,
        *,
        template_resolver: Callable[[str, bool, str], str] | None = None,
        firewall: PromptFirewall | None = None,
    ) -> None:
        self.template_resolver = template_resolver or get_prompt_template
        self.firewall = firewall or PromptFirewall()

    def _render_canvas_profile_name_from_skill_context(
        skill_context: dict[str, Any] | None,
    ) -> str | None:
        if not isinstance(skill_context, dict):
            return None
        profile = skill_context.get("render_canvas_profile")
        if not isinstance(profile, dict):
            return None
        value = str(profile.get("profile_name") or "").strip()
        return value or None


