from __future__ import annotations
from typing import Any
from .prompt_compiler_v0211 import *

class PromptCompilerProfileMixin:
    @classmethod
    def _profile_manifest(
        cls,
        *,
        selected_skills: list[str],
        skill_context: dict[str, Any] | None,
    ) -> dict[str, Any]:
        return {
            "schema_version": "prompt_profile_manifest.v1",
            "color_profile": cls._color_profile_from_selection(
                selected_skills=selected_skills,
                skill_context=skill_context,
            ),
            "topic_profile": cls._topic_profile_from_selection(
                selected_skills=selected_skills,
                skill_context=skill_context,
            ),
        }

    @classmethod
    def _color_profile_from_selection(
        cls,
        *,
        selected_skills: list[str],
        skill_context: dict[str, Any] | None,
    ) -> dict[str, Any]:
        selected = list(selected_skills or [])
        context_profile = (
            (skill_context or {}).get("color_profile")
            if isinstance(skill_context, dict)
            else None
        )
        if (
            isinstance(context_profile, dict)
            and context_profile.get("source") == "enterprise_background_theme"
        ):
            return {
                "schema_version": "color_profile.v1",
                "source": "skill_context",
                **dict(context_profile),
            }
        scheme_skill_ids = [
            skill_id for skill_id in selected if skill_id in COLOR_SCHEME_PROFILES
        ]
        contrast_skill_ids = [
            skill_id for skill_id in selected if skill_id in COLOR_CONTRAST_PROFILES
        ]
        if len(scheme_skill_ids) > 1:
            raise ValueError(
                "color_profile_prompt_contamination: multiple color.scheme.* "
                f"profiles selected: {scheme_skill_ids}"
            )
        if len(contrast_skill_ids) > 1:
            raise ValueError(
                "color_profile_prompt_contamination: multiple color.contrast.* "
                f"profiles selected: {contrast_skill_ids}"
            )
        if bool(scheme_skill_ids) != bool(contrast_skill_ids):
            raise ValueError(
                "color_profile_prompt_contamination: color scheme and contrast "
                f"profiles must be paired, got schemes={scheme_skill_ids}, "
                f"contrasts={contrast_skill_ids}"
            )

        if isinstance(context_profile, dict):
            scheme_skill_id = str(context_profile.get("scheme_skill_id") or "")
            contrast_skill_id = str(context_profile.get("contrast_skill_id") or "")
            three_d_skill_id = str(context_profile.get("three_d_skill_id") or "")
            for profile_skill_id in (scheme_skill_id, contrast_skill_id, three_d_skill_id):
                if profile_skill_id and profile_skill_id not in selected:
                    raise ValueError(
                        "color_profile_prompt_contamination: skill_context color "
                        f"profile references {profile_skill_id}, but selected_skills "
                        "does not include it"
                    )
            return {
                "schema_version": "color_profile.v1",
                "source": "skill_context",
                **dict(context_profile),
            }

        if not scheme_skill_ids and not contrast_skill_ids:
            return {
                "schema_version": "color_profile.v1",
                "source": "selected_skills",
                "status": "not_selected",
                "color_scheme": 0,
                "scheme_skill_id": "",
                "contrast_skill_id": "",
                "three_d_skill_id": COLOR_3D_SKILL_ID
                if COLOR_3D_SKILL_ID in selected
                else "",
            }

        scheme_skill_id = scheme_skill_ids[0]
        contrast_skill_id = contrast_skill_ids[0]
        scheme_profile = COLOR_SCHEME_PROFILES[scheme_skill_id]
        expected_contrast = scheme_profile["contrast_profile"]
        actual_contrast = COLOR_CONTRAST_PROFILES[contrast_skill_id]
        if actual_contrast != expected_contrast:
            raise ValueError(
                "color_profile_prompt_contamination: color scheme profile "
                f"{scheme_skill_id} expects {expected_contrast}, got {contrast_skill_id}"
            )
        return {
            "schema_version": "color_profile.v1",
            "source": "selected_skills",
            "color_scheme": scheme_profile["color_scheme"],
            "scheme_name": scheme_profile["scheme_name"],
            "contrast_profile": expected_contrast,
            "scheme_skill_id": scheme_skill_id,
            "contrast_skill_id": contrast_skill_id,
            "three_d_skill_id": COLOR_3D_SKILL_ID
            if COLOR_3D_SKILL_ID in selected
            else "",
        }

    @staticmethod
    def _topic_profile_from_selection(
        *,
        selected_skills: list[str],
        skill_context: dict[str, Any] | None,
    ) -> dict[str, Any]:
        selected = list(selected_skills or [])
        context_profile = (
            (skill_context or {}).get("topic_profile")
            if isinstance(skill_context, dict)
            else None
        )
        if isinstance(context_profile, dict):
            selected_topic_skill = str(context_profile.get("selected_skill_id") or "")
            if selected_topic_skill and selected_topic_skill not in selected:
                raise ValueError(
                    "topic_profile_prompt_contamination: skill_context topic profile "
                    f"references {selected_topic_skill}, but selected_skills does not include it"
                )
            return {
                "schema_version": "topic_profile.v1",
                "source": "skill_context",
                **dict(context_profile),
            }

        matched_profile_ids = [
            profile_id
            for skill_id, profile_id in TOPIC_PROFILE_SKILL_IDS.items()
            if skill_id in selected
        ]
        if len(set(matched_profile_ids)) > 1:
            raise ValueError(
                "topic_profile_prompt_contamination: multiple topic profiles selected: "
                f"{matched_profile_ids}"
            )
        if matched_profile_ids:
            profile_id = matched_profile_ids[0]
            selected_skill_id = next(
                skill_id
                for skill_id, candidate in TOPIC_PROFILE_SKILL_IDS.items()
                if candidate == profile_id and skill_id in selected
            )
            return {
                "schema_version": "topic_profile.v1",
                "source": "selected_skills",
                "id": profile_id,
                "selected_skill_id": selected_skill_id,
            }
        return {
            "schema_version": "topic_profile.v1",
            "source": "selected_skills",
            "id": "general",
            "selected_skill_id": "",
        }
