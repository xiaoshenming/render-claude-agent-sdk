from .prompt_compiler_constants_a import *
LAYOUT_SPEC_TEXT_FIELDS = (
    "mode",
    "main_area",
    "text_area",
    "diagram_area",
    "proof_area",
    "formula_area",
    "anchor",
    "durable_until",
)
LAYOUT_SPEC_INT_FIELDS = ("max_visible_texts", "max_visible_formulas")
LAYOUT_SPEC_LIST_FIELDS = (
    "must_pass_others",
    "persistent_objects",
    "replace_on_next_step",
    "avoid",
    "reveal_order",
    "replace_before_next",
)
LAYOUT_SPEC_STRUCTURED_FIELDS = (
    "reserved_bbox",
    "text_clearance",
    "diagram_text_relation",
)
LAYOUT_SPEC_TOP_LEVEL_FIELDS = (
    *LAYOUT_SPEC_TEXT_FIELDS,
    *LAYOUT_SPEC_INT_FIELDS,
    *LAYOUT_SPEC_LIST_FIELDS,
    *LAYOUT_SPEC_STRUCTURED_FIELDS,
)
PLANNED_SCENE_TEXT_FIELDS = (
    "name",
    "title",
    "purpose",
    "visual_description",
    "math_content",
    "voiceover",
    "entry_context",
    "rehydration_from",
    "primary_object_id",
    "motion_bridge",
)
PLANNED_SCENE_STRUCTURED_FIELDS = (
    "key_objects",
    "silent_context_objects",
    "new_reveals",
    "spoken_reveal_objects",
    "entry_state",
    "exit_state",
    "notes",
    "scene_layout_contract",
    "tts_sync_contract",
)
MICRO_BEAT_SCRIPT_FIELDS = ("visual_script", "tts_timeline")
MICRO_BEAT_SENSITIVE_KEYS = {
    "api_key",
    "authorization",
    "cosyvoice_id",
    "model",
    "provider",
    "secret",
    "token",
    "tts_voice",
    "voice_id",
    "voice_type",
}
VOICE_SCRIPT_BLOCK_TEXT_FIELDS = (
    "spoken_text",
    "visual_action",
    "single_action",
    "single_action_name",
    "visual_focus",
    "persistent_object",
    "new_object",
    "spoken_reveal_object",
    "tts_role",
    "mark",
    "caption",
    "teaching_claim",
    "proof_row_text",
    "diagram_support",
)
VOICE_SCRIPT_BLOCK_LIST_FIELDS = (
    "silent_context_objects",
    "new_reveals",
    "spoken_reveal_objects",
    "reveal_targets",
    "emphasis_targets",
    "targets",
    "keep_visible",
    "replace_targets",
)
SYNC_UNIT_TEXT_FIELDS = (
    "narration",
    "visual_action",
    "single_action",
    "single_action_name",
    "visual_focus",
    "spoken_reveal_object",
    "mark",
    "caption",
    "spoken_math",
    "teaching_claim",
    "proof_row_text",
    "diagram_support",
)
SYNC_UNIT_LIST_FIELDS = (
    "silent_context_objects",
    "new_reveals",
    "spoken_reveal_objects",
    "reveal_targets",
    "emphasis_targets",
    "targets",
    "keep_visible",
    "replace_targets",
)
TTS_SYNC_CONTRACT_ALLOWED_FIELDS = (
    "mode",
    "required",
    "voiceover_block_policy",
    "sync_unit_semantics",
    "target_chars_per_block",
    "runtime",
    "voiceover_blocks",
)
TTS_SYNC_CONTRACT_UNSAFE_PATTERNS = (
    "2-4 visual actions",
    "2 to 4 visual actions",
    "2~4 visual actions",
    "2-4 个",
    "2 到 4 个",
    "多个视觉动作",
    "多动作",
)

REPAIR_CACHE_STABLE_PRIMER = """
## Render Skill OS Repair Stable Playbook
This block is intentionally stable across repair calls. It exists for two reasons:
1. keep repair quality consistent;
2. keep the provider-cacheable prefix long and identical while all job-specific code,
   traceback, scene name, feedback, and user content stay in the dynamic payload.

Repair contract:
- Treat the existing Manim code as the source of truth. The goal is not to answer the
  original lesson prompt again; the goal is to make the current artifact render.
- Prefer the smallest patch that fixes the observed failure. A local variable rename,
  bounds check, label shift, missing import usage replacement, or one-line animation
  correction is better than a scene rewrite.
- Preserve class names, scene order, timing intent, visual hierarchy, colors, labels,
  narration hooks, and existing helper APIs unless the failure directly proves one of
  them is invalid.
- Never invent new global helpers, assets, fonts, files, external services, or runtime
  dependencies. Use only Manim primitives and helpers already present in the provided
  context.
- Keep repairs deterministic. Avoid randomness, wall-clock time, network access, file
  discovery outside the given code, and hidden mutable global state.
- Respect the output contract for the requested repair mode. Patch mode must output
  only search/replace patch blocks. Full scene mode must output only the requested
  class or the requested BaseConfigScene plus class, with no markdown commentary.
- Do not broaden scope because the surrounding code looks imperfect. If unrelated code
  is suspicious but not part of the failing path, leave it unchanged.
- Do not remove mathematically important labels, equations, arrows, axes, geometry
  objects, or voiceover synchronization merely to make rendering easier.
- If a repair needs a new mobject, define it in the same local scope before first use,
  and add it to the scene only when it is meant to be visible.
- If a repair changes an animation call, preserve the pedagogical sequence: introduce,
  transform, highlight, conclude.

Patch quality rules:
- SEARCH must be copied exactly from the supplied code window.
- SEARCH must include enough surrounding context to match once and only once in the
  full file. A single common line is unsafe.
- REPLACE must be syntactically complete for the same indentation level.
- Keep patch blocks independent. Do not rely on applying one patch to make the SEARCH
  of another patch appear unless the dynamic payload explicitly asks for that.
- If the same line appears multiple times, include the enclosing loop, condition,
  method call, or nearby unique label in SEARCH.
- If the requested replacement would require changing code outside the supplied
  window, output a minimal patch for the visible root cause and let validation decide
  whether broader handling is needed.

Common Manim repair patterns:
- Scene.play receives Animation objects, not raw Mobject values. Wrap creation,
  writing, fading, transforming, or indicating calls with valid Animation classes.
- Do not call methods or attributes that are version-specific unless they already
  appear in the codebase context. Prefer conservative Manim 0.19-compatible APIs.
- For text, formulas, and labels, prefer next_to, align_to, move_to, shift, scale,
  arrange, and VGroup-based positioning over hard-coded coordinates when overlap is
  the observed failure.
- Formula rendering must remain parseable. Do not put formula-like strings containing
  TeX commands, ^, _, =, +, fractions, or roots inside Text/safe_text_box. Use MathTex
  for formulas, and split mixed CJK prose plus formulas into VGroup(Text(...), MathTex(...)).
- When indexing VGroups, tables, lists, or generated rows, guard against length
  mismatch. Prefer min/max clamping, enumerate, zip, or direct construction from
  known objects in the supplied code.
- If a MathTex or Tex expression is invalid, simplify only the failing expression and
  preserve the mathematical meaning.
- If a camera-frame or aspect-ratio issue appears, move content inside the safe area
  rather than deleting content.
- If voiceover timing is involved, keep waits and animations aligned with spoken
  content. Do not remove voiceover blocks unless they are the direct source of the
  exception.
- If an object is referenced after being replaced, transformed, or scoped inside a
  loop, keep a stable variable reference before reuse.
- If a label overlaps geometry, move the label, add a small buffer, or use a compact
  scale; do not remove the geometry proof element.
- If the failure is caused by an undefined name, either replace it with the intended
  existing variable from the local context or define it immediately before use.

Quality preservation rules:
- For geometry scenes, preserve correspondence: point labels, side labels, parallel
  marks, angle marks, ratio labels, and transform arrows must continue to express the
  proof relationship.
- For formula scenes, preserve readability: avoid tiny formula text, excessive
  simultaneous equations, or labels placed over axes.
- For layout fixes, keep objects in the visible frame and avoid covering title,
  subtitle, formula, or critical proof annotations.
- For short local fixes, do not change color themes, title text, or explanatory
  wording unless the dynamic payload says the issue is text-specific.
- A successful repair should reduce the current error without raising repair loops,
  code drift, or a new unrelated visual regression.

Return discipline:
- Output the requested artifact only.
- No explanation, no bullet list, no markdown fence unless the requested mode requires
  plain class code and the surrounding extractor accepts fenced code.
- If a valid minimal repair cannot be produced from the supplied window, prefer a
  conservative no-op-sized patch over a speculative rewrite.
""".strip()


