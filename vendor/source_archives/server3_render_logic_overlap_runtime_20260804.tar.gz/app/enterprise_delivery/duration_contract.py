from __future__ import annotations

import math
from typing import Any


ENTERPRISE_ROUTE = "enterprise_fastpre_v1"
REPORT_SCHEMA_VERSION = "enterprise_planning_duration_normalization.v1"


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on", "enabled"}
    return bool(value)


def _positive_int(value: Any) -> int | None:
    try:
        number = int(float(value))
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _scene_durations(scenes: list[Any]) -> list[int]:
    durations: list[int] = []
    for scene in scenes:
        if not isinstance(scene, dict):
            durations.append(0)
            continue
        durations.append(_positive_int(scene.get("duration_sec")) or 0)
    return durations


def _allocate_fixed_total(durations: list[int], target_duration: int) -> list[int]:
    count = len(durations)
    if count <= 0:
        return []
    weights = [max(1, duration) for duration in durations]
    weight_total = sum(weights) or count
    raw_units = [target_duration * weight / weight_total for weight in weights]
    floors = [math.floor(unit) for unit in raw_units]
    allocated = list(floors)
    delta = target_duration - sum(allocated)
    if delta > 0:
        order = sorted(
            range(count),
            key=lambda index: raw_units[index] - floors[index],
            reverse=True,
        )
        for index in order[:delta]:
            allocated[index] += 1
    elif delta < 0:
        order = sorted(range(count), key=lambda index: allocated[index], reverse=True)
        for index in order[: abs(delta)]:
            if allocated[index] > 1:
                allocated[index] -= 1
    if sum(allocated) != target_duration:
        allocated[-1] += target_duration - sum(allocated)
    return allocated


def _is_enterprise_payload(task_data: dict[str, Any]) -> bool:
    return (
        _truthy(task_data.get("_enterprise_delivery_enabled"))
        and str(task_data.get("_enterprise_route") or "").strip() == ENTERPRISE_ROUTE
    )


def _resolve_target_duration(
    task_data: dict[str, Any],
    explicit_target_duration: Any = None,
) -> int | None:
    for candidate in (
        explicit_target_duration,
        task_data.get("_enterprise_fixed_duration_sec"),
        task_data.get("_auto_planning_target_duration"),
        task_data.get("duration_hint"),
    ):
        target = _positive_int(candidate)
        if target:
            return target
    return None


def apply_enterprise_fixed_duration_to_planning(
    task_data: dict[str, Any],
    *,
    planning_json: dict[str, Any] | None = None,
    target_duration: int | None = None,
) -> dict[str, Any]:
    """Normalize enterprise planning duration before generate_stream.

    This is an input-contract adapter, not a render gate: it only rewrites the
    enterprise planning payload so the first code generation sees one duration
    source of truth.
    """

    report: dict[str, Any] = {
        "schema_version": REPORT_SCHEMA_VERSION,
        "policy": "pre_generate_input_contract",
        "normalized": False,
    }
    if not isinstance(task_data, dict) or not _is_enterprise_payload(task_data):
        report["reason"] = "not_enterprise_route"
        return report

    target = _resolve_target_duration(task_data, target_duration)
    if not target:
        report["reason"] = "target_duration_missing"
        return report

    plan = planning_json if isinstance(planning_json, dict) else task_data.get("planning_json")
    if not isinstance(plan, dict):
        report.update(
            {
                "reason": "planning_json_missing",
                "target_duration_sec": target,
            }
        )
        return report

    scenes = plan.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        report.update(
            {
                "reason": "planning_scenes_missing",
                "target_duration_sec": target,
            }
        )
        return report

    before_durations = _scene_durations(scenes)
    before_total = sum(before_durations)
    after_durations = _allocate_fixed_total(before_durations, target)
    for scene, duration in zip(scenes, after_durations):
        if isinstance(scene, dict):
            scene["duration_sec"] = int(duration)

    plan["target_duration_sec"] = int(target)
    plan["total_duration_sec"] = int(sum(after_durations))
    plan["_enterprise_fixed_duration_sec"] = int(target)

    normalized = before_total != target or plan.get("target_duration_sec") != target
    report.update(
        {
            "reason": (
                "rescaled_to_enterprise_fixed_duration"
                if normalized
                else "already_fixed"
            ),
            "normalized": bool(normalized),
            "target_duration_sec": int(target),
            "before_total_duration_sec": int(before_total),
            "after_total_duration_sec": int(sum(after_durations)),
            "scene_count": len(after_durations),
            "before_scene_durations": before_durations,
            "after_scene_durations": after_durations,
        }
    )
    task_data["planning_json"] = plan
    task_data["_enterprise_planning_duration_normalized"] = report
    return report


def recompile_enterprise_scene_contracts_after_duration_normalization(
    task_data: dict[str, Any],
    *,
    aspect_ratio: str,
    enable_tts: bool,
    topic: str | None = None,
    target_duration: int | None = None,
) -> dict[str, Any]:
    report = dict(task_data.get("_enterprise_planning_duration_normalized") or {})
    if not report:
        report = apply_enterprise_fixed_duration_to_planning(
            task_data,
            target_duration=target_duration,
        )
    plan = task_data.get("planning_json")
    target = _resolve_target_duration(task_data, target_duration)
    if not isinstance(plan, dict) or not target:
        report["scene_contract_recompiled"] = False
        task_data["_enterprise_planning_duration_normalized"] = report
        return report

    try:
        from app.agents.scene_contracts import compile_or_raise

        task_data["scene_contracts"] = [
            contract.to_dict()
            for contract in compile_or_raise(
                plan,
                aspect_ratio=aspect_ratio,
                enable_tts=enable_tts,
                topic=topic or str(task_data.get("prompt") or ""),
                target_duration=target,
            )
        ]
        report["scene_contract_recompiled"] = True
        report["scene_contract_count"] = len(task_data["scene_contracts"])
    except Exception as exc:
        report["scene_contract_recompiled"] = False
        report["scene_contract_error"] = f"{type(exc).__name__}: {exc}"[:500]
    task_data["_enterprise_planning_duration_normalized"] = report
    return report
