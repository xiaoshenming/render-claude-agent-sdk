from __future__ import annotations

from typing import Any
from .prompt_compiler_v0211 import (PLACEHOLDER_RE, ROLE_MARKER_RE, LEGACY_PLACEHOLDERS, STABLE_REFERENCE_PLACEHOLDERS)
class PromptFirewall:
    """Static prompt linter for placeholder and composition mistakes."""

    HIGH_RISK_ISSUE_EXACT = {
        "dynamic_payload_in_stable_prefix",
        "composition_violation:dynamic_payload_not_object",
    }
    HIGH_RISK_ISSUE_PREFIXES = (
        "role_violation:",
        "skill_role_violation:",
        "unknown_skill:",
        "missing_dependency:",
        "conflict:",
        "trust_level_not_allowed:",
        "scope_not_allowed:",
        "composition_violation:",
    )

    def __init__(self, *, allowed_placeholders: set[str] | None = None) -> None:
        self.allowed_placeholders = allowed_placeholders or set(LEGACY_PLACEHOLDERS)

    def lint_template_and_output(
        self,
        *,
        template: str,
        output: str,
        stable_prefix: str,
        dynamic_values: list[str] | None = None,
        messages: list[dict[str, Any]] | None = None,
        selected_skills: list[str] | None = None,
        prompt_segments: dict[str, Any] | None = None,
        expected_skill_role: str = "generate",
        allowed_message_roles: set[str] | None = None,
    ) -> dict[str, Any]:
        issues: list[str] = []
        template_placeholders = set(PLACEHOLDER_RE.findall(template or ""))
        output_placeholders = set(PLACEHOLDER_RE.findall(output or ""))
        allowed_roles = allowed_message_roles or {"user"}

        for placeholder in sorted(template_placeholders - self.allowed_placeholders):
            issues.append(f"unknown_placeholder:{placeholder}")
        for placeholder in sorted(output_placeholders):
            if placeholder in STABLE_REFERENCE_PLACEHOLDERS:
                continue
            issues.append(f"unreplaced_placeholder:{placeholder}")

        for value in dynamic_values or []:
            if value and value in stable_prefix:
                issues.append("dynamic_payload_in_stable_prefix")
                break
        for value in dynamic_values or []:
            for placeholder in sorted(set(PLACEHOLDER_RE.findall(value or ""))):
                issues.append(f"dynamic_payload_contains_placeholder:{placeholder}")
            for marker in sorted(set(ROLE_MARKER_RE.findall(value or ""))):
                issues.append(f"dynamic_payload_role_marker:{marker}")

        message_roles = []
        for message in messages or []:
            role = str(message.get("role") or "")
            message_roles.append(role)
            if role not in allowed_roles:
                issues.append(f"role_violation:{role or 'missing'}")
        if messages and "user" not in message_roles:
            issues.append("role_missing:user")

        skill_policy = self._lint_skill_chain(
            selected_skills=selected_skills or [],
            expected_skill_role=expected_skill_role,
        )
        issues.extend(skill_policy["issues"])
        composition = self._lint_composition(
            prompt_segments=prompt_segments or {},
            selected_skills=selected_skills or [],
            expected_stable_prefix=stable_prefix,
        )
        issues.extend(composition["issues"])

        blocking_issues = self._blocking_issues(issues)
        risk_tier = "high" if blocking_issues else "medium" if issues else "none"

        return {
            "ok": not issues,
            "issues": issues,
            "fallback": "legacy_template" if issues else None,
            "mode": "warn_only",
            "risk_tier": risk_tier,
            "blocking_issues": blocking_issues,
            "enforcement": {
                "mode": "warn_only",
                "default_action": (
                    "collect_evidence_when_enabled" if blocking_issues else "allow"
                ),
                "blocking_issue_count": len(blocking_issues),
            },
            "template_placeholders": sorted(template_placeholders),
            "output_placeholders": sorted(output_placeholders),
            "message_roles": message_roles,
            "skill_policy": skill_policy,
            "composition": composition,
        }

    @classmethod
    def _blocking_issues(cls, issues: list[str]) -> list[str]:
        blocking: list[str] = []
        for issue in issues:
            if issue in cls.HIGH_RISK_ISSUE_EXACT or issue.startswith(
                cls.HIGH_RISK_ISSUE_PREFIXES
            ):
                blocking.append(issue)
        return blocking

    @staticmethod
    def _lint_skill_chain(
        *,
        selected_skills: list[str],
        expected_skill_role: str,
    ) -> dict[str, Any]:
        if not selected_skills:
            return {"issues": [], "mode": "warn_only", "selected_skills": []}
        from app.agents.skills.policy import SkillPolicy
        from app.agents.skills.registry import get_runtime_skill

        skill_objects = []
        issues: list[str] = []
        for skill_id in selected_skills:
            try:
                skill = get_runtime_skill(skill_id)
            except KeyError:
                issues.append(f"unknown_skill:{skill_id}")
                continue
            skill_objects.append(skill)
            if skill.role_target != expected_skill_role:
                issues.append(
                    f"skill_role_violation:{skill.id}:{skill.role_target}:"
                    f"{expected_skill_role}"
                )
        policy = SkillPolicy().validate_chain(
            skill_objects,
            expected_role_target=expected_skill_role,
            allowed_trust_levels={"audited"},
        )
        issues.extend(policy["issues"])
        return {
            "issues": issues,
            "mode": "warn_only",
            "selected_skills": selected_skills,
        }

    @staticmethod
    def _lint_composition(
        *,
        prompt_segments: dict[str, Any],
        selected_skills: list[str],
        expected_stable_prefix: str,
    ) -> dict[str, Any]:
        issues: list[str] = []
        if not prompt_segments:
            return {"issues": issues, "mode": "warn_only"}

        if prompt_segments.get("stable_prefix") != expected_stable_prefix:
            issues.append("composition_violation:stable_prefix_mismatch")

        skill_prefix = str(prompt_segments.get("skill_prefix") or "")
        expected_skill_prefix = "\n".join(
            f"skill://{skill}@active" for skill in selected_skills
        )
        if skill_prefix != expected_skill_prefix:
            issues.append("composition_violation:skill_prefix_mismatch")

        dynamic_payload = prompt_segments.get("dynamic_payload")
        if dynamic_payload is not None and not isinstance(dynamic_payload, dict):
            issues.append("composition_violation:dynamic_payload_not_object")

        return {"issues": issues, "mode": "warn_only"}


class PromptCompiler:
    """Compile legacy prompts without changing the rendered prompt content."""
