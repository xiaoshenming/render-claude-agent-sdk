from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any


ScoreResult = dict[str, Any]


def score_case(
    case: Mapping[str, Any],
    original_review: Mapping[str, Any] | None = None,
    repaired_review: Mapping[str, Any] | None = None,
) -> ScoreResult:
    """Score one quality-lab repair attempt without side effects."""

    before_metrics = _extract_metrics(original_review)
    after_metrics = _extract_metrics(repaired_review)
    target_issues = _extract_case_hard_issues(case) or _extract_review_hard_issues(original_review)
    after_issues = _extract_review_hard_issues(repaired_review)

    reasons: list[str] = []
    improved_metrics: list[str] = []
    worsened_metrics: list[str] = []

    review_error = _has_review_error(repaired_review)
    if review_error:
        reasons.append("review_error")

    for name in sorted(before_metrics.keys() & after_metrics.keys()):
        before_value = before_metrics[name]
        after_value = after_metrics[name]
        if after_value < before_value:
            improved_metrics.append(name)
        elif after_value > before_value:
            worsened_metrics.append(name)
            reasons.append(f"metric_worse:{name}")

    remaining_issues = sorted(issue for issue in target_issues if issue in after_issues)
    hard_issue_remaining = bool(remaining_issues)
    reasons.extend(f"hard_issue_remaining:{issue}" for issue in remaining_issues)

    new_hard_issues = sorted(after_issues - _extract_review_hard_issues(original_review) - target_issues)
    reasons.extend(f"new_hard_issue:{issue}" for issue in new_hard_issues)

    metrics_unchanged = bool(before_metrics or after_metrics) and before_metrics == after_metrics
    issues_unchanged = target_issues == after_issues
    unchanged = not review_error and not worsened_metrics and not improved_metrics and metrics_unchanged and issues_unchanged
    if unchanged:
        reasons.append("unchanged")

    degraded = bool(worsened_metrics or new_hard_issues)
    if review_error or unchanged or hard_issue_remaining:
        outcome = "degraded" if degraded else "failed"
    elif degraded:
        outcome = "degraded"
    else:
        outcome = "clean"

    clean = outcome == "clean"
    return {
        "case_id": case.get("case_id") or case.get("id"),
        "outcome": outcome,
        "clean": clean,
        "false_repaired": not clean,
        "review_error": review_error,
        "degraded": degraded,
        "hard_issue_remaining": hard_issue_remaining,
        "before": {"metrics": before_metrics, "hard_issues": sorted(_extract_review_hard_issues(original_review))},
        "after": {"metrics": after_metrics, "hard_issues": sorted(after_issues)},
        "metrics": {
            "improved": improved_metrics,
            "worsened": worsened_metrics,
        },
        "reasons": reasons,
    }


def summarize_scores(results: Iterable[Mapping[str, Any]]) -> dict[str, int]:
    result_list = list(results)
    return {
        "case_count": len(result_list),
        "clean_count": sum(1 for result in result_list if result.get("outcome") == "clean" or result.get("clean") is True),
        "degraded_count": sum(1 for result in result_list if result.get("outcome") == "degraded" or result.get("degraded") is True),
        "failed_count": sum(1 for result in result_list if result.get("outcome") == "failed"),
        "false_repaired_count": sum(1 for result in result_list if result.get("false_repaired") is True),
        "review_error_count": sum(1 for result in result_list if result.get("review_error") is True),
    }


def _extract_metrics(review: Mapping[str, Any] | None) -> dict[str, float]:
    if not isinstance(review, Mapping):
        return {}
    raw_metrics = review.get("metrics") or review.get("quality_metrics") or {}
    if not isinstance(raw_metrics, Mapping):
        return {}
    metrics: dict[str, float] = {}
    for name, value in raw_metrics.items():
        if isinstance(value, bool) or not isinstance(value, int | float):
            continue
        metrics[str(name)] = float(value)
    return metrics


def _extract_case_hard_issues(case: Mapping[str, Any]) -> set[str]:
    return _normalize_issue_set(case.get("hard_issues") or case.get("target_hard_issues") or case.get("issues"))


def _extract_review_hard_issues(review: Mapping[str, Any] | None) -> set[str]:
    if not isinstance(review, Mapping):
        return set()
    raw_issues = review.get("hard_issues") or review.get("issues") or []
    return _normalize_issue_set(raw_issues)


def _normalize_issue_set(raw_issues: Any) -> set[str]:
    if isinstance(raw_issues, str):
        return {raw_issues}
    if not isinstance(raw_issues, Iterable):
        return set()

    issues: set[str] = set()
    for issue in raw_issues:
        if isinstance(issue, str):
            issues.add(issue)
            continue
        if not isinstance(issue, Mapping):
            continue
        severity = issue.get("severity") or issue.get("level")
        if severity and str(severity).lower() not in {"hard", "critical", "error"}:
            continue
        name = issue.get("type") or issue.get("code") or issue.get("name") or issue.get("issue")
        if name:
            issues.add(str(name))
    return issues


def _has_review_error(review: Mapping[str, Any] | None) -> bool:
    if not isinstance(review, Mapping):
        return True
    if review.get("review_error") or review.get("error"):
        return True
    status = review.get("status")
    return isinstance(status, str) and status.lower() in {"error", "review_error"}
