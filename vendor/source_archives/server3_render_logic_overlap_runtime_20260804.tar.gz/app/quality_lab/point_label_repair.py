from __future__ import annotations

import ast
import re
from dataclasses import dataclass


_DIRECTION_RE = r"UP|DOWN|LEFT|RIGHT|UL|UR|DL|DR"
_NEXT_TO_RE = re.compile(
    rf"(?P<prefix>\.next_to\s*\(\s*[^,\n]+,\s*)(?P<direction>{_DIRECTION_RE})(?P<suffix>[^)\n]*)(?P<close>\))"
)
_BUFF_RE = re.compile(r"buff\s*=\s*(?P<value>[0-9]+(?:\.[0-9]+)?)")
_MOVE_TO_VECTOR_RE = re.compile(
    rf"(?P<prefix>\.move_to\s*\([^#\n]*\+\s*)(?P<direction>{_DIRECTION_RE})(?P<scale>\s*\*\s*)(?P<value>[0-9]+(?:\.[0-9]+)?)"
)


@dataclass(frozen=True)
class PointLabelRepairResult:
    code: str
    changed: bool
    strategy: str
    target_variable: str | None


def repair_point_label_overlap(
    code: str,
    target_variable: str | None,
    problem_summary: str | None = None,
) -> PointLabelRepairResult:
    if not target_variable:
        return PointLabelRepairResult(code=code, changed=False, strategy="missing_target", target_variable=target_variable)

    direction, minimum_distance, strategy = _choose_outer_direction(problem_summary)
    lines = code.splitlines(keepends=True)
    changed = False
    repaired_lines: list[str] = []

    for line in lines:
        if target_variable not in line or not _looks_like_point_label_line(line, target_variable):
            repaired_lines.append(line)
            continue

        repaired_line = _repair_next_to_line(line, direction, minimum_distance)
        if repaired_line == line:
            repaired_line = _repair_move_to_line(line, direction, minimum_distance)

        if repaired_line != line:
            changed = True
        repaired_lines.append(repaired_line)

    if not changed:
        return PointLabelRepairResult(code=code, changed=False, strategy="no_matching_point_label_patch", target_variable=target_variable)

    candidate = "".join(repaired_lines)
    if not _is_parseable(candidate):
        return PointLabelRepairResult(code=code, changed=False, strategy="parse_guard_rejected_patch", target_variable=target_variable)

    return PointLabelRepairResult(code=candidate, changed=True, strategy=strategy, target_variable=target_variable)


def _looks_like_point_label_line(line: str, target_variable: str) -> bool:
    stripped = line.strip()
    if ".next_to(" in stripped:
        return (
            stripped.startswith(f"{target_variable}.")
            or stripped.startswith(f"{target_variable} =")
            or stripped.startswith(f"{target_variable}=")
        )
    if ".move_to(" in stripped:
        return stripped.startswith(f"{target_variable}.")
    return False


def _repair_next_to_line(line: str, direction: str, minimum_buff: float) -> str:
    def replace(match: re.Match[str]) -> str:
        suffix = _repair_buff(match.group("suffix"), minimum_buff)
        return f"{match.group('prefix')}{direction}{suffix}{match.group('close')}"

    return _NEXT_TO_RE.sub(replace, line, count=1)


def _repair_move_to_line(line: str, direction: str, minimum_distance: float) -> str:
    def replace(match: re.Match[str]) -> str:
        current = float(match.group("value"))
        distance = max(current, minimum_distance)
        return f"{match.group('prefix')}{direction}{match.group('scale')}{_format_float(distance)}"

    return _MOVE_TO_VECTOR_RE.sub(replace, line, count=1)


def _repair_buff(suffix: str, minimum_buff: float) -> str:
    match = _BUFF_RE.search(suffix)
    if match is None:
        return f"{suffix}, buff={_format_float(minimum_buff)}"

    current = float(match.group("value"))
    if current >= minimum_buff:
        return suffix
    return _BUFF_RE.sub(f"buff={_format_float(minimum_buff)}", suffix, count=1)


def _choose_outer_direction(problem_summary: str | None) -> tuple[str, float, str]:
    summary = (problem_summary or "").lower()
    if "polygon" in summary:
        return "UR", 0.65, "polygon_outer_diagonal_label_push"
    if "x-axis" in summary or "x axis" in summary or "axis" in summary or "arrow" in summary or "line" in summary:
        return "UP", 0.60, "axis_line_arrow_outer_label_push"
    return "UR", 0.55, "generic_outer_label_push"


def _format_float(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".")


def _is_parseable(code: str) -> bool:
    try:
        ast.parse(code)
    except SyntaxError:
        return False
    return True
