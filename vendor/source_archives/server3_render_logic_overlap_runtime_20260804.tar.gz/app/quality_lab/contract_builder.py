"""Build contract-only repair inputs for the B-line video quality lab."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


LAYOUT_RESTRUCTURE_STRATEGY = "split_question_and_solution_or_stage_fadeout"


def build_repair_contract(
    case: Mapping[str, Any] | object,
    original_review: Mapping[str, Any] | object | None = None,
) -> dict[str, Any]:
    """Convert a quality-lab case into a second-modification style contract."""

    case_data = _as_mapping(case)
    review_data = _as_mapping(original_review)
    lane = _normalize_lane(_get(case_data, "lane"), _get(case_data, "failure_code"))

    base_contract: dict[str, Any] = {
        "schema_version": "render_repair_contract.v1",
        "case_id": _get(case_data, "case_id") or _get(case_data, "id"),
        "job_id": _get(case_data, "job_id"),
        "target_scene": _first_value(case_data, review_data, "scene_name", "target_scene")
        or "unknown_scene",
        "failure_code": _get(case_data, "failure_code") or _get(review_data, "failure_code"),
        "lane": lane,
        "target_object": _target_object(case_data, review_data, lane),
        "problem_summary": _problem_summary(case_data, review_data),
        "evidence": _evidence(case_data, review_data),
        "repair_scope": _repair_scope(case_data, review_data, lane),
        "repair_obligations": _repair_obligations(lane, case_data, review_data),
        "recommended_strategy": _recommended_strategy(lane, _get(case_data, "failure_code")),
        "forbidden_actions": _forbidden_actions(lane),
        "acceptance_criteria": _acceptance_criteria(lane, case_data),
    }

    target_region = _first_value(case_data, review_data, "target_region", "visual_target_region")
    if target_region:
        base_contract["target_region"] = target_region

    non_target_preservation = _get(case_data, "non_target_preservation") or _get(
        review_data, "non_target_preservation"
    )
    if non_target_preservation:
        base_contract["non_target_preservation"] = list(non_target_preservation)

    if lane == "pre_render_helper_runtime":
        base_contract["deterministic_first"] = True

    return base_contract


def score_repair_contract(
    case: Mapping[str, Any] | object,
    contract: Mapping[str, Any] | object,
) -> dict[str, Any]:
    """Score whether a contract is actionable enough for repair-only mode."""

    case_data = _as_mapping(case)
    contract_data = _as_mapping(contract)
    lane = _normalize_lane(_get(contract_data, "lane") or _get(case_data, "lane"), _get(case_data, "failure_code"))
    acceptance = _as_mapping(_get(contract_data, "acceptance_criteria"))
    reasons: list[str] = []

    has_target_scene = _has_value(_get(contract_data, "target_scene")) and _get(contract_data, "target_scene") != "unknown_scene"
    has_target_object = _has_value(_get(contract_data, "target_object"))
    has_target_region_or_bbox = any(
        _has_value(_get(contract_data, key))
        for key in ("target_region", "target_bbox", "visual_target_region", "bbox")
    )
    evidence = _as_mapping(_get(contract_data, "evidence"))
    has_target_region_or_bbox = has_target_region_or_bbox or any(
        _has_value(_get(evidence, key))
        for key in ("target_region", "target_bbox", "visual_target_region", "bbox", "objects")
    )
    has_before_metrics = _has_baseline_metric(case_data, "before")
    has_after_metrics = _has_baseline_metric(case_data, "after")
    has_non_target_preservation = _has_value(_get(contract_data, "non_target_preservation"))
    has_acceptance_script = _has_value(_get(contract_data, "acceptance_script")) or _has_value(
        _get(acceptance, "acceptance_script")
    )
    deterministic_first = _get(contract_data, "deterministic_first") is True or _get(
        acceptance, "deterministic_fix_attempted_first"
    ) is True

    if not has_target_scene:
        reasons.append("missing_target_scene")
    if not has_target_object:
        reasons.append("missing_target_object")
    if lane in {"post_review_layout", "layout", "modify_success_reference"} and not has_target_region_or_bbox:
        reasons.append("missing_target_region_or_bbox")
    if lane == "modify_success_reference" and not has_non_target_preservation:
        reasons.append("missing_non_target_preservation")
    if lane == "math_logic" and not (
        _get(acceptance, "math_meaning_preserved") is True
        and (
            _get(acceptance, "math_hard_issue_disappears") is True
            or _get(acceptance, "hard_issue_must_disappear") is True
        )
    ):
        reasons.append("missing_math_acceptance")
    if lane == "pre_render_helper_runtime" and not deterministic_first:
        reasons.append("missing_deterministic_first")

    hard_failures = {
        "missing_target_scene",
        "missing_target_object",
        "missing_non_target_preservation",
        "missing_math_acceptance",
        "missing_deterministic_first",
    }
    degraded_reasons = set(reasons) - hard_failures

    if any(reason in hard_failures for reason in reasons):
        quality = "failed"
    elif degraded_reasons:
        quality = "degraded"
    else:
        quality = "clean"

    return {
        "case_id": _get(case_data, "case_id") or _get(contract_data, "case_id"),
        "lane": lane,
        "contract_quality": quality,
        "clean": quality == "clean",
        "degraded": quality == "degraded",
        "failed": quality == "failed",
        "reasons": reasons,
        "checks": {
            "has_target_scene": has_target_scene,
            "has_target_object": has_target_object,
            "has_target_region_or_bbox": has_target_region_or_bbox,
            "has_before_metrics": has_before_metrics,
            "has_after_metrics": has_after_metrics,
            "has_non_target_preservation": has_non_target_preservation,
            "has_acceptance_script": has_acceptance_script,
            "deterministic_first": deterministic_first,
        },
    }


def _as_mapping(value: Mapping[str, Any] | object | None) -> Mapping[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return value
    if hasattr(value, "model_dump"):
        dumped = value.model_dump()
        if isinstance(dumped, Mapping):
            return dumped
    if hasattr(value, "__dict__"):
        return vars(value)
    return {}


def _get(source: Mapping[str, Any], key: str, default: Any = None) -> Any:
    return source.get(key, default)


def _has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def _has_baseline_metric(case_data: Mapping[str, Any], prefix: str) -> bool:
    baseline = _get(case_data, "baseline")
    if not isinstance(baseline, Mapping):
        return False
    prefix_text = f"{prefix}_"
    return any(key.startswith(prefix_text) and isinstance(value, int | float) for key, value in baseline.items())


def _first_value(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
    *keys: str,
) -> Any:
    for key in keys:
        value = _get(case_data, key)
        if value not in (None, "", []):
            return value
        value = _get(review_data, key)
        if value not in (None, "", []):
            return value
    return None


def _normalize_lane(lane: Any, failure_code: Any) -> str:
    lane_text = str(lane or "").strip()
    failure_text = str(failure_code or "").lower()

    if lane_text == "math_logic" or failure_text.startswith("math_logic"):
        return "math_logic"
    if "helper" in lane_text or "runtime" in lane_text or _is_helper_runtime_failure(failure_text):
        return "pre_render_helper_runtime"
    if lane_text == "modify_success_reference" or "modify" in lane_text:
        return "modify_success_reference"
    if "layout" in lane_text or "overlap" in failure_text or "layout" in failure_text:
        return lane_text or "post_review_layout"
    return lane_text or "post_review_layout"


def _is_helper_runtime_failure(failure_code: str) -> bool:
    return any(
        marker in failure_code
        for marker in (
            "helper",
            "runtime",
            "nameerror",
            "import",
            "missing_function",
            "undefined",
        )
    )


def _target_object(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
    lane: str,
) -> str:
    explicit = _first_value(case_data, review_data, "target_object", "object", "issue_target")
    if explicit:
        return str(explicit)
    if lane == "math_logic":
        return "数学推导与结论"
    if lane == "pre_render_helper_runtime":
        return "helper/runtime failure site"
    if lane == "modify_success_reference":
        return "客户确认的目标区域"
    return "layout conflict region"


def _problem_summary(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
) -> str:
    explicit = _first_value(case_data, review_data, "problem_summary", "summary", "message")
    if explicit:
        return str(explicit)
    failure_code = _get(case_data, "failure_code") or "quality_issue"
    return f"{failure_code} requires point-to-point repair contract."


def _evidence(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
) -> dict[str, Any]:
    """Collect structured evidence without inventing probe results."""

    evidence: dict[str, Any] = {}
    for key in (
        "target_region",
        "visual_target_region",
        "target_bbox",
        "bbox",
        "objects",
        "top_overlaps",
        "top_bounds_violations",
        "frame_refs",
        "probe_snapshot_refs",
    ):
        value = _first_value(case_data, review_data, key)
        if _has_value(value):
            evidence[key] = value

    baseline = _get(case_data, "baseline")
    if isinstance(baseline, Mapping) and baseline:
        evidence["baseline"] = dict(baseline)

    source_evidence = _get(case_data, "source_evidence")
    if isinstance(source_evidence, Mapping) and source_evidence:
        evidence["source_evidence"] = dict(source_evidence)

    failure_code = _get(case_data, "failure_code") or _get(review_data, "failure_code")
    if _has_value(failure_code):
        evidence["failure_code"] = failure_code

    problem_summary = _problem_summary(case_data, review_data)
    if problem_summary:
        evidence["problem_summary"] = problem_summary

    evidence.update(_structured_quality_evidence(case_data, review_data))

    return evidence


def _structured_quality_evidence(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
) -> dict[str, Any]:
    structured: dict[str, Any] = {}

    parse_check = _first_mapping(case_data, review_data, "parse_check", "parse")
    if parse_check:
        structured["parse"] = {
            "checked": True,
            "ok": _optional_bool(_first_present(parse_check, "parse_ok", "ok")),
            "errors": _list_value(_get(parse_check, "errors")),
        }

    render_check = _first_mapping(
        case_data,
        review_data,
        "docker_render_check",
        "render_check",
        "render",
    )
    if render_check:
        structured["render"] = {
            "checked": True,
            "ok": _optional_bool(_first_present(render_check, "render_ok", "ok")),
            "mp4": _get(render_check, "mp4"),
            "mp4_bytes": _get(render_check, "mp4_bytes"),
            "errors": _list_value(_get(render_check, "errors")),
        }

    frame_probe = _first_mapping(
        case_data,
        review_data,
        "frame_probe_check",
        "frame_probe",
    )
    if frame_probe:
        structured["frame"] = {
            "checked": True,
            "ok": _optional_bool(_first_present(frame_probe, "frame_probe_ok", "ok")),
            "frame_count": _get(frame_probe, "frame_count"),
            "frame_hashes": _list_value(_get(frame_probe, "frame_hashes")),
            "frames": _list_value(_get(frame_probe, "frames")),
            "edge_overflow_count": _get(frame_probe, "edge_overflow_count"),
            "errors": _list_value(_get(frame_probe, "errors")),
        }

    layout_probe = _first_mapping(
        case_data,
        review_data,
        "layout_probe_check",
        "layout_probe",
        "layout",
    )
    if layout_probe:
        structured["layout"] = {
            "checked": True,
            "ok": _optional_bool(_first_present(layout_probe, "layout_probe_ok", "ok")),
            "overlap_count": _get(layout_probe, "overlap_count"),
            "bounds_violation_count": _get(layout_probe, "bounds_violation_count"),
            "top_overlaps": _list_value(_get(layout_probe, "top_overlaps")),
            "top_bounds_violations": _list_value(_get(layout_probe, "top_bounds_violations")),
            "errors": _list_value(_get(layout_probe, "errors")),
        }

    multimodal_review = _first_mapping(
        case_data,
        review_data,
        "multimodal_review",
        "gpt_multimodal_review",
    )
    if multimodal_review:
        structured["multimodal"] = {
            "checked": True,
            "ok": _optional_bool(_first_present(multimodal_review, "review_ok", "ok")),
            "has_image_payload": _optional_bool(_get(multimodal_review, "has_image_payload")),
            "frame_count": _get(multimodal_review, "frame_count"),
            "frame_hashes": _list_value(_get(multimodal_review, "frame_hashes")),
            "frame_extract_error": _get(multimodal_review, "frame_extract_error"),
            "layout_overlap_ok": _optional_bool(_get(multimodal_review, "layout_overlap_ok")),
            "math_logic_ok": _optional_bool(_get(multimodal_review, "math_logic_ok")),
            "affected_objects": _list_value(
                _get(multimodal_review, "affected_objects")
                or _get(multimodal_review, "object_ids")
            ),
            "repair_hints": _list_value(
                _get(multimodal_review, "repair_hints")
                or _get(multimodal_review, "patch_hints")
            ),
            "errors": _list_value(_get(multimodal_review, "errors")),
        }

    return structured


def _first_mapping(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
    *keys: str,
) -> Mapping[str, Any]:
    for key in keys:
        value = _get(case_data, key)
        if isinstance(value, Mapping):
            return value
        value = _get(review_data, key)
        if isinstance(value, Mapping):
            return value
    return {}


def _first_present(source: Mapping[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in source:
            return _get(source, key)
    return None


def _optional_bool(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "yes", "1", "ok", "pass", "passed"}:
            return True
        if lowered in {"false", "no", "0", "fail", "failed"}:
            return False
    return bool(value)


def _list_value(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple | set):
        return list(value)
    return [value]


def _repair_obligations(
    lane: str,
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
) -> list[str]:
    explicit = _first_value(case_data, review_data, "repair_obligations", "obligations")
    if isinstance(explicit, list) and explicit:
        return [str(item) for item in explicit if str(item).strip()]

    target = _target_object(case_data, review_data, lane)
    if lane == "math_logic":
        return [
            f"Fix the math or geometry reasoning problem in {target}.",
            "Keep the original problem statement and final claim semantically consistent.",
            "After math repair, keep the scene eligible for layout and frame probe.",
        ]
    if lane == "pre_render_helper_runtime":
        return [
            f"Repair the deterministic helper/runtime failure at {target}.",
            "Prefer a known helper shim or import-compatible local patch before asking for broad regeneration.",
            "Keep unrelated scene content unchanged.",
        ]
    if lane == "modify_success_reference":
        return [
            f"Apply only the requested visual change to {target}.",
            "Preserve every listed non-target region.",
            "Do not use global rewriting to satisfy a local modification.",
        ]
    return [
        f"Separate the conflicting visual objects around {target}.",
        "Keep labels close to their semantic geometry anchor.",
        "Do not resolve overlap only by shrinking text or moving it to an unrelated screen edge.",
        "The repaired candidate must pass real render, frame probe, and layout probe before it is clean.",
    ]


def _repair_scope(
    case_data: Mapping[str, Any],
    review_data: Mapping[str, Any],
    lane: str,
) -> str:
    explicit = _first_value(case_data, review_data, "repair_scope", "scope")
    if explicit:
        return str(explicit)

    scene = _first_value(case_data, review_data, "scene_name", "target_scene") or "target scene"
    target = _target_object(case_data, review_data, lane)
    if lane == "math_logic":
        return f"{scene} 内 {target} 的数学含义与推导文本"
    if lane == "pre_render_helper_runtime":
        return f"{scene} 内 {target} 的确定性 helper/runtime 修复点"
    if lane == "modify_success_reference":
        return f"{scene} 内目标区域最小修改，非目标区域保持不变"
    return f"{scene} 内 {target} 的布局重构"


def _recommended_strategy(lane: str, failure_code: Any) -> str:
    failure_text = str(failure_code or "").lower()
    if lane == "math_logic":
        return "repair_math_reasoning_preserve_layout"
    if lane == "pre_render_helper_runtime":
        return "deterministic_fix_first"
    if lane == "modify_success_reference":
        return "targeted_modify_with_non_target_preservation"
    if "layout_overlap" in failure_text or "no_quantified_improvement" in failure_text:
        return LAYOUT_RESTRUCTURE_STRATEGY
    return "layout_restructure_with_scene_recheck"


def _forbidden_actions(lane: str) -> list[str]:
    common = [
        "do not edit non-target scenes",
        "do not delete key text",
        "do not mark repaired without re-probe",
    ]

    if lane == "math_logic":
        return common + [
            "do not change layout as math fix",
            "do not change problem statement",
            "do not change final answer without proof",
        ]
    if lane == "pre_render_helper_runtime":
        return common + [
            "do not use multi-round LLM patch as first choice",
            "do not patch unrelated scene content",
            "do not change math meaning to avoid runtime error",
        ]
    if lane == "modify_success_reference":
        return common + [
            "do not rewrite unrelated objects",
            "do not change non-target regions",
            "do not broaden the user-requested target",
        ]
    return common + [
        "do not use smaller font as only strategy",
        "do not hide or crop content",
    ]


def _acceptance_criteria(lane: str, case_data: Mapping[str, Any]) -> dict[str, Any]:
    expected = _get(case_data, "expected_acceptance")
    criteria = dict(expected) if isinstance(expected, Mapping) else {}
    criteria.update(
        {
            "parse_ok": True,
            "target_scene_changed": True,
            "non_target_changed": False,
            "render_ok": True,
            "frame_probe_ok": True,
        }
    )

    if lane == "math_logic":
        criteria.update(
            {
                "math_meaning_preserved": True,
                "math_hard_issue_disappears": True,
                "layout_repair_not_allowed": True,
                "layout_probe_ok": True,
            }
        )
        return criteria

    if lane == "pre_render_helper_runtime":
        criteria.update(
            {
                "deterministic_fix_attempted_first": True,
                "parse_or_import_passes": True,
                "multi_round_llm_patch_not_first_choice": True,
            }
        )
        return criteria

    if lane == "modify_success_reference":
        criteria.update(
            {
                "target_region_changed": True,
                "non_target_regions_unchanged": True,
                "math_meaning_preserved": True,
            }
        )
        return criteria

    criteria.update(
        {
            "hard_layout_errors": 0,
            "overlap_count_must_not_increase": True,
            "max_overlap_ratio_must_not_increase": True,
            "key_text_visible": True,
            "math_meaning_preserved": True,
            "layout_probe_ok": True,
        }
    )
    return criteria
