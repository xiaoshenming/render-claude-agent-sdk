from __future__ import annotations

from dataclasses import dataclass
import re


@dataclass(frozen=True)
class FrameOverflowRepairResult:
    code: str
    changed: bool
    strategy: str | None = None
    target_variable: str | None = None


_ASSIGNMENT_RE = re.compile(
    r"(?m)^(?P<indent>[ \t]*)(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*="
)
_DIRECT_TARGET_RE = re.compile(
    r"\b([A-Za-z_][A-Za-z0-9_]*(?:_(?:group|text|title|formula|axes|content))?|"
    r"title|formula_group|content_group|axes_group)\b"
)
_CONSTRUCTOR_RE = re.compile(
    r"\b(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?P<ctor>VGroup|Group|Text|MathTex)\s*\(",
    re.MULTILINE | re.DOTALL,
)


def extract_frame_overflow_target(problem_summary: str | None, code: str) -> str | None:
    summary = problem_summary or ""
    direct = _target_from_summary_name(summary, code)
    if direct:
        return direct

    constructor = _target_from_summary_constructor(summary, code)
    if constructor:
        return constructor

    if _looks_like_frame_overflow(summary):
        return _fallback_visual_target(code)
    return None


def repair_frame_overflow(
    code: str,
    problem_summary: str | None = None,
    scene_name: str | None = None,
) -> FrameOverflowRepairResult:
    scoped_code = _scene_scope_code(code, scene_name) if scene_name else code
    target = extract_frame_overflow_target(problem_summary, scoped_code)
    if not target or _has_existing_patch(code, target):
        return FrameOverflowRepairResult(code=code, changed=False, target_variable=target)

    patched = _insert_patch_after_assignment(code, target)
    patched = _repair_top_title_overflow(patched, scene_name)
    if patched == code:
        return FrameOverflowRepairResult(code=code, changed=False, target_variable=target)

    return FrameOverflowRepairResult(
        code=patched,
        changed=True,
        strategy="frame_overflow_fit_and_center",
        target_variable=target,
    )


def _target_from_summary_name(summary: str, code: str) -> str | None:
    assigned_names = set(_assigned_names(code))
    if not assigned_names:
        return None

    group_args = _constructor_args_from_summary(summary, ("VGroup", "Group"))
    if group_args:
        target = _assigned_constructor_matching_args(code, ("VGroup", "Group"), group_args)
        if target:
            return target

    for name in _DIRECT_TARGET_RE.findall(summary):
        if name in assigned_names:
            return name

    return None


def _target_from_summary_constructor(summary: str, code: str) -> str | None:
    ctors = []
    for ctor in ("VGroup", "Group", "MathTex", "Text"):
        if re.search(rf"\b{ctor}\s*\(", summary):
            ctors.append(ctor)
    if not ctors:
        return None

    args = _constructor_args_from_summary(summary, tuple(ctors))
    if args:
        target = _assigned_constructor_matching_args(code, tuple(ctors), args)
        if target:
            return target

    return _preferred_constructor_assignment(code, tuple(ctors))


def _looks_like_frame_overflow(summary: str) -> bool:
    lowered = summary.lower()
    if not lowered:
        return False
    return (
        "frame" in lowered
        or "bound" in lowered
        or "overflow" in lowered
        or "no_quantified_improvement" in lowered
        or "exceeds" in lowered
    )


def _fallback_visual_target(code: str) -> str | None:
    visual_assignments = list(_constructor_assignments(code))
    if not visual_assignments:
        return None

    group_assignments = [
        item for item in visual_assignments if item[1] in {"VGroup", "Group"}
    ]
    preferred_names = (
        "formula_group",
        "content_group",
        "axes_group",
        "title_group",
        "text_group",
        "group",
    )
    for preferred in preferred_names:
        for name, _ctor in group_assignments:
            if name == preferred:
                return name
    if group_assignments:
        return group_assignments[0][0]

    for preferred in ("title", "content", "text", "formula"):
        for name, _ctor in visual_assignments:
            if name == preferred or preferred in name.lower():
                return name
    return visual_assignments[0][0]


def _assigned_names(code: str) -> list[str]:
    return [match.group("name") for match in _ASSIGNMENT_RE.finditer(code)]


def _constructor_assignments(code: str) -> list[tuple[str, str]]:
    return [(match.group("name"), match.group("ctor")) for match in _CONSTRUCTOR_RE.finditer(code)]


def _constructor_args_from_summary(summary: str, constructors: tuple[str, ...]) -> list[str]:
    for ctor in constructors:
        index = summary.find(f"{ctor}(")
        if index < 0:
            continue
        start = index + len(ctor)
        end = _matching_paren_index(summary, start)
        if end is None:
            continue
        inner = summary[start + 1 : end]
        names = re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", inner)
        return [name for name in names if name not in {"Text", "MathTex", "VGroup", "Group"}]
    return []


def _assigned_constructor_matching_args(
    code: str,
    constructors: tuple[str, ...],
    required_args: list[str],
) -> str | None:
    if not required_args:
        return None
    for match in _CONSTRUCTOR_RE.finditer(code):
        if match.group("ctor") not in constructors:
            continue
        start = code.find("(", match.end() - 1)
        end = _matching_paren_index(code, start)
        if end is None:
            continue
        inner = code[start + 1 : end]
        if all(re.search(rf"\b{re.escape(arg)}\b", inner) for arg in required_args):
            return match.group("name")
    return None


def _preferred_constructor_assignment(code: str, constructors: tuple[str, ...]) -> str | None:
    matches = [
        (name, ctor)
        for name, ctor in _constructor_assignments(code)
        if ctor in set(constructors)
    ]
    if not matches:
        return None

    for preferred in ("formula_group", "content_group", "axes_group", "long_formula", "formula", "title"):
        for name, _ctor in matches:
            if name == preferred or preferred in name.lower():
                return name
    return matches[0][0]


def _matching_paren_index(text: str, open_index: int) -> int | None:
    if open_index < 0 or open_index >= len(text) or text[open_index] != "(":
        return None
    depth = 0
    quote: str | None = None
    escaped = False
    for index in range(open_index, len(text)):
        char = text[index]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in {'"', "'"}:
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return index
    return None


def _has_existing_patch(code: str, target: str) -> bool:
    return (
        f"{target}.scale_to_fit_width(config.frame_width * 0.9)" in code
        or f"{target}.scale_to_fit_height(config.frame_height * 0.85)" in code
    )


def _insert_patch_after_assignment(code: str, target: str) -> str:
    lines = code.splitlines(keepends=True)
    assignment_index = _assignment_line_index(lines, target)
    if assignment_index is None:
        return code

    end_index = _assignment_end_line_index(lines, assignment_index)
    end_index = _target_positioning_end_line_index(lines, end_index, target)
    line_text = lines[assignment_index]
    indent = re.match(r"^[ \t]*", line_text).group(0)
    newline = "\n" if line_text.endswith("\n") else ""
    patch_lines = [
        f"{indent}# quality_lab:frame_overflow_fit_and_center{newline or chr(10)}",
        f"{indent}if {target}.width > config.frame_width * 0.9:{newline or chr(10)}",
        f"{indent}    {target}.scale_to_fit_width(config.frame_width * 0.9){newline or chr(10)}",
        f"{indent}if {target}.height > config.frame_height * 0.85:{newline or chr(10)}",
        f"{indent}    {target}.scale_to_fit_height(config.frame_height * 0.85){newline or chr(10)}",
        f"{indent}{target}.move_to(ORIGIN){newline or chr(10)}",
        f"{indent}if {target}.width > config.frame_width * 0.65:{newline or chr(10)}",
        f"{indent}    {target}.to_edge(LEFT, buff=0.65){newline or chr(10)}",
    ]
    return "".join(lines[: end_index + 1] + patch_lines + lines[end_index + 1 :])


def _assignment_line_index(lines: list[str], target: str) -> int | None:
    pattern = re.compile(rf"^[ \t]*{re.escape(target)}\s*=")
    for index, line in enumerate(lines):
        if pattern.search(line):
            return index
    return None


def _assignment_end_line_index(lines: list[str], start_index: int) -> int:
    depth = 0
    quote: str | None = None
    escaped = False
    for index in range(start_index, len(lines)):
        for char in lines[index]:
            if quote:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == quote:
                    quote = None
                continue
            if char in {'"', "'"}:
                quote = char
            elif char in "([{":
                depth += 1
            elif char in ")]}":
                depth = max(depth - 1, 0)
        if depth == 0:
            return index
    return start_index


def _target_positioning_end_line_index(lines: list[str], start_index: int, target: str) -> int:
    end_index = start_index
    pattern = re.compile(
        rf"^[ \t]*{re.escape(target)}\.(?:move_to|shift|to_edge|next_to|scale|scale_to_fit_width|scale_to_fit_height)\("
    )
    for index in range(start_index + 1, len(lines)):
        line = lines[index]
        if not line.strip():
            continue
        if pattern.match(line):
            end_index = index
            continue
        break
    return end_index


def _scene_scope_code(code: str, scene_name: str | None) -> str:
    bounds = _class_scope_line_bounds(code.splitlines(keepends=True), scene_name)
    if bounds is None:
        return code
    start, end = bounds
    return "".join(code.splitlines(keepends=True)[start:end])


def _repair_top_title_overflow(code: str, scene_name: str | None) -> str:
    lines = code.splitlines(keepends=True)
    bounds = _class_scope_line_bounds(lines, scene_name)
    start, end = bounds if bounds else (0, len(lines))
    changed = False
    for index in range(start, min(end, len(lines))):
        line = lines[index]
        if re.match(r"^\s*title\.move_to\(\s*UP\s*\*\s*4\.0\s*\)", line):
            indent = re.match(r"^[ \t]*", line).group(0)
            newline = "\n" if line.endswith("\n") else ""
            lines[index] = f"{indent}title.to_edge(UP, buff=0.55){newline}"
            changed = True
        elif re.match(r"^\s*title\.to_edge\(\s*UP\s*,\s*buff\s*=\s*0\.[0-4]\d*\s*\)", line):
            lines[index] = re.sub(r"buff\s*=\s*0\.[0-4]\d*", "buff=0.55", line, count=1)
            changed = True
    return "".join(lines) if changed else code


def _class_scope_line_bounds(lines: list[str], class_name: str | None) -> tuple[int, int] | None:
    if not class_name:
        return None
    class_pattern = re.compile(rf"^(?P<indent>[ \t]*)class\s+{re.escape(class_name)}\b")
    start = None
    base_indent = 0
    for index, line in enumerate(lines):
        match = class_pattern.match(line)
        if match:
            start = index
            base_indent = len(match.group("indent"))
            break
    if start is None:
        return None
    for index in range(start + 1, len(lines)):
        line = lines[index]
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" \t"))
        if indent <= base_indent and re.match(r"^(class|def)\s+", line.lstrip()):
            return start, index
    return start, len(lines)
