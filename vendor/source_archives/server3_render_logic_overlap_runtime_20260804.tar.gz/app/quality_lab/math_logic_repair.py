from __future__ import annotations

import ast
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class MathLogicRepairResult:
    code: str
    changed: bool
    strategy: str
    failure_code: str | None
    message: str


_REPAIR_SPECS = {
    "missing_subquestion": {
        "strategy": "append_missing_subquestion_check_prompt",
        "text": "补充遗漏小问/条件核对：确认题目每个小问和已知条件都已覆盖",
        "existing_markers": ("补充遗漏小问/条件核对",),
    },
    "geometry_relation_error": {
        "strategy": "append_geometry_relation_check_prompt",
        "text": "关系核对：对应点/平行/垂直/距离需与题设一致",
        "existing_markers": ("关系核对：对应点/平行/垂直/距离需与题设一致",),
    },
    "teaching_structure_gap": {
        "strategy": "append_teaching_structure_prompt",
        "text": "关键步骤：观察 -> 建模 -> 推导 -> 验证",
        "existing_markers": ("关键步骤：观察 -> 建模 -> 推导 -> 验证",),
    },
}

_CONSTRUCT_RE = re.compile(r"^(?P<indent>[ \t]*)def\s+construct\s*\(", re.MULTILINE)
_SUMMARY_MARKERS = ("summary", "conclusion", "总结", "小结", "结论")


def repair_math_logic_case(
    code: str,
    failure_code: str | None,
    problem_summary: str | None = None,
) -> MathLogicRepairResult:
    spec = _REPAIR_SPECS.get(failure_code or "")
    if spec is None:
        return MathLogicRepairResult(
            code=code,
            changed=False,
            strategy="unsupported_failure_code",
            failure_code=failure_code,
            message=f"unsupported math_logic failure_code: {failure_code}",
        )

    prompt_text = _select_prompt_text(code, problem_summary, failure_code, spec["text"])
    if _contains_existing_repair_prompt(code, prompt_text, spec["existing_markers"]):
        return MathLogicRepairResult(
            code=code,
            changed=False,
            strategy="already_contains_math_logic_prompt",
            failure_code=failure_code,
            message="already contains a matching math logic repair prompt",
        )

    if failure_code == "missing_subquestion" and not _has_summary_context(code, problem_summary):
        return MathLogicRepairResult(
            code=code,
            changed=False,
            strategy="missing_summary_anchor",
            failure_code=failure_code,
            message="missing_subquestion repair requires an existing summary/conclusion anchor",
        )

    insertion = _find_construct_insertion(code)
    if insertion is None:
        return MathLogicRepairResult(
            code=code,
            changed=False,
            strategy="missing_construct_anchor",
            failure_code=failure_code,
            message="could not find a safe construct() insertion point",
        )

    line_index, indent = insertion
    patched = _insert_prompt(code, line_index, indent, prompt_text)
    if not _is_parseable(patched):
        return MathLogicRepairResult(
            code=code,
            changed=False,
            strategy="parse_guard_rejected_patch",
            failure_code=failure_code,
            message="candidate math logic repair patch was not parseable",
        )

    return MathLogicRepairResult(
        code=patched,
        changed=True,
        strategy=spec["strategy"],
        failure_code=failure_code,
        message="inserted safe math logic review prompt",
    )


def _contains_existing_repair_prompt(
    code: str,
    prompt_text: str,
    existing_markers: tuple[str, ...],
) -> bool:
    return prompt_text in code or any(marker in code for marker in existing_markers)


def _has_summary_context(code: str, problem_summary: str | None) -> bool:
    combined = f"{code}\n{problem_summary or ''}".lower()
    return any(marker in combined for marker in _SUMMARY_MARKERS)


def _select_prompt_text(
    code: str,
    problem_summary: str | None,
    failure_code: str,
    default_text: str,
) -> str:
    combined = _normalize_context(f"{code}\n{problem_summary or ''}")
    if failure_code == "missing_subquestion" and all(
        marker in combined for marker in ("平移", "中心对称", "原点")
    ):
        return "复合变换补充：先平移 P(x,y)->P'(x+a,y+b)，再关于原点中心对称，得到 P'' (-(x+a), -(y+b))"
    if failure_code == "geometry_relation_error" and all(
        marker in combined for marker in ("逆时针", "90")
    ):
        return "旋转方向校验：绕A点逆时针90°时，B'在A上方，D'在A左侧；仅添加校验提示，不移动点坐标"
    if failure_code == "teaching_structure_gap" and all(
        marker in combined for marker in ("旋转", "直角", "垂直")
    ):
        return "证明链补充：旋转保持角度，因此直角边的像仍互相垂直"
    return default_text


def _normalize_context(text: str) -> str:
    return re.sub(r"\s+", "", text)


def _find_construct_insertion(code: str) -> tuple[int, str] | None:
    lines = code.splitlines(keepends=True)
    construct_match = _CONSTRUCT_RE.search(code)
    if construct_match is None:
        return None

    construct_line_index = code[: construct_match.start()].count("\n")
    body_indent = f"{construct_match.group('indent')}    "

    last_wait_index: int | None = None
    last_body_index: int | None = None
    for index in range(construct_line_index + 1, len(lines)):
        line = lines[index]
        stripped = line.strip()
        if not stripped:
            continue

        leading = line[: len(line) - len(line.lstrip(" \t"))]
        if len(leading) <= len(construct_match.group("indent")) and not stripped.startswith("#"):
            break

        last_body_index = index + 1
        if "self.wait(" in line:
            last_wait_index = index
            body_indent = leading

    if last_wait_index is not None:
        return last_wait_index, body_indent
    if last_body_index is not None:
        return last_body_index, body_indent
    return None


def _insert_prompt(code: str, line_index: int, indent: str, prompt_text: str) -> str:
    lines = code.splitlines(keepends=True)
    newline = "\n" if code.endswith("\n") or not lines else ""
    prompt_lines = [
        f'{indent}math_logic_note = Text("{prompt_text}", font_size=24).to_edge(DOWN, buff=0.25)\n',
        f"{indent}self.add(math_logic_note)\n",
    ]
    if not lines:
        return "".join(prompt_lines)
    lines[line_index:line_index] = prompt_lines
    patched = "".join(lines)
    if newline and not patched.endswith("\n"):
        patched += newline
    return patched


def _is_parseable(code: str) -> bool:
    try:
        ast.parse(code)
    except SyntaxError:
        return False
    return True
