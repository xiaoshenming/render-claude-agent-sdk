from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

from app.quality_lab.case_schema import CaseValidationError, QualityRepairCase


def load_case(path: str | Path, *, strict_files: bool = False) -> QualityRepairCase:
    case_path = _resolve_case_json(Path(path))
    data = _load_json(case_path)
    case = QualityRepairCase.from_dict(data)
    if strict_files:
        _validate_artifact_files(case_path.parent, case)
    return case


def load_manifest(
    jsonl_path: str | Path,
    *,
    strict_files: bool = False,
) -> list[QualityRepairCase]:
    manifest_path = Path(jsonl_path)
    cases: list[QualityRepairCase] = []
    with manifest_path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                entry = json.loads(stripped)
            except json.JSONDecodeError as exc:
                raise CaseValidationError(
                    f"{manifest_path}:{line_number} is not valid JSON: {exc.msg}"
                ) from exc
            cases.append(
                _load_manifest_entry(
                    entry,
                    manifest_dir=manifest_path.parent,
                    strict_files=strict_files,
                    line_number=line_number,
                )
            )
    return cases


def validate_case_pack_dir(
    case_dir: str | Path,
    *,
    strict_files: bool = False,
) -> QualityRepairCase:
    case_path = Path(case_dir)
    if not case_path.is_dir():
        raise CaseValidationError(f"case pack path must be a directory: {case_path}")
    return load_case(case_path, strict_files=strict_files)


def _resolve_case_json(path: Path) -> Path:
    if path.is_dir():
        path = path / "case.json"
    if path.name != "case.json":
        raise CaseValidationError(f"case path must be case.json or a case directory: {path}")
    if not path.exists():
        raise CaseValidationError(f"case.json not found: {path}")
    return path


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise CaseValidationError(f"{path} is not valid JSON: {exc.msg}") from exc
    if not isinstance(data, dict):
        raise CaseValidationError(f"{path} must contain a JSON object")
    return data


def _load_manifest_entry(
    entry: Any,
    *,
    manifest_dir: Path,
    strict_files: bool,
    line_number: int,
) -> QualityRepairCase:
    if not isinstance(entry, dict):
        raise CaseValidationError(f"manifest line {line_number} must be a JSON object")

    case_ref = entry.get("case_path") or entry.get("path")
    if case_ref:
        if not isinstance(case_ref, str):
            raise CaseValidationError(f"manifest line {line_number} case_path must be a string")
        return load_case(manifest_dir / case_ref, strict_files=strict_files)

    return QualityRepairCase.from_dict(entry)


def _validate_artifact_files(case_dir: Path, case: QualityRepairCase) -> None:
    missing = [
        reference
        for reference in _iter_artifact_references(case.input_artifacts.values())
        if not (case_dir / reference).exists()
    ]
    if missing:
        raise CaseValidationError(
            "missing artifact files: " + ", ".join(str(path) for path in missing)
        )


def _iter_artifact_references(values: Iterable[Any]) -> Iterable[str]:
    for value in values:
        if isinstance(value, str):
            yield value
        elif isinstance(value, dict):
            yield from _iter_artifact_references(value.values())
        elif isinstance(value, list):
            yield from _iter_artifact_references(value)
