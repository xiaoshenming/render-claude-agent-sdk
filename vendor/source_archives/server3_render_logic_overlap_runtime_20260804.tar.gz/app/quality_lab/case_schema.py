from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any


class CaseValidationError(ValueError):
    """Raised when a quality repair lab case pack is structurally invalid."""


REQUIRED_CASE_FIELDS = (
    "case_id",
    "job_id",
    "scene_name",
    "lane",
    "failure_code",
    "first_failure_source",
    "input_artifacts",
    "expected_acceptance",
    "baseline",
)


def _require_mapping(data: Any, context: str) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise CaseValidationError(f"{context} must be an object")
    return data


def _require_string(data: dict[str, Any], field_name: str) -> str:
    value = data.get(field_name)
    if not isinstance(value, str) or not value.strip():
        raise CaseValidationError(f"{field_name} is required and must be a string")
    return value


def _optional_string(data: dict[str, Any], field_name: str) -> str | None:
    value = data.get(field_name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise CaseValidationError(f"{field_name} must be a string")
    return value


def _copy_mapping(data: dict[str, Any], field_name: str) -> dict[str, Any]:
    value = data.get(field_name)
    if not isinstance(value, dict):
        raise CaseValidationError(f"{field_name} is required and must be an object")
    return dict(value)


@dataclass(frozen=True)
class QualityRepairCase:
    case_id: str
    job_id: str
    scene_name: str
    lane: str
    failure_code: str
    first_failure_source: str
    input_artifacts: dict[str, Any]
    expected_acceptance: dict[str, Any]
    baseline: dict[str, Any]
    original_status: str | None = None
    terminal_error_stage: str | None = None
    terminal_error_type: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QualityRepairCase":
        data = _require_mapping(data, "case")
        missing = [field_name for field_name in REQUIRED_CASE_FIELDS if field_name not in data]
        if missing:
            raise CaseValidationError(f"missing required case fields: {', '.join(missing)}")

        case = cls(
            case_id=_require_string(data, "case_id"),
            job_id=_require_string(data, "job_id"),
            scene_name=_require_string(data, "scene_name"),
            lane=_require_string(data, "lane"),
            failure_code=_require_string(data, "failure_code"),
            first_failure_source=_require_string(data, "first_failure_source"),
            original_status=_optional_string(data, "original_status"),
            terminal_error_stage=_optional_string(data, "terminal_error_stage"),
            terminal_error_type=_optional_string(data, "terminal_error_type"),
            input_artifacts=_copy_mapping(data, "input_artifacts"),
            expected_acceptance=_copy_mapping(data, "expected_acceptance"),
            baseline=_copy_mapping(data, "baseline"),
            metadata=dict(data.get("metadata") or {}),
            raw=dict(data),
        )
        case.validate()
        return case

    def validate(self) -> None:
        if not self.input_artifacts:
            raise CaseValidationError("input_artifacts must not be empty")
        for name, reference in self.input_artifacts.items():
            if not isinstance(name, str) or not name:
                raise CaseValidationError("input_artifacts keys must be non-empty strings")
            if not isinstance(reference, str) or not reference:
                raise CaseValidationError(
                    f"input_artifacts.{name} must be a non-empty relative path"
                )
            if reference.startswith("/"):
                raise CaseValidationError(
                    f"input_artifacts.{name} must be relative, got {reference}"
                )
            if _escapes_case_dir(reference):
                raise CaseValidationError(
                    f"input_artifacts.{name} must stay inside case directory, got {reference}"
                )


def _escapes_case_dir(reference: str) -> bool:
    path = PurePosixPath(reference.replace("\\", "/"))
    return any(part == ".." for part in path.parts)


@dataclass(frozen=True)
class RepairContract:
    case_id: str
    lane: str
    target_object: str | None = None
    repair_scope: str | None = None
    recommended_strategy: str | None = None
    forbidden_actions: list[str] = field(default_factory=list)
    acceptance_criteria: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RepairContract":
        data = _require_mapping(data, "repair_contract")
        forbidden_actions = data.get("forbidden_actions") or []
        acceptance_criteria = data.get("acceptance_criteria") or {}
        if not isinstance(forbidden_actions, list):
            raise CaseValidationError("forbidden_actions must be a list")
        if isinstance(acceptance_criteria, list):
            acceptance_criteria = {str(item): True for item in acceptance_criteria}
        if not isinstance(acceptance_criteria, dict):
            raise CaseValidationError("acceptance_criteria must be an object")
        return cls(
            case_id=_require_string(data, "case_id"),
            lane=_require_string(data, "lane"),
            target_object=_optional_string(data, "target_object"),
            repair_scope=_optional_string(data, "repair_scope"),
            recommended_strategy=_optional_string(data, "recommended_strategy"),
            forbidden_actions=[str(item) for item in forbidden_actions],
            acceptance_criteria=dict(acceptance_criteria),
            raw=dict(data),
        )


@dataclass(frozen=True)
class ReplayResult:
    case_id: str
    mode: str
    outcome: str
    metrics: dict[str, Any] = field(default_factory=dict)
    artifacts: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ReplayResult":
        data = _require_mapping(data, "replay_result")
        metrics = data.get("metrics") or {}
        artifacts = data.get("artifacts") or {}
        errors = data.get("errors") or []
        if not isinstance(metrics, dict):
            raise CaseValidationError("metrics must be an object")
        if not isinstance(artifacts, dict):
            raise CaseValidationError("artifacts must be an object")
        if not isinstance(errors, list):
            raise CaseValidationError("errors must be a list")
        return cls(
            case_id=_require_string(data, "case_id"),
            mode=_require_string(data, "mode"),
            outcome=_require_string(data, "outcome"),
            metrics=dict(metrics),
            artifacts=dict(artifacts),
            errors=[str(error) for error in errors],
            raw=dict(data),
        )
