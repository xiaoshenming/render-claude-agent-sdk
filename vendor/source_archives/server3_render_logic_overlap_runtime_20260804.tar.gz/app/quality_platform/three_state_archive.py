"""Persist the V3 full-video Before / Logic / After artifacts fail-open."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping

from app.workers.quality_cases.collector import QualityCaseCollector
from app.workers.quality_cases.compose import compose_three_state_video
from app.workers.quality_cases.persist import persist_quality_case
from app.workers.quality_cases.storage import (
    is_quality_case_composition_enabled,
    is_quality_cases_enabled,
    quality_case_dir,
)

logger = logging.getLogger("render")

CASE_ID = "__job_v3_three_state__"
SCENE_NAME = "完整视频三态"


async def persist_v3_three_state(
    *,
    worker: Any,
    task_data: dict[str, Any],
    payload: Mapping[str, Any],
) -> dict[str, Any] | None:
    """Copy, compose, upload and index existing V3 renders without rerendering."""
    if not is_quality_cases_enabled():
        return None
    artifacts = payload.get("three_state")
    if not isinstance(artifacts, Mapping):
        return None
    try:
        before = _stage(artifacts, "before")
        logic = _stage(artifacts, "logic")
        after = _stage(artifacts, "after")
        case_dir = quality_case_dir(
            media_root=str(worker.media_root),
            job_id=str(task_data["job_id"]),
            scene_name=SCENE_NAME,
            case_id=CASE_ID,
        )
        collector = QualityCaseCollector(
            case_dir=case_dir,
            job_id=str(task_data["job_id"]),
            scene_name=SCENE_NAME,
            pipeline="minimal_v3",
            aspect_ratio=str(task_data.get("aspect_ratio") or "16:9"),
            case_id=CASE_ID,
        )
        collector.capture_baseline(
            script_path=before["code"],
            video_path=before["video"],
            source="initial_render_reused",
        )
        logic_status = str(logic.get("status") or "")
        collector.capture_logic_fixed(
            script_path=logic["code"],
            video_path=logic["video"],
            issues=_issues(payload.get("logic")),
            status=_logic_stage_status(logic_status),
            error=_stage_error(payload.get("logic")),
            repair_event={"status": logic_status, "source": "v3_logic_agent"},
        )
        layout_status = str(after.get("status") or "")
        collector.capture_layout_fixed(
            script_path=after["code"],
            video_path=after["video"],
            status=_layout_stage_status(layout_status),
            error=_stage_error(payload.get("layout")),
            repair_method="v3_layout_agent",
            repair_source="claude_agent_sdk",
        )
        collector.add_note("三态均复用 V3 已有真实渲染，不额外重复渲染。")
        collector.finalize()
        comparison = None
        if is_quality_case_composition_enabled():
            comparison = await compose_three_state_video(case_dir, collector.manifest)
        row = await persist_quality_case(
            case_dir=case_dir,
            manifest=collector.manifest,
            comparison_path=comparison,
            collector=task_data.get("_error_collector"),
        )
        return {"case_id": CASE_ID, "case_dir": str(case_dir), "persisted": bool(row)}
    except Exception as exc:  # noqa: BLE001 - evidence must never block delivery.
        logger.warning("[V3_THREE_STATE] 留档失败 job=%s: %s", task_data.get("job_id"), exc)
        return {"case_id": CASE_ID, "error": f"{type(exc).__name__}: {exc}"[:500]}


def _stage(artifacts: Mapping[str, Any], name: str) -> dict[str, Any]:
    value = artifacts.get(name)
    if not isinstance(value, Mapping):
        raise ValueError(f"missing three-state stage: {name}")
    result = dict(value)
    for key in ("code", "video"):
        path = Path(str(result.get(key) or ""))
        if not path.is_file() or path.stat().st_size <= 0:
            raise FileNotFoundError(f"{name}.{key} missing: {path}")
    return result


def _logic_stage_status(status: str) -> str:
    if status == "candidate_ready":
        return "repaired"
    if status == "review_record_only":
        return "available"
    if status in {"candidate_advisory", "human_review"}:
        return "repair_failed"
    if status == "review_pass":
        return "not_triggered"
    return "repair_failed"


def _layout_stage_status(status: str) -> str:
    if status in {"candidate_recheck_required", "residual_candidate_recheck_required"}:
        return "repaired"
    if status == "clean":
        return "available"
    if status in {"record_only", "detection_error"}:
        return "repair_failed"
    return "repair_failed"


def _issues(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, Mapping):
        return []
    issues = value.get("issues")
    return [dict(item) for item in issues or [] if isinstance(item, Mapping)]


def _stage_error(value: Any) -> str | None:
    if not isinstance(value, Mapping):
        return None
    error = str(value.get("error") or value.get("reason") or "").strip()
    return error[:1000] or None


__all__ = ["CASE_ID", "SCENE_NAME", "persist_v3_three_state"]
