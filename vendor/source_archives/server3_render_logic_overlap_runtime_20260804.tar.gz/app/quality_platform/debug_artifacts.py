"""Upload allowlisted V3 debugging evidence before job cleanup."""

from __future__ import annotations

import difflib
import hashlib
import json
import logging
from pathlib import Path
from typing import Awaitable, Callable, Mapping

logger = logging.getLogger("render")

UploadFile = Callable[..., Awaitable[str]]

_FIXED_FILES = {
    "result": "result.json",
    "selected_code": "candidate_final.py",
    "logic_summary": "logic/logic_summary.json",
    "logic_case_log": "logic/logic_case_log.json",
    "review_attempts": "logic/review_attempts.json",
    "before_code": "logic/dataset/candidate.py",
    "layout_summary": "layout/layout_summary.json",
    "layout_case_log": "layout/layout_case_log.json",
    "layout_classification": "layout/detect/platform_overlap_classification.json",
    "layout_context": "layout/layout_context.json",
}
_GLOBS = {
    "review_report": "logic/review*/cases/*/review_report.json",
    "review_agent_call": "logic/review*/cases/*/agent_call.json",
    "repair_result": "logic/repair/cases/*/repair_result.json",
    "repair_candidate": "logic/repair/cases/*/workspace/candidate.py",
    "accepted_candidate": "logic/repair/cases/*/candidate_after.py",
    "coder_call": "logic/repair/cases/*/coder-call-*.json",
    "verifier_call": "logic/repair/cases/*/verifier-call-*.json",
    "layout_repair_summary": "layout/repair_evidence/*/summary.json",
    "layout_acceptance": "layout/repair_evidence/*/acceptance.json",
    "layout_bundle_manifest": "layout/repair_evidence/*/bundle_manifest.json",
    "layout_round_usage": "layout/repair_evidence/*/round_*/usage.json",
    "layout_round_decision": "layout/repair_evidence/*/round_*/agent_decision.json",
    "layout_round_query": "layout/repair_evidence/*/round_*/evidence_query.json",
    "layout_round_check": "layout/repair_evidence/*/round_*/check_after/check_result.json",
    "layout_round_before_code": "layout/repair_evidence/*/round_*/candidate.full.before.py",
    "layout_round_after_code": "layout/repair_evidence/*/round_*/candidate.full.after.py",
    "layout_round_diff": "layout/repair_evidence/*/round_*/diff.patch",
    "layout_round_full_diff": "layout/repair_evidence/*/round_*/full_diff.patch",
    "layout_round_rejected_diff": "layout/repair_evidence/*/round_*/rejected_diff.patch",
    "layout_round_response": "layout/repair_evidence/*/round_*/final_response.txt",
    "layout_round_prompt": "layout/repair_evidence/*/round_*/prompt.md",
}


async def upload_debug_artifacts(
    *,
    job_id: str,
    manifest_path: Path,
    upload_file: UploadFile,
    retry_count: int,
) -> dict[str, object]:
    run_dir = manifest_path.parent
    entries = _collect(run_dir)
    prefix = f"quality-platform/{job_id}/pre-archive/retry-{retry_count}/debug"
    urls: dict[str, str] = {}
    metadata: list[dict[str, object]] = []
    for name, data in entries.items():
        key = f"{prefix}/{name}{_suffix(name)}"
        try:
            url = await upload_file(key, data, content_type=_content_type(name))
        except Exception as exc:  # noqa: BLE001 - evidence must remain fail-open.
            logger.warning("[QUALITY-PLATFORM] debug upload failed: %s %s", name, exc)
            continue
        urls[name] = str(url)
        metadata.append(
            {
                "name": name,
                "url": str(url),
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        )
    index = json.dumps(
        {"schema_version": "mathpi.quality-debug-index.v1", "artifacts": metadata},
        ensure_ascii=False,
        indent=2,
    ).encode("utf-8")
    try:
        index_url = await upload_file(
            f"{prefix}/index.json", index, content_type="application/json; charset=utf-8"
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("[QUALITY-PLATFORM] debug index upload failed: %s", exc)
        index_url = ""
    return {"index_url": str(index_url), "artifacts": urls}


def _collect(run_dir: Path) -> dict[str, bytes]:
    entries: dict[str, bytes] = {}
    for name, relative in _FIXED_FILES.items():
        _add(entries, name, run_dir / relative)
    for name, pattern in _GLOBS.items():
        for index, path in enumerate(sorted(run_dir.glob(pattern)), 1):
            _add(entries, f"{name}_{index}", path)
    before = entries.get("before_code")
    repaired = _first(entries, "repair_candidate_")
    if before is not None and repaired is not None and before != repaired:
        entries["repair_diff"] = _diff(before, repaired)
    return entries


def _add(entries: dict[str, bytes], name: str, path: Path) -> None:
    if path.is_file() and path.stat().st_size <= 5_000_000:
        entries[name] = path.read_bytes()


def _first(entries: Mapping[str, bytes], prefix: str) -> bytes | None:
    return next((value for key, value in entries.items() if key.startswith(prefix)), None)


def _diff(before: bytes, after: bytes) -> bytes:
    lines = difflib.unified_diff(
        before.decode("utf-8", "replace").splitlines(True),
        after.decode("utf-8", "replace").splitlines(True),
        fromfile="candidate_before.py",
        tofile="candidate_after_attempt.py",
    )
    return "".join(lines).encode("utf-8")


def _suffix(name: str) -> str:
    if "diff" in name:
        return ".diff"
    if "code" in name or "candidate" in name:
        return ".py"
    if "response" in name:
        return ".txt"
    if "prompt" in name:
        return ".md"
    return ".json"


def _content_type(name: str) -> str:
    if "diff" in name:
        return "text/x-diff; charset=utf-8"
    if "code" in name or "candidate" in name:
        return "text/x-python; charset=utf-8"
    if "response" in name or "prompt" in name:
        return "text/plain; charset=utf-8"
    return "application/json; charset=utf-8"
