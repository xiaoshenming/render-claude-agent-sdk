"""Video worker construction and runtime defaults."""

import asyncio
import logging
import os
from typing import List, Optional

from app.core.config import (
    DEFAULT_MAX_CONCURRENT_TASKS,
    normalize_container_names,
    normalize_max_concurrent_tasks,
    settings,
)
from app.workers.rendering.container import ContainerManager

logger = logging.getLogger(__name__)


class WorkerInitializationMixin:
    def __init__(
        self,
        container_names: Optional[List[str]] = None,
        media_root: Optional[str] = None,
        cpu_idle_threshold: float = 30.0,
        container_check_interval: float = 1.0,
        lock_stale_seconds: int = 60 * 30,
    ):
        configured_names = settings.CONTAINER_NAMES if container_names is None else container_names
        self.container_names = normalize_container_names(configured_names)
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        self.manim_media_root = os.path.join(project_root, "manim_media")
        self.media_root = os.path.abspath(
            media_root if media_root else os.path.join(project_root, "media")
        )
        self.locks_dir = os.path.join(self.manim_media_root, "locks")
        self.cache_dir = os.path.join(project_root, "render_cache")
        for path in (self.locks_dir, self.manim_media_root, self.media_root, self.cache_dir):
            os.makedirs(path, exist_ok=True)

        self.container_mgr = ContainerManager(
            container_names=self.container_names,
            locks_dir=self.locks_dir,
            container_check_interval=container_check_interval,
            lock_stale_seconds=lock_stale_seconds,
        )
        self.cpu_idle_threshold = cpu_idle_threshold
        self.container_check_interval = container_check_interval
        self.lock_stale_seconds = lock_stale_seconds
        self.connection = None
        self.channel = None
        self._consuming = False
        self._consumer_tasks: List[asyncio.Task] = []
        self._inflight_tasks: set[asyncio.Task] = set()
        self._inflight_task_ids: set[str] = set()
        self._last_consumer_error: Optional[str] = None
        self._last_consumer_exit_at: Optional[str] = None
        self._stale_active_job_recovery_checked = False
        self._container_backpressure_delay = 1.0
        self._container_backpressure_max_wait_seconds = 300.0
        self.processed_jobs = 0
        self.max_retries = getattr(settings, "MAX_RETRIES", 3)
        self.retry_queue_name = "video_generate_retry_queue"
        self.normal_queue_name = "video_generate_queue"

        requested = normalize_max_concurrent_tasks(
            getattr(settings, "MAX_CONCURRENT_TASKS", DEFAULT_MAX_CONCURRENT_TASKS)
        )
        maximum = self._cap_concurrency_by_container_count(requested)
        self._max_concurrent_tasks = maximum
        self._task_semaphore = asyncio.Semaphore(maximum)
        if requested != getattr(settings, "MAX_CONCURRENT_TASKS", None):
            logger.warning(
                "MAX_CONCURRENT_TASKS=%s 非法，已回退为 %s",
                getattr(settings, "MAX_CONCURRENT_TASKS", None), requested,
            )
        if maximum != requested:
            logger.warning(
                "MAX_CONCURRENT_TASKS=%s 超过容器数量=%s，已限制为 %s",
                requested, len(self.container_names), maximum,
            )
        if not self.container_names:
            logger.warning("CONTAINER_NAMES 未配置有效容器名，渲染任务将快速失败")
        self._dispatch_ctx_cache = None
        logger.info(
            "VideoWorker initialized: media_root=%s, containers=%s, max_concurrent_tasks=%s",
            self.media_root, self.container_names, self._max_concurrent_tasks,
        )
