"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}

# 这些实现已按职责拆到批次辅助模块；本文件保留稳定的导入 ABI。
from app.workers.task_dispatcher_helpers_batch1 import *
from app.workers.task_dispatcher_helpers_batch2 import *
from app.workers.task_dispatcher_helpers_batch3 import *
from app.workers.task_dispatcher_queue_helpers_batch4 import *
from app.workers.task_dispatcher_status_helpers_batch6 import *
from app.workers.task_dispatcher_helpers_batch1 import (
    _strip_non_serializable, _without_none, _safe_int, _normalize_job_status,
    _is_terminal_job_status, _failure_pipeline_fields, _json_safe_failure_value,
    _failure_signature_payload, _repair_signature_counts_payload,
    _layout_repair_failed_events_payload,
)
from app.workers.task_dispatcher_helpers_batch2 import (
    _failure_scene_name_from_task_data, _append_failure_attribution_to_error_message,
    _mq_attempt_id, _queue_name_for_type, _final_failure_state, _final_failure_ackable,
    _terminal_failure_signature, _record_final_failure_persist_failure,
    _clear_final_failure_persist_guard,
)
from app.workers.task_dispatcher_helpers_batch3 import _failure_attribution_payload, _failed_code_fallback
from app.workers.task_dispatcher_queue_helpers_batch4 import _ensure_queue_ready
from app.workers.task_dispatcher_retry_helpers_batch5 import handle_final_failure
from app.workers.task_dispatcher_failure_helpers_batch7 import (
    handle_task_failure,
    handle_task_exception,
)
from app.workers.task_dispatcher_core_contracts_batch8 import ack_terminal_redelivery_if_needed
from app.services import job_repository
from app.core.config import settings

def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

@dataclass
class DispatchContext:
    """消息调度所需的共享依赖。保持启动 ABI 稳定。"""
    channel: Any
    retry_queue_name: str
    max_retries: int
    manim_media_root: str

# 拆分模块中的实现保持独立文件，但运行时共享同一组契约辅助函数。
from app.workers import (
    task_dispatcher_helpers_batch2 as _batch2,
    task_dispatcher_helpers_batch3 as _batch3,
    task_dispatcher_queue_helpers_batch4 as _batch4,
    task_dispatcher_retry_helpers_batch5 as _batch5,
    task_dispatcher_status_helpers_batch6 as _batch6,
    task_dispatcher_failure_helpers_batch7 as _batch7,
    task_dispatcher_core_contracts_batch8 as _batch8,
)
_shared_helpers = {
    "job_repository": job_repository,
    "settings": settings,
    "mark_quality_rejected": mark_quality_rejected,
    "logger": logger,
    **{name: globals()[name] for name in (
        "_safe_int", "_without_none", "_normalize_job_status", "_is_terminal_job_status",
        "_failure_pipeline_fields", "_json_safe_failure_value",
        "_failure_signature_payload", "_repair_signature_counts_payload",
        "_layout_repair_failed_events_payload", "_failure_scene_name_from_task_data",
        "_append_failure_attribution_to_error_message", "_mq_attempt_id",
        "_queue_name_for_type", "_final_failure_state", "_final_failure_ackable",
        "_terminal_failure_signature", "_record_final_failure_persist_failure",
        "_clear_final_failure_persist_guard", "_failure_attribution_payload",
        "record_queue_event", "_failed_code_fallback", "handle_final_failure_persist_failed",
        "_ensure_queue_ready", "log_mq_quality_event", "log_render_quality_event",
        "flush_error_collector", "ack_with_queue_evidence", "nack_with_queue_evidence",
        "ack_terminal_redelivery_if_needed",
    )},
}
for _module in (_batch2, _batch3, _batch4, _batch5, _batch6, _batch7, _batch8):
    _module.__dict__.update(_shared_helpers)

async def publish_to_retry_queue(
    ctx: DispatchContext, task_data: Dict[str, Any],
):
    """发布任务到重试队列"""
    job_id = task_data.get("job_id")
    retry_count = task_data.get("retry_count", 0)
    last_error = task_data.get("last_error", "unknown")
    logger.warning(
        f"[RETRY] [{_ts()}] 准备重试任务 job_id={job_id}, "
        f"当前重试次数={retry_count}, 最大重试={ctx.max_retries}, "
        f"上次错误={last_error[:200] if last_error else 'N/A'}")
    try:
        serializable_data = _strip_non_serializable(task_data)
        # Retry mutates top-level fields in task_data.  A consumed schema-v1
        # message may still carry a stale nested payload from the previous
        # attempt; drop it before rebuilding the wire contract so the new
        # retry_count/attempt_id cannot be overwritten by old payload values.
        serializable_data.pop("payload", None)
        retry_count = _safe_int(serializable_data.get("retry_count", retry_count), 0)
        serializable_data["retry_count"] = retry_count
        task_data["retry_count"] = retry_count
        if job_id:
            attempt_id = _mq_attempt_id(
                serializable_data,
                job_id=job_id,
                retry_count=retry_count,
            )
            serializable_data["attempt_id"] = attempt_id
            task_data["attempt_id"] = attempt_id
        wire_data = build_video_task_message(serializable_data)
        payload = payload_from_task_data(wire_data)
        headers = {
            key: payload[key]
            for key in ("job_id", "user_id", "retry_count", "request_id", "trace_id", "attempt_id")
            if payload.get(key) is not None
        }
        body = json.dumps(wire_data, ensure_ascii=False).encode("utf-8")
        message = aio_pika.Message(
            body=body,
            delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
            priority=10,
            headers=headers,
        )
        await _ensure_queue_ready(ctx, ctx.retry_queue_name)
        await ctx.channel.default_exchange.publish(
            message,
            routing_key=ctx.retry_queue_name,
            mandatory=True,
            timeout=10,
        )
        record_queue_event(
            task_data,
            "info",
            "RETRY_PUBLISH",
            "RabbitMQ retry publish complete",
            queue_type="RETRY",
            job_id=job_id,
            retry_count=retry_count,
            retry_queue=ctx.retry_queue_name,
        )
        await log_mq_quality_event(
            "mq_retry_published",
            task_data,
            queue_type="RETRY",
            queue_name=ctx.retry_queue_name,
            routing_key=ctx.retry_queue_name,
            retry_count=retry_count,
            max_retries=ctx.max_retries,
            message_bytes=len(body),
            result="succeeded",
            detail="RabbitMQ retry publish complete",
        )
        logger.info(
            f"[RETRY] [{_ts()}] 任务已加入重试队列: "
            f"job_id={job_id}, retry={retry_count}")
    except Exception as e:
        record_queue_event(
            task_data,
            "error",
            "RETRY_PUBLISH",
            f"RabbitMQ retry publish failed: {e}",
            queue_type="RETRY",
            job_id=job_id,
            retry_count=retry_count,
            retry_queue=ctx.retry_queue_name,
            error=str(e),
        )
        await log_mq_quality_event(
            "mq_retry_publish_failed",
            task_data,
            queue_type="RETRY",
            queue_name=ctx.retry_queue_name,
            routing_key=ctx.retry_queue_name,
            retry_count=task_data.get("retry_count", retry_count),
            max_retries=ctx.max_retries,
            result="failed",
            detail="RabbitMQ retry publish failed",
            exception=e,
        )
        logger.exception(
            f"[RETRY] [{_ts()}] 发布到重试队列失败: "
            f"job_id={job_id}, error={e}")
        raise

async def defer_retry_publish_failure(
    ctx: DispatchContext,
    message: Any,
    task_data: Dict[str, Any],
    *,
    queue_type: str,
    job_id: str,
    retry_count: int,
    pub_err: Exception,
    detail_prefix: str = "Retry publish failed",
) -> None:
    """Keep retry publish failures as MQ infra events, not job final failures."""
    attempted_retry_count = task_data.get("retry_count")
    task_data["_mq_retry_publish_deferred"] = True
    task_data["_mq_retry_publish_error"] = {
        "reason": "retry_publish_failed",
        "queue_type": queue_type,
        "retry_queue": ctx.retry_queue_name,
        "routing_key": ctx.retry_queue_name,
        "previous_retry_count": retry_count,
        "attempted_retry_count": attempted_retry_count,
        "max_retries": ctx.max_retries,
        "exception_type": type(pub_err).__name__,
        "exception_message": str(pub_err)[:500],
    }
    task_data["_infra_error_type"] = "retry_publish_failed"
    task_data["_infra_error_stage"] = "retry_publish"
    task_data["retry_count"] = retry_count
    record_queue_event(
        task_data,
        "warning",
        "RETRY_PUBLISH_DEFERRED",
        f"{detail_prefix}; original message nacked for broker redelivery",
        queue_type="RETRY",
        job_id=job_id,
        retry_count=retry_count,
        retry_queue=ctx.retry_queue_name,
        attempted_retry_count=attempted_retry_count,
        error=str(pub_err),
    )
    await nack_with_queue_evidence(
        message,
        task_data,
        stage="QUEUE_NACK_RETRY_PUBLISH_DEFERRED",
        detail=(
            "Retry publish failed; original message nacked without "
            "overwriting job final failure"
        ),
        queue_type=queue_type,
        job_id=job_id,
        retry_count=retry_count,
        requeue=True,
    )
    await log_mq_quality_event(
        "mq_retry_publish_deferred",
        task_data,
        queue_type="RETRY",
        queue_name=ctx.retry_queue_name,
        routing_key=ctx.retry_queue_name,
        retry_count=retry_count,
        max_retries=ctx.max_retries,
        requeue=True,
        result="deferred",
        detail=(
            f"{detail_prefix}; keep original failure attribution and "
            "requeue original message"
        ),
        exception=pub_err,
    )
