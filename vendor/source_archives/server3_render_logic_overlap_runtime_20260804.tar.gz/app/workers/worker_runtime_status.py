"""Runtime health snapshots for the video worker."""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from typing import Any, Dict
from urllib.parse import quote, urlsplit

import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


async def get_container_status_summary(worker) -> Dict[str, Any]:
    """Return a lightweight status snapshot for the admin health endpoint."""
    containers = []
    running_count = busy_count = locked_count = available_count = 0
    for container in worker.container_names:
        lock_path = worker.container_mgr._lock_path(container)
        locked = os.path.exists(lock_path)
        lock_info = worker.container_mgr._lock_info(container)
        locked_count += int(locked)
        try:
            running = await worker.container_mgr._is_container_running(container)
            busy = await worker.container_mgr._container_has_manim(container) if running else False
            running_count += int(running)
            busy_count += int(busy)
            if not running:
                status = "stopped"
            elif busy:
                status = "busy"
            elif locked:
                status = "locked"
            else:
                status = "idle"
                available_count += 1
            containers.append({
                "name": container, "running": running, "busy": busy,
                "locked": locked, "lock": lock_info, "status": status,
            })
        except Exception as exc:
            logger.warning(
                "[CONTAINER] [%s] 获取容器状态失败: %s, error=%s",
                _ts(), container, exc,
            )
            containers.append({
                "name": container, "running": False, "busy": False,
                "locked": locked, "lock": lock_info, "status": "error",
                "error": str(exc)[:120],
            })
    inflight_ids = sorted(
        str(item) for item in (getattr(worker, "_inflight_task_ids", set()) or set()) if item
    )
    return {
        "total": len(worker.container_names), "running": running_count,
        "busy": busy_count, "locked": locked_count, "available": available_count,
        "processed_jobs": worker.processed_jobs, "inflight_task_ids": inflight_ids,
        "queues": await worker._get_queue_depth_summary(), "containers": containers,
    }


def unavailable_queue_payload(worker, error: str = "") -> Dict[str, Any]:
    item = {"ready": "unavailable", "unacked": "unavailable", "consumers": "unavailable"}
    payload = {
        "status": "unavailable",
        "normal": {"name": worker.normal_queue_name, **item},
        "retry": {"name": worker.retry_queue_name, **item},
    }
    if error:
        payload["error"] = error[:300]
    return payload


def declaration_int(declaration: Any, *names: str) -> int | str:
    for name in names:
        value = getattr(declaration, name, None)
        if value is not None:
            try:
                return int(value)
            except (TypeError, ValueError):
                return "unavailable"
    return "unavailable"


async def queue_depth_for(worker, queue_name: str) -> Dict[str, Any]:
    management_payload = await worker._queue_depth_for_management(queue_name)
    if management_payload is not None:
        return management_payload
    queue = await worker.channel.declare_queue(queue_name, passive=True)
    declaration = getattr(queue, "declaration_result", None)
    return {
        "name": queue_name,
        "ready": declaration_int(declaration, "messages_ready", "message_count"),
        "unacked": declaration_int(
            declaration, "messages_unacknowledged", "message_unacknowledged", "unacked"
        ),
        "consumers": declaration_int(declaration, "consumer_count"),
    }


def rabbitmq_management_queue_url(queue_name: str) -> tuple[str, tuple[str, str]] | None:
    parsed = urlsplit(str(settings.RABBITMQ_URL or ""))
    if not parsed.hostname or not parsed.username:
        return None
    host = parsed.hostname
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    vhost = parsed.path.lstrip("/") or "/"
    url = f"http://{host}:15672/api/queues/{quote(vhost, safe='')}/{quote(queue_name, safe='')}"
    return url, (parsed.username, parsed.password or "")


async def queue_depth_for_management(worker, queue_name: str) -> Dict[str, Any] | None:
    target = rabbitmq_management_queue_url(queue_name)
    if target is None:
        return None
    url, auth = target
    try:
        async with httpx.AsyncClient(timeout=1.5) as client:
            response = await client.get(url, auth=auth)
        response.raise_for_status()
        payload = response.json()
        return {
            "name": queue_name,
            "ready": int(payload.get("messages_ready") or 0),
            "unacked": int(payload.get("messages_unacknowledged") or 0),
            "consumers": int(payload.get("consumers") or 0),
        }
    except Exception as exc:
        logger.debug("[QUEUE] [%s] management depth unavailable: %s", _ts(), exc)
        return None


async def get_queue_depth_summary(worker) -> Dict[str, Any]:
    channel = getattr(worker, "channel", None)
    if not channel or getattr(channel, "is_closed", False):
        return unavailable_queue_payload(worker, "rabbitmq channel unavailable")
    if not hasattr(channel, "declare_queue"):
        return unavailable_queue_payload(worker, "rabbitmq queue probe unavailable")
    try:
        normal, retry = await asyncio.gather(
            worker._queue_depth_for(worker.normal_queue_name),
            worker._queue_depth_for(worker.retry_queue_name),
        )
        return {"status": "available", "normal": normal, "retry": retry}
    except Exception as exc:
        logger.warning("[QUEUE] [%s] queue depth unavailable: %s", _ts(), exc)
        return unavailable_queue_payload(worker, str(exc))


def get_queue_runtime_status(worker) -> Dict[str, Any]:
    """Return local RabbitMQ consumer runtime state for health checks."""
    channel_open = bool(worker.channel and not getattr(worker.channel, "is_closed", False))
    consumer_tasks = list(getattr(worker, "_consumer_tasks", []) or [])
    running_consumers = sum(1 for task in consumer_tasks if not task.done())
    consuming = bool(getattr(worker, "_consuming", False))
    healthy = channel_open and (not consuming or running_consumers >= 2)
    healthy = healthy and not getattr(worker, "_last_consumer_error", None)
    return {
        "healthy": healthy, "consuming": consuming, "channel_open": channel_open,
        "consumer_task_count": len(consumer_tasks),
        "running_consumer_task_count": running_consumers,
        "inflight_task_count": len(getattr(worker, "_inflight_tasks", set()) or set()),
        "last_consumer_error": getattr(worker, "_last_consumer_error", None),
        "last_consumer_exit_at": getattr(worker, "_last_consumer_exit_at", None),
        "normal_queue": worker.normal_queue_name, "retry_queue": worker.retry_queue_name,
    }
