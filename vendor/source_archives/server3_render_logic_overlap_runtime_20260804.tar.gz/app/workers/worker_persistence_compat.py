"""Compatibility facade for uploads and render-job persistence."""

from typing import Optional

from app.services import job_repository
from app.workers.pipeline import upload as upload_handler
from app.workers.validation import code_validator


class WorkerPersistenceCompatMixin:
    async def _upload_results(
        self, job_id, user_id, video_data, code, aspect_ratio="16:9",
        render_canvas_profile_name=None, collector=None,
    ):
        return await upload_handler._upload_results(
            job_id, user_id, video_data, code, aspect_ratio,
            render_canvas_profile_name=render_canvas_profile_name,
            collector=collector,
        )

    async def _upload_video_variant(
        self, job_id, user_id, video_data, *, aspect_ratio="16:9",
        render_canvas_profile_name=None, variant, collector=None,
    ):
        return await upload_handler._upload_video_variant(
            job_id, user_id, video_data, aspect_ratio=aspect_ratio,
            render_canvas_profile_name=render_canvas_profile_name,
            variant=variant, collector=collector,
        )

    async def _rollback_uploaded_files(
        self, video_url, code_url, extra_video_urls=None, collector=None,
    ):
        return await upload_handler._rollback_uploaded_files(
            video_url, code_url, extra_video_urls=extra_video_urls,
            collector=collector,
        )

    async def _is_job_cancelled(self, job_id: str) -> bool:
        return await job_repository.is_job_cancelled(job_id)

    async def _get_job_status(self, job_id: str) -> Optional[str]:
        return await job_repository.get_job_status(job_id)

    async def _update_job_status(
        self, job_id: str, status: str, error_message: str = None,
        refund_points: int = 0, error_type: str = None,
        error_stage: str = None, retry_count: int = None,
        llm_fix_count: int = 0, render_fix_count: int = 0,
        total_tokens: int = 0, input_tokens: int = 0,
        output_tokens: int = 0, cache_read_tokens: int = 0,
        cache_creation_tokens: int = 0,
        failed_code_url: Optional[str] = None,
        pipeline_mode: Optional[str] = None,
        slice_count: Optional[int] = None,
    ) -> bool:
        return await job_repository.update_job_status(
            job_id, status, error_message, refund_points,
            error_type, error_stage, retry_count,
            llm_fix_count, render_fix_count,
            total_tokens, input_tokens, output_tokens,
            cache_read_tokens, cache_creation_tokens,
            failed_code_url=failed_code_url,
            pipeline_mode=pipeline_mode, slice_count=slice_count,
        )

    async def _update_database_success(
        self, job_id: str, user_id: str, video_url: str, code_url: str,
        cost: float, title: str = "", description: str = "",
        has_watermark: bool = False,
        aigc_clean_video_url: str | None = None,
        aigc_watermarked_video_url: str | None = None,
        aigc_display_variant: str | None = None,
        aigc_visible_watermark_applied: bool = False,
        aigc_metadata_injected: bool = False,
        pipeline_mode: str = None, slice_count: int = 0,
        llm_fix_count: int = 0, render_fix_count: int = 0,
        total_tokens: int = 0, input_tokens: int = 0,
        output_tokens: int = 0, cache_read_tokens: int = 0,
        cache_creation_tokens: int = 0, retry_count: int = 0,
        timeline_manifest: dict | None = None,
    ) -> bool:
        return await job_repository.update_database_success(
            job_id, user_id, video_url, code_url, cost,
            title, description, has_watermark,
            aigc_clean_video_url, aigc_watermarked_video_url,
            aigc_display_variant, aigc_visible_watermark_applied,
            aigc_metadata_injected, pipeline_mode, slice_count,
            llm_fix_count, render_fix_count,
            total_tokens, input_tokens, output_tokens,
            cache_read_tokens, cache_creation_tokens, retry_count,
            timeline_manifest=timeline_manifest,
        )

    async def _get_slice_duration(self, mp4_path: str) -> float:
        return await job_repository.get_slice_duration(mp4_path)

    def _extract_scene_standalone_code(self, full_code: str, scene_name: str) -> str:
        return code_validator.extract_scene_standalone_code(full_code, scene_name)

    async def _upload_and_register_slices(
        self, job_id: str, user_id: str, scene_names: list,
        slice_mp4_paths: list, full_code: str,
    ):
        return await job_repository.upload_and_register_slices(
            job_id, user_id, scene_names, slice_mp4_paths, full_code,
        )
