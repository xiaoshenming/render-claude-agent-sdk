"""Deterministic compiler from lesson DSL specs to Manim Python."""

from __future__ import annotations

import json
from textwrap import dedent, indent

from app.prompts.header_config import COLOR_VARS
from app.prompts.header_template import (
    HEADER_TEMPLATE,
    VOICE_HEADER_TEMPLATE,
    apply_render_canvas_config,
)

from .schema import LessonSpec, SceneSpec


def _py(value: str) -> str:
    return json.dumps(str(value or ""), ensure_ascii=False)


def _py_list(values: list[str]) -> str:
    return "[" + ", ".join(_py(value) for value in values) + "]"


def _project_header(
    *,
    color_scheme: int,
    enable_tts: bool,
    tts_voice: str,
    voice_type: str,
    cosyvoice_id: str,
) -> str:
    colors = COLOR_VARS.get(int(color_scheme or 1), COLOR_VARS[1])
    template = VOICE_HEADER_TEMPLATE if enable_tts else HEADER_TEMPLATE
    header = apply_render_canvas_config(
        template.replace("__COLOR__", colors),
        "16:9",
    )
    if enable_tts:
        voice_value = cosyvoice_id if voice_type == "clone" and cosyvoice_id else tts_voice
        header = header.replace("__VOICE__", str(voice_value or "longxiaoxia_v3"))
    return header.rstrip()


from .compiler_scene_part_a import _DSL_BASE_SCENE_PART as _DSL_BASE_SCENE_PART_A
from .compiler_scene_part_b import _DSL_BASE_SCENE_PART as _DSL_BASE_SCENE_PART_B


_DSL_BASE_SCENE = _DSL_BASE_SCENE_PART_A + _DSL_BASE_SCENE_PART_B


_VISUAL_METHOD_BY_KIND = {
    "right_triangle": "right_triangle_visual",
    "pythagorean_squares": "pythagorean_squares_visual",
    "fraction_bars": "fraction_bars_visual",
    "fraction_lcm": "fraction_bars_visual",
    "fraction_sum": "fraction_bars_visual",
    "congruence_cards": "congruence_cards_visual",
    "rotation_point": "rotation_point_visual",
    "sector_rearrange": "sector_rearrange_visual",
    "quadratic_shift": "quadratic_shift_visual",
    "triangle_transform": "triangle_transform_visual",
}


def _visual_expression(scene: SceneSpec) -> str:
    if scene.visual_kind == "formula_focus":
        return f"self.formula_focus_visual({_py_list(scene.formulas)}, {_py_list(scene.bullets)})"
    if scene.visual_kind == "summary":
        return f"self.summary_visual({_py_list(scene.formulas)}, {_py_list(scene.bullets)})"
    method = _VISUAL_METHOD_BY_KIND.get(scene.visual_kind, "summary_visual")
    if method == "summary_visual":
        return f"self.summary_visual({_py_list(scene.formulas)}, {_py_list(scene.bullets)})"
    return f"self.{method}()"


def _compile_scene(scene: SceneSpec) -> str:
    expression = _visual_expression(scene)
    title = _py(scene.title)
    narration = _py(scene.narration)
    formulas = _py_list(scene.formulas)
    bullets = _py_list(scene.bullets)
    body = f'''
class {scene.name}(DSLBaseScene):
    def construct(self):
        self.setup_layout()
        title = self.title_mob({title})
        visual = {expression}
        formulas = self.formula_panel({formulas})
        bullets = self.bullet_panel({bullets})
        side = VGroup(formulas, bullets).arrange(DOWN, buff=0.25, aligned_edge=LEFT)
        if side.width > 0 and visual.width > 0:
            content = VGroup(visual, side).arrange(RIGHT, buff=0.58)
        else:
            content = VGroup(visual, side).arrange(DOWN, buff=0.35)
        self.fit_to_canvas(content, area="bottom", max_width=11.3, max_height=4.8)
        self.run_timeline("{scene.visual_kind}", {narration}, title, visual, formulas, bullets)
        self.wait(0.25)
'''
    return dedent(body).strip()


def compile_lesson_to_manim(
    spec: LessonSpec,
    *,
    color_scheme: int = 1,
    enable_tts: bool = True,
    tts_voice: str = "longxiaoxia_v3",
    voice_type: str = "system",
    cosyvoice_id: str = "",
) -> str:
    """Compile a lesson spec into a full project-compatible Manim script."""
    header = _project_header(
        color_scheme=color_scheme,
        enable_tts=enable_tts,
        tts_voice=tts_voice,
        voice_type=voice_type,
        cosyvoice_id=cosyvoice_id,
    )
    scene_code = "\n\n\n".join(_compile_scene(scene) for scene in spec.scenes)
    spec_comment = "# DSL_SPEC " + json.dumps(spec.to_dict(), ensure_ascii=False, sort_keys=True)
    parts = [
        header,
        _DSL_BASE_SCENE.strip(),
        scene_code,
        spec_comment,
        "# END",
    ]
    return "\n\n\n".join(part.rstrip() for part in parts if part.strip()) + "\n"
