"""Generated DSL scene template fragment; keep byte-for-byte stable."""

_DSL_BASE_SCENE_PART = r'''            self._add_step(
                steps,
                Circumscribe(formulas, color=GlobalConfig.ACCENT_COLOR),
                Indicate(formulas, color=GlobalConfig.EMPHASIS_COLOR),
                run_time=0.7,
            )
        if bullets.width > 0:
            self._add_step(steps, FadeIn(bullets, shift=UP * 0.10), run_time=0.55)
        self.play_timeline(narration, steps)

    def formula_panel(self, formulas):
        mobs = [
            self.safe_math(str(item), font_size=34, color=GlobalConfig.FORMULA_COLOR, max_width=5.6)
            for item in list(formulas or [])
            if str(item or "").strip()
        ]
        if not mobs:
            return VGroup()
        panel = VGroup(*mobs).arrange(DOWN, buff=0.18, aligned_edge=LEFT)
        frame = RoundedRectangle(
            width=max(5.9, panel.width + 0.55),
            height=max(1.05, panel.height + 0.42),
            corner_radius=0.14,
            stroke_color=GlobalConfig.ACCENT_COLOR,
            stroke_opacity=0.55,
            fill_color=GlobalConfig.BG_COLOR,
            fill_opacity=0.78,
        )
        panel.move_to(frame.get_center())
        return VGroup(frame, panel)

    def bullet_panel(self, bullets, width=4.8):
        rows = [
            self.safe_text("• " + str(item), font_size=25, max_width=width, color=GlobalConfig.PRIMARY_TEXT)
            for item in list(bullets or [])[:4]
            if str(item or "").strip()
        ]
        if not rows:
            return VGroup()
        return VGroup(*rows).arrange(DOWN, buff=0.14, aligned_edge=LEFT)

    def title_mob(self, title):
        mob = self.make_title(str(title))
        mob.to_edge(UP, buff=0.33)
        return mob

    def make_title(self, text, area="top", font_size=40, color=None, **kwargs):
        return make_title(text, area=area, font_size=font_size, color=color, **kwargs)

    def _right_triangle_points(self):
        a = LEFT * 1.7 + DOWN * 1.0
        b = RIGHT * 1.6 + DOWN * 1.0
        c = LEFT * 1.7 + UP * 1.15
        return a, b, c

    def right_triangle_visual(self):
        a, b, c = self._right_triangle_points()
        triangle = Polygon(a, b, c, color=GlobalConfig.MAIN_COLOR, stroke_width=5)
        triangle.set_fill(GlobalConfig.MAIN_COLOR, opacity=0.08)
        right_mark = VGroup(
            Line(a + RIGHT * 0.32, a + RIGHT * 0.32 + UP * 0.32, color=GlobalConfig.EMPHASIS_COLOR, stroke_width=4),
            Line(a + RIGHT * 0.32 + UP * 0.32, a + UP * 0.32, color=GlobalConfig.EMPHASIS_COLOR, stroke_width=4),
        )
        labels = VGroup(
            self.safe_text("直角边 a", font_size=24, max_width=1.8).next_to(Line(a, b), DOWN, buff=0.14),
            self.safe_text("直角边 b", font_size=24, max_width=1.8).next_to(Line(a, c), LEFT, buff=0.14),
            self.safe_text("斜边 c", font_size=24, max_width=1.5).next_to(Line(b, c), UP + RIGHT, buff=0.05),
        )
        return VGroup(triangle, right_mark, labels)

    def square_on_segment(self, start, end, away_from, color, fill_opacity=0.10):
        start = np.array(start, dtype=float)
        end = np.array(end, dtype=float)
        away_from = np.array(away_from, dtype=float)
        segment = end - start
        side_length = float(np.linalg.norm(segment))
        if side_length <= 1e-6:
            return VGroup()
        normal = np.array([-segment[1], segment[0], 0.0]) / side_length
        midpoint = (start + end) / 2
        if np.linalg.norm(midpoint + normal * side_length - away_from) < np.linalg.norm(midpoint - normal * side_length - away_from):
            normal = -normal
        offset = normal * side_length
        square = Polygon(start, end, end + offset, start + offset, color=color, stroke_width=4)
        square.set_fill(color, opacity=fill_opacity)
        return square

    def pythagorean_squares_visual(self):
        a, b, c = self._right_triangle_points()
        visual = self.right_triangle_visual()
        square_a = self.square_on_segment(a, b, c, GlobalConfig.SECONDARY_COLOR)
        square_b = self.square_on_segment(c, a, b, GlobalConfig.ACCENT_COLOR)
        square_c = self.square_on_segment(b, c, a, GlobalConfig.SUCCESS)
        labels = VGroup(
            self.safe_math("a^2", font_size=28).move_to(square_a.get_center()),
            self.safe_math("b^2", font_size=28).move_to(square_b.get_center()),
            self.safe_math("c^2", font_size=28).move_to(square_c.get_center()),
        )
        return VGroup(visual, square_a, square_b, square_c, labels)

    def fraction_bars_visual(self):
        rows = VGroup()
        specs = [(2, 1, r"\frac{1}{2}"), (3, 1, r"\frac{1}{3}"), (6, 5, r"\frac{5}{6}")]
        for index, (parts, filled, label) in enumerate(specs):
            bar = Rectangle(width=4.2, height=0.42, color=GlobalConfig.MAIN_COLOR, stroke_width=3)
            cells = VGroup()
            for part in range(parts):
                cell = Rectangle(width=4.2 / parts, height=0.42, stroke_width=1.5, color=GlobalConfig.MAIN_COLOR)
                cell.set_fill(GlobalConfig.ACCENT_COLOR, opacity=0.35 if part < filled else 0.03)
                cell.move_to(bar.get_left() + RIGHT * (4.2 / parts) * (part + 0.5))
                cells.add(cell)
            row = VGroup(self.safe_math(label, font_size=30), VGroup(bar, cells)).arrange(RIGHT, buff=0.35)
            rows.add(row)
        rows.arrange(DOWN, buff=0.34, aligned_edge=LEFT)
        return rows

    def congruence_cards_visual(self):
        data = [("SSS", "三边"), ("SAS", "两边夹角"), ("ASA", "两角夹边"), ("AAS", "两角一边"), ("HL", "斜边直角边")]
        cards = VGroup()
        for code, meaning in data:
            label = VGroup(
                self.safe_math(code, font_size=32, color=GlobalConfig.FORMULA_COLOR),
                self.safe_text(meaning, font_size=22, max_width=1.55),
            ).arrange(DOWN, buff=0.08)
            frame = RoundedRectangle(width=1.82, height=1.08, corner_radius=0.12, color=GlobalConfig.MAIN_COLOR, stroke_width=3)
            frame.set_fill(GlobalConfig.BG_COLOR, opacity=0.82)
            label.move_to(frame.get_center())
            cards.add(VGroup(frame, label))
        cards.arrange_in_grid(rows=2, cols=3, buff=(0.28, 0.26))
        return cards

    def rotation_point_visual(self):
        axes = Axes(x_range=[-3, 3, 1], y_range=[-1, 4, 1], x_length=4.8, y_length=3.8, tips=False, axis_config={"color": GlobalConfig.GRID_COLOR})
        origin = axes.c2p(0, 0)
        p = axes.c2p(2, 1)
        q = axes.c2p(-1, 2)
        op = Line(origin, p, color=GlobalConfig.MAIN_COLOR, stroke_width=4)
        oq = Line(origin, q, color=GlobalConfig.SUCCESS, stroke_width=4)
        arc = Arc(radius=0.68, start_angle=op.get_angle(), angle=PI / 2, color=GlobalConfig.EMPHASIS_COLOR).move_arc_center_to(origin)
        labels = VGroup(
            Dot(p, color=GlobalConfig.MAIN_COLOR),
            Dot(q, color=GlobalConfig.SUCCESS),
            self.safe_math("P(x,y)", font_size=26).next_to(p, RIGHT, buff=0.08),
            self.safe_math("P'(-y,x)", font_size=26).next_to(q, LEFT, buff=0.08),
            self.safe_math("OP=OP'", font_size=30).next_to(axes, DOWN, buff=0.15),
        )
        return VGroup(axes, op, oq, arc, labels)

    def sector_rearrange_visual(self):
        wedges = VGroup()
        radius = 1.15
        sector_count = 8
        for index in range(sector_count):
            angle0 = index * TAU / sector_count
            angle1 = (index + 1) * TAU / sector_count
            p0 = np.array([radius * np.cos(angle0), radius * np.sin(angle0), 0.0])
            p1 = np.array([radius * np.cos(angle1), radius * np.sin(angle1), 0.0])
            wedge = Polygon(ORIGIN, p0, p1, color=GlobalConfig.MAIN_COLOR, stroke_width=2)
            wedge.set_fill(GlobalConfig.MAIN_COLOR if index % 2 == 0 else GlobalConfig.ACCENT_COLOR, opacity=0.18)
            wedges.add(wedge)
        circle_model = wedges.copy().scale(0.86).shift(LEFT * 2.2)
        rearranged = VGroup()
        spacing = 3.24 / max(sector_count - 1, 1)
        for index in range(sector_count):
            tri = Triangle(color=GlobalConfig.ACCENT_COLOR if index % 2 else GlobalConfig.MAIN_COLOR, stroke_width=2)
            tri.set_fill(tri.get_color(), opacity=0.18)
            tri.scale(0.28).rotate(PI if index % 2 else 0)
            tri.move_to(RIGHT * (index * spacing - 1.62) + (UP * 0.24 if index % 2 else DOWN * 0.24))
            rearranged.add(tri)
        rearranged.shift(RIGHT * 2.0)
        arrow = Arrow(circle_model.get_right() + RIGHT * 0.2, rearranged.get_left() + LEFT * 0.2, buff=0.1, color=GlobalConfig.EMPHASIS_COLOR)
        labels = VGroup(
            self.safe_text("圆被切成扇形", font_size=22, max_width=2.3).next_to(circle_model, DOWN, buff=0.14),
            self.safe_text("交错重排为近似长方形", font_size=22, max_width=2.8).next_to(rearranged, DOWN, buff=0.14),
        )
        return VGroup(circle_model, arrow, rearranged, labels)

    def quadratic_shift_visual(self):
        axes = Axes(x_range=[-1, 5, 1], y_range=[0, 6, 1], x_length=5.4, y_length=3.5, tips=False, axis_config={"color": GlobalConfig.GRID_COLOR})
        base = axes.plot(lambda x: x * x, x_range=[-1, 2.2], color=GlobalConfig.MUTED_COLOR)
        shifted = axes.plot(lambda x: (x - 2) ** 2 + 1, x_range=[-0.2, 4.2], color=GlobalConfig.MAIN_COLOR)
        vertex = Dot(axes.c2p(2, 1), color=GlobalConfig.EMPHASIS_COLOR)
        axis_line = DashedLine(axes.c2p(2, 0), axes.c2p(2, 5.2), color=GlobalConfig.EMPHASIS_COLOR)
        labels = VGroup(
            self.safe_math("y=x^2", font_size=24).next_to(base, LEFT, buff=0.08),
            self.safe_math("y=(x-2)^2+1", font_size=24).next_to(shifted, RIGHT, buff=0.08),
            self.safe_math("(2,1)", font_size=24).next_to(vertex, UP, buff=0.08),
            self.safe_math("x=2", font_size=24).next_to(axis_line, DOWN, buff=0.08),
        )
        return VGroup(axes, base, shifted, vertex, axis_line, labels)

    def triangle_transform_visual(self):
        a = LEFT * 2.4 + DOWN * 0.8
        b = LEFT * 1.1 + DOWN * 0.8
        c = LEFT * 2.0 + UP * 0.55
        shift = RIGHT * 1.55 + UP * 0.35
        tri1 = Polygon(a, b, c, color=GlobalConfig.MUTED_COLOR, stroke_width=4)
        tri2 = Polygon(a + shift, b + shift, c + shift, color=GlobalConfig.MAIN_COLOR, stroke_width=4)
        center = a + shift
        rot = PI / 3
        def rotate(point):
            vector = point - center
            matrix = np.array([[np.cos(rot), -np.sin(rot), 0.0], [np.sin(rot), np.cos(rot), 0.0], [0.0, 0.0, 1.0]])
            return center + matrix.dot(vector)
        tri3 = Polygon(rotate(a + shift), rotate(b + shift), rotate(c + shift), color=GlobalConfig.SUCCESS, stroke_width=4)
        arrows = VGroup(
            Arrow(tri1.get_right(), tri2.get_left(), buff=0.12, color=GlobalConfig.ACCENT_COLOR),
            CurvedArrow(tri2.get_top(), tri3.get_top(), color=GlobalConfig.EMPHASIS_COLOR, angle=TAU / 6),
        )
        labels = VGroup(
            self.safe_text("原图", font_size=22).next_to(tri1, DOWN, buff=0.10),
            self.safe_text("平移", font_size=22).next_to(tri2, DOWN, buff=0.10),
            self.safe_text("旋转后", font_size=22).next_to(tri3, UP, buff=0.10),
        )
        return VGroup(tri1, tri2, tri3, arrows, labels)

    def formula_focus_visual(self, formulas, bullets):
        formulas_mob = self.formula_panel(formulas)
        bullets_mob = self.bullet_panel(bullets)
        group = VGroup(bullets_mob, formulas_mob).arrange(RIGHT, buff=0.62)
        return group

    def summary_visual(self, formulas, bullets):
        formulas_mob = self.formula_panel(formulas)
        bullets_mob = self.bullet_panel(bullets, width=5.2)
        group = VGroup(formulas_mob, bullets_mob).arrange(DOWN, buff=0.34)
        return group
'''
