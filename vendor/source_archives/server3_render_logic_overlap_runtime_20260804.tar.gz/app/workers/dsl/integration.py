"""Agent-pipeline integration helpers for DSL-first generation."""

from __future__ import annotations

import ast
import os
from pathlib import Path
from typing import Any

from app.core.config import settings

from .compiler import compile_lesson_to_manim
from .planner import build_lesson_spec
from .schema import LessonSpec


_DYNAMIC_ACTIONS_BY_KIND = {
    "right_triangle": 4,
    "pythagorean_squares": 4,
    "fraction_bars": 3,
    "fraction_lcm": 3,
    "fraction_sum": 3,
    "congruence_cards": 3,
    "rotation_point": 6,
    "sector_rearrange": 5,
    "quadratic_shift": 6,
    "triangle_transform": 7,
    "formula_focus": 3,
    "summary": 3,
}

_DYNAMIC_TOKENS = (
    "Create(",
    "Write(",
    "TransformFromCopy(",
    "ReplacementTransform(",
    "MoveToTarget(",
    "Indicate(",
    "Circumscribe(",
    "GrowArrow(",
)


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "on", "enabled"}


def should_use_dsl_first(
    *,
    provider: str,
    aspect_ratio: str,
    task_data: dict[str, Any] | None,
    prompt: str,
) -> bool:
    """Return true when the safe deterministic DSL path should be attempted."""
    data = task_data if isinstance(task_data, dict) else {}
    enabled = (
        _truthy(os.getenv("MATHPI_DSL_FIRST"))
        or bool(getattr(settings, "MATHPI_DSL_FIRST", False))
    )
    if not enabled:
        return False
    if str(provider or "").strip() != "MathPi-2D":
        return False
    if str(aspect_ratio or "").strip() == "9:16":
        return False
    if _truthy(data.get("short_video")) or str(data.get("generation_mode") or "") == "short_video":
        return False
    return bool(str(prompt or "").strip())


def analyze_dynamic_gate(code: str, spec: LessonSpec) -> dict[str, Any]:
    """Return a deterministic quality gate summary for DSL timeline output."""
    failed_reasons: list[str] = []
    action_count_by_scene: dict[str, int] = {}
    code_text = str(code or "")

    if "def run_timeline(" not in code_text:
        failed_reasons.append("missing_run_timeline_helper")
    if "FadeIn(content)" in code_text:
        failed_reasons.append("static_content_fadein_detected")

    dynamic_token_count = sum(code_text.count(token) for token in _DYNAMIC_TOKENS)
    if dynamic_token_count < 18:
        failed_reasons.append(f"dynamic_token_count_too_low:{dynamic_token_count}")

    for scene in spec.scenes:
        count = _DYNAMIC_ACTIONS_BY_KIND.get(scene.visual_kind, 2)
        action_count_by_scene[scene.name] = count
        expected_call = f'self.run_timeline("{scene.visual_kind}",'
        if expected_call not in code_text:
            failed_reasons.append(f"{scene.name}:missing_timeline_call")
        if scene.visual_kind != "summary" and count < 3:
            failed_reasons.append(f"{scene.name}:insufficient_dynamic_actions:{count}")

    return {
        "passed": not failed_reasons,
        "scene_count": len(spec.scenes),
        "dynamic_token_count": dynamic_token_count,
        "action_count_by_scene": action_count_by_scene,
        "failed_reasons": failed_reasons,
    }


async def generate_dsl_artifacts(
    *,
    ctx: Any,
    provider: str,
    prompt: str,
    color_scheme: int,
    enable_tts: bool,
    tts_voice: str,
    voice_type: str,
    cosyvoice_id: str,
    tts_voice_snapshot: dict | None = None,
) -> dict[str, Any]:
    """Generate a full Manim script from DSL and write it to the job script path."""
    spec = build_lesson_spec(prompt, aspect_ratio=str(getattr(ctx, "aspect_ratio", "16:9") or "16:9"))
    code = compile_lesson_to_manim(
        spec,
        color_scheme=color_scheme,
        enable_tts=enable_tts,
        tts_voice=tts_voice,
        voice_type=voice_type,
        cosyvoice_id=cosyvoice_id,
    )
    if enable_tts:
        from app.workers.repair.tts_voice_contract import enforce_configured_tts_voice

        code, _ = enforce_configured_tts_voice(
            code,
            enable_tts=True,
            tts_voice=tts_voice,
            voice_type=voice_type,
            cosyvoice_id=cosyvoice_id,
            tts_voice_snapshot=tts_voice_snapshot,
        )
    ast.parse(code)
    dynamic_gate = analyze_dynamic_gate(code, spec)
    if not dynamic_gate["passed"]:
        raise ValueError(
            "DSL dynamic gate failed: " + "; ".join(dynamic_gate["failed_reasons"])
        )

    script_path = Path(ctx.manim_media_root) / f"job_{ctx.job_id}" / "script.py"
    script_path.parent.mkdir(parents=True, exist_ok=True)
    script_path.write_text(code, encoding="utf-8")

    stream_usage = {
        "provider_success": True,
        "semantic_acceptance_success": True,
        "quality_result": "dsl_first_generated",
        "dsl_first": True,
        "dsl_spec": spec.to_dict(),
        "dsl_scene_count": len(spec.scenes),
        "dsl_provider": provider,
        "dsl_dynamic_gate": dynamic_gate,
    }
    task_data = getattr(ctx, "task_data", None)
    if isinstance(task_data, dict):
        task_data["_dsl_first_used"] = True
        task_data["_dsl_spec"] = spec.to_dict()
        task_data["_dsl_dynamic_gate"] = dynamic_gate

    return {
        "code": code,
        "slice_paths": [],
        "cost_initial": 0.0,
        "scene_names": [scene.name for scene in spec.scenes],
        "script_path": str(script_path),
        "stream_usage": stream_usage,
        "pre_render_fixes": ["DSL-first deterministic generation"],
        "generation_mode": "dsl_first",
    }
