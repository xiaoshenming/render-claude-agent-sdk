"""Typed data model for the deterministic teaching-video DSL."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class SceneSpec:
    name: str
    title: str
    purpose: str
    narration: str
    visual_kind: str
    formulas: list[str] = field(default_factory=list)
    bullets: list[str] = field(default_factory=list)
    visual_params: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "title": self.title,
            "purpose": self.purpose,
            "narration": self.narration,
            "visual_kind": self.visual_kind,
            "formulas": list(self.formulas),
            "bullets": list(self.bullets),
            "visual_params": dict(self.visual_params),
        }


@dataclass(frozen=True)
class LessonSpec:
    prompt: str
    title: str
    aspect_ratio: str = "16:9"
    theme: str = "light_fresh"
    formulas: list[str] = field(default_factory=list)
    obligations: list[str] = field(default_factory=list)
    scenes: list[SceneSpec] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "mathpi.lesson_dsl.v1",
            "prompt": self.prompt,
            "title": self.title,
            "aspect_ratio": self.aspect_ratio,
            "theme": self.theme,
            "formulas": list(self.formulas),
            "obligations": list(self.obligations),
            "scenes": [scene.to_dict() for scene in self.scenes],
            "tags": list(self.tags),
        }
