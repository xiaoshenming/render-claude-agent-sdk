"""Heuristic planner that maps common math prompts into lesson DSL specs."""

from __future__ import annotations

import re

from .schema import LessonSpec, SceneSpec


def _contains(text: str, *needles: str) -> bool:
    lowered = text.lower()
    return any(needle.lower() in lowered for needle in needles)


def _formula_from_prompt(prompt: str) -> str:
    candidates = [
        r"a^2+b^2=c^2",
        r"\frac{1}{2}+\frac{1}{3}=\frac{5}{6}",
        r"S=\pi r^2",
        r"y=(x-2)^2+1",
        r"3^2+4^2=5^2",
        r"P'(-y,x)",
        r"60^\circ",
        r"SSS",
    ]
    normalized = prompt.replace(" ", "")
    for candidate in candidates:
        if candidate.replace(" ", "") in normalized:
            return candidate
    match = re.search(
        r"([A-Za-z0-9\\{}_^+\-=()'πpi\s/]+=[A-Za-z0-9\\{}_^+\-=()'πpi\s/]+)",
        prompt,
    )
    if match:
        value = match.group(1).strip()
        return value.replace("π", r"\pi")
    return r"\text{关键关系}"


def _scene(
    index: int,
    key: str,
    title: str,
    purpose: str,
    narration: str,
    visual_kind: str,
    formulas: list[str] | None = None,
    bullets: list[str] | None = None,
) -> SceneSpec:
    return SceneSpec(
        name=f"Scene_{index:02d}_{key}",
        title=title,
        purpose=purpose,
        narration=narration,
        visual_kind=visual_kind,
        formulas=formulas or [],
        bullets=bullets or [],
    )


def _base_spec(
    *,
    prompt: str,
    title: str,
    formula: str,
    obligations: list[str],
    scenes: list[SceneSpec],
    aspect_ratio: str,
    tags: list[str],
) -> LessonSpec:
    return LessonSpec(
        prompt=prompt,
        title=title,
        aspect_ratio=aspect_ratio or "16:9",
        formulas=[formula],
        obligations=obligations,
        scenes=scenes,
        tags=tags,
    )


def build_lesson_spec(prompt: str, *, aspect_ratio: str = "16:9") -> LessonSpec:
    """Build a conservative DSL plan from the user prompt.

    The planner intentionally covers common geometry/algebra teaching shapes
    first. Unknown prompts still get a safe theorem-explanation template instead
    of free-form helper invention.
    """
    text = str(prompt or "").strip()
    formula = _formula_from_prompt(text)

    if _contains(text, "勾股", "3-4-5", "直角三角形"):
        is_numeric = "3-4-5" in text or "3^2" in text
        formula = "3^2+4^2=5^2" if is_numeric else "a^2+b^2=c^2"
        title = "3-4-5 直角三角形验证" if is_numeric else "勾股定理的面积意义"
        obligations = [
            "画出直角三角形并明确标注直角边、斜边和直角角标",
            "用三个正方形表示三边平方面积",
            "把面积关系写成清晰 MathTex 公式",
        ]
        scenes = [
            _scene(
                1,
                "Intro",
                title,
                "建立直角三角形模型",
                "先看一个直角三角形，直角边围成两个小正方形，斜边围成一个大正方形。",
                "right_triangle",
                [formula],
                ["直角三角形", "直角边", "斜边"],
            ),
            _scene(
                2,
                "Squares",
                "三边外接正方形",
                "展示面积对象",
                "把三条边分别看作正方形边长，面积分别对应边长的平方。",
                "pythagorean_squares",
                [formula],
                ["正方形", "面积"],
            ),
            _scene(
                3,
                "AreaRelation",
                "面积相加",
                "说明面积关系",
                "两个直角边正方形的面积相加，正好等于斜边正方形的面积。",
                "formula_focus",
                [formula],
                ["面积", "相加", "相等"],
            ),
            _scene(
                4,
                "Summary",
                "结论",
                "总结公式含义",
                "所以直角三角形中，两直角边平方和等于斜边平方。",
                "summary",
                [formula],
                ["直角边", "斜边", "面积关系"],
            ),
        ]
        return _base_spec(
            prompt=text,
            title=title,
            formula=formula,
            obligations=obligations,
            scenes=scenes,
            aspect_ratio=aspect_ratio,
            tags=["right_triangle", "pythagorean"],
        )

    if _contains(text, "通分", "frac", "分数"):
        formula = r"\frac{1}{2}+\frac{1}{3}=\frac{5}{6}"
        scenes = [
            _scene(1, "Intro", "分数相加要先通分", "展示原式", "分母不同的分数不能直接加分子，要先找到共同分母。", "fraction_bars", [formula], ["通分", "分母"]),
            _scene(2, "LCM", "共同分母是 6", "找到最小公倍数", "二和三的最小公倍数是六，所以两个分数都改写成六等份。", "fraction_lcm", [r"\frac{1}{2}=\frac{3}{6}", r"\frac{1}{3}=\frac{2}{6}"], ["分母", "六等份"]),
            _scene(3, "Add", "合并同分母分数", "完成加法", "三份加两份，一共是五份，分母仍然是六。", "fraction_sum", [r"\frac{3}{6}+\frac{2}{6}=\frac{5}{6}"], ["通分", "相加"]),
            _scene(4, "Summary", "结论", "总结通分法", "异分母分数相加，先通分，再把分子相加。", "summary", [formula], ["通分", "MathTex"]),
        ]
        return _base_spec(prompt=text, title="分数通分动画", formula=formula, obligations=["中文说明和 MathTex 公式分开显示", "用等分条解释共同分母"], scenes=scenes, aspect_ratio=aspect_ratio, tags=["fraction"])

    if _contains(text, "全等", "SSS", "SAS", "ASA", "AAS", "HL"):
        formula = "SSS"
        scenes = [
            _scene(1, "Intro", "三角形全等判定", "建立分类视图", "全等判定要看对应边和对应角的信息是否足够。", "congruence_cards", [formula], ["SSS", "SAS", "ASA", "AAS", "HL"]),
            _scene(2, "SidesAngles", "边角条件", "解释常用判定", "SSS 看三边，SAS 看两边及夹角，ASA 和 AAS 看角边组合。", "congruence_cards", [r"\triangle ABC \cong \triangle DEF"], ["SAS", "ASA", "AAS"]),
            _scene(3, "RightTriangle", "直角三角形 HL", "补充直角情形", "HL 只适用于直角三角形，需要斜边和一条直角边对应相等。", "congruence_cards", [r"HL"], ["直角三角形", "斜边", "直角边"]),
            _scene(4, "Summary", "同屏分区总结", "避免卡片重叠", "五种判定分区摆放，先确认对应关系，再使用判定。", "congruence_cards", [formula], ["SSS", "SAS", "ASA", "AAS", "HL"]),
        ]
        return _base_spec(prompt=text, title="三角形全等判定对比", formula=formula, obligations=["五个卡片必须分区布局", "每个判定写清边角条件"], scenes=scenes, aspect_ratio=aspect_ratio, tags=["congruence"])

    if _contains(text, "旋转 90", "旋转90", "P(x,y)", "P'"):
        formula = "P'(-y,x)"
        scenes = [
            _scene(1, "Intro", "坐标旋转 90 度", "展示点和坐标轴", "点 P 绕原点逆时针旋转九十度，横纵坐标会交换并改变一个符号。", "rotation_point", [formula], ["旋转", "坐标"]),
            _scene(2, "Matrix", "坐标变换", "写出变换公式", "逆时针九十度旋转把横坐标变成新的纵坐标，把纵坐标取相反数作为新的横坐标。", "formula_focus", [r"(x,y)\mapsto(-y,x)", formula], ["旋转", "公式"]),
            _scene(3, "Distance", "长度保持", "证明 OP 等于 OP'", "旋转不会改变到中心的距离，所以 OP 与 OP' 相等。", "rotation_point", [r"OP=OP'"], ["OP=OP'", "长度保持"]),
            _scene(4, "Summary", "结论", "总结旋转规律", "记住逆时针九十度：先交换坐标，再给新的横坐标加负号。", "summary", [formula], ["旋转", "OP=OP'"]),
        ]
        return _base_spec(prompt=text, title="点绕原点旋转 90 度", formula=formula, obligations=["写出 P'(-y,x)", "证明 OP=OP'"], scenes=scenes, aspect_ratio=aspect_ratio, tags=["rotation"])

    if _contains(text, "扇形", "圆面积", "pi r^2", "πr"):
        formula = r"S=\pi r^2"
        scenes = [
            _scene(1, "Intro", "扇形重排推导圆面积", "展示圆被分成扇形", "把圆平均分成许多小扇形，每个扇形都保留半径和一段弧长。", "sector_rearrange", [formula], ["扇形", "弧长"]),
            _scene(2, "Rearrange", "交错重排", "解释近似长方形", "把扇形一上一下交错排列，边界会逐渐接近一个长方形。", "sector_rearrange", [r"\text{底边}\approx \pi r"], ["近似长方形", "弧长"]),
            _scene(3, "Area", "长方形面积", "得到面积公式", "近似长方形的底边趋近于圆周长的一半，高就是半径。", "formula_focus", [r"S\approx \pi r \times r", formula], ["底边", "半径", "面积"]),
            _scene(4, "Summary", "结论", "总结极限思想", "扇形越分越细，近似越准确，圆面积就是 π 乘半径平方。", "summary", [formula], ["扇形", "近似长方形", "弧长"]),
        ]
        return _base_spec(prompt=text, title="圆面积公式推导", formula=formula, obligations=["扇形重排成近似长方形", "说明底边来自半圆周长"], scenes=scenes, aspect_ratio=aspect_ratio, tags=["circle_area"])

    if _contains(text, "二次函数", "y=x^2", "(x-2)^2"):
        formula = r"y=(x-2)^2+1"
        scenes = [
            _scene(1, "Intro", "二次函数平移", "展示母函数", "从最基本的 y 等于 x 平方开始观察图像。", "quadratic_shift", [r"y=x^2"], ["二次函数", "母函数"]),
            _scene(2, "Shift", "向右 2 向上 1", "解释平移", "括号里的 x 减二表示向右平移二，外面的加一表示向上平移一。", "quadratic_shift", [formula], ["平移", "顶点"]),
            _scene(3, "Vertex", "顶点和对称轴", "标注关键元素", "新图像的顶点是二一，对称轴是 x 等于二。", "quadratic_shift", [r"\text{顶点 }(2,1)", r"x=2"], ["顶点", "对称轴"]),
            _scene(4, "Summary", "结论", "总结平移规律", "二次函数顶点式直接读出左右和上下平移。", "summary", [formula], ["平移", "顶点", "对称轴"]),
        ]
        return _base_spec(prompt=text, title="二次函数图像平移", formula=formula, obligations=["展示顶点", "展示对称轴", "展示图像变换"], scenes=scenes, aspect_ratio=aspect_ratio, tags=["quadratic"])

    if _contains(text, "向量", "平移", "60"):
        formula = r"60^\circ"
        scenes = [
            _scene(
                1,
                "Intro",
                "三角形平移再旋转",
                "展示原三角形、向量和像点目标",
                "先观察三角形 ABC、平移向量 v，以及后续要跟踪的 A、B、C 三个像点。",
                "triangle_transform",
                [r"A\to A'", r"B\to B'", r"C\to C'"],
                ["原图：三角形 ABC", "平移向量 v", "像点 A'、B'、C'"],
            ),
            _scene(2, "Translate", "沿向量平移", "得到 A'B'C'", "平移时每个点都沿同一个向量移动，所以边长不变，对应边平行。", "triangle_transform", [r"\vec v"], ["平移", "像点"]),
            _scene(3, "Rotate", "绕 A' 旋转 60 度", "继续得到最终像", "再以 A' 为中心旋转六十度，旋转同样保持所有边长。", "triangle_transform", [formula], ["旋转", "边长不变"]),
            _scene(4, "Summary", "结论", "证明边长保持", "平移和旋转都是刚体变换，连续作用后边长仍然不变。", "summary", [r"A'B'=AB", r"B'C'=BC"], ["边长不变", "像点"]),
        ]
        return _base_spec(prompt=text, title="平移与旋转的复合变换", formula=formula, obligations=["追踪 A、B、C 的像点", "证明边长不变"], scenes=scenes, aspect_ratio=aspect_ratio, tags=["transform"])

    scenes = [
        _scene(1, "Intro", "问题建模", "提取条件", "先把题目中的已知条件和目标分开。", "summary", [formula], ["条件", "目标"]),
        _scene(2, "Visual", "图形表示", "建立图像", "把关键对象放到画面中心，文字说明放在两侧安全区域。", "summary", [formula], ["图形", "公式"]),
        _scene(3, "Reasoning", "推理过程", "逐步说明", "每一步只展示一个核心关系，避免公式和中文混在一起。", "formula_focus", [formula], ["推理", "关系"]),
        _scene(4, "Summary", "结论", "总结答案", "最后回到题目目标，给出清晰结论。", "summary", [formula], ["结论", "MathTex"]),
    ]
    return _base_spec(
        prompt=text,
        title="数学问题讲解",
        formula=formula,
        obligations=["公式必须用 MathTex 显示", "画面采用左右分区避免重叠"],
        scenes=scenes,
        aspect_ratio=aspect_ratio,
        tags=["generic"],
    )
