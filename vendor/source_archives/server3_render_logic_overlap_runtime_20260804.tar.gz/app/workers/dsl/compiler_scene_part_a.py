"""Generated DSL scene template fragment; keep byte-for-byte stable."""

_DSL_BASE_SCENE_PART = r'''

def make_title(text, area="top", font_size=40, color=None, max_width=11.6, **_kwargs):
    title = Text(str(text), font_size=font_size, color=color or GlobalConfig.TITLE_COLOR)
    if max_width and title.width > float(max_width):
        title.scale(float(max_width) / max(title.width, 1e-6))
    return title


class DSLBaseScene(BaseConfigScene):
    """Deterministic scene helpers emitted by the DSL compiler."""

    def show_step(self, narration, *animations, run_time=0.85):
        text = str(narration or "").strip()
        if hasattr(self, "voiceover") and text:
            with self.voiceover(text=text):
                if animations:
                    self.play(*animations, run_time=run_time)
                else:
                    self.wait(max(0.4, run_time))
        else:
            if animations:
                self.play(*animations, run_time=run_time)
            else:
                self.wait(max(0.4, run_time))

    def play_timeline(self, narration, steps):
        text = str(narration or "").strip()

        def _run_steps():
            for animations, run_time in steps:
                flattened = self._flatten_animations(animations or [])
                if flattened:
                    self.play(*flattened, run_time=run_time)

        if hasattr(self, "voiceover") and text:
            with self.voiceover(text=text):
                _run_steps()
        else:
            _run_steps()

    def _children(self, group):
        try:
            return [group[index] for index in range(len(group))]
        except Exception:
            return []

    def _add_step(self, steps, *animations, run_time=0.75):
        valid = []
        for animation in animations:
            if animation is None:
                continue
            if isinstance(animation, (list, tuple)):
                valid.extend(self._flatten_animations(animation))
            else:
                valid.append(animation)
        if valid:
            steps.append((valid, run_time))

    def _flatten_animations(self, animations):
        flattened = []
        for animation in animations:
            if animation is None:
                continue
            if isinstance(animation, (list, tuple)):
                flattened.extend(self._flatten_animations(animation))
            else:
                flattened.append(animation)
        return flattened

    def _lagged(self, animations, lag_ratio=0.16):
        items = [animation for animation in animations if animation is not None]
        if not items:
            return None
        if len(items) == 1:
            return items[0]
        return LaggedStart(*items, lag_ratio=lag_ratio)

    def _generic_visual_steps(self, visual):
        children = self._children(visual)
        if children:
            return [([self._lagged([Create(item) for item in children])], 0.9)]
        return [([Create(visual)], 0.9)]

    def _right_triangle_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 3:
            return [
                ([Create(children[0])], 0.9),
                ([Create(children[1])], 0.45),
                ([Write(children[2])], 0.55),
                ([Circumscribe(children[1], color=GlobalConfig.EMPHASIS_COLOR)], 0.55),
            ]
        return self._generic_visual_steps(visual)

    def _pythagorean_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 5:
            squares = children[1:4]
            return [
                ([Create(children[0])], 0.9),
                ([self._lagged([GrowFromCenter(square) for square in squares])], 0.9),
                ([Write(children[4])], 0.65),
                ([self._lagged([Circumscribe(square, color=GlobalConfig.ACCENT_COLOR) for square in squares])], 0.8),
            ]
        return self._generic_visual_steps(visual)

    def _fraction_steps(self, visual):
        rows = self._children(visual)
        if rows:
            bars = []
            labels = []
            for row in rows:
                row_children = self._children(row)
                if row_children:
                    labels.append(row_children[0])
                if len(row_children) > 1:
                    bars.append(row_children[1])
            return [
                ([self._lagged([Create(bar) for bar in bars])], 0.95),
                ([self._lagged([Write(label) for label in labels])], 0.75),
                ([self._lagged([Indicate(row, color=GlobalConfig.ACCENT_COLOR) for row in rows])], 0.85),
            ]
        return self._generic_visual_steps(visual)

    def _congruence_steps(self, visual):
        cards = self._children(visual)
        if cards:
            return [
                ([self._lagged([FadeIn(card, shift=UP * 0.16) for card in cards])], 1.0),
                ([self._lagged([Circumscribe(card, color=GlobalConfig.ACCENT_COLOR) for card in cards])], 0.9),
                ([Indicate(cards[0], color=GlobalConfig.EMPHASIS_COLOR)], 0.55),
            ]
        return self._generic_visual_steps(visual)

    def _rotation_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 5:
            return [
                ([Create(children[0])], 0.7),
                ([Create(children[1])], 0.65),
                ([Create(children[3])], 0.55),
                ([TransformFromCopy(children[1], children[2])], 0.85),
                ([Write(children[4])], 0.7),
                ([Circumscribe(children[4], color=GlobalConfig.ACCENT_COLOR)], 0.55),
            ]
        return self._generic_visual_steps(visual)

    def _sector_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 4:
            return [
                ([Create(children[0])], 0.85),
                ([GrowArrow(children[1])], 0.45),
                ([TransformFromCopy(children[0], children[2])], 1.05),
                ([Write(children[3])], 0.6),
                ([Circumscribe(children[2], color=GlobalConfig.ACCENT_COLOR)], 0.7),
            ]
        return self._generic_visual_steps(visual)

    def _quadratic_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 6:
            return [
                ([Create(children[0])], 0.7),
                ([Create(children[1])], 0.75),
                ([TransformFromCopy(children[1], children[2])], 0.95),
                ([GrowFromCenter(children[3]), Create(children[4])], 0.75),
                ([Write(children[5])], 0.75),
                ([Circumscribe(children[3], color=GlobalConfig.EMPHASIS_COLOR)], 0.55),
            ]
        return self._generic_visual_steps(visual)

    def _triangle_transform_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 5:
            arrows = self._children(children[3])
            translation_arrow = arrows[0] if arrows else None
            rotation_arrow = arrows[1] if len(arrows) > 1 else None
            return [
                ([Create(children[0])], 0.7),
                ([TransformFromCopy(children[0], children[1])], 0.85),
                ([GrowArrow(translation_arrow)] if translation_arrow is not None else [], 0.45),
                ([TransformFromCopy(children[1], children[2])], 0.9),
                ([Create(rotation_arrow)] if rotation_arrow is not None else [], 0.45),
                ([Write(children[4])], 0.65),
                ([Circumscribe(children[2], color=GlobalConfig.ACCENT_COLOR)], 0.65),
            ]
        return self._generic_visual_steps(visual)

    def _formula_focus_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 2:
            return [
                ([Write(children[0])], 0.65),
                ([Write(children[1])], 0.75),
                ([Circumscribe(children[1], color=GlobalConfig.ACCENT_COLOR)], 0.6),
            ]
        return self._generic_visual_steps(visual)

    def _summary_steps(self, visual):
        children = self._children(visual)
        if len(children) >= 2:
            return [
                ([Write(children[0])], 0.75),
                ([FadeIn(children[1], shift=UP * 0.12)], 0.65),
                ([Circumscribe(children[0], color=GlobalConfig.ACCENT_COLOR)], 0.55),
            ]
        return self._generic_visual_steps(visual)

    def run_timeline(self, visual_kind, narration, title, visual, formulas, bullets):
        steps = []
        self._add_step(steps, Write(title), run_time=0.6)
        branch = {
            "right_triangle": self._right_triangle_steps,
            "pythagorean_squares": self._pythagorean_steps,
            "fraction_bars": self._fraction_steps,
            "fraction_lcm": self._fraction_steps,
            "fraction_sum": self._fraction_steps,
            "congruence_cards": self._congruence_steps,
            "rotation_point": self._rotation_steps,
            "sector_rearrange": self._sector_steps,
            "quadratic_shift": self._quadratic_steps,
            "triangle_transform": self._triangle_transform_steps,
            "formula_focus": self._formula_focus_steps,
            "summary": self._summary_steps,
        }.get(str(visual_kind), self._generic_visual_steps)
        for animations, run_time in branch(visual):
            self._add_step(steps, *animations, run_time=run_time)
        if formulas.width > 0:
            self._add_step(steps, Write(formulas), run_time=0.65)
'''
