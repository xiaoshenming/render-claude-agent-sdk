"""DSL-first generation package for deterministic 2D teaching videos."""

from .compiler import compile_lesson_to_manim
from .integration import generate_dsl_artifacts, should_use_dsl_first
from .planner import build_lesson_spec
from .schema import LessonSpec, SceneSpec

__all__ = [
    "LessonSpec",
    "SceneSpec",
    "build_lesson_spec",
    "compile_lesson_to_manim",
    "generate_dsl_artifacts",
    "should_use_dsl_first",
]
