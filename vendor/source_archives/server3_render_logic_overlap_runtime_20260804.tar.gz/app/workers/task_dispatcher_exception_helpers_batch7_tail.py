from pathlib import Path
import importlib.util
_p=Path(__file__).with_name('task_dispatcher.py'); _s=importlib.util.spec_from_file_location('_td_orig7t',_p); _m=importlib.util.module_from_spec(_s); _s.loader.exec_module(_m); globals().update({k:v for k,v in vars(_m).items() if not k.startswith('__')})

class TaskExceptionHelper:
    async def handle_task_failure(
        ctx: DispatchContext, message, task_data: Dict[str, Any],
        job_id: str, retry_count: int, queue_type: str,
        update_job_status_fn: Optional[Callable[..., Awaitable]] = None,
    ):
        """处理任务返回失败的重试/最终失败逻辑"""
        from app.services.error_collector import classify_render_error

        last_error = task_data.get("last_error", "unknown")
        task_type = task_data.get("task_type", "normal")
        error_stage = task_data.get("_error_stage", "unknown")

        if await ack_terminal_redelivery_if_needed(
            message,
            task_data,
            queue_type=queue_type,
            job_id=job_id,
            retry_count=_safe_int(retry_count),
        ):
            return

        logger.warning(
            f"[QUEUE] [{_ts()}] [{queue_type}] ✗ 任务失败: "
            f"job_id={job_id}, retry={retry_count}, "
            f"task_type={task_type}, stage={error_stage}, "
            f"错误={last_error[:200] if last_error else 'N/A'}")

        non_retryable = bool(task_data.get("_non_retryable"))

        if non_retryable:
            final_error_msg = task_data.get("last_error", "Non-retryable failure")
            final_error_type = task_data.get("_error_type", "non_retryable")
            final_error_stage = task_data.get("_error_stage", "unknown")
            ok = await handle_final_failure(
                ctx, job_id,
                final_error_msg,
                refund_points=task_data.get("refund_points", 0),
                error_type=final_error_type,
                error_stage=final_error_stage,
                retry_count=retry_count, task_data=task_data,
                update_job_status_fn=update_job_status_fn,
            )
            if _final_failure_ackable(ok):
                _clear_final_failure_persist_guard(
                    task_data,
                    job_id=job_id,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    error_msg=final_error_msg,
                )
                await ack_with_queue_evidence(
                    message,
                    task_data,
                    stage="QUEUE_ACK",
                    detail="Non-retryable final failure persisted and acked",
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                )
            else:
                await handle_final_failure_persist_failed(
                    message,
                    task_data,
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                    error_msg=final_error_msg,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    nack_detail=(
                        "Final failure persist failed, message nacked for requeue"
                    ),
                )
            logger.error(
                f"[QUEUE] [{_ts()}] [{queue_type}] "
                f"任务已标记不可重试: job_id={job_id}")

        elif retry_count < ctx.max_retries:
            task_data["retry_count"] = retry_count + 1
            task_data["_retry_processing_takeover_allowed"] = True
            try:
                await publish_to_retry_queue(ctx, task_data)
                await ack_with_queue_evidence(
                    message,
                    task_data,
                    stage="QUEUE_ACK_RETRY_PUBLISHED",
                    detail="Retry message published and original acked",
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                )
                logger.info(
                    f"[QUEUE] [{_ts()}] [{queue_type}] "
                    f"任务已重新入队: job_id={job_id} "
                    f"(第{task_data['retry_count']}次重试)")
            except Exception as pub_err:
                logger.exception(
                    f"[QUEUE] [{_ts()}] [{queue_type}] "
                    f"发布重试队列失败，保留原始失败并等待重投: "
                    f"job_id={job_id}, err={pub_err}")
                await defer_retry_publish_failure(
                    ctx,
                    message,
                    task_data,
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                    pub_err=pub_err,
                    detail_prefix="Retry publish failed during task failure handling",
                )
        else:
            final_error_msg = task_data.get("last_error", "Max retries exceeded")
            final_error_type = task_data.get("_error_type", "max_retries")
            final_error_stage = task_data.get("_error_stage", "unknown")
            ok = await handle_final_failure(
                ctx, job_id,
                final_error_msg,
                refund_points=task_data.get("refund_points", 0),
                error_type=final_error_type,
                error_stage=final_error_stage,
                retry_count=retry_count, task_data=task_data,
                update_job_status_fn=update_job_status_fn,
            )
            if _final_failure_ackable(ok):
                _clear_final_failure_persist_guard(
                    task_data,
                    job_id=job_id,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    error_msg=final_error_msg,
                )
                await ack_with_queue_evidence(
                    message,
                    task_data,
                    stage="QUEUE_ACK",
                    detail="Max retries final failure persisted and acked",
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                )
            else:
                await handle_final_failure_persist_failed(
                    message,
                    task_data,
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                    error_msg=final_error_msg,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    nack_detail=(
                        "Max retries final failure persist failed, message nacked"
                    ),
                )
            logger.error(
                f"[QUEUE] [{_ts()}] [{queue_type}] "
                f"任务达到最大重试次数已移除: job_id={job_id}")
