"""Rebuild retry payloads for stale active-job markers."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any, Dict

STALE_ACTIVE_JOB_MARKER_CLEANUP_ONLY = "_stale_active_job_marker_cleanup_only"

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


class ActiveJobRecoveryLoaderMixin:
    async def _load_recoverable_active_job_task_data(
        self,
        job_id: str,
        marker: Dict[str, Any],
    ) -> Dict[str, Any] | None:
        """Rebuild the minimal render task payload for a dead active marker."""
        try:
            from sqlalchemy import text
            from app.database.database import AsyncSessionLocal, DATABASE_URL, engine

            session = AsyncSessionLocal()
            try:
                row = (await session.execute(text("""
                    SELECT
                        id, user_id, prompt, ai_model, status, tts_enabled, tts_voice,
                        voice_type, aspect_ratio, pipeline_mode, task_type,
                        generation_mode, credits_charged, retry_count,
                        tts_voice_snapshot
                    FROM video_generation_jobs
                    WHERE id = :job_id
                    LIMIT 1
                """), {"job_id": job_id})).mappings().first()
            finally:
                await session.close()
                if str(DATABASE_URL).startswith("sqlite"):
                    await engine.dispose()
        except Exception:
            logger.exception(
                "[QUEUE] [%s] stale active marker DB lookup failed: job_id=%s",
                _ts(),
                job_id,
            )
            return None

        if not row:
            logger.warning(
                "[QUEUE] [%s] stale active marker has no matching DB job: job_id=%s",
                _ts(),
                job_id,
            )
            return {
                STALE_ACTIVE_JOB_MARKER_CLEANUP_ONLY: True,
                "job_id": job_id,
                "reason": "missing_db_job",
            }

        status = str(row.get("status") or "")
        if status and status not in {"PENDING", "PROCESSING"}:
            logger.info(
                "[QUEUE] [%s] stale active marker points to terminal job; skip recovery: "
                "job_id=%s status=%s",
                _ts(),
                job_id,
                status,
            )
            return {
                STALE_ACTIVE_JOB_MARKER_CLEANUP_ONLY: True,
                "job_id": job_id,
                "reason": f"terminal_status:{status}",
            }

        required = ("id", "user_id", "prompt", "ai_model")
        missing = [field for field in required if not row.get(field)]
        if missing:
            logger.warning(
                "[QUEUE] [%s] stale active marker cannot rebuild payload: "
                "job_id=%s missing=%s",
                _ts(),
                job_id,
                missing,
            )
            return {
                STALE_ACTIVE_JOB_MARKER_CLEANUP_ONLY: True,
                "job_id": job_id,
                "reason": f"missing_required:{','.join(missing)}",
            }

        def _safe_int(value: Any, default: int = 0) -> int:
            try:
                return int(value or default)
            except (TypeError, ValueError):
                return default

        db_retry_count = _safe_int(row.get("retry_count"), 0)
        marker_retry_count = _safe_int(marker.get("retry_count"), 0)
        retry_count = max(db_retry_count, marker_retry_count) + 1

        voice_snapshot = row.get("tts_voice_snapshot")
        if isinstance(voice_snapshot, str) and voice_snapshot:
            try:
                voice_snapshot = json.loads(voice_snapshot)
            except json.JSONDecodeError:
                pass

        task_data: Dict[str, Any] = {
            "job_id": str(row["id"]),
            "user_id": str(row["user_id"]),
            "prompt": str(row["prompt"]),
            "ai_model": str(row["ai_model"]),
            "enable_tts": bool(row.get("tts_enabled")),
            "tts_voice": row.get("tts_voice") or "longxiaoxia_v3",
            "voice_type": row.get("voice_type") or "system",
            "aspect_ratio": row.get("aspect_ratio") or "16:9",
            "task_type": row.get("task_type") or "normal",
            "generation_mode": row.get("generation_mode") or "standard",
            "pipeline_mode": row.get("pipeline_mode"),
            "refund_points": _safe_int(row.get("credits_charged"), 0),
            "retry_count": retry_count,
            "last_error": "stale active job marker recovered after worker restart",
            "_recovered_stale_active_job_marker": {
                "pid": marker.get("pid"),
                "created_at": marker.get("created_at"),
                "updated_at": marker.get("updated_at"),
                "marker_retry_count": marker.get("retry_count"),
            },
        }
        if voice_snapshot:
            task_data["tts_voice_snapshot"] = voice_snapshot
        return task_data
