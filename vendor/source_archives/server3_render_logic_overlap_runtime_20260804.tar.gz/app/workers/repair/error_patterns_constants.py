"""
Manim 渲染错误模式库 — 常见错误的正则匹配 + 自动修复规则。
在调用 LLM 之前先尝试模式匹配修复，节省时间和 token。
"""
import io
import re
import tokenize
from typing import Tuple, Optional

from app.workers.repair.polyline_compat import inject_polyline_compat

# 每项: { "match": 错误信息正则, "fixes": [(old_regex, new_str), ...] }
ERROR_PATTERNS = [
    # 1. TypeError: 缺少关键字参数 — Dot/Line/Circle/Arrow/Arc 等
    #    例: TypeError: Dot.__init__() missing required keyword argument 'point'
    {
        "match": r"TypeError:.*(?:Dot|Line|Circle|Arrow|Arc)\.__init__\(\).*missing.*(?:keyword argument|positional argument)",
        "fixes": [
            # Dot(x, y, z) -> Dot(point=[x, y, z])
            (r"Dot\(\s*([^,\)]+),\s*([^,\)]+),\s*([^,\)]+)\s*\)",
             r"Dot(point=[\1, \2, \3])"),
            # Dot(ORIGIN) 等常量保持不变，但 Dot(np.array(...)) 需包裹
            (r"Dot\(\s*(np\.array\([^)]+\))\s*\)",
             r"Dot(point=\1)"),
        ],
    },

    # 2. NameError: 颜色常量不存在
    #    例: NameError: name 'BROWN' is not defined
    {
        "match": r"NameError:.*name\s+'BROWN'.*not defined",
        "fixes": [
            (r"\bBROWN\b", r"ORANGE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'DARK_GREY'.*not defined",
        "fixes": [
            (r"\bDARK_GREY\b", r"GREY"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'LIGHT_GREY'.*not defined",
        "fixes": [
            (r"\bLIGHT_GREY\b", r"GREY"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'GREY'.*not defined",
        "fixes": [
            (r"\bGREY\b", r"GRAY"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'DARK_GRAY'.*not defined",
        "fixes": [
            (r"\bDARK_GRAY\b", r"GRAY"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'LIGHT_GRAY'.*not defined",
        "fixes": [
            (r"\bLIGHT_GRAY\b", r"GRAY"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'DARK_BLUE'.*not defined",
        "fixes": [
            (r"\bDARK_BLUE\b", r"BLUE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'LIGHT_BLUE'.*not defined",
        "fixes": [
            (r"\bLIGHT_BLUE\b", r"BLUE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'DARK_GREEN'.*not defined",
        "fixes": [
            (r"\bDARK_GREEN\b", r"GREEN"),
        ],
    },

    # 3D 科技风配色幻觉：LLM 生成不存在的 MAIN_YELLOW / MAIN_RED 等
    {
        "match": r"NameError:.*name\s+'MAIN_YELLOW'.*not defined",
        "fixes": [
            (r"\bMAIN_YELLOW\b", r"MAIN_ORANGE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'MAIN_RED'.*not defined",
        "fixes": [
            (r"\bMAIN_RED\b", r"MAIN_PINK"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'MAIN_GOLD'.*not defined",
        "fixes": [
            (r"\bMAIN_GOLD\b", r"MAIN_ORANGE"),
        ],
    },

    # 通用 NameError: LLM 幻觉的全局变量/常量 — 直接删除或替换
    {
        "match": r"NameError:.*name\s+'MAIN_COLOR'.*not defined",
        "fixes": [
            (r"\bMAIN_COLOR\b", r"BLUE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'MAIN'.*not defined",
        "fixes": [
            (r"\bMAIN\b(?!\w)", r"BLUE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'GlobalConfig'.*not defined",
        "fixes": [
            # GlobalConfig.xxx 引用 → 删除整行
            (r".*GlobalConfig\b.*\n?", r""),
        ],
    },
    {
        "match": r"NameError:.*name\s+'ACCENT'.*not defined",
        "fixes": [
            (r"\bACCENT\b", r"YELLOW"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'SECONDARY'.*not defined",
        "fixes": [
            (r"\bSECONDARY\b", r"GREEN"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'PRIMARY'.*not defined",
        "fixes": [
            (r"\bPRIMARY\b", r"BLUE"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'BG_COLOR'.*not defined",
        "fixes": [
            (r"\bBG_COLOR\b", r"BLACK"),
        ],
    },
    {
        "match": r"NameError:.*name\s+'TEXT_COLOR'.*not defined",
        "fixes": [
            (r"\bTEXT_COLOR\b", r"GlobalConfig.PRIMARY_TEXT"),
        ],
    },

    # 3. TypeError: Write 只能用于 VMobject — 改 Create
    #    例: TypeError: Write requires VMobject
    {
        "match": r"TypeError:.*Write.*(?:VMobject|requires|cannot)",
        "fixes": [
            (r"\bWrite\(", r"Create("),
        ],
    },

    # 4. NameError: Group 不存在 — 改 VGroup
    {
        "match": r"NameError:.*name\s+'Group'.*not defined",
        "fixes": [
            (r"\bGroup\(", r"VGroup("),
        ],
    },

    # 5. MathTex 含中文 — 改用 Tex
    #    例: LaTeX Error / Package inputenc Error with MathTex
    {
        "match": r"(?:LaTeX Error|Package inputenc Error).*(?:MathTex|mathtex)",
        "fixes": [
            (r"\bMathTex\(", r"Tex("),
        ],
    },

    # 6. .length 属性不存在
    #    例: AttributeError: 'Line' object has no attribute 'length'
    {
        "match": r"AttributeError:.*has no attribute\s+'length'",
        "fixes": [
            (r"\.length\b", r".get_length()"),
        ],
    },

    # 7. ShowCreation 已废弃 — 改 Create
    {
        "match": r"NameError:.*name\s+'ShowCreation'.*not defined",
        "fixes": [
            (r"\bShowCreation\(", r"Create("),
        ],
    },

    # 8. .radius 属性不存在（RegularPolygon 等）
    {
        "match": r"AttributeError:.*has no attribute\s+'radius'",
        "fixes": [
            (r"\.radius\b", r".width / 2"),
        ],
    },

    # 8b. Angle.get_vector() 在 Manim v0.19.0 中已移除
    #     例: AttributeError: Angle object has no attribute 'vector'
    #     修复: .get_vector() → .get_center() - .get_start()（方向向量）
    {
        "match": r"AttributeError:.*(?:Angle|Arc).*has no attribute\s+'vector'",
        "fixes": [
            # obj.get_vector() → (obj.point_from_proportion(0.5) - obj.arc_center)
            # 但这太复杂，简单方案：用 normalize 替代
            (r'(\w+)\.get_vector\(\)', r'(\1.get_end() - \1.get_start())'),
        ],
    },

    # 9. stroke_opacity 关键字不支持
    {
        "match": r"TypeError:.*(?:unexpected|got an unexpected).*keyword.*stroke_opacity",
        "fixes": [
            (r"\bstroke_opacity\s*=\s*([^,\)]+)", r"stroke_width=2"),
        ],
    },

    # 10. ThreeDCamera 没有 animate 属性 — 改用 move_camera
    #     例: AttributeError: 'ThreeDCamera' object has no attribute 'animate'
    {
        "match": r"AttributeError:.*ThreeDCamera.*has no attribute\s+'animate'",
        "fixes": [
            # self.camera.animate.move_to(...) → 删除整行（无法自动转 move_camera）
            # 但最常见的是 self.camera.animate 被误用，直接替换为注释提示
            (r"self\.camera\.animate\b", r"# FIXME_camera_animate"),
        ],
    },

    # 11. wait() duration <= 0 — 自动改为 self.wait(1)
    #     例: ValueError: Scene_06_DynamicBuild.wait() has a duration of 0 <= 0 seconds
    {
        "match": r"ValueError:.*\.wait\(\).*duration.*(?:<=\s*0|negative)",
        "fixes": [
            # self.wait(max(0, expr)) → self.wait(max(0.5, expr))
            (r"self\.wait\(\s*max\(\s*0\s*,", r"self.wait(max(0.5,"),
            # self.wait(0) → self.wait(1)
            (r"self\.wait\(\s*0\s*\)", r"self.wait(1)"),
        ],
    },
]


# 中文字符检测正则
_CHINESE_RE = re.compile(r'[\u4e00-\u9fff\u3400-\u4dbf]')
_NONPOSITIVE_WAIT_MAX_RE = re.compile(
    r"^(?P<indent>\s*)self\.wait\(\s*max\(\s*0(?:\.0)?\s*,\s*(?P<expr>.+)\)\s*\)\s*$"
)
_ZERO_WAIT_RE = re.compile(
    r"^(?P<indent>\s*)self\.wait\(\s*0(?:\.0)?\s*\)\s*$"
)



