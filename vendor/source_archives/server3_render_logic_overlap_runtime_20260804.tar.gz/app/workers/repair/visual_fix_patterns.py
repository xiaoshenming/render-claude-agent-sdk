"""Compiled patterns and thresholds for deterministic visual fixes."""

import re

CN = r"\u4e00-\u9fff\u3400-\u4dbf"
UNPROTECTED_TEXT_RE = re.compile(
    r'^(\s*\w+\s*=\s*)'
    r'(Text\(\s*(?:r)?["\'])'
    r'([^"\']{0,500}?)'
    r'(["\'][^)]*\))'
    r'(\s*$)',
    re.MULTILINE,
)
CHINESE_CHAR_RE = re.compile(f"[{CN}]")
SCALE_WIDTH_RE = re.compile(r"\.scale_to_fit_width\(")
SCALE_HEIGHT_RE = re.compile(r"\.scale_to_fit_height\(")
VERTICAL_LIST_VGROUP_RE = re.compile(
    r"VGroup\(\s*(?P<args>[A-Za-z_]\w*(?:\s*,\s*[A-Za-z_]\w*)+)"
    r"\s*\)\.arrange\(\s*DOWN\b",
    re.MULTILINE,
)
LIST_WRAP_TARGET_CN = 12
LIST_WRAP_MIN_LINE_CN = 8
LIST_WRAP_MIN_REMAINING_CN = 2
LIST_WRAP_PUNCTUATION = set("，,；;、。！？!?")
