"""TTS provider argument parsing and configured service-call construction."""

import re
from typing import Any

_AUDIO_REFERENCE_RE = re.compile(
    r"^(?:https?://|data:audio/|file://|/).+",
    re.IGNORECASE,
)


def looks_like_audio_reference(value: str) -> bool:
    normalized = str(value or "").strip()
    if not normalized:
        return False
    if _AUDIO_REFERENCE_RE.match(normalized):
        return True
    return normalized.lower().split("?", 1)[0].endswith((".mp3", ".wav"))


def extract_keyword_assignment(args: str, name: str) -> str:
    match = re.search(
        rf"\b{name}\s*=\s*(?P<value>\"[^\"]*\"|'[^']*'|[^,\s)]+)",
        args or "",
    )
    if not match:
        return ""
    return f"{name}={match.group('value')}"


def assignment_value(assignment: str) -> str:
    if "=" not in assignment:
        return ""
    value = assignment.split("=", 1)[1].strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def provider_from_direct_class(provider_class: str) -> str:
    if provider_class == "CosyVoiceManimService":
        return 'provider="cosyvoice"'
    if provider_class == "MimoVoiceManimService":
        return 'provider="mimo"'
    return ""


def preserved_provider_args(args: str, provider_class: str = "") -> list[str]:
    provider = extract_keyword_assignment(args, "provider")
    if not provider:
        provider = provider_from_direct_class(provider_class)
    preserved = [provider] if provider else []
    for name in ("target_model", "model"):
        assignment = extract_keyword_assignment(args, name)
        if assignment:
            preserved.append(assignment)
            break
    return preserved


def _preserved_provider(preserved_args: list[str]) -> str:
    for assignment in preserved_args:
        if assignment.startswith("provider="):
            return assignment_value(assignment).strip().lower()
    return ""


def _has_assignment(args: list[str], name: str) -> bool:
    return any(arg.strip().startswith(f"{name}=") for arg in args)


def _append_assignment(args: list[str], name: str, value: str) -> None:
    if value and not _has_assignment(args, name):
        args.append(f"{name}={value!r}")


def _snapshot_value(snapshot: dict[str, Any] | None, *keys: str) -> str:
    if not snapshot:
        return ""
    for key in keys:
        value = str(snapshot.get(key) or "").strip()
        if value:
            return value
    return ""


def configured_call(
    *,
    enable_tts: bool,
    tts_voice: str,
    voice_type: str,
    cosyvoice_id: str,
    preserved_args: list[str] | None = None,
    tts_voice_snapshot: dict[str, Any] | None = None,
) -> tuple[str, str]:
    if not enable_tts:
        return "", ""
    normalized_voice_type = str(voice_type or "system").strip().lower()
    snapshot = tts_voice_snapshot if isinstance(tts_voice_snapshot, dict) else None
    reference = str(cosyvoice_id or "").strip()
    args = list(preserved_args or [])
    snapshot_provider = _snapshot_value(snapshot, "provider").lower()
    snapshot_model = _snapshot_value(snapshot, "target_model", "model")
    snapshot_provider_voice_id = _snapshot_value(
        snapshot,
        "provider_voice_id",
        "voice_id",
    )
    if snapshot_provider:
        _append_assignment(args, "provider", snapshot_provider)
    if snapshot_model and not (
        _has_assignment(args, "target_model") or _has_assignment(args, "model")
    ):
        args.append(f"target_model={snapshot_model!r}")
    if normalized_voice_type == "clone" and snapshot and not reference:
        if snapshot_provider in {"mimo", "xiaomi", "xiaomi_mimo"}:
            reference = _snapshot_value(
                snapshot,
                "reference_audio_url",
                "source_audio_url",
                "audio_url",
                "cosyvoice_id",
            )
        else:
            reference = snapshot_provider_voice_id
    if normalized_voice_type == "clone" and reference:
        provider = _preserved_provider(args)
        if provider in {"ali", "aliyun", "dashscope", "cosy", "cosyvoice"}:
            if not looks_like_audio_reference(reference):
                _append_assignment(args, "cosyvoice_id", reference)
                _append_assignment(
                    args,
                    "provider_voice_id",
                    snapshot_provider_voice_id or reference,
                )
            else:
                _append_assignment(args, "cosyvoice_id", reference)
        else:
            _append_assignment(args, "cosyvoice_id", reference)
        args.append('voice_type="clone"')
        return f"create_system_tts_service({', '.join(args)})", "克隆TTS引用强制注入"
    voice = str(tts_voice or "").strip()
    if not voice:
        return "", ""
    args.append(f"voice_id={voice!r}")
    return f"create_system_tts_service({', '.join(args)})", "系统TTS音色强制注入"
