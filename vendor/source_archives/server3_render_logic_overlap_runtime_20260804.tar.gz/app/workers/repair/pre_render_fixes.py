"""Deprecated compatibility boundary for the removed pre-render repair stack.

The generation pipeline now owns correctness before formal rendering. These
functions intentionally preserve import compatibility without mutating code.
Callers should be removed as their surrounding flows are refactored.
"""

from typing import Tuple


def pre_render_scan(code: str, **_: object) -> Tuple[str, list]:
    return code, []


def pre_render_scan_planning(code: str, **_: object) -> Tuple[str, list]:
    return code, []
