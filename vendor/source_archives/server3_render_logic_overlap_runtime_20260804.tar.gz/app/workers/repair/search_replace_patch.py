"""Shared helpers for patch-first repair flows."""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from app.agents.patcher import (
    PatchScope,
    apply_search_replace,
    has_patch_blocks,
    output_looks_like_full_rewrite,
)

PATCH_ONLY_REPAIR_INSTRUCTIONS = (
    "只输出 search/replace patch，不要重写整个文件。\n"
    "公式渲染修复必须保留可解析公式：禁止把含 TeX 命令、^、_、=、+、分数或根号的公式字符串放进 Text/safe_text_box；"
    "应改为 MathTex，混合中文说明则拆成 VGroup(Text(...), MathTex(...))。\n"
    "格式必须严格为：\n"
    "<<<<<<< SEARCH\n"
    "原始代码片段\n"
    "=======\n"
    "替换后的代码片段\n"
    ">>>>>>> REPLACE\n"
)


def extract_patch_text(text: str) -> str:
    """Strip optional Markdown fences while preserving patch body exactly."""
    value = (text or "").strip()
    if not value.startswith("```"):
        return value
    value = re.sub(r"^```[A-Za-z0-9_-]*\s*\n?", "", value)
    value = re.sub(r"\n?```\s*$", "", value)
    return value.strip()


def summarize_patch_failures(failures: list[Any]) -> str:
    parts: list[str] = []
    for failure in failures:
        reason = getattr(failure, "reason", "unknown")
        search = str(getattr(failure, "search", "") or "")
        search = search.replace("\n", "\\n")[:160]
        parts.append(f"{reason}:{search}")
    return "; ".join(parts) if parts else "unknown_patch_failure"


def apply_patch_or_fallback(
    original: str,
    output: str,
    *,
    patch_scope: PatchScope | None = None,
    looks_like_fallback: Callable[[str], bool] | None = None,
    full_rewrite_min_lines: int = 100,
) -> dict[str, Any]:
    """Apply Search/Replace output or return a full-code fallback candidate."""
    patch_text = extract_patch_text(output)
    if not patch_text:
        return {"ok": False, "reason": "empty_patch_output"}

    if not has_patch_blocks(patch_text):
        if looks_like_fallback and looks_like_fallback(patch_text):
            return {
                "ok": False,
                "reason": "non_patch_code_output",
                "fallback_raw": patch_text,
            }
        return {"ok": False, "reason": "invalid_patch_block"}

    if output_looks_like_full_rewrite(
        patch_text,
        min_lines=full_rewrite_min_lines,
    ):
        if looks_like_fallback and looks_like_fallback(patch_text):
            return {
                "ok": False,
                "reason": "full_rewrite_code_output",
                "fallback_raw": patch_text,
            }
        return {"ok": False, "reason": "full_file_rewrite_rejected"}

    result = apply_search_replace(original, patch_text, scope=patch_scope)
    if result.failures:
        return {
            "ok": False,
            "reason": summarize_patch_failures(result.failures),
            "patch": patch_text,
        }
    if result.applied_count <= 0 or result.text == original:
        return {
            "ok": False,
            "reason": "patch_no_change",
            "patch": patch_text,
        }
    return {
        "ok": True,
        "code": result.text,
        "patch": patch_text,
        "applied_count": result.applied_count,
    }


def apply_modify_patch_or_fallback(
    original: str,
    output: str,
    *,
    scene_name: str = "",
    function_name: str = "",
    full_rewrite_min_lines: int = 100,
) -> dict[str, Any]:
    """Apply modify Search/Replace output or expose full-code fallback.

    User modify patch output must be treated differently from render-repair
    memory: a full Python file is acceptable as a fallback candidate, but a
    malformed or non-unique patch must keep an explicit failure reason.
    """

    def _looks_like_modify_fallback(candidate: str) -> bool:
        from app.workers.validation import code_validator

        code = code_validator.extract_python_code(candidate)
        if not code:
            return False
        if scene_name and re.search(
            rf"(?m)^class\s+{re.escape(scene_name)}\s*\(", code
        ):
            return True
        return "class " in code and ("Scene" in code or "self." in code)

    result = apply_patch_or_fallback(
        original,
        output,
        patch_scope=PatchScope(
            scene_name=scene_name,
            function_name=function_name,
        ),
        looks_like_fallback=_looks_like_modify_fallback,
        full_rewrite_min_lines=full_rewrite_min_lines,
    )
    fallback_raw = result.get("fallback_raw")
    if fallback_raw:
        from app.workers.validation import code_validator

        fallback_code = code_validator.extract_python_code(str(fallback_raw))
        result["fallback_code"] = fallback_code or str(fallback_raw)
    return result
