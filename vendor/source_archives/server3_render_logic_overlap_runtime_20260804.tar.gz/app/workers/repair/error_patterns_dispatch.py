from __future__ import annotations

from .error_patterns_constants import *
from .error_patterns_fixes import *

_TTS_ERROR_PATTERNS = (
    re.compile(r"CosyVoice|cosyvoice", re.IGNORECASE),
    re.compile(r"TTS.*(?:timeout|timed out|connection|websocket|418)", re.IGNORECASE),
)
_VOICEOVER_RUNTIME_CONTEXT_RE = re.compile(r"voiceover|speech_service|tts", re.IGNORECASE)
_VOICEOVER_CODE_ERROR_RE = re.compile(r"(?:NameError|AttributeError|SyntaxError)", re.IGNORECASE)
def try_pattern_fix(
    scene_code: str, error_msg: str, has_ctex: bool = False
) -> Tuple[Optional[str], str]:
    """尝试用模式匹配修复 scene_code。

    Args:
        scene_code: 待修复的 Scene 类代码
        error_msg: 渲染错误信息
        has_ctex: 代码上下文中是否已配置 ctex 模板

    Returns:
        (fixed_code, description) — 修复成功返回新代码和描述；
        未命中任何模式返回 (None, "")
    """
    # 0. 预处理：中文标点修复（无论什么错误类型）
    punct_fixed, punct_desc = _auto_fix_chinese_punctuation(scene_code)
    if punct_fixed:
        scene_code = punct_fixed

    if re.search(
        r"ValueError:.*\.wait\(\).*duration.*(?:<=\s*0|negative)",
        error_msg,
        re.IGNORECASE,
    ):
        fixed, desc = _auto_fix_nonpositive_waits(scene_code)
        if fixed:
            if punct_desc:
                desc = f"{punct_desc}; {desc}"
            return fixed, desc

    fixed, desc = _auto_fix_numpy_math(scene_code, error_msg)
    if fixed:
        if punct_desc:
            desc = f"{punct_desc}; {desc}"
        return fixed, desc

    # Manim 0.19 无 Polyline；这是 LLM 画直角/折线时的高频幻觉。
    if re.search(
        r"NameError:.*name\s+'Polyline'.*not defined",
        error_msg,
        re.IGNORECASE,
    ):
        fixed, desc = inject_polyline_compat(scene_code)
        if fixed:
            if punct_desc:
                desc = f"{punct_desc}; {desc}"
            return fixed, desc

    for pattern in ERROR_PATTERNS:
        if not re.search(pattern["match"], error_msg, re.IGNORECASE):
            continue

        modified = scene_code
        applied = []
        for old_re, new_re in pattern["fixes"]:
            result = re.sub(old_re, new_re, modified)
            if result != modified:
                applied.append(f"{old_re} -> {new_re}")
                modified = result

        if applied and modified != scene_code:
            desc = (
                f"匹配模式 [{pattern['match'][:50]}...], "
                f"应用 {len(applied)} 条替换"
            )
            if punct_desc:
                desc = f"{punct_desc}; {desc}"
            return modified, desc

    # 正则模式未命中时，尝试自动补全截断（SyntaxError: 括号/引号未闭合）
    if re.search(r"SyntaxError:.*(?:was never closed|unexpected EOF|unterminated)", error_msg, re.IGNORECASE):
        fixed, desc = _auto_fix_truncation(scene_code)
        if fixed:
            if punct_desc:
                desc = f"{punct_desc}; {desc}"
            return fixed, desc

    # xelatex 编译错误 — 将含中文的 MathTex/Tex 替换为 Text
    # 但如果已有 ctex 模板则跳过（ctex 原生支持中文）
    if re.search(r"(?:xelatex error|xdv|LaTeX Error|Package inputenc)", error_msg, re.IGNORECASE):
        fixed, desc = _auto_fix_mathtex_chinese(scene_code, has_ctex=has_ctex)
        if fixed:
            if punct_desc:
                desc = f"{punct_desc}; {desc}"
            return fixed, desc

    # 如果只有标点修复，也返回
    if punct_fixed:
        return punct_fixed, punct_desc

    return None, ""
def is_tts_error(error_msg: str) -> bool:
    """判断错误是否为 TTS 语音合成服务的网络/连接错误。

    这类错误与生成的 Manim 代码无关，不应触发 LLM 代码修复，
    而应走纯重渲染重试路径。
    """
    if not error_msg:
        return False
    if any(p.search(error_msg) for p in _TTS_ERROR_PATTERNS):
        return True
    if _VOICEOVER_RUNTIME_CONTEXT_RE.search(error_msg):
        return _VOICEOVER_CODE_ERROR_RE.search(error_msg) is None
    return False
