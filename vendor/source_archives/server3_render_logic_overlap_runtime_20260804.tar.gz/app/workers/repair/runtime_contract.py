"""Static generated-code runtime helper contract compatibility facade.

This module only reports contract violations. It intentionally does not repair
code or inject helper shims.
"""
# ruff: noqa: F401

from __future__ import annotations

import ast
from collections.abc import Iterable

from .runtime_contract_ast import (
    _ClassContractIndex,
    _RuntimeContractVisitor,
    _call_helper_name,
    _class_name,
    _hallucinated_helper_violation,
    _is_direct_self_or_cls,
    _missing_runtime_helper_violation,
    _syntax_error_violation,
)
from .runtime_contract_constants import (
    ALLOWED_LLM_RUNTIME_HELPERS,
    ALLOWED_MANIM_SCENE_METHODS,
    HALLUCINATED_LLM_HELPERS,
    MISSING_LATEST_RUNTIME_HELPERS,
    VERTICAL_DIVISION_RUNTIME_HELPERS,
    Violation,
)


def scan_runtime_contract_violations(
    code: str,
    *,
    allowed_runtime_helpers: Iterable[str] | None = None,
) -> list[Violation]:
    """Return static runtime-contract violations for generated Manim code."""

    try:
        tree = ast.parse(code or "")
    except SyntaxError as exc:
        return [_syntax_error_violation(exc)]

    contract_index = _ClassContractIndex()
    contract_index.visit(tree)
    visitor = _RuntimeContractVisitor(
        HALLUCINATED_LLM_HELPERS,
        contract_index,
        allowed_runtime_helpers=allowed_runtime_helpers,
    )
    visitor.visit(tree)
    return visitor.violations
