"""TTS voice contract enforcement for final render scripts."""

from __future__ import annotations

import re
from typing import Any

from app.workers.repair.tts_voice_arguments import configured_call as _configured_call

SYSTEM_TTS_IMPORT = "from custom_services.system_tts_service import create_system_tts_service"
_SYSTEM_TTS_CALL_RE = re.compile(r"create_system_tts_service\((?P<args>[^()]*)\)")
_DIRECT_PROVIDER_CALL_RE = re.compile(
    r"\b(?P<class>CosyVoiceManimService|MimoVoiceManimService)\((?P<args>[^()]*)\)"
)
_DIRECT_PROVIDER_IMPORTS = (
    "from custom_services.cosyvoice_manim_service import CosyVoiceManimService",
    "from custom_services.mimo_manim_service import MimoVoiceManimService",
)
_VOICEOVER_USAGE_RE = re.compile(
    r"\bself\.(?:voiceover|add_voiceover_text|add_voiceover_ssml)\s*\("
)
def _extract_keyword_assignment(args: str, name: str) -> str:
    match = re.search(
        rf"\b{name}\s*=\s*(?P<value>\"[^\"]*\"|'[^']*'|[^,\s)]+)",
        args or "",
    )
    if not match:
        return ""
    return f"{name}={match.group('value')}"


def _provider_from_direct_class(provider_class: str) -> str:
    if provider_class == "CosyVoiceManimService":
        return 'provider="cosyvoice"'
    if provider_class == "MimoVoiceManimService":
        return 'provider="mimo"'
    return ""


def _preserved_provider_args(args: str, provider_class: str = "") -> list[str]:
    provider = _extract_keyword_assignment(args, "provider")
    if not provider:
        provider = _provider_from_direct_class(provider_class)
    preserved = [provider] if provider else []
    for name in ("target_model", "model"):
        assignment = _extract_keyword_assignment(args, name)
        if assignment:
            preserved.append(assignment)
            break
    return preserved


def _ensure_system_tts_import(code: str) -> str:
    if SYSTEM_TTS_IMPORT in code:
        return code
    lines = code.splitlines()
    insert_at = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith(("import ", "from ")):
            insert_at = index + 1
            continue
        if stripped == "":
            continue
        break
    lines.insert(insert_at, SYSTEM_TTS_IMPORT)
    trailing_newline = "\n" if code.endswith("\n") else ""
    return "\n".join(lines) + trailing_newline


def _dedupe_imports(code: str) -> str:
    seen: set[str] = set()
    lines: list[str] = []
    for line in code.splitlines():
        stripped = line.strip()
        if stripped == SYSTEM_TTS_IMPORT:
            if stripped in seen:
                continue
            seen.add(stripped)
        lines.append(line)
    trailing_newline = "\n" if code.endswith("\n") else ""
    return "\n".join(lines) + trailing_newline


def _base_name(node: Any) -> str:
    if getattr(node, "id", None):
        return str(node.id)
    if getattr(node, "attr", None):
        return str(node.attr)
    return ""


def _line_indent(line: str) -> str:
    return line[: len(line) - len(line.lstrip())]


def _is_docstring_node(node: Any) -> bool:
    value = getattr(node, "value", None)
    return (
        getattr(node, "__class__", None).__name__ == "Expr"
        and getattr(value, "__class__", None).__name__ == "Constant"
        and isinstance(getattr(value, "value", None), str)
    )


def _inject_missing_tts_setup(code: str, call: str) -> tuple[str, int]:
    if (
        not code
        or not call
        or "set_speech_service(" in code
        or "VoiceoverScene" not in code
        or not _VOICEOVER_USAGE_RE.search(code)
    ):
        return code, 0
    try:
        tree = __import__("ast").parse(code)
    except SyntaxError:
        return code, 0

    target_class = None
    for node in getattr(tree, "body", []):
        if getattr(node, "__class__", None).__name__ != "ClassDef":
            continue
        if getattr(node, "name", "") != "BaseConfigScene":
            continue
        if any(_base_name(base) == "VoiceoverScene" for base in getattr(node, "bases", [])):
            target_class = node
            break
    if target_class is None:
        return code, 0

    lines = code.splitlines()
    method = None
    for node in getattr(target_class, "body", []):
        if (
            getattr(node, "__class__", None).__name__ == "FunctionDef"
            and getattr(node, "name", "") == "setup_layout"
        ):
            method = node
            break

    if method is None:
        class_indent = _line_indent(lines[target_class.lineno - 1])
        body_indent = class_indent + "    "
        insert_at = target_class.body[0].end_lineno if (
            target_class.body and _is_docstring_node(target_class.body[0])
        ) else target_class.lineno
        block = [
            f"{body_indent}def setup_layout(self):",
            f"{body_indent}    self.set_speech_service({call})",
            "",
        ]
        lines[insert_at:insert_at] = block
        return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), 1

    body = list(getattr(method, "body", []))
    insert_index = 0
    if body and _is_docstring_node(body[0]):
        insert_index = 1
    if len(body) > insert_index and getattr(body[insert_index], "__class__", None).__name__ == "Pass":
        pass_node = body[insert_index]
        line_no = pass_node.lineno - 1
        indent = _line_indent(lines[line_no])
        lines[line_no : pass_node.end_lineno] = [
            f"{indent}self.set_speech_service({call})"
        ]
        return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), 1

    target = body[insert_index] if len(body) > insert_index else method
    line_no = max(int(getattr(target, "lineno", method.lineno)) - 1, 0)
    indent = _line_indent(lines[line_no]) or (_line_indent(lines[method.lineno - 1]) + "    ")
    lines[line_no:line_no] = [f"{indent}self.set_speech_service({call})"]
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), 1


def enforce_configured_tts_voice(
    code: str,
    *,
    enable_tts: bool,
    tts_voice: str = "",
    voice_type: str = "system",
    cosyvoice_id: str = "",
    tts_voice_snapshot: dict[str, Any] | None = None,
) -> tuple[str, str | None]:
    """Force generated code to use the voice selected by the job payload."""
    source = code or ""
    call, reason_prefix = _configured_call(
        enable_tts=enable_tts,
        tts_voice=tts_voice,
        voice_type=voice_type,
        cosyvoice_id=cosyvoice_id,
        tts_voice_snapshot=tts_voice_snapshot,
    )
    if not call:
        return source, None

    changed = 0

    def _replace_call(match: re.Match[str]) -> str:
        nonlocal changed
        preserved_args = _preserved_provider_args(
            match.group("args"),
            match.groupdict().get("class", ""),
        )
        replacement, _reason = _configured_call(
            enable_tts=enable_tts,
            tts_voice=tts_voice,
            voice_type=voice_type,
            cosyvoice_id=cosyvoice_id,
            preserved_args=preserved_args,
            tts_voice_snapshot=tts_voice_snapshot,
        )
        if not replacement:
            return match.group(0)
        original = match.group(0)
        if original == replacement:
            return original
        changed += 1
        return replacement

    fixed = _SYSTEM_TTS_CALL_RE.sub(_replace_call, source)
    fixed = _DIRECT_PROVIDER_CALL_RE.sub(_replace_call, fixed)
    reasons: list[str] = []

    if changed:
        reasons.append(f"{reason_prefix}: {changed}处")

    for provider_import in _DIRECT_PROVIDER_IMPORTS:
        fixed = fixed.replace(provider_import, SYSTEM_TTS_IMPORT)

    fixed, injected = _inject_missing_tts_setup(fixed, call)
    if injected:
        reasons.append(f"{reason_prefix}初始化补齐: {injected}处")

    if not reasons or fixed == source:
        return source, None

    fixed = _ensure_system_tts_import(fixed)
    fixed = _dedupe_imports(fixed)
    return fixed, "; ".join(reasons)
