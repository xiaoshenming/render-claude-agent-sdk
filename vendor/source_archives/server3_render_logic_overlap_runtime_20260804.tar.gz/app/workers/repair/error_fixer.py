"""Error analysis and syntax repair compatibility facade."""
# ruff: noqa: F401

import ast
import logging
from typing import Any, Dict, Optional

from app.services.ai_guardrails import guard_ai_output
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_patch_or_fallback,
)
from .error_classification import (
    _restore_missing_header,
    _ts,
    error_signature,
    extract_error_context,
    extract_render_error,
)
from .error_scene_ops import (
    check_scene_cache,
    extract_scene_code,
    replace_scene_code,
    save_scene_cache,
    scene_cache_key,
)
from .error_truncation import auto_fix_truncation, has_empty_call_after_truncation

logger = logging.getLogger("render")


async def fix_syntax_error(
    code: str,
    error_msg: str,
    job_id: str,
    max_attempts: int = 2,
    task_data: Optional[Dict[str, Any]] = None,
    expected_scene_name: Optional[str] = None,
) -> Optional[str]:
    """尝试修复代码中的语法错误。
    优先用程序自动补全（截断类错误），失败再调 LLM。
    """
    from app.workers.validation.code_validator import (
        extract_python_code,
        validate_generated_code_shape,
    )

    # ===== 阶段 1: 自动补全截断 =====
    auto_fixed = auto_fix_truncation(code, error_msg)
    if auto_fixed:
        try:
            ast.parse(auto_fixed, filename=f"job_{job_id}_autofix.py")
            logger.info(
                f"[SYNTAX-FIX] [{_ts()}] ✓ 自动补全修复成功 (无需 LLM), job_id={job_id}"
            )
            return auto_fixed
        except SyntaxError:
            logger.info(f"[SYNTAX-FIX] [{_ts()}] 自动补全后仍有语法错误，转 LLM")

    # ===== 阶段 2: LLM 修复（只发错误附近代码）=====
    from app.services.llm_service import get_repair_llm_manager

    for attempt in range(max_attempts):
        try:
            logger.info(
                f"[SYNTAX-FIX] [{_ts()}] 第{attempt + 1}次尝试 LLM 修复: "
                f"job_id={job_id}, error={error_msg[:200]}"
            )

            context_code = extract_error_context(code, error_msg, context_lines=30)

            patch_prompt = (
                f"{PATCH_ONLY_REPAIR_INSTRUCTIONS}\n"
                f"以下 Python/Manim 代码有语法错误，请修复。"
                "SEARCH 片段必须逐字匹配下面代码中的原文，只修改导致语法错误的最小范围。\n\n"
                f"## 语法错误\n```\n{error_msg}\n```\n\n"
                f"## 错误附近代码\n```python\n{context_code}\n```"
            )

            llm_mgr = get_repair_llm_manager()
            response, backend = await llm_mgr.call(
                messages=[{"role": "user", "content": patch_prompt}],
                max_tokens=8192,
                retry_budget=1,
                trace_job_id=job_id,
                trace_call_type="syntax_fix_patch",
                trace_prompt_version=f"attempt_{attempt + 1}",
                trace_prompt_content=patch_prompt,
            )
            if task_data is not None and hasattr(response, "usage") and response.usage:
                from app.workers.video_worker import _accumulate_tokens

                _accumulate_tokens(task_data, response)

            patch_raw = guard_ai_output(
                response.choices[0].message.content or "",
                scenario="render_error_fix_output",
            )
            patch_result = apply_patch_or_fallback(
                code,
                patch_raw,
                looks_like_fallback=lambda output: bool(
                    extract_scene_code(output, expected_scene_name)
                    if expected_scene_name
                    else "class " in output
                ),
            )
            if patch_result.get("ok"):
                fixed_raw = patch_result["code"]
                logger.info(
                    f"[SYNTAX-FIX] [{_ts()}] Search/Replace Patch "
                    f"已应用 {patch_result.get('applied_count', 0)} 个块"
                )
            elif patch_result.get("fallback_raw"):
                fixed_raw = patch_result["fallback_raw"]
                logger.info(
                    f"[SYNTAX-FIX] [{_ts()}] Patch 请求返回完整代码，转兜底校验: "
                    f"{patch_result.get('reason')}"
                )
            else:
                fix_prompt = (
                    f"以下 Python/Manim 代码有语法错误，请修复。"
                    f"只输出修复后的完整 Python 代码，不要输出任何解释。\n\n"
                    f"## 语法错误\n```\n{error_msg}\n```\n\n"
                    f"## Search/Replace Patch 首选失败\n"
                    f"- 原因: {str(patch_result.get('reason') or '')[:600]}\n\n"
                    f"## 代码\n```python\n{context_code}\n```"
                )
                response, backend = await llm_mgr.call(
                    messages=[{"role": "user", "content": fix_prompt}],
                    max_tokens=65536,
                    retry_budget=2,
                    trace_job_id=job_id,
                    trace_call_type="syntax_fix",
                    trace_prompt_version=f"attempt_{attempt + 1}",
                    trace_prompt_content=fix_prompt,
                )
                if (
                    task_data is not None
                    and hasattr(response, "usage")
                    and response.usage
                ):
                    from app.workers.video_worker import _accumulate_tokens

                    _accumulate_tokens(task_data, response)
                fixed_raw = guard_ai_output(
                    response.choices[0].message.content or "",
                    scenario="render_error_fix_output",
                )
            fixed_code = extract_python_code(fixed_raw)

            fixed_code = _restore_missing_header(code, fixed_code)

            is_valid_code, invalid_reason = validate_generated_code_shape(
                fixed_code,
                expected_scene_name=expected_scene_name,
            )
            if not is_valid_code:
                raise ValueError(invalid_reason)

            _cn_punc = {
                "\uff0c": ",",
                "\u3002": ".",
                "\uff1b": ";",
                "\uff1a": ":",
                "\uff08": "(",
                "\uff09": ")",
                "\u3010": "[",
                "\u3011": "]",
                "\u201c": '"',
                "\u201d": '"',
                "\u2018": "'",
                "\u2019": "'",
            }
            for _cn, _en in _cn_punc.items():
                if _cn in fixed_code:
                    fixed_code = fixed_code.replace(_cn, _en)

            guard_ai_output(fixed_code, scenario="render_error_fix_code_output")
            ast.parse(fixed_code, filename=f"job_{job_id}_fixed.py")
            logger.info(
                f"[SYNTAX-FIX] [{_ts()}] ✓ 第{attempt + 1}次 LLM 修复成功, "
                f"代码长度={len(fixed_code)}"
            )
            return fixed_code
        except SyntaxError as se:
            error_msg = str(se)
            logger.warning(
                f"[SYNTAX-FIX] [{_ts()}] 第{attempt + 1}次修复后仍有语法错误: {se}"
            )
            if "fixed_code" in dir():
                code = fixed_code
        except Exception as e:
            logger.warning(f"[SYNTAX-FIX] [{_ts()}] 第{attempt + 1}次修复异常: {e}")

    logger.error(f"[SYNTAX-FIX] [{_ts()}] {max_attempts}次修复均失败")
    # 收录最终失败的代码到 failed_code_records 便于后续排查
    try:
        from app.services.failed_code_recorder import record_failed_code

        await record_failed_code(
            job_id=job_id,
            code=code,
            source="syntax_fix_failed",
            scene_name=expected_scene_name,
            attempt=max_attempts,
            error_type="SyntaxError",
            error_message=error_msg,
            stage="SYNTAX_FIX",
        )
    except Exception:
        pass
    return None
