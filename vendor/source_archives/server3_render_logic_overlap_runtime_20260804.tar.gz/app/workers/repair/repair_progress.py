"""Repair lane classification, strategy escalation, and progress tracking."""

import hashlib
from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class RepairLane(StrEnum):
    RENDER = "render_repair"
    MATH_LOGIC = "math_logic_repair"
    LAYOUT = "layout_repair"


class RepairStrategy(StrEnum):
    DETERMINISTIC = "deterministic_repair"
    LLM_PATCH = "llm_patch_repair"
    SCENE_REWRITE = "scene_rewrite_repair"
    FULL_SLICE_REGENERATE = "full_slice_regenerate"


@dataclass(frozen=True)
class RepairProgressDecision:
    should_stop: bool
    reason: str
    hit_count: int
    signature: str | None = None
    hash: str | None = None
    next_strategy: RepairStrategy | None = None


def code_hash(code: str) -> str:
    return hashlib.sha256((code or "").encode("utf-8", "replace")).hexdigest()[:16]


def classify_repair_lane(
    *, last_error: str = "", quality_issues: list[dict[str, Any]] | None = None
) -> RepairLane:
    codes = [str(item.get("code") or "") for item in (quality_issues or []) if isinstance(item, dict)]
    error = (last_error or "").lower()
    if error.startswith("layout_") or any(
        code.startswith("layout_") or "overlap" in code or "frame_overflow" in code
        for code in codes
    ):
        return RepairLane.LAYOUT
    math_codes = {
        "condition_error", "cut_fill_shape_deformation", "final_answer_error",
        "missing_condition", "missing_subquestion", "formula_error",
        "geometry_relation_error", "reasoning_step_error", "symbol_binding_error",
        "teaching_structure_gap", "wrong_geometric_relation",
    }
    if error.startswith("math_logic_") or any(
        code.startswith("math_") or code in math_codes for code in codes
    ):
        return RepairLane.MATH_LOGIC
    return RepairLane.RENDER


def next_strategy_after(strategy: RepairStrategy) -> RepairStrategy:
    if strategy == RepairStrategy.DETERMINISTIC:
        return RepairStrategy.LLM_PATCH
    if strategy == RepairStrategy.LLM_PATCH:
        return RepairStrategy.SCENE_REWRITE
    return RepairStrategy.FULL_SLICE_REGENERATE


def strategy_escalation_decision(
    *, strategy: RepairStrategy, reason: str, signature: str | None = None,
    hash: str | None = None, hit_count: int = 1,
) -> RepairProgressDecision:
    return RepairProgressDecision(
        should_stop=True, reason=reason or "strategy_escalation",
        hit_count=max(1, int(hit_count or 1)), signature=signature, hash=hash,
        next_strategy=next_strategy_after(strategy),
    )


class RepairProgressTracker:
    def __init__(self, *, repeat_threshold: int = 2) -> None:
        self.repeat_threshold = max(2, int(repeat_threshold or 2))
        self._signature_hits: dict[str, int] = {}
        self._candidate_hits: dict[str, int] = {}

    def record_error(self, *, strategy: RepairStrategy, signature: str, attempt: int) -> RepairProgressDecision:
        del attempt
        key = signature or "unknown"
        count = self._signature_hits.get(key, 0) + 1
        self._signature_hits[key] = count
        return RepairProgressDecision(
            should_stop=count >= self.repeat_threshold,
            reason="repeated_error_signature" if count >= self.repeat_threshold else "error_recorded",
            hit_count=count, signature=key, next_strategy=next_strategy_after(strategy),
        )

    def record_candidate(self, *, strategy: RepairStrategy, code: str, signature: str | None, attempt: int) -> RepairProgressDecision:
        del attempt
        digest = code_hash(code)
        key = f"{strategy.value}:{digest}"
        count = self._candidate_hits.get(key, 0) + 1
        self._candidate_hits[key] = count
        return RepairProgressDecision(
            should_stop=count >= self.repeat_threshold,
            reason="repeated_candidate_hash" if count >= self.repeat_threshold else "candidate_recorded",
            hit_count=count, signature=signature, hash=digest,
            next_strategy=next_strategy_after(strategy),
        )
