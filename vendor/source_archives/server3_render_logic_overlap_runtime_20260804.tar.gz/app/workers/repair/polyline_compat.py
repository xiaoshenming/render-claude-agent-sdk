"""Polyline compatibility fix for LLM-generated Manim code."""

import re
from typing import Optional, Tuple


_POLYLINE_CALL_RE = re.compile(r"\bPolyline\s*\(")
_POLYLINE_CLASS_RE = re.compile(
    r"^\s*class\s+Polyline\s*\(",
    re.MULTILINE,
)
_POLYLINE_COMPAT_SHIM = """
# Manim 0.19 没有内置 Polyline；为 LLM 生成的开放折线提供兼容类。
try:
    VMobject
except NameError:
    from manim import VMobject

class Polyline(VMobject):
    def __init__(self, *points, **kwargs):
        super().__init__(**kwargs)
        if len(points) >= 2:
            self.set_points_as_corners(list(points))
"""


def _find_import_prelude_end(lines: list[str]) -> int:
    """Return a safe insertion line after module docstring/future/imports."""
    index = 0
    while index < len(lines) and (
        not lines[index].strip()
        or lines[index].lstrip().startswith("#")
    ):
        index += 1

    if index < len(lines):
        stripped = lines[index].lstrip()
        quote = stripped[:3]
        if quote in ('"""', "'''"):
            index += 1
            if stripped.count(quote) < 2:
                while index < len(lines):
                    if quote in lines[index]:
                        index += 1
                        break
                    index += 1

    while index < len(lines) and (
        not lines[index].strip()
        or lines[index].lstrip().startswith("#")
    ):
        index += 1

    while index < len(lines) and re.match(
        r"\s*from\s+__future__\s+import\b",
        lines[index],
    ):
        index += 1

    last_import_end = None
    cursor = index
    while cursor < len(lines):
        stripped = lines[cursor].strip()
        if not stripped or stripped.startswith("#"):
            cursor += 1
            continue
        if stripped.startswith("import ") or stripped.startswith("from "):
            last_import_end = cursor + 1
            cursor += 1
            continue
        break

    return last_import_end if last_import_end is not None else index


def inject_polyline_compat(code: str) -> Tuple[Optional[str], str]:
    """Inject a Polyline shim when generated code uses a non-existent class."""
    if not _POLYLINE_CALL_RE.search(code):
        return None, ""
    if _POLYLINE_CLASS_RE.search(code):
        return None, ""

    lines = code.splitlines()
    insert_at = _find_import_prelude_end(lines)
    fixed = "\n".join(
        lines[:insert_at]
        + ["", _POLYLINE_COMPAT_SHIM.strip(), ""]
        + lines[insert_at:]
    )
    if code.endswith("\n"):
        fixed += "\n"
    return fixed, "注入 Polyline兼容类"
