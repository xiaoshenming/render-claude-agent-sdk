from __future__ import annotations

import ast
import builtins

from .post_patch_contracts import (
    COMMON_POST_PATCH_HELPERS,
    GEOMETRY_ALLOWED_POINT_NAMES,
    GEOMETRY_NUMERIC_CALLS,
)


def _class_method_index(
    tree: ast.AST,
) -> tuple[dict[str, set[str]], dict[str, set[str]], set[str], set[str]]:
    class_methods: dict[str, set[str]] = {}
    class_bases: dict[str, set[str]] = {}
    module_functions: set[str] = set()
    imported_names: set[str] = set()

    for node in getattr(tree, "body", []):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imported_names.add(alias.asname or alias.name.split(".", 1)[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name != "*":
                    imported_names.add(alias.asname or alias.name)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            module_functions.add(node.name)
        elif isinstance(node, ast.ClassDef):
            class_bases[node.name] = {
                _class_name(base) for base in node.bases if _class_name(base)
            }
            class_methods[node.name] = {
                item.name
                for item in node.body
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
    return class_methods, class_bases, module_functions, imported_names


def _class_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Subscript):
        return _class_name(node.value)
    return ""


def _methods_for_class(
    class_name: str,
    class_methods: dict[str, set[str]],
    class_bases: dict[str, set[str]],
) -> set[str]:
    seen: set[str] = set()
    methods: set[str] = set()

    def visit(name: str) -> None:
        if not name or name in seen:
            return
        seen.add(name)
        methods.update(class_methods.get(name, set()))
        for base in class_bases.get(name, set()):
            visit(base)

    visit(class_name)
    return methods


class _MissingCommonHelperVisitor(ast.NodeVisitor):
    def __init__(
        self,
        *,
        class_methods: dict[str, set[str]],
        class_bases: dict[str, set[str]],
        module_functions: set[str],
        imported_names: set[str],
    ) -> None:
        self.class_methods = class_methods
        self.class_bases = class_bases
        self.module_functions = module_functions
        self.imported_names = imported_names
        self.class_stack: list[str] = []
        self.issues: list[dict[str, str]] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.class_stack.append(node.name)
        try:
            for item in node.body:
                self.visit(item)
        finally:
            self.class_stack.pop()

    def visit_Call(self, node: ast.Call) -> None:
        helper = ""
        receiver = ""
        if isinstance(node.func, ast.Attribute):
            helper = node.func.attr
            if isinstance(node.func.value, ast.Name):
                receiver = node.func.value.id
        elif isinstance(node.func, ast.Name):
            helper = node.func.id

        if helper in COMMON_POST_PATCH_HELPERS:
            if receiver in {"self", "cls"}:
                current_class = self.class_stack[-1] if self.class_stack else ""
                available = _methods_for_class(
                    current_class,
                    self.class_methods,
                    self.class_bases,
                )
                if helper not in available:
                    self._add_issue(helper, node, f"{receiver}.{helper}")
            elif not receiver:
                if (
                    helper not in self.module_functions
                    and helper not in self.imported_names
                ):
                    self._add_issue(helper, node, helper)

        self.generic_visit(node)

    def _add_issue(self, helper: str, node: ast.AST, call: str) -> None:
        self.issues.append(
            {
                "helper": helper,
                "evidence": f"line={getattr(node, 'lineno', '?')}: {call}",
            }
        )


def _missing_common_helper_calls(tree: ast.AST) -> list[dict[str, str]]:
    class_methods, class_bases, module_functions, imported_names = _class_method_index(
        tree
    )
    visitor = _MissingCommonHelperVisitor(
        class_methods=class_methods,
        class_bases=class_bases,
        module_functions=module_functions,
        imported_names=imported_names,
    )
    visitor.visit(tree)
    seen: set[tuple[str, str]] = set()
    issues: list[dict[str, str]] = []
    for issue in visitor.issues:
        key = (issue["helper"], issue["evidence"])
        if key in seen:
            continue
        seen.add(key)
        issues.append(issue)
    return issues


def _geometry_numeric_guard_issues(tree: ast.AST) -> list[str]:
    bound_names = _bound_names_for_guard(tree)
    issues: list[str] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute):
            full_name = _ast_full_name(node)
            if full_name in {"np.nan", "numpy.nan", "math.nan"}:
                issues.append(f"line={getattr(node, 'lineno', '?')}: {full_name}")
        elif isinstance(node, ast.Call):
            call_name = _ast_full_name(node.func)
            if _is_float_nan_call(node, call_name):
                issues.append(f"line={getattr(node, 'lineno', '?')}: float_nan")
            if call_name in GEOMETRY_NUMERIC_CALLS:
                for name in _load_names_in_positional_args(node):
                    if _is_unbound_geometry_point_name(name, bound_names):
                        issues.append(
                            f"line={getattr(node, 'lineno', '?')}: "
                            f"undefined_geometry_point:{name}"
                        )
        elif isinstance(node, ast.BinOp):
            if isinstance(
                node.op, (ast.Div, ast.FloorDiv, ast.Mod)
            ) and _is_zero_literal(node.right):
                issues.append(f"line={getattr(node, 'lineno', '?')}: division_by_zero")

    return _dedupe_guard_issues(issues)


def _bound_names_for_guard(tree: ast.AST) -> set[str]:
    bound = {"self", "cls"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            bound.add(node.id)
        elif isinstance(node, ast.arg):
            bound.add(node.arg)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                bound.add(alias.asname or alias.name.split(".", 1)[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name != "*":
                    bound.add(alias.asname or alias.name)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(node.name)
    return bound


def _ast_full_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _ast_full_name(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    return ""


def _is_float_nan_call(node: ast.Call, call_name: str) -> bool:
    if call_name != "float" or not node.args:
        return False
    first = node.args[0]
    if not isinstance(first, ast.Constant) or not isinstance(first.value, str):
        return False
    return first.value.strip().lower() in {"nan", "+nan", "-nan"}


def _load_names_in_positional_args(node: ast.Call) -> set[str]:
    names: set[str] = set()

    class ArgNameVisitor(ast.NodeVisitor):
        def visit_Call(self, call: ast.Call) -> None:
            # For nested geometry calls such as Angle(Line(Q, A), Line(Q, B)),
            # the callee name (Line) is a constructor, not a point variable.
            for nested_arg in call.args:
                self.visit(nested_arg)
            for keyword in call.keywords:
                if keyword.value is not None:
                    self.visit(keyword.value)

        def visit_Name(self, name: ast.Name) -> None:
            if isinstance(name.ctx, ast.Load):
                names.add(name.id)

    visitor = ArgNameVisitor()
    for arg in node.args:
        visitor.visit(arg)
    return names


def _is_unbound_geometry_point_name(name: str, bound_names: set[str]) -> bool:
    if name in bound_names:
        return False
    if name in GEOMETRY_ALLOWED_POINT_NAMES:
        return False
    if name in dir(builtins):
        return False
    return bool(name and name[0].isupper())


def _is_zero_literal(node: ast.AST) -> bool:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value) == 0.0
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        return _is_zero_literal(node.operand)
    return False


def _dedupe_guard_issues(issues: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for issue in issues:
        if issue in seen:
            continue
        seen.add(issue)
        deduped.append(issue)
    return deduped
