"""Global fallback closure for generated ``self.<helper>()`` calls.

Generated Manim scenes often invent small instance helpers and then forget to
define them. This module keeps that repair generic: infer broad helper intent
from the method name and call context, then inject executable BaseConfigScene
methods before render. It intentionally avoids topic-specific geometry.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Optional


_IGNORED_SELF_METHODS = {
    "add",
    "add_fixed_in_frame_mobjects",
    "add_fixed_orientation_mobjects",
    "bring_to_front",
    "clear",
    "clamp_to_canvas",
    "construct",
    "embed",
    "fit_to_canvas",
    "get_layout_area",
    "get_mobjects",
    "get_time",
    "layout_canvas",
    "move_camera",
    "narrate",
    "next_section",
    "place_non_overlapping",
    "play",
    "play_voiceover",
    "remove",
    "render",
    "safe_math_box",
    "safe_text_box",
    "set_camera_orientation",
    "setup",
    "setup_layout",
    "tear_down",
    "wait",
    "wait_until_bookmark",
}

_REPAIRABLE_PREFIXES = (
    "build_",
    "calc_",
    "compute_",
    "create_",
    "draw_",
    "get_",
    "make_",
)

_POINT_MARKERS = (
    "anchor",
    "center",
    "coord",
    "intersection",
    "point",
    "position",
    "vertex",
    "vertices",
)
_LAYOUT_MARKERS = ("column", "columns", "grid", "layout", "panel", "row", "table")
_TEXT_MARKERS = ("caption", "formula", "label", "line", "text", "title")
_CONTENT_CARD_HELPERS = {
    "make_card",
    "make_sentence_card",
    "create_sentence_card",
    "make_step_card",
    "make_relation_card",
}
_CONTENT_LINE_HELPERS = {
    "get_single_line_sentence",
}
_VERTICAL_DIVISION_SELF_HELPERS = {
    "create_division_elements",
    "create_division_grid",
    "create_division_layout",
    "create_division_mobject",
    "create_division_mobjects",
    "create_long_division",
    "get_division_grid",
    "get_division_group",
    "get_division_mobjects",
    "make_division_layout",
}


@dataclass(slots=True)
class _SelfHelperUse:
    name: str
    contexts: set[str] = field(default_factory=set)
    unpack_count: int = 0
    assigned_names: set[str] = field(default_factory=set)
    subscript_keys: set[str] = field(default_factory=set)



__all__ = [name for name in globals() if name.startswith("_")]

