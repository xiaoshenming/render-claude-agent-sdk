"""Focused pre-render utilities retained by explicit callers.

The historical monolithic mutation pipeline has been removed. Modules in this
package must be imported directly and must not recreate a catch-all repair loop.
"""
