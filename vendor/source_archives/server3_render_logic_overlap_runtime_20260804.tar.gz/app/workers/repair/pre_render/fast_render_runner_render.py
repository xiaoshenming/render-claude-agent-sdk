"""Production per-scene render-before-repair loop for generate_stream code."""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Mapping
from app.workers.repair.pre_render.fast_pool_summary import pool_summary, pool_summary_markdown
from app.workers.repair.pre_render.pool_case_loader import load_pool_cases
from app.workers.repair.pre_render.fast_render_llm import (
    openai_protocol_repair_client as _openai_protocol_repair_client,
    _chat_completions_url,
    stream_delta_content as _stream_delta_content,
)
from app.workers.repair.pre_render.fast_render_validation import (
    missing_base_name as _missing_base_name,
    scene_base_reference_errors as _scene_base_reference_errors,
    validate_repair_candidate as _validate_repair_candidate,
)


from app.repair_lab.video_render import _scene_class_names, run_manim_docker_render


RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
CaseRunner = Callable[..., Mapping[str, Any]]



from . import fast_render_runner_cases as _cases
globals().update({k: v for k, v in vars(_cases).items() if k not in {"__builtins__"}})

def _run_pool_case(**kwargs: Any) -> dict[str, Any]:
    return run_file(
        source_path=kwargs["source_path"],
        out_dir=kwargs["out_dir"],
        max_rounds=kwargs["max_rounds"],
        workers=kwargs["workers"],
        scene_names=kwargs.get("scene_names"),
        image=kwargs.get("image"),
        network=kwargs.get("network"),
        timeout_sec=kwargs.get("timeout_sec"),
        render_fn=kwargs.get("render_fn") or run_manim_docker_render,
        repair_client=kwargs.get("repair_client"),
    )
def _render_scene(
    *,
    source_path: Path,
    scene_name: str,
    out_dir: Path,
    image: str | None,
    network: str | None,
    timeout_sec: int | None,
    render_fn: RenderFn,
) -> dict[str, Any]:
    try:
        check = dict(
            render_fn(
                script_path=source_path,
                scene_name=scene_name,
                output_dir=out_dir,
                image=image,
                network=network,
                timeout_sec=timeout_sec,
            ),
        )
    except Exception as exc:  # noqa: BLE001 - convert probe crashes into repair feedback.
        out_dir.mkdir(parents=True, exist_ok=True)
        return {
            "render_ok": False,
            "returncode": None,
            "mp4": "",
            "mp4_bytes": 0,
            "log": "",
            "check_json": "",
            "errors": [f"render_probe_error:{type(exc).__name__}:{exc}"],
            "scene_name": scene_name,
        }
    check["scene_name"] = scene_name
    return {
        "render_ok": bool(check.get("render_ok")),
        "returncode": check.get("returncode"),
        "mp4": str(check.get("mp4") or ""),
        "mp4_bytes": int(check.get("mp4_bytes") or 0),
        "log": str(check.get("log") or ""),
        "check_json": str(check.get("check_json") or ""),
        "errors": [str(item) for item in check.get("errors", []) or []],
    }
def _render_all(
    *,
    source_path: Path,
    scene_names: list[str],
    out_dir: Path,
    workers: int,
    image: str | None,
    network: str | None,
    timeout_sec: int | None,
    render_fn: RenderFn,
) -> dict[str, dict[str, Any]]:
    max_workers = max(1, int(workers or 1))
    if max_workers == 1:
        return {
            scene: _render_scene(
                source_path=source_path,
                scene_name=scene,
                out_dir=out_dir / _safe_path_name(scene),
                image=image,
                network=network,
                timeout_sec=timeout_sec,
                render_fn=render_fn,
            )
            for scene in scene_names
        }
    results: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_map = {
            pool.submit(
                _render_scene,
                source_path=source_path,
                scene_name=scene,
                out_dir=out_dir / _safe_path_name(scene),
                image=image,
                network=network,
                timeout_sec=timeout_sec,
                render_fn=render_fn,
            ): scene
            for scene in scene_names
        }
        for future in as_completed(future_map):
            results[future_map[future]] = future.result()
    return {scene: results[scene] for scene in scene_names}

