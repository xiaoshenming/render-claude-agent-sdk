"""AST spans and generated Manim compatibility helper contracts."""

from __future__ import annotations

import ast
import re


def _call_name(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _line_offsets(code: str) -> list[int]:
    offsets = [0]
    for match in re.finditer("\n", code):
        offsets.append(match.end())
    return offsets


def _keyword_span(
    keyword: ast.keyword, line_offsets: list[int]
) -> tuple[int, int] | None:
    if not all(
        hasattr(keyword, attr)
        for attr in ("lineno", "col_offset", "end_lineno", "end_col_offset")
    ):
        return None
    return (
        line_offsets[keyword.lineno - 1] + keyword.col_offset,
        line_offsets[keyword.end_lineno - 1] + keyword.end_col_offset,
    )


def _keyword_removal_span(code: str, start: int, end: int) -> tuple[int, int]:
    left = start
    while left > 0 and code[left - 1] in " \t":
        left -= 1
    if left > 0 and code[left - 1] == ",":
        return left - 1, end

    right = end
    while right < len(code) and code[right] in " \t":
        right += 1
    if right < len(code) and code[right] == ",":
        return start, right + 1
    return start, end


def _call_func_name_span(
    func: ast.AST, line_offsets: list[int]
) -> tuple[int, int] | None:
    if isinstance(func, ast.Name):
        return (
            line_offsets[func.lineno - 1] + func.col_offset,
            line_offsets[func.end_lineno - 1] + func.end_col_offset,
        )
    if isinstance(func, ast.Attribute):
        end = line_offsets[func.end_lineno - 1] + func.end_col_offset
        return end - len(func.attr), end
    return None


def _helper_insert_position(code: str) -> int:
    class_match = re.search(r"(?m)^class\s+\w+", code)
    if class_match:
        return class_match.start()
    return 0


def _replace_method_body_containing(
    code: str,
    method_name: str,
    markers: tuple[str, ...],
    replacement_body: list[str],
) -> str:
    lines = code.splitlines()
    pattern = re.compile(rf"^(?P<indent>\s*)def\s+{re.escape(method_name)}\s*\(")
    for index, line in enumerate(lines):
        match = pattern.match(line)
        if not match:
            continue
        indent = match.group("indent")
        end = index + 1
        while end < len(lines):
            candidate = lines[end]
            if candidate.strip() and len(candidate) - len(candidate.lstrip()) <= len(
                indent
            ):
                break
            end += 1
        method_text = "\n".join(lines[index:end])
        if not all(marker in method_text for marker in markers):
            continue
        replacement = [f"{indent}{body}" if body else "" for body in replacement_body]
        lines[index:end] = replacement
        suffix = "\n" if code.endswith("\n") else ""
        return "\n".join(lines) + suffix
    return code


_LABEL_ARC_METHOD_LINES = [
    "def get_label_arc(self, center, point, angle, radius=None, color=None, stroke_width=2, **_kwargs):",
    "    c = np.array(center, dtype=float)",
    "    p = np.array(point, dtype=float)",
    "    delta = p - c",
    "    resolved_radius = radius if radius is not None else np.linalg.norm(delta[:2])",
    "    resolved_radius = max(0.05, float(resolved_radius or 0.05))",
    "    start_angle = float(np.arctan2(delta[1], delta[0]))",
    '    arc_color = color or getattr(self, "ANNOTATION_COLOR", globals().get("YELLOW", WHITE))',
    "    return Arc(",
    "        radius=resolved_radius,",
    "        start_angle=start_angle,",
    "        angle=float(angle),",
    "        arc_center=c,",
    "        color=arc_color,",
    "        stroke_width=float(stroke_width or 2),",
    "    )",
]


_OUTSIDE_LABEL_POS_METHOD_LINES = [
    "def get_outside_label_pos(self, point, center, distance=0.28, **_kwargs):",
    "    p = np.array(point, dtype=float)",
    "    c = np.array(center, dtype=float)",
    "    direction = p - c",
    "    norm = np.linalg.norm(direction[:2])",
    "    if norm < 1e-6:",
    '        direction = globals().get("UP", np.array([0.0, 1.0, 0.0]))',
    "    else:",
    "        direction = direction / norm",
    "    return p + direction * distance",
]


_CYLINDER_MOBJECT_HELPER = """
class CylinderMobject(VGroup):
    def __init__(self, radius=1.0, height=2.0, color=BLUE, **kwargs):
        super().__init__()
        radius = float(radius)
        height = float(height)
        stroke_width = kwargs.get("stroke_width", 2)
        fill_opacity = kwargs.get("fill_opacity", 0.08)
        self.top_ellipse = Ellipse(
            width=2 * radius,
            height=0.35,
            color=color,
            stroke_width=stroke_width,
            fill_color=color,
            fill_opacity=fill_opacity,
        ).shift(UP * height / 2)
        self.bottom_ellipse = Ellipse(
            width=2 * radius,
            height=0.35,
            color=color,
            stroke_width=stroke_width,
            fill_color=color,
            fill_opacity=fill_opacity,
        ).shift(DOWN * height / 2)
        self.left_side = Line(
            LEFT * radius + UP * height / 2,
            LEFT * radius + DOWN * height / 2,
            color=color,
            stroke_width=stroke_width,
        )
        self.right_side = Line(
            RIGHT * radius + UP * height / 2,
            RIGHT * radius + DOWN * height / 2,
            color=color,
            stroke_width=stroke_width,
        )
        self.add(self.top_ellipse, self.bottom_ellipse, self.left_side, self.right_side)
""".strip()


_CONE_MOBJECT_HELPER = """
class ConeMobject(VGroup):
    def __init__(self, radius=1.0, height=2.0, color=ORANGE, **kwargs):
        super().__init__()
        radius = float(radius)
        height = float(height)
        stroke_width = kwargs.get("stroke_width", 2)
        fill_opacity = kwargs.get("fill_opacity", 0.08)
        self._apex_marker = Dot(UP * height / 2, radius=0.001, fill_opacity=0)
        self.bottom_ellipse = Ellipse(
            width=2 * radius,
            height=0.35,
            color=color,
            stroke_width=stroke_width,
            fill_color=color,
            fill_opacity=fill_opacity,
        ).shift(DOWN * height / 2)
        self.left_side = Line(
            LEFT * radius + DOWN * height / 2,
            self._apex_marker.get_center(),
            color=color,
            stroke_width=stroke_width,
        )
        self.right_side = Line(
            RIGHT * radius + DOWN * height / 2,
            self._apex_marker.get_center(),
            color=color,
            stroke_width=stroke_width,
        )
        self.add(self.bottom_ellipse, self.left_side, self.right_side, self._apex_marker)

    @property
    def apex(self):
        return self._apex_marker.get_center()
""".strip()
