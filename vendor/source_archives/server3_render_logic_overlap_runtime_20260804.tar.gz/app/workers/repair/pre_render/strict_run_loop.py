"""Strict pre-render repair loop implementation."""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any
from app.repair_lab.video_render import _scene_class_names
from app.repair_lab.video_render import run_manim_docker_render
from typing import Callable, Mapping
RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
def run_file(
    *,
    source_path: str | Path,
    out_dir: str | Path,
    max_rounds: int = 3,
    workers: int = 4,
    scene_names: list[str] | None = None,
    image: str | None = None,
    network: str | None = None,
    timeout_sec: int | None = None,
    render_fn: RenderFn = run_manim_docker_render,
    repair_client: RepairClient | None = None,
) -> dict[str, Any]:

    from app.workers.repair.pre_render.strict_block_repair import (
        _normalize_render_contracts, _render_selected, _failures_from_checks,
        _update_ledger, _round_record, _common_root_failure_context, _write_json,
        _parse_block_patch_payload, _apply_common_root_patches, _apply_failure_scene_patches,
        _validate_repair_candidate, _summary, _is_non_repairable_render_failure,
        _missing_repair_client, _dedupe,
    )
    started = time.monotonic()
    root = Path(out_dir)
    root.mkdir(parents=True, exist_ok=True)
    source = Path(source_path)
    current_path = root / "current.py"
    current_code = source.read_text(encoding="utf-8", errors="ignore")
    current_code, source_contract_repairs = _normalize_render_contracts(current_code)
    current_path.write_text(current_code, encoding="utf-8")
    (root / "source.py").write_text(current_code, encoding="utf-8")
    scenes = scene_names or _scene_class_names(current_code)
    if not scenes:
        summary = _summary(
            root=root,
            source=source,
            status="no_scenes_found",
            scenes=[],
            checks={},
            llm_call_count=0,
            repair_round_count=0,
            render_round_count=0,
            rejected_repair_count=0,
            rejected_repair_reasons=[],
            common_root_repair_count=0,
            source_contract_repairs=source_contract_repairs,
            started=started,
            max_rounds=max_rounds,
        )
        _write_json(root / "summary.json", summary)
        return summary
    repair_client = repair_client or _missing_repair_client
    ledger: dict[str, dict[str, Any]] = {
        scene: {"scene_name": scene, "render_ok": False, "dirty": True}
        for scene in scenes
    }
    validation_feedback: list[str] = []
    rejected_repair_count = 0
    rejected_repair_reasons: list[str] = []
    repair_round_count = 0
    llm_call_count = 0
    common_root_repair_count = 0
    render_round_count = 0
    terminal_status = ""
    repair_log: list[dict[str, Any]] = []
    round_log: list[dict[str, Any]] = []
    checks = _render_selected(
        source_path=current_path,
        scene_names=scenes,
        out_dir=root / "checks" / "round_00_full",
        workers=workers,
        image=image,
        network=network,
        timeout_sec=timeout_sec,
        render_fn=render_fn,
    )
    render_round_count += 1
    _update_ledger(ledger, checks)
    failures = _failures_from_checks(scenes, checks)
    round_log.append(_round_record(0, scenes, failures, scope="full"))
    for round_index in range(1, max(0, int(max_rounds)) + 1):
        if not failures:
            break
        non_repairable = [
            failure
            for failure in failures
            if _is_non_repairable_render_failure(failure["error_summary"])
        ]
        if non_repairable:
            terminal_status = "non_repairable_render_probe_error"
            repair_log.append(
                {
                    "round_index": round_index,
                    "accepted": False,
                    "skipped": True,
                    "skip_reason": terminal_status,
                    "failures": failures,
                }
            )
            break
        repair_dir = root / "repairs" / f"round_{round_index:02d}"
        repair_dir.mkdir(parents=True, exist_ok=True)
        before = current_path.read_text(encoding="utf-8")
        common_root_context = _common_root_failure_context(
            source=before,
            scene_names=scenes,
            failures=failures,
        )
        repair_failures = (
            [common_root_context]
            if common_root_context
            else _failures_with_scene_sources(before, failures)
        )
        request_payload = {
            "round_index": round_index,
            "failures": repair_failures,
            "validation_feedback": validation_feedback,
            "repair_mode_required": "block_patch",
            "editable_scope": (
                "common_root_helper_or_module_contract"
                if common_root_context
                else "failed_scene_or_direct_helper_only"
            ),
        }
        _write_json(repair_dir / "repair_request.json", request_payload)
        (repair_dir / "before.py").write_text(before, encoding="utf-8")
        try:
            llm_call_count += 1
            response = repair_client(
                source=before,
                failures=request_payload["failures"],
                validation_feedback=validation_feedback,
                round_index=round_index,
                max_rounds=max_rounds,
            )
            payload = _parse_block_patch_payload(response)
            if common_root_context:
                patched_code, patch_meta = _apply_common_root_patches(
                    source=before,
                    scene_names=scenes,
                    context=common_root_context,
                    payload=payload,
                )
            else:
                patched_code, patch_meta = _apply_failure_scene_patches(
                    source=before,
                    failures=failures,
                    payload=payload,
                )
            validation_errors = _validate_repair_candidate(
                patched_code,
                required_scene_names=scenes,
            )
            if validation_errors:
                raise _RejectedRepair(validation_errors, metadata=patch_meta)
        except _RejectedRepair as exc:
            rejected_repair_count += 1
            rejected_repair_reasons.extend(exc.reasons)
            validation_feedback = [
                f"repair_response_rejected:{reason}" for reason in exc.reasons
            ]
            _write_json(
                repair_dir / "repair_validation.json",
                {
                    "accepted": False,
                    "errors": exc.reasons,
                    "metadata": exc.metadata,
                },
            )
            (repair_dir / "after.py").write_text(before, encoding="utf-8")
            repair_log.append(
                {
                    "round_index": round_index,
                    "accepted": False,
                    "failures": failures,
                    "validation_errors": exc.reasons,
                }
            )
            continue
        except Exception as exc:  # noqa: BLE001 - LLM/provider errors feed next round.
            reason = f"repair_client_error:{type(exc).__name__}:{exc}"
            rejected_repair_count += 1
            rejected_repair_reasons.append(reason)
            validation_feedback = [reason]
            _write_json(
                repair_dir / "repair_validation.json",
                {"accepted": False, "errors": [reason]},
            )
            (repair_dir / "after.py").write_text(before, encoding="utf-8")
            repair_log.append(
                {
                    "round_index": round_index,
                    "accepted": False,
                    "failures": failures,
                    "validation_errors": [reason],
                }
            )
            continue
        repair_round_count += 1
        if common_root_context:
            common_root_repair_count += 1
        validation_feedback = []
        current_path.write_text(patched_code, encoding="utf-8")
        (repair_dir / "after.py").write_text(patched_code, encoding="utf-8")
        _write_json(
            repair_dir / "repair_validation.json",
            {"accepted": True, "errors": [], "metadata": patch_meta},
        )
        repair_log.append(
            {
                "round_index": round_index,
                "accepted": True,
                "failures": failures,
                "patched_scenes": patch_meta.get("patched_scenes") or [],
                "patched_helpers": patch_meta.get("patched_helpers") or [],
                "repair_scope": patch_meta.get("repair_scope") or "",
            }
        )
        dirty_scenes = sorted(
            set(patch_meta.get("patched_scenes") or [])
            or {failure["scene_name"] for failure in failures}
        )
        dirty_checks = _render_selected(
            source_path=current_path,
            scene_names=dirty_scenes,
            out_dir=root / "checks" / f"round_{round_index:02d}_dirty",
            workers=workers,
            image=image,
            network=network,
            timeout_sec=timeout_sec,
            render_fn=render_fn,
        )
        render_round_count += 1
        _update_ledger(ledger, dirty_checks)
        failures = _failures_from_checks(dirty_scenes, dirty_checks)
        round_log.append(_round_record(round_index, dirty_scenes, failures, scope="dirty"))
        if failures:
            continue
        final_checks = _render_selected(
            source_path=current_path,
            scene_names=scenes,
            out_dir=root / "checks" / f"round_{round_index:02d}_final_confirm",
            workers=workers,
            image=image,
            network=network,
            timeout_sec=timeout_sec,
            render_fn=render_fn,
        )
        render_round_count += 1
        _update_ledger(ledger, final_checks)
        failures = _failures_from_checks(scenes, final_checks)
        round_log.append(_round_record(round_index, scenes, failures, scope="final_confirm"))
    final_failed = [scene for scene in scenes if not bool(ledger[scene].get("render_ok"))]
    status = (
        "all_scenes_render_ok"
        if not final_failed
        else terminal_status or "render_failed_after_max_rounds"
    )
    final_path = root / "final.py"
    final_path.write_text(current_path.read_text(encoding="utf-8"), encoding="utf-8")
    _write_json(root / "repair_log.json", {"rounds": round_log, "repairs": repair_log})
    (root / "per_scene_results.jsonl").write_text(
        "".join(
            json.dumps({"scene_name": scene, **ledger[scene]}, ensure_ascii=False) + "\n"
            for scene in scenes
        ),
        encoding="utf-8",
    )
    summary = _summary(
        root=root,
        source=source,
        status=status,
        scenes=scenes,
        checks=ledger,
        llm_call_count=llm_call_count,
        repair_round_count=repair_round_count,
        render_round_count=render_round_count,
        rejected_repair_count=rejected_repair_count,
        rejected_repair_reasons=_dedupe(rejected_repair_reasons),
        common_root_repair_count=common_root_repair_count,
        source_contract_repairs=source_contract_repairs,
        started=started,
        max_rounds=max_rounds,
    )
    summary["final_path"] = str(final_path)
    summary["failed_scenes"] = final_failed
    summary["repair_strategy"] = "strict_block_patch"
    summary["compatibility_patches_enabled"] = bool(source_contract_repairs)
    _write_json(root / "summary.json", summary)
    return summary
