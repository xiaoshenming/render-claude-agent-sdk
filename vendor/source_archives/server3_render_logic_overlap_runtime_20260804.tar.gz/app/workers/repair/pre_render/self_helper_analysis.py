from __future__ import annotations

import ast
import re
from .self_helper_patterns import *

def _collect_defined_methods(tree: ast.AST) -> set[str]:
    methods: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        for child in node.body:
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                methods.add(child.name)
    return methods

def _collect_missing_self_calls(
    tree: ast.AST,
    defined_methods: set[str],
) -> dict[str, _SelfHelperUse]:
    parents: dict[ast.AST, ast.AST] = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parents[child] = node

    missing: dict[str, _SelfHelperUse] = {}
    for node in ast.walk(tree):
        if (
            not isinstance(node, ast.Call)
            or not isinstance(node.func, ast.Attribute)
            or not isinstance(node.func.value, ast.Name)
            or node.func.value.id != "self"
        ):
            continue
        name = node.func.attr
        if not _is_repairable_self_helper(name, defined_methods):
            continue
        item = missing.setdefault(name, _SelfHelperUse(name=name))
        item.contexts.update(_call_contexts(node, parents))
        item.assigned_names.update(_assignment_target_names(node, parents))
        item.unpack_count = max(item.unpack_count, _assignment_unpack_count(node, parents))
    subscript_keys_by_name = _subscript_keys_by_name(tree)
    for item in missing.values():
        for assigned_name in item.assigned_names:
            keys = subscript_keys_by_name.get(assigned_name)
            if keys:
                item.contexts.add("subscript")
                item.subscript_keys.update(keys)
    return missing

def _is_repairable_self_helper(name: str, defined_methods: set[str]) -> bool:
    if name in defined_methods or name in _IGNORED_SELF_METHODS:
        return False
    if name.startswith("_") or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        return False
    return name.startswith(_REPAIRABLE_PREFIXES)

def _assignment_unpack_count(node: ast.Call, parents: dict[ast.AST, ast.AST]) -> int:
    current: ast.AST = node
    while current in parents:
        owner = parents[current]
        if isinstance(owner, ast.Assign) and current is owner.value:
            for target in owner.targets:
                if isinstance(target, (ast.Tuple, ast.List)):
                    return len(target.elts)
            return 0
        current = owner
    return 0

def _assignment_target_names(node: ast.Call, parents: dict[ast.AST, ast.AST]) -> set[str]:
    current: ast.AST = node
    while current in parents:
        owner = parents[current]
        if isinstance(owner, ast.Assign) and current is owner.value:
            names: set[str] = set()
            for target in owner.targets:
                names.update(_target_names(target))
            return names
        if isinstance(owner, ast.AnnAssign) and current is owner.value:
            return set(_target_names(owner.target))
        current = owner
    return set()

def _target_names(target: ast.AST) -> list[str]:
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        names: list[str] = []
        for item in target.elts:
            names.extend(_target_names(item.value if isinstance(item, ast.Starred) else item))
        return names
    return []

def _subscript_keys_by_name(tree: ast.AST) -> dict[str, set[str]]:
    keys: dict[str, set[str]] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Subscript) or not isinstance(node.value, ast.Name):
            continue
        key = _constant_subscript_key(node.slice)
        if key is None:
            continue
        keys.setdefault(node.value.id, set()).add(key)
    return keys

def _constant_subscript_key(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None

def _call_contexts(node: ast.Call, parents: dict[ast.AST, ast.AST]) -> set[str]:
    contexts: set[str] = set()
    current: ast.AST = node
    for _ in range(5):
        owner = parents.get(current)
        if owner is None:
            break
        if isinstance(owner, ast.Call):
            name = _call_name(owner.func)
            if name:
                contexts.add(f"arg:{name}")
        elif isinstance(owner, ast.Subscript):
            contexts.add("subscript")
        elif isinstance(owner, ast.Assign):
            for target in owner.targets:
                if isinstance(target, (ast.Tuple, ast.List)):
                    contexts.add("tuple_unpack")
        current = owner
    return contexts

def _call_name(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""

def _helper_kind(use: _SelfHelperUse) -> str:
    name = use.name.lower()
    if name in _VERTICAL_DIVISION_SELF_HELPERS:
        return "vertical_division"
    if name in _CONTENT_CARD_HELPERS:
        return "content_card"
    if name in _CONTENT_LINE_HELPERS:
        return "content_line"
    if _needs_geometry_object_dict(use):
        return "geometry_dict"
    if use.unpack_count >= 2:
        return "point_data"
    if "subscript" in use.contexts:
        return "point_data"
    if any(marker in name for marker in ("data", "dict", "geometry", "map", "points", "vertices", "intersections")):
        return "point_data"
    if any(ctx in use.contexts for ctx in ("arg:Dot", "arg:Line", "arg:Polygon", "arg:move_to")):
        return "point"
    if any(marker in name for marker in _POINT_MARKERS):
        return "point"
    if any(marker in name for marker in _LAYOUT_MARKERS):
        return "layout"
    if any(marker in name for marker in _TEXT_MARKERS):
        return "text"
    if any(ctx in use.contexts for ctx in ("arg:Dot", "arg:Line", "arg:Polygon")):
        return "point_data"
    return "visual"

def _needs_geometry_object_dict(use: _SelfHelperUse) -> bool:
    object_keys = {
        "dots",
        "labels",
        "ticks",
        "group",
        "geo_group",
        "dot_A",
        "dot_B",
        "dot_C",
        "dot_M",
        "dot_N",
        "label_A",
        "label_B",
        "label_C",
        "label_M",
        "label_N",
    }
    if use.subscript_keys & object_keys:
        return True
    if any(key.startswith("line_") for key in use.subscript_keys):
        return True
    name = use.name.lower()
    return name in {"draw_geometry", "create_geometry", "create_geometry_model"}

