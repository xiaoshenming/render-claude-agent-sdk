"""AST helpers for setup-layout compatibility repairs."""

from __future__ import annotations

import ast
import re
from typing import Sequence


LAYOUT_SETUP_REQUIRED_ATTRS = {
    "full_canvas",
    "layout_canvas",
    "layout_zones",
    "safe_text_box",
    "safe_math_box",
    "fit_to_canvas",
    "clamp_to_canvas",
}


def class_can_call_setup_layout(node: ast.ClassDef) -> bool:
    if any(isinstance(member, ast.FunctionDef) and member.name == "setup_layout" for member in node.body):
        return True
    for base in node.bases:
        if isinstance(base, ast.Name) and base.id == "BaseConfigScene":
            return True
        if isinstance(base, ast.Attribute) and base.attr == "BaseConfigScene":
            return True
    return False


def construct_has_setup_layout_call(member: ast.FunctionDef) -> bool:
    for child in ast.walk(member):
        if not isinstance(child, ast.Call):
            continue
        func = child.func
        if (
            isinstance(func, ast.Attribute)
            and func.attr == "setup_layout"
            and isinstance(func.value, ast.Name)
            and func.value.id == "self"
        ):
            return True
    return False


def first_layout_contract_usage_line(member: ast.FunctionDef) -> int | None:
    first: int | None = None
    for child in ast.walk(member):
        if not isinstance(child, ast.Attribute):
            continue
        if child.attr not in LAYOUT_SETUP_REQUIRED_ATTRS:
            continue
        if not isinstance(child.value, ast.Name) or child.value.id != "self":
            continue
        lineno = int(getattr(child, "lineno", 0) or 0)
        if lineno and (first is None or lineno < first):
            first = lineno
    return first


def body_indent(lines: Sequence[str], member: ast.FunctionDef) -> str:
    for statement in member.body:
        try:
            line = lines[max(0, int(statement.lineno) - 1)]
        except (IndexError, TypeError, ValueError):
            continue
        match = re.match(r"^(\s*)", line)
        if match and line.strip():
            return match.group(1)
    return " " * (int(getattr(member, "col_offset", 0) or 0) + 4)
