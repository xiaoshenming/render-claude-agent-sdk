from __future__ import annotations

from . import self_helper_analysis as _analysis
from . import self_helper_generation as _generation
from . import self_helper_vertical as _vertical

globals().update({k: v for _module in (_analysis, _generation, _vertical) for k, v in vars(_module).items() if k not in {"__builtins__"}})

def inject_missing_self_helper_methods(code: str) -> tuple[Optional[str], str]:
    """Inject generic BaseConfigScene methods for missing ``self.helper()`` calls."""
    if not code or "self." not in code or "class BaseConfigScene" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    defined_methods = _collect_defined_methods(tree)
    missing = _collect_missing_self_calls(tree, defined_methods)
    if not missing:
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if class_range is None:
        return None, ""
    _start, end, class_indent = class_range
    method_indent = class_indent + "    "
    body = class_indent + "        "
    helper_lines = _helper_lines(missing, indent=method_indent, body=body)
    if not helper_lines:
        return None, ""

    lines = code.splitlines()
    if end > 0 and end <= len(lines) and lines[end - 1].strip():
        helper_lines.insert(0, "")
    lines[end:end] = helper_lines
    fixed = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    names = ", ".join(sorted(missing))
    return fixed, f"global_missing_helper_repair self helper runtime closure: {names}"

