"""Runtime helper closure for generated undefined symbol calls.

Generated Manim code often invents small helper functions and then forgets to
emit their definitions. This module repairs that class by adding executable
fallback helpers before container render. It is intentionally repair-first:
the generated scene keeps its structure, while missing helper calls become
safe, renderable primitives.
"""

from __future__ import annotations

import ast
import builtins
import re
from dataclasses import dataclass, field
from typing import Optional

try:
    from app.workers.repair.static_guard import _COMMON_ALLOWED_NAMES
except Exception:  # pragma: no cover - import-time safety for isolated tools
    _COMMON_ALLOWED_NAMES = set()


_KNOWN_LOWER_MANIM_NAMES = {
    "always_redraw",
    "angle_of_vector",
    "color_gradient",
    "interpolate",
    "interpolate_color",
    "linear",
    "smooth",
    "there_and_back",
    "there_and_back_with_pause",
    "rush_from",
    "rush_into",
    "wiggle",
}

_PROJECT_CONTRACT_HELPERS = {
    "add_title",
    "clamp_to_canvas",
    "fit_to_canvas",
    "inline_math_text",
    "layout_canvas",
    "make_title",
    "narrate",
    "place_non_overlapping",
    "play_voiceover",
    "safe_math_box",
    "safe_text_box",
    "setup_layout",
    "wait_until_bookmark",
}

_IGNORED_HELPER_NAMES = (
    set(dir(builtins))
    | set(_COMMON_ALLOWED_NAMES)
    | _KNOWN_LOWER_MANIM_NAMES
    | _PROJECT_CONTRACT_HELPERS
)

_VERTICAL_DIVISION_HELPER_NAMES = {
    "create_division_grid",
    "create_division_layout",
    "create_division_mobject",
    "create_long_division",
    "make_division_layout",
}
_VERTICAL_DIVISION_CLASS_NAMES = {"VerticalDivision"}


from .undefined_symbol_analysis import *
def _vertical_division_helper_lines(calls: dict[str, _MissingCall]) -> list[str]:
    lines = [
        "def _mathpi_vertical_division_value(kwargs, names, default='?'):",
        "    for name in names:",
        "        value = kwargs.get(name)",
        "        if value is not None and str(value) != '':",
        "            return str(value)",
        "    return str(default)",
        "",
        "def _mathpi_vertical_division_digit(value, color=WHITE, font_size=40):",
        "    text = str(value if value is not None and str(value) != '' else '?')",
        "    try:",
        "        return MathTex(text, font_size=font_size, color=color)",
        "    except Exception:",
        "        return Text(text, font_size=font_size, color=color)",
        "",
        "def _mathpi_vertical_division_layout(*args, **kwargs):",
        "    color_map = kwargs.get('color_map') or {}",
        "    default_color = kwargs.get('color', kwargs.get('stroke_color', WHITE))",
        "    line_color = color_map.get('lines', default_color)",
        "    font_size = int(_mathpi_runtime_scalar(kwargs.get('font_size', 40), 40))",
        "    dividend_raw = str(kwargs.get('dividend', ''))",
        "    quotient_raw = str(kwargs.get('quotient', ''))",
        "    dividend_t_default = dividend_raw[-2] if len(dividend_raw) >= 2 else '?'",
        "    dividend_u_default = dividend_raw[-1] if len(dividend_raw) >= 1 else '?'",
        "    quotient_t_default = quotient_raw[-2] if len(quotient_raw) >= 2 else '?'",
        "    quotient_u_default = quotient_raw[-1] if len(quotient_raw) >= 1 else '?'",
        "    divisor_text = _mathpi_vertical_division_value(kwargs, ('divisor', 'divisor_text'), '3')",
        "    dividend_t_text = _mathpi_vertical_division_value(kwargs, ('dividend_t', 'dividend_tens', 'tens'), dividend_t_default)",
        "    dividend_u_text = _mathpi_vertical_division_value(kwargs, ('dividend_u', 'dividend_units', 'units'), dividend_u_default)",
        "    quotient_t_text = _mathpi_vertical_division_value(kwargs, ('quotient_t', 'quotient_tens'), quotient_t_default)",
        "    quotient_u_text = _mathpi_vertical_division_value(kwargs, ('quotient_u', 'quotient_units'), quotient_u_default)",
        "    sub1_text = _mathpi_vertical_division_value(kwargs, ('sub1', 'subtract1', 'first_sub'), '')",
        "    diff_t_text = _mathpi_vertical_division_value(kwargs, ('diff_t', 'diff_tens', 'remainder_t'), '')",
        "    diff_u_text = _mathpi_vertical_division_value(kwargs, ('diff_u', 'diff_units', 'bring_down'), dividend_u_text)",
        "    sub2_t_text = _mathpi_vertical_division_value(kwargs, ('sub2_t', 'sub2_tens', 'second_sub_t'), '')",
        "    sub2_u_text = _mathpi_vertical_division_value(kwargs, ('sub2_u', 'sub2_units', 'second_sub_u'), '')",
        "    rem_text = _mathpi_vertical_division_value(kwargs, ('rem', 'remainder'), '0')",
        "    def color_for(name):",
        "        return color_map.get(name, default_color)",
        "    divisor = _mathpi_vertical_division_digit(divisor_text, color_for('divisor'), font_size)",
        "    dividend_t = _mathpi_vertical_division_digit(dividend_t_text, color_for('dividend_t'), font_size)",
        "    dividend_u = _mathpi_vertical_division_digit(dividend_u_text, color_for('dividend_u'), font_size)",
        "    quotient_t = _mathpi_vertical_division_digit(quotient_t_text, color_for('quotient_t'), font_size)",
        "    quotient_u = _mathpi_vertical_division_digit(quotient_u_text, color_for('quotient_u'), font_size)",
        "    sub1 = _mathpi_vertical_division_digit(sub1_text, color_for('sub1'), font_size)",
        "    diff_t = _mathpi_vertical_division_digit(diff_t_text, color_for('diff_t'), font_size)",
        "    diff_u = _mathpi_vertical_division_digit(diff_u_text, color_for('diff_u'), font_size)",
        "    sub2_t = _mathpi_vertical_division_digit(sub2_t_text, color_for('sub2_t'), font_size)",
        "    sub2_u = _mathpi_vertical_division_digit(sub2_u_text, color_for('sub2_u'), font_size)",
        "    rem = _mathpi_vertical_division_digit(rem_text, color_for('rem'), font_size)",
        "    divisor.move_to(np.array([-1.15, 0.05, 0.0]))",
        "    dividend_t.move_to(np.array([-0.35, 0.05, 0.0]))",
        "    dividend_u.move_to(np.array([0.15, 0.05, 0.0]))",
        "    quotient_t.move_to(np.array([-0.35, 0.78, 0.0]))",
        "    quotient_u.move_to(np.array([0.15, 0.78, 0.0]))",
        "    sub1.move_to(np.array([-0.35, -0.48, 0.0]))",
        "    diff_t.move_to(np.array([-0.35, -1.02, 0.0]))",
        "    diff_u.move_to(np.array([0.15, -1.02, 0.0]))",
        "    sub2_t.move_to(np.array([-0.35, -1.55, 0.0]))",
        "    sub2_u.move_to(np.array([0.15, -1.55, 0.0]))",
        "    rem.move_to(np.array([0.15, -2.08, 0.0]))",
        "    bracket_vertical = Line(np.array([-0.72, 0.42, 0.0]), np.array([-0.72, -0.24, 0.0]), color=line_color)",
        "    bracket_top = Line(np.array([-0.72, 0.42, 0.0]), np.array([0.46, 0.42, 0.0]), color=line_color)",
        "    first_line = Line(np.array([-0.55, -0.22, 0.0]), np.array([0.46, -0.22, 0.0]), color=line_color)",
        "    second_line = Line(np.array([-0.55, -1.28, 0.0]), np.array([0.46, -1.28, 0.0]), color=line_color)",
        "    lines = VGroup(bracket_vertical, bracket_top, first_line, second_line)",
        "    quotient = VGroup(quotient_t, quotient_u)",
        "    dividend = VGroup(dividend_t, dividend_u)",
        "    subtraction_1 = VGroup(sub1)",
        "    remainder_step = VGroup(diff_t, diff_u)",
        "    subtraction_2 = VGroup(sub2_t, sub2_u)",
        "    group = VGroup(divisor, dividend, quotient, subtraction_1, remainder_step, subtraction_2, rem, lines)",
        "    scale = _mathpi_runtime_scalar(kwargs.get('scale', 1.0), 1.0)",
        "    if abs(scale - 1.0) > 1e-6:",
        "        group.scale(scale)",
        "    if kwargs.get('center') is not None:",
        "        group.move_to(_mathpi_runtime_point3(kwargs.get('center')))",
        "    parts = {",
        "        'divisor': divisor,",
        "        'dividend_t': dividend_t,",
        "        'dividend_u': dividend_u,",
        "        'dividend': dividend,",
        "        'quotient_t': quotient_t,",
        "        'quotient_u': quotient_u,",
        "        'quotient': quotient,",
        "        'sub1': sub1,",
        "        'diff_t': diff_t,",
        "        'diff_u': diff_u,",
        "        'sub2_t': sub2_t,",
        "        'sub2_u': sub2_u,",
        "        'rem': rem,",
        "        'remainder': rem,",
        "        'lines': lines,",
        "        'group': group,",
        "    }",
        "    return group, parts",
        "",
    ]

    for name, info in sorted(calls.items()):
        if name in _VERTICAL_DIVISION_HELPER_NAMES:
            lines.append(f"def {name}(*args, **kwargs):")
            if info.unpack_count >= 2:
                lines.append("    return _mathpi_vertical_division_layout(*args, **kwargs)")
            else:
                lines.append("    return _mathpi_vertical_division_layout(*args, **kwargs)[0]")
            lines.append("")

    if any(name in _VERTICAL_DIVISION_CLASS_NAMES for name in calls):
        lines.extend([
            "class VerticalDivision(VGroup):",
            "    def __init__(self, *args, **kwargs):",
            "        group, parts = _mathpi_vertical_division_layout(*args, **kwargs)",
            "        super().__init__(*list(group.submobjects))",
            "        self.parts = dict(parts)",
            "    def __getitem__(self, key):",
            "        if isinstance(key, str):",
            "            return self.parts[key]",
            "        return super().__getitem__(key)",
            "    def get(self, key, default=None):",
            "        return self.parts.get(key, default)",
            "",
        ])
    return lines
