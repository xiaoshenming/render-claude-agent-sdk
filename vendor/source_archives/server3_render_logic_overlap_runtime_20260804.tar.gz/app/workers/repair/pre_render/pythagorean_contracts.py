"""Deterministic contract repairs for generated Pythagorean geometry helpers."""

from __future__ import annotations

import ast
import re
from typing import Optional, Tuple


_PYTHAGOREAN_AREA_MODEL_KEYS = (
    "triangle",
    "right_angle",
    "sq_a",
    "sq_b",
    "sq_c",
    "label_a",
    "label_b",
    "label_c",
    "area_a",
    "area_b",
    "area_c",
)


def _byte_col_to_char_col(line: str, byte_col: int) -> int:
    return len(line.encode("utf-8")[:byte_col].decode("utf-8"))


def _module_alias_insert_index(code: str) -> int:
    lines = code.splitlines()
    insert_at = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith(("import ", "from ")):
            insert_at = index + 1
            continue
        if stripped.startswith(("_", "BG", "PRIMARY", "SECONDARY", "ACCENT", "TEXT")) and "=" in stripped:
            insert_at = index + 1
            continue
        break
    return insert_at


def _mathpi_pythagorean_area_model_contract_lines() -> list[str]:
    return [
        "class _MathPiPythagoreanAreaModel(VGroup):",
        "    _ORDER = (",
        "        \"triangle\", \"right_angle\",",
        "        \"sq_a\", \"sq_b\", \"sq_c\",",
        "        \"label_a\", \"label_b\", \"label_c\",",
        "        \"area_a\", \"area_b\", \"area_c\",",
        "    )",
        "",
        "    def __init__(self, parts=None):",
        "        self.parts = dict(parts or {})",
        "        mobjects = []",
        "        for key in self._ORDER:",
        "            mob = self.parts.get(key)",
        "            if hasattr(mob, \"get_center\") and mob not in mobjects:",
        "                try:",
        "                    mob.name = key",
        "                except Exception:",
        "                    pass",
        "                mobjects.append(mob)",
        "        group = self.parts.get(\"group\") or self.parts.get(\"geo_group\")",
        "        if hasattr(group, \"submobjects\"):",
        "            for mob in list(getattr(group, \"submobjects\", [])):",
        "                if hasattr(mob, \"get_center\") and mob not in mobjects:",
        "                    mobjects.append(mob)",
        "        super().__init__(*mobjects)",
        "        self.parts[\"group\"] = self",
        "        self.parts[\"geo_group\"] = self",
        "",
        "    def __getitem__(self, key):",
        "        if isinstance(key, str):",
        "            return self.parts[key]",
        "        return super().__getitem__(key)",
        "",
        "    def __setitem__(self, key, value):",
        "        if isinstance(key, str):",
        "            self.parts[key] = value",
        "            return None",
        "        raise TypeError(\"integer item assignment is not supported\")",
        "",
        "    def __contains__(self, key):",
        "        if isinstance(key, str):",
        "            return key in self.parts",
        "        return key in list(getattr(self, \"submobjects\", []))",
        "",
        "    def get(self, key, default=None):",
        "        return self.parts.get(key, default)",
        "",
        "    def keys(self):",
        "        return self.parts.keys()",
        "",
        "    def items(self):",
        "        return self.parts.items()",
        "",
        "    def as_group(self):",
        "        return self",
        "",
    ]


def _assigned_names_in_function(node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    names: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, (ast.Store, ast.Param)):
            names.add(child.id)
        elif isinstance(child, (ast.Assign, ast.AnnAssign)):
            targets = child.targets if isinstance(child, ast.Assign) else [child.target]
            for target in targets:
                for target_child in ast.walk(target):
                    if isinstance(target_child, ast.Name):
                        names.add(target_child.id)
    return names


def _value_expr(assigned: set[str], candidates: tuple[str, ...], fallback: str) -> str:
    for candidate in candidates:
        if candidate in assigned:
            return candidate
    return fallback


def _area_model_return_expr(assigned: set[str]) -> str:
    mobject_fallback = "VGroup()"
    values = {
        "A": _value_expr(assigned, ("A", "p0", "point_a"), "ORIGIN"),
        "B": _value_expr(assigned, ("B", "p1", "point_b"), "RIGHT"),
        "C": _value_expr(assigned, ("C", "p2", "point_c"), "UP"),
        "triangle": _value_expr(assigned, ("triangle", "tri", "right_triangle"), mobject_fallback),
        "right_angle": _value_expr(assigned, ("right_angle", "right_mark", "right_angle_mark"), mobject_fallback),
        "sq_a": _value_expr(assigned, ("square_a", "sq_a", "a_square"), mobject_fallback),
        "sq_b": _value_expr(assigned, ("square_b", "sq_b", "b_square"), mobject_fallback),
        "sq_c": _value_expr(assigned, ("square_c", "sq_c", "c_square", "hyp_square"), mobject_fallback),
        "label_a": _value_expr(assigned, ("side_a", "label_side_a", "label_a_side"), mobject_fallback),
        "label_b": _value_expr(assigned, ("side_b", "label_side_b", "label_b_side"), mobject_fallback),
        "label_c": _value_expr(assigned, ("side_c", "label_side_c", "label_c_side"), mobject_fallback),
        "area_a": _value_expr(assigned, ("label_a", "area_a", "area_label_a"), mobject_fallback),
        "area_b": _value_expr(assigned, ("label_b", "area_b", "area_label_b"), mobject_fallback),
        "area_c": _value_expr(assigned, ("label_c", "area_c", "area_label_c"), mobject_fallback),
        "group": _value_expr(assigned, ("model", "geo_group", "group", "full_group"), mobject_fallback),
    }
    lines = ["_MathPiPythagoreanAreaModel({"]
    for key, expr in values.items():
        lines.append(f"    {key!r}: {expr},")
    lines.append("})")
    return "\n".join(lines)


def _function_return_value_spans(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    code: str,
) -> list[tuple[int, int]]:
    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    spans: list[tuple[int, int]] = []
    for child in ast.walk(node):
        if not isinstance(child, ast.Return) or child.value is None:
            continue
        source = ast.get_source_segment(code, child.value) or ""
        if "_MathPiPythagoreanAreaModel" in source:
            continue
        lineno = getattr(child.value, "lineno", None)
        end_lineno = getattr(child.value, "end_lineno", None)
        col_offset = getattr(child.value, "col_offset", None)
        end_col_offset = getattr(child.value, "end_col_offset", None)
        if (
            lineno is None
            or end_lineno is None
            or col_offset is None
            or end_col_offset is None
        ):
            continue
        start = line_offsets[lineno - 1] + _byte_col_to_char_col(lines[lineno - 1], col_offset)
        end = line_offsets[end_lineno - 1] + _byte_col_to_char_col(lines[end_lineno - 1], end_col_offset)
        spans.append((start, end))
    return spans


def _rewrite_create_geometry_calls(code: str) -> tuple[str, int]:
    lines = code.splitlines()
    changed = 0
    pythagorean_keys = ("A", "B", "C") + _PYTHAGOREAN_AREA_MODEL_KEYS
    key_pattern = re.compile(
        r"\b(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*\[\s*['\"](?P<key>"
        + "|".join(re.escape(key) for key in pythagorean_keys)
        + r")['\"]\s*\]"
    )
    assign_pattern = re.compile(
        r"^(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*self\.create_geometry\((?P<args>[^)]*)\)\s*$"
    )
    for index, line in enumerate(lines):
        match = assign_pattern.match(line)
        if not match:
            continue
        var_name = match.group("var")
        window = "\n".join(lines[index + 1 : index + 12])
        if not any(
            key_match.group("var") == var_name
            for key_match in key_pattern.finditer(window)
        ):
            continue
        args = match.group("args")
        lines[index] = f"{match.group('indent')}{var_name} = self.create_pythagorean_area_model({args})"
        changed += 1
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), changed


def fix_pythagorean_area_model_dict_contract(code: str) -> Tuple[Optional[str], str]:
    """Normalize generated Pythagorean area helpers across dict/VGroup callers."""
    if (
        "def create_pythagorean_area_model" not in code
        or "create_pythagorean_area_model(" not in code
    ):
        return None, ""
    if not any(f'["{key}"]' in code or f"['{key}']" in code for key in ("triangle", "sq_a", "area_a", "A")):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    helper_count = 0
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name != "create_pythagorean_area_model":
            continue
        return_expr = _area_model_return_expr(_assigned_names_in_function(node))
        for start, end in _function_return_value_spans(node, code):
            replacements.append((start, end, return_expr))
            helper_count += 1

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]

    create_geometry_rewrites = 0
    if "self.create_geometry(" in current:
        current, create_geometry_rewrites = _rewrite_create_geometry_calls(current)

    if "class _MathPiPythagoreanAreaModel(VGroup)" not in current:
        lines = current.splitlines()
        insert_at = _module_alias_insert_index(current)
        helper_lines = _mathpi_pythagorean_area_model_contract_lines()
        if insert_at > 0 and lines[insert_at - 1].strip():
            helper_lines.insert(0, "")
        lines[insert_at:insert_at] = helper_lines
        current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")

    details = [f"return={helper_count}"]
    if create_geometry_rewrites:
        details.append(f"create_geometry={create_geometry_rewrites}")
    return current, "勾股面积模型合同修复: " + ", ".join(details)
