"""Runtime helper closure for generated undefined symbol calls.

Generated Manim code often invents small helper functions and then forgets to
emit their definitions. This module repairs that class by adding executable
fallback helpers before container render. It is intentionally repair-first:
the generated scene keeps its structure, while missing helper calls become
safe, renderable primitives.
"""

from __future__ import annotations

import ast
import builtins
import re
from dataclasses import dataclass, field
from typing import Optional

try:
    from app.workers.repair.static_guard import _COMMON_ALLOWED_NAMES
except Exception:  # pragma: no cover - import-time safety for isolated tools
    _COMMON_ALLOWED_NAMES = set()


_KNOWN_LOWER_MANIM_NAMES = {
    "always_redraw",
    "angle_of_vector",
    "color_gradient",
    "interpolate",
    "interpolate_color",
    "linear",
    "smooth",
    "there_and_back",
    "there_and_back_with_pause",
    "rush_from",
    "rush_into",
    "wiggle",
}

_PROJECT_CONTRACT_HELPERS = {
    "add_title",
    "clamp_to_canvas",
    "fit_to_canvas",
    "inline_math_text",
    "layout_canvas",
    "make_title",
    "narrate",
    "place_non_overlapping",
    "play_voiceover",
    "safe_math_box",
    "safe_text_box",
    "setup_layout",
    "wait_until_bookmark",
}

_IGNORED_HELPER_NAMES = (
    set(dir(builtins))
    | set(_COMMON_ALLOWED_NAMES)
    | _KNOWN_LOWER_MANIM_NAMES
    | _PROJECT_CONTRACT_HELPERS
)

_VERTICAL_DIVISION_HELPER_NAMES = {
    "create_division_grid",
    "create_division_layout",
    "create_division_mobject",
    "create_long_division",
    "make_division_layout",
}
_VERTICAL_DIVISION_CLASS_NAMES = {"VerticalDivision"}


from .undefined_symbol_analysis import *
def _runtime_support_lines(calls: dict[str, _MissingCall]) -> list[str]:
    lines: list[str] = [
        "def _mathpi_runtime_point3(value=None, fallback=ORIGIN, **_kwargs):",
        "    try:",
        "        if value is None:",
        "            return np.array(fallback, dtype=float)",
        "        arr = np.array(value, dtype=float)",
        "        if arr.ndim == 0:",
        "            return np.array([float(arr), 0.0, 0.0], dtype=float)",
        "        flat = arr.reshape(-1)",
        "        if flat.shape[0] == 2:",
        "            return np.array([flat[0], flat[1], 0.0], dtype=float)",
        "        if flat.shape[0] >= 3:",
        "            return np.array([flat[0], flat[1], flat[2]], dtype=float)",
        "    except Exception:",
        "        pass",
        "    return np.array(fallback, dtype=float)",
        "",
        "def _mathpi_runtime_scalar(value=1.0, default=1.0, **_kwargs):",
        "    try:",
        "        return float(value)",
        "    except Exception:",
        "        return float(default)",
        "",
        "def _mathpi_runtime_unit(value=None, fallback=RIGHT, **_kwargs):",
        "    vec = _mathpi_runtime_point3(value, fallback=fallback)",
        "    norm = np.linalg.norm(vec)",
        "    if norm < 1e-9:",
        "        return _mathpi_runtime_point3(fallback)",
        "    return vec / norm",
        "",
        "def _mathpi_fallback_point(*args, **kwargs):",
        "    center = kwargs.get('center', kwargs.get('origin', ORIGIN))",
        "    for value in args:",
        "        try:",
        "            return _mathpi_runtime_point3(value)",
        "        except Exception:",
        "            pass",
        "    return _mathpi_runtime_point3(center)",
        "",
        "def _mathpi_fallback_point_pair(*args, **kwargs):",
        "    center = _mathpi_runtime_point3(kwargs.get('center', ORIGIN))",
        "    radius = _mathpi_runtime_scalar(kwargs.get('radius', 1.0), 1.0)",
        "    return center + LEFT * radius, center + RIGHT * radius",
        "",
        "def _mathpi_fallback_mobject(*args, label='辅助图形', **kwargs):",
        "    if args and label == '辅助图形':",
        "        label = args[0]",
        "    color = kwargs.get('color', kwargs.get('stroke_color', BLUE))",
        "    try:",
        "        text = Text(str(label), font_size=kwargs.get('font_size', 24), color=color)",
        "    except Exception:",
        "        text = VGroup()",
        "    box = RoundedRectangle(width=2.4, height=0.9, corner_radius=0.12, color=color)",
        "    try:",
        "        text.move_to(box.get_center())",
        "    except Exception:",
        "        pass",
        "    return VGroup(box, text)",
        "",
        "class _MathPiNamedVGroup(VGroup):",
        "    def __init__(self, *mobjects, parts=None, **kwargs):",
        "        super().__init__(*mobjects, **kwargs)",
        "        self.parts = dict(parts or {})",
        "    def __getitem__(self, key):",
        "        if isinstance(key, str):",
        "            return self.parts[key]",
        "        return super().__getitem__(key)",
        "    def get(self, key, default=None):",
        "        return self.parts.get(key, default)",
        "",
        "def _mathpi_fallback_geometry_dict(*args, **kwargs):",
        "    center = _mathpi_runtime_point3(kwargs.get('center', ORIGIN))",
        "    scale = _mathpi_runtime_scalar(kwargs.get('scale', kwargs.get('side_length', 2.6)), 2.6)",
        "    A = center + LEFT * scale * 0.9 + DOWN * scale * 0.25",
        "    B = center + RIGHT * scale * 0.9 + DOWN * scale * 0.25",
        "    C = center + LEFT * scale * 0.9 + UP * scale * 0.55",
        "    D = center + RIGHT * scale * 0.9 + UP * scale * 0.55",
        "    E = center + DOWN * scale * 0.05",
        "    F = center + RIGHT * scale * 0.25 + UP * scale * 0.18",
        "    P = center + UP * scale * 0.05",
        "    G = center + LEFT * scale * 0.25 + UP * scale * 0.18",
        "    M = (A + C) / 2",
        "    N = (B + C) / 2",
        "    O = (A + B + C + D) / 4",
        "    tri_ABC = Polygon(A, B, C)",
        "    square = Polygon(A, B, D, C)",
        "    wing_ABP = Polygon(A, B, P, fill_color=BLUE, fill_opacity=0.16, stroke_width=0)",
        "    wing_ACP = Polygon(A, C, P, fill_color=ORANGE, fill_opacity=0.16, stroke_width=0)",
        "    line_AB = Line(A, B)",
        "    line_AC = Line(A, C)",
        "    line_BC = Line(B, C)",
        "    line_AD = Line(A, D)",
        "    line_BD = Line(B, D)",
        "    line_CD = Line(C, D)",
        "    line_AE = Line(A, E)",
        "    line_AF = Line(A, F)",
        "    line_AG = Line(A, G)",
        "    line_BE = Line(B, E)",
        "    line_BP = Line(B, P)",
        "    line_CP = Line(C, P)",
        "    line_CF = Line(C, F)",
        "    line_CG = Line(C, G)",
        "    line_EF = Line(E, F)",
        "    line_DE = Line(D, E)",
        "    line_CE = Line(C, E)",
        "    line_MN = Line(M, N)",
        "    dot_parts = {label: Dot(point, radius=0.045) for label, point in {'A': A, 'B': B, 'C': C, 'D': D, 'E': E, 'F': F, 'G': G, 'P': P, 'M': M, 'N': N, 'O': O}.items()}",
        "    dot_parts.update({label.lower(): dot for label, dot in list(dot_parts.items())})",
        "    dots = _MathPiNamedVGroup(*dot_parts.values(), parts=dot_parts)",
        "    label_specs = {'A': (A, DL), 'B': (B, DR), 'C': (C, UL), 'D': (D, UR), 'E': (E, DOWN), 'F': (F, RIGHT), 'G': (G, LEFT), 'P': (P, UP), 'M': (M, LEFT), 'N': (N, UP), 'O': (O, DOWN)}",
        "    label_parts = {label: MathTex(label, font_size=22).next_to(point, direction, buff=0.12) for label, (point, direction) in label_specs.items()}",
        "    label_parts.update({label.lower(): label_mob for label, label_mob in list(label_parts.items())})",
        "    labels = _MathPiNamedVGroup(*label_parts.values(), parts=label_parts)",
        "    line_parts = {'AB': line_AB, 'AC': line_AC, 'BC': line_BC, 'AD': line_AD, 'BD': line_BD, 'CD': line_CD, 'AE': line_AE, 'AF': line_AF, 'AG': line_AG, 'BE': line_BE, 'BP': line_BP, 'CP': line_CP, 'CF': line_CF, 'CG': line_CG, 'EF': line_EF, 'DE': line_DE, 'CE': line_CE, 'MN': line_MN, 'line_AB': line_AB, 'line_AC': line_AC, 'line_BC': line_BC, 'line_AD': line_AD, 'line_BD': line_BD, 'line_CD': line_CD, 'line_AE': line_AE, 'line_AF': line_AF, 'line_AG': line_AG, 'line_BE': line_BE, 'line_BP': line_BP, 'line_CP': line_CP, 'line_CF': line_CF, 'line_CG': line_CG, 'line_EF': line_EF, 'line_DE': line_DE, 'line_CE': line_CE, 'line_MN': line_MN, 'l1': line_AB, 'l2': line_CD, 'line': line_AB}",
        "    line_parts.update({key.lower(): value for key, value in list(line_parts.items())})",
        "    lines = _MathPiNamedVGroup(line_AB, line_AC, line_BC, line_AD, line_BD, line_CD, line_AE, line_AF, line_AG, line_BE, line_BP, line_CP, line_CF, line_CG, line_EF, line_DE, line_CE, line_MN, parts=line_parts)",
        "    dashed_bg = VGroup(*[line.copy().set_stroke(opacity=0.35) for line in (line_AB, line_BC, line_CD, line_AD)])",
        "    dashed_ag = line_AG.copy().set_stroke(opacity=0.35)",
        "    right_angle = VGroup(Line(A, A + RIGHT * 0.24), Line(A + RIGHT * 0.24, A + RIGHT * 0.24 + UP * 0.24), Line(A + RIGHT * 0.24 + UP * 0.24, A + UP * 0.24))",
        "    right_angles = _MathPiNamedVGroup(right_angle, parts={'A': right_angle, 'a': right_angle, 'right_angle': right_angle})",
        "    ticks = VGroup(line_MN.copy().set_stroke(width=3))",
        "    group = VGroup(square, tri_ABC, wing_ABP, wing_ACP, lines, dots, labels, right_angles, ticks)",
        "    return {",
        "        'A': A, 'B': B, 'C': C, 'D': D, 'E': E, 'F': F, 'G': G, 'P': P, 'M': M, 'N': N, 'O': O,",
        "        'points': {'A': A, 'B': B, 'C': C, 'D': D, 'E': E, 'F': F, 'G': G, 'P': P, 'M': M, 'N': N, 'O': O},",
        "        'tri_ABC': tri_ABC, 'tri_abc': tri_ABC, 'triangle': tri_ABC, 'square': square, 'wing_ABP': wing_ABP, 'wing_ACP': wing_ACP,",
        "        'line_AB': line_AB, 'line_AC': line_AC, 'line_BC': line_BC, 'line_AD': line_AD, 'line_BD': line_BD, 'line_CD': line_CD, 'line_AE': line_AE, 'line_AF': line_AF, 'line_AG': line_AG, 'line_BE': line_BE, 'line_BP': line_BP, 'line_CP': line_CP, 'line_CF': line_CF, 'line_CG': line_CG, 'line_EF': line_EF, 'line_DE': line_DE, 'line_CE': line_CE, 'line_MN': line_MN,",
        "        'line_ab': line_AB, 'line_ac': line_AC, 'line_bc': line_BC, 'line_ad': line_AD, 'line_bd': line_BD, 'line_cd': line_CD, 'line_ae': line_AE, 'line_af': line_AF, 'line_ag': line_AG, 'line_be': line_BE, 'line_bp': line_BP, 'line_cp': line_CP, 'line_cf': line_CF, 'line_cg': line_CG, 'line_ef': line_EF, 'line_de': line_DE, 'line_ce': line_CE, 'line_mn': line_MN,",
        "        'l1': line_AB, 'l2': line_CD, 'line': line_AB, 'lines': lines, 'right_angle': right_angle, 'right_angles': right_angles,",
        "        'dot_A': dot_parts['A'], 'dot_B': dot_parts['B'], 'dot_C': dot_parts['C'], 'dot_D': dot_parts['D'], 'dot_E': dot_parts['E'], 'dot_F': dot_parts['F'], 'dot_G': dot_parts['G'], 'dot_P': dot_parts['P'], 'dot_a': dot_parts['a'], 'dot_b': dot_parts['b'], 'dot_c': dot_parts['c'], 'dot_d': dot_parts['d'], 'dot_e': dot_parts['e'], 'dot_f': dot_parts['f'], 'dot_g': dot_parts['g'], 'dot_p': dot_parts['p'],",
        "        'label_A': label_parts['A'], 'label_B': label_parts['B'], 'label_C': label_parts['C'], 'label_D': label_parts['D'], 'label_E': label_parts['E'], 'label_F': label_parts['F'], 'label_G': label_parts['G'], 'label_P': label_parts['P'], 'label_a': label_parts['a'], 'label_b': label_parts['b'], 'label_c': label_parts['c'], 'label_d': label_parts['d'], 'label_e': label_parts['e'], 'label_f': label_parts['f'], 'label_g': label_parts['g'], 'label_p': label_parts['p'],",
        "        'dashed_bg': dashed_bg, 'dashed_ag': dashed_ag, 'dots': dots, 'labels': labels, 'ticks': ticks, 'group': group, 'geo_group': group,",
        "    }",
        "",
    ]

    vertical_division_calls = {
        name: info
        for name, info in calls.items()
        if name in _VERTICAL_DIVISION_HELPER_NAMES
        or name in _VERTICAL_DIVISION_CLASS_NAMES
    }
    if vertical_division_calls:
        lines.extend(_vertical_division_helper_lines(vertical_division_calls))

    if "get_tangent_point" in calls:
        lines.extend(_tangent_point_helper_lines())
    if "get_secant_points" in calls:
        lines.extend(_secant_points_helper_lines())

    for name, info in sorted(calls.items()):
        if name in {"get_tangent_point", "get_secant_points"}:
            continue
        if name in vertical_division_calls:
            continue
        lines.extend(_generic_helper_lines(name, _infer_return_kind(info)))
    return lines
