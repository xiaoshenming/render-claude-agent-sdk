"""快速预渲染的 LLM 修复协议与提示词辅助。"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Callable, Mapping


RepairClient = Callable[..., str]


def openai_protocol_repair_client(
    *,
    base_url: str,
    model: str,
    api_key: str,
    timeout_sec: int,
    require_google: bool,
) -> RepairClient:
    if not base_url:
        raise SystemExit("Missing --base-url or PRERENDER_LLM_BASE_URL")
    if not model:
        raise SystemExit("Missing --model or PRERENDER_LLM_MODEL")
    if not api_key:
        raise SystemExit("Missing PRERENDER_LLM_API_KEY")
    identity = model.lower()
    if require_google and not any(token in identity for token in ("gemini", "google")):
        raise SystemExit("Model must be a Google/Gemini model unless --allow-non-google-model is set")
    url = _chat_completions_url(base_url)

    def repair_client(
        *,
        source: str,
        failures: list[dict[str, str]],
        validation_feedback: list[str] | None = None,
        round_index: int,
        max_rounds: int,
    ) -> str:
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": repair_prompt(
                source=source,
                failures=failures,
                validation_feedback=validation_feedback or [],
                round_index=round_index,
                max_rounds=max_rounds,
            )}],
            "temperature": 0,
            "max_tokens": 65536,
            "stream": True,
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Authorization": "Bearer " + api_key, "Content-Type": "application/json"},
            method="POST",
        )
        chunks: list[str] = []
        try:
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                while True:
                    line = resp.readline()
                    if not line:
                        break
                    item = line.decode("utf-8", "ignore").strip()
                    if not item or not item.startswith("data:"):
                        continue
                    data = item[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        obj = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    delta = stream_delta_content(obj)
                    if delta:
                        chunks.append(str(delta))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "ignore")[:500]
            raise RuntimeError(f"llm_http_error:{exc.code}:{body}") from exc
        if not chunks:
            raise RuntimeError("llm_empty_response")
        return "".join(chunks)

    return repair_client


def stream_delta_content(obj: Mapping[str, Any]) -> str:
    choices = obj.get("choices") or []
    first = choices[0] if choices and isinstance(choices[0], Mapping) else {}
    delta = first.get("delta") or {}
    if not isinstance(delta, Mapping):
        return ""
    content = delta.get("content") or delta.get("reasoning_content")
    return str(content) if content else ""


def repair_prompt(
    *,
    source: str,
    failures: list[dict[str, str]],
    validation_feedback: list[str],
    round_index: int,
    max_rounds: int,
) -> str:
    failure_text = "\n\n".join(
        f"Scene: {item['scene_name']}\n错误:\n{item['error_summary']}" for item in failures
    )
    feedback_text = "\n".join(f"- {item}" for item in validation_feedback)
    feedback_block = f"\n上一轮修复响应被拒收:\n{feedback_text}\n" if feedback_text else ""
    return (
        "你是 MathPi Manim 切片渲染修复器。目标只有一个：让失败 Scene 能渲染出 MP4。\n"
        "只针对失败 Scene 的 traceback 做最小修复；不要重写无关 Scene，不要解释。\n"
        "返回完整 Python 文件源码，不要 Markdown fence。\n"
        f"修复轮次: {round_index}/{max_rounds}\n\n"
        f"失败切片与渲染错误:\n{failure_text}\n\n{feedback_block}"
        f"完整源码:\n{source}"
    )


def _chat_completions_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/chat/completions"):
        return base
    if base.endswith("/v1"):
        return base + "/chat/completions"
    return base + "/v1/chat/completions"
