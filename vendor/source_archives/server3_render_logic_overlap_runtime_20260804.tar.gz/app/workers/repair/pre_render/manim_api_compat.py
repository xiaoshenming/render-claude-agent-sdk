"""Focused Manim API compatibility repairs for generated scene code."""
# ruff: noqa: F401

from __future__ import annotations

import ast
import re
from typing import Optional

from .manim_api_compat_ast import (
    _CONE_MOBJECT_HELPER,
    _CYLINDER_MOBJECT_HELPER,
    _LABEL_ARC_METHOD_LINES,
    _OUTSIDE_LABEL_POS_METHOD_LINES,
    _call_func_name_span,
    _call_name,
    _helper_insert_position,
    _keyword_removal_span,
    _keyword_span,
    _line_offsets,
    _replace_method_body_containing,
)


def fix_manim_arrow_size_keyword(code: str) -> tuple[Optional[str], str]:
    if "arrow_size" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    line_offsets = _line_offsets(code)
    edits: list[tuple[int, int]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name(node.func) not in {"Arrow", "DoubleArrow", "CurvedArrow"}:
            continue
        for keyword in node.keywords:
            if keyword.arg != "arrow_size":
                continue
            span = _keyword_span(keyword, line_offsets)
            if span:
                edits.append(_keyword_removal_span(code, *span))

    if not edits:
        return None, ""

    current = code
    for start, end in sorted(edits, reverse=True):
        current = current[:start] + current[end:]
    if current == code:
        return None, ""
    return current, f"Manim 0.19 arrow_size参数清理: {len(edits)}处"


def fix_get_layout_area_get_center_calls(code: str) -> tuple[Optional[str], str]:
    if "get_layout_area" not in code or '.get("center"' not in code:
        return None, ""

    pattern = re.compile(
        r"self\.get_layout_area\(\s*(?P<area>\"[^\"]+\"|'[^']+')\s*\)"
        r"\.get\(\s*(?P<key>\"center\"|'center')\s*,\s*(?P<default>[^)\n]+)\)"
    )

    def _replace(match: re.Match[str]) -> str:
        return (
            f"self.layout_canvas({match.group('area')}).get("
            f"{match.group('key')}, {match.group('default').strip()})"
        )

    fixed, count = pattern.subn(_replace, code)
    if not count or fixed == code:
        return None, ""
    return fixed, f"get_layout_area().get('center')形态修复: {count}处"


def fix_fit_to_zone_alias_calls(code: str) -> tuple[Optional[str], str]:
    """Rewrite invented fit_to_zone calls to the supported fit_to_canvas helper."""
    if "fit_to_zone" not in code or re.search(r"(?m)^\s*def\s+fit_to_zone\s*\(", code):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    line_offsets = _line_offsets(code)
    edits: list[tuple[int, int, str]] = []
    changed_calls = 0
    renamed_keywords = 0
    removed_keywords = 0

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name(node.func) != "fit_to_zone":
            continue

        func_span = _call_func_name_span(node.func, line_offsets)
        if func_span:
            edits.append((*func_span, "fit_to_canvas"))
            changed_calls += 1

        has_area = any(keyword.arg == "area" for keyword in node.keywords)
        for keyword in node.keywords:
            if keyword.arg not in {"zone", "zone_name"}:
                continue
            span = _keyword_span(keyword, line_offsets)
            if not span:
                continue
            if has_area:
                start, end = _keyword_removal_span(code, *span)
                edits.append((start, end, ""))
                removed_keywords += 1
            else:
                name_start = line_offsets[keyword.lineno - 1] + keyword.col_offset
                edits.append((name_start, name_start + len(keyword.arg), "area"))
                renamed_keywords += 1

    if not edits:
        return None, ""

    current = code
    for start, end, replacement in sorted(edits, reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""

    parts = [f"调用{changed_calls}处"]
    if renamed_keywords:
        parts.append(f"zone参数改名{renamed_keywords}处")
    if removed_keywords:
        parts.append(f"重复zone参数移除{removed_keywords}处")
    return current, "fit_to_zone别名改写为fit_to_canvas: " + "，".join(parts)


def fix_clamp_to_canvas_buff_keyword(code: str) -> tuple[Optional[str], str]:
    if "clamp_to_canvas" not in code or "buff=" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    line_offsets = _line_offsets(code)
    edits: list[tuple[int, int, str]] = []
    removed = 0
    renamed = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name(node.func) != "clamp_to_canvas":
            continue
        has_padding = any(keyword.arg == "padding" for keyword in node.keywords)
        for keyword in node.keywords:
            if keyword.arg != "buff":
                continue
            span = _keyword_span(keyword, line_offsets)
            if not span:
                continue
            if has_padding:
                start, end = _keyword_removal_span(code, *span)
                edits.append((start, end, ""))
                removed += 1
            else:
                name_start = line_offsets[keyword.lineno - 1] + keyword.col_offset
                edits.append((name_start, name_start + len("buff"), "padding"))
                renamed += 1

    if not edits:
        return None, ""

    current = code
    for start, end, replacement in sorted(edits, reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    parts: list[str] = []
    if renamed:
        parts.append(f"改名{renamed}处")
    if removed:
        parts.append(f"移除重复{removed}处")
    return current, "clamp_to_canvas buff参数兼容: " + "，".join(parts)


def inject_cylinder_cone_mobject_contracts(code: str) -> tuple[Optional[str], str]:
    needs_cylinder = "CylinderMobject(" in code and "class CylinderMobject" not in code
    needs_cone = "ConeMobject(" in code and "class ConeMobject" not in code
    if not needs_cylinder and not needs_cone:
        return None, ""

    helpers: list[str] = []
    if needs_cylinder:
        helpers.append(_CYLINDER_MOBJECT_HELPER)
    if needs_cone:
        helpers.append(_CONE_MOBJECT_HELPER)

    helper_code = "\n\n".join(helpers)
    insert_at = _helper_insert_position(code)
    fixed = (
        code[:insert_at].rstrip()
        + "\n\n"
        + helper_code
        + "\n\n"
        + code[insert_at:].lstrip()
    )
    return fixed, "CylinderMobject/ConeMobject属性合同注入"


def fix_label_arc_and_outside_label_icon_fallbacks(
    code: str,
) -> tuple[Optional[str], str]:
    if "_mathpi_fallback_icon" not in code:
        return None, ""

    current = code
    changed: list[str] = []
    fixed = _replace_method_body_containing(
        current,
        "get_label_arc",
        ("Label Arc", "_mathpi_fallback_icon"),
        _LABEL_ARC_METHOD_LINES,
    )
    if fixed != current:
        current = fixed
        changed.append("get_label_arc路径兜底修复")

    fixed = _replace_method_body_containing(
        current,
        "get_outside_label_pos",
        ("Outside Label Pos", "_mathpi_fallback_icon"),
        _OUTSIDE_LABEL_POS_METHOD_LINES,
    )
    if fixed != current:
        current = fixed
        changed.append("get_outside_label_pos坐标兜底修复")

    if not changed:
        return None, ""
    return current, "; ".join(changed)
