"""Production per-scene render-before-repair loop for generate_stream code."""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Mapping
from app.workers.repair.pre_render.fast_pool_summary import pool_summary, pool_summary_markdown
from app.workers.repair.pre_render.pool_case_loader import load_pool_cases
from app.workers.repair.pre_render.fast_render_llm import (
    openai_protocol_repair_client as _openai_protocol_repair_client,
    _chat_completions_url,
    stream_delta_content as _stream_delta_content,
)
from app.workers.repair.pre_render.fast_render_validation import (
    missing_base_name as _missing_base_name,
    scene_base_reference_errors as _scene_base_reference_errors,
    validate_repair_candidate as _validate_repair_candidate,
)


from app.repair_lab.video_render import _scene_class_names, run_manim_docker_render


RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
CaseRunner = Callable[..., Mapping[str, Any]]




def _load_pool_cases(pool_path: Path) -> list[dict[str, Any]]:
    return load_pool_cases(pool_path, _read_json, _scene_names_from_case)
def _scene_names_from_case(item: Mapping[str, Any]) -> list[str]:
    for key in ("scene_names", "scenes"):
        value = item.get(key)
        if isinstance(value, list):
            return [str(scene) for scene in value if str(scene).strip()]
    scene_name = item.get("scene_name")
    return [str(scene_name)] if scene_name else []
def _is_non_repairable_render_failure(error_summary: str) -> bool:
    text = str(error_summary or "").lower()
    if not text:
        return False
    platform_markers = (
        "docker: error response from daemon",
        "no such image",
        "cannot connect to the docker daemon",
        "error during connect",
        "waiting for container",
        "等待容器超时",
    )
    return any(marker in text for marker in platform_markers)
def _pool_summary(
    results: list[dict[str, Any]],
    *,
    pool_path: Path,
    out_dir: Path,
    duration_sec: float,
) -> dict[str, Any]:
    return pool_summary(results, pool_path=pool_path, out_dir=out_dir, duration_sec=duration_sec, rate=_rate)
def _pool_summary_markdown(summary: Mapping[str, Any], results: list[dict[str, Any]]) -> str:
    return pool_summary_markdown(summary, results)
def _write_self_test_sources(root: Path) -> list[dict[str, Any]]:
    cases = [
        (
            "selftest-one-failed-scene",
            _self_test_source("# SELFTEST_FAIL_MISSING_HELPER\n"),
        ),
        (
            "selftest-two-failed-scenes-one-call",
            _self_test_source("# SELFTEST_FAIL_MISSING_HELPER\n# SELFTEST_FAIL_BAD_ARROW\n"),
        ),
        (
            "selftest-regression-recheck",
            _self_test_source("# SELFTEST_FAIL_MISSING_HELPER\n# SELFTEST_REGRESS_OK_AFTER_BAD_FIX\n"),
        ),
        (
            "selftest-non-code-first-response",
            _self_test_source("# SELFTEST_FAIL_MISSING_HELPER\n# SELFTEST_NON_CODE_FIRST_RESPONSE\n"),
        ),
        (
            "selftest-drops-scene-first-response",
            _self_test_source("# SELFTEST_FAIL_MISSING_HELPER\n# SELFTEST_DROP_SCENE_FIRST_RESPONSE\n"),
        ),
        (
            "selftest-provider-error-first-response",
            _self_test_source("# SELFTEST_FAIL_MISSING_HELPER\n# SELFTEST_PROVIDER_ERROR_FIRST_RESPONSE\n"),
        ),
    ]
    rows: list[dict[str, Any]] = []
    for case_id, source in cases:
        path = root / f"{case_id}.py"
        path.write_text(source, encoding="utf-8")
        rows.append({"case_id": case_id, "source_path": str(path.resolve())})
    return rows
def _self_test_source(markers: str) -> str:
    return (
        "from manim import *\n\n"
        f"{markers}"
        "class Scene_OK(Scene):\n"
        "    def construct(self):\n"
        "        self.add(Text('ok'))\n\n"
        "class Scene_Bad(Scene):\n"
        "    def construct(self):\n"
        "        self.add(Text('bad'))\n\n"
        "class Scene_Arrow(Scene):\n"
        "    def construct(self):\n"
        "        self.add(Text('arrow'))\n"
    )
def _self_test_render(**kwargs: Any) -> dict[str, Any]:
    scene_name = str(kwargs["scene_name"])
    source = Path(kwargs["script_path"]).read_text(encoding="utf-8")
    out_dir = Path(kwargs["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / "render.log"
    error = ""
    if (
        scene_name == "Scene_Bad"
        and "SELFTEST_FAIL_MISSING_HELPER" in source
        and "SELFTEST_FIXED_MISSING_HELPER" not in source
    ):
        error = "NameError: name 'missing_helper' is not defined"
    elif (
        scene_name == "Scene_Arrow"
        and "SELFTEST_FAIL_BAD_ARROW" in source
        and "SELFTEST_FIXED_BAD_ARROW" not in source
    ):
        error = "TypeError: Arrow.__init__() got an unexpected keyword argument 'arrow_size'"
    elif (
        scene_name == "Scene_OK"
        and "SELFTEST_REGRESS_OK_AFTER_BAD_FIX" in source
        and "SELFTEST_FIXED_MISSING_HELPER" in source
        and "SELFTEST_FIXED_REGRESSED_OK" not in source
    ):
        error = "RuntimeError: Scene_OK regressed after previous repair"

    if error:
        log_path.write_text(error + "\n", encoding="utf-8")
        return {
            "render_ok": False,
            "returncode": 1,
            "mp4": "",
            "mp4_bytes": 0,
            "log": str(log_path),
            "check_json": str(out_dir / "docker_render_check.json"),
            "errors": ["self_test_render_failed"],
        }

    mp4 = out_dir / f"{scene_name}.mp4"
    mp4.write_bytes(b"self-test")
    log_path.write_text("render ok\n", encoding="utf-8")
    return {
        "render_ok": True,
        "returncode": 0,
        "mp4": str(mp4),
        "mp4_bytes": mp4.stat().st_size,
        "log": str(log_path),
        "check_json": str(out_dir / "docker_render_check.json"),
        "errors": [],
    }
def _self_test_repair_client(**kwargs: Any) -> str:
    fixed = str(kwargs["source"])
    validation_feedback = list(kwargs.get("validation_feedback") or [])
    if "SELFTEST_NON_CODE_FIRST_RESPONSE" in fixed and not validation_feedback:
        return "已经修好了，直接运行。"
    if "SELFTEST_DROP_SCENE_FIRST_RESPONSE" in fixed and not validation_feedback:
        return (
            "from manim import *\n\n"
            "class Scene_Bad(Scene):\n"
            "    def construct(self):\n"
            "        self.add(Text('fixed'))\n"
            "# SELFTEST_FIXED_MISSING_HELPER\n"
        )
    if "SELFTEST_PROVIDER_ERROR_FIRST_RESPONSE" in fixed and not validation_feedback:
        raise RuntimeError("self-test transient provider error")
    for failure in kwargs.get("failures") or []:
        error = str(failure.get("error_summary") or "")
        if "missing_helper" in error and "SELFTEST_FIXED_MISSING_HELPER" not in fixed:
            fixed += "\n# SELFTEST_FIXED_MISSING_HELPER\n"
        if "arrow_size" in error and "SELFTEST_FIXED_BAD_ARROW" not in fixed:
            fixed += "\n# SELFTEST_FIXED_BAD_ARROW\n"
        if "Scene_OK regressed" in error and "SELFTEST_FIXED_REGRESSED_OK" not in fixed:
            fixed += "\n# SELFTEST_FIXED_REGRESSED_OK\n"
    return fixed
def _error_summary(check: Mapping[str, Any]) -> str:
    log_path = Path(str(check.get("log") or ""))
    text = ""
    if log_path.is_file():
        text = log_path.read_text(encoding="utf-8", errors="ignore")
    if text:
        text = re.sub(r"\x1b\[[0-9;]*m", "", text)
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        selected = [
            line
            for line in lines
            if any(token in line for token in ("Error", "Exception", "NameError", "TypeError", "AttributeError", "RuntimeError", "ValueError"))
        ]
        if selected:
            return "\n".join(selected[-12:])[:4000]
        return "\n".join(lines[-20:])[:4000]
    errors = check.get("errors") or []
    return "\n".join(str(item) for item in errors)[:4000]
def extract_code(response_text: str) -> str:
    text = (response_text or "").strip()
    fenced = re.search(r"```(?:python|py)?\s*(?P<code>.*?)```", text, flags=re.S | re.I)
    if fenced:
        text = fenced.group("code").strip()
    return text + ("\n" if text and not text.endswith("\n") else "")
def _missing_repair_client(**kwargs) -> str:
    raise RuntimeError("repair_client_required_after_render_failure")
def _safe_path_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"_", "-", "."} else "_" for ch in value)
def _dedupe(items: list[str]) -> list[str]:
    return list(dict.fromkeys(items))
def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))
def _rate(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 4) if denominator else 0.0


