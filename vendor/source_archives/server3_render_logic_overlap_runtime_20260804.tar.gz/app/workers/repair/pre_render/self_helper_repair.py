"""Compatibility facade for missing self-helper repair."""
from . import self_helper_entry as _entry
from . import self_helper_patterns as _patterns

globals().update({k: v for _module in (_entry, _patterns) for k, v in vars(_module).items() if k not in {"_module", "__builtins__"}})
