"""pre_render_fixes.py — 渲染前代码修复管线。

pre_render_scan() 是主入口：依次运行一组启发式修复，
清理 LLM 常见的代码错误（LaTeX 语法、重复 Scene、中文引号等）。
"""

import re
import ast
import io
import json
import logging
import os
import tokenize
from typing import Callable, Iterable, Optional, Tuple

from app.workers.repair.error_patterns import (
    _auto_fix_chinese_punctuation,
    _auto_fix_truncation,
)
from app.workers.repair.visual_fixes import (
    _fix_unprotected_text_overflow,
    _fix_mathtex_overflow,
)
from app.workers.repair.polyline_compat import inject_polyline_compat
from app.prompts.header_template import resolve_global_config_alias_target
from app.workers.validation.formula_text_contract import (
    compile_formula_text_boundaries,
    rewrite_formula_text_payloads_to_mathtex,
)
from app.workers.repair.pre_render_text_fixes import (
    _INLINE_MATH_TUPLE_STRING_RE,
    _LATEX_OVERESCAPED_CMD_RE,
    _fix_hallucinated_self_safe_call,
    _fix_inline_math_tuple_overescaped_latex_commands,
    _fix_markup_br_tags_in_string_literals,
    _fix_mathtex_plain_string_latex_escapes,
    _fix_nested_ascii_quotes,
    _fix_raw_string_trailing_backslash,
    _fix_unicode_brace_escapes,
    _latex_has_aligned_begin,
    _latex_has_aligned_end,
    _normalize_overescaped_latex_commands,
    _strip_markdown_code_fence,
)
from app.workers.repair.pre_render.pythagorean_contracts import (
    fix_pythagorean_area_model_dict_contract,
)
from app.workers.repair.pre_render.manim_api_compat import (
    fix_clamp_to_canvas_buff_keyword,
    fix_fit_to_zone_alias_calls,
    fix_label_arc_and_outside_label_icon_fallbacks,
    fix_get_layout_area_get_center_calls,
    fix_manim_arrow_size_keyword,
    inject_cylinder_cone_mobject_contracts,
)
from app.workers.repair.pre_render.undefined_symbol_repair import (
    inject_undefined_symbol_runtime_helpers,
)
from app.workers.repair.pre_render.self_helper_repair import (
    inject_missing_self_helper_methods,
)

logger = logging.getLogger("render")

# ============================================================
# 渲染前全文扫描 — 拦截常见错误，成本接近 0
# ============================================================
# 中文字符检测正则（本地定义，避免与 error_patterns 循环导入）
_CHINESE_RE = re.compile(r'[\u4e00-\u9fff\u3400-\u4dbf]')
# MathTex/Tex 参数中的中文字符检测
_MATHTEX_WITH_CHINESE_RE = re.compile(
    r'\b(MathTex|Tex)\(([^)]*[' + '\u4e00-\u9fff\u3400-\u4dbf' + r'][^)]*)\)'
)
_DYNAMIC_MATHTEX_NAME_ARG_RE = re.compile(
    r"\bMathTex\(\s*(?P<name>[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]\n]+\])?)\s*,"
)
_SAFE_TEXT_BOX_DUP_COLOR_RE = re.compile(
    r"(?m)^(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"Text\(\s*(?P<content>[A-Za-z_][A-Za-z0-9_]*)\s*,\s*"
    r"color\s*=\s*self\.PRIMARY_TEXT\s*,\s*\*\*kwargs\s*\)"
)
_MAKE_HELPER_CALL_RE = re.compile(r"(?<!\.)\b(make_[A-Za-z_][A-Za-z0-9_]*)\s*\(")
_MAKE_HELPER_DEF_RE = re.compile(r"(?m)^\s*def\s+(make_[A-Za-z_][A-Za-z0-9_]*)\s*\(")
_INLINE_MATH_TEXT_NARROW_DEF_RE = re.compile(
    r"(?m)^(?P<indent>\s*)def\s+inline_math_text\s*\("
    r"\s*self\s*,\s*\*(?P<var>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?P<tail>\s*,\s*[^)]*)?\)\s*:"
)
_INLINE_MATH_TEXT_DEF_LINE_RE = re.compile(
    r"^(?P<indent>\s*)def\s+inline_math_text\s*\("
)
# wait_until_bookmark 多参数调用
_WAIT_BOOKMARK_MULTI_RE = re.compile(
    r'\.wait_until_bookmark\(\s*["\'][^"\']*["\']\s*,'
)
_BOOKMARK_TAG_RE = re.compile(
    r"<bookmark\s+mark\s*=\s*(['\"])(?P<mark>[^'\"]+)\1\s*/?>",
    re.IGNORECASE,
)
_BOOKMARK_CONSUME_RE = re.compile(
    r"\.(?:wait_until_bookmark|time_until_bookmark)"
    r"\(\s*(['\"])(?P<mark>[^'\"]+)\1\s*\)"
)
_CUSTOM_WAIT_FOR_VOICEOVER_RE = re.compile(
    r"(?m)^(?P<indent>\s*)def\s+wait_for_voiceover"
    r"\(\s*self\s*,(?P<args>[^)]*)\)\s*:"
)
_VOICEOVER_SCENE_BASE_RE = re.compile(
    r"(?m)^class\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\bVoiceoverScene\b[^)]*\)\s*:"
)
_VOICEOVER_SCENE_IMPORT_RE = re.compile(
    r"(?m)^\s*from\s+manim_voiceover\s+import\s+(?:[^#\n]*\bVoiceoverScene\b|\*)\b"
)
_VOICEOVER_SCENE_LOCAL_DEF_RE = re.compile(
    r"(?m)^\s*(?:class\s+VoiceoverScene\b|VoiceoverScene\s*=)"
)
_INIT_VOICEOVER_CALL_RE = re.compile(
    r"\bself\.(?:init_voiceover|set_voiceover_service|set_tts_service)\s*\("
)
_SETUP_LAYOUT_REQUIRED_SELF_METHODS = {
    "safe_text_box",
    "safe_text",
    "safe_math_box",
    "safe_math",
    "inline_math_text",
    "layout_canvas",
    "fit_to_canvas",
    "clamp_to_canvas",
    "place_non_overlapping",
    "safe_group",
    "voiceover",
    "add_voiceover_text",
    "create_subcaption",
    "play_synced_steps",
    "play_steps_evenly",
    "wait_until_bookmark",
    "time_until_bookmark",
    "get_zone_center",
    "get_right_angle_mark",
    "get_geometry_base",
}
_SETUP_LAYOUT_REQUIRED_SELF_ATTRS = {
    "full_canvas",
    "left_canvas",
    "right_canvas",
    "top_canvas",
    "bottom_canvas",
    "title_zone",
    "content_zone",
    "footer_zone",
    "formula_zone",
    "frame_width",
    "frame_height",
    "safe_margin",
}
_GTTS_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^(?P<indent>\s*)from\s+manim_voiceover\.services\.gtts\s+"
    r"import\s+(?:GTTSService|gTTSService|GTSService)\s*(?:#.*)?$"
)
_GTTS_PROVIDER_CALL_RE = re.compile(r"\b(?:GTTSService|gTTSService|GTSService)\s*\([^)]*\)")
_RECORDER_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^(?P<indent>\s*)from\s+manim_voiceover\.services\.recorder\s+"
    r"import\s+RecorderService\s*(?:#.*)?$"
)
_RECORDER_PROVIDER_CALL_RE = re.compile(r"\bRecorderService\s*\([^)]*\)")
_STUB_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^(?P<indent>\s*)from\s+manim_voiceover\.services\.stub\s+"
    r"import\s+StubService\s*(?:#.*)?$"
)
_STUB_PROVIDER_CALL_RE = re.compile(r"\bStubService\s*\([^)]*\)")
_DUMMY_PROVIDER_IMPORT_RE = re.compile(
    r"(?m)^(?P<indent>\s*)from\s+manim_voiceover\.services\.dummy\s+"
    r"import\s+DummyService\s*(?:#.*)?$"
)
_DUMMY_PROVIDER_CALL_RE = re.compile(r"\bDummyService\s*\([^)]*\)")
_TITLE_Y_ATTR_RE = re.compile(r"\bself\.title_y\b")
_TITLE_LIKE_VAR_RE = re.compile(
    r"(?:^|_)(?:title|scene_title|main_title|header|heading)(?:_|$)",
    re.IGNORECASE,
)
_TITLE_POSITIONING_METHOD_RE = re.compile(
    r"\b{var}\s*\.\s*(?:move_to|next_to|to_edge|to_corner|shift|align_to)\s*\("
)
_BASE_SPEECH_SERVICE_IMPORT_RE = re.compile(
    r"(?m)^(?P<indent>\s*)from\s+manim_voiceover\.services\.base\s+"
    r"import\s+BaseSpeechService\s*(?:#.*)?$"
)
_BARE_START_VOICEOVER_RE = re.compile(
    r"(?m)^(?P<indent>\s*)self\.start_voiceover\s*\((?P<args>[^()\n]*(?:\([^()\n]*\)[^()\n]*)*)\)\s*$"
)
_SECTOR_OUTER_RADIUS_RE = re.compile(r"(\bSector\s*\([^)]*?)\bouter_radius\s*=", re.S)
_SECTOR_ZERO_INNER_RADIUS_RE = re.compile(
    r"(\bSector\s*\(\s*)inner_radius\s*=\s*0(?:\.0)?\s*,\s*",
    re.S,
)
_DETERMINISTIC_GENERATED_HELPERS = {
    "get_arc_for_point",
    "get_placed_sector",
    "make_triangle_and_labels",
    "get_side_labels",
    "get_square_geometry",
    "rotate_point",
    "create_cube_elements",
    "get_cube_elements",
    "create_cube_edges",
    "get_rhombus_points",
    "get_right_angle_mark",
    "get_triangle_positions",
    "full_canvas",
    "make_angle_arc",
}
_THREED_BASE_CONFIG_SCENE_RE = re.compile(
    r"(?m)^class\s+BaseConfigScene\s*\([^)]*\bThreeDScene\b[^)]*\)\s*:"
)
_THREED_CAMERA_SETUP_CALL_RE = re.compile(
    r"\b(?:self\.)?(?:set_camera_orientation|move_camera|begin_ambient_camera_rotation)\s*\("
)
_THREED_FRONT_FACING_CAMERA_CALL = (
    "self.set_camera_orientation(phi=0 * DEGREES, theta=-90 * DEGREES)"
)
_FIXED_3D_TEXT_REGISTRATION_METHODS = {
    "add_fixed_in_frame_mobjects",
    "add_fixed_orientation_mobjects",
}
_3D_TEXT_REVEAL_ANIMATIONS = {
    "FadeIn",
    "Write",
    "Create",
    "ReplacementTransform",
    "Transform",
    "TransformFromCopy",
}
_TRACKER_REMAINDER_WAIT_MAX_RE = re.compile(
    r"(?m)^(?P<indent>\s*)self\.wait\s*\(\s*max\(\s*(?:0(?:\.\d+)?|[.]\d+)\s*,"
    r"\s*(?P<tracker>[A-Za-z_][A-Za-z0-9_]*)\.duration\s*-\s*(?P<used>[^)]+?)\s*\)\s*\)\s*$"
)
_TRACKER_REMAINDER_WAIT_HELPER_RE = re.compile(
    r"(?m)^(?P<indent>\s*)self\.[A-Za-z_]*wait[A-Za-z_]*\s*"
    r"\(\s*(?P<tracker>[A-Za-z_][A-Za-z0-9_]*)\.duration\s*-\s*(?P<used>[^)]+?)\s*\)\s*$"
)
_TRACKER_TIME_REMAINING_RE = re.compile(r"tracker\.time_remaining\s*\(\s*\)")
_TRACKER_TIME_REMAINING_ATTR_RE = re.compile(
    r"tracker\.time_remaining\b(?!\s*\()"
)
_VOICEOVER_SHORT_TARGET_MIN_CJK = 8
_VOICEOVER_SHORT_TARGET_MAX_CJK = 28
_VOICEOVER_HARD_MAX_CJK = 45
_VOICEOVER_SPLIT_PUNCTUATION = set("，。！？；、,.!?;：:")


def _tts_timeline_rewrites_enabled() -> bool:
    """Legacy TTS timeline rewrites are opt-in only.

    The current first-pass TTS route expects generated code to follow the
    5.23-style voiceover/helper contract directly.  Rewriting long blocks,
    wait-only blocks, or raw self.play blocks here changes the semantic timing
    after generate_stream, which makes manimtest unsuitable for judging raw TTS
    synchronization quality.
    """
    return os.getenv("MATHPI_ENABLE_TTS_TIMELINE_REWRITES", "").strip() == "1"

_TEXT_VAR_ASSIGNMENT_RE = re.compile(
    r"(?m)^\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"(?:Text|Tex|MathTex|self\.(?:create_text|create_formula|portrait_title|portrait_formula))\s*\("
)
_BULK_PRE_REVEAL_ADD_RE = re.compile(
    r"^(?P<indent>\s*)self\.add\s*\((?P<args>[^)\n]+)\)\s*$"
)
_HORIZONTAL_VGROUP_ASSIGN_RE = re.compile(
    r"^(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"VGroup\((?P<args>[^()\n]+)\)\.arrange\(\s*RIGHT\s*,\s*buff\s*=\s*(?P<buff>[^)\n]+)\)"
    r"\.move_to\((?P<center>[^)\n]+)\)(?P<tail>\.scale\([^)\n]+\))?\s*$"
)
_HORIZONTAL_VGROUP_EXPR_RE = re.compile(
    r"^(?P<indent>\s*)"
    r"VGroup\((?P<args>[^()\n]+)\)\.arrange\(\s*RIGHT\s*,\s*buff\s*=\s*(?P<buff>[^)\n]+)\)"
    r"\.move_to\((?P<center>[^)\n]+)\)(?P<tail>\.scale\([^)\n]+\))\s*$"
)
_SIMPLE_MOBJECT_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_UNSAFE_INLINE_GET_TEX_STRING_RE = re.compile(
    r"^(?P<indent>\s*)(?P<lhs>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"(?P<obj>[A-Za-z_][A-Za-z0-9_]*)\.get_tex_string\(\)\s+"
    r"if\s+hasattr\(\s*(?P=obj)\s*,\s*['\"]get_tex_string['\"]\s*\)\s+"
    r"else\s+getattr\(\s*(?P=obj)\s*,\s*['\"]text['\"]\s*,\s*['\"]{2}\s*\)\s*$"
)
_LAYOUT_CANVAS_METHOD_SUBSCRIPT_RE = re.compile(
    r"self\.layout_canvas\s*\[\s*(?P<quote>['\"])(?P<key>[A-Za-z_]+)(?P=quote)\s*\]"
)
_LAYOUT_CANVAS_CENTER_ALIAS_SUBSCRIPT_RE = re.compile(
    r"self\.layout_canvas\(\s*(?P<quote>['\"])"
    r"(?P<key>top_center|bottom_center|bottom_caption|left_center|right_center|full_center|center)"
    r"(?P=quote)\s*\)\s*\[\s*['\"]center['\"]\s*\]"
)
_BRACE_GET_TEXT_CJK_RE = re.compile(
    r"(?P<brace>[A-Za-z_][A-Za-z0-9_]*)\.get_text\("
    r"(?P<quote>['\"])(?P<text>(?:\\.|(?!['\"]).)*?[\u4e00-\u9fff\u3400-\u4dbf](?:\\.|(?!['\"]).)*?)(?P=quote)"
    r"\)"
)
_MOBJECT_IS_OVERLAPPING_RE = re.compile(r"\.is_overlapping\s*\(")
def _inline_math_text_plain_value_expr(var_name: str) -> str:
    return (
        f"{var_name}[1] if isinstance({var_name}, (tuple, list)) and len({var_name}) >= 2 "
        f"else ({var_name}[0] if isinstance({var_name}, (tuple, list)) and len({var_name}) == 1 "
        f"else ('' if isinstance({var_name}, (tuple, list)) else {var_name}))"
    )


def _fix_bulk_pre_reveal_text_adds(code: str) -> Tuple[Optional[str], str]:
    """首个动画前的批量文字 add 改成短 FadeIn。"""
    text_vars = {match.group("var") for match in _TEXT_VAR_ASSIGNMENT_RE.finditer(code)}
    if not text_vars:
        return None, ""

    lines = code.splitlines()
    changed = 0
    seen_play = False
    in_construct = False

    for index, line in enumerate(lines):
        if re.match(r"^\s*def\s+construct\s*\(\s*self\s*\)\s*:", line):
            in_construct = True
            seen_play = False
            continue
        if in_construct and re.match(r"^\s*def\s+|^class\s+", line):
            in_construct = False
        if not in_construct:
            continue
        if "self.play(" in line:
            seen_play = True
        if seen_play:
            continue

        match = _BULK_PRE_REVEAL_ADD_RE.match(line)
        if not match:
            continue
        context = "\n".join(lines[max(0, index - 24):index])
        if "self.restore_camera(" in context or any(
            marker in context
            for marker in ("重建上一场景", "上一场景", "状态重构", "视觉衔接", "rehydration")
        ):
            continue
        args = [part.strip() for part in match.group("args").split(",")]
        if len(args) < 2:
            continue
        if not all(re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", arg) for arg in args):
            continue
        if not all(arg in text_vars for arg in args):
            continue
        fadeins = ", ".join(f"FadeIn({arg})" for arg in args)
        lines[index] = f"{match.group('indent')}self.play({fadeins}, run_time=0.6)"
        changed += 1

    if changed == 0:
        return None, ""
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), f"首屏批量add修复: {changed}处"


def _ensure_core_manim_imports(code: str) -> Tuple[Optional[str], str]:
    """Restore mandatory Manim/NumPy/math imports when a generated header is missing."""
    additions: list[str] = []
    has_manim_import = bool(re.search(r"(?m)^\s*(?:from\s+manim\s+import|import\s+manim\b)", code))
    uses_manim_symbols = bool(
        re.search(r"\bclass\s+\w+\([^)]*\bScene\b", code)
        or re.search(
            r"\b(?:Scene|Text|MathTex|Tex|Dot|Line|DashedLine|VGroup|"
            r"Circle|Square|Polygon|Arrow|Axes|NumberPlane)\s*\(",
            code,
        )
    )
    if uses_manim_symbols and not has_manim_import:
        additions.append("from manim import *")

    has_numpy_import = bool(re.search(r"(?m)^\s*import\s+numpy\s+as\s+np\b", code))
    if "np." in code and not has_numpy_import:
        additions.append("import numpy as np")

    has_math_import = bool(re.search(r"(?m)^\s*(?:import\s+math\b|from\s+math\s+import\s+)", code))
    if "math." in code and not has_math_import:
        additions.append("import math")

    if not additions:
        return None, ""
    stripped = code.lstrip("\n")
    return "\n".join(additions) + "\n\n" + stripped, (
        f"核心导入补全: {', '.join(additions)}"
    )


_COMMON_FONT_SIZE_DEFAULTS = {
    "FONT_TITLE": 40,
    "FONT_SECTION": 32,
    "FONT_BODY": 28,
    "FONT_FORMULA": 32,
    "FONT_LABEL": 22,
    "FONT_CAPTION": 24,
    "title_font_size": 36,
    "subtitle_font_size": 28,
    "body_font_size": 24,
    "label_font_size": 22,
    "formula_font_size": 30,
    "caption_font_size": 18,
    "small_font_size": 16,
}

_PROJECT_CJK_TEXT_FONT = "AR PL KaitiM GB"
_CJK_TEXT_FONT_VAR = "_mathpi_cjk_text_font"
_CJK_TEXT_CONSTRUCTOR_NAMES = {"Text", "MarkupText", "Paragraph"}
_CJK_TEXT_DEFAULT_CLASSES = {"Text", "MarkupText", "Paragraph"}
_CJK_TEXT_ACCEPTABLE_FONTS = {
    "ar pl kaitim gb",
    "ar pl ukai cn",
}


def _collect_bound_names_for_repair(tree: ast.AST) -> set[str]:
    bound: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            bound.add(node.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(node.name)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                bound.update(arg.arg for arg in node.args.posonlyargs)
                bound.update(arg.arg for arg in node.args.args)
                bound.update(arg.arg for arg in node.args.kwonlyargs)
                if node.args.vararg:
                    bound.add(node.args.vararg.arg)
                if node.args.kwarg:
                    bound.add(node.args.kwarg.arg)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                bound.add((alias.asname or alias.name).split(".")[0])
        elif isinstance(node, ast.ExceptHandler) and node.name:
            bound.add(str(node.name))
    return bound


def _inject_common_font_size_defaults(code: str) -> Tuple[Optional[str], str]:
    """Define common generated font-size aliases when the scene forgot them."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    bound = _collect_bound_names_for_repair(tree)
    loaded: list[str] = []
    seen: set[str] = set()
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Load)
            and node.id in _COMMON_FONT_SIZE_DEFAULTS
            and node.id not in bound
            and node.id not in seen
        ):
            continue
        seen.add(node.id)
        loaded.append(node.id)

    if not loaded:
        return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    default_lines = [
        f"{name} = {_COMMON_FONT_SIZE_DEFAULTS[name]}"
        for name in sorted(loaded, key=lambda item: list(_COMMON_FONT_SIZE_DEFAULTS).index(item))
    ]
    lines[insert_at:insert_at] = default_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, f"字号变量兜底: {', '.join(loaded)}"


def _normalize_self_font_size_tokens(code: str) -> Tuple[Optional[str], str]:
    pattern = re.compile(
        r"\bself\.(?P<name>"
        + "|".join(re.escape(name) for name in _COMMON_FONT_SIZE_DEFAULTS if name.startswith("FONT_"))
        + r")\b"
    )
    names: list[str] = []

    def repl(match: re.Match[str]) -> str:
        name = match.group("name")
        if name not in names:
            names.append(name)
        return name

    fixed = pattern.sub(repl, code)
    if fixed == code:
        return None, ""
    return fixed, f"self字号变量归一: {', '.join(names)}"


def _literal_font_name_for_repair(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _normalize_font_name_for_repair(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _font_needs_project_cjk_font(value: str) -> bool:
    normalized = _normalize_font_name_for_repair(value)
    return not normalized or normalized not in _CJK_TEXT_ACCEPTABLE_FONTS


def _set_default_owner_name(func: ast.AST) -> str:
    if not isinstance(func, ast.Attribute) or func.attr != "set_default":
        return ""
    if isinstance(func.value, ast.Name):
        return func.value.id
    return ""


def _set_default_font_insert_at(node: ast.Call, code: str) -> Optional[int]:
    func_span = _positioned_node_span(node.func, code)
    if not func_span:
        return None
    open_paren = code.find("(", func_span[1])
    if open_paren < 0:
        return None
    return open_paren + 1


def _inject_project_cjk_text_font_defaults(code: str) -> str:
    if re.search(rf"(?m)^\s*{re.escape(_CJK_TEXT_FONT_VAR)}\s*=", code):
        return code
    lines = code.splitlines()
    insert_at = _voiceover_import_insert_index(lines)
    block = [
        "try:",
        f'    {_CJK_TEXT_FONT_VAR} = "{_PROJECT_CJK_TEXT_FONT}"',
        f"    Text.set_default(font={_CJK_TEXT_FONT_VAR})",
        '    if "MarkupText" in globals():',
        f"        MarkupText.set_default(font={_CJK_TEXT_FONT_VAR})",
        '    if "Paragraph" in globals():',
        f"        Paragraph.set_default(font={_CJK_TEXT_FONT_VAR})",
        "except Exception:",
        f'    {_CJK_TEXT_FONT_VAR} = "{_PROJECT_CJK_TEXT_FONT}"',
        "",
    ]
    lines[insert_at:insert_at] = block
    return "\n".join(lines) + ("\n" if code.endswith("\n") else "")


def _normalize_cjk_text_typography_font(code: str) -> Tuple[Optional[str], str]:
    """Force project CJK text font while leaving MathTex formula glyphs alone."""
    if not (
        _CHINESE_RE.search(code or "")
        or "Text.set_default(" in code
        or "MarkupText.set_default(" in code
        or "Paragraph.set_default(" in code
    ):
        return None, ""
    if not any(
        marker in code
        for marker in (
            "Text(",
            "MarkupText(",
            "Paragraph(",
            "Text.set_default(",
            "MarkupText.set_default(",
            "Paragraph.set_default(",
        )
    ):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    edits: list[tuple[int, int, str]] = []
    changed = 0
    needs_default_block = False

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        call_name = _call_name_for_repair(node.func)
        if call_name in _CJK_TEXT_CONSTRUCTOR_NAMES:
            needs_default_block = True
            for keyword in node.keywords:
                if keyword.arg != "font":
                    continue
                font_name = _literal_font_name_for_repair(keyword.value)
                if font_name is not None and not _font_needs_project_cjk_font(font_name):
                    continue
                value_span = _positioned_node_span(keyword.value, code)
                if not value_span:
                    continue
                edits.append((*value_span, _CJK_TEXT_FONT_VAR))
                changed += 1
            continue

        default_owner = _set_default_owner_name(node.func)
        if default_owner not in _CJK_TEXT_DEFAULT_CLASSES:
            continue
        needs_default_block = True
        font_keyword = next((keyword for keyword in node.keywords if keyword.arg == "font"), None)
        if font_keyword is not None:
            font_name = _literal_font_name_for_repair(font_keyword.value)
            if font_name is not None and not _font_needs_project_cjk_font(font_name):
                continue
            value_span = _positioned_node_span(font_keyword.value, code)
            if not value_span:
                continue
            edits.append((*value_span, _CJK_TEXT_FONT_VAR))
            changed += 1
            continue
        insert_at = _set_default_font_insert_at(node, code)
        if insert_at is None:
            continue
        separator = "" if not node.args and not node.keywords else ", "
        edits.append((insert_at, insert_at, f"font={_CJK_TEXT_FONT_VAR}{separator}"))
        changed += 1

    current = code
    if edits:
        current = _apply_keyword_edits_for_repair(current, edits)

    if needs_default_block:
        before = current
        current = _inject_project_cjk_text_font_defaults(current)
        if current != before:
            changed += 1

    if current == code or changed <= 0:
        return None, ""
    return current, f"中文文本楷体字体归一: {changed}处"


def _inject_mathpi_bbox_helper(code: str) -> str:
    if "def _mathpi_bbox(" in code:
        return code
    lines = code.splitlines()
    insert_at = _voiceover_import_insert_index(lines)
    helper = [
        "def _mathpi_bbox(mobject):",
        "    return (",
        "        (float(mobject.get_left()[0]), float(mobject.get_bottom()[1]), 0.0),",
        "        (float(mobject.get_center()[0]), float(mobject.get_center()[1]), 0.0),",
        "        (float(mobject.get_right()[0]), float(mobject.get_top()[1]), 0.0),",
        "    )",
        "",
    ]
    lines[insert_at:insert_at] = helper
    return "\n".join(lines) + ("\n" if code.endswith("\n") else "")


def _fix_mobject_bounding_box_attribute(code: str) -> Tuple[Optional[str], str]:
    """Use stable edge getters instead of Manim's broken bounding_box shim."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "get_bounding_box" and not node.args and not node.keywords:
                base = ast.get_source_segment(code, node.func.value)
                span = _source_span_for_multiline_node(node, code)
                if base and span is not None:
                    replacements.append((span[0], span[1], f"_mathpi_bbox({base})"))
            continue
        if not isinstance(node, ast.Attribute) or node.attr != "bounding_box":
            continue
        parent = parents.get(node)
        if isinstance(parent, ast.Call) and parent.func is node:
            continue
        if isinstance(parent, ast.Assign) and node in parent.targets:
            continue
        if isinstance(parent, ast.AugAssign) and parent.target is node:
            continue
        if isinstance(parent, ast.Delete) and node in parent.targets:
            continue
        base = ast.get_source_segment(code, node.value)
        span = _source_span_for_multiline_node(node, code)
        if not base or span is None:
            continue
        replacements.append((span[0], span[1], f"_mathpi_bbox({base})"))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        current = current[:start] + replacement + current[end:]
    current = _inject_mathpi_bbox_helper(current)
    return current, f"Manim bounding_box属性修复; bounding_box兼容修复: {len(replacements)}处"


def _inject_mobject_is_overlapping_compat(code: str) -> Tuple[Optional[str], str]:
    """Provide a tiny bbox-overlap method for LLM generated Text.is_overlapping()."""
    if (
        not _MOBJECT_IS_OVERLAPPING_RE.search(code)
        or "def _mathpi_mobject_is_overlapping(" in code
    ):
        return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    helper = [
        "",
        "def _mathpi_mobject_is_overlapping(self, other, buff=0.0):",
        "    try:",
        "        margin = float(buff or 0.0)",
        "        ax0 = float(self.get_left()[0]) - margin",
        "        ax1 = float(self.get_right()[0]) + margin",
        "        ay0 = float(self.get_bottom()[1]) - margin",
        "        ay1 = float(self.get_top()[1]) + margin",
        "        bx0 = float(other.get_left()[0]) - margin",
        "        bx1 = float(other.get_right()[0]) + margin",
        "        by0 = float(other.get_bottom()[1]) - margin",
        "        by1 = float(other.get_top()[1]) + margin",
        "        return not (ax1 < bx0 or bx1 < ax0 or ay1 < by0 or by1 < ay0)",
        "    except Exception:",
        "        return False",
        "",
        "try:",
        "    if not hasattr(Mobject, \"is_overlapping\"):",
        "        Mobject.is_overlapping = _mathpi_mobject_is_overlapping",
        "except Exception:",
        "    pass",
        "",
    ]
    lines[insert_at:insert_at] = helper
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "Mobject重叠检测兼容注入: 1处",
    )


def _inject_base_config_text_color_fallback(code: str) -> Tuple[Optional[str], str]:
    """Expose self.TEXT_COLOR even when a standalone slice only sets PRIMARY_TEXT in setup()."""
    if (
        "class BaseConfigScene" not in code
        or "self.TEXT_COLOR" not in code
        or re.search(r"(?m)^\s*(?:TEXT_COLOR\s*=|def\s+TEXT_COLOR\s*\()", code)
    ):
        return None, ""
    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines = [
        "",
        f"{indent}@property",
        f"{indent}def TEXT_COLOR(self):",
        f"{body}return getattr(self, \"PRIMARY_TEXT\", globals().get(\"MAIN_WHITE\", WHITE))",
    ]
    lines = code.splitlines()
    lines[end:end] = helper_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "BaseConfigScene.TEXT_COLOR兜底: 1处",
    )


def _fix_unsafe_inline_get_tex_string(code: str) -> Tuple[Optional[str], str]:
    """Text.get_tex_string may exist but raise because Text has no tex_string."""
    lines = code.splitlines()
    changed = 0
    for index, line in enumerate(lines):
        match = _UNSAFE_INLINE_GET_TEX_STRING_RE.match(line)
        if not match:
            continue
        indent = match.group("indent")
        lhs = match.group("lhs")
        obj = match.group("obj")
        lines[index:index + 1] = [
            f"{indent}try:",
            f"{indent}    {lhs} = {obj}.get_tex_string()",
            f"{indent}except Exception:",
            f"{indent}    {lhs} = getattr({obj}, \"text\", \"\")",
        ]
        changed += 1

    if changed == 0:
        return None, ""
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), (
        f"Text取值保护修复: {changed}处"
    )


def _fix_undefined_center_point_o(code: str) -> Tuple[Optional[str], str]:
    """LLM often uses O as a center point but forgets to bind it in helpers."""
    lines = code.splitlines()
    changed = 0
    index = 0

    while index < len(lines):
        line = lines[index]
        match = re.match(
            r"^(?P<indent>\s*)def\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\bcenter\s*=",
            line,
        )
        if not match:
            index += 1
            continue

        def_indent = match.group("indent")
        body_indent = def_indent + "    "
        start = index + 1
        end = start
        while end < len(lines):
            current = lines[end]
            if current.strip() and len(current) - len(current.lstrip()) <= len(def_indent):
                break
            end += 1

        body = "\n".join(lines[start:end])
        if (
            re.search(r"(?m)^\s*O\s*=", body)
            or not re.search(r"\b(?:next_to|move_to|Dot)\(\s*O\b|\breturn\b[^\n]*\bO\b", body)
        ):
            index = end
            continue

        insert_at = None
        for offset, body_line in enumerate(lines[start:end], start=start):
            if re.search(r"\bcenter_dot\s*=\s*Dot\s*\(\s*point\s*=\s*center\b", body_line):
                insert_at = offset + 1
                break
            if insert_at is None and re.search(r"\b[A-Z]\s*,\s*[A-Z]\s*,\s*[A-Z]\s*,\s*[A-Z]\s*=", body_line):
                insert_at = offset + 1
        if insert_at is None:
            index = end
            continue

        lines.insert(insert_at, f"{body_indent}O = center")
        changed += 1
        index = end + 1

    if changed == 0:
        return None, ""
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), f"中心点O补全: {changed}处"


def _ensure_base_config_scene_header(
    code: str,
    *,
    color_scheme: int,
) -> Tuple[Optional[str], str]:
    """Restore the fixed runtime header when continuation starts at Scene code."""
    references_base = bool(
        re.search(r"\bclass\s+\w+\s*\(\s*BaseConfigScene\s*\)", code)
    )
    defines_base = bool(re.search(r"\bclass\s+BaseConfigScene\s*\(", code))
    if not references_base or defines_base:
        return None, ""

    from app.prompts.header_template import (
        COLOR_VARS,
        HEADER_TEMPLATE,
        THREED_HEADER_TEMPLATE,
    )

    template = (
        THREED_HEADER_TEMPLATE
        if re.search(r"\b(?:ThreeD|ThreeDAxes|set_camera_orientation)\b", code)
        else HEADER_TEMPLATE
    )
    color_code = COLOR_VARS.get(color_scheme, COLOR_VARS[1])
    header = template.replace("__COLOR__", color_code).rstrip()
    stripped = code.lstrip("\n")
    return f"{header}\n\n{stripped}", "BaseConfigScene头部补全: 1处"


def _find_dict_block_end(lines: list[str], start_index: int) -> int:
    depth = 0
    for index in range(start_index, len(lines)):
        line = lines[index]
        depth += line.count("{")
        depth -= line.count("}")
        if depth <= 0:
            return index
    return start_index


def _find_enclosing_dict_block(lines: list[str], item_index: int) -> tuple[int, int]:
    start_index = item_index
    for index in range(item_index, max(-1, item_index - 12), -1):
        if "{" in lines[index]:
            start_index = index
            break
    block_end = _find_dict_block_end(lines, start_index)
    return start_index, block_end


def _fix_missing_left_right_canvas_areas(code: str) -> Tuple[Optional[str], str]:
    """Generated headers sometimes call area=left/right but map them to full."""
    if not re.search(r"area\s*=\s*['\"](?:left|right)['\"]", code):
        return None, ""
    if "self.left_canvas" in code and "self.right_canvas" in code:
        return None, ""

    lines = code.splitlines()
    full_start = next(
        (
            index
            for index, line in enumerate(lines)
            if "self.full_canvas" in line and "{" in line
        ),
        None,
    )
    if full_start is None:
        return None, ""
    full_end = _find_dict_block_end(lines, full_start)
    indent = re.match(r"^(\s*)", lines[full_start]).group(1)
    canvas_block = [
        f"{indent}self.left_canvas = {{",
        f'{indent}    "center": np.array([-self.frame_width * 0.25, 0.0, 0.0]),',
        f'{indent}    "width": self.frame_width * 0.46,',
        f'{indent}    "height": self.frame_height - self.safe_margin * 2.0',
        f"{indent}}}",
        f"{indent}self.right_canvas = {{",
        f'{indent}    "center": np.array([self.frame_width * 0.25, 0.0, 0.0]),',
        f'{indent}    "width": self.frame_width * 0.46,',
        f'{indent}    "height": self.frame_height - self.safe_margin * 2.0',
        f"{indent}}}",
    ]
    lines[full_end + 1:full_end + 1] = canvas_block

    changed_mapping = False
    for index, line in enumerate(lines):
        if '"full"' not in line and "'full'" not in line:
            continue
        if "self.full_canvas" not in line:
            continue
        block_start, block_end = _find_enclosing_dict_block(lines, index)
        if block_end <= block_start:
            continue
        mapping_text = "\n".join(lines[block_start:block_end + 1])
        if "self.left_canvas" in mapping_text or "self.right_canvas" in mapping_text:
            continue
        item_indent = re.match(r"^(\s*)", line).group(1)
        lines[index + 1:index + 1] = [
            f'{item_indent}"left": self.left_canvas,',
            f'{item_indent}"right": self.right_canvas,',
        ]
        changed_mapping = True
        break

    if not changed_mapping:
        return None, ""
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), "左右画布区域补全: 1处"


def _fix_layout_canvas_vector_edges(code: str) -> Tuple[Optional[str], str]:
    """Normalize legacy layout_canvas helpers to numeric edge coordinates."""
    if "def layout_canvas" not in code:
        return None, ""

    replacements = 0
    current = code

    compact_pattern = re.compile(
        r'(?m)^(?P<indent>\s*)b=dict\(mapping\.get\(area,self\.full_canvas\)\);'
        r'c=b\["center"\];w,h=b\["width"\],b\["height"\];'
        r'l,r,d,u=c\+LEFT\*w/2,c\+RIGHT\*w/2,c\+DOWN\*h/2,c\+UP\*h/2\s*\n'
        r'(?P=indent)return dict\(b,left=l,right=r,bottom=d,top=u,'
        r'x_min=l\[0\],x_max=r\[0\],y_min=d\[1\],y_max=u\[1\]\)'
    )

    def _compact_replacement(match: re.Match[str]) -> str:
        indent = match.group("indent")
        return "\n".join([
            f'{indent}b=dict(mapping.get(area,self.full_canvas));c=np.array(b["center"],dtype=float);w,h=float(b["width"]),float(b["height"])',
            f"{indent}l,r,d,u=float(c[0]-w/2),float(c[0]+w/2),float(c[1]-h/2),float(c[1]+h/2)",
            f'{indent}return dict(b,center=c,left=l,right=r,bottom=d,top=u,x_min=l,x_max=r,y_min=d,y_max=u,left_center=np.array([l,c[1],0.0]),right_center=np.array([r,c[1],0.0]),bottom_center=np.array([c[0],d,0.0]),top_center=np.array([c[0],u,0.0]))',
        ])

    current, count = compact_pattern.subn(_compact_replacement, current)
    replacements += count

    expanded_pattern = re.compile(
        r'(?m)^(?P<indent>\s*)box = dict\(mapping\.get\(area, self\.full_canvas\)\); '
        r'center = np\.array\(box\["center"\], float\); width, height = box\["width"\], box\["height"\]\s*\n'
        r'(?P=indent)return dict\(box, center=center, left=center \+ LEFT \* width / 2, '
        r'right=center \+ RIGHT \* width / 2, bottom=center \+ DOWN \* height / 2, '
        r'top=center \+ UP \* height / 2, x_min=center\[0\] - width / 2, '
        r'x_max=center\[0\] \+ width / 2, y_min=center\[1\] - height / 2, '
        r'y_max=center\[1\] \+ height / 2\)'
    )

    def _expanded_replacement(match: re.Match[str]) -> str:
        indent = match.group("indent")
        return "\n".join([
            f'{indent}box = dict(mapping.get(area, self.full_canvas))',
            f'{indent}center = np.array(box["center"], dtype=float)',
            f'{indent}width, height = float(box["width"]), float(box["height"])',
            f'{indent}left, right = float(center[0] - width / 2), float(center[0] + width / 2)',
            f'{indent}bottom, top = float(center[1] - height / 2), float(center[1] + height / 2)',
            f'{indent}return dict(box, center=center, left=left, right=right, bottom=bottom, top=top, x_min=left, x_max=right, y_min=bottom, y_max=top, left_center=np.array([left, center[1], 0.0]), right_center=np.array([right, center[1], 0.0]), bottom_center=np.array([center[0], bottom, 0.0]), top_center=np.array([center[0], top, 0.0]))',
        ])

    current, count = expanded_pattern.subn(_expanded_replacement, current)
    replacements += count

    if replacements == 0 or current == code:
        return None, ""
    return current, f"layout_canvas边界数字化修复: {replacements}处"


def _fix_legacy_rectangle_layout_canvas_helper(code: str) -> Tuple[Optional[str], str]:
    """Normalize old helpers that returned invisible Rectangle mobjects.

    The current render contract expects ``layout_canvas(area)`` to return a
    mapping with at least center/width/height. Some historical slice code
    returned a transparent Rectangle instead, which breaks modified slices when
    new code uses ``self.layout_canvas("right")["center"]``.
    """
    if (
        "def layout_canvas" not in code
        or "Rectangle(" not in code
        or "return canvas" not in code
    ):
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines()
    replacements: list[tuple[int, int, list[str]]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef) or node.name != "layout_canvas":
            continue
        if node.end_lineno is None:
            continue
        source = "\n".join(lines[node.lineno - 1:node.end_lineno])
        if (
            "Rectangle(" not in source
            or "zones.get(" not in source
            or "return canvas" not in source
        ):
            continue
        if "set_stroke(opacity=0)" not in source and "set_fill(opacity=0)" not in source:
            continue

        def_line = lines[node.lineno - 1]
        indent = re.match(r"^(\s*)", def_line).group(1)
        body_indent = indent + "    "
        arg_name = "area"
        if len(node.args.args) >= 2:
            arg_name = node.args.args[1].arg

        body = [
            def_line,
            f'{body_indent}key = str({arg_name} or "full").strip().lower().replace("-", "_")',
            f"{body_indent}alias_map = {{",
            f'{body_indent}    "full_content_zone": "full", "content_zone": "full", "content": "full",',
            f'{body_indent}    "main": "full", "main_zone": "full", "diagram": "full", "diagram_zone": "full",',
            f'{body_indent}    "left_zone": "left", "left_content": "left", "left_panel": "left", "left_canvas": "left",',
            f'{body_indent}    "right_zone": "right", "right_content": "right", "right_panel": "right", "right_canvas": "right",',
            f'{body_indent}    "top_zone": "top", "title": "top", "title_zone": "top", "header": "top", "header_zone": "top",',
            f'{body_indent}    "bottom_zone": "bottom", "footer": "bottom", "footer_zone": "bottom", "caption": "bottom",',
            f"{body_indent}}}",
            f"{body_indent}key = alias_map.get(key, key)",
            f"{body_indent}zones = {{",
            f'{body_indent}    "full": {{"center": ORIGIN, "width": 11.8, "height": 5.6}},',
            f'{body_indent}    "left": {{"center": LEFT * 3.0, "width": 5.6, "height": 5.6}},',
            f'{body_indent}    "right": {{"center": RIGHT * 3.0, "width": 5.6, "height": 5.6}},',
            f'{body_indent}    "top": {{"center": UP * 1.45, "width": 11.8, "height": 2.2}},',
            f'{body_indent}    "bottom": {{"center": DOWN * 1.45, "width": 11.8, "height": 2.2}},',
            f"{body_indent}}}",
            f'{body_indent}canvas = dict(zones.get(key, zones["full"]))',
            f'{body_indent}center = canvas["center"]',
            f'{body_indent}width, height = float(canvas["width"]), float(canvas["height"])',
            f"{body_indent}left, right = float(center[0] - width / 2), float(center[0] + width / 2)",
            f"{body_indent}bottom, top = float(center[1] - height / 2), float(center[1] + height / 2)",
            f"{body_indent}return dict(",
            f"{body_indent}    canvas, center=center, width=width, height=height,",
            f"{body_indent}    left=left, right=right, bottom=bottom, top=top,",
            f"{body_indent}    x_min=left, x_max=right, y_min=bottom, y_max=top,",
            f"{body_indent}    left_center=center + LEFT * width / 2,",
            f"{body_indent}    right_center=center + RIGHT * width / 2,",
            f"{body_indent}    bottom_center=center + DOWN * height / 2,",
            f"{body_indent}    top_center=center + UP * height / 2,",
            f"{body_indent})",
        ]
        replacements.append((node.lineno - 1, node.end_lineno, body))

    if not replacements:
        return None, ""

    current_lines = lines[:]
    for start, end, body in sorted(replacements, reverse=True):
        current_lines[start:end] = body
    fixed = "\n".join(current_lines)
    if code.endswith("\n"):
        fixed += "\n"
    if fixed == code:
        return None, ""
    return fixed, f"layout_canvas旧版Rectangle helper兼容: {len(replacements)}处"


def _fix_layout_canvas_method_subscripts(code: str) -> Tuple[Optional[str], str]:
    """Generated code sometimes treats self.layout_canvas as a dict, not a method."""
    if "self.layout_canvas[" not in code:
        return None, ""

    key_map = {
        "top_center": 'self.layout_canvas("top")["center"]',
        "bottom_center": 'self.layout_canvas("bottom")["center"]',
        "left_center": 'self.layout_canvas("left")["center"]',
        "right_center": 'self.layout_canvas("right")["center"]',
        "full_center": 'self.layout_canvas("full")["center"]',
        "center": 'self.layout_canvas("full")["center"]',
        "top": 'self.layout_canvas("top")',
        "bottom": 'self.layout_canvas("bottom")',
        "left": 'self.layout_canvas("left")',
        "right": 'self.layout_canvas("right")',
        "full": 'self.layout_canvas("full")',
    }
    changed = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal changed
        replacement = key_map.get(match.group("key"))
        if not replacement:
            return match.group(0)
        changed += 1
        return replacement

    fixed = _LAYOUT_CANVAS_METHOD_SUBSCRIPT_RE.sub(_replace, code)
    if changed == 0 or fixed == code:
        return None, ""
    return fixed, f"layout_canvas方法下标修复: {changed}处"


def _layout_canvas_center_alias_area(node: ast.AST) -> str | None:
    if not isinstance(node, ast.Call):
        return None
    if (
        not isinstance(node.func, ast.Attribute)
        or node.func.attr != "layout_canvas"
        or not isinstance(node.func.value, ast.Name)
        or node.func.value.id != "self"
        or not node.args
    ):
        return None
    first_arg = node.args[0]
    if not isinstance(first_arg, ast.Constant) or not isinstance(first_arg.value, str):
        return None
    key_map = {
        "top_center": "top",
        "bottom_center": "bottom",
        "bottom_caption": "bottom",
        "left_center": "left",
        "right_center": "right",
        "full_center": "full",
        "center": "full",
    }
    return key_map.get(first_arg.value.strip().lower().replace("-", "_"))


def _fix_layout_canvas_center_alias_method_calls(code: str) -> Tuple[Optional[str], str]:
    """Normalize layout_canvas("top_center") point aliases to supported area keys."""
    if "self.layout_canvas(" not in code or "center" not in code:
        return None, ""

    key_map = {
        "top_center": "top",
        "bottom_center": "bottom",
        "bottom_caption": "bottom",
        "left_center": "left",
        "right_center": "right",
        "full_center": "full",
        "center": "full",
    }
    changed = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal changed
        changed += 1
        area = key_map[match.group("key")]
        return f'self.layout_canvas("{area}")["center"]'

    current = _LAYOUT_CANVAS_CENTER_ALIAS_SUBSCRIPT_RE.sub(_replace, code)

    try:
        tree = ast.parse(current)
    except SyntaxError:
        if changed == 0 or current == code:
            return None, ""
        return current, f"layout_canvas中心别名方法调用修复: {changed}处"

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr not in {"move_to", "next_to"}:
            continue
        if not node.args:
            continue
        first_arg = node.args[0]
        area = _layout_canvas_center_alias_area(first_arg)
        if area is None:
            continue
        span = _positioned_node_span(first_arg, current)
        if not span:
            continue
        replacements.append((span[0], span[1], f'self.layout_canvas("{area}")["center"]'))

    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
        changed += 1

    if changed == 0 or current == code:
        return None, ""
    return current, f"layout_canvas中心别名方法调用修复: {changed}处"


def _legacy_layout_canvas_area(zone_name: str | None, align: str | None) -> str:
    zone = (zone_name or "").strip().lower().replace("-", "_")
    alignment = (align or "").strip().lower().replace("-", "_")

    if alignment in {"top", "top_center", "top-center"}:
        return "top"
    if alignment in {"bottom", "bottom_center", "bottom-center"}:
        return "bottom"
    if alignment in {"left", "left_center", "left-center"}:
        return "left"
    if alignment in {"right", "right_center", "right-center"}:
        return "right"

    zone_map = {
        "top": "top",
        "title": "top",
        "title_zone": "top",
        "header": "top",
        "header_zone": "top",
        "top_center": "top",
        "top_left": "top",
        "top_right": "top",
        "bottom": "bottom",
        "footer": "bottom",
        "footer_zone": "bottom",
        "caption": "bottom",
        "caption_zone": "bottom",
        "bottom_caption": "bottom",
        "formula": "bottom",
        "formula_zone": "bottom",
        "bottom_center": "bottom",
        "bottom_left": "bottom",
        "bottom_right": "bottom",
        "content": "full",
        "content_zone": "full",
        "content_center": "full",
        "diagram": "full",
        "diagram_zone": "full",
        "main": "full",
        "main_zone": "full",
        "full_center": "full",
        "left": "left",
        "left_center": "left",
        "left_zone": "left",
        "left_content": "left",
        "left_col": "left",
        "left_panel": "left",
        "left_pane": "left",
        "left_side": "left",
        "left_canvas": "left",
        "left_area": "left",
        "content_left": "left",
        "diagram_left": "left",
        "visual_left": "left",
        "formula_left": "left",
        "right": "right",
        "right_center": "right",
        "right_zone": "right",
        "right_content": "right",
        "right_col": "right",
        "right_panel": "right",
        "right_pane": "right",
        "right_side": "right",
        "right_canvas": "right",
        "right_area": "right",
        "content_right": "right",
        "diagram_right": "right",
        "visual_right": "right",
        "formula_right": "right",
    }
    return zone_map.get(zone, "full")


def _layout_canvas_anchor_expr(area: str) -> str:
    """Return a point expression that preserves coarse corner intent.

    Older generated code sometimes used area names like ``bottom_right`` as a
    point anchor. Collapsing those names to the parent area's center makes dense
    formula/diagram scenes crowd into the same line, so keep a deterministic
    horizontal offset for left/right corner anchors.
    """
    normalized = (area or "").strip().lower().replace("-", "_")
    base_area = _legacy_layout_canvas_area(normalized, None)
    expr = f'self.layout_canvas("{base_area}")["center"]'
    if normalized in {
        "top_left",
        "bottom_left",
        "left_top",
        "left_bottom",
        "left_content",
        "left_pane",
        "left_zone",
        "content_left",
        "diagram_left",
        "visual_left",
        "formula_left",
    }:
        expr += f' + LEFT * self.layout_canvas("{base_area}").get("width", 0) * 0.35'
    elif normalized in {
        "top_right",
        "bottom_right",
        "right_top",
        "right_bottom",
        "right_content",
        "right_pane",
        "right_zone",
        "content_right",
        "diagram_right",
        "visual_right",
        "formula_right",
    }:
        expr += f' + RIGHT * self.layout_canvas("{base_area}").get("width", 0) * 0.35'
    return expr


def _string_keyword_value(call: ast.Call, name: str) -> str | None:
    for keyword in call.keywords:
        if keyword.arg != name:
            continue
        value = keyword.value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            return value.value
    return None


def _is_self_layout_canvas_call(call: ast.Call) -> bool:
    return (
        isinstance(call.func, ast.Attribute)
        and call.func.attr == "layout_canvas"
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "self"
    )


def _statement_followup_indent(code: str, start: int) -> str:
    line_start = code.rfind("\n", 0, start) + 1
    prefix = code[line_start:start]
    match = re.match(r"[ \t]*", prefix)
    return match.group(0) if match else ""


def _legacy_layout_canvas_replacement(
    *,
    mob_source: str,
    area: str,
    indent: str,
) -> str:
    anchor_expr = _layout_canvas_anchor_expr(area)
    lines = [f"{mob_source}.move_to({anchor_expr})"]
    if mob_source.isidentifier():
        lines.extend(
            [
                'if "visible_objects" not in locals():',
                "    visible_objects = []",
                'if hasattr(self, "place_non_overlapping"):',
                (
                    f"    {mob_source} = self.place_non_overlapping("
                    f"{mob_source}, anchor={anchor_expr}, "
                    f"others=visible_objects, area={_legacy_layout_canvas_area(area, None)!r})"
                ),
                f"if {mob_source} not in visible_objects:",
                f"    visible_objects.append({mob_source})",
            ]
        )
    return ("\n" + indent).join(lines)


def _fix_legacy_layout_canvas_mobject_calls(code: str) -> Tuple[Optional[str], str]:
    """Rewrite old layout_canvas(mobject, zone_name=..., align=...) placement calls."""
    if "self.layout_canvas(" not in code or ("zone_name" not in code and "align" not in code):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for statement in ast.walk(tree):
        if not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call):
            continue
        call = statement.value
        if not _is_self_layout_canvas_call(call) or not call.args:
            continue
        if not any(keyword.arg in {"zone_name", "align"} for keyword in call.keywords):
            continue
        first_arg = call.args[0]
        if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
            continue
        mob_source = ast.get_source_segment(code, first_arg) or ast.unparse(first_arg)
        if not mob_source:
            continue
        zone_name = _string_keyword_value(call, "zone_name")
        align = _string_keyword_value(call, "align")
        if zone_name is None and align is None:
            continue
        area = _legacy_layout_canvas_area(zone_name, align)
        span = _source_span_for_multiline_node(statement, code)
        if span is None:
            continue
        indent = _statement_followup_indent(code, span[0])
        replacements.append(
            (
                span[0],
                span[1],
                _legacy_layout_canvas_replacement(
                    mob_source=mob_source,
                    area=area,
                    indent=indent,
                ),
            )
        )

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    return current, f"layout_canvas旧式调用兼容: {len(replacements)}处"


def _canvas_dict_expr_source(node: ast.AST, code: str, canvas_vars: set[str]) -> str | None:
    if (
        isinstance(node, ast.Attribute)
        and isinstance(node.value, ast.Name)
        and node.value.id == "self"
        and (
            node.attr == "full_canvas"
            or node.attr in {
                "left_canvas",
                "right_canvas",
                "top_canvas",
                "bottom_canvas",
            }
        )
    ):
        return f"self.{node.attr}"

    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and node.func.attr == "layout_canvas"
    ):
        span = _positioned_node_span(node, code)
        return code[span[0]:span[1]] if span else None

    if isinstance(node, ast.Name) and node.id in canvas_vars:
        return node.id

    return None


def _numeric_offset_source(node: ast.AST, code: str) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return repr(float(node.value)) if isinstance(node.value, float) else str(node.value)
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, (ast.USub, ast.UAdd))
        and isinstance(node.operand, ast.Constant)
        and isinstance(node.operand.value, (int, float))
    ):
        span = _positioned_node_span(node, code)
        return code[span[0]:span[1]] if span else None
    return None


def _canvas_center_expr_source(node: ast.AST, code: str, canvas_vars: set[str]) -> str | None:
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and node.func.attr == "layout_canvas"
    ):
        area = _layout_canvas_area_literal(node)
        if area is not None:
            return _layout_canvas_anchor_expr(area)

    source = _canvas_dict_expr_source(node, code, canvas_vars)
    if source is None:
        return None
    return f'{source}["center"]'


def _fix_canvas_dict_arithmetic(code: str) -> Tuple[Optional[str], str]:
    """Rewrite canvas dict +/- float into center-vector offsets."""
    if not any(token in code for token in ("full_canvas", "layout_canvas", "_canvas")):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    canvas_vars: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if _canvas_dict_expr_source(node.value, code, canvas_vars) is None:
            continue
        for target in node.targets:
            if isinstance(target, ast.Name):
                canvas_vars.add(target.id)

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.BinOp) or not isinstance(node.op, (ast.Add, ast.Sub)):
            continue
        canvas_source = _canvas_dict_expr_source(node.left, code, canvas_vars)
        center_source = _canvas_center_expr_source(node.left, code, canvas_vars)
        offset_source = _numeric_offset_source(node.right, code)
        if not canvas_source or not center_source:
            continue
        span = _positioned_node_span(node, code)
        if not span:
            continue
        if offset_source:
            direction = "UP" if isinstance(node.op, ast.Add) else "DOWN"
            replacements.append(
                (span[0], span[1], f"{center_source} + {direction} * {offset_source}")
            )
            continue
        rhs_source = ast.get_source_segment(code, node.right)
        if rhs_source and _canvas_dict_expr_source(node.right, code, canvas_vars) is None:
            operator = "+" if isinstance(node.op, ast.Add) else "-"
            replacements.append((span[0], span[1], f"{center_source} {operator} {rhs_source}"))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"canvas dict算术修复: {len(replacements)}处"


def _is_center_key_subscript(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Subscript)
        and isinstance(node.slice, ast.Constant)
        and node.slice.value == "center"
    )


def _expr_contains_canvas_center(
    node: ast.AST,
    code: str,
    canvas_vars: set[str],
) -> bool:
    if _is_center_key_subscript(node) and _canvas_dict_expr_source(
        node.value,
        code,
        canvas_vars,
    ):
        return True
    return any(
        _expr_contains_canvas_center(child, code, canvas_vars)
        for child in ast.iter_child_nodes(node)
    )


def _fix_canvas_center_vector_subscripts(code: str) -> Tuple[Optional[str], str]:
    """Rewrite center-vector variables incorrectly indexed as dicts."""
    if '"center"' not in code and "'center'" not in code:
        return None, ""
    if not any(token in code for token in ("full_canvas", "layout_canvas", "_canvas")):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    canvas_vars: set[str] = set()
    vector_vars: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if (
            isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Attribute)
            and node.value.func.attr == "layout_canvas"
            and node.value.args
            and isinstance(node.value.args[0], ast.Constant)
            and node.value.args[0].value in {
                "center",
                "top_center",
                "bottom_center",
                "left_center",
                "right_center",
                "full_center",
            }
        ):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    vector_vars.add(target.id)
            continue
        if _canvas_dict_expr_source(node.value, code, canvas_vars) is not None:
            for target in node.targets:
                if isinstance(target, ast.Name):
                    canvas_vars.add(target.id)
            continue
        if _expr_contains_canvas_center(node.value, code, canvas_vars):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    vector_vars.add(target.id)

    if not vector_vars:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not _is_center_key_subscript(node):
            continue
        if not isinstance(node.value, ast.Name) or node.value.id not in vector_vars:
            continue
        span = _positioned_node_span(node, code)
        if not span:
            continue
        replacements.append((span[0], span[1], node.value.id))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"canvas中心向量下标修复: {len(replacements)}处"


def _fix_canvas_dict_legacy_bounds_indexing(code: str) -> Tuple[Optional[str], str]:
    """Rewrite old canvas[0..3] tuple-bound access for dict layout regions."""
    if "layout_canvas" not in code and "_canvas" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    canvas_vars: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if _canvas_dict_expr_source(node.value, code, canvas_vars) is None:
            continue
        for target in node.targets:
            if isinstance(target, ast.Name):
                canvas_vars.add(target.id)

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Subscript):
            continue
        index_node = node.slice
        if not isinstance(index_node, ast.Constant) or index_node.value not in {0, 1, 2, 3}:
            continue
        source = _canvas_dict_expr_source(node.value, code, canvas_vars)
        if not source:
            continue
        span = _positioned_node_span(node, code)
        if not span:
            continue
        index = int(index_node.value)
        if index == 0:
            replacement = f'({source}["center"][0] - {source}.get("width", 0) / 2)'
        elif index == 1:
            replacement = f'({source}["center"][0] + {source}.get("width", 0) / 2)'
        elif index == 2:
            replacement = f'({source}["center"][1] - {source}.get("height", 0) / 2)'
        else:
            replacement = f'({source}["center"][1] + {source}.get("height", 0) / 2)'
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"canvas dict旧边界索引修复: {len(replacements)}处"


def _fix_layout_canvas_tuple_unpack(code: str) -> Tuple[Optional[str], str]:
    """Rewrite tuple unpacking of layout_canvas dicts to explicit field reads."""
    if "self.layout_canvas(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Tuple):
            continue
        if not _is_self_layout_canvas_call(node.value):
            continue
        targets = list(node.targets[0].elts)
        if len(targets) not in {3, 4}:
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        call_source = ast.get_source_segment(code, node.value)
        if not call_source:
            continue
        if len(targets) == 3:
            field_exprs = [
                f'{call_source}.get("center", ORIGIN)',
                f'{call_source}.get("width", 0)',
                f'{call_source}.get("height", 0)',
            ]
        else:
            center_x = f'{call_source}.get("center", ORIGIN)[0]'
            center_y = f'{call_source}.get("center", ORIGIN)[1]'
            width = f'{call_source}.get("width", 0)'
            height = f'{call_source}.get("height", 0)'
            field_exprs = [
                f"({center_x} - {width} / 2)",
                f"({center_x} + {width} / 2)",
                f"({center_y} - {height} / 2)",
                f"({center_y} + {height} / 2)",
            ]
        line_start = code.rfind("\n", 0, span[0]) + 1
        indent = code[line_start:span[0]]
        lines: list[str] = []
        for target, field_expr in zip(targets, field_exprs):
            target_source = ast.get_source_segment(code, target)
            if not target_source or target_source.strip() == "_":
                continue
            lines.append(f"{indent}{target_source} = {field_expr}")
        if not lines:
            lines.append(f"{indent}{call_source}")
        replacements.append((line_start, span[1], "\n".join(lines)))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"layout_canvas dict解包修复: {len(replacements)}处"


def _layout_canvas_area_literal(node: ast.AST) -> str | None:
    if not (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and node.func.attr == "layout_canvas"
        and node.args
        and isinstance(node.args[0], ast.Constant)
        and isinstance(node.args[0].value, str)
    ):
        return None
    return node.args[0].value


def _simple_name_targets_for_repair(targets: Iterable[ast.AST]) -> list[str]:
    names: list[str] = []
    for target in targets:
        if isinstance(target, ast.Name):
            names.append(target.id)
    return names


class _LayoutCanvasAreaArgScopeVisitor(ast.NodeVisitor):
    def __init__(self, root: ast.AST):
        self.root = root
        self.assignments: list[tuple[str, tuple[int, int], str | None]] = []
        self.calls: list[ast.Call] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        area = _layout_canvas_area_literal(node.value)
        order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        for name in _simple_name_targets_for_repair(node.targets):
            self.assignments.append((name, order, area))
        self.generic_visit(node.value)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        area = _layout_canvas_area_literal(node.value) if node.value is not None else None
        order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        for name in _simple_name_targets_for_repair([node.target]):
            self.assignments.append((name, order, area))
        if node.value is not None:
            self.generic_visit(node.value)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        for name in _simple_name_targets_for_repair([node.target]):
            self.assignments.append((name, order, None))
        self.generic_visit(node.value)

    def visit_Call(self, node: ast.Call) -> None:
        if (
            isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "self"
            and node.func.attr in {"fit_to_canvas", "clamp_to_canvas"}
            and len(node.args) >= 2
            and not any(keyword.arg == "area" for keyword in node.keywords)
        ):
            self.calls.append(node)
        self.generic_visit(node)

    def alias_area_before(self, name: str, node: ast.AST) -> str | None:
        call_order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        prior = [
            (order, area)
            for assigned_name, order, area in self.assignments
            if assigned_name == name and order < call_order
        ]
        if not prior:
            return None
        _order, area = max(prior, key=lambda item: item[0])
        return area


def _fix_layout_canvas_dict_positional_area(code: str) -> Tuple[Optional[str], str]:
    """Rewrite helper(mob, layout_canvas_dict) to helper(mob, area="area")."""
    if "self.layout_canvas(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    scope_nodes = [
        node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]
    for scope in scope_nodes:
        visitor = _LayoutCanvasAreaArgScopeVisitor(scope)
        visitor.visit(scope)
        for node in visitor.calls:
            area = _layout_canvas_area_literal(node.args[1])
            if area is None and isinstance(node.args[1], ast.Name):
                area = visitor.alias_area_before(node.args[1].id, node)
            if not area:
                continue
            span = _positioned_node_span(node.args[1], code)
            if not span:
                continue
            replacements.append((span[0], span[1], f"area={area!r}"))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"layout_canvas dict位置参数修复: {len(replacements)}处"


def _is_self_layout_canvas_call(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "layout_canvas"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _fix_layout_canvas_dict_point_arguments(code: str) -> Tuple[Optional[str], str]:
    """Rewrite move_to/next_to(layout_canvas(...)) to use the region center."""
    if "self.layout_canvas(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr not in {"move_to", "next_to"}:
            continue
        if not node.args:
            continue
        first_arg = node.args[0]
        if not _is_self_layout_canvas_call(first_arg):
            continue
        span = _positioned_node_span(first_arg, code)
        if not span:
            continue
        source = code[span[0]:span[1]]
        area = _layout_canvas_area_literal(first_arg)
        point_expr = _layout_canvas_anchor_expr(area) if area is not None else f'{source}["center"]'
        replacements.append((span[0], span[1], point_expr))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"layout_canvas dict点位参数修复: {len(replacements)}处"


_LAYOUT_CANVAS_DICT_ATTR_FIELDS = {
    "center": ("center", "ORIGIN"),
    "width": ("width", "0"),
    "height": ("height", "0"),
    "left": ("left", "0"),
    "right": ("right", "0"),
    "top": ("top", "0"),
    "bottom": ("bottom", "0"),
    "x_min": ("x_min", "0"),
    "x_max": ("x_max", "0"),
    "y_min": ("y_min", "0"),
    "y_max": ("y_max", "0"),
    "left_center": ("left_center", "ORIGIN"),
    "right_center": ("right_center", "ORIGIN"),
    "top_center": ("top_center", "ORIGIN"),
    "bottom_center": ("bottom_center", "ORIGIN"),
}

_LAYOUT_CANVAS_DICT_METHOD_FIELDS = {
    "get_center": ("center", "ORIGIN"),
    "get_width": ("width", "0"),
    "get_height": ("height", "0"),
}


class _LayoutCanvasDictAliasVisitor(ast.NodeVisitor):
    def __init__(self, root: ast.AST):
        self.root = root
        self.assignments: list[tuple[str, tuple[int, int], bool]] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        is_layout_dict = _is_self_layout_canvas_call(node.value)
        for name in _simple_name_targets_for_repair(node.targets):
            self.assignments.append((name, order, is_layout_dict))
        self.generic_visit(node.value)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        is_layout_dict = _is_self_layout_canvas_call(node.value) if node.value is not None else False
        for name in _simple_name_targets_for_repair([node.target]):
            self.assignments.append((name, order, is_layout_dict))
        if node.value is not None:
            self.generic_visit(node.value)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        for name in _simple_name_targets_for_repair([node.target]):
            self.assignments.append((name, order, False))
        self.generic_visit(node.value)

    def is_layout_alias_before(self, name: str, node: ast.AST) -> bool:
        node_order = (getattr(node, "lineno", 0), getattr(node, "col_offset", 0))
        prior = [
            (order, is_layout)
            for assigned_name, order, is_layout in self.assignments
            if assigned_name == name and order < node_order
        ]
        if not prior:
            return False
        _order, is_layout = max(prior, key=lambda item: item[0])
        return is_layout


def _layout_canvas_dict_get_expr(source: str, field: str, default: str) -> str:
    return f'{source}.get("{field}", {default})'


def _layout_canvas_dict_field_expr(
    *,
    source_node: ast.AST,
    code: str,
    field: str,
    default: str,
    method_name: str | None = None,
) -> str | None:
    source = ast.get_source_segment(code, source_node)
    if not source:
        return None
    if (
        method_name == "get_center"
        and isinstance(source_node, ast.Call)
        and _is_self_layout_canvas_call(source_node)
    ):
        area = _layout_canvas_area_literal(source_node)
        if area is not None:
            return _layout_canvas_anchor_expr(area)
    return _layout_canvas_dict_get_expr(source, field, default)


def _fix_layout_canvas_dict_attribute_access(code: str) -> Tuple[Optional[str], str]:
    """Rewrite layout_canvas dicts that generated code treats as mobjects."""
    if "self.layout_canvas(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    scope_visitors: list[tuple[ast.AST, _LayoutCanvasDictAliasVisitor]] = []
    for scope in ast.walk(tree):
        if not isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        visitor = _LayoutCanvasDictAliasVisitor(scope)
        visitor.visit(scope)
        scope_visitors.append((scope, visitor))

    replacements: list[tuple[int, int, str]] = []

    for scope, visitor in scope_visitors:
        for node in ast.walk(scope):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                field_info = _LAYOUT_CANVAS_DICT_METHOD_FIELDS.get(node.func.attr)
                if not field_info:
                    continue
                field, default = field_info
                source_node = node.func.value
                if _is_self_layout_canvas_call(source_node):
                    replacement = _layout_canvas_dict_field_expr(
                        source_node=source_node,
                        code=code,
                        field=field,
                        default=default,
                        method_name=node.func.attr,
                    )
                elif (
                    isinstance(source_node, ast.Name)
                    and visitor.is_layout_alias_before(source_node.id, node)
                ):
                    replacement = _layout_canvas_dict_get_expr(source_node.id, field, default)
                else:
                    replacement = None
                if not replacement:
                    continue
                span = _positioned_node_span(node, code)
                if not span:
                    continue
                replacements.append((span[0], span[1], replacement))

            elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load):
                field_info = _LAYOUT_CANVAS_DICT_ATTR_FIELDS.get(node.attr)
                if not field_info:
                    continue
                field, default = field_info
                if _is_self_layout_canvas_call(node.value):
                    replacement = _layout_canvas_dict_field_expr(
                        source_node=node.value,
                        code=code,
                        field=field,
                        default=default,
                    )
                elif (
                    isinstance(node.value, ast.Name)
                    and visitor.is_layout_alias_before(node.value.id, node)
                ):
                    replacement = _layout_canvas_dict_get_expr(node.value.id, field, default)
                else:
                    replacement = None
                if not replacement:
                    continue
                span = _positioned_node_span(node, code)
                if not span:
                    continue
                replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"layout_canvas dict属性访问修复: {len(replacements)}处"


def _fix_layout_canvas_dict_keyword_area(code: str) -> Tuple[Optional[str], str]:
    """Rewrite area=<layout_canvas dict> keyword values back to area names."""
    if "area=" not in code or "self.layout_canvas(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    scope_nodes = [
        node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]
    for scope in scope_nodes:
        visitor = _LayoutCanvasAreaArgScopeVisitor(scope)
        visitor.visit(scope)
        for node in ast.walk(scope):
            if not isinstance(node, ast.Call):
                continue
            for keyword in node.keywords:
                if keyword.arg != "area":
                    continue
                area = _layout_canvas_area_literal(keyword.value)
                if area is None and isinstance(keyword.value, ast.Name):
                    area = visitor.alias_area_before(keyword.value.id, node)
                if not area:
                    continue
                mapped = _legacy_layout_canvas_area(area, None)
                span = _positioned_node_span(keyword.value, code)
                if not span:
                    continue
                replacements.append((span[0], span[1], repr(mapped)))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"layout_canvas dict面积关键字修复: {len(replacements)}处"


def _numeric_bounds_list_values(node: ast.AST) -> tuple[float, float, float, float] | None:
    if not isinstance(node, (ast.List, ast.Tuple)) or len(node.elts) != 4:
        return None
    try:
        values = ast.literal_eval(node)
    except Exception:
        return None
    if not isinstance(values, (list, tuple)) or len(values) != 4:
        return None
    numeric: list[float] = []
    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        numeric.append(float(value))
    left, right, bottom, top = numeric
    if right == left or top == bottom:
        return None
    return left, right, bottom, top


def _compact_float(value: float) -> str:
    if abs(value) < 1e-9:
        value = 0.0
    formatted = f"{value:.6g}"
    return "0" if formatted == "-0" else formatted


def _fix_fit_to_canvas_numeric_bounds_area(code: str) -> Tuple[Optional[str], str]:
    """Honor generated fit_to_canvas(mob, [left, right, bottom, top]) calls."""
    if "fit_to_canvas" not in code or "[" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for statement in ast.walk(tree):
        if not isinstance(statement, ast.Expr):
            continue
        call = statement.value
        if not isinstance(call, ast.Call):
            continue
        if not (
            isinstance(call.func, ast.Attribute)
            and isinstance(call.func.value, ast.Name)
            and call.func.value.id == "self"
            and call.func.attr == "fit_to_canvas"
        ):
            continue
        if len(call.args) < 2 or call.keywords:
            continue
        bounds = _numeric_bounds_list_values(call.args[1])
        if bounds is None:
            continue
        mob_source = ast.get_source_segment(code, call.args[0])
        if not mob_source or not _SIMPLE_MOBJECT_NAME_RE.fullmatch(mob_source.strip()):
            continue
        span = _source_span_for_multiline_node(statement, code)
        if span is None:
            continue
        line = code.splitlines()[max(0, statement.lineno - 1)]
        indent = line[: len(line) - len(line.lstrip())]
        left, right, bottom, top = bounds
        width = abs(right - left)
        height = abs(top - bottom)
        center_x = (left + right) / 2.0
        center_y = (bottom + top) / 2.0
        mob_name = mob_source.strip()
        replacement = "\n".join(
            [
                (
                    f'{indent}self.fit_to_canvas({mob_name}, "full", '
                    f"max_width={_compact_float(width)}, max_height={_compact_float(height)})"
                ),
                (
                    f"{indent}{mob_name}.move_to("
                    f"ORIGIN + RIGHT * {_compact_float(center_x)} + UP * {_compact_float(center_y)})"
                ),
            ]
        )
        start = code.rfind("\n", 0, span[0]) + 1
        end = _extend_span_to_trailing_newline(code, span[1])
        replacements.append((start, end, replacement + "\n"))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"fit_to_canvas数值边界区域修复: {len(replacements)}处"


_NEXT_TO_SELF_DIRECTION_RE = re.compile(
    r"\.next_to\(\s*self\s*,\s*getattr\(\s*self\s*,\s*['\"]direction['\"]\s*,\s*UP\s*\)\s*,\s*buff\s*=\s*[^)]*?\)"
)


def _fix_next_to_self_direction_calls(code: str) -> Tuple[Optional[str], str]:
    """Drop invalid next_to(self, getattr(self, "direction", UP), ...) calls."""
    if "next_to(self" not in code or "getattr(self" not in code:
        return None, ""
    current, count = _NEXT_TO_SELF_DIRECTION_RE.subn("", code)
    if count == 0 or current == code:
        return None, ""
    return current, f"next_to(self,direction)无效锚点修复: {count}处"


def _fix_missing_cube_edge_pairs_global(code: str) -> Tuple[Optional[str], str]:
    """Expose the standard cube edge list when later scenes reuse edge_pairs."""
    if "edge_pairs" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    has_edge_pair_load = any(
        isinstance(node, ast.Name)
        and isinstance(node.ctx, ast.Load)
        and node.id == "edge_pairs"
        for node in ast.walk(tree)
    )
    if not has_edge_pair_load:
        return None, ""

    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if any(isinstance(target, ast.Name) and target.id == "edge_pairs" for target in targets):
            return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    block = [
        "",
        "edge_pairs = [",
        "    (\"A\", \"B\"), (\"B\", \"C\"), (\"C\", \"D\"), (\"D\", \"A\"),",
        "    (\"A1\", \"B1\"), (\"B1\", \"C1\"), (\"C1\", \"D1\"), (\"D1\", \"A1\"),",
        "    (\"A\", \"A1\"), (\"B\", \"B1\"), (\"C\", \"C1\"), (\"D\", \"D1\"),",
        "]",
    ]
    lines[insert_at:insert_at] = block
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "3D立方体edge_pairs全局兜底",
    )


def _fix_number_line_add_labels_without_values(code: str) -> Tuple[Optional[str], str]:
    """Rewrite label-less NumberLine.add_labels(...) to add_numbers(...)."""
    if ".add_labels(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "add_labels" or node.args:
            continue
        span = _positioned_node_span(node.func, code)
        if not span:
            continue
        source = code[span[0]:span[1]]
        if not source.endswith(".add_labels"):
            continue
        replacements.append((span[0], span[1], source[: -len("add_labels")] + "add_numbers"))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"NumberLine.add_labels无标签值兼容修复: {len(replacements)}处"


_NON_COORDS_TO_POINT_MOBJECT_CLASSES = {
    "Arc",
    "Circle",
    "Dot",
    "Line",
    "Polygon",
    "Rectangle",
    "Shape",
    "Square",
    "Text",
    "Tex",
    "MathTex",
    "Triangle",
    "VGroup",
}


def _coords_to_point_array_expr(call: ast.Call, code: str) -> str | None:
    if len(call.args) not in {2, 3} or call.keywords:
        return None
    values: list[str] = []
    for arg in call.args:
        if isinstance(arg, ast.Starred):
            return None
        source = ast.get_source_segment(code, arg)
        if not source:
            return None
        values.append(source.strip())
    if len(values) == 2:
        values.append("0.0")
    return f"np.array([{', '.join(values)}])"


def _fix_shape_coords_to_point_misuse(code: str) -> Tuple[Optional[str], str]:
    """Rewrite coords_to_point on non-coordinate mobjects to a conservative point."""
    if "coords_to_point" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    mobject_vars: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        value = node.value
        if not isinstance(target, ast.Name) or not isinstance(value, ast.Call):
            continue
        if _call_func_name(value.func) in _NON_COORDS_TO_POINT_MOBJECT_CLASSES:
            mobject_vars.add(target.id)

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "coords_to_point"
        ):
            continue
        owner = node.func.value
        should_rewrite = False
        if isinstance(owner, ast.Name):
            should_rewrite = (
                owner.id in mobject_vars
                or owner.id in _NON_COORDS_TO_POINT_MOBJECT_CLASSES
            )
        elif isinstance(owner, ast.Call):
            should_rewrite = _call_func_name(owner.func) in _NON_COORDS_TO_POINT_MOBJECT_CLASSES
        if not should_rewrite:
            continue
        replacement = _coords_to_point_array_expr(node, code)
        span = _positioned_node_span(node, code)
        if replacement and span:
            replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    if not re.search(r"(?m)^\s*import\s+numpy\s+as\s+np\b", current):
        lines = current.splitlines()
        insert_at = _module_alias_insert_index(current)
        lines[insert_at:insert_at] = ["import numpy as np"]
        current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, f"coords_to_point误用修复: {len(replacements)}处"


def _inject_safe_unpack_part_helper(code: str) -> str:
    if "def _mathpi_safe_unpack_part(" in code:
        return code
    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    helper = [
        "",
        "def _mathpi_safe_unpack_part(group, index):",
        "    try:",
        "        return group[index]",
        "    except Exception:",
        "        if index == 0:",
        "            return group",
        "        return VGroup()",
        "",
    ]
    lines[insert_at:insert_at] = helper
    return "\n".join(lines) + ("\n" if code.endswith("\n") else "")


def _fix_vgroup_tuple_unpack_shortfall(code: str) -> Tuple[Optional[str], str]:
    """Avoid runtime 'not enough values to unpack' for short literal VGroups."""
    if "VGroup(" not in code or "," not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    counter = 0
    for statement in ast.walk(tree):
        if not isinstance(statement, ast.Assign) or len(statement.targets) != 1:
            continue
        target = statement.targets[0]
        value = statement.value
        if not (
            isinstance(target, (ast.Tuple, ast.List))
            and isinstance(value, ast.Call)
            and _call_func_name(value.func) == "VGroup"
        ):
            continue
        if any(isinstance(arg, ast.Starred) for arg in value.args):
            continue
        targets = list(target.elts)
        if len(value.args) >= len(targets) or not targets:
            continue
        target_sources: list[str] = []
        for item in targets:
            if isinstance(item, ast.Starred):
                target_sources = []
                break
            source = ast.get_source_segment(code, item)
            if not source:
                target_sources = []
                break
            target_sources.append(source.strip())
        if not target_sources:
            continue
        value_source = ast.get_source_segment(code, value)
        span = _source_span_for_multiline_node(statement, code)
        if not value_source or span is None:
            continue
        line = code.splitlines()[statement.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        counter += 1
        temp_name = f"__mathpi_unpack_{counter}"
        replacement_lines = [f"{indent}{temp_name} = {value_source.strip()}"]
        replacement_lines.extend(
            f"{indent}{target_source} = _mathpi_safe_unpack_part({temp_name}, {index})"
            for index, target_source in enumerate(target_sources)
        )
        start = code.rfind("\n", 0, span[0]) + 1
        end = _extend_span_to_trailing_newline(code, span[1])
        replacement = "\n".join(replacement_lines)
        if end > span[1]:
            replacement += "\n"
        replacements.append((start, end, replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    current = _inject_safe_unpack_part_helper(current)
    return current, f"VGroup解包短缺修复: {len(replacements)}处"


def _fix_mathtex_frac_text_color_map_split(code: str) -> Tuple[Optional[str], str]:
    """Avoid Manim splitting \\frac{\\text{...}} by tex_to_color_map substrings."""
    if "tex_to_color_map" not in code or "\\frac" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    removals: list[tuple[int, int]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "MathTex":
            continue
        has_fragile_frac = False
        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                value = arg.value
                if "\\frac" in value and ("\\text{" in value or "\\mathrm{" in value):
                    has_fragile_frac = True
                    break
        if not has_fragile_frac:
            continue
        for keyword in node.keywords:
            if keyword.arg != "tex_to_color_map":
                continue
            span = _keyword_removal_span_for_repair(keyword, code, lines, line_offsets)
            if span is None:
                value_span = _source_span_for_multiline_node(keyword.value, code)
                if value_span and keyword.arg:
                    value_start, value_end = value_span
                    line_index = keyword.value.lineno - 1
                    line_start = line_offsets[line_index]
                    key_start = code.rfind(keyword.arg, line_start, value_start)
                    if key_start >= line_start:
                        span = _keyword_removal_span(code, key_start, value_end)
            if span:
                removals.append(span)

    if not removals:
        return None, ""
    current = code
    for start, end in sorted(removals, key=lambda item: item[0], reverse=True):
        current = current[:start] + current[end:]
    return current, f"MathTex分式文本颜色映射拆分修复: {len(removals)}处"


def _get_base_geometry_tuple_unpack_targets(tree: ast.AST) -> int:
    count = 0
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value = node.value
        if not isinstance(value, ast.Call):
            continue
        if not (
            isinstance(value.func, ast.Attribute)
            and value.func.attr == "get_base_geometry"
            and isinstance(value.func.value, ast.Name)
            and value.func.value.id == "self"
        ):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if any(isinstance(target, (ast.Tuple, ast.List)) and len(target.elts) >= 5 for target in targets):
            count += 1
    return count


def _mathpi_geometry_base_contract_lines() -> list[str]:
    return [
        "class _MathPiGeometryBase(dict):",
        "    def _point(self, name, fallback=ORIGIN):",
        "        try:",
        "            arr = np.array(self.get(name, fallback), dtype=float)",
        "            if arr.shape[0] == 2:",
        "                return np.array([arr[0], arr[1], 0.0], dtype=float)",
        "            return arr[:3] if arr.shape[0] >= 3 else fallback",
        "        except Exception:",
        "            return fallback",
        "",
        "    def _valid_point(self, name):",
        "        value = self.get(name)",
        "        try:",
        "            arr = np.array(value, dtype=float)",
        "            return arr.shape[0] >= 2",
        "        except Exception:",
        "            return False",
        "",
        "    def as_group(self):",
        "        existing = self.get(\"geo_group\") or self.get(\"group\")",
        "        if hasattr(existing, \"add\") and hasattr(existing, \"__getitem__\"):",
        "            return existing",
        "        A = self._point(\"A\")",
        "        B = self._point(\"B\")",
        "        C = self._point(\"C\")",
        "        D = self._point(\"D\", (B + C) / 2.0)",
        "        color = self.get(\"_line_color\", globals().get(\"WHITE\", WHITE))",
        "        primary = self.get(\"triangle\") or self.get(\"polygon\") or self.get(\"shape\")",
        "        if not hasattr(primary, \"get_center\"):",
        "            try:",
        "                primary = Polygon(A, B, C, color=color, fill_opacity=0.08)",
        "            except Exception:",
        "                primary = VGroup()",
        "        group = VGroup(primary)",
        "        point_color = self.get(\"_point_color\", color)",
        "        for name, point in ((\"A\", A), (\"B\", B), (\"C\", C), (\"D\", D)):",
        "            if self._valid_point(name):",
        "                group.add(Dot(point, radius=0.035, color=point_color))",
        "        for key in (",
        "            \"right_angle\", \"bisector\", \"line_ad\", \"line_BD\", \"line_DC\",",
        "            \"label_A\", \"label_B\", \"label_C\", \"label_D\",",
        "            \"label_AB\", \"label_AC\", \"label_BC\",",
        "        ):",
        "            item = self.get(key)",
        "            if hasattr(item, \"get_center\") and item not in group:",
        "                group.add(item)",
        "        return group",
        "",
        "    def __iter__(self):",
        "        return iter((self.as_group(), self._point(\"A\"), self._point(\"B\"), self._point(\"C\"), self._point(\"D\")))",
        "",
    ]


def _fix_get_base_geometry_dict_contract(code: str) -> Tuple[Optional[str], str]:
    """Make generated get_base_geometry dict returns also support tuple-unpack callers."""
    if "def get_base_geometry" not in code or "self.get_base_geometry(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    unpack_count = _get_base_geometry_tuple_unpack_targets(tree)
    if unpack_count == 0:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or node.name != "get_base_geometry":
            continue
        for child in ast.walk(node):
            if not isinstance(child, ast.Return):
                continue
            value = child.value
            if isinstance(value, ast.Dict):
                span = _source_span_for_multiline_node(value, code)
                if span is None:
                    continue
                source = code[span[0]:span[1]]
                if source.lstrip().startswith("_MathPiGeometryBase("):
                    continue
                replacements.append((span[0], span[1], f"_MathPiGeometryBase({source})"))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]

    if "class _MathPiGeometryBase(dict)" not in current:
        lines = current.splitlines()
        insert_at = _module_alias_insert_index(current)
        helper_lines = _mathpi_geometry_base_contract_lines()
        if insert_at > 0 and lines[insert_at - 1].strip():
            helper_lines.insert(0, "")
        lines[insert_at:insert_at] = helper_lines
        current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")

    return current, f"get_base_geometry字典/元组合同修复: {len(replacements)}处"


def _collect_defined_and_loaded_names(code: str) -> tuple[set[str], set[str]]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return set(re.findall(r"(?m)^\s*(?:def|class)\s+([A-Za-z_][A-Za-z0-9_]*)\b", code)), set()

    defined: set[str] = set()
    loaded: set[str] = set()

    class Visitor(ast.NodeVisitor):
        def visit_Import(self, node: ast.Import) -> None:
            for alias in node.names:
                defined.add(alias.asname or alias.name.split(".", 1)[0])

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            for alias in node.names:
                if alias.name != "*":
                    defined.add(alias.asname or alias.name)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            defined.add(node.name)
            for arg in (
                list(node.args.posonlyargs)
                + list(node.args.args)
                + list(node.args.kwonlyargs)
            ):
                defined.add(arg.arg)
            if node.args.vararg:
                defined.add(node.args.vararg.arg)
            if node.args.kwarg:
                defined.add(node.args.kwarg.arg)
            self.generic_visit(node)

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            defined.add(node.name)
            self.generic_visit(node)

        def visit_Name(self, node: ast.Name) -> None:
            if isinstance(node.ctx, ast.Load):
                loaded.add(node.id)
            elif isinstance(node.ctx, (ast.Store, ast.Del)):
                defined.add(node.id)

    Visitor().visit(tree)
    return defined, loaded


def _deterministic_helper_shim_lines(missing: set[str]) -> list[str]:
    lines: list[str] = []
    if "full_canvas" in missing:
        lines.extend([
            'full_canvas = {"center": ORIGIN, "width": float(getattr(config, "frame_width", 14.222)) - 0.9, "height": float(getattr(config, "frame_height", 8.0)) - 0.9}',
            "",
        ])
    if {
        "get_arc_for_point",
        "get_square_geometry",
        "get_side_labels",
        "get_rhombus_points",
        "get_triangle_positions",
        "make_angle_arc",
        "make_triangle_and_labels",
        "rotate_point",
    } & missing:
        lines.extend([
            "def _mathpi_point3(value, fallback=ORIGIN):",
            "    try:",
            "        arr = np.array(value, dtype=float)",
            "        if arr.shape[0] == 2:",
            "            return np.array([arr[0], arr[1], 0.0], dtype=float)",
            "        return arr[:3] if arr.shape[0] >= 3 else fallback",
            "    except Exception:",
            "        return fallback",
            "",
        ])
    if "rotate_point" in missing:
        lines.extend([
            "def rotate_point(point, center=ORIGIN, angle=0.0, **_kwargs):",
            "    p = _mathpi_point3(point)",
            "    c = _mathpi_point3(center)",
            "    v = p - c",
            "    ca, sa = np.cos(float(angle or 0.0)), np.sin(float(angle or 0.0))",
            "    return c + np.array([v[0] * ca - v[1] * sa, v[0] * sa + v[1] * ca, v[2]], dtype=float)",
            "",
        ])
    if "get_triangle_positions" in missing:
        lines.extend([
            "def get_triangle_positions(center=ORIGIN, rows=5, row_spacing=0.8, col_spacing=1.0, **_kwargs):",
            "    c = _mathpi_point3(center)",
            "    try:",
            "        row_count = max(1, int(rows or 5))",
            "    except Exception:",
            "        row_count = 5",
            "    try:",
            "        row_gap = float(row_spacing or 0.8)",
            "    except Exception:",
            "        row_gap = 0.8",
            "    try:",
            "        col_gap = float(col_spacing or 1.0)",
            "    except Exception:",
            "        col_gap = 1.0",
            "    positions = {}",
            "    for n in range(row_count):",
            "        y = c[1] - n * row_gap",
            "        for k in range(n + 1):",
            "            x = c[0] + (k - n / 2.0) * col_gap",
            "            positions[(n, k)] = np.array([x, y, c[2]], dtype=float)",
            "    return positions",
            "",
        ])
    if {"get_arc_for_point", "make_angle_arc"} & missing:
        lines.extend([
            "def get_arc_for_point(p1=None, vertex=ORIGIN, p2=None, radius=0.35, color=YELLOW, **kwargs):",
            "    try:",
            "        start = _mathpi_point3(RIGHT if p1 is None else p1)",
            "        center = _mathpi_point3(vertex)",
            "        end = _mathpi_point3(UP if p2 is None else p2)",
            "        return Angle(",
            "            Line(center, start),",
            "            Line(center, end),",
            "            radius=float(radius or 0.35),",
            "            color=color,",
            "            other_angle=bool(kwargs.get(\"other_angle\", False)),",
            "        )",
            "    except Exception:",
            "        arc = Arc(radius=float(radius or 0.35), angle=kwargs.get(\"angle\", PI / 2), color=color)",
            "        try:",
            "            arc.move_to(_mathpi_point3(vertex))",
            "        except Exception:",
            "            pass",
            "        return arc",
            "",
        ])
    if "make_angle_arc" in missing:
        lines.extend([
            "def make_angle_arc(p1=None, vertex=ORIGIN, p2=None, radius=0.35, color=YELLOW, **kwargs):",
            "    return get_arc_for_point(p1=p1, vertex=vertex, p2=p2, radius=radius, color=color, **kwargs)",
            "",
        ])
    if "get_placed_sector" in missing:
        lines.extend([
            "def get_placed_sector(*args, index=None, sector=None, cols=4, columns=None, cell_width=1.1, cell_height=0.95, center=ORIGIN, scale=1.0, **kwargs):",
            "    for arg in args:",
            "        if sector is None and (hasattr(arg, \"move_to\") or hasattr(arg, \"submobjects\")):",
            "            sector = arg",
            "            continue",
            "        if index is None:",
            "            try:",
            "                index = int(arg)",
            "                continue",
            "            except Exception:",
            "                pass",
            "    try:",
            "        cols_value = max(1, int(columns or cols or 4))",
            "    except Exception:",
            "        cols_value = 4",
            "    try:",
            "        index_value = max(0, int(index or 0))",
            "    except Exception:",
            "        index_value = 0",
            "    row = index_value // cols_value",
            "    col = index_value % cols_value",
            "    x = (col - (cols_value - 1) / 2.0) * float(cell_width or 1.1)",
            "    y = -row * float(cell_height or 0.95)",
            "    try:",
            "        target = center + RIGHT * x + UP * y",
            "    except Exception:",
            "        target = ORIGIN + RIGHT * x + UP * y",
            "    def _new_sector():",
            "        color = kwargs.get(\"color\", kwargs.get(\"fill_color\", BLUE))",
            "        return Sector(angle=kwargs.get(\"angle\", PI / 2), outer_radius=kwargs.get(\"outer_radius\", kwargs.get(\"radius\", 0.45)), fill_color=color, fill_opacity=kwargs.get(\"fill_opacity\", 0.75), stroke_color=kwargs.get(\"stroke_color\", color), stroke_width=kwargs.get(\"stroke_width\", 2))",
            "    def _place(mob, offset=0):",
            "        item = mob if hasattr(mob, \"move_to\") else _new_sector()",
            "        if scale not in (None, 1, 1.0):",
            "            try:",
            "                item.scale(float(scale))",
            "            except Exception:",
            "                pass",
            "        item.move_to(target + RIGHT * (offset % cols_value) * float(cell_width or 1.1))",
            "        return item",
            "    if sector is None:",
            "        sector = _new_sector()",
            "    if isinstance(sector, (list, tuple)) and not hasattr(sector, \"move_to\"):",
            "        return VGroup(*[_place(item, offset) for offset, item in enumerate(sector)])",
            "    return _place(sector)",
            "",
        ])
    if "make_triangle_and_labels" in missing:
        lines.extend([
            "class _MathPiTriangleAndLabels(VGroup):",
            "    def __init__(self, triangle, labels):",
            "        self.triangle = triangle",
            "        self.labels = labels if isinstance(labels, VGroup) else VGroup(labels)",
            "        super().__init__(self.triangle, self.labels)",
            "    def __iter__(self):",
            "        return iter((self.triangle, self.labels))",
            "",
            "def make_triangle_and_labels(points=None, labels=(\"A\", \"B\", \"C\"), center=ORIGIN, scale=1.0, color=WHITE, label_color=None, font_size=28, buff=0.18, fill_opacity=0.0, **_kwargs):",
            "    if isinstance(points, dict):",
            "        raw_points = [points.get(name) for name in (\"A\", \"B\", \"C\")]",
            "    elif isinstance(points, (list, tuple)) and len(points) >= 3:",
            "        raw_points = list(points[:3])",
            "    else:",
            "        c = _mathpi_point3(center)",
            "        s = float(scale or 1.0)",
            "        raw_points = [c + UP * 1.15 * s, c + LEFT * 1.45 * s + DOWN * 1.0 * s, c + RIGHT * 1.45 * s + DOWN * 1.0 * s]",
            "    pts = [_mathpi_point3(point) for point in raw_points]",
            "    triangle = Polygon(*pts, color=color, stroke_width=_kwargs.get(\"stroke_width\", 3), fill_color=_kwargs.get(\"fill_color\", color), fill_opacity=fill_opacity)",
            "    label_values = list(labels or (\"A\", \"B\", \"C\"))",
            "    while len(label_values) < 3:",
            "        label_values.append(chr(ord(\"A\") + len(label_values)))",
            "    directions = [UP, DL, DR]",
            "    label_group = VGroup()",
            "    for text, point, direction in zip(label_values[:3], pts, directions):",
            "        label = MathTex(str(text), font_size=font_size, color=label_color or color)",
            "        label.next_to(Dot(point, radius=0.01), direction, buff=buff)",
            "        label_group.add(label)",
            "    return _MathPiTriangleAndLabels(triangle, label_group)",
            "",
        ])
    if {"create_cube_elements", "get_cube_elements"} & missing:
        lines.extend([
            "def create_cube_elements(main_color=BLUE, accent_color=YELLOW, text_color=WHITE, side_length=2.0, **_kwargs):",
            "    side = float(side_length or 2.0)",
            "    half = side / 2.0",
            "    points = {",
            "        \"A\": np.array([-half, -half, -half]), \"B\": np.array([half, -half, -half]),",
            "        \"C\": np.array([half, half, -half]), \"D\": np.array([-half, half, -half]),",
            "        \"A1\": np.array([-half, -half, half]), \"B1\": np.array([half, -half, half]),",
            "        \"C1\": np.array([half, half, half]), \"D1\": np.array([-half, half, half]),",
            "    }",
            "    order = [(\"A\", \"B\"), (\"B\", \"C\"), (\"C\", \"D\"), (\"D\", \"A\"), (\"A1\", \"B1\"), (\"B1\", \"C1\"), (\"C1\", \"D1\"), (\"D1\", \"A1\"), (\"A\", \"A1\"), (\"B\", \"B1\"), (\"C\", \"C1\"), (\"D\", \"D1\")]",
            "    line_cls = globals().get(\"Line3D\", Line)",
            "    dot_cls = globals().get(\"Dot3D\", Dot)",
            "    edges = VGroup(*[line_cls(points[a], points[b], color=main_color, stroke_width=3) for a, b in order])",
            "    dots = VGroup(*[dot_cls(point=points[name], radius=0.055, color=accent_color) for name in (\"A\", \"B\", \"C\", \"D\", \"A1\", \"B1\", \"C1\", \"D1\")])",
            "    labels = []",
            "    for name in (\"A\", \"B\", \"C\", \"D\", \"A_1\", \"B_1\", \"C_1\", \"D_1\"):",
            "        key = name.replace(\"_\", \"\")",
            "        label = MathTex(name, font_size=22, color=text_color)",
            "        direction = np.array(points[key], dtype=float)",
            "        norm = np.linalg.norm(direction)",
            "        if norm > 1e-9:",
            "            direction = direction / norm",
            "        label.move_to(points[key] + direction * 0.28)",
            "        labels.append(label)",
            "    return points, edges, dots, labels",
            "",
        ])
    if "get_cube_elements" in missing:
        lines.extend([
            "def get_cube_elements(side_length=2.0, main_color=BLUE, accent_color=YELLOW, text_color=WHITE, **_kwargs):",
            "    points, edges, dots, labels = create_cube_elements(main_color=main_color, accent_color=accent_color, text_color=text_color, side_length=side_length)",
            "    axes = ThreeDAxes(x_range=[-2, 2, 1], y_range=[-2, 2, 1], z_range=[-2, 2, 1], x_length=3.2, y_length=3.2, z_length=3.2)",
            "    cube = VGroup(edges, dots, *labels)",
            "    return axes, points, edges, dots, labels, cube",
            "",
        ])
    if "get_square_geometry" in missing:
        lines.extend([
            "def get_square_geometry(side_length=2.0, center=ORIGIN, **_kwargs):",
            "    side = float(side_length or 2.0)",
            "    c = _mathpi_point3(center)",
            "    half = side / 2.0",
            "    points = [c + LEFT * half + DOWN * half, c + RIGHT * half + DOWN * half, c + RIGHT * half + UP * half, c + LEFT * half + UP * half]",
            "    corners = dict(zip((\"A\", \"B\", \"C\", \"D\"), points))",
            "    return {\"center\": c, \"side\": side, \"side_length\": side, \"width\": side, \"height\": side, \"points\": points, \"vertices\": points, \"corners\": corners, **corners}",
            "",
        ])
    if "get_side_labels" in missing:
        lines.extend([
            "def get_side_labels(square=None, labels=(\"A\", \"B\", \"C\", \"D\"), font_size=24, color=WHITE, buff=0.18, **_kwargs):",
            "    if isinstance(square, dict):",
            "        corners = square.get(\"corners\", square)",
            "        points = [corners.get(k) for k in (\"A\", \"B\", \"C\", \"D\") if corners.get(k) is not None]",
            "        if len(points) < 4:",
            "            points = square.get(\"points\") or square.get(\"vertices\") or points",
            "    else:",
            "        points = square or []",
            "    if len(points) < 4:",
            "        points = [LEFT + DOWN, RIGHT + DOWN, RIGHT + UP, LEFT + UP]",
            "    dirs = [DL, DR, UR, UL]",
            "    group = VGroup()",
            "    for text, point, direction in zip(labels, points[:4], dirs):",
            "        label = MathTex(str(text), font_size=font_size, color=color)",
            "        label.move_to(_mathpi_point3(point) + direction * buff)",
            "        group.add(label)",
            "    return group",
            "",
        ])
    if "get_rhombus_points" in missing:
        lines.extend([
            "def get_rhombus_points(center=ORIGIN, width=4.2, height=2.4, **_kwargs):",
            "    c = _mathpi_point3(center)",
            "    try:",
            "        w = float(width or 4.2)",
            "    except Exception:",
            "        w = 4.2",
            "    try:",
            "        h = float(height or 2.4)",
            "    except Exception:",
            "        h = 2.4",
            "    A = c + LEFT * (w / 2.0)",
            "    B = c + UP * (h / 2.0)",
            "    C = c + RIGHT * (w / 2.0)",
            "    D = c + DOWN * (h / 2.0)",
            "    O = c",
            "    return {\"A\": A, \"B\": B, \"C\": C, \"D\": D, \"O\": O}",
            "",
        ])
    if "create_cube_edges" in missing:
        lines.extend([
            "def create_cube_edges(vertices, color=WHITE, stroke_width=2, **_kwargs):",
            "    order = [(\"A\", \"B\"), (\"B\", \"C\"), (\"C\", \"D\"), (\"D\", \"A\"), (\"A1\", \"B1\"), (\"B1\", \"C1\"), (\"C1\", \"D1\"), (\"D1\", \"A1\"), (\"A\", \"A1\"), (\"B\", \"B1\"), (\"C\", \"C1\"), (\"D\", \"D1\")]",
            "    if isinstance(vertices, dict):",
            "        lookup = vertices",
            "    else:",
            "        names = [\"A\", \"B\", \"C\", \"D\", \"A1\", \"B1\", \"C1\", \"D1\"]",
            "        lookup = dict(zip(names, list(vertices)))",
            "    group = VGroup()",
            "    line_cls = globals().get(\"Line3D\", Line)",
            "    for start, end in order:",
            "        if start in lookup and end in lookup:",
            "            group.add(line_cls(lookup[start], lookup[end], color=color, stroke_width=stroke_width))",
            "    return group",
            "",
        ])
    if "get_right_angle_mark" in missing:
        lines.extend([
            "def get_right_angle_mark(p1=None, vertex=None, p2=None, size=0.25, color=YELLOW, **_kwargs):",
            "    try:",
            "        return RightAngle(Line(vertex, p1), Line(vertex, p2), length=float(size), color=color)",
            "    except Exception:",
            "        return VGroup()",
            "",
        ])
    return lines


def _fix_global_config_default_refs_before_definition(code: str) -> Tuple[Optional[str], str]:
    """Function defaults are evaluated before GlobalConfig exists at module load time."""
    marker = re.search(r"(?m)^class\s+GlobalConfig\b", code)
    if not marker:
        return None, ""
    prefix = code[: marker.start()]
    if "GlobalConfig." not in prefix:
        return None, ""
    fixed_prefix, count = re.subn(
        r"(?P<head>[,(]\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*)GlobalConfig\.[A-Za-z_][A-Za-z0-9_]*",
        r"\g<head>WHITE",
        prefix,
    )
    if not count:
        return None, ""
    return fixed_prefix + code[marker.start():], "GlobalConfig默认参数前置引用修复"


def _square_partition_helper_lines(needs_point3: bool) -> list[str]:
    lines: list[str] = []
    if needs_point3:
        lines.extend([
            "def _mathpi_point3(value, fallback=ORIGIN):",
            "    try:",
            "        arr = np.array(value, dtype=float)",
            "        if arr.shape[0] == 2:",
            "            return np.array([arr[0], arr[1], 0.0], dtype=float)",
            "        return arr[:3] if arr.shape[0] >= 3 else fallback",
            "    except Exception:",
            "        return fallback",
            "",
        ])
    lines.extend([
        "class _MathPiLabelGroup(VGroup):",
        "    def __init__(self, mapping):",
        "        self._mapping = dict(mapping)",
        "        super().__init__(*self._mapping.values())",
        "    def __getitem__(self, key):",
        "        if isinstance(key, str):",
        "            return self._mapping[key]",
        "        return super().__getitem__(key)",
        "",
        "def get_square_geometry(side_length=2.0, center=ORIGIN, side=None, a_ratio=0.6, **_kwargs):",
        "    side_value = side if side is not None else side_length",
        "    side_value = float(side_value or 2.0)",
        "    c = _mathpi_point3(center)",
        "    ratio = float(a_ratio if a_ratio is not None else 0.6)",
        "    ratio = min(0.95, max(0.05, ratio))",
        "    a = side_value * ratio",
        "    b = side_value - a",
        "    left = c + LEFT * (side_value / 2.0)",
        "    right = c + RIGHT * (side_value / 2.0)",
        "    top = c + UP * (side_value / 2.0)",
        "    bottom = c + DOWN * (side_value / 2.0)",
        "    x_split = left + RIGHT * a",
        "    y_split = bottom + UP * b",
        "    corners = {",
        "        \"A\": left + DOWN * (side_value / 2.0),",
        "        \"B\": right + DOWN * (side_value / 2.0),",
        "        \"C\": right + UP * (side_value / 2.0),",
        "        \"D\": left + UP * (side_value / 2.0),",
        "    }",
        "    points = [corners[k] for k in (\"A\", \"B\", \"C\", \"D\")]",
        "    return {",
        "        \"center\": c, \"side\": side_value, \"side_length\": side_value,",
        "        \"width\": side_value, \"height\": side_value, \"a\": a, \"b\": b,",
        "        \"points\": points, \"vertices\": points, \"corners\": corners, **corners,",
        "        \"left\": left, \"right\": right, \"top\": top, \"bottom\": bottom,",
        "        \"x_split\": x_split, \"y_split\": y_split,",
        "        \"p_bottom\": x_split + DOWN * (side_value / 2.0),",
        "        \"p_top\": x_split + UP * (side_value / 2.0),",
        "        \"p_left\": left + UP * b,",
        "        \"p_right\": right + UP * b,",
        "    }",
        "",
        "def get_outer_square(geom, color=WHITE, stroke_width=3, **_kwargs):",
        "    side = float(geom.get(\"side\", geom.get(\"side_length\", 2.0))) if isinstance(geom, dict) else 2.0",
        "    center = _mathpi_point3(geom.get(\"center\", ORIGIN)) if isinstance(geom, dict) else ORIGIN",
        "    return Square(side_length=side, color=color, stroke_width=stroke_width).move_to(center)",
        "",
        "def get_side_labels(square=None, labels=(\"A\", \"B\", \"C\", \"D\"), font_size=24, color=WHITE, buff=0.18, **_kwargs):",
        "    if isinstance(square, dict) and {\"a\", \"b\", \"left\", \"right\", \"top\", \"bottom\"}.issubset(square):",
        "        c = _mathpi_point3(square.get(\"center\", ORIGIN))",
        "        side = float(square.get(\"side\", square.get(\"side_length\", 2.0)))",
        "        a = float(square.get(\"a\", side * 0.6))",
        "        b = float(square.get(\"b\", side - a))",
        "        mapping = {",
        "            \"top\": Text(\"a+b\", font_size=font_size, color=color).move_to(c + UP * (side / 2 + 0.32)),",
        "            \"right\": Text(\"a+b\", font_size=font_size, color=color).move_to(c + RIGHT * (side / 2 + 0.36)),",
        "            \"left_a\": Text(\"a\", font_size=font_size, color=color).move_to(c + LEFT * (side / 2 + 0.28) + UP * (b / 2)),",
        "            \"left_b\": Text(\"b\", font_size=font_size, color=color).move_to(c + LEFT * (side / 2 + 0.28) + DOWN * (a / 2)),",
        "            \"bottom_a\": Text(\"a\", font_size=font_size, color=color).move_to(c + LEFT * (b / 2) + DOWN * (side / 2 + 0.28)),",
        "            \"bottom_b\": Text(\"b\", font_size=font_size, color=color).move_to(c + RIGHT * (a / 2) + DOWN * (side / 2 + 0.28)),",
        "        }",
        "        return _MathPiLabelGroup(mapping)",
        "    if isinstance(square, dict):",
        "        corners = square.get(\"corners\", square)",
        "        points = [corners.get(k) for k in (\"A\", \"B\", \"C\", \"D\") if corners.get(k) is not None]",
        "        if len(points) < 4:",
        "            points = square.get(\"points\") or square.get(\"vertices\") or points",
        "    else:",
        "        points = square or []",
        "    if len(points) < 4:",
        "        points = [LEFT + DOWN, RIGHT + DOWN, RIGHT + UP, LEFT + UP]",
        "    dirs = [DL, DR, UR, UL]",
        "    mapping = {}",
        "    for text, point, direction in zip(labels, points[:4], dirs):",
        "        label = MathTex(str(text), font_size=font_size, color=color)",
        "        label.move_to(_mathpi_point3(point) + direction * buff)",
        "        mapping[str(text)] = label",
        "    return _MathPiLabelGroup(mapping)",
        "",
        "def get_square_regions(geom, colors=None, fill_opacity=0.45, **_kwargs):",
        "    colors = colors or {}",
        "    side = float(geom.get(\"side\", geom.get(\"side_length\", 2.0)))",
        "    c = _mathpi_point3(geom.get(\"center\", ORIGIN))",
        "    a = float(geom.get(\"a\", side * 0.6))",
        "    b = float(geom.get(\"b\", side - a))",
        "    main = colors.get(\"main\", BLUE)",
        "    secondary = colors.get(\"secondary\", GREEN)",
        "    emphasis = colors.get(\"emphasis\", colors.get(\"accent\", YELLOW))",
        "    accent = colors.get(\"accent\", ORANGE)",
        "    def _rect(width, height, center_point, color):",
        "        rect = Rectangle(width=width, height=height, stroke_width=0, fill_color=color, fill_opacity=fill_opacity)",
        "        return rect.move_to(center_point)",
        "    return {",
        "        \"tl\": _rect(a, a, c + LEFT * (b / 2) + UP * (b / 2), main),",
        "        \"tr\": _rect(b, a, c + RIGHT * (a / 2) + UP * (b / 2), secondary),",
        "        \"bl\": _rect(a, b, c + LEFT * (b / 2) + DOWN * (a / 2), emphasis),",
        "        \"br\": _rect(b, b, c + RIGHT * (a / 2) + DOWN * (a / 2), accent),",
        "    }",
        "",
    ])
    return lines


def _fix_square_partition_helper_contract(code: str) -> Tuple[Optional[str], str]:
    if not any(name in code for name in ("get_outer_square", "get_square_regions", "get_square_geometry", "get_side_labels")):
        return None, ""
    needs_contract = (
        "get_outer_square(" in code
        or "get_square_regions(" in code
        or "[\"top\"]" in code
        or "[\"bottom_a\"]" in code
    )
    if not needs_contract:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    target_names = {
        "get_square_geometry",
        "get_side_labels",
        "get_outer_square",
        "get_square_regions",
    }
    line_ranges: list[tuple[int, int]] = []
    existing = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in target_names:
            existing.add(node.name)
            if node.end_lineno is not None:
                line_ranges.append((node.lineno - 1, node.end_lineno))
        elif isinstance(node, ast.ClassDef) and node.name == "_MathPiLabelGroup":
            existing.add(node.name)
            if node.end_lineno is not None:
                line_ranges.append((node.lineno - 1, node.end_lineno))

    need_np = not re.search(r"(?m)^\s*import\s+numpy\s+as\s+np\b", code)
    needs_point3 = "def _mathpi_point3" not in code
    replacement = _square_partition_helper_lines(needs_point3)
    if need_np:
        replacement.insert(0, "import numpy as np")
        replacement.insert(1, "")

    lines = code.splitlines()
    if line_ranges:
        start = min(start for start, _end in line_ranges)
        end = max(end for _start, end in line_ranges)
        lines[start:end] = replacement
    else:
        insert_at = _module_alias_insert_index(code)
        if insert_at > 0 and lines[insert_at - 1].strip():
            replacement.insert(0, "")
        lines[insert_at:insert_at] = replacement

    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "square partition helper合同修复",
    )


def _inject_deterministic_generated_helper_shims(code: str) -> Tuple[Optional[str], str]:
    """Inject deterministic shims for recurring generated helper hallucinations."""
    if not any(name in code for name in _DETERMINISTIC_GENERATED_HELPERS):
        return None, ""
    defined, loaded = _collect_defined_and_loaded_names(code)
    missing = {
        name for name in _DETERMINISTIC_GENERATED_HELPERS
        if name in loaded and name not in defined
    }
    if not missing:
        return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    shim_lines: list[str] = []
    if missing & {
        "create_cube_elements",
        "get_arc_for_point",
        "get_square_geometry",
        "get_side_labels",
        "get_triangle_positions",
        "make_triangle_and_labels",
        "rotate_point",
    } and not re.search(
        r"(?m)^\s*import\s+numpy\s+as\s+np\b", code
    ):
        shim_lines.append("import numpy as np")
    shim_lines.extend(_deterministic_helper_shim_lines(missing))
    if not shim_lines:
        return None, ""
    if insert_at > 0 and lines[insert_at - 1].strip():
        shim_lines.insert(0, "")
    lines[insert_at:insert_at] = shim_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "deterministic helper shim注入: " + ",".join(sorted(missing)),
    )


def _inject_safe_brace_wrapper(code: str) -> Tuple[Optional[str], str]:
    """Make Manim Brace tolerant of generated ragged VGroups.

    Manim 0.19 may fail when Brace is built directly from a VGroup whose
    children have inhomogeneous point arrays. The safe path preserves normal
    Brace behavior and only falls back to a transparent bounding rectangle when
    the original constructor raises.
    """
    if "Brace(" not in code or "_MathPiOriginalBrace" in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""
    has_brace_call = any(
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "Brace"
        for node in ast.walk(tree)
    )
    if not has_brace_call:
        return None, ""

    shim_lines = [
        "",
        "_MathPiOriginalBrace = Brace",
        "",
        "def _mathpi_safe_brace_target(mobject):",
        "    try:",
        "        return SurroundingRectangle(mobject, buff=0.0)",
        "    except Exception:",
        "        try:",
        "            center = mobject.get_center()",
        "        except Exception:",
        "            center = ORIGIN",
        "        try:",
        "            width = float(getattr(mobject, \"width\", 4.0) or 4.0)",
        "        except Exception:",
        "            width = 4.0",
        "        try:",
        "            height = float(getattr(mobject, \"height\", 2.0) or 2.0)",
        "        except Exception:",
        "            height = 2.0",
        "        return Rectangle(width=max(width, 0.2), height=max(height, 0.2), stroke_opacity=0, fill_opacity=0).move_to(center)",
        "",
        "def Brace(mobject, direction=DOWN, *args, **kwargs):",
        "    try:",
        "        return _MathPiOriginalBrace(mobject, direction, *args, **kwargs)",
        "    except Exception:",
        "        return _MathPiOriginalBrace(_mathpi_safe_brace_target(mobject), direction, *args, **kwargs)",
        "",
    ]
    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    if insert_at > 0 and lines[insert_at - 1].strip() and shim_lines[0] != "":
        shim_lines.insert(0, "")
    lines[insert_at:insert_at] = shim_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "Brace安全兜底: ragged VGroup外接矩形",
    )


def _fix_self_make_triangle_and_labels_calls(code: str) -> Tuple[Optional[str], str]:
    """Route missing ``self.make_triangle_and_labels`` to the deterministic module shim."""
    if "self.make_triangle_and_labels(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    has_method = any(
        isinstance(item, ast.FunctionDef) and item.name == "make_triangle_and_labels"
        for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef)
        for item in node.body
    )
    if has_method:
        return None, ""

    current, changed = re.subn(
        r"\bself\.make_triangle_and_labels\s*\(",
        "make_triangle_and_labels(",
        code,
    )
    if changed <= 0 or current == code:
        return None, ""
    return current, f"make_triangle_and_labels调用修复: {changed}处"


def _count_simple_args(args: str) -> int:
    return len([part for part in (item.strip() for item in args.split(",")) if part])


def _fix_wide_horizontal_geometry_groups(code: str) -> Tuple[Optional[str], str]:
    """横向排列 3 个以上对象时补边界适配，避免竖屏中左右飞出。"""
    if "BaseConfigScene" not in code and "def fit_to_canvas" not in code:
        return None, ""

    lines = code.splitlines()
    output: list[str] = []
    changed = 0
    temp_index = 0

    for index, line in enumerate(lines):
        assign_match = _HORIZONTAL_VGROUP_ASSIGN_RE.match(line)
        if assign_match and _count_simple_args(assign_match.group("args")) >= 3:
            output.append(line)
            var_name = assign_match.group("var")
            next_line = lines[index + 1] if index + 1 < len(lines) else ""
            if f"self.fit_to_canvas({var_name}" not in next_line:
                output.append(
                    f"{assign_match.group('indent')}self.fit_to_canvas({var_name}, area=\"full\", move=True)"
                )
                changed += 1
            continue

        expr_match = _HORIZONTAL_VGROUP_EXPR_RE.match(line)
        if expr_match and _count_simple_args(expr_match.group("args")) >= 3:
            temp_index += 1
            temp_var = f"__mathpi_safe_group_{temp_index}"
            indent = expr_match.group("indent")
            output.append(
                f"{indent}{temp_var} = VGroup({expr_match.group('args')}).arrange("
                f"RIGHT, buff={expr_match.group('buff')}).move_to({expr_match.group('center')})"
                f"{expr_match.group('tail')}"
            )
            output.append(
                f"{indent}self.fit_to_canvas({temp_var}, area=\"full\", move=True)"
            )
            changed += 1
            continue

        output.append(line)

    if changed == 0:
        return None, ""
    return "\n".join(output) + ("\n" if code.endswith("\n") else ""), f"横向几何组越界保护: {changed}处"


def _inject_missing_fit_to_canvas_helper(code: str) -> Tuple[Optional[str], str]:
    """Inject a compact fit_to_canvas fallback when generated BaseConfigScene omits it."""
    if (
        "self.fit_to_canvas(" not in code
        or "def fit_to_canvas" in code
        or "class BaseConfigScene" not in code
    ):
        return None, ""

    insertion = _base_config_scene_class_insert_index(code)
    if not insertion:
        return None, ""
    insert_at, indent = insertion
    lines = code.splitlines()
    method = [
        f'{indent}def fit_to_canvas(self, mob, area="full", max_width=None, max_height=None, move=True, **_unused_fit_kwargs):',
        f"{indent}    if mob is None:",
        f"{indent}        return mob",
        f"{indent}    try:",
        f'{indent}        if hasattr(self, "layout_canvas"):',
        f"{indent}            box = self.layout_canvas(area)",
        f'{indent}            width = float(max_width or box.get("width") or config.frame_width)',
        f'{indent}            height = float(max_height or box.get("height") or config.frame_height)',
        f'{indent}            center = box.get("center", ORIGIN)',
        f"{indent}        else:",
        f"{indent}            width = float(max_width or (config.frame_width - 0.8))",
        f"{indent}            height = float(max_height or (config.frame_height - 0.8))",
        f"{indent}            center = ORIGIN",
        f'{indent}        if width > 0 and getattr(mob, "width", 0) > width:',
        f"{indent}            mob.scale_to_fit_width(width)",
        f'{indent}        if height > 0 and getattr(mob, "height", 0) > height:',
        f"{indent}            mob.scale_to_fit_height(height)",
        f"{indent}        if move:",
        f"{indent}            mob.move_to(center)",
        f'{indent}        if hasattr(self, "clamp_to_canvas"):',
        f"{indent}            return self.clamp_to_canvas(mob, area=area)",
        f"{indent}    except Exception:",
        f"{indent}        return mob",
        f"{indent}    return mob",
    ]
    lines[insert_at:insert_at] = method
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "fit_to_canvas兜底helper注入: 1处",
    )


_NP_POINT_ASSIGN_RE = re.compile(
    r"(?m)^\s*(?P<name>[A-Z][A-Za-z0-9_]*)\s*=\s*np\.array\(\s*\[(?P<coords>[^\]\n]+)\]\s*\)"
)


def _np_point_literals_for_repair(code: str) -> dict[str, str]:
    points: dict[str, str] = {}
    for match in _NP_POINT_ASSIGN_RE.finditer(code):
        name = match.group("name")
        if name in points:
            continue
        coords = match.group("coords").strip()
        if coords:
            points[name] = coords
    return points


_SEMANTIC_DATA_HELPER_NAME_RE = re.compile(
    r"(^|_)(data|dict|map|metadata|config|layout|bounds|vertices|anchors?|"
    r"pos|position|center|points?|coords?|coordinates?|intersections?|vectors?|"
    r"mobjects?|objects?|parts?)($|_)",
    re.IGNORECASE,
)

_COORDINATE_CONSUMER_CALLS = {
    "Arc",
    "Arrow",
    "Circle",
    "CubicBezier",
    "CurvedArrow",
    "Dot",
    "DoubleArrow",
    "Elbow",
    "Line",
    "ParametricFunction",
    "Polygon",
    "Polyline",
    "Rectangle",
    "RightAngle",
    "Sector",
    "Square",
    "Triangle",
    "Vector",
}


def _semantic_helper_call_name(node: ast.AST, candidates: set[str]) -> str | None:
    if not isinstance(node, ast.Call):
        return None
    func = node.func
    if (
        isinstance(func, ast.Attribute)
        and isinstance(func.value, ast.Name)
        and func.value.id == "self"
        and func.attr in candidates
    ):
        return func.attr
    return None


def _semantic_helper_consumed_as_coordinate(
    node: ast.AST,
    parents: dict[ast.AST, ast.AST],
) -> bool:
    current = node
    while current in parents:
        parent = parents[current]
        if isinstance(parent, ast.Call):
            if parent.func is current:
                current = parent
                continue
            if _call_name_for_repair(parent.func) in _COORDINATE_CONSUMER_CALLS:
                return True
        if isinstance(parent, (ast.Expr, ast.Assign, ast.AnnAssign, ast.Return)):
            return False
        current = parent
    return False


def _semantic_visual_helper_data_like_names(
    code: str,
    candidates: Iterable[str],
) -> set[str]:
    """Unknown semantic helpers used as data must not be replaced by icon Mobjects."""
    candidate_set = set(candidates)
    if not candidate_set:
        return set()

    data_like = {
        name for name in candidate_set if _SEMANTIC_DATA_HELPER_NAME_RE.search(name)
    }
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return data_like

    parents: dict[ast.AST, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[child] = parent

    assigned_helpers: dict[str, str] = {}
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        helper_name = _semantic_helper_call_name(node.value, candidate_set)
        if not helper_name:
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        for target in targets:
            if isinstance(target, (ast.Tuple, ast.List)):
                data_like.add(helper_name)
            elif isinstance(target, ast.Name):
                assigned_helpers[target.id] = helper_name

    for node in ast.walk(tree):
        helper_name = _semantic_helper_call_name(node, candidate_set)
        if helper_name and _semantic_helper_consumed_as_coordinate(node, parents):
            data_like.add(helper_name)

        if isinstance(node, ast.Subscript):
            value = node.value
            if isinstance(value, ast.Name) and value.id in assigned_helpers:
                data_like.add(assigned_helpers[value.id])
            elif isinstance(value, ast.Call):
                helper_name = _semantic_helper_call_name(value, candidate_set)
                if helper_name:
                    data_like.add(helper_name)
        elif isinstance(node, ast.BinOp):
            for item in (node.left, node.right):
                if isinstance(item, ast.Name) and item.id in assigned_helpers:
                    data_like.add(assigned_helpers[item.id])
                elif isinstance(item, ast.Call):
                    helper_name = _semantic_helper_call_name(item, candidate_set)
                    if helper_name:
                        data_like.add(helper_name)
        elif isinstance(node, ast.Call) and _call_name_for_repair(node.func) in _COORDINATE_CONSUMER_CALLS:
            for arg in node.args:
                if isinstance(arg, ast.Name) and arg.id in assigned_helpers:
                    data_like.add(assigned_helpers[arg.id])
                elif isinstance(arg, ast.Call):
                    helper_name = _semantic_helper_call_name(arg, candidate_set)
                    if helper_name:
                        data_like.add(helper_name)
        elif (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr in {"get", "items", "keys", "values"}
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id in assigned_helpers
        ):
            data_like.add(assigned_helpers[node.func.value.id])
    return data_like


def _inject_missing_base_config_runtime_helpers(code: str) -> Tuple[Optional[str], str]:
    """Patch incomplete generated BaseConfigScene headers with tiny safe helpers."""
    if "class BaseConfigScene" not in code or "self." not in code:
        return None, ""

    needs_zones_alias = (
        "self.zones" in code
        and "def zones" not in code
        and "self.zones =" not in code
    )
    needs_layout_zones = (
        ("self.layout_zones" in code or needs_zones_alias)
        and "def layout_zones" not in code
        and "self.layout_zones =" not in code
    )
    needs_get_layout_area = (
        "self.get_layout_area(" in code
        and "def get_layout_area" not in code
    )
    needs_get_zone_center = (
        "self.get_zone_center(" in code
        and "def get_zone_center" not in code
    )
    needs_layout_canvas = (
        (
            "self.layout_canvas(" in code
            or needs_layout_zones
            or needs_get_layout_area
            or needs_get_zone_center
        )
        and "def layout_canvas" not in code
    )
    needs_safe_text_box = "self.safe_text_box(" in code and "def safe_text_box" not in code
    needs_clamp_to_canvas = (
        "self.clamp_to_canvas(" in code and "def clamp_to_canvas" not in code
    )
    needs_place_non_overlapping = (
        "self.place_non_overlapping(" in code
        and "def place_non_overlapping" not in code
    )
    needs_fit_to_canvas = (
        "self.fit_to_canvas(" in code and "def fit_to_canvas" not in code
    )
    needs_fit_to_width = "self.fit_to_width(" in code and "def fit_to_width" not in code
    needs_create_3d_label = (
        "self.create_3d_label(" in code and "def create_3d_label" not in code
    )
    needs_to_3d = "self.to_3d(" in code and "def to_3d" not in code
    needs_safe_formula = "self.safe_formula(" in code and "def safe_formula" not in code
    needs_setup_scene = "self.setup_scene(" in code and "def setup_scene" not in code
    needs_inline_math_text = (
        "self.inline_math_text(" in code and "def inline_math_text" not in code
    )
    needs_cjk_math_tex = (
        "self.cjk_math_tex(" in code and "def cjk_math_tex" not in code
    )
    needs_get_pt = "self.get_pt(" in code and "def get_pt" not in code
    needs_rotate_about_axis = (
        "self.rotate_about_axis(" in code and "def rotate_about_axis" not in code
    )
    needs_get_figure_parts = (
        "self.get_figure_parts(" in code and "def get_figure_parts" not in code
    )
    needs_get_base_geometry = (
        "self.get_base_geometry(" in code and "def get_base_geometry" not in code
    )
    needs_get_geometry_figure = (
        "self.get_geometry_figure(" in code
        and "def get_geometry_figure" not in code
    )
    needs_get_geometry_base = (
        "self.get_geometry_base(" in code
        and "def get_geometry_base" not in code
    )
    needs_get_square_model = (
        "self.get_square_model(" in code
        and "def get_square_model" not in code
    )
    needs_get_figure = "self.get_figure(" in code and "def get_figure" not in code
    needs_get_figures = "self.get_figures(" in code and "def get_figures" not in code
    needs_get_title = "self.get_title(" in code and "def get_title" not in code
    needs_get_formula = (
        "self.get_formula(" in code and "def get_formula" not in code
    )
    needs_get_paraboloid = (
        "self.get_paraboloid(" in code and "def get_paraboloid" not in code
    )
    needs_get_cube_elements = (
        "self.get_cube_elements(" in code and "def get_cube_elements" not in code
    )
    needs_create_triangle_figure = (
        "self.create_triangle_figure(" in code
        and "def create_triangle_figure" not in code
    )
    needs_create_triangle_abc = (
        "self.create_triangle_abc(" in code
        and "def create_triangle_abc" not in code
    )
    needs_create_figure = "self.create_figure(" in code and "def create_figure" not in code
    needs_get_triangle_centers = (
        "self.get_triangle_centers(" in code
        and "def get_triangle_centers" not in code
    )
    needs_get_rhombus_geometry = (
        "self.get_rhombus_geometry(" in code
        and "def get_rhombus_geometry" not in code
    )
    needs_make_text = "self.make_text(" in code and "def make_text" not in code
    needs_make_title = "self.make_title(" in code and "def make_title" not in code
    needs_make_mixed_line = (
        "self.make_mixed_line(" in code
        and "def make_mixed_line" not in code
    )
    needs_create_text = "self.create_text(" in code and "def create_text" not in code
    needs_make_formula = (
        "self.make_formula(" in code and "def make_formula" not in code
    )
    needs_play_voiceover = (
        "self.play_voiceover(" in code
        and "def play_voiceover" not in code
    )
    needs_make_point_with_label = (
        "self.make_point_with_label(" in code
        and "def make_point_with_label" not in code
    )
    needs_get_right_angle_mark = (
        "self.get_right_angle_mark(" in code
        and "def get_right_angle_mark" not in code
    )
    needs_get_tick_mark = (
        "self.get_tick_mark(" in code
        and "def get_tick_mark" not in code
    )
    needs_get_angle_arc = (
        "self.get_angle_arc(" in code
        and "def get_angle_arc" not in code
    )
    needs_create_check_mark = (
        "self.create_check_mark(" in code
        and "def create_check_mark" not in code
    )
    needs_create_cargo_box = (
        "self.create_cargo_box(" in code
        and "def create_cargo_box" not in code
    )
    needs_create_thermometer = (
        "self.create_thermometer(" in code
        and "def create_thermometer" not in code
    )
    needs_create_frozen_river = (
        "self.create_frozen_river(" in code
        and "def create_frozen_river" not in code
    )
    needs_create_balance_scale = (
        "self.create_balance_scale(" in code
        and "def create_balance_scale" not in code
    )
    needs_create_left_column = (
        "self.create_left_column(" in code
        and "def create_left_column" not in code
    )
    needs_fg_color_alias = "self.FG_COLOR" in code and not re.search(
        r"(?m)^\s*FG_COLOR\s*=", code
    )
    needs_line_color_alias = "self.LINE_COLOR" in code and not re.search(
        r"(?m)^\s*LINE_COLOR\s*=", code
    )
    handled_create_helpers = {
        "create_3d_label",
        "create_triangle_figure",
        "create_triangle_abc",
        "create_figure",
        "create_text",
        "create_formula",
        "create_options",
        "create_subcaption",
        "create_title",
        "create_check_mark",
        "create_cargo_box",
        "create_thermometer",
        "create_frozen_river",
        "create_balance_scale",
        "create_left_column",
    }
    semantic_create_helpers = sorted({
        match.group("name")
        for match in re.finditer(r"\bself\.(?P<name>create_[A-Za-z_][A-Za-z0-9_]*)\s*\(", code)
        if match.group("name") not in handled_create_helpers
        and f"def {match.group('name')}" not in code
    })
    needs_create_grid = "create_grid" in semantic_create_helpers
    needs_create_grid_visual = "create_grid_visual" in semantic_create_helpers
    semantic_create_helpers = [
        helper for helper in semantic_create_helpers
        if helper not in {"create_grid", "create_grid_visual"}
    ]
    handled_get_helpers = {
        "get_layout_area",
        "get_zone_center",
        "get_pt",
        "get_figure_parts",
        "get_base_geometry",
        "get_geometry_figure",
        "get_geometry_base",
        "get_square_model",
        "get_figure",
        "get_figures",
        "get_title",
        "get_formula",
        "get_paraboloid",
        "get_cube_elements",
        "get_triangle_centers",
        "get_rhombus_geometry",
        "get_right_angle_mark",
        "get_tick_mark",
        "get_angle_arc",
        "get_folded_A",
        "get_check",
        "get_check_mark",
        "get_checkmark",
        "get_cross",
        "get_cross_mark",
        "get_icon",
    }
    semantic_get_helpers = sorted({
        match.group("name")
        for match in re.finditer(r"\bself\.(?P<name>get_[A-Za-z_][A-Za-z0-9_]*)\s*\(", code)
        if match.group("name") not in handled_get_helpers
        and f"def {match.group('name')}" not in code
    })
    needs_get_rope = "get_rope" in semantic_get_helpers
    needs_get_single_line_sentence = "get_single_line_sentence" in semantic_get_helpers
    semantic_get_helpers = [
        helper for helper in semantic_get_helpers
        if helper not in {"get_rope", "get_single_line_sentence"}
    ]
    semantic_data_helpers = _semantic_visual_helper_data_like_names(
        code,
        [*semantic_create_helpers, *semantic_get_helpers],
    )
    semantic_create_helpers = [
        helper for helper in semantic_create_helpers
        if helper not in semantic_data_helpers
    ]
    semantic_get_helpers = [
        helper for helper in semantic_get_helpers
        if helper not in semantic_data_helpers
    ]
    point_literals = _np_point_literals_for_repair(code)
    needs_get_folded_a = (
        "self.get_folded_A(" in code
        and "def get_folded_A" not in code
        and {"A", "B", "E"}.issubset(point_literals)
    )
    if not (
        needs_layout_canvas
        or needs_layout_zones
        or needs_zones_alias
        or needs_get_layout_area
        or needs_get_zone_center
        or needs_safe_text_box
        or needs_clamp_to_canvas
        or needs_place_non_overlapping
        or needs_fit_to_canvas
        or needs_fit_to_width
        or needs_create_3d_label
        or needs_to_3d
        or needs_safe_formula
        or needs_setup_scene
        or needs_inline_math_text
        or needs_cjk_math_tex
        or needs_get_pt
        or needs_rotate_about_axis
        or needs_get_figure_parts
        or needs_get_base_geometry
        or needs_get_geometry_figure
        or needs_get_geometry_base
        or needs_get_square_model
        or needs_get_figure
        or needs_get_figures
        or needs_get_title
        or needs_get_formula
        or needs_get_paraboloid
        or needs_get_cube_elements
        or needs_create_triangle_figure
        or needs_create_triangle_abc
        or needs_create_figure
        or needs_get_triangle_centers
        or needs_get_rhombus_geometry
        or needs_make_text
        or needs_make_title
        or needs_make_mixed_line
        or needs_create_text
        or needs_make_formula
        or needs_play_voiceover
        or needs_make_point_with_label
        or needs_get_right_angle_mark
        or needs_get_tick_mark
        or needs_get_angle_arc
        or needs_create_check_mark
        or needs_create_cargo_box
        or needs_create_thermometer
        or needs_create_frozen_river
        or needs_create_balance_scale
        or needs_create_left_column
        or needs_fg_color_alias
        or needs_line_color_alias
        or needs_create_grid_visual
        or needs_create_grid
        or needs_get_rope
        or needs_get_single_line_sentence
        or semantic_create_helpers
        or semantic_get_helpers
        or needs_get_folded_a
    ):
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines: list[str] = []
    if needs_fg_color_alias:
        helper_lines.extend([
            "",
            f'{indent}FG_COLOR = locals().get("PRIMARY_TEXT", globals().get("BLACK", "#222222"))',
        ])
    if needs_line_color_alias:
        helper_lines.extend([
            "",
            f'{indent}LINE_COLOR = locals().get("MAIN_COLOR", globals().get("BLUE", "#3498DB"))',
        ])
    if needs_layout_canvas:
        helper_lines.extend([
            "",
            f'{indent}def layout_canvas(self, *args, area="full", **_kwargs):',
            f"{body}if args and isinstance(args[0], str):",
            f"{body}    area = args[0]",
            f"{body}key = str(area or \"full\").strip().lower().replace(\"-\", \"_\")",
            f"{body}fw = float(getattr(config, \"frame_width\", 14.222))",
            f"{body}fh = float(getattr(config, \"frame_height\", 8.0))",
            f"{body}margin = 0.45",
            f"{body}full = {{\"center\": ORIGIN, \"width\": fw - 2 * margin, \"height\": fh - 2 * margin}}",
            f"{body}top = {{\"center\": UP * (fh * 0.34), \"width\": full[\"width\"], \"height\": fh * 0.22}}",
            f"{body}bottom = {{\"center\": DOWN * (fh * 0.34), \"width\": full[\"width\"], \"height\": fh * 0.24}}",
            f"{body}left = {{\"center\": LEFT * (fw * 0.24), \"width\": fw * 0.46, \"height\": full[\"height\"]}}",
            f"{body}right = {{\"center\": RIGHT * (fw * 0.24), \"width\": fw * 0.46, \"height\": full[\"height\"]}}",
            f"{body}mapping = {{",
            f"{body}    \"full\": full,",
            f"{body}    \"top\": top,",
            f"{body}    \"bottom\": bottom,",
            f"{body}    \"left\": left,",
            f"{body}    \"right\": right,",
            f"{body}    \"content\": full,",
            f"{body}    \"content_zone\": full,",
            f"{body}    \"content_center\": full,",
            f"{body}    \"diagram\": full,",
            f"{body}    \"diagram_zone\": full,",
            f"{body}    \"main\": full,",
            f"{body}    \"main_zone\": full,",
            f"{body}    \"full_canvas\": full,",
            f"{body}    \"title\": top,",
            f"{body}    \"title_zone\": top,",
            f"{body}    \"header\": top,",
            f"{body}    \"header_zone\": top,",
            f"{body}    \"top_zone\": top,",
            f"{body}    \"formula\": bottom,",
            f"{body}    \"formula_zone\": bottom,",
            f"{body}    \"footer\": bottom,",
            f"{body}    \"footer_zone\": bottom,",
            f"{body}    \"caption\": bottom,",
            f"{body}    \"caption_zone\": bottom,",
            f"{body}    \"bottom_zone\": bottom,",
            f"{body}    \"left_zone\": left,",
            f"{body}    \"left_content\": left,",
            f"{body}    \"left_col\": left,",
            f"{body}    \"left_panel\": left,",
            f"{body}    \"left_pane\": left,",
            f"{body}    \"left_side\": left,",
            f"{body}    \"left_canvas\": left,",
            f"{body}    \"left_area\": left,",
            f"{body}    \"content_left\": left,",
            f"{body}    \"diagram_left\": left,",
            f"{body}    \"visual_left\": left,",
            f"{body}    \"formula_left\": left,",
            f"{body}    \"right_zone\": right,",
            f"{body}    \"right_content\": right,",
            f"{body}    \"right_col\": right,",
            f"{body}    \"right_panel\": right,",
            f"{body}    \"right_pane\": right,",
            f"{body}    \"right_side\": right,",
            f"{body}    \"right_canvas\": right,",
            f"{body}    \"right_area\": right,",
            f"{body}    \"content_right\": right,",
            f"{body}    \"diagram_right\": right,",
            f"{body}    \"visual_right\": right,",
            f"{body}    \"formula_right\": right,",
            f"{body}}}",
            f"{body}return mapping.get(key, full)",
        ])
    if needs_get_layout_area:
        helper_lines.extend([
            "",
            f'{indent}def get_layout_area(self, area="full"):',
            f"{body}return self.layout_canvas(area)[\"center\"]",
        ])
    if needs_get_zone_center:
        helper_lines.extend([
            "",
            f'{indent}def get_zone_center(self, area="full"):',
            f"{body}return self.layout_canvas(area)[\"center\"]",
        ])
    if needs_layout_zones:
        helper_lines.extend([
            "",
            f"{indent}@property",
            f"{indent}def layout_zones(self):",
            f"{body}if not hasattr(self, \"full_canvas\") and hasattr(self, \"setup_layout\"):",
            f"{body}    try:",
            f"{body}        self.setup_layout()",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}def _zone(area):",
            f"{body}    try:",
            f"{body}        box = dict(self.layout_canvas(area))",
            f"{body}    except Exception:",
            f"{body}        box = {{\"center\": ORIGIN, \"width\": float(config.frame_width) - 0.9, \"height\": float(config.frame_height) - 0.9}}",
            f"{body}    center = np.array(box.get(\"center\", ORIGIN), dtype=float)",
            f"{body}    width = float(box.get(\"width\", max(0.1, float(box.get(\"right\", box.get(\"x_max\", center[0]))) - float(box.get(\"left\", box.get(\"x_min\", center[0]))))))",
            f"{body}    height = float(box.get(\"height\", max(0.1, float(box.get(\"top\", box.get(\"y_max\", center[1]))) - float(box.get(\"bottom\", box.get(\"y_min\", center[1]))))))",
            f"{body}    left = float(box.get(\"left\", box.get(\"x_min\", center[0] - width / 2)))",
            f"{body}    right = float(box.get(\"right\", box.get(\"x_max\", center[0] + width / 2)))",
            f"{body}    bottom = float(box.get(\"bottom\", box.get(\"y_min\", center[1] - height / 2)))",
            f"{body}    top = float(box.get(\"top\", box.get(\"y_max\", center[1] + height / 2)))",
            f"{body}    box.update({{\"center\": center, \"width\": width, \"height\": height, \"left\": left, \"right\": right, \"bottom\": bottom, \"top\": top, \"x_min\": left, \"x_max\": right, \"y_min\": bottom, \"y_max\": top}})",
            f"{body}    return box",
            f"{body}mapping = {{",
            f"{body}    \"full_canvas\": _zone(\"full\"),",
            f"{body}    \"content\": _zone(\"full\"),",
            f"{body}    \"content_zone\": _zone(\"full\"),",
            f"{body}    \"content_center\": _zone(\"full\"),",
            f"{body}    \"diagram\": _zone(\"full\"),",
            f"{body}    \"diagram_zone\": _zone(\"full\"),",
            f"{body}    \"main\": _zone(\"full\"),",
            f"{body}    \"main_zone\": _zone(\"full\"),",
            f"{body}    \"title\": _zone(\"top\"),",
            f"{body}    \"title_zone\": _zone(\"top\"),",
            f"{body}    \"header\": _zone(\"top\"),",
            f"{body}    \"header_zone\": _zone(\"top\"),",
            f"{body}    \"formula\": _zone(\"bottom\"),",
            f"{body}    \"formula_zone\": _zone(\"bottom\"),",
            f"{body}    \"footer\": _zone(\"bottom\"),",
            f"{body}    \"footer_zone\": _zone(\"bottom\"),",
            f"{body}    \"caption\": _zone(\"bottom\"),",
            f"{body}    \"caption_zone\": _zone(\"bottom\"),",
            f"{body}    \"left\": _zone(\"left\"),",
            f"{body}    \"left_zone\": _zone(\"left\"),",
            f"{body}    \"left_content\": _zone(\"left\"),",
            f"{body}    \"left_col\": _zone(\"left\"),",
            f"{body}    \"left_panel\": _zone(\"left\"),",
            f"{body}    \"left_pane\": _zone(\"left\"),",
            f"{body}    \"left_side\": _zone(\"left\"),",
            f"{body}    \"left_canvas\": _zone(\"left\"),",
            f"{body}    \"left_area\": _zone(\"left\"),",
            f"{body}    \"content_left\": _zone(\"left\"),",
            f"{body}    \"diagram_left\": _zone(\"left\"),",
            f"{body}    \"visual_left\": _zone(\"left\"),",
            f"{body}    \"formula_left\": _zone(\"left\"),",
            f"{body}    \"right\": _zone(\"right\"),",
            f"{body}    \"right_zone\": _zone(\"right\"),",
            f"{body}    \"right_content\": _zone(\"right\"),",
            f"{body}    \"right_col\": _zone(\"right\"),",
            f"{body}    \"right_panel\": _zone(\"right\"),",
            f"{body}    \"right_pane\": _zone(\"right\"),",
            f"{body}    \"right_side\": _zone(\"right\"),",
            f"{body}    \"right_canvas\": _zone(\"right\"),",
            f"{body}    \"right_area\": _zone(\"right\"),",
            f"{body}    \"content_right\": _zone(\"right\"),",
            f"{body}    \"diagram_right\": _zone(\"right\"),",
            f"{body}    \"visual_right\": _zone(\"right\"),",
            f"{body}    \"formula_right\": _zone(\"right\"),",
            f"{body}    \"top\": _zone(\"top\"),",
            f"{body}    \"top_zone\": _zone(\"top\"),",
            f"{body}    \"bottom\": _zone(\"bottom\"),",
            f"{body}    \"bottom_zone\": _zone(\"bottom\"),",
            f"{body}}}",
            f"{body}return mapping",
        ])
    if needs_zones_alias:
        helper_lines.extend([
            "",
            f"{indent}@property",
            f"{indent}def zones(self):",
            f"{body}try:",
            f"{body}    return self.layout_zones",
            f"{body}except Exception:",
            f"{body}    return {{\"full\": {{\"center\": ORIGIN, \"width\": float(config.frame_width) - 0.9, \"height\": float(config.frame_height) - 0.9}}, \"left_col\": {{\"center\": LEFT * (float(config.frame_width) * 0.24), \"width\": float(config.frame_width) * 0.44, \"height\": float(config.frame_height) - 0.9}}, \"right_col\": {{\"center\": RIGHT * (float(config.frame_width) * 0.24), \"width\": float(config.frame_width) * 0.44, \"height\": float(config.frame_height) - 0.9}}}}",
        ])
    if needs_safe_text_box:
        helper_lines.extend([
            "",
            (
                f'{indent}def safe_text_box(self, text, area="full", font_size=32, '
                "color=None, max_width=None, max_height=None, **_kwargs):"
            ),
            f"{body}text_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"MAIN_WHITE\", WHITE))",
            f"{body}try:",
            f"{body}    size = int(font_size)",
            f"{body}except Exception:",
            f"{body}    size = 32",
            f"{body}mob = Text(str(text), font_size=size, color=text_color, line_spacing=0.85)",
            f"{body}if hasattr(self, \"layout_canvas\"):",
            f"{body}    box = self.layout_canvas(area)",
            f"{body}else:",
            f"{body}    box = {{\"center\": ORIGIN, \"width\": float(config.frame_width) - 0.8, \"height\": float(config.frame_height) - 0.8}}",
            f"{body}width = float(max_width or box.get(\"width\") or 0)",
            f"{body}height = float(max_height or box.get(\"height\") or 0)",
            f"{body}if width > 0 and getattr(mob, \"width\", 0) > width:",
            f"{body}    mob.scale_to_fit_width(width)",
            f"{body}if height > 0 and getattr(mob, \"height\", 0) > height:",
            f"{body}    mob.scale_to_fit_height(height)",
            f"{body}if area not in (None, \"none\", \"raw\"):",
            f"{body}    mob.move_to(box.get(\"center\", ORIGIN))",
            f"{body}return mob",
        ])
    if needs_clamp_to_canvas:
        helper_lines.extend([
            "",
            f'{indent}def clamp_to_canvas(self, mob, area="full", max_width=None, max_height=None, move=True, buff=0.2, **_kwargs):',
            f"{body}if mob is None:",
            f"{body}    return mob",
            f"{body}try:",
            f"{body}    if hasattr(self, \"layout_canvas\"):",
            f"{body}        box = self.layout_canvas(area)",
            f"{body}        center = box.get(\"center\", ORIGIN)",
            f"{body}        width = float(max_width or box.get(\"width\") or getattr(config, \"frame_width\", 14.222)) - float(buff or 0.0)",
            f"{body}        height = float(max_height or box.get(\"height\") or getattr(config, \"frame_height\", 8.0)) - float(buff or 0.0)",
            f"{body}    else:",
            f"{body}        center = ORIGIN",
            f"{body}        width = float(max_width or getattr(config, \"frame_width\", 14.222)) - float(buff or 0.0)",
            f"{body}        height = float(max_height or getattr(config, \"frame_height\", 8.0)) - float(buff or 0.0)",
            f"{body}    if width > 0 and getattr(mob, \"width\", 0) > width:",
            f"{body}        mob.scale_to_fit_width(width)",
            f"{body}    if height > 0 and getattr(mob, \"height\", 0) > height:",
            f"{body}        mob.scale_to_fit_height(height)",
            f"{body}    if move:",
            f"{body}        mob.move_to(center)",
            f"{body}except Exception:",
            f"{body}    return mob",
            f"{body}return mob",
        ])
    if needs_place_non_overlapping:
        helper_lines.extend([
            "",
            f'{indent}def place_non_overlapping(self, mob, anchor=ORIGIN, others=None, area="full", buff=0.25, **_kwargs):',
            f"{body}if mob is None:",
            f"{body}    return mob",
            f"{body}others = list(others or [])",
            f"{body}try:",
            f"{body}    if hasattr(self, \"layout_canvas\"):",
            f"{body}        box = self.layout_canvas(area)",
            f"{body}        width_limit = float(box.get(\"width\", getattr(config, \"frame_width\", 14.222)))",
            f"{body}        height_limit = float(box.get(\"height\", getattr(config, \"frame_height\", 8.0)))",
            f"{body}    else:",
            f"{body}        width_limit = float(getattr(config, \"frame_width\", 14.222)) - 0.8",
            f"{body}        height_limit = float(getattr(config, \"frame_height\", 8.0)) - 0.8",
            f"{body}    if width_limit > 0 and getattr(mob, \"width\", 0) > width_limit:",
            f"{body}        mob.scale_to_fit_width(max(0.1, width_limit - float(buff or 0.0)))",
            f"{body}    if height_limit > 0 and getattr(mob, \"height\", 0) > height_limit:",
            f"{body}        mob.scale_to_fit_height(max(0.1, height_limit - float(buff or 0.0)))",
            f"{body}    candidates = [anchor, anchor + UP * 0.45, anchor + DOWN * 0.45, anchor + RIGHT * 0.6, anchor + LEFT * 0.6, anchor + UP * 0.85, anchor + DOWN * 0.85]",
            f"{body}    best = anchor",
            f"{body}    best_score = None",
            f"{body}    for candidate in candidates:",
            f"{body}        mob.move_to(candidate)",
            f"{body}        score = 0.0",
            f"{body}        for other in others:",
            f"{body}            try:",
            f"{body}                x_overlap = max(0.0, min(mob.get_right()[0], other.get_right()[0]) - max(mob.get_left()[0], other.get_left()[0]))",
            f"{body}                y_overlap = max(0.0, min(mob.get_top()[1], other.get_top()[1]) - max(mob.get_bottom()[1], other.get_bottom()[1]))",
            f"{body}                score += x_overlap * y_overlap",
            f"{body}            except Exception:",
            f"{body}                continue",
            f"{body}        if best_score is None or score < best_score:",
            f"{body}            best = candidate",
            f"{body}            best_score = score",
            f"{body}    mob.move_to(best)",
            f"{body}except Exception:",
            f"{body}    try:",
            f"{body}        mob.move_to(anchor)",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}return mob",
        ])
    if needs_fit_to_canvas:
        helper_lines.extend([
            "",
            f'{indent}def fit_to_canvas(self, mob, area="full", max_width=None, max_height=None, move=True, buff=0.0, **_unused_fit_kwargs):',
            f"{body}if mob is None:",
            f"{body}    return mob",
            f"{body}try:",
            f"{body}    if hasattr(self, \"layout_canvas\"):",
            f"{body}        box = self.layout_canvas(area)",
            f"{body}        center = box.get(\"center\", ORIGIN)",
            f"{body}        width = float(max_width or box.get(\"width\") or getattr(config, \"frame_width\", 14.222)) - float(buff or 0.0)",
            f"{body}        height = float(max_height or box.get(\"height\") or getattr(config, \"frame_height\", 8.0)) - float(buff or 0.0)",
            f"{body}    else:",
            f"{body}        center = ORIGIN",
            f"{body}        width = float(max_width or getattr(config, \"frame_width\", 14.222)) - float(buff or 0.0)",
            f"{body}        height = float(max_height or getattr(config, \"frame_height\", 8.0)) - float(buff or 0.0)",
            f"{body}    if width > 0 and getattr(mob, \"width\", 0) > width:",
            f"{body}        mob.scale_to_fit_width(max(0.1, width))",
            f"{body}    if height > 0 and getattr(mob, \"height\", 0) > height:",
            f"{body}        mob.scale_to_fit_height(max(0.1, height))",
            f"{body}    if move:",
            f"{body}        mob.move_to(center)",
            f"{body}except Exception:",
            f"{body}    return mob",
            f"{body}return mob",
        ])
    if needs_fit_to_width:
        helper_lines.extend([
            "",
            f'{indent}def fit_to_width(self, mob, width=None, max_width=None, area="full", buff=0.6, **_kwargs):',
            f"{body}if mob is None:",
            f"{body}    return mob",
            f"{body}limit = width or max_width",
            f"{body}if limit is None and hasattr(self, \"layout_canvas\"):",
            f"{body}    limit = self.layout_canvas(area).get(\"width\")",
            f"{body}if limit is None:",
            f"{body}    limit = float(getattr(config, \"frame_width\", 14.222)) - 2 * buff",
            f"{body}try:",
            f"{body}    limit = float(limit)",
            f"{body}    if limit > 0 and getattr(mob, \"width\", 0) > limit:",
            f"{body}        mob.scale_to_fit_width(limit)",
            f"{body}except Exception:",
            f"{body}    return mob",
            f"{body}return mob",
        ])
    if needs_create_3d_label:
        helper_lines.extend([
            "",
            f'{indent}def create_3d_label(self, text, point, direction=UP, font_size=20, color=None, buff=0.18, **_kwargs):',
            f"{body}raw = str(text)",
            f"{body}label_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"MAIN_WHITE\", WHITE))",
            f"{body}if any(\"\\u4e00\" <= ch <= \"\\u9fff\" for ch in raw):",
            f"{body}    label = Text(raw, font_size=font_size, color=label_color)",
            f"{body}else:",
            f"{body}    label = MathTex(raw, font_size=font_size, color=label_color)",
            f"{body}try:",
            f"{body}    label.move_to(np.array(point, dtype=float) + direction * buff)",
            f"{body}except Exception:",
            f"{body}    label.move_to(point)",
            f"{body}return label",
        ])
    if needs_to_3d:
        helper_lines.extend([
            "",
            f'{indent}def to_3d(self, point, z=0.0, scale=1.0, offset=None, **_kwargs):',
            f"{body}arr = np.array(point, dtype=float)",
            f"{body}if arr.shape[0] == 2:",
            f"{body}    arr = np.array([arr[0], arr[1], z], dtype=float)",
            f"{body}elif arr.shape[0] > 3:",
            f"{body}    arr = arr[:3]",
            f"{body}if offset is not None:",
            f"{body}    arr = arr + np.array(offset, dtype=float)",
            f"{body}return arr * float(scale)",
        ])
    if needs_safe_formula:
        helper_lines.extend([
            "",
            f'{indent}def safe_formula(self, tex, area="full", font_size=32, color=None, max_width=None, max_height=None, move=False, **kwargs):',
            f"{body}formula_color = color or getattr(self, \"FORMULA_COLOR\", getattr(self, \"PRIMARY_TEXT\", WHITE))",
            f"{body}mob = MathTex(str(tex), font_size=font_size, color=formula_color, **kwargs)",
            f"{body}if hasattr(self, \"fit_to_width\"):",
            f"{body}    self.fit_to_width(mob, max_width=max_width, area=area)",
            f"{body}elif max_width and getattr(mob, \"width\", 0) > max_width:",
            f"{body}    mob.scale_to_fit_width(float(max_width))",
            f"{body}if max_height and getattr(mob, \"height\", 0) > max_height:",
            f"{body}    mob.scale_to_fit_height(float(max_height))",
            f"{body}if move and hasattr(self, \"layout_canvas\"):",
            f"{body}    mob.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}return mob",
        ])
    if needs_setup_scene:
        helper_lines.extend([
            "",
            f"{indent}def setup_scene(self, *args, **kwargs):",
            f'{body}if hasattr(self, "setup_layout"):',
            f"{body}    try:",
            f"{body}        self.setup_layout()",
            f"{body}        return None",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}self.frame_width = float(getattr(config, \"frame_width\", 14.222))",
            f"{body}self.frame_height = float(getattr(config, \"frame_height\", 8.0))",
            f"{body}self.safe_margin = float(getattr(self, \"safe_margin\", 0.45))",
            f"{body}self.full_canvas = {{\"center\": ORIGIN, \"width\": self.frame_width - 2 * self.safe_margin, \"height\": self.frame_height - 2 * self.safe_margin}}",
            f"{body}return None",
        ])
    if needs_inline_math_text:
        helper_lines.extend([
            "",
            f"{indent}def inline_math_text(self, *parts, font_size=24, color=None, formula_color=None, buff=0.08, **_kwargs):",
            f"{body}items = []",
            f"{body}text_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"MAIN_WHITE\", WHITE))",
            f"{body}math_color = formula_color or getattr(self, \"FORMULA_COLOR\", text_color)",
            f"{body}for part in parts:",
            f"{body}    if isinstance(part, (tuple, list)) and len(part) >= 2 and str(part[0]).lower() == \"math\":",
            f"{body}        items.append(MathTex(str(part[1]), font_size=font_size, color=math_color))",
            f"{body}    else:",
            f"{body}        text_value = {_inline_math_text_plain_value_expr('part')}",
            f"{body}        items.append(Text(str(text_value), font_size=font_size, color=text_color))",
            f"{body}if not items:",
            f"{body}    items.append(Text(\"\", font_size=font_size, color=text_color))",
            f"{body}group = VGroup(*items).arrange(RIGHT, buff=buff, aligned_edge=DOWN)",
            f"{body}return group",
        ])
    if needs_cjk_math_tex:
        helper_lines.extend([
            "",
            f'{indent}def cjk_math_tex(self, content, area="none", font_size=30, color=None, max_width=None, max_height=None, **kwargs):',
            f"{body}text_color = color or getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}if hasattr(self, \"inline_math_text\"):",
            f"{body}    try:",
            f"{body}        return self.inline_math_text(str(content), area=area, font_size=font_size, color=text_color, max_width=max_width, max_height=max_height, **kwargs)",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    return self.safe_text_box(str(content), area=area, font_size=font_size, color=text_color, max_width=max_width, max_height=max_height, **kwargs)",
            f"{body}mob = Text(str(content), font_size=int(font_size), color=text_color, line_spacing=0.88)",
            f"{body}if max_width and getattr(mob, \"width\", 0) > float(max_width):",
            f"{body}    mob.scale_to_fit_width(float(max_width))",
            f"{body}if max_height and getattr(mob, \"height\", 0) > float(max_height):",
            f"{body}    mob.scale_to_fit_height(float(max_height))",
            f"{body}if hasattr(self, \"layout_canvas\") and area not in (None, \"none\", \"raw\"):",
            f"{body}    mob.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}return mob",
        ])
    if needs_get_pt:
        helper_lines.extend([
            "",
            f"{indent}def get_pt(self, x=0.0, y=0.0, z=0.0, scale=1.0, offset=None, **_kwargs):",
            f"{body}if isinstance(x, (list, tuple, np.ndarray)) and y == 0.0 and z == 0.0:",
            f"{body}    arr = np.array(x, dtype=float)",
            f"{body}else:",
            f"{body}    arr = np.array([x, y, z], dtype=float)",
            f"{body}if arr.shape[0] == 2:",
            f"{body}    arr = np.array([arr[0], arr[1], 0.0], dtype=float)",
            f"{body}elif arr.shape[0] > 3:",
            f"{body}    arr = arr[:3]",
            f"{body}if offset is not None:",
            f"{body}    arr = arr + np.array(offset, dtype=float)",
            f"{body}return arr * float(scale)",
        ])
    if needs_rotate_about_axis:
        helper_lines.extend([
            "",
            f"{indent}def rotate_about_axis(self, point, axis_start, axis_end, angle, **_kwargs):",
            f"{body}p = np.array(point, dtype=float)",
            f"{body}a = np.array(axis_start, dtype=float)",
            f"{body}b = np.array(axis_end, dtype=float)",
            f"{body}axis = b - a",
            f"{body}norm = np.linalg.norm(axis)",
            f"{body}if norm < 1e-9:",
            f"{body}    return p",
            f"{body}u = axis / norm",
            f"{body}v = p - a",
            f"{body}return a + v * np.cos(angle) + np.cross(u, v) * np.sin(angle) + u * np.dot(u, v) * (1 - np.cos(angle))",
        ])
    if needs_get_figure_parts:
        helper_lines.extend([
            "",
            f"{indent}def get_figure_parts(self, rows=2, cols=5, shaded_cols=2, width=3.8, height=1.8, **_kwargs):",
            f"{body}lines = VGroup()",
            f"{body}shaded = VGroup()",
            f"{body}cell_w = float(width) / max(1, int(cols))",
            f"{body}cell_h = float(height) / max(1, int(rows))",
            f"{body}origin = LEFT * (float(width) / 2) + UP * (float(height) / 2)",
            f"{body}for r in range(int(rows)):",
            f"{body}    for c in range(int(cols)):",
            f"{body}        center = origin + RIGHT * (c * cell_w + cell_w / 2) + DOWN * (r * cell_h + cell_h / 2)",
            f"{body}        rect = Rectangle(width=cell_w, height=cell_h, stroke_color=getattr(self, \"PRIMARY_TEXT\", WHITE), stroke_width=2)",
            f"{body}        rect.move_to(center)",
            f"{body}        lines.add(rect)",
            f"{body}        if c < int(shaded_cols):",
            f"{body}            fill = Rectangle(width=cell_w, height=cell_h, stroke_width=0, fill_color=getattr(self, \"ACCENT_COLOR\", BLUE), fill_opacity=0.45)",
            f"{body}            fill.move_to(center)",
            f"{body}            shaded.add(fill)",
            f"{body}return lines, shaded",
        ])
    if needs_get_base_geometry:
        helper_lines.extend([
            "",
            f"{indent}def get_base_geometry(self, **_kwargs):",
            f"{body}A = np.array([-2.2, 1.2, 0.0])",
            f"{body}B = np.array([-2.2, -1.2, 0.0])",
            f"{body}C = np.array([1.6, -1.2, 0.0])",
            f"{body}D = np.array([-0.7, -1.2, 0.0])",
            f"{body}line_color = getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}accent = getattr(self, \"ACCENT_COLOR\", getattr(self, \"MAIN_COLOR\", BLUE))",
            f"{body}triangle = Polygon(A, B, C, color=line_color, fill_color=getattr(self, \"MAIN_COLOR\", BLUE), fill_opacity=0.12)",
            f"{body}right_angle = RightAngle(Line(B, A), Line(B, C), length=0.28, color=accent)",
            f"{body}bisector = DashedLine(B, D, color=accent)",
            f"{body}label_A = MathTex(\"A\", font_size=24, color=line_color).next_to(Dot(A, radius=0.01), UP, buff=0.12)",
            f"{body}label_B = MathTex(\"B\", font_size=24, color=line_color).next_to(Dot(B, radius=0.01), DOWN + LEFT, buff=0.12)",
            f"{body}label_C = MathTex(\"C\", font_size=24, color=line_color).next_to(Dot(C, radius=0.01), DOWN + RIGHT, buff=0.12)",
            f"{body}label_D = MathTex(\"D\", font_size=24, color=accent).next_to(Dot(D, radius=0.01), DOWN, buff=0.12)",
            f"{body}label_AC = MathTex(\"AC\", font_size=22, color=line_color).move_to((A + C) / 2 + UP * 0.2)",
            f"{body}label_BC = MathTex(\"BC\", font_size=22, color=line_color).next_to(Line(B, C), DOWN, buff=0.12)",
            f"{body}label_AB = MathTex(\"AB\", font_size=22, color=line_color).next_to(Line(A, B), LEFT, buff=0.12)",
            f"{body}return {{\"A\": A, \"B\": B, \"C\": C, \"D\": D, \"triangle\": triangle, \"right_angle\": right_angle, \"bisector\": bisector, \"label_A\": label_A, \"label_B\": label_B, \"label_C\": label_C, \"label_D\": label_D, \"label_AC\": label_AC, \"label_BC\": label_BC, \"label_AB\": label_AB}}",
        ])
    if needs_get_geometry_figure:
        helper_lines.extend([
            "",
            f"{indent}def get_geometry_figure(self, rows=4, cols=4, shaded=6, width=3.2, height=2.4, **_kwargs):",
            f"{body}lines = VGroup()",
            f"{body}fills = VGroup()",
            f"{body}cell_w = float(width) / max(1, int(cols))",
            f"{body}cell_h = float(height) / max(1, int(rows))",
            f"{body}origin = LEFT * (float(width) / 2) + DOWN * (float(height) / 2)",
            f"{body}count = 0",
            f"{body}for r in range(int(rows)):",
            f"{body}    for c in range(int(cols)):",
            f"{body}        p1 = origin + RIGHT * (c * cell_w) + UP * (r * cell_h)",
            f"{body}        p2 = p1 + RIGHT * cell_w",
            f"{body}        p3 = p1 + UP * cell_h",
            f"{body}        tri = Polygon(p1, p2, p3, stroke_color=getattr(self, \"PRIMARY_TEXT\", WHITE), stroke_width=1.5)",
            f"{body}        lines.add(tri)",
            f"{body}        if count < int(shaded):",
            f"{body}            fill = Polygon(p1, p2, p3, stroke_width=0, fill_color=getattr(self, \"ACCENT_COLOR\", BLUE), fill_opacity=0.45)",
            f"{body}            fills.add(fill)",
            f"{body}        count += 1",
            f"{body}return VGroup(fills, lines)",
        ])
    if needs_get_geometry_base:
        helper_lines.extend([
            "",
            f"{indent}def get_geometry_base(self, center=ORIGIN, scale=1.0, **_kwargs):",
            f"{body}s = float(scale or 1.0)",
            f"{body}A = np.array(center, dtype=float) + UP * 1.55 * s",
            f"{body}B = np.array(center, dtype=float) + LEFT * 2.0 * s + DOWN * 1.05 * s",
            f"{body}C = np.array(center, dtype=float) + RIGHT * 2.0 * s + DOWN * 1.05 * s",
            f"{body}D = (B + C) / 2.0",
            f"{body}line_color = getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}accent = getattr(self, \"ACCENT_COLOR\", YELLOW)",
            f"{body}tri = Polygon(A, B, C, color=getattr(self, \"MAIN_COLOR\", BLUE), fill_opacity=0.05)",
            f"{body}line_ad = Line(A, D, color=accent, stroke_width=3)",
            f"{body}label_A = MathTex(\"A\", font_size=24, color=line_color).next_to(Dot(A, radius=0.01), UP, buff=0.1)",
            f"{body}label_B = MathTex(\"B\", font_size=24, color=line_color).next_to(Dot(B, radius=0.01), DOWN + LEFT, buff=0.1)",
            f"{body}label_C = MathTex(\"C\", font_size=24, color=line_color).next_to(Dot(C, radius=0.01), DOWN + RIGHT, buff=0.1)",
            f"{body}label_D = MathTex(\"D\", font_size=24, color=line_color).next_to(Dot(D, radius=0.01), DOWN, buff=0.1)",
            f"{body}def _tick(p, q, color=None):",
            f"{body}    p_arr, q_arr = np.array(p, dtype=float), np.array(q, dtype=float)",
            f"{body}    mid = (p_arr + q_arr) / 2.0",
            f"{body}    v = q_arr - p_arr",
            f"{body}    perp = np.array([-v[1], v[0], 0.0])",
            f"{body}    norm = np.linalg.norm(perp)",
            f"{body}    if norm > 1e-9:",
            f"{body}        perp = perp / norm",
            f"{body}    return Line(mid - perp * 0.11 * s, mid + perp * 0.11 * s, color=color or accent, stroke_width=3)",
            f"{body}return {{",
            f"{body}    \"A\": A, \"B\": B, \"C\": C, \"D\": D,",
            f"{body}    \"tri\": tri, \"line_ad\": line_ad,",
            f"{body}    \"label_A\": label_A, \"label_B\": label_B, \"label_C\": label_C, \"label_D\": label_D,",
            f"{body}    \"tick_AB\": _tick(A, B), \"tick_AC\": _tick(A, C),",
            f"{body}    \"tick_BD\": _tick(B, D), \"tick_CD\": _tick(D, C),",
            f"{body}}}",
        ])
    if needs_get_square_model:
        helper_lines.extend([
            "",
            f'{indent}def get_square_model(self, side_length=3.0, center=None, fill_opacity=0.22, show_labels=True, show_areas=True, **_kwargs):',
            f"{body}side = float(side_length or 3.0)",
            f"{body}c = center if center is not None else RIGHT * 2.3 + DOWN * 0.15",
            f"{body}a = side * 0.58",
            f"{body}b = side - a",
            f"{body}left = c + LEFT * (side / 2)",
            f"{body}right = c + RIGHT * (side / 2)",
            f"{body}top = c + UP * (side / 2)",
            f"{body}bottom = c + DOWN * (side / 2)",
            f"{body}x_split = left + RIGHT * a",
            f"{body}y_split = bottom + UP * b",
            f"{body}line_color = getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}main_color = getattr(self, \"MAIN_COLOR\", BLUE)",
            f"{body}accent = getattr(self, \"ACCENT_COLOR\", YELLOW)",
            f"{body}outer = Square(side_length=side, color=line_color, stroke_width=3).move_to(c)",
            f"{body}vline = Line(x_split + DOWN * (side / 2), x_split + UP * (side / 2), color=line_color, stroke_width=2)",
            f"{body}hline = Line(left + UP * b, right + UP * b, color=line_color, stroke_width=2)",
            f"{body}split_lines = VGroup(vline, hline)",
            f"{body}def _rect(width, height, center_point, color):",
            f"{body}    rect = Rectangle(width=width, height=height, stroke_width=0, fill_color=color, fill_opacity=float(fill_opacity or 0.0))",
            f"{body}    rect.move_to(center_point)",
            f"{body}    return rect",
            f"{body}regions = VGroup(",
            f"{body}    _rect(a, a, c + LEFT * (b / 2) + UP * (b / 2), main_color),",
            f"{body}    _rect(b, a, c + RIGHT * (a / 2) + UP * (b / 2), accent),",
            f"{body}    _rect(a, b, c + LEFT * (b / 2) + DOWN * (a / 2), accent),",
            f"{body}    _rect(b, b, c + RIGHT * (a / 2) + DOWN * (a / 2), main_color),",
            f"{body})",
            f"{body}labels = VGroup()",
            f"{body}if show_labels:",
            f"{body}    label_specs = [(\"a\", c + LEFT * (b / 2) + UP * (side / 2 + 0.22)), (\"b\", c + RIGHT * (a / 2) + UP * (side / 2 + 0.22)), (\"a\", c + LEFT * (side / 2 + 0.22) + UP * (b / 2)), (\"b\", c + LEFT * (side / 2 + 0.22) + DOWN * (a / 2))]",
            f"{body}    for tex, pos in label_specs:",
            f"{body}        labels.add(Text(str(tex), font_size=24, color=line_color).move_to(pos))",
            f"{body}area_labels = VGroup()",
            f"{body}if show_areas:",
            f"{body}    area_specs = [(\"a^2\", regions[0]), (\"ab\", regions[1]), (\"ab\", regions[2]), (\"b^2\", regions[3])]",
            f"{body}    for tex, rect in area_specs:",
            f"{body}        area_labels.add(Text(str(tex), font_size=22, color=line_color).move_to(rect.get_center()))",
            f"{body}return {{\"outer\": outer, \"split_lines\": split_lines, \"labels\": labels, \"regions\": regions, \"area_labels\": area_labels}}",
        ])
    if needs_get_figure:
        helper_lines.extend([
            "",
            f"{indent}def get_figure(self, rows=4, cols=4, shaded=6, width=3.2, height=2.4, **kwargs):",
            f"{body}if hasattr(self, \"create_figure\"):",
            f"{body}    return self.create_figure(rows=rows, cols=cols, shaded=shaded, width=width, height=height, **kwargs)",
            f"{body}if hasattr(self, \"get_geometry_figure\"):",
            f"{body}    return self.get_geometry_figure(rows=rows, cols=cols, shaded=shaded, width=width, height=height, **kwargs)",
            f"{body}group = VGroup()",
            f"{body}cell_w = float(width) / max(1, int(cols))",
            f"{body}cell_h = float(height) / max(1, int(rows))",
            f"{body}origin = LEFT * (float(width) / 2) + DOWN * (float(height) / 2)",
            f"{body}for r in range(int(rows)):",
            f"{body}    for c in range(int(cols)):",
            f"{body}        rect = Rectangle(width=cell_w, height=cell_h, stroke_color=getattr(self, \"PRIMARY_TEXT\", WHITE), stroke_width=1.5)",
            f"{body}        rect.move_to(origin + RIGHT * (c * cell_w + cell_w / 2) + UP * (r * cell_h + cell_h / 2))",
            f"{body}        group.add(rect)",
            f"{body}return group",
        ])
    if needs_get_figures:
        helper_lines.extend([
            "",
            f"{indent}def get_figures(self, rows=2, cols=5, shaded_a=2, shaded_b=3, width=3.4, height=1.6, **_kwargs):",
            f"{body}def _grid(shaded):",
            f"{body}    group = VGroup()",
            f"{body}    cell_w = float(width) / max(1, int(cols))",
            f"{body}    cell_h = float(height) / max(1, int(rows))",
            f"{body}    origin = LEFT * (float(width) / 2) + DOWN * (float(height) / 2)",
            f"{body}    count = 0",
            f"{body}    for r in range(int(rows)):",
            f"{body}        for c in range(int(cols)):",
            f"{body}            rect = Rectangle(width=cell_w, height=cell_h, stroke_color=getattr(self, \"PRIMARY_TEXT\", WHITE), stroke_width=1.5)",
            f"{body}            rect.move_to(origin + RIGHT * (c * cell_w + cell_w / 2) + UP * (r * cell_h + cell_h / 2))",
            f"{body}            if count < int(shaded):",
            f"{body}                rect.set_fill(getattr(self, \"ACCENT_COLOR\", BLUE), opacity=0.45)",
            f"{body}            group.add(rect)",
            f"{body}            count += 1",
            f"{body}    return group",
            f"{body}fig_a = _grid(shaded_a)",
            f"{body}fig_b = _grid(shaded_b)",
            f"{body}fig_a.shift(LEFT * 2.0)",
            f"{body}fig_b.shift(RIGHT * 2.0)",
            f"{body}return fig_a, fig_b",
        ])
    if needs_get_title:
        helper_lines.extend([
            "",
            f'{indent}def get_title(self, text="", area="top", font_size=42, color=None, **_kwargs):',
            f"{body}title_color = color or getattr(self, \"TITLE_COLOR\", getattr(self, \"PRIMARY_TEXT\", WHITE))",
            f"{body}title = Text(str(text), font_size=font_size, color=title_color)",
            f"{body}if hasattr(self, \"layout_canvas\"):",
            f"{body}    try:",
            f"{body}        title.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}        return title",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}title.to_edge(UP, buff=0.35)",
            f"{body}return title",
        ])
    if needs_get_formula:
        helper_lines.extend([
            "",
            f'{indent}def get_formula(self, tex="", font_size=28, color=None, **_kwargs):',
            f"{body}formula_color = color or getattr(self, \"FORMULA_COLOR\", getattr(self, \"PRIMARY_TEXT\", WHITE))",
            f"{body}raw = str(tex)",
            f"{body}try:",
            f"{body}    return MathTex(raw, font_size=font_size, color=formula_color)",
            f"{body}except Exception:",
            f"{body}    plain = raw.replace(r\"\\text{{\", \"\").replace(r\"\\mathrm{{\", \"\").replace(\"{{\", \"\").replace(\"}}\", \"\")",
            f"{body}    plain = plain.replace(r\"\\Rightarrow\", \"=>\").replace(r\"\\frac\", \"frac\")",
            f"{body}    return Text(plain, font_size=font_size, color=formula_color)",
        ])
    if needs_get_paraboloid:
        helper_lines.extend([
            "",
            f"{indent}def get_paraboloid(self, axes=None, r_max=2.0, color=None, opacity=0.6, **_kwargs):",
            f"{body}surface_color = color or getattr(self, \"SECONDARY_COLOR\", getattr(self, \"MAIN_COLOR\", BLUE))",
            f"{body}try:",
            f"{body}    r = float(r_max or 2.0)",
            f"{body}except Exception:",
            f"{body}    r = 2.0",
            f"{body}def _point(u, v):",
            f"{body}    x = u * np.cos(v)",
            f"{body}    y = u * np.sin(v)",
            f"{body}    z = x * x + y * y",
            f"{body}    return axes.c2p(x, y, z) if axes is not None and hasattr(axes, \"c2p\") else np.array([x, y, z], dtype=float)",
            f"{body}return Surface(_point, u_range=[0, r], v_range=[0, TAU], resolution=(12, 24), fill_opacity=float(opacity), checkerboard_colors=[surface_color, surface_color])",
        ])
    if needs_get_cube_elements:
        helper_lines.extend([
            "",
            f'{indent}def get_cube_elements(self, side_length=2.0, main_color=None, accent_color=None, text_color=None, **_kwargs):',
            f"{body}side = float(side_length or 2.0)",
            f"{body}half = side / 2.0",
            f"{body}main = main_color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", BLUE))",
            f"{body}accent = accent_color or getattr(self, \"ACCENT_COLOR\", globals().get(\"YELLOW\", YELLOW))",
            f"{body}label_color = text_color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"WHITE\", WHITE))",
            f"{body}axes = ThreeDAxes(x_range=[-2, 2, 1], y_range=[-2, 2, 1], z_range=[-2, 2, 1], x_length=3.2, y_length=3.2, z_length=3.2)",
            f"{body}points = {{",
            f"{body}    \"A\": np.array([-half, -half, -half]), \"B\": np.array([half, -half, -half]),",
            f"{body}    \"C\": np.array([half, half, -half]), \"D\": np.array([-half, half, -half]),",
            f"{body}    \"A1\": np.array([-half, -half, half]), \"B1\": np.array([half, -half, half]),",
            f"{body}    \"C1\": np.array([half, half, half]), \"D1\": np.array([-half, half, half]),",
            f"{body}}}",
            f"{body}edge_pairs = [(\"A\", \"B\"), (\"B\", \"C\"), (\"C\", \"D\"), (\"D\", \"A\"), (\"A1\", \"B1\"), (\"B1\", \"C1\"), (\"C1\", \"D1\"), (\"D1\", \"A1\"), (\"A\", \"A1\"), (\"B\", \"B1\"), (\"C\", \"C1\"), (\"D\", \"D1\")]",
            f"{body}line_cls = globals().get(\"Line3D\", Line)",
            f"{body}dot_cls = globals().get(\"Dot3D\", Dot)",
            f"{body}edges = VGroup(*[line_cls(points[a], points[b], color=main, stroke_width=3) for a, b in edge_pairs])",
            f"{body}dots = VGroup(*[dot_cls(point=points[name], radius=0.055, color=accent) for name in (\"A\", \"B\", \"C\", \"D\", \"A1\", \"B1\", \"C1\", \"D1\")])",
            f"{body}labels = []",
            f"{body}for label_text in (\"A\", \"B\", \"C\", \"D\", \"A_1\", \"B_1\", \"C_1\", \"D_1\"):",
            f"{body}    key = label_text.replace(\"_\", \"\")",
            f"{body}    label = MathTex(label_text, font_size=22, color=label_color)",
            f"{body}    direction = np.array(points[key], dtype=float)",
            f"{body}    norm = np.linalg.norm(direction)",
            f"{body}    if norm > 1e-9:",
            f"{body}        direction = direction / norm",
            f"{body}    label.move_to(points[key] + direction * 0.28)",
            f"{body}    labels.append(label)",
            f"{body}cube = VGroup(edges, dots, *labels)",
            f"{body}return axes, points, edges, dots, labels, cube",
        ])
    if needs_create_triangle_figure:
        helper_lines.extend([
            "",
            f"{indent}def create_triangle_figure(self, rows=4, cols=4, shaded=6, width=3.2, height=2.4, **_kwargs):",
            f"{body}fig = self.get_geometry_figure(rows=rows, cols=cols, shaded=shaded, width=width, height=height) if hasattr(self, \"get_geometry_figure\") else VGroup()",
            f"{body}points = []",
            f"{body}cell_w = float(width) / max(1, int(cols))",
            f"{body}cell_h = float(height) / max(1, int(rows))",
            f"{body}origin = LEFT * (float(width) / 2) + DOWN * (float(height) / 2)",
            f"{body}for r in range(int(rows)):",
            f"{body}    for c in range(int(cols)):",
            f"{body}        p1 = origin + RIGHT * (c * cell_w) + UP * (r * cell_h)",
            f"{body}        p2 = p1 + RIGHT * cell_w",
            f"{body}        p3 = p1 + UP * cell_h",
            f"{body}        points.append((p1 + p2 + p3) / 3)",
            f"{body}class _MathPiTriangleFigure(VGroup):",
            f"{body}    def __init__(self, figure, centers):",
            f"{body}        super().__init__(figure)",
            f"{body}        self.triangle_centers = list(centers or [])",
            f"{body}    def __iter__(self):",
            f"{body}        return iter((self, self.triangle_centers))",
            f"{body}return _MathPiTriangleFigure(fig, points)",
        ])
    if needs_create_triangle_abc:
        helper_lines.extend([
            "",
            f"{indent}def create_triangle_abc(self, scale=1.0, center=ORIGIN, **_kwargs):",
            f"{body}s = float(scale or 1.0)",
            f"{body}c = np.array(center, dtype=float)",
            f"{body}A = c + UP * 1.45 * s",
            f"{body}B = c + LEFT * 1.8 * s + DOWN * 1.15 * s",
            f"{body}C = c + RIGHT * 1.8 * s + DOWN * 1.15 * s",
            f"{body}D = (B + C) / 2.0",
            f"{body}line_color = getattr(self, \"MAIN_COLOR\", BLUE)",
            f"{body}text_color = getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}accent = getattr(self, \"ACCENT_COLOR\", YELLOW)",
            f"{body}triangle = Polygon(A, B, C, color=line_color, stroke_width=4)",
            f"{body}label_A = MathTex(\"A\", color=text_color, font_size=28).next_to(Dot(A, radius=0.01), UP, buff=0.2)",
            f"{body}label_B = MathTex(\"B\", color=text_color, font_size=28).next_to(Dot(B, radius=0.01), DL, buff=0.1)",
            f"{body}label_C = MathTex(\"C\", color=text_color, font_size=28).next_to(Dot(C, radius=0.01), DR, buff=0.1)",
            f"{body}label_D = MathTex(\"D\", color=text_color, font_size=28).next_to(Dot(D, radius=0.01), DOWN, buff=0.2)",
            f"{body}dot_D = Dot(D, color=accent, radius=0.06)",
            f"{body}return triangle, label_A, label_B, label_C, label_D, dot_D, A, B, C, D",
        ])
    if needs_create_figure:
        helper_lines.extend([
            "",
            f"{indent}def create_figure(self, rows=4, cols=4, shaded=6, width=3.2, height=2.4, **_kwargs):",
            f"{body}if hasattr(self, \"get_geometry_figure\"):",
            f"{body}    return self.get_geometry_figure(rows=rows, cols=cols, shaded=shaded, width=width, height=height)",
            f"{body}group = VGroup()",
            f"{body}cell_w = float(width) / max(1, int(cols))",
            f"{body}cell_h = float(height) / max(1, int(rows))",
            f"{body}origin = LEFT * (float(width) / 2) + DOWN * (float(height) / 2)",
            f"{body}count = 0",
            f"{body}for r in range(int(rows)):",
            f"{body}    for c in range(int(cols)):",
            f"{body}        rect = Rectangle(width=cell_w, height=cell_h, stroke_color=getattr(self, \"PRIMARY_TEXT\", WHITE), stroke_width=1.5)",
            f"{body}        rect.move_to(origin + RIGHT * (c * cell_w + cell_w / 2) + UP * (r * cell_h + cell_h / 2))",
            f"{body}        if count < int(shaded):",
            f"{body}            rect.set_fill(getattr(self, \"ACCENT_COLOR\", BLUE), opacity=0.45)",
            f"{body}        group.add(rect)",
            f"{body}        count += 1",
            f"{body}return group",
        ])
    if needs_get_triangle_centers:
        helper_lines.extend([
            "",
            f"{indent}def get_triangle_centers(self, points, shaded=6, **_kwargs):",
            f"{body}centers = list(points or [])",
            f"{body}cut = max(0, min(int(shaded), len(centers)))",
            f"{body}return centers[:cut], centers[cut:]",
        ])
    if needs_get_rhombus_geometry:
        helper_lines.extend([
            "",
            f"{indent}def get_rhombus_geometry(self, center=ORIGIN, width=4.4, height=2.6, **_kwargs):",
            f"{body}try:",
            f"{body}    c = np.array(center, dtype=float)",
            f"{body}except Exception:",
            f"{body}    c = ORIGIN",
            f"{body}try:",
            f"{body}    w = float(width or 4.4)",
            f"{body}except Exception:",
            f"{body}    w = 4.4",
            f"{body}try:",
            f"{body}    h = float(height or 2.6)",
            f"{body}except Exception:",
            f"{body}    h = 2.6",
            f"{body}A = c + LEFT * (w / 2.0)",
            f"{body}B = c + UP * (h / 2.0)",
            f"{body}C = c + RIGHT * (w / 2.0)",
            f"{body}D = c + DOWN * (h / 2.0)",
            f"{body}O = c",
            f"{body}line_color = getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}diag_color = getattr(self, \"SECONDARY_COLOR\", getattr(self, \"ACCENT_COLOR\", line_color))",
            f"{body}accent = getattr(self, \"ACCENT_COLOR\", diag_color)",
            f"{body}text_color = getattr(self, \"PRIMARY_TEXT\", globals().get(\"BLACK\", line_color))",
            f"{body}rhombus = Polygon(A, B, C, D, color=line_color, stroke_width=3, fill_opacity=0.05)",
            f"{body}diag_AC = Line(A, C, color=diag_color, stroke_width=2.5)",
            f"{body}diag_BD = Line(B, D, color=diag_color, stroke_width=2.5)",
            f"{body}lbl_A = MathTex(\"A\", font_size=26, color=text_color).move_to(A + LEFT * 0.28)",
            f"{body}lbl_B = MathTex(\"B\", font_size=26, color=text_color).move_to(B + UP * 0.28)",
            f"{body}lbl_C = MathTex(\"C\", font_size=26, color=text_color).move_to(C + RIGHT * 0.28)",
            f"{body}lbl_D = MathTex(\"D\", font_size=26, color=text_color).move_to(D + DOWN * 0.28)",
            f"{body}dot_O = Dot(O, color=accent, radius=0.055)",
            f"{body}lbl_O = MathTex(\"O\", font_size=24, color=text_color).move_to(O + UR * 0.25)",
            f"{body}try:",
            f"{body}    ra_mark = RightAngle(Line(O, A), Line(O, B), length=0.18, color=accent)",
            f"{body}except Exception:",
            f"{body}    ra_mark = VGroup()",
            f"{body}tri_AOB = Polygon(A, O, B, color=accent, fill_color=accent, fill_opacity=0.10, stroke_width=1.5)",
            f"{body}tri_BOC = Polygon(B, O, C, color=accent, fill_color=accent, fill_opacity=0.10, stroke_width=1.5)",
            f"{body}tri_COD = Polygon(C, O, D, color=accent, fill_color=accent, fill_opacity=0.10, stroke_width=1.5)",
            f"{body}tri_DOA = Polygon(D, O, A, color=accent, fill_color=accent, fill_opacity=0.10, stroke_width=1.5)",
            f"{body}return {{",
            f"{body}    \"A\": A, \"B\": B, \"C\": C, \"D\": D, \"O\": O,",
            f"{body}    \"rhombus\": rhombus, \"diag_AC\": diag_AC, \"diag_BD\": diag_BD,",
            f"{body}    \"lbl_A\": lbl_A, \"lbl_B\": lbl_B, \"lbl_C\": lbl_C, \"lbl_D\": lbl_D,",
            f"{body}    \"dot_O\": dot_O, \"lbl_O\": lbl_O, \"ra_mark\": ra_mark,",
            f"{body}    \"tri_AOB\": tri_AOB, \"tri_BOC\": tri_BOC, \"tri_COD\": tri_COD, \"tri_DOA\": tri_DOA,",
            f"{body}}}",
        ])
    if needs_make_text:
        helper_lines.extend([
            "",
            f'{indent}def make_text(self, text, font_size=24, color=None, area=None, max_width=None, max_height=None, **_kwargs):',
            f"{body}text_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"MAIN_WHITE\", WHITE))",
            f"{body}mob = Text(str(text), font_size=font_size, color=text_color, line_spacing=0.85)",
            f"{body}if max_width and getattr(mob, \"width\", 0) > float(max_width):",
            f"{body}    mob.scale_to_fit_width(float(max_width))",
            f"{body}if max_height and getattr(mob, \"height\", 0) > float(max_height):",
            f"{body}    mob.scale_to_fit_height(float(max_height))",
            f"{body}if area and hasattr(self, \"layout_canvas\"):",
            f"{body}    mob.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}return mob",
        ])
    if needs_make_title:
        helper_lines.extend([
            "",
            f'{indent}def make_title(self, text, area="top", font_size=42, color=None, **kwargs):',
            f"{body}title_color = color or getattr(self, \"TITLE_COLOR\", getattr(self, \"PRIMARY_TEXT\", globals().get(\"WHITE\", WHITE)))",
            f"{body}try:",
            f"{body}    if hasattr(self, \"safe_text_box\"):",
            f"{body}        title = self.safe_text_box(text, area=area, font_size=font_size, color=title_color, **kwargs)",
            f"{body}    else:",
            f"{body}        title = Text(str(text), font_size=font_size, color=title_color, **kwargs)",
            f"{body}except TypeError:",
            f"{body}    title = Text(str(text), font_size=font_size, color=title_color)",
            f"{body}try:",
            f"{body}    if hasattr(self, \"layout_canvas\") and area not in (None, \"none\", \"raw\"):",
            f"{body}        title.move_to(self.layout_canvas(area).get(\"center\", UP * 3.1))",
            f"{body}    else:",
            f"{body}        title.to_edge(UP, buff=0.35)",
            f"{body}except Exception:",
            f"{body}    try:",
            f"{body}        title.to_edge(UP, buff=0.35)",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}return title",
        ])
    if needs_make_mixed_line:
        helper_lines.extend([
            "",
            f'{indent}def make_mixed_line(self, *parts, font_size=30, color=None, text_color=None, math_color=None, buff=0.08, area=None, max_width=None, **_kwargs):',
            f"{body}if len(parts) == 1 and isinstance(parts[0], (list, tuple)):",
            f"{body}    parts = tuple(parts[0])",
            f"{body}default_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"WHITE\", WHITE))",
            f"{body}items = []",
            f"{body}for part in parts:",
            f"{body}    if part is None:",
            f"{body}        continue",
            f"{body}    if hasattr(part, \"move_to\"):",
            f"{body}        items.append(part)",
            f"{body}        continue",
            f"{body}    raw = str(part)",
            f"{body}    has_cjk = any(0x4E00 <= ord(ch) <= 0x9FFF for ch in raw)",
            f"{body}    is_math = (not has_cjk) and any(token in raw for token in (\"\\\\\", \"^\", \"_\", \"=\", \"+\"))",
            f"{body}    try:",
            f"{body}        mob = MathTex(raw, font_size=font_size, color=math_color or default_color) if is_math else Text(raw, font_size=font_size, color=text_color or default_color)",
            f"{body}    except Exception:",
            f"{body}        mob = Text(raw.replace(\"\\\\\", \"\"), font_size=font_size, color=text_color or default_color)",
            f"{body}    items.append(mob)",
            f"{body}group = VGroup(*items) if items else VGroup()",
            f"{body}try:",
            f"{body}    group.arrange(RIGHT, buff=float(buff or 0.08), aligned_edge=DOWN)",
            f"{body}except TypeError:",
            f"{body}    group.arrange(RIGHT, buff=float(buff or 0.08))",
            f"{body}try:",
            f"{body}    if max_width and getattr(group, \"width\", 0) > float(max_width):",
            f"{body}        group.scale_to_fit_width(float(max_width))",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}if area and hasattr(self, \"fit_to_canvas\"):",
            f"{body}    return self.fit_to_canvas(group, area=area, move=True)",
            f"{body}return group",
        ])
    if needs_create_text:
        helper_lines.extend([
            "",
            f'{indent}def create_text(self, text, font_size=24, color=None, area=None, max_width=None, max_height=None, width=None, height=None, **_kwargs):',
            f"{body}text_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"MAIN_WHITE\", WHITE))",
            f"{body}try:",
            f"{body}    size = int(font_size)",
            f"{body}except Exception:",
            f"{body}    size = 24",
            f"{body}mob = Text(str(text), font_size=size, color=text_color, line_spacing=0.85)",
            f"{body}limit_w = max_width or width",
            f"{body}limit_h = max_height or height",
            f"{body}try:",
            f"{body}    if limit_w and getattr(mob, \"width\", 0) > float(limit_w):",
            f"{body}        mob.scale_to_fit_width(float(limit_w))",
            f"{body}    if limit_h and getattr(mob, \"height\", 0) > float(limit_h):",
            f"{body}        mob.scale_to_fit_height(float(limit_h))",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}if area and hasattr(self, \"layout_canvas\"):",
            f"{body}    try:",
            f"{body}        mob.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}return mob",
        ])
    if needs_play_voiceover:
        helper_lines.extend([
            "",
            f"{indent}def play_voiceover(self, text=None, *animations, run_time=None, **kwargs):",
            f"{body}text = \"\" if text is None else str(text)",
            f"{body}play_kwargs = dict(kwargs)",
            f"{body}if run_time is not None:",
            f"{body}    play_kwargs[\"run_time\"] = run_time",
            f"{body}def _play_or_wait():",
            f"{body}    if animations:",
            f"{body}        try:",
            f"{body}            return self.play(*animations, **play_kwargs)",
            f"{body}        except TypeError:",
            f"{body}            return self.play(*animations)",
            f"{body}    try:",
            f"{body}        wait_time = float(play_kwargs.get(\"wait_time\", run_time if run_time is not None else 0.3))",
            f"{body}    except Exception:",
            f"{body}        wait_time = 0.3",
            f"{body}    return self.wait(max(0.0, wait_time))",
            f"{body}if text and hasattr(self, \"voiceover\"):",
            f"{body}    try:",
            f"{body}        with self.voiceover(text=text) as tracker:",
            f"{body}            _play_or_wait()",
            f"{body}        return tracker",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}return _play_or_wait()",
        ])
    if needs_make_formula:
        helper_lines.extend([
            "",
            f'{indent}def make_formula(self, tex, font_size=28, color=None, area=None, max_width=None, max_height=None, **kwargs):',
            f"{body}formula_color = color or getattr(self, \"FORMULA_COLOR\", getattr(self, \"PRIMARY_TEXT\", WHITE))",
            f"{body}mob = MathTex(str(tex), font_size=font_size, color=formula_color, **kwargs)",
            f"{body}if max_width and getattr(mob, \"width\", 0) > float(max_width):",
            f"{body}    mob.scale_to_fit_width(float(max_width))",
            f"{body}if max_height and getattr(mob, \"height\", 0) > float(max_height):",
            f"{body}    mob.scale_to_fit_height(float(max_height))",
            f"{body}if area and hasattr(self, \"layout_canvas\"):",
            f"{body}    mob.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}return mob",
        ])
    if needs_make_point_with_label:
        helper_lines.extend([
            "",
            f"{indent}def make_point_with_label(self, name, point, direction=UP, color=None, dot_color=None, font_size=24, dot_radius=0.06, buff=0.15, **_kwargs):",
            f"{body}point_arr = np.array(point, dtype=float)",
            f"{body}main_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}label_color = color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"WHITE\", WHITE))",
            f"{body}dot = Dot(point_arr, radius=dot_radius, color=dot_color or main_color)",
            f"{body}raw = str(name)",
            f"{body}if any(\"\\u4e00\" <= ch <= \"\\u9fff\" for ch in raw):",
            f"{body}    label = Text(raw, font_size=font_size, color=label_color)",
            f"{body}else:",
            f"{body}    label = MathTex(raw, font_size=font_size, color=label_color)",
            f"{body}label.next_to(dot, direction, buff=buff)",
            f"{body}return VGroup(dot, label)",
        ])
    if needs_get_right_angle_mark:
        helper_lines.extend([
            "",
            f"{indent}def get_right_angle_mark(self, p1=None, vertex=None, p2=None, size=0.25, color=None, **_kwargs):",
            f"{body}try:",
            f"{body}    return RightAngle(Line(vertex, p1), Line(vertex, p2), length=float(size), color=color or getattr(self, \"ACCENT_COLOR\", YELLOW))",
            f"{body}except Exception:",
            f"{body}    return VGroup()",
        ])
    if needs_get_tick_mark:
        helper_lines.extend([
            "",
            f"{indent}def get_tick_mark(self, p1, p2, num_ticks=1, color=None, length=0.18, spacing=0.08, **_kwargs):",
            f"{body}try:",
            f"{body}    start = np.array(p1, dtype=float)",
            f"{body}    end = np.array(p2, dtype=float)",
            f"{body}    direction = end - start",
            f"{body}    norm = np.linalg.norm(direction)",
            f"{body}    if norm < 1e-9:",
            f"{body}        return VGroup()",
            f"{body}    unit = direction / norm",
            f"{body}    perp = np.array([-unit[1], unit[0], 0.0])",
            f"{body}    count = max(1, int(num_ticks or 1))",
            f"{body}    group = VGroup()",
            f"{body}    for index in range(count):",
            f"{body}        offset = (index - (count - 1) / 2.0) * float(spacing)",
            f"{body}        mid = (start + end) / 2.0 + unit * offset",
            f"{body}        group.add(Line(mid - perp * float(length) / 2.0, mid + perp * float(length) / 2.0, color=color or getattr(self, \"ACCENT_COLOR\", YELLOW), stroke_width=3))",
            f"{body}    return group",
            f"{body}except Exception:",
            f"{body}    return VGroup()",
        ])
    if needs_get_angle_arc:
        helper_lines.extend([
            "",
            f"{indent}def get_angle_arc(self, vertex=None, p1=None, p2=None, radius=0.3, color=None, **_kwargs):",
            f"{body}try:",
            f"{body}    v = np.array(vertex, dtype=float)",
            f"{body}    a = np.array(p1, dtype=float) - v",
            f"{body}    b = np.array(p2, dtype=float) - v",
            f"{body}    start = np.arctan2(a[1], a[0])",
            f"{body}    end = np.arctan2(b[1], b[0])",
            f"{body}    angle = (end - start) % TAU",
            f"{body}    if angle > PI:",
            f"{body}        angle -= TAU",
            f"{body}    arc = Arc(radius=float(radius), start_angle=start, angle=angle, color=color or getattr(self, \"ACCENT_COLOR\", YELLOW))",
            f"{body}    arc.move_arc_center_to(v)",
            f"{body}    return arc",
            f"{body}except Exception:",
            f"{body}    return VGroup()",
        ])
    if needs_create_check_mark:
        helper_lines.extend([
            "",
            f"{indent}def create_check_mark(self, size=0.8, color=None, stroke_width=6, **_kwargs):",
            f"{body}mark_color = color or getattr(self, \"SECONDARY_COLOR\", globals().get(\"GREEN\", WHITE))",
            f"{body}s = float(size or 0.8)",
            f"{body}left = Line(LEFT * 0.36 + DOWN * 0.02, LEFT * 0.08 + DOWN * 0.28, color=mark_color, stroke_width=stroke_width)",
            f"{body}right = Line(LEFT * 0.08 + DOWN * 0.28, RIGHT * 0.42 + UP * 0.30, color=mark_color, stroke_width=stroke_width)",
            f"{body}return VGroup(left, right).scale(s)",
        ])
    if needs_create_cargo_box:
        helper_lines.extend([
            "",
            f"{indent}def create_cargo_box(self, width=1.35, height=0.9, color=None, fill_color=None, **_kwargs):",
            f"{body}line_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}box_fill = fill_color or getattr(self, \"BG_COLOR\", globals().get(\"WHITE\", BLACK))",
            f"{body}box = RoundedRectangle(width=float(width), height=float(height), corner_radius=0.08, stroke_color=line_color, stroke_width=3, fill_color=box_fill, fill_opacity=0.18)",
            f"{body}stripe1 = Line(box.get_left() + RIGHT * 0.28, box.get_left() + RIGHT * 0.28 + UP * float(height), color=line_color, stroke_width=2)",
            f"{body}stripe2 = Line(box.get_right() + LEFT * 0.28, box.get_right() + LEFT * 0.28 + UP * float(height), color=line_color, stroke_width=2)",
            f"{body}label = Text(\"冷链\", font_size=16, color=getattr(self, \"PRIMARY_TEXT\", globals().get(\"WHITE\", WHITE)))",
            f"{body}label.move_to(box.get_center())",
            f"{body}return VGroup(box, stripe1, stripe2, label)",
        ])
    if needs_create_thermometer:
        helper_lines.extend([
            "",
            f"{indent}def create_thermometer(self, temp_ratio=0.6, color=None, height=1.2, **_kwargs):",
            f"{body}accent = color or getattr(self, \"ACCENT_COLOR\", globals().get(\"RED\", WHITE))",
            f"{body}outline = RoundedRectangle(width=0.28, height=float(height), corner_radius=0.14, stroke_color=accent, stroke_width=3, fill_opacity=0)",
            f"{body}bulb = Circle(radius=0.20, stroke_color=accent, stroke_width=3, fill_color=accent, fill_opacity=0.35).next_to(outline, DOWN, buff=-0.05)",
            f"{body}ratio = max(0.05, min(1.0, float(temp_ratio or 0.6)))",
            f"{body}fill = Rectangle(width=0.12, height=max(0.08, float(height) * ratio * 0.78), stroke_width=0, fill_color=accent, fill_opacity=0.55)",
            f"{body}fill.align_to(outline, DOWN).shift(UP * 0.08)",
            f"{body}ticks = VGroup(*[Line(RIGHT * 0.20 + UP * y, RIGHT * 0.34 + UP * y, color=accent, stroke_width=1.5) for y in (-0.35, 0.0, 0.35)])",
            f"{body}ticks.move_to(outline.get_center() + RIGHT * 0.28)",
            f"{body}return VGroup(outline, fill, bulb, ticks)",
        ])
    if needs_create_frozen_river:
        helper_lines.extend([
            "",
            f"{indent}def create_frozen_river(self, width=3.2, height=1.0, color=None, **_kwargs):",
            f"{body}ice_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}base = RoundedRectangle(width=float(width), height=float(height), corner_radius=0.12, stroke_color=ice_color, stroke_width=3, fill_color=ice_color, fill_opacity=0.12)",
            f"{body}cracks = VGroup(",
            f"{body}    Line(LEFT * float(width) * 0.38 + UP * 0.18, LEFT * float(width) * 0.10 + DOWN * 0.04, color=ice_color, stroke_width=2),",
            f"{body}    Line(LEFT * float(width) * 0.10 + DOWN * 0.04, RIGHT * float(width) * 0.12 + UP * 0.12, color=ice_color, stroke_width=2),",
            f"{body}    Line(RIGHT * float(width) * 0.18 + DOWN * 0.18, RIGHT * float(width) * 0.40 + UP * 0.05, color=ice_color, stroke_width=2),",
            f"{body})",
            f"{body}waves = VGroup(*[Line(LEFT * float(width) * 0.42 + RIGHT * index * float(width) * 0.21 + DOWN * 0.34, LEFT * float(width) * 0.32 + RIGHT * index * float(width) * 0.21 + DOWN * 0.26, color=ice_color, stroke_width=1.5) for index in range(5)])",
            f"{body}return VGroup(base, cracks, waves)",
        ])
    if needs_create_balance_scale:
        helper_lines.extend([
            "",
            f"{indent}def create_balance_scale(self, width=2.2, color=None, **_kwargs):",
            f"{body}line_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}accent = getattr(self, \"EMPHASIS_COLOR\", getattr(self, \"ACCENT_COLOR\", line_color))",
            f"{body}beam = Line(LEFT * float(width) / 2, RIGHT * float(width) / 2, color=line_color, stroke_width=4)",
            f"{body}post = Line(DOWN * 0.65, UP * 0.35, color=line_color, stroke_width=4)",
            f"{body}base = Line(LEFT * 0.55 + DOWN * 0.65, RIGHT * 0.55 + DOWN * 0.65, color=line_color, stroke_width=4)",
            f"{body}left_chain = Line(LEFT * float(width) * 0.36, LEFT * float(width) * 0.36 + DOWN * 0.42, color=line_color, stroke_width=2)",
            f"{body}right_chain = Line(RIGHT * float(width) * 0.36, RIGHT * float(width) * 0.36 + DOWN * 0.42, color=line_color, stroke_width=2)",
            f"{body}left_pan = Arc(radius=0.38, start_angle=PI, angle=PI, color=accent).move_to(left_chain.get_end() + DOWN * 0.05)",
            f"{body}right_pan = Arc(radius=0.38, start_angle=PI, angle=PI, color=accent).move_to(right_chain.get_end() + DOWN * 0.05)",
            f"{body}return VGroup(beam, post, base, left_chain, right_chain, left_pan, right_pan)",
        ])
    if needs_create_left_column:
        helper_lines.extend(["", *_create_left_column_helper_lines(indent, body)])
    if needs_get_rope:
        helper_lines.extend([
            "",
            f"{indent}def get_rope(self, folds=0, width=6.4, color=None, marker_color=None, **_kwargs):",
            f"{body}try:",
            f"{body}    segments = max(1, int(2 ** max(0, int(folds))))",
            f"{body}except Exception:",
            f"{body}    segments = 1",
            f"{body}line_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}tick_color = marker_color or getattr(self, \"ACCENT_COLOR\", line_color)",
            f"{body}try:",
            f"{body}    total_width = float(width or 6.4)",
            f"{body}except Exception:",
            f"{body}    total_width = 6.4",
            f"{body}try:",
            f"{body}    frame_limit = max(1.0, float(getattr(config, \"frame_width\", 14.222)) - 1.4)",
            f"{body}    total_width = min(total_width, frame_limit)",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}segment_width = total_width / max(1, segments)",
            f"{body}left = LEFT * (total_width / 2.0)",
            f"{body}segment_group = VGroup()",
            f"{body}marker_group = VGroup()",
            f"{body}for index in range(segments):",
            f"{body}    start = left + RIGHT * (index * segment_width)",
            f"{body}    end = left + RIGHT * ((index + 1) * segment_width)",
            f"{body}    segment = Line(start, end, color=line_color, stroke_width=7)",
            f"{body}    segment.set_stroke(line_color, width=7, opacity=1)",
            f"{body}    segment_group.add(segment)",
            f"{body}for index in range(segments + 1):",
            f"{body}    x = left + RIGHT * (index * segment_width)",
            f"{body}    marker_group.add(Line(x + DOWN * 0.18, x + UP * 0.18, color=tick_color, stroke_width=2.2))",
            f"{body}rope = VGroup(segment_group, marker_group)",
            f"{body}rope.segment_count = segments",
            f"{body}rope.segment_width = segment_width",
            f"{body}return rope",
        ])
    if needs_create_grid_visual:
        helper_lines.extend([
            "",
            f"{indent}def create_grid_visual(self, rows=3, cols=3, spacing=1.0, color=None, point_color=None, dot_radius=0.045, **_kwargs):",
            f"{body}try:",
            f"{body}    rows = max(2, int(rows))",
            f"{body}except Exception:",
            f"{body}    rows = 3",
            f"{body}try:",
            f"{body}    cols = max(2, int(cols))",
            f"{body}except Exception:",
            f"{body}    cols = 3",
            f"{body}try:",
            f"{body}    step = max(0.25, float(spacing or 1.0))",
            f"{body}except Exception:",
            f"{body}    step = 1.0",
            f"{body}line_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}dot_color = point_color or getattr(self, \"ACCENT_COLOR\", line_color)",
            f"{body}grid_width = (cols - 1) * step",
            f"{body}grid_height = (rows - 1) * step",
            f"{body}line_group = VGroup()",
            f"{body}dot_group = VGroup()",
            f"{body}for c in range(cols):",
            f"{body}    x = (c - (cols - 1) / 2.0) * step",
            f"{body}    line_group.add(Line(np.array([x, -grid_height / 2.0, 0.0]), np.array([x, grid_height / 2.0, 0.0]), color=line_color, stroke_width=2.2))",
            f"{body}for r in range(rows):",
            f"{body}    y = ((rows - 1) / 2.0 - r) * step",
            f"{body}    line_group.add(Line(np.array([-grid_width / 2.0, y, 0.0]), np.array([grid_width / 2.0, y, 0.0]), color=line_color, stroke_width=2.2))",
            f"{body}for r in range(rows):",
            f"{body}    for c in range(cols):",
            f"{body}        dot_group.add(Dot(np.array([(c - (cols - 1) / 2.0) * step, ((rows - 1) / 2.0 - r) * step, 0.0]), radius=float(dot_radius or 0.045), color=dot_color))",
            f"{body}grid = VGroup(line_group, dot_group)",
            f"{body}def _grid_pos(row, col, *_args, **_kw):",
            f"{body}    try:",
            f"{body}        rr = max(0, min(rows - 1, int(row)))",
            f"{body}    except Exception:",
            f"{body}        rr = 0",
            f"{body}    try:",
            f"{body}        cc = max(0, min(cols - 1, int(col)))",
            f"{body}    except Exception:",
            f"{body}        cc = 0",
            f"{body}    return np.array([(cc - (cols - 1) / 2.0) * step, ((rows - 1) / 2.0 - rr) * step, 0.0])",
            f"{body}grid.get_grid_pos = _grid_pos",
            f"{body}grid.grid_lines = line_group",
            f"{body}grid.grid_dots = dot_group",
            f"{body}grid.rows = rows",
            f"{body}grid.cols = cols",
            f"{body}grid.spacing = step",
            f"{body}return grid",
        ])
    if needs_create_grid:
        helper_lines.extend([
            "",
            f"{indent}def create_grid(self, x_range=None, y_range=None, step=1.0, origin=None, rows=None, cols=None, spacing=None, color=None, point_color=None, dot_radius=0.035, **_kwargs):",
            f"{body}def _range_pair(value, default_start, default_end):",
            f"{body}    try:",
            f"{body}        if isinstance(value, (list, tuple)) and len(value) >= 2:",
            f"{body}            return float(value[0]), float(value[1])",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}    return float(default_start), float(default_end)",
            f"{body}x0, x1 = _range_pair(x_range, 0.0, 6.0)",
            f"{body}y0, y1 = _range_pair(y_range, 0.0, 4.0)",
            f"{body}try:",
            f"{body}    step_value = max(0.2, float(spacing if spacing is not None else step))",
            f"{body}except Exception:",
            f"{body}    step_value = 1.0",
            f"{body}try:",
            f"{body}    cols_value = max(2, int(cols)) if cols is not None else max(2, int(round(abs(x1 - x0) / step_value)) + 1)",
            f"{body}except Exception:",
            f"{body}    cols_value = 7",
            f"{body}try:",
            f"{body}    rows_value = max(2, int(rows)) if rows is not None else max(2, int(round(abs(y1 - y0) / step_value)) + 1)",
            f"{body}except Exception:",
            f"{body}    rows_value = 5",
            f"{body}line_color = color or getattr(self, \"MAIN_COLOR\", globals().get(\"BLUE\", WHITE))",
            f"{body}dot_color = point_color or getattr(self, \"ACCENT_COLOR\", line_color)",
            f"{body}use_origin = origin is not None",
            f"{body}try:",
            f"{body}    base = np.array(origin, dtype=float) if use_origin else ORIGIN",
            f"{body}except Exception:",
            f"{body}    base = ORIGIN",
            f"{body}width = max(step_value, abs(x1 - x0))",
            f"{body}height = max(step_value, abs(y1 - y0))",
            f"{body}line_group = VGroup()",
            f"{body}dot_group = VGroup()",
            f"{body}def _grid_pos(row, col, *_args, **_kw):",
            f"{body}    try:",
            f"{body}        rr = max(0, min(rows_value - 1, int(row)))",
            f"{body}    except Exception:",
            f"{body}        rr = 0",
            f"{body}    try:",
            f"{body}        cc = max(0, min(cols_value - 1, int(col)))",
            f"{body}    except Exception:",
            f"{body}        cc = 0",
            f"{body}    x = x0 + (x1 - x0) * (cc / max(1, cols_value - 1))",
            f"{body}    y = y0 + (y1 - y0) * (rr / max(1, rows_value - 1))",
            f"{body}    if use_origin:",
            f"{body}        return base + RIGHT * x + UP * y",
            f"{body}    return base + RIGHT * (x - (x0 + x1) / 2.0) + UP * (y - (y0 + y1) / 2.0)",
            f"{body}for c in range(cols_value):",
            f"{body}    start = _grid_pos(0, c)",
            f"{body}    end = _grid_pos(rows_value - 1, c)",
            f"{body}    line_group.add(Line(start, end, color=line_color, stroke_width=2.0))",
            f"{body}for r in range(rows_value):",
            f"{body}    start = _grid_pos(r, 0)",
            f"{body}    end = _grid_pos(r, cols_value - 1)",
            f"{body}    line_group.add(Line(start, end, color=line_color, stroke_width=2.0))",
            f"{body}for r in range(rows_value):",
            f"{body}    for c in range(cols_value):",
            f"{body}        dot_group.add(Dot(_grid_pos(r, c), radius=float(dot_radius or 0.035), color=dot_color))",
            f"{body}grid = VGroup(line_group, dot_group)",
            f"{body}grid.get_grid_pos = _grid_pos",
            f"{body}grid.grid_lines = line_group",
            f"{body}grid.grid_dots = dot_group",
            f"{body}grid.rows = rows_value",
            f"{body}grid.cols = cols_value",
            f"{body}grid.spacing = step_value",
            f"{body}grid.width_range = (x0, x1)",
            f"{body}grid.height_range = (y0, y1)",
            f"{body}return grid",
        ])
    if needs_get_single_line_sentence:
        helper_lines.extend([
            "",
            f"{indent}def get_single_line_sentence(self, index=None, text=None, sentence_map=None, sentences=None, font_size=18, color=None, **kwargs):",
            f"{body}raw = text",
            f"{body}source = sentence_map or sentences or kwargs.get(\"sentence_map\") or kwargs.get(\"sentences\") or getattr(self, \"sentence_map\", None) or getattr(self, \"sentences\", None)",
            f"{body}if raw in (None, \"\") and source is not None and index is not None:",
            f"{body}    try:",
            f"{body}        if isinstance(source, dict):",
            f"{body}            raw = source.get(index)",
            f"{body}            if raw in (None, \"\"):",
            f"{body}                raw = source.get(str(index))",
            f"{body}            if raw in (None, \"\"):",
            f"{body}                try:",
            f"{body}                    raw = source.get(int(index))",
            f"{body}                except Exception:",
            f"{body}                    raw = None",
            f"{body}        elif isinstance(source, (list, tuple)):",
            f"{body}            raw = source[max(0, int(index) - 1)]",
            f"{body}    except Exception:",
            f"{body}        raw = None",
            f"{body}if raw in (None, \"\"):",
            f"{body}    raw = index if index not in (None, \"\") else kwargs.get(\"label\", \"句子\")",
            f"{body}prefix = f\"{{index}}. \" if index not in (None, \"\") and not str(raw).lstrip().startswith(str(index)) else \"\"",
            f"{body}line = Text(prefix + str(raw), font_size=int(font_size or 18), color=color or getattr(self, \"PRIMARY_TEXT\", globals().get(\"BLACK\")))",
            f"{body}try:",
            f"{body}    line.scale_to_fit_width(min(float(getattr(config, \"frame_width\", 14.222)) - 1.2, max(2.0, line.width)))",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}return line",
        ])
    if semantic_create_helpers or semantic_get_helpers:
        label_overrides = {
            "create_checkmark": "Check",
            "create_check": "Check",
            "create_cross": "No",
            "create_sun": "Sun",
            "create_snowflake": "Snow",
            "create_truck": "Truck",
            "create_train": "Train",
            "create_ship": "Ship",
            "create_water": "Water",
            "create_ice": "Ice",
            "create_warning": "Warn",
            "get_sun": "Sun",
            "get_snowflake": "Snow",
            "get_truck": "Truck",
            "get_train": "Train",
            "get_ship": "Ship",
            "get_scale": "Scale",
            "get_container": "Container",
            "get_check": "Check",
            "get_cross": "No",
        }
        for helper_name in [*semantic_create_helpers, *semantic_get_helpers]:
            label = label_overrides.get(
                helper_name,
                helper_name.removeprefix("create_").removeprefix("get_").replace("_", " ").title() or "Icon",
            )
            helper_lines.extend([
                "",
                f"{indent}def {helper_name}(self, *args, size=0.8, color=None, **_kwargs):",
                f"{body}raise RuntimeError('MATHPI_MISSING_REAL_HELPER: {helper_name} requires real visual implementation for {label}; visible fallback disabled')",
            ])
    if needs_get_folded_a:
        helper_lines.extend([
            "",
            f'{indent}def get_folded_A(self, angle=PI / 2):',
            f"{body}A = np.array([{point_literals['A']}], dtype=float)",
            f"{body}B = np.array([{point_literals['B']}], dtype=float)",
            f"{body}E = np.array([{point_literals['E']}], dtype=float)",
            f"{body}axis = B - E",
            f"{body}norm = np.linalg.norm(axis)",
            f"{body}if norm < 1e-9:",
            f"{body}    return A",
            f"{body}u = axis / norm",
            f"{body}v = A - E",
            f"{body}return E + v * np.cos(angle) + np.cross(u, v) * np.sin(angle) + u * np.dot(u, v) * (1 - np.cos(angle))",
        ])

    lines = code.splitlines()
    if helper_lines and any("np." in line for line in helper_lines) and not re.search(
        r"(?m)^\s*import\s+numpy\s+as\s+np\b", code
    ):
        insert_at = _module_alias_insert_index(code)
        lines[insert_at:insert_at] = ["import numpy as np"]
        if insert_at < end:
            end += 1
    lines[end:end] = helper_lines
    names = []
    if needs_layout_canvas:
        names.append("layout_canvas")
    if needs_layout_zones:
        names.append("layout_zones")
    if needs_zones_alias:
        names.append("zones")
    if needs_safe_text_box:
        names.append("safe_text_box")
    if needs_clamp_to_canvas:
        names.append("clamp_to_canvas")
    if needs_place_non_overlapping:
        names.append("place_non_overlapping")
    if needs_fit_to_canvas:
        names.append("fit_to_canvas")
    if needs_fit_to_width:
        names.append("fit_to_width")
    if needs_create_3d_label:
        names.append("create_3d_label")
    if needs_to_3d:
        names.append("to_3d")
    if needs_safe_formula:
        names.append("safe_formula")
    if needs_setup_scene:
        names.append("setup_scene")
    if needs_inline_math_text:
        names.append("inline_math_text")
    if needs_cjk_math_tex:
        names.append("cjk_math_tex")
    if needs_get_pt:
        names.append("get_pt")
    if needs_rotate_about_axis:
        names.append("rotate_about_axis")
    if needs_get_figure_parts:
        names.append("get_figure_parts")
    if needs_get_base_geometry:
        names.append("get_base_geometry")
    if needs_get_geometry_figure:
        names.append("get_geometry_figure")
    if needs_get_geometry_base:
        names.append("get_geometry_base")
    if needs_get_square_model:
        names.append("get_square_model")
    if needs_get_figure:
        names.append("get_figure")
    if needs_get_figures:
        names.append("get_figures")
    if needs_get_title:
        names.append("get_title")
    if needs_get_formula:
        names.append("get_formula")
    if needs_get_paraboloid:
        names.append("get_paraboloid")
    if needs_get_cube_elements:
        names.append("get_cube_elements")
    if needs_create_triangle_figure:
        names.append("create_triangle_figure")
    if needs_create_triangle_abc:
        names.append("create_triangle_abc")
    if needs_create_figure:
        names.append("create_figure")
    if needs_get_triangle_centers:
        names.append("get_triangle_centers")
    if needs_get_rhombus_geometry:
        names.append("get_rhombus_geometry")
    if needs_make_text:
        names.append("make_text")
    if needs_make_title:
        names.append("make_title")
    if needs_make_mixed_line:
        names.append("make_mixed_line")
    if needs_create_text:
        names.append("create_text")
    if needs_make_formula:
        names.append("make_formula")
    if needs_play_voiceover:
        names.append("play_voiceover")
    if needs_make_point_with_label:
        names.append("make_point_with_label")
    if needs_get_right_angle_mark:
        names.append("get_right_angle_mark")
    if needs_get_tick_mark:
        names.append("get_tick_mark")
    if needs_get_angle_arc:
        names.append("get_angle_arc")
    if needs_create_check_mark:
        names.append("create_check_mark")
    if needs_create_cargo_box:
        names.append("create_cargo_box")
    if needs_create_thermometer:
        names.append("create_thermometer")
    if needs_create_frozen_river:
        names.append("create_frozen_river")
    if needs_create_balance_scale:
        names.append("create_balance_scale")
    if needs_create_left_column:
        names.append("create_left_column")
    if needs_fg_color_alias:
        names.append("FG_COLOR")
    if needs_line_color_alias:
        names.append("LINE_COLOR")
    if needs_get_rope:
        names.append("get_rope")
    if needs_create_grid_visual:
        names.append("create_grid_visual")
    if needs_create_grid:
        names.append("create_grid")
    names.extend(semantic_create_helpers)
    if needs_get_single_line_sentence:
        names.append("get_single_line_sentence")
    names.extend(semantic_get_helpers)
    if needs_get_folded_a:
        names.append("get_folded_A")
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"BaseConfigScene运行期helper补全: {', '.join(names)}",
    )


def _fix_triangle_figure_tuple_helper_return(code: str) -> Tuple[Optional[str], str]:
    """Keep legacy create_triangle_figure unpackable while making it usable as a VGroup."""
    if (
        "def create_triangle_figure" not in code
        or "return fig, points" not in code
        or "_MathPiTriangleFigure" in code
    ):
        return None, ""

    lines = code.splitlines()
    changed = 0
    in_helper = False
    helper_indent = ""
    for index, line in enumerate(lines):
        match = re.match(
            r"^(?P<indent>\s*)def\s+create_triangle_figure\s*\(",
            line,
        )
        if match:
            in_helper = True
            helper_indent = match.group("indent")
            continue
        if in_helper:
            if line.strip() and not line.startswith(helper_indent + " "):
                in_helper = False
                helper_indent = ""
                continue
            return_match = re.match(r"^(?P<indent>\s*)return\s+fig\s*,\s*points\s*$", line)
            if not return_match:
                continue
            indent = return_match.group("indent")
            lines[index:index + 1] = [
                f"{indent}class _MathPiTriangleFigure(VGroup):",
                f"{indent}    def __init__(self, figure, centers):",
                f"{indent}        super().__init__(figure)",
                f"{indent}        self.triangle_centers = list(centers or [])",
                f"{indent}    def __iter__(self):",
                f"{indent}        return iter((self, self.triangle_centers))",
                f"{indent}return _MathPiTriangleFigure(fig, points)",
            ]
            changed += 1
            break
    if changed == 0:
        return None, ""
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "create_triangle_figure返回兼容修复: 1处",
    )


def _fix_unfiltered_self_mobjects_vgroup(code: str) -> Tuple[Optional[str], str]:
    """Filter self.mobjects splats before VGroup(), because VoiceoverScene may hold non-VMobjects."""
    if "VGroup(*self.mobjects" not in code:
        return None, ""

    pattern = re.compile(
        r"VGroup\(\*self\.mobjects(?P<slice>\[[^\]\n]+\])?\)"
    )
    count = 0

    def _replace(match: re.Match) -> str:
        nonlocal count
        count += 1
        source = f"self.mobjects{match.group('slice') or ''}"
        return f"VGroup(*[mob for mob in {source} if isinstance(mob, VMobject)])"

    modified = pattern.sub(_replace, code)
    if count and modified != code:
        return modified, f"self.mobjects VGroup过滤: {count}处"
    return None, ""


def _fix_tracker_remainder_waits(code: str) -> Tuple[Optional[str], str]:
    """把 tracker.duration 剩余补时改成最多 0.8 秒短尾巴。"""
    replacements = 0

    def _replace(match: re.Match) -> str:
        nonlocal replacements
        replacements += 1
        indent = match.group("indent")
        tracker = match.group("tracker")
        used = match.group("used").strip()
        return (
            f"{indent}tail = min(0.8, max(0.0, float({tracker}.duration) - ({used})))\n"
            f"{indent}if tail > 0:\n"
            f"{indent}    self.wait(tail)"
        )

    current = _TRACKER_REMAINDER_WAIT_MAX_RE.sub(_replace, code)
    current = _TRACKER_REMAINDER_WAIT_HELPER_RE.sub(_replace, current)
    if replacements and current != code:
        return current, f"配音剩余等待修复: {replacements}处"
    return None, ""


def _fix_tracker_time_remaining_calls(code: str) -> Tuple[Optional[str], str]:
    """VoiceoverTracker has duration, but not time_remaining()."""
    current, replacements = _TRACKER_TIME_REMAINING_RE.subn(
        "min(0.8, float(tracker.duration))",
        code,
    )
    current, attr_replacements = _TRACKER_TIME_REMAINING_ATTR_RE.subn(
        "min(0.8, float(tracker.duration))",
        current,
    )
    replacements += attr_replacements
    if replacements and current != code:
        return current, f"配音剩余时间兼容修复: {replacements}处"
    return None, ""


def _fix_tracker_duration_direct_bindings(code: str) -> Tuple[Optional[str], str]:
    """Keep voiceover animations short instead of binding them to full narration."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.With):
            continue
        tracker_name = _voiceover_tracker_name(node, code)
        if not tracker_name:
            continue
        for statement in node.body:
            for child in ast.walk(statement):
                if not isinstance(child, ast.Call):
                    continue
                method = _self_call_method_name(child)
                if method == "play":
                    for keyword in child.keywords:
                        if keyword.arg != "run_time":
                            continue
                        if not _is_tracker_duration_attr(keyword.value, tracker_name):
                            continue
                        span = _source_span_for_node(
                            keyword.value,
                            lines,
                            line_offsets,
                        )
                        if span:
                            replacements.append(
                                (span[0], span[1], f"min(1.2, float({tracker_name}.duration))")
                            )
                elif method == "wait" and len(child.args) == 1:
                    wait_arg = child.args[0]
                    if not _is_tracker_duration_attr(wait_arg, tracker_name):
                        continue
                    span = _source_span_for_node(wait_arg, lines, line_offsets)
                    if span:
                        replacements.append(
                            (span[0], span[1], f"min(0.8, float({tracker_name}.duration))")
                        )

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        current = current[:start] + replacement + current[end:]
    return current, f"配音tracker.duration直绑修复: {len(replacements)}处"


def _is_tracker_duration_attr(node: ast.AST, tracker_name: str) -> bool:
    return (
        isinstance(node, ast.Attribute)
        and node.attr == "duration"
        and isinstance(node.value, ast.Name)
        and node.value.id == tracker_name
    )


def _fix_direction_alias_constants(code: str) -> Tuple[Optional[str], str]:
    """Repair non-Manim direction aliases such as TOP/BOTTOM/CENTER."""
    if "TOP" not in code and "BOTTOM" not in code and "CENTER" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    alias_map = {"TOP": "UP", "BOTTOM": "DOWN", "CENTER": "ORIGIN"}
    lines, line_offsets = _line_offsets(code)
    replacements: list[tuple[int, int, str, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Load)
            and node.id in alias_map
        ):
            continue
        span = _source_span_for_node(node, lines, line_offsets)
        if not span:
            continue
        replacements.append((span[0], span[1], alias_map[node.id], node.id))

    if not replacements:
        return None, ""
    current = code
    changed: list[str] = []
    for start, end, replacement, original in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        if current[start:end] != original:
            continue
        current = current[:start] + replacement + current[end:]
        changed.append(f"{original}→{replacement}")
    if current == code:
        return None, ""
    return current, f"方向常量别名修复: {', '.join(reversed(changed))}"


def _fix_number_axes_alias(code: str) -> Tuple[Optional[str], str]:
    """Repair hallucinated NumberAxes(), which is not part of Manim CE."""
    if "NumberAxes" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    replacements: list[tuple[int, int]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "NumberAxes"
        ):
            continue
        span = _source_span_for_node(node.func, lines, line_offsets)
        if span:
            replacements.append(span)

    if not replacements:
        return None, ""

    current = code
    for start, end in sorted(replacements, reverse=True):
        current = current[:start] + "Axes" + current[end:]
    return current, f"NumberAxes别名修复: {len(replacements)}处"


def _fix_voiceover_wait_method_collision(code: str) -> Tuple[Optional[str], str]:
    """Avoid overriding manim-voiceover's no-arg wait_for_voiceover().

    GPT-style outputs sometimes add a helper named wait_for_voiceover(self,
    tracker, used_time). VoiceoverScene.voiceover() calls
    self.wait_for_voiceover() with no args on context exit, so the helper
    shadows the library method and every voiceover scene fails at runtime.
    """
    matches = list(_CUSTOM_WAIT_FOR_VOICEOVER_RE.finditer(code))
    if not matches:
        return None, ""

    modified = _CUSTOM_WAIT_FOR_VOICEOVER_RE.sub(
        r"\g<indent>def wait_for_voiceover_remaining(self,\g<args>):",
        code,
    )
    modified, call_count = re.subn(
        r"self\.wait_for_voiceover\(\s*(?=[^)\s])",
        "self.wait_for_voiceover_remaining(",
        modified,
    )
    if modified != code:
        return (
            modified,
            f"voiceover等待方法冲突修复: {len(matches)}处定义, {call_count}处调用",
        )
    return None, ""


def _fix_missing_voiceover_scene_import(code: str) -> Tuple[Optional[str], str]:
    if not _VOICEOVER_SCENE_BASE_RE.search(code):
        return None, ""
    if (
        _VOICEOVER_SCENE_IMPORT_RE.search(code)
        or _VOICEOVER_SCENE_LOCAL_DEF_RE.search(code)
    ):
        return None, ""

    lines = code.splitlines()
    insert_at = _voiceover_import_insert_index(lines)
    updated = [
        *lines[:insert_at],
        "from manim_voiceover import VoiceoverScene",
        *lines[insert_at:],
    ]
    return "\n".join(updated) + ("\n" if code.endswith("\n") else ""), "VoiceoverScene导入补全"


def _voiceover_import_insert_index(lines: list[str]) -> int:
    for index, line in enumerate(lines):
        if re.match(r"^\s*from\s+manim\s+import\s+\*", line):
            return index + 1

    insert_at = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if re.match(r"^\s*(?:from|import)\s+", line):
            insert_at = index + 1
            continue
        break
    return insert_at


def _fix_init_voiceover_call(code: str) -> Tuple[Optional[str], str]:
    if (
        "init_voiceover" not in code
        and "set_voiceover_service" not in code
        and "set_tts_service" not in code
    ):
        return None, ""
    fixed, changed = _INIT_VOICEOVER_CALL_RE.subn(
        "self.set_speech_service(",
        code,
    )
    if changed == 0:
        return None, ""
    return fixed, f"Voiceover服务初始化API修复: {changed}处"


def _class_base_name(base: ast.expr) -> str:
    if isinstance(base, ast.Name):
        return base.id
    if isinstance(base, ast.Attribute):
        return base.attr
    return ""


def _fix_scene_setup_calls_to_setup_layout(code: str) -> Tuple[Optional[str], str]:
    if "self.setup()" not in code or "def setup_layout" not in code:
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    has_setup_layout = _find_base_config_method_index(
        lines,
        class_start=class_start,
        class_end=class_end,
        body_indent=body_indent,
        method_name="setup_layout",
    ) is not None
    has_setup = _find_base_config_method_index(
        lines,
        class_start=class_start,
        class_end=class_end,
        body_indent=body_indent,
        method_name="setup",
    ) is not None
    if not has_setup_layout or has_setup:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    rewrite_lines: set[int] = set()
    for class_node in tree.body:
        if not isinstance(class_node, ast.ClassDef):
            continue
        if not any(_class_base_name(base) == "BaseConfigScene" for base in class_node.bases):
            continue
        for member in class_node.body:
            if not isinstance(member, ast.FunctionDef) or member.name != "construct":
                continue
            for statement in member.body:
                if (
                    isinstance(statement, ast.Expr)
                    and isinstance(statement.value, ast.Call)
                    and not statement.value.args
                    and not statement.value.keywords
                    and _is_self_method_expr(statement, "setup")
                ):
                    rewrite_lines.add(statement.lineno)

    if not rewrite_lines:
        return None, ""

    changed = 0
    for line_no in sorted(rewrite_lines):
        index = line_no - 1
        if index < 0 or index >= len(lines):
            continue
        new_line = re.sub(r"\bself\.setup\(\)", "self.setup_layout()", lines[index], count=1)
        if new_line != lines[index]:
            lines[index] = new_line
            changed += 1

    if changed == 0:
        return None, ""
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"setup_layout入口修复: {changed}处",
    )


def _fix_setup_layout_call_args(code: str) -> Tuple[Optional[str], str]:
    if "self.setup_layout(" not in code:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    edits: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "setup_layout":
            continue
        if not isinstance(node.func.value, ast.Name) or node.func.value.id != "self":
            continue
        if not node.args and not node.keywords:
            continue
        call_span = _positioned_node_span(node, code)
        if not call_span:
            continue
        edits.append((call_span[0], call_span[1], "self.setup_layout()"))

    if not edits:
        return None, ""

    current = code
    for start, end, replacement in sorted(edits, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"setup_layout参数兼容修复: {len(edits)}处"


def _fix_setup_scene_calls_to_setup_layout(code: str) -> Tuple[Optional[str], str]:
    if "self.setup_scene(" not in code or "def setup_layout" not in code:
        return None, ""
    if "def setup_scene" in code:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    edits: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "setup_scene":
            continue
        if not isinstance(node.func.value, ast.Name) or node.func.value.id != "self":
            continue
        call_span = _positioned_node_span(node, code)
        if not call_span:
            continue
        edits.append((call_span[0], call_span[1], "self.setup_layout()"))

    if not edits:
        return None, ""

    current = code
    for start, end, replacement in sorted(edits, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"setup_scene入口兼容修复: {len(edits)}处"


_BARE_SELF_GEOMETRY_HELPERS = {
    "get_pt",
    "make_title",
    "rotate_about_axis",
}


def _fix_bare_geometry_helper_calls(code: str) -> Tuple[Optional[str], str]:
    """Rewrite bare helper calls inside Scene methods to self.helper(...)."""
    if not any(f"{name}(" in code for name in _BARE_SELF_GEOMETRY_HELPERS):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    edits: list[tuple[int, int, str]] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.class_depth = 0
            self.method_depth = 0

        def visit_ClassDef(self, node: ast.ClassDef):
            self.class_depth += 1
            self.generic_visit(node)
            self.class_depth -= 1

        def visit_FunctionDef(self, node: ast.FunctionDef):
            in_method = self.class_depth > 0
            if in_method:
                self.method_depth += 1
            self.generic_visit(node)
            if in_method:
                self.method_depth -= 1

        def visit_Call(self, node: ast.Call):
            if (
                self.method_depth > 0
                and isinstance(node.func, ast.Name)
                and node.func.id in _BARE_SELF_GEOMETRY_HELPERS
            ):
                span = _positioned_node_span(node.func, code)
                if span:
                    edits.append((span[0], span[1], f"self.{node.func.id}"))
            self.generic_visit(node)

    Visitor().visit(tree)
    if not edits:
        return None, ""

    current = code
    for start, end, replacement in sorted(edits, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    helper_names = sorted({replacement.removeprefix("self.") for _, _, replacement in edits})
    return current, f"裸几何helper调用修复: {','.join(helper_names)} {len(edits)}处"


def _fix_brace_get_text_cjk_to_text(code: str) -> Tuple[Optional[str], str]:
    """Brace.get_text uses Tex; CJK labels must be plain Text to avoid LaTeX Unicode errors."""
    if ".get_text(" not in code or not _CHINESE_RE.search(code):
        return None, ""

    count = 0

    def _replace(match: re.Match) -> str:
        nonlocal count
        count += 1
        brace = match.group("brace")
        text = match.group("text")
        return (
            f"Text({text!r}, font_size=24)"
            f'.next_to({brace}, getattr({brace}, "direction", UP), buff=0.12)'
        )

    modified = _BRACE_GET_TEXT_CJK_RE.sub(_replace, code)
    if count and modified != code:
        return modified, f"Brace中文标签Text化: {count}处"
    return None, ""


def _construct_needs_setup_layout(member: ast.FunctionDef) -> bool:
    for node in ast.walk(member):
        if not isinstance(node, ast.Attribute):
            continue
        if not isinstance(node.value, ast.Name) or node.value.id != "self":
            continue
        if (
            node.attr in _SETUP_LAYOUT_REQUIRED_SELF_METHODS
            or node.attr in _SETUP_LAYOUT_REQUIRED_SELF_ATTRS
        ):
            return True
    return False


def _first_setup_layout_usage_line(member: ast.FunctionDef) -> int | None:
    line_no: int | None = None
    for node in ast.walk(member):
        if not isinstance(node, ast.Attribute):
            continue
        if not isinstance(node.value, ast.Name) or node.value.id != "self":
            continue
        if not (
            node.attr in _SETUP_LAYOUT_REQUIRED_SELF_METHODS
            or node.attr in _SETUP_LAYOUT_REQUIRED_SELF_ATTRS
        ):
            continue
        current = getattr(node, "lineno", None)
        if current is None:
            continue
        line_no = current if line_no is None else min(line_no, current)
    return line_no


def _top_level_setup_layout_line(member: ast.FunctionDef) -> int | None:
    for statement in member.body:
        if _is_self_method_expr(statement, "setup_layout"):
            return statement.lineno
    return None


def _construct_body_insert_index(
    member: ast.FunctionDef,
    lines: list[str],
) -> tuple[int, str] | None:
    if member.lineno < 1 or member.lineno > len(lines):
        return None
    def_line = lines[member.lineno - 1]
    def_indent = def_line[: len(def_line) - len(def_line.lstrip())]
    body_indent = def_indent + "    "
    insert_after_line = member.lineno

    if member.body:
        first_stmt = member.body[0]
        first_line = getattr(first_stmt, "lineno", None)
        if isinstance(first_line, int) and 1 <= first_line <= len(lines):
            first_source = lines[first_line - 1]
            inferred = first_source[: len(first_source) - len(first_source.lstrip())]
            if inferred:
                body_indent = inferred
        if (
            isinstance(first_stmt, ast.Expr)
            and isinstance(first_stmt.value, ast.Constant)
            and isinstance(first_stmt.value.value, str)
        ):
            insert_after_line = getattr(first_stmt, "end_lineno", first_stmt.lineno)

    return insert_after_line, body_indent


def _ensure_construct_setup_layout_entry(code: str) -> Tuple[Optional[str], str]:
    """Insert setup_layout() before generated scenes touch layout or voiceover APIs."""
    if "def setup_layout" not in code or "BaseConfigScene" not in code:
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    has_setup_layout = _find_base_config_method_index(
        lines,
        class_start=class_start,
        class_end=class_end,
        body_indent=body_indent,
        method_name="setup_layout",
    ) is not None
    if not has_setup_layout:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    class_nodes = [
        node for node in tree.body if isinstance(node, ast.ClassDef)
    ]
    base_config_scene_names = {"BaseConfigScene"}
    changed = True
    while changed:
        changed = False
        for class_node in class_nodes:
            if class_node.name in base_config_scene_names:
                continue
            if not any(
                _class_base_name(base) in base_config_scene_names
                for base in class_node.bases
            ):
                continue
            base_config_scene_names.add(class_node.name)
            changed = True

    insertions: list[tuple[int, str]] = []
    for class_node in class_nodes:
        if not isinstance(class_node, ast.ClassDef):
            continue
        if not any(
            _class_base_name(base) in base_config_scene_names
            for base in class_node.bases
        ):
            continue
        for member in class_node.body:
            if not isinstance(member, ast.FunctionDef) or member.name != "construct":
                continue
            if not _construct_needs_setup_layout(member):
                continue
            first_usage_line = _first_setup_layout_usage_line(member)
            setup_line = _top_level_setup_layout_line(member)
            if (
                setup_line is not None
                and first_usage_line is not None
                and setup_line <= first_usage_line
            ):
                continue
            insertion = _construct_body_insert_index(member, lines)
            if insertion is None:
                continue
            insert_after_line, indent = insertion
            insertions.append((insert_after_line, f"{indent}self.setup_layout()"))

    if not insertions:
        return None, ""

    for insert_after_line, line in sorted(insertions, key=lambda item: item[0], reverse=True):
        lines.insert(insert_after_line, line)
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"setup_layout入口补全: {len(insertions)}处",
    )


def _ensure_base_config_setup_layout_auto_entry(code: str) -> Tuple[Optional[str], str]:
    """Make Manim call setup_layout() before construct() for generated BaseConfigScene."""
    if "def setup_layout" not in code or "class BaseConfigScene" not in code:
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    setup_layout_index = _find_base_config_method_index(
        lines,
        class_start=class_start,
        class_end=class_end,
        body_indent=body_indent,
        method_name="setup_layout",
    )
    if setup_layout_index is None:
        return None, ""

    setup_index = _find_base_config_method_index(
        lines,
        class_start=class_start,
        class_end=class_end,
        body_indent=body_indent,
        method_name="setup",
    )
    method_body = body_indent + "    "
    if setup_index is None:
        insert_at = setup_layout_index
        method_lines = [
            f"{body_indent}def setup(self):",
            f"{method_body}try:",
            f"{method_body}    super().setup()",
            f"{method_body}except Exception:",
            f"{method_body}    pass",
            f"{method_body}self.setup_layout()",
            "",
        ]
        lines[insert_at:insert_at] = method_lines
        return (
            "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
            "setup_layout自动入口补全: setup",
        )

    setup_end = _find_indented_block_end(
        lines,
        start_index=setup_index + 1,
        parent_indent_len=len(body_indent),
    )
    setup_body = "\n".join(lines[setup_index:setup_end])
    if "setup_layout(" in setup_body:
        return None, ""

    insert_at = setup_index + 1
    for offset in range(setup_index + 1, setup_end):
        if re.search(r"\bsuper\(\)\.setup\s*\(", lines[offset]):
            insert_at = offset + 1
            break
    lines.insert(insert_at, f"{method_body}self.setup_layout()")
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "setup_layout自动入口补全: existing setup",
    )


_DIRECT_LAYOUT_ZONE_ATTR_RE = re.compile(
    r"\bself\.(?P<name>"
    r"title_zone|content_zone|formula_zone|footer_zone|caption_zone|"
    r"diagram_zone|top_zone|bottom_zone|left_zone|right_zone"
    r")\b(?!\s*\[)"
)
_DIRECT_LAYOUT_ZONE_MOVE_TO_RE = re.compile(
    r"\.move_to\(\s*self\.(?P<name>"
    r"title_zone|content_zone|formula_zone|footer_zone|caption_zone|"
    r"diagram_zone|top_zone|bottom_zone|left_zone|right_zone"
    r")\s*\)"
)


def _rewrite_direct_layout_zone_move_to(code: str) -> Tuple[str, int]:
    def _replace(match: re.Match[str]) -> str:
        name = match.group("name")
        return (
            f'.move_to(self._layout_zone_vector("{name}", '
            f'getattr(self, "{name}", None)))'
        )

    return _DIRECT_LAYOUT_ZONE_MOVE_TO_RE.subn(_replace, code)


def _ensure_layout_zone_vector_attrs(code: str) -> Tuple[Optional[str], str]:
    """Give direct self.title_zone-style attributes center-point fallbacks."""
    if "class BaseConfigScene" not in code or "def setup_layout" not in code:
        return None, ""
    needed = {
        match.group("name")
        for match in _DIRECT_LAYOUT_ZONE_ATTR_RE.finditer(code)
    }
    if not needed or "def _ensure_layout_zone_vectors" in code:
        return None, ""

    code, rewrite_count = _rewrite_direct_layout_zone_move_to(code)
    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    setup_layout_index = _find_base_config_method_index(
        lines,
        class_start=class_start,
        class_end=class_end,
        body_indent=body_indent,
        method_name="setup_layout",
    )
    if setup_layout_index is None:
        return None, ""
    setup_end = _find_indented_block_end(
        lines,
        start_index=setup_layout_index + 1,
        parent_indent_len=len(body_indent),
    )
    method_body = body_indent + "    "
    setup_body = "\n".join(lines[setup_layout_index:setup_end])
    if "_ensure_layout_zone_vectors(" not in setup_body:
        lines.insert(setup_end, f"{method_body}self._ensure_layout_zone_vectors()")
        setup_end += 1

    method_lines = [
        "",
        f"{body_indent}def _layout_zone_center(self, area):",
        f"{method_body}try:",
        f"{method_body}    box = self.layout_canvas(area)",
        f"{method_body}    if isinstance(box, dict):",
        f"{method_body}        return np.array(box.get(\"center\", ORIGIN), dtype=float)",
        f"{method_body}except Exception:",
        f"{method_body}    pass",
        f"{method_body}return np.array(ORIGIN, dtype=float)",
        "",
        f"{body_indent}def _layout_zone_vector(self, area, value=None):",
        f"{method_body}if isinstance(value, dict):",
        f"{method_body}    if \"center\" in value:",
        f"{method_body}        try:",
        f"{method_body}            return np.array(value.get(\"center\", ORIGIN), dtype=float)",
        f"{method_body}        except Exception:",
        f"{method_body}            pass",
        f"{method_body}    return self._layout_zone_center(area)",
        f"{method_body}try:",
        f"{method_body}    arr = np.array(value, dtype=float)",
        f"{method_body}    if arr.shape == (3,):",
        f"{method_body}        return arr",
        f"{method_body}except Exception:",
        f"{method_body}    pass",
        f"{method_body}return self._layout_zone_center(area)",
        "",
        f"{body_indent}def _ensure_layout_zone_vectors(self):",
        f"{method_body}def _center(area):",
        f"{method_body}    try:",
        f"{method_body}        box = self.layout_canvas(area)",
        f"{method_body}        if isinstance(box, dict):",
        f"{method_body}            return np.array(box.get(\"center\", ORIGIN), dtype=float)",
        f"{method_body}    except Exception:",
        f"{method_body}        pass",
        f"{method_body}    return np.array(ORIGIN, dtype=float)",
        f"{method_body}mapping = {{",
        f"{method_body}    \"title_zone\": \"title_zone\",",
        f"{method_body}    \"content_zone\": \"content_zone\",",
        f"{method_body}    \"formula_zone\": \"formula_zone\",",
        f"{method_body}    \"footer_zone\": \"footer_zone\",",
        f"{method_body}    \"caption_zone\": \"caption_zone\",",
        f"{method_body}    \"diagram_zone\": \"diagram_zone\",",
        f"{method_body}    \"top_zone\": \"top_zone\",",
        f"{method_body}    \"bottom_zone\": \"bottom_zone\",",
        f"{method_body}    \"left_zone\": \"left_zone\",",
        f"{method_body}    \"right_zone\": \"right_zone\",",
        f"{method_body}}}",
        f"{method_body}for attr, area in mapping.items():",
        f"{method_body}    if not hasattr(self, attr):",
        f"{method_body}        setattr(self, attr, _center(area))",
    ]
    lines[setup_end:setup_end] = method_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"layout zone向量属性兜底: {max(1, rewrite_count)}处",
    )


def _fix_unsupported_gtts_voiceover_provider(code: str) -> Tuple[Optional[str], str]:
    """Replace gTTS demo provider with the project TTS contract."""
    if not any(
        token in code
        for token in (
            "GTTSService",
            "GTSService",
            "manim_voiceover.services.gtts",
            "RecorderService",
            "manim_voiceover.services.recorder",
            "StubService",
            "manim_voiceover.services.stub",
            "DummyService",
            "manim_voiceover.services.dummy",
        )
    ):
        return None, ""

    current, import_count = _GTTS_PROVIDER_IMPORT_RE.subn(
        r"\g<indent>from custom_services.system_tts_service import create_system_tts_service",
        code,
    )
    current, call_count = _GTTS_PROVIDER_CALL_RE.subn(
        "create_system_tts_service()",
        current,
    )
    current, recorder_import_count = _RECORDER_PROVIDER_IMPORT_RE.subn(
        r"\g<indent>from custom_services.system_tts_service import create_system_tts_service",
        current,
    )
    current, recorder_call_count = _RECORDER_PROVIDER_CALL_RE.subn(
        "create_system_tts_service()",
        current,
    )
    current, stub_import_count = _STUB_PROVIDER_IMPORT_RE.subn(
        r"\g<indent>from custom_services.system_tts_service import create_system_tts_service",
        current,
    )
    current, stub_call_count = _STUB_PROVIDER_CALL_RE.subn(
        "create_system_tts_service()",
        current,
    )
    current, dummy_import_count = _DUMMY_PROVIDER_IMPORT_RE.subn(
        r"\g<indent>from custom_services.system_tts_service import create_system_tts_service",
        current,
    )
    current, dummy_call_count = _DUMMY_PROVIDER_CALL_RE.subn(
        "create_system_tts_service()",
        current,
    )

    changed = (
        import_count
        + call_count
        + recorder_import_count
        + recorder_call_count
        + stub_import_count
        + stub_call_count
        + dummy_import_count
        + dummy_call_count
    )
    if changed == 0 or current == code:
        return None, ""
    return current, f"gTTS兜底服务合同修复: {changed}处"


def _fix_missing_title_y_attr(code: str) -> Tuple[Optional[str], str]:
    """Replace hallucinated self.title_y with a safe title baseline."""
    if "self.title_y" not in code:
        return None, ""
    if re.search(r"\bself\.title_y\s*=", code):
        return None, ""
    fixed, count = _TITLE_Y_ATTR_RE.subn("3.2", code)
    if count == 0 or fixed == code:
        return None, ""
    return fixed, f"title_y标题基线兜底: {count}处"


def _fix_legacy_base_speech_service_import(code: str) -> Tuple[Optional[str], str]:
    """Map obsolete manim-voiceover BaseSpeechService imports to SpeechService."""
    if "BaseSpeechService" not in code:
        return None, ""

    current, import_count = _BASE_SPEECH_SERVICE_IMPORT_RE.subn(
        r"\g<indent>from manim_voiceover.services.base import SpeechService",
        code,
    )
    current, ref_count = re.subn(r"\bBaseSpeechService\b", "SpeechService", current)
    if "SpeechService" in current and not re.search(
        r"(?m)^\s*from\s+manim_voiceover\.services\.base\s+import\s+SpeechService\b",
        current,
    ):
        lines = current.splitlines()
        insert_at = _module_alias_insert_index(current)
        lines.insert(insert_at, "from manim_voiceover.services.base import SpeechService")
        current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
        import_count += 1

    changed = import_count + ref_count
    if changed == 0 or current == code:
        return None, ""
    return current, f"Voiceover旧BaseSpeechService导入修复: {changed}处"


def _fix_pure_latex_markers_to_text(code: str) -> Tuple[Optional[str], str]:
    """Render standalone check/cross markers as Text instead of fragile TeX."""
    if "\\checkmark" not in code and "\\times" not in code:
        return None, ""

    marker_map = {
        r"\checkmark": "✓",
        r"\times": "×",
    }

    def _replace(match: re.Match) -> str:
        marker = marker_map.get(match.group("marker"), match.group("marker"))
        return f'Text("{marker}"{match.group("tail")}'

    pattern = re.compile(
        r"\b(?:Tex|MathTex)\(\s*(?:[rRuUbB]*)"
        r"(?P<quote>['\"])(?P<marker>\\(?:checkmark|times))(?P=quote)"
        r"(?P<tail>\s*(?:,|\)))"
    )
    current, changed = pattern.subn(_replace, code)
    if changed == 0 or current == code:
        return None, ""
    return current, f"纯对错符号Tex降级Text: {changed}处"


def _choice_factory_helper_source(name: str) -> str:
    if name == "make_check":
        return (
            "def make_check(center=None, size=0.8, color=None, **_kwargs):\n"
            "    mark_color = color or globals().get(\"GREEN\", globals().get(\"WHITE\", \"#FFFFFF\"))\n"
            "    s = float(size or 0.8)\n"
            "    stroke = max(2.0, 5.5 * s)\n"
            "    left = Line(LEFT * 0.36 + DOWN * 0.02, LEFT * 0.08 + DOWN * 0.28, color=mark_color, stroke_width=stroke)\n"
            "    right = Line(LEFT * 0.08 + DOWN * 0.28, RIGHT * 0.42 + UP * 0.30, color=mark_color, stroke_width=stroke)\n"
            "    mark = VGroup(left, right).scale(s)\n"
            "    if center is not None:\n"
            "        mark.move_to(center)\n"
            "    return mark"
        )
    return (
        "def make_cross(center=None, size=0.8, color=None, **_kwargs):\n"
        "    mark_color = color or globals().get(\"RED\", globals().get(\"WHITE\", \"#FFFFFF\"))\n"
        "    s = float(size or 0.8)\n"
        "    stroke = max(2.0, 5.0 * s)\n"
        "    line1 = Line(LEFT * 0.36 + DOWN * 0.36, RIGHT * 0.36 + UP * 0.36, color=mark_color, stroke_width=stroke)\n"
        "    line2 = Line(LEFT * 0.36 + UP * 0.36, RIGHT * 0.36 + DOWN * 0.36, color=mark_color, stroke_width=stroke)\n"
        "    mark = VGroup(line1, line2).scale(s)\n"
        "    if center is not None:\n"
        "        mark.move_to(center)\n"
        "    return mark"
    )


def _fix_module_choice_factory_signatures(code: str) -> Tuple[Optional[str], str]:
    """Make module-level make_check/make_cross helpers accept target/size/color."""
    if "make_check(" not in code and "make_cross(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef) or node.name not in {"make_check", "make_cross"}:
            continue
        args = node.args
        accepts_varargs = args.vararg is not None or args.kwarg is not None
        arg_names = [arg.arg for arg in args.args]
        if accepts_varargs and {"center", "size", "color"}.issubset(arg_names):
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        replacements.append((span[0], span[1], _choice_factory_helper_source(node.name)))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"勾叉工厂函数签名兼容: {len(replacements)}处"


def _inject_system_tts_available_flag(code: str) -> Tuple[Optional[str], str]:
    """Generated code may guard project TTS with an undefined SYSTEM_TTS_AVAILABLE flag."""
    if "SYSTEM_TTS_AVAILABLE" not in code:
        return None, ""
    if re.search(r"(?m)^\s*SYSTEM_TTS_AVAILABLE\s*=", code):
        return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    lines.insert(insert_at, "SYSTEM_TTS_AVAILABLE = True")
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "系统TTS可用标记补全",
    )


def _fix_bare_start_voiceover_calls(code: str) -> Tuple[Optional[str], str]:
    """Rewrite hallucinated start/end voiceover API calls into voiceover blocks."""
    if "self.start_voiceover(" not in code:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        def _replace(match: re.Match) -> str:
            indent = match.group("indent")
            args = match.group("args").strip()
            return (
                f"{indent}with self.voiceover({args}) as tracker:\n"
                f"{indent}    self.wait(min(float(getattr(tracker, \"duration\", 0.0)), 0.8))"
            )

        fixed, changed = _BARE_START_VOICEOVER_RE.subn(_replace, code)
        if changed == 0 or fixed == code:
            return None, ""
        return fixed, f"start_voiceover裸调用修复: {changed}处"

    lines = code.splitlines()
    replacements: list[tuple[int, int, list[str]]] = []
    changed = 0

    for scope in [
        node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]:
        statements = list(scope.body)
        used_end_indices: set[int] = set()
        for index, statement in enumerate(statements):
            call = _self_voiceover_api_statement_call(statement, "start_voiceover")
            if call is None:
                continue
            end_index = None
            for candidate_index in range(index + 1, len(statements)):
                if candidate_index in used_end_indices:
                    continue
                if _self_voiceover_api_statement_call(
                    statements[candidate_index],
                    "end_voiceover",
                ) is not None:
                    end_index = candidate_index
                    used_end_indices.add(candidate_index)
                    break

            start_line = getattr(statement, "lineno", None)
            start_end_line = getattr(statement, "end_lineno", None)
            if not start_line or not start_end_line:
                continue
            indent = re.match(r"^(\s*)", lines[start_line - 1]).group(1)
            args = _voiceover_call_args_source(call, code)
            header = f"{indent}with self.voiceover({args}) as tracker:"

            if end_index is None:
                replacement = [
                    header,
                    f"{indent}    self.wait(min(float(getattr(tracker, \"duration\", 0.0)), 0.8))",
                ]
                replacements.append((start_line - 1, start_end_line, replacement))
                changed += 1
                continue

            end_statement = statements[end_index]
            end_line = getattr(end_statement, "lineno", None)
            end_end_line = getattr(end_statement, "end_lineno", None)
            if not end_line or not end_end_line or end_line <= start_end_line:
                continue
            body_lines = lines[start_end_line:end_line - 1]
            indented_body = [
                (f"{indent}    {line[len(indent):]}" if line.startswith(indent) else f"{indent}    {line}")
                if line.strip()
                else line
                for line in body_lines
            ]
            if not any(line.strip() for line in indented_body):
                indented_body = [
                    f"{indent}    self.wait(min(float(getattr(tracker, \"duration\", 0.0)), 0.8))"
                ]
            replacements.append((start_line - 1, end_end_line, [header, *indented_body]))
            changed += 1

    if not replacements:
        return None, ""

    for start, end, replacement in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        lines[start:end] = replacement
    fixed = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    if fixed == code:
        return None, ""
    return fixed, f"start_voiceover裸调用修复: {changed}处"


def _fix_bare_voiceover_calls(code: str) -> Tuple[Optional[str], str]:
    """Rewrite bare self.voiceover(...) calls into real voiceover blocks."""
    if "self.voiceover(" not in code:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines()
    replacements: list[tuple[int, int, list[str]]] = []
    changed = 0

    for scope in [
        node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]:
        statements = list(scope.body)
        for index, statement in enumerate(statements):
            call = _self_voiceover_api_statement_call(statement, "voiceover")
            if call is None:
                continue

            start_line = getattr(statement, "lineno", None)
            start_end_line = getattr(statement, "end_lineno", None)
            if not start_line or not start_end_line:
                continue
            indent = re.match(r"^(\s*)", lines[start_line - 1]).group(1)
            args = _voiceover_call_args_source(call, code)
            header = f"{indent}with self.voiceover({args}) as tracker:"

            stop_exclusive = None
            for candidate in statements[index + 1:]:
                if (
                    _self_voiceover_api_statement_call(candidate, "voiceover") is not None
                    or _self_voiceover_api_statement_call(candidate, "start_voiceover") is not None
                    or _self_voiceover_api_statement_call(candidate, "end_voiceover") is not None
                    or _self_voiceover_api_statement_call(candidate, "next_section") is not None
                ):
                    candidate_line = getattr(candidate, "lineno", None)
                    if candidate_line:
                        stop_exclusive = candidate_line - 1
                    break
            if stop_exclusive is None:
                last_statement = statements[-1] if statements else statement
                stop_exclusive = getattr(last_statement, "end_lineno", start_end_line)

            body_lines = list(lines[start_end_line:stop_exclusive])
            while body_lines and (
                not body_lines[-1].strip() or body_lines[-1].lstrip().startswith("#")
            ):
                body_lines.pop()
            indented_body = [
                (f"{indent}    {line[len(indent):]}" if line.startswith(indent) else f"{indent}    {line}")
                if line.strip()
                else line
                for line in body_lines
            ]
            if not any(line.strip() for line in indented_body):
                indented_body = [
                    f"{indent}    self.wait(min(float(getattr(tracker, \"duration\", 0.0)), 0.8))"
                ]
            replacements.append((start_line - 1, stop_exclusive, [header, *indented_body]))
            changed += 1

    if not replacements:
        return None, ""

    for start, end, replacement in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        lines[start:end] = replacement
    fixed = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    if fixed == code:
        return None, ""
    return fixed, f"voiceover裸调用修复: {changed}处"


def _self_voiceover_api_statement_call(
    statement: ast.AST,
    attr: str,
) -> ast.Call | None:
    if not isinstance(statement, ast.Expr):
        return None
    call = statement.value
    if not isinstance(call, ast.Call):
        return None
    func = call.func
    if (
        isinstance(func, ast.Attribute)
        and func.attr == attr
        and isinstance(func.value, ast.Name)
        and func.value.id == "self"
    ):
        return call
    return None


def _voiceover_call_args_source(call: ast.Call, code: str) -> str:
    parts: list[str] = []
    for arg in call.args:
        parts.append(ast.get_source_segment(code, arg) or ast.unparse(arg))
    for keyword in call.keywords:
        value = ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)
        if keyword.arg is None:
            parts.append(f"**{value}")
        else:
            parts.append(f"{keyword.arg}={value}")
    return ", ".join(parts) if parts else 'text=""'


def _fix_nested_custom_services_import(code: str) -> Tuple[Optional[str], str]:
    """Expose project custom_services via the mounted top-level package."""
    wrong_prefix = "manim_voiceover.services.custom_services."
    if wrong_prefix not in code:
        return None, ""
    fixed = code.replace(wrong_prefix, "custom_services.")
    changed = code.count(wrong_prefix)
    if fixed == code or changed == 0:
        return None, ""
    return fixed, f"custom_services导入路径修复: {changed}处"


def _fix_sector_outer_radius_keyword(code: str) -> Tuple[Optional[str], str]:
    if "Sector(" not in code or "outer_radius" not in code:
        return None, ""

    fixed, inner_removed = _SECTOR_ZERO_INNER_RADIUS_RE.subn(r"\1", code)
    fixed, outer_changed = _SECTOR_OUTER_RADIUS_RE.subn(r"\1radius=", fixed)
    changed = inner_removed + outer_changed
    if changed == 0:
        return None, ""
    return fixed, f"Sector半径参数修复: {changed}处"


def _fix_annular_sector_duplicate_outer_radius_keyword(code: str) -> Tuple[Optional[str], str]:
    if "AnnularSector(" not in code or "outer_radius" not in code:
        return None, ""
    edits: list[tuple[int, int, str]] = []
    for open_paren, close_paren in _find_named_call_paren_spans_for_repair(
        code,
        "AnnularSector",
    ):
        argument_start = open_paren + 1
        argument_source = code[argument_start:close_paren]
        seen_outer_radius = False
        for start, end, argument in _top_level_call_argument_spans_for_repair(argument_source):
            if not re.match(r"^\s*outer_radius\s*=", argument):
                continue
            if not seen_outer_radius:
                seen_outer_radius = True
                continue
            absolute_start = argument_start + start
            absolute_end = argument_start + end
            remove_start = absolute_start
            remove_end = absolute_end
            prev_comma = code.rfind(",", argument_start, absolute_start)
            if prev_comma >= argument_start:
                remove_start = prev_comma
            else:
                following = code[absolute_end:close_paren]
                following_comma = re.match(r"\s*,\s*", following)
                if following_comma:
                    remove_end += following_comma.end()
            edits.append((remove_start, remove_end, ""))

    if not edits:
        return None, ""
    fixed = _apply_keyword_edits_for_repair(code, edits)
    if fixed == code:
        return None, ""
    return fixed, f"AnnularSector重复参数修复: {len(edits)}处"


def _find_named_call_paren_spans_for_repair(
    code: str,
    call_name: str,
) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    pattern = re.compile(rf"\b{re.escape(call_name)}\s*\(")
    for match in pattern.finditer(code):
        open_paren = code.find("(", match.start(), match.end())
        if open_paren < 0:
            continue
        close_paren = _matching_paren_index_for_repair(code, open_paren)
        if close_paren is not None:
            spans.append((open_paren, close_paren))
    return spans


def _matching_paren_index_for_repair(source: str, open_paren: int) -> int | None:
    depth = 0
    quote: str | None = None
    triple = False
    escaped = False
    index = open_paren
    while index < len(source):
        char = source[index]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif triple and source.startswith(quote * 3, index):
                quote = None
                triple = False
                index += 2
            elif not triple and char == quote:
                quote = None
            index += 1
            continue
        if char in {"'", '"'}:
            quote = char
            triple = source.startswith(char * 3, index)
            if triple:
                index += 3
                continue
            index += 1
            continue
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return index
        index += 1
    return None


def _top_level_call_argument_spans_for_repair(
    argument_source: str,
) -> list[tuple[int, int, str]]:
    spans: list[tuple[int, int, str]] = []
    depth = 0
    quote: str | None = None
    triple = False
    escaped = False
    start = 0
    index = 0
    while index < len(argument_source):
        char = argument_source[index]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif triple and argument_source.startswith(quote * 3, index):
                quote = None
                triple = False
                index += 2
            elif not triple and char == quote:
                quote = None
            index += 1
            continue
        if char in {"'", '"'}:
            quote = char
            triple = argument_source.startswith(char * 3, index)
            if triple:
                index += 3
                continue
            index += 1
            continue
        if char in "([{":
            depth += 1
        elif char in ")]}":
            depth = max(depth - 1, 0)
        elif char == "," and depth == 0:
            spans.append((start, index, argument_source[start:index]))
            start = index + 1
        index += 1
    if start <= len(argument_source):
        spans.append((start, len(argument_source), argument_source[start:]))
    return spans


def _fix_3d_text_registration_order(code: str) -> Tuple[Optional[str], str]:
    """Move fixed-frame/orientation registration before the play that reveals it.

    In ThreeDScene, Text/MathTex must be registered before the first add/Write/
    FadeIn/transform. LLMs often put the registration immediately after the
    display call; the script compiles, but the first rendered frame may show a
    flat 3D text plane. This fix is intentionally narrow: it only moves an
    adjacent registration call when it references a variable used immediately
    before it.
    """
    if "add_fixed_" not in code or ("self.play(" not in code and "self.add(" not in code):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    moves: list[tuple[int, int, int]] = []
    for statements in _iter_statement_lists(tree):
        for index, statement in enumerate(statements[:-1]):
            next_statement = statements[index + 1]
            if not (
                _is_self_method_expr(statement, "play")
                or _is_self_method_expr(statement, "add")
            ):
                continue
            registered_vars = _fixed_registration_vars(next_statement)
            if not registered_vars:
                continue
            revealed_vars = (
                _revealed_vars_in_play(statement)
                if _is_self_method_expr(statement, "play")
                else _added_vars_in_add(statement)
            )
            if not registered_vars.intersection(revealed_vars):
                continue
            if not getattr(next_statement, "end_lineno", None):
                continue
            moves.append((statement.lineno, next_statement.lineno, next_statement.end_lineno))

    if not moves:
        return None, ""

    lines = code.splitlines()
    moved = 0
    seen: set[tuple[int, int, int]] = set()
    for play_lineno, reg_lineno, reg_end_lineno in sorted(moves, reverse=True):
        key = (play_lineno, reg_lineno, reg_end_lineno)
        if key in seen or reg_lineno <= play_lineno:
            continue
        seen.add(key)
        registration_block = lines[reg_lineno - 1:reg_end_lineno]
        del lines[reg_lineno - 1:reg_end_lineno]
        lines[play_lineno - 1:play_lineno - 1] = registration_block
        moved += 1

    if moved == 0:
        return None, ""
    return "\n".join(lines), f"3D文字注册顺序修复: {moved} 处"


def _inject_missing_3d_camera_orientation(code: str) -> Tuple[Optional[str], str]:
    if not _THREED_BASE_CONFIG_SCENE_RE.search(code):
        return None, ""
    if _base_config_has_camera_orientation(code):
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""

    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    for method_name in ("setup_layout", "setup"):
        method_index = _find_base_config_method_index(
            lines,
            class_start=class_start,
            class_end=class_end,
            body_indent=body_indent,
            method_name=method_name,
        )
        if method_index is None:
            continue
        method_body_indent = body_indent + "    "
        method_end = _find_indented_block_end(
            lines,
            start_index=method_index + 1,
            parent_indent_len=len(body_indent),
        )
        insert_at = method_index + 1
        for offset in range(method_index + 1, method_end):
            if re.search(r"\bsuper\(\)\.(?:setup|setup_layout)\s*\(", lines[offset]):
                insert_at = offset + 1
                break
        lines.insert(
            insert_at,
            f"{method_body_indent}{_THREED_FRONT_FACING_CAMERA_CALL}",
        )
        return (
            "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
            f"3D镜头初始化补全: {method_name}",
        )

    insertion = _base_config_scene_class_insert_index(code)
    if not insertion:
        return None, ""
    insert_at, indent = insertion
    method_body_indent = indent + "    "
    lines[insert_at:insert_at] = [
        "",
        f"{indent}def setup(self):",
        f"{method_body_indent}super().setup()",
        f"{method_body_indent}{_THREED_FRONT_FACING_CAMERA_CALL}",
    ]
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "3D镜头初始化补全: setup",
    )


def _normalize_oblique_base_3d_camera_orientation(code: str) -> Tuple[Optional[str], str]:
    if not _THREED_BASE_CONFIG_SCENE_RE.search(code) or "set_camera_orientation" not in code:
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""

    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    changed = 0
    for method_name in ("setup_layout", "setup"):
        method_index = _find_base_config_method_index(
            lines,
            class_start=class_start,
            class_end=class_end,
            body_indent=body_indent,
            method_name=method_name,
        )
        if method_index is None:
            continue
        method_end = _find_indented_block_end(
            lines,
            start_index=method_index + 1,
            parent_indent_len=len(body_indent),
        )
        for index in range(method_index + 1, method_end):
            line = lines[index]
            if "set_camera_orientation(" not in re.sub(r"\s+", "", line):
                continue
            if _is_front_facing_3d_camera_line(line):
                continue
            indent = line[: len(line) - len(line.lstrip())]
            lines[index] = f"{indent}{_THREED_FRONT_FACING_CAMERA_CALL}"
            changed += 1

    if changed == 0:
        return None, ""
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"3D默认镜头正向化: {changed}处",
    )


def _boost_portrait_tiny_font_sizes(
    code: str,
    *,
    min_font_size: int = 24,
) -> Tuple[Optional[str], str]:
    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(code).readline))
    except (tokenize.TokenError, IndentationError):
        return None, ""

    changed = 0
    rewritten: list[tokenize.TokenInfo] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if (
            token.type == tokenize.NAME
            and token.string == "font_size"
            and index + 2 < len(tokens)
            and tokens[index + 1].string == "="
            and tokens[index + 2].type == tokenize.NUMBER
        ):
            number_token = tokens[index + 2]
            try:
                value = float(number_token.string)
            except ValueError:
                value = float(min_font_size)
            if value < min_font_size:
                number_token = number_token._replace(string=str(min_font_size))
                changed += 1
            rewritten.extend((token, tokens[index + 1], number_token))
            index += 3
            continue
        rewritten.append(token)
        index += 1

    if changed == 0:
        return None, ""
    return tokenize.untokenize(rewritten), f"竖屏小字号放大: {changed}处"


def _is_front_facing_3d_camera_line(line: str) -> bool:
    compact = re.sub(r"\s+", "", line)
    return (
        "set_camera_orientation(" in compact
        and "phi=0*DEGREES" in compact
        and "theta=-90*DEGREES" in compact
    )


def _base_config_has_camera_orientation(code: str) -> bool:
    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return False
    class_start, class_end, body_indent = class_range
    lines = code.splitlines()
    for method_name in ("setup_layout", "setup"):
        method_index = _find_base_config_method_index(
            lines,
            class_start=class_start,
            class_end=class_end,
            body_indent=body_indent,
            method_name=method_name,
        )
        if method_index is None:
            continue
        method_end = _find_indented_block_end(
            lines,
            start_index=method_index + 1,
            parent_indent_len=len(body_indent),
        )
        if any("set_camera_orientation" in line for line in lines[method_index + 1:method_end]):
            return True
    return False


def _find_base_config_method_index(
    lines: list[str],
    *,
    class_start: int,
    class_end: int,
    body_indent: str,
    method_name: str,
) -> int | None:
    pattern = re.compile(
        rf"^{re.escape(body_indent)}def\s+{re.escape(method_name)}\s*\("
    )
    for index in range(class_start + 1, class_end):
        line = lines[index]
        if pattern.match(line):
            return index
    return None


def _find_indented_block_end(
    lines: list[str],
    *,
    start_index: int,
    parent_indent_len: int,
) -> int:
    index = start_index
    while index < len(lines):
        line = lines[index]
        if line.strip() and len(line) - len(line.lstrip()) <= parent_indent_len:
            break
        index += 1
    return index


def _iter_statement_lists(node: ast.AST):
    for field_name in ("body", "orelse", "finalbody"):
        body = getattr(node, field_name, None)
        if isinstance(body, list):
            yield body
            for statement in body:
                yield from _iter_statement_lists(statement)
    handlers = getattr(node, "handlers", None)
    if isinstance(handlers, list):
        for handler in handlers:
            yield from _iter_statement_lists(handler)


def _is_self_method_expr(statement: ast.stmt, method_name: str) -> bool:
    if not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call):
        return False
    call = statement.value
    return (
        isinstance(call.func, ast.Attribute)
        and call.func.attr == method_name
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "self"
    )


def _fixed_registration_vars(statement: ast.stmt) -> set[str]:
    if not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call):
        return set()
    call = statement.value
    if not (
        isinstance(call.func, ast.Attribute)
        and call.func.attr in _FIXED_3D_TEXT_REGISTRATION_METHODS
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "self"
    ):
        return set()
    return {
        arg.id
        for arg in call.args
        if isinstance(arg, ast.Name)
    }


def _revealed_vars_in_play(statement: ast.stmt) -> set[str]:
    if not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call):
        return set()
    revealed: set[str] = set()
    for node in ast.walk(statement.value):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        name = ""
        if isinstance(func, ast.Name):
            name = func.id
        elif isinstance(func, ast.Attribute):
            name = func.attr
        if name not in _3D_TEXT_REVEAL_ANIMATIONS:
            continue
        revealed.update(
            child.id
            for child in ast.walk(node)
            if isinstance(child, ast.Name)
        )
    return revealed


def _added_vars_in_add(statement: ast.stmt) -> set[str]:
    if not _is_self_method_expr(statement, "add"):
        return set()
    call = statement.value
    assert isinstance(call, ast.Call)
    added: set[str] = set()
    for arg in call.args:
        if isinstance(arg, ast.Name):
            added.add(arg.id)
        elif isinstance(arg, ast.Starred) and isinstance(arg.value, ast.Name):
            added.add(arg.value.id)
    return added


def _fix_mathtex_chinese_pre(code: str) -> Tuple[Optional[str], str]:
    """渲染前扫描：MathTex/Tex 中含中文 → 替换为 Text()。

    注意：如果代码已配置 ctex 模板（TexTemplateLibrary.ctex），
    Tex/MathTex 本身就支持中文，不需要转换。盲目转成 Text() 会导致
    LaTeX 命令（如 \\text{}, \\frac{}, \\Rightarrow）被原样显示。
    """
    # 如果代码中已有 ctex 模板，Tex() 可以正确渲染中文，跳过转换
    if 'ctex' in code or 'TexTemplateLibrary' in code:
        return None, ""

    fixes = []

    def _replace(m):
        func_name = m.group(1)
        args_str = m.group(2)
        if _CHINESE_RE.search(args_str):
            fixes.append(f"{func_name}→Text")
            cleaned = re.sub(r',\s*tex_template\s*=[^,)]+', '', args_str)
            cleaned = re.sub(r'r?"?\$\$\\text\{([^}]+)\}\$\$"?', r'"\1"', cleaned)
            cleaned = re.sub(r'r?"?\$\$([^$]+)\$\$"?', r'"\1"', cleaned)
            return f"Text({cleaned})"
        return m.group(0)

    modified = _MATHTEX_WITH_CHINESE_RE.sub(_replace, code)
    if fixes and modified != code:
        return modified, f"预扫描: {len(fixes)} 处 MathTex/Tex 含中文→Text"
    return None, ""


def _plain_dynamic_latex_expr(name: str) -> str:
    return (
        f"str({name})"
        r'.replace(r"\text{", "")'
        r'.replace(r"\mathrm{", "")'
        r'.replace("{", "")'
        r'.replace("}", "")'
        r'.replace(r"\times", "×")'
        r'.replace(r"\cdot", "·")'
        r'.replace(r"\circ", "°")'
        r'.replace(r"\le", "≤")'
        r'.replace(r"\ge", "≥")'
        r'.replace(r"\lt", "<")'
        r'.replace(r"\gt", ">")'
    )


def _fix_dynamic_mathtex_name_args(code: str) -> Tuple[Optional[str], str]:
    """Avoid runtime LaTeX failures from MathTex(variable, ...).

    Generated long-course summary scenes sometimes build a formula string from
    CJK/prose fragments and pass the variable to MathTex. Literal MathTex stays
    untouched; variable payloads are safer as Text because the real content has
    already been decided by Python at runtime.
    """
    count = 0

    def _replace(match: re.Match) -> str:
        nonlocal count
        count += 1
        return f"Text({_plain_dynamic_latex_expr(match.group('name'))},"

    modified = _DYNAMIC_MATHTEX_NAME_ARG_RE.sub(_replace, code)
    if count and modified != code:
        return modified, f"变量型MathTex降级Text: {count}处"
    return None, ""


def _fix_inline_math_text_kwargs_signature(code: str) -> Tuple[Optional[str], str]:
    """Allow local inline_math_text helpers to accept kwargs emitted by formula repair."""
    if "inline_math_text" not in code:
        return None, ""

    def _replace(match: re.Match) -> str:
        tail = match.group("tail") or ""
        if "**" in tail:
            return match.group(0)
        return (
            f"{match.group('indent')}def inline_math_text("
            f"self, *{match.group('var')}{tail}, **_unused_inline_kwargs):"
        )

    modified, count = _INLINE_MATH_TEXT_NARROW_DEF_RE.subn(_replace, code)
    if count and modified != code:
        return modified, f"inline_math_text签名兼容: {count}处"
    return None, ""


def _fix_inline_math_text_math_branch_uses_mathtex(code: str) -> Tuple[Optional[str], str]:
    """Ensure inline_math_text(('math', ...)) renders with MathTex, not Text."""
    if "inline_math_text" not in code or (
        ".append(Text(str(" not in code and ".add(Text(str(" not in code
    ):
        return None, ""

    fixed_lines: list[str] = []
    fix_count = 0
    for line in code.splitlines(keepends=True):
        if (
            ".append(Text(str(" not in line
            and ".add(Text(str(" not in line
        ) or "FORMULA_COLOR" not in line:
            fixed_lines.append(line)
            continue
        call_match = re.search(
            r"(?P<target>[A-Za-z_][A-Za-z0-9_]*)\.(?P<method>append|add)"
            r"\(\s*Text\(str\("
            r"(?P<var>[A-Za-z_][A-Za-z0-9_]*)\[1\]\)",
            line,
        )
        font_match = re.search(r"font_size\s*=\s*(?P<font>[^,)]+(?:\s*[+\-*/]\s*[^,)]+)?)", line)
        color_match = re.search(r"color\s*=\s*(?P<color>[^,)]+)", line)
        if not call_match:
            fixed_lines.append(line)
            continue
        indent = line[: len(line) - len(line.lstrip())]
        target = call_match.group("target")
        method = call_match.group("method")
        var = call_match.group("var")
        color = color_match.group("color").strip() if color_match else "self.FORMULA_COLOR"
        font = font_match.group("font").strip() if font_match else ""
        font_arg = f", font_size={font}" if font else ""
        newline = "\n" if line.endswith("\n") else ""
        fixed_lines.append(
            f"{indent}{target}.{method}(MathTex(str({var}[1]), color={color}{font_arg})){newline}"
        )
        fix_count += 1

    if not fix_count:
        return None, ""
    modified = "".join(fixed_lines)
    if modified == code:
        return None, ""
    return modified, f"inline_math_text公式分支改用MathTex: {fix_count}处"


def _fix_inline_math_text_tuple_text_payloads(code: str) -> Tuple[Optional[str], str]:
    """Ensure inline_math_text(('text', ...)) renders the payload, not the tuple repr."""
    if "def inline_math_text" not in code or (
        "Text(" not in code and "_build_text_mobject" not in code
    ):
        return None, ""

    str_arg_re = re.compile(
        r"Text\(\s*str\(\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*\)\s*,"
    )
    bare_arg_re = re.compile(
        r"Text\(\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*,"
    )
    plain_str_arg_re = re.compile(
        r"(?<![A-Za-z0-9_])str\(\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*\)"
    )

    def _replace_str_arg(match: re.Match) -> str:
        var_name = match.group("var")
        return f"Text(str({_inline_math_text_plain_value_expr(var_name)}),"

    def _replace_bare_arg(match: re.Match) -> str:
        var_name = match.group("var")
        return f"Text(str({_inline_math_text_plain_value_expr(var_name)}),"

    def _replace_plain_str_arg(match: re.Match) -> str:
        var_name = match.group("var")
        return f"str({_inline_math_text_plain_value_expr(var_name)})"

    lines = code.splitlines(keepends=True)
    fixed_lines: list[str] = []
    in_helper = False
    helper_indent = 0
    fix_count = 0

    for line in lines:
        def_match = _INLINE_MATH_TEXT_DEF_LINE_RE.match(line)
        if def_match:
            in_helper = True
            helper_indent = len(def_match.group("indent"))
            fixed_lines.append(line)
            continue

        if in_helper:
            stripped = line.strip()
            line_indent = len(line) - len(line.lstrip())
            if stripped and line_indent <= helper_indent and not stripped.startswith("#"):
                in_helper = False

        if in_helper and "Text(" in line:
            fixed_line = str_arg_re.sub(_replace_str_arg, line)
            fixed_line = bare_arg_re.sub(_replace_bare_arg, fixed_line)
            if fixed_line != line:
                fix_count += 1
            fixed_lines.append(fixed_line)
            continue

        if in_helper and "str(" in line:
            fixed_line = plain_str_arg_re.sub(_replace_plain_str_arg, line)
            if fixed_line != line:
                fix_count += 1
            fixed_lines.append(fixed_line)
            continue

        fixed_lines.append(line)

    if not fix_count:
        return None, ""
    modified = "".join(fixed_lines)
    if modified == code:
        return None, ""
    return modified, f"inline_math_text文本tuple兼容: {fix_count}处"


def _fix_inline_math_text_single_list_parts_argument(code: str) -> Tuple[Optional[str], str]:
    """Expand self.inline_math_text([tuple, ...], **kwargs) to positional parts."""
    if "inline_math_text" not in code or "[" not in code:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets = [0]
    for line in lines:
        line_offsets.append(line_offsets[-1] + len(line))

    def _absolute_pos(lineno: int, col_offset: int) -> int:
        # ast col offsets are UTF-8 byte offsets; source slicing needs character offsets.
        char_col = len(lines[lineno - 1].encode("utf-8")[:col_offset].decode("utf-8"))
        return line_offsets[lineno - 1] + char_col

    replacements: list[tuple[int, int, str]] = []

    class _InlineMathListVisitor(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            if not (
                isinstance(node.func, ast.Attribute)
                and node.func.attr == "inline_math_text"
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "self"
                and node.args
                and isinstance(node.args[0], ast.List)
            ):
                self.generic_visit(node)
                return

            first_arg = node.args[0]
            if not first_arg.elts or not all(isinstance(item, ast.Tuple) for item in first_arg.elts):
                self.generic_visit(node)
                return
            if not (
                hasattr(first_arg, "end_lineno")
                and hasattr(first_arg, "end_col_offset")
                and first_arg.lineno is not None
                and first_arg.end_lineno is not None
            ):
                self.generic_visit(node)
                return

            parts = [ast.get_source_segment(code, item) for item in first_arg.elts]
            if not parts or any(part is None for part in parts):
                self.generic_visit(node)
                return

            start = _absolute_pos(first_arg.lineno, first_arg.col_offset)
            end = _absolute_pos(first_arg.end_lineno, first_arg.end_col_offset)
            replacements.append((start, end, ", ".join(part.strip() for part in parts if part)))
            self.generic_visit(node)

    _InlineMathListVisitor().visit(tree)
    if not replacements:
        return None, ""

    modified = code
    for start, end, replacement in reversed(replacements):
        modified = modified[:start] + replacement + modified[end:]

    if modified == code:
        return None, ""
    try:
        ast.parse(modified)
    except SyntaxError:
        return None, ""
    return modified, f"inline_math_text单list参数展开: {len(replacements)}处"


def _fix_make_cjk_fraction_latex_prefix_uses_mathtex(
    code: str,
) -> Tuple[Optional[str], str]:
    """Render make_cjk_fraction(r"\\sin \\theta =", ...) prefix as MathTex."""
    if "make_cjk_fraction" not in code or "Text(str(formula_prefix)" not in code:
        return None, ""

    fixed_lines: list[str] = []
    fix_count = 0
    for line in code.splitlines(keepends=True):
        if "prefix" not in line or "Text(str(formula_prefix)" not in line:
            fixed_lines.append(line)
            continue
        color_match = re.search(r"color\s*=\s*(?P<color>[^,)]+)", line)
        font_match = re.search(r"font_size\s*=\s*(?P<font>[^,)]+)", line)
        if not color_match:
            fixed_lines.append(line)
            continue
        indent = line[: len(line) - len(line.lstrip())]
        color = color_match.group("color").strip()
        font = font_match.group("font").strip() if font_match else "36"
        newline = "\n" if line.endswith("\n") else ""
        fixed_lines.append(
            f"{indent}prefix = MathTex(str(formula_prefix), color={color}, font_size={font}){newline}"
        )
        fix_count += 1

    if not fix_count:
        return None, ""
    modified = "".join(fixed_lines)
    if modified == code:
        return None, ""
    return modified, f"make_cjk_fraction公式前缀改用MathTex: {fix_count}处"


_SANITIZED_DYNAMIC_FORMULA_MARKERS = (
    r"\text{",
    r"\mathrm{",
    r"\times",
    r"\cdot",
    r"\circ",
    r"\frac",
    r"\sqrt",
    r"\sin",
    r"\cos",
    r"\tan",
    r"\theta",
    r"\le",
    r"\ge",
    r"\lt",
    r"\gt",
)
_SANITIZED_DYNAMIC_FORMULA_DISPATCH_NAMES = {"cell", "stripped"}


def _strip_sanitized_text_replace_chain(node: ast.AST) -> ast.AST:
    current = node
    while (
        isinstance(current, ast.Call)
        and isinstance(current.func, ast.Attribute)
        and current.func.attr == "replace"
    ):
        current = current.func.value
    return current


def _str_call_payload(node: ast.AST) -> ast.AST:
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "str"
        and len(node.args) == 1
    ):
        return node.args[0]
    return node


def _dynamic_formula_dispatch_call_source(
    code: str,
    call: ast.Call,
    payload_node: ast.AST,
) -> str:
    base = _str_call_payload(_strip_sanitized_text_replace_chain(payload_node))
    base_source = ast.get_source_segment(code, base) or ast.unparse(base)
    base_source = str(base_source or "").strip()
    if not base_source:
        return ""

    parts = [base_source]
    for arg in call.args[1:]:
        arg_source = ast.get_source_segment(code, arg) or ast.unparse(arg)
        if not arg_source:
            return ""
        parts.append(str(arg_source).strip())
    for keyword in call.keywords:
        value_source = ast.get_source_segment(code, keyword.value) or ast.unparse(
            keyword.value
        )
        if not value_source:
            return ""
        if keyword.arg is None:
            parts.append(f"**{value_source.strip()}")
        else:
            parts.append(f"{keyword.arg}={value_source.strip()}")
    return f"_mathpi_formula_or_text({', '.join(parts)})"


def _inject_formula_or_text_dispatch_helper(code: str) -> str:
    if "def _mathpi_formula_or_text" in code:
        return code

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    helper_lines = [
        "",
        "def _mathpi_formula_or_text(value, *args, **kwargs):",
        "    raw = str(value)",
        "    math_tokens = (",
        '        r"\\frac", r"\\sqrt", r"\\sin", r"\\cos", r"\\tan",',
        '        r"\\theta", r"\\alpha", r"\\beta", r"\\gamma", r"\\pi",',
        '        r"\\times", r"\\cdot", r"\\circ", r"\\le", r"\\ge",',
        '        "^", "_", "="',
        "    )",
        "    has_cjk = any('\\u4e00' <= ch <= '\\u9fff' for ch in raw)",
        "    if not has_cjk and any(token in raw for token in math_tokens):",
        "        math_kwargs = {",
        "            key: val for key, val in kwargs.items()",
        "            if key in {'color', 'font_size', 'tex_template', 'tex_environment', 'substrings_to_isolate', 'tex_to_color_map'}",
        "        }",
        "        try:",
        "            return MathTex(raw, *args, **math_kwargs)",
        "        except Exception:",
        "            pass",
        '    plain = raw.replace(r"\\text{", "").replace(r"\\mathrm{", "")',
        '    plain = plain.replace("{", "").replace("}", "")',
        '    plain = plain.replace(r"\\times", "×").replace(r"\\cdot", "·").replace(r"\\circ", "°")',
        '    plain = plain.replace(r"\\le", "≤").replace(r"\\ge", "≥").replace(r"\\lt", "<").replace(r"\\gt", ">")',
        "    return Text(plain, *args, **kwargs)",
        "",
    ]
    lines[insert_at:insert_at] = helper_lines
    return "\n".join(lines) + ("\n" if code.endswith("\n") else "")


def _fix_sanitized_dynamic_formula_text_to_runtime_dispatch(
    code: str,
) -> Tuple[Optional[str], str]:
    """Route dynamic TeX-like Text(str(x).replace(...)) through a runtime splitter."""
    if "Text(" not in code or ".replace(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "Text"
            and node.args
        ):
            continue
        payload_node = node.args[0]
        expr_source = ast.get_source_segment(code, payload_node) or ast.unparse(
            payload_node
        )
        expr_source = str(expr_source or "")
        if ".replace(" not in expr_source:
            continue
        if not any(marker in expr_source for marker in _SANITIZED_DYNAMIC_FORMULA_MARKERS):
            continue
        base = _str_call_payload(_strip_sanitized_text_replace_chain(payload_node))
        if not (
            isinstance(base, ast.Name)
            and (
                base.id in _SANITIZED_DYNAMIC_FORMULA_DISPATCH_NAMES
                or "cell" in base.id.lower()
            )
        ):
            continue
        base_source = ast.get_source_segment(code, base) or ast.unparse(base)
        if not str(base_source or "").strip():
            continue
        replacement = _dynamic_formula_dispatch_call_source(code, node, payload_node)
        if not replacement:
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    current = _inject_formula_or_text_dispatch_helper(current)
    return current, f"动态公式Text运行期分流: {len(replacements)}处"


def _remove_dangerous_global_text_monkey_patch(code: str) -> Tuple[Optional[str], str]:
    """Remove generated Text = PatchedText blocks that break Manim Text.__new__."""
    if "Text =" not in code or "__new__" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    text_patch_classes: set[str] = set()
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.Assign):
            continue
        if not (isinstance(node.value, ast.Name) and node.value.id):
            continue
        if any(isinstance(target, ast.Name) and target.id == "Text" for target in node.targets):
            text_patch_classes.add(node.value.id)
    if not text_patch_classes:
        return None, ""

    original_text_aliases: set[str] = set()
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.Assign):
            continue
        if not (isinstance(node.value, ast.Name) and node.value.id == "Text"):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name):
                original_text_aliases.add(target.id)

    class_nodes: dict[str, ast.ClassDef] = {}
    for node in getattr(tree, "body", []):
        if isinstance(node, ast.ClassDef) and node.name in text_patch_classes:
            has_new = any(
                isinstance(child, ast.FunctionDef) and child.name == "__new__"
                for child in node.body
            )
            base_names = {
                base.id
                for base in node.bases
                if isinstance(base, ast.Name)
            }
            if has_new and (base_names & ({"Text"} | original_text_aliases)):
                class_nodes[node.name] = node

    if not class_nodes:
        return None, ""

    remove_ranges: list[tuple[int, int]] = []
    for node in getattr(tree, "body", []):
        if isinstance(node, ast.ClassDef) and node.name in class_nodes:
            remove_ranges.append((node.lineno - 1, getattr(node, "end_lineno", node.lineno)))
            continue
        if not isinstance(node, ast.Assign):
            continue
        remove_assignment = False
        if isinstance(node.value, ast.Name):
            if node.value.id in class_nodes and any(
                isinstance(target, ast.Name) and target.id == "Text"
                for target in node.targets
            ):
                remove_assignment = True
            if node.value.id == "Text" and any(
                isinstance(target, ast.Name) and target.id in original_text_aliases
                for target in node.targets
            ):
                remove_assignment = True
        if remove_assignment:
            remove_ranges.append((node.lineno - 1, getattr(node, "end_lineno", node.lineno)))

    if not remove_ranges:
        return None, ""
    lines = code.splitlines()
    for start, end in sorted(set(remove_ranges), reverse=True):
        del lines[start:end]
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, f"危险Text全局猴子补丁移除: {len(class_nodes)}处"


def _fix_safe_text_box_duplicate_color_kwargs(code: str) -> Tuple[Optional[str], str]:
    """Repair custom safe_text_box helpers that pass color twice to Text()."""
    if "def safe_text_box" not in code or "**kwargs" not in code:
        return None, ""

    def _replace(match: re.Match) -> str:
        indent = match.group("indent")
        return (
            f"{indent}_text_color = kwargs.pop(\"color\", self.PRIMARY_TEXT)\n"
            f"{indent}{match.group('var')} = Text("
            f"{match.group('content')}, color=_text_color, **kwargs)"
        )

    modified, count = _SAFE_TEXT_BOX_DUP_COLOR_RE.subn(_replace, code)
    if count and modified != code:
        return modified, f"safe_text_box重复color修复: {count}处"
    return None, ""


def _safe_text_box_signature_for_repair(tree: ast.AST) -> tuple[set[str], bool]:
    return _function_signature_for_repair(tree, "safe_text_box")


def _function_signature_for_repair(tree: ast.AST, name: str) -> tuple[set[str], bool]:
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef) or node.name != name:
            continue
        accepted = {
            arg.arg
            for arg in (*node.args.args, *node.args.kwonlyargs)
            if arg.arg != "self"
        }
        return accepted, node.args.kwarg is not None
    return set(), False


def _keyword_name_span_for_repair(
    keyword: ast.keyword,
    code: str,
    lines: list[str],
    line_offsets: list[int],
) -> Optional[tuple[int, int]]:
    value_span = _source_span_for_node(keyword.value, lines, line_offsets)
    if not value_span or not keyword.arg:
        return None
    line_index = keyword.value.lineno - 1
    line_start = line_offsets[line_index]
    key_start = code.rfind(keyword.arg, line_start, value_span[0])
    if key_start < line_start:
        return None
    return key_start, key_start + len(keyword.arg)


def _keyword_removal_span_for_repair(
    keyword: ast.keyword,
    code: str,
    lines: list[str],
    line_offsets: list[int],
) -> Optional[tuple[int, int]]:
    value_span = _source_span_for_node(keyword.value, lines, line_offsets)
    if not value_span or not keyword.arg:
        return None
    line_index = keyword.value.lineno - 1
    line_start = line_offsets[line_index]
    line_end = line_start + len(lines[line_index])
    value_start, value_end = value_span
    key_start = code.rfind(keyword.arg, line_start, value_start)
    if key_start < line_start:
        return None

    remove_start = key_start
    remove_end = value_end
    prev_comma = code.rfind(",", line_start, remove_start)
    if prev_comma >= line_start:
        remove_start = prev_comma
    else:
        after = code[remove_end:line_end]
        after_comma = re.match(r"\s*,\s*", after)
        if after_comma:
            remove_end += after_comma.end()
    return remove_start, remove_end


def _apply_keyword_edits_for_repair(
    code: str,
    edits: list[tuple[int, int, str]],
) -> str:
    current = code
    next_right_boundary = len(code)
    for start, end, replacement in sorted(edits, key=lambda item: item[0], reverse=True):
        if end > next_right_boundary:
            end = next_right_boundary
        if start > end:
            continue
        current = current[:start] + replacement + current[end:]
        next_right_boundary = start
    return current


def _base_config_scene_attrs_for_repair(tree: ast.AST) -> set[str]:
    attrs: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef) or node.name != "BaseConfigScene":
            continue
        for child in node.body:
            if isinstance(child, ast.Assign):
                for target in child.targets:
                    if isinstance(target, ast.Name) and target.id.isupper():
                        attrs.add(target.id)
            elif (
                isinstance(child, ast.AnnAssign)
                and isinstance(child.target, ast.Name)
                and child.target.id.isupper()
            ):
                attrs.add(child.target.id)
        break
    return attrs


def _self_upper_attr_refs_for_repair(tree: ast.AST) -> list[str]:
    refs: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id == "self"
            and isinstance(node.ctx, ast.Load)
            and node.attr.isupper()
        ):
            continue
        refs.append((
            getattr(node, "lineno", 0),
            getattr(node, "col_offset", 0),
            node.attr,
        ))
    ordered: list[str] = []
    seen: set[str] = set()
    for _lineno, _col, attr in sorted(refs):
        if attr in seen:
            continue
        seen.add(attr)
        ordered.append(attr)
    return ordered


def _module_upper_attrs_for_repair(tree: ast.AST) -> set[str]:
    attrs: set[str] = set()
    for node in getattr(tree, "body", []):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id.isupper():
                    attrs.add(target.id)
        elif (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id.isupper()
        ):
            attrs.add(node.target.id)
    return attrs


_MODULE_COLOR_ALIAS_CANDIDATES = {
    "MAIN_COLOR": ("MAIN_COLOR", "MAIN_BLUE", "PRIMARY", "BLUE"),
    "PRIMARY_COLOR": ("MAIN_COLOR", "MAIN_BLUE", "PRIMARY", "BLUE"),
    "TEXT_COLOR": ("TEXT_COLOR", "PRIMARY_TEXT", "MAIN_WHITE", "TEXT_1", "WHITE"),
    "PRIMARY_TEXT": ("PRIMARY_TEXT", "TEXT_COLOR", "MAIN_WHITE", "TEXT_1", "WHITE"),
    "TITLE_COLOR": ("TITLE_COLOR", "PRIMARY_TEXT", "TEXT_COLOR", "MAIN_WHITE", "TEXT_1", "WHITE"),
    "MUTED_COLOR": ("MUTED_COLOR", "MUTED_TEXT", "PRIMARY_TEXT", "TEXT_COLOR", "MAIN_WHITE", "TEXT_1"),
    "MUTED_TEXT": ("MUTED_TEXT", "MUTED_COLOR", "PRIMARY_TEXT", "TEXT_COLOR", "MAIN_WHITE", "TEXT_1"),
    "SECONDARY_COLOR": ("SECONDARY_COLOR", "MAIN_PURPLE", "SECONDARY", "PURPLE"),
    "SECONDARY_TEXT": ("SECONDARY_TEXT", "SECONDARY_COLOR", "MAIN_PURPLE", "SECONDARY"),
    "ACCENT_COLOR": ("ACCENT_COLOR", "MAIN_ORANGE", "ACCENT", "ORANGE", "YELLOW"),
    "EMPHASIS_COLOR": ("EMPHASIS_COLOR", "ACCENT_COLOR", "MAIN_ORANGE", "ACCENT", "ORANGE", "YELLOW"),
    "ANNOTATION_COLOR": ("ANNOTATION_COLOR", "ACCENT_COLOR", "MAIN_ORANGE", "ACCENT", "ORANGE", "YELLOW"),
    "FORMULA_COLOR": ("FORMULA_COLOR", "PRIMARY_TEXT", "TEXT_COLOR", "MAIN_WHITE", "TEXT_1"),
    "GEOMETRY_COLOR": ("GEOMETRY_COLOR", "MAIN_COLOR", "AXIS_COLOR", "SECONDARY_COLOR", "PRIMARY_TEXT", "BLUE"),
    "GRID_COLOR": ("GRID_COLOR", "AXIS_COLOR", "SECONDARY_COLOR", "MAIN_COLOR", "PRIMARY_TEXT", "BLUE"),
    "AXIS_COLOR": ("AXIS_COLOR", "MAIN_COLOR", "SECONDARY_COLOR", "PRIMARY_TEXT", "BLUE"),
    "STROKE_COLOR": ("STROKE_COLOR", "GEOMETRY_COLOR", "MAIN_COLOR", "AXIS_COLOR", "PRIMARY_TEXT", "WHITE"),
    "FILL_COLOR": ("FILL_COLOR", "MAIN_COLOR", "SECONDARY_COLOR", "ACCENT_COLOR", "BLUE"),
    "CARD_FILL": ("CARD_FILL", "CARD_BG", "CARD_BACKGROUND", "PANEL_FILL", "FILL_COLOR", "WHITE"),
    "PANEL_FILL": ("PANEL_FILL", "FILL_COLOR", "CARD_BG", "CARD_BACKGROUND", "PRIMARY_TEXT", "WHITE"),
    "SECONDARY_BG": ("SECONDARY_BG", "CARD_BG", "CARD_BACKGROUND", "PANEL_FILL", "FILL_COLOR", "WHITE"),
    "SOFT_FILL": ("SOFT_FILL", "CARD_BG", "CARD_BACKGROUND", "PANEL_FILL", "FILL_COLOR", "WHITE"),
    "BG_COLOR": ("BG_COLOR", "BG", "BACKGROUND_COLOR", "BACKGROUND"),
    "RED_COLOR": ("RED_COLOR", "ERROR_COLOR", "WRONG_COLOR", "NEGATIVE_COLOR", "ANNOTATION_COLOR", "ACCENT_COLOR", "RED", "PRIMARY_TEXT", "MAIN_COLOR"),
    "GREEN_COLOR": ("GREEN_COLOR", "SUCCESS_COLOR", "CORRECT_COLOR", "POSITIVE_COLOR", "SECONDARY_COLOR", "GREEN", "MAIN_COLOR"),
    "YELLOW_COLOR": ("YELLOW_COLOR", "HIGHLIGHT_COLOR", "ACCENT_COLOR", "ANNOTATION_COLOR", "YELLOW", "GOLD", "PRIMARY_TEXT"),
    "BLUE_COLOR": ("BLUE_COLOR", "MAIN_COLOR", "PRIMARY_COLOR", "GEOMETRY_COLOR", "BLUE", "PRIMARY_TEXT"),
    "ORANGE_COLOR": ("ORANGE_COLOR", "ACCENT_COLOR", "EMPHASIS_COLOR", "ANNOTATION_COLOR", "ORANGE", "YELLOW"),
    "PURPLE_COLOR": ("PURPLE_COLOR", "SECONDARY_COLOR", "ANNOTATION_COLOR", "PURPLE", "ACCENT_COLOR"),
}


def _module_color_alias_target(attr: str, attrs: set[str]) -> Optional[str]:
    if attr in attrs:
        return attr
    for candidate in _MODULE_COLOR_ALIAS_CANDIDATES.get(attr, ()):
        if candidate in attrs:
            return candidate
    return None


def _upper_name_refs_for_repair(tree: ast.AST) -> list[str]:
    refs: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Load)
            and node.id.isupper()
        ):
            continue
        refs.append((
            getattr(node, "lineno", 0),
            getattr(node, "col_offset", 0),
            node.id,
        ))
    ordered: list[str] = []
    seen: set[str] = set()
    for _lineno, _col, attr in sorted(refs):
        if attr in seen:
            continue
        seen.add(attr)
        ordered.append(attr)
    return ordered


def _module_alias_insert_index(code: str) -> int:
    lines = code.splitlines()
    last_assignment = -1
    for index, line in enumerate(lines):
        if re.match(r"^class\s+", line):
            break
        if re.match(r"^[A-Z][A-Z0-9_]*\s*(?::[^=]+)?=", line):
            last_assignment = index
    if last_assignment >= 0:
        return last_assignment + 1

    last_import = -1
    for index, line in enumerate(lines):
        if re.match(r"^(?:from\s+\S+\s+import\s+|import\s+)", line):
            last_import = index
            continue
        if line.strip() and last_import >= 0:
            break
    return last_import + 1 if last_import >= 0 else 0


def _inject_module_color_aliases(code: str) -> Tuple[Optional[str], str]:
    """Add module-level color aliases for generated free-name color refs."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    module_attrs = _module_upper_attrs_for_repair(tree)
    if not module_attrs:
        return None, ""

    aliases: list[tuple[str, str]] = []
    planned = set(module_attrs)
    for attr in _upper_name_refs_for_repair(tree):
        if attr in planned:
            continue
        target = _module_color_alias_target(attr, planned)
        if not target:
            continue
        aliases.append((attr, target))
        planned.add(attr)

    if not aliases:
        return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    alias_lines = [f"{attr} = {target}" for attr, target in aliases]
    lines[insert_at:insert_at] = alias_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    changed = ", ".join(f"{attr}={target}" for attr, target in aliases)
    return current, f"模块级颜色别名补全: {changed}"


_MODULE_THEME_COLOR_FALLBACKS = {
    "RED_COLOR": 'globals().get("RED", "#C62828")',
    "GREEN_COLOR": 'globals().get("GREEN", "#2E7D32")',
    "YELLOW_COLOR": 'globals().get("YELLOW", "#F9A825")',
    "BLUE_COLOR": 'globals().get("BLUE", "#2E86AB")',
    "ORANGE_COLOR": 'globals().get("ORANGE", "#F18F01")',
    "PURPLE_COLOR": 'globals().get("PURPLE", "#7B1FA2")',
}


def _inject_module_theme_color_fallbacks(code: str) -> Tuple[Optional[str], str]:
    """Add module-level semantic color fallbacks such as RED_COLOR."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    module_attrs = _module_upper_attrs_for_repair(tree)
    missing: list[str] = []
    planned = set(module_attrs)
    for attr in _upper_name_refs_for_repair(tree):
        if attr in planned or attr not in _MODULE_THEME_COLOR_FALLBACKS:
            continue
        missing.append(attr)
        planned.add(attr)
    if not missing:
        return None, ""

    lines = code.splitlines()
    insert_at = _module_alias_insert_index(code)
    alias_lines = [
        f"{attr} = {_MODULE_THEME_COLOR_FALLBACKS[attr]}"
        for attr in missing
    ]
    lines[insert_at:insert_at] = alias_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, f"模块主题色兜底: {', '.join(missing)}"


def _global_config_class_range(code: str) -> tuple[int, int, str] | None:
    lines = code.splitlines()
    for index, line in enumerate(lines):
        match = re.match(r"^(?P<indent>\s*)class\s+GlobalConfig\b.*:\s*$", line)
        if not match:
            continue
        class_indent = match.group("indent")
        end = index + 1
        while end < len(lines):
            body_line = lines[end]
            if body_line.strip() and len(body_line) - len(body_line.lstrip()) <= len(class_indent):
                break
            end += 1
        return index, end, class_indent + "    "
    return None


def _inject_module_global_config_color_aliases(code: str) -> Tuple[Optional[str], str]:
    """Expose common bare color names from GlobalConfig at module scope.

    Slice-level LLM fixes sometimes reintroduce ``color=MAIN_COLOR`` while the
    official header only exposes ``GlobalConfig.MAIN_COLOR`` and
    ``BaseConfigScene.MAIN_COLOR``.  Adding a module alias preserves the selected
    theme and avoids falling back to Manim's unrelated named colors.
    """
    if "class GlobalConfig" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    global_attrs = _global_config_attrs_for_repair(tree)
    module_attrs = _module_upper_attrs_for_repair(tree)
    if not global_attrs:
        return None, ""

    missing_refs: list[str] = []
    seen: set[str] = set()
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Name)
            and isinstance(node.ctx, ast.Load)
            and node.id in _MODULE_COLOR_ALIAS_CANDIDATES
            and node.id not in module_attrs
        ):
            continue
        target = (
            node.id if node.id in global_attrs
            else _global_config_alias_target(node.id, global_attrs)
        )
        if not target or node.id in seen:
            continue
        seen.add(node.id)
        missing_refs.append(node.id)

    if not missing_refs:
        return None, ""

    class_range = _global_config_class_range(code)
    if not class_range:
        return None, ""
    _start, end, _indent = class_range
    lines = code.splitlines()
    alias_lines: list[str] = [""]
    changed: list[str] = []
    for name in missing_refs:
        target = (
            name if name in global_attrs
            else _global_config_alias_target(name, global_attrs)
        )
        if not target:
            continue
        alias_lines.append(f"{name} = GlobalConfig.{target}")
        changed.append(f"{name}=GlobalConfig.{target}")
    if not changed:
        return None, ""

    lines[end:end] = alias_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, f"模块颜色别名补全: {', '.join(changed)}"


def _base_config_scene_class_insert_index(code: str) -> tuple[int, str] | None:
    lines = code.splitlines()
    for index, line in enumerate(lines):
        match = re.match(r"^(?P<indent>\s*)class\s+BaseConfigScene\b.*:\s*$", line)
        if not match:
            continue
        class_indent = match.group("indent")
        body_indent = class_indent + "    "
        last_assignment = index
        body_index = index + 1
        while body_index < len(lines):
            body_line = lines[body_index]
            if body_line.strip():
                indent_len = len(body_line) - len(body_line.lstrip())
                if indent_len <= len(class_indent):
                    break
            if re.match(
                rf"^{re.escape(body_indent)}[A-Z][A-Z0-9_]*\s*(?::[^=]+)?=",
                body_line,
            ):
                last_assignment = body_index
            body_index += 1
        return last_assignment + 1, body_indent
    return None


def _inject_base_config_scene_global_aliases(code: str) -> Tuple[Optional[str], str]:
    """Expose GlobalConfig aliases as BaseConfigScene class attrs for self.X use."""
    if "class BaseConfigScene" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    global_attrs = _global_config_attrs_for_repair(tree)
    module_attrs = _module_upper_attrs_for_repair(tree)
    base_attrs = _base_config_scene_attrs_for_repair(tree)
    if not global_attrs and not module_attrs:
        return None, ""

    aliases: list[tuple[str, str]] = []
    module_aliases: list[tuple[str, str]] = []
    planned = set(base_attrs)
    for attr in _self_upper_attr_refs_for_repair(tree):
        if attr in planned:
            continue
        if global_attrs:
            target = (
                attr if attr in global_attrs
                else _global_config_alias_target(attr, global_attrs)
            )
            if target:
                aliases.append((attr, target))
                planned.add(attr)
                continue
        module_target = _module_color_alias_target(attr, module_attrs)
        if not module_target:
            continue
        module_aliases.append((attr, module_target))
        planned.add(attr)
    if not aliases and not module_aliases:
        return None, ""

    insertion = _base_config_scene_class_insert_index(code)
    if not insertion:
        return None, ""
    insert_at, indent = insertion
    lines = code.splitlines()
    alias_lines = [
        f"{indent}{attr} = GlobalConfig.{target}" for attr, target in aliases
    ] + [
        f"{indent}{attr} = {target}" for attr, target in module_aliases
    ]
    lines[insert_at:insert_at] = alias_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    changed_parts = [
        f"{attr}=GlobalConfig.{target}" for attr, target in aliases
    ] + [
        f"{attr}={target}" for attr, target in module_aliases
    ]
    changed = ", ".join(changed_parts)
    return current, f"BaseConfigScene别名补全: {changed}"


_BASE_CONFIG_THEME_COLOR_FALLBACKS = {
    "FG": 'locals().get("PRIMARY_TEXT", globals().get("BLACK", "#222222"))',
    "RED_COLOR": 'globals().get("RED", "#C62828")',
    "GREEN_COLOR": 'globals().get("GREEN", "#2E7D32")',
    "YELLOW_COLOR": 'globals().get("YELLOW", "#F9A825")',
    "BLUE_COLOR": 'globals().get("BLUE", "#2E86AB")',
    "ORANGE_COLOR": 'globals().get("ORANGE", "#F18F01")',
    "PURPLE_COLOR": 'globals().get("PURPLE", "#7B1FA2")',
    "SUCCESS_COLOR": 'globals().get("GREEN", "#2E7D32")',
    "CORRECT_COLOR": 'globals().get("GREEN", "#2E7D32")',
    "POSITIVE_COLOR": 'globals().get("GREEN", "#2E7D32")',
    "ERROR_COLOR": 'globals().get("RED", "#C62828")',
    "WRONG_COLOR": 'globals().get("RED", "#C62828")',
    "NEGATIVE_COLOR": 'globals().get("RED", "#C62828")',
    "CARD_BG": 'globals().get("WHITE", "#FFFFFF")',
    "CARD_BACKGROUND": 'globals().get("WHITE", "#FFFFFF")',
    "CARD_FILL": 'locals().get("CARD_BG", locals().get("CARD_BACKGROUND", globals().get("WHITE", "#FFFFFF")))',
    "CARD_COLOR": 'globals().get("BLUE", "#2E86AB")',
    "CARD_STROKE": 'globals().get("BLUE", "#2E86AB")',
    "CARD_BORDER_COLOR": 'globals().get("BLUE", "#2E86AB")',
    "PANEL_FILL": 'locals().get("FILL_COLOR", locals().get("PRIMARY_TEXT", globals().get("WHITE", "#FFFFFF")))',
    "SECONDARY_BG": 'locals().get("CARD_BG", locals().get("CARD_BACKGROUND", globals().get("WHITE", "#FFFFFF")))',
    "SOFT_FILL": 'locals().get("CARD_BG", locals().get("CARD_BACKGROUND", globals().get("WHITE", "#FFFFFF")))',
}


def _inject_base_config_scene_theme_color_fallbacks(code: str) -> Tuple[Optional[str], str]:
    """Add safe BaseConfigScene color attrs when generated scenes use self.X."""
    if "class BaseConfigScene" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    base_attrs = _base_config_scene_attrs_for_repair(tree)
    missing: list[str] = []
    planned = set(base_attrs)
    for attr in _self_upper_attr_refs_for_repair(tree):
        if attr in planned or attr not in _BASE_CONFIG_THEME_COLOR_FALLBACKS:
            continue
        missing.append(attr)
        planned.add(attr)
    if not missing:
        return None, ""

    insertion = _base_config_scene_class_insert_index(code)
    if not insertion:
        return None, ""
    insert_at, indent = insertion
    lines = code.splitlines()
    alias_lines = [
        f"{indent}{attr} = {_BASE_CONFIG_THEME_COLOR_FALLBACKS[attr]}"
        for attr in missing
    ]
    lines[insert_at:insert_at] = alias_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    changed = ", ".join(missing)
    return current, f"BaseConfigScene主题色兜底: {changed}"


_KNOWN_SCENE_BASES = {
    "Scene",
    "ThreeDScene",
    "VoiceoverScene",
    "MovingCameraScene",
    "BaseConfigScene",
}


def _inject_missing_scene_base_aliases(code: str) -> Tuple[Optional[str], str]:
    """Alias omitted shared scene bases back to BaseConfigScene.

    LLMs sometimes emit ``class Scene1(...SharedGeometryScene)`` but drop the
    shared base class definition during repair. A BaseConfigScene alias keeps the
    script renderable and lets later runtime repair handle any true missing
    helper methods.
    """
    if "BaseConfigScene" not in code or "class " not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    defined = {
        node.name
        for node in getattr(tree, "body", [])
        if isinstance(node, ast.ClassDef)
    }
    if "BaseConfigScene" not in defined:
        return None, ""

    missing: list[str] = []
    seen: set[str] = set()
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef):
            continue
        if not re.match(r"Scene(?:_|\d)", node.name):
            continue
        for base in node.bases:
            base_name = _class_base_name(base)
            if (
                not base_name
                or base_name in defined
                or base_name in _KNOWN_SCENE_BASES
                or not base_name.endswith("Scene")
                or base_name in seen
            ):
                continue
            seen.add(base_name)
            missing.append(base_name)

    if not missing:
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, _indent = class_range
    lines = code.splitlines()
    alias_lines: list[str] = []
    for name in missing:
        alias_lines.extend([
            "",
            f"class {name}(BaseConfigScene):",
            "    pass",
        ])
    lines[end:end] = alias_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, f"缺失Scene基类别名补全: {', '.join(missing)}"


_BASE_CONFIG_HELPER_ATTRS = {
    "full_canvas",
    "left_canvas",
    "right_canvas",
    "top_canvas",
    "bottom_canvas",
    "title_zone",
    "content_zone",
    "footer_zone",
    "formula_zone",
    "frame_width",
    "frame_height",
    "safe_margin",
    "safe_text_box",
    "layout_canvas",
    "fit_to_canvas",
    "fit_to_width",
    "safe_formula",
    "to_3d",
    "setup_scene",
    "inline_math_text",
    "cjk_math_tex",
    "get_pt",
    "rotate_about_axis",
    "get_figure_parts",
    "get_base_geometry",
    "get_geometry_figure",
    "get_geometry_base",
    "get_figure",
    "get_figures",
    "get_title",
    "get_quote_box",
    "show_law_card",
    "rebuild_question_layout",
    "get_stamp",
    "get_cross",
    "get_checkmark",
    "create_triangle_figure",
    "get_cube_elements",
    "get_triangle_centers",
    "make_text",
    "make_title",
    "make_formula",
    "make_point_with_label",
    "place_non_overlapping",
    "asset_icon",
    "icon_card",
    "icon_row",
    "create_3d_label",
    "narrate",
    "play_voiceover",
    "play_steps_evenly",
    "play_synced_steps",
    "wait_for_voiceover_remaining",
    "create_right_angle_mark",
    "build_intro_triangle",
    "build_area_proof_diagram",
}


def _scene_class_needs_base_config_contract(node: ast.ClassDef) -> bool:
    for child in ast.walk(node):
        if not (
            isinstance(child, ast.Attribute)
            and isinstance(child.value, ast.Name)
            and child.value.id == "self"
            and isinstance(child.ctx, ast.Load)
        ):
            continue
        if child.attr in _BASE_CONFIG_HELPER_ATTRS or child.attr.isupper():
            return True
    return False


def _fix_scene_classes_requiring_base_config_inheritance(
    code: str,
) -> Tuple[Optional[str], str]:
    """Scene classes using project helpers must inherit BaseConfigScene."""
    if "class BaseConfigScene" not in code or "self." not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    defined = {
        node.name
        for node in getattr(tree, "body", [])
        if isinstance(node, ast.ClassDef)
    }
    if "BaseConfigScene" not in defined:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    replacements: list[tuple[int, int, str]] = []
    changed_classes: list[str] = []
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef):
            continue
        if node.name == "BaseConfigScene" or not re.match(r"Scene(?:_|\d)", node.name):
            continue
        if not _scene_class_needs_base_config_contract(node):
            continue
        for base in node.bases:
            if not isinstance(base, ast.Name) or base.id != "Scene":
                continue
            span = _source_span_for_node(base, lines, line_offsets)
            if not span:
                continue
            replacements.append((span[0], span[1], "BaseConfigScene"))
            changed_classes.append(node.name)
            break

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        if current[start:end] != "Scene":
            continue
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    return current, f"Scene继承BaseConfigScene修复: {', '.join(changed_classes)}"


def _fix_scene_classes_redundant_base_config_mro(
    code: str,
) -> Tuple[Optional[str], str]:
    """Drop concrete Scene bases when BaseConfigScene is already inherited.

    Project headers define BaseConfigScene as the concrete Manim scene base
    (Scene / VoiceoverScene / ThreeDScene).  Generated code sometimes emits
    ``class Scene_X(VoiceoverScene, BaseConfigScene)`` which fails at import
    time with Python MRO conflicts.  Keeping BaseConfigScene and removing the
    duplicate concrete bases is deterministic and preserves project helpers.
    """
    if "class BaseConfigScene" not in code or "BaseConfigScene" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    defined = {
        node.name
        for node in getattr(tree, "body", [])
        if isinstance(node, ast.ClassDef)
    }
    if "BaseConfigScene" not in defined:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    concrete_scene_bases = _KNOWN_SCENE_BASES - {"BaseConfigScene"}
    replacements: list[tuple[int, int, str]] = []
    changed_classes: list[str] = []
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef):
            continue
        if node.name == "BaseConfigScene" or not re.match(r"Scene(?:_|\d)", node.name):
            continue
        base_names = [_class_base_name(base) for base in node.bases]
        if "BaseConfigScene" not in base_names:
            continue
        if not any(name in concrete_scene_bases for name in base_names if name):
            continue

        new_base_sources: list[str] = []
        seen_base_config = False
        changed = False
        for base, base_name in zip(node.bases, base_names):
            if base_name == "BaseConfigScene":
                if seen_base_config:
                    changed = True
                    continue
                new_base_sources.append("BaseConfigScene")
                seen_base_config = True
                continue
            if base_name in concrete_scene_bases:
                changed = True
                continue
            source = ast.get_source_segment(code, base)
            if source:
                new_base_sources.append(source)

        if not changed or not seen_base_config or not new_base_sources:
            continue
        start_span = _source_span_for_node(node.bases[0], lines, line_offsets)
        end_span = _source_span_for_node(node.bases[-1], lines, line_offsets)
        if not start_span or not end_span:
            continue
        replacements.append((start_span[0], end_span[1], ", ".join(new_base_sources)))
        changed_classes.append(node.name)

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    return current, f"Scene冗余基类MRO修复: {', '.join(changed_classes)}"


def _inject_voiceover_runtime_compat_helpers(code: str) -> Tuple[Optional[str], str]:
    """Install cheap BaseConfigScene fallbacks for recurring VoiceoverScene drift."""
    if "class BaseConfigScene" not in code:
        return None, ""

    needs_subcaption = "self.create_subcaption(" in code and "def create_subcaption" not in code
    needs_wrap_text = "self._wrap_generate_from_text(" in code and "def _wrap_generate_from_text" not in code
    needs_add_title = "self.add_title(" in code and "def add_title" not in code
    needs_create_title = (
        ("self.create_title(" in code or needs_add_title)
        and "def create_title" not in code
    )
    if not (
        needs_subcaption
        or needs_wrap_text
        or needs_create_title
        or needs_add_title
    ):
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines: list[str] = []
    if needs_subcaption:
        helper_lines.extend([
            "",
            f"{indent}def create_subcaption(self, text, duration=None, **kwargs):",
            f"{body}if hasattr(self, \"add_wrapped_subcaption\"):",
            f"{body}    return self.add_wrapped_subcaption(text, duration=duration, **kwargs)",
            f"{body}if hasattr(self, \"add_subcaption\"):",
            f"{body}    return self.add_subcaption(text, duration=duration, **kwargs)",
            f"{body}return None",
        ])
    if needs_wrap_text:
        helper_lines.extend([
            "",
            f"{indent}def _wrap_generate_from_text(self, text, **kwargs):",
            f"{body}return Text(str(text), **kwargs)",
        ])
    if needs_create_title:
        helper_lines.extend([
            "",
            f"{indent}def create_title(self, text, area=\"top\", font_size=42, color=None, **kwargs):",
            f"{body}cfg = globals().get(\"GlobalConfig\")",
            f"{body}title_color = color or getattr(cfg, \"TITLE_COLOR\", WHITE)",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    title = self.safe_text_box(text, area=area, font_size=font_size, color=title_color, **kwargs)",
            f"{body}else:",
            f"{body}    title = Text(str(text), font_size=font_size, color=title_color)",
            f"{body}if hasattr(self, \"layout_canvas\"):",
            f"{body}    title.move_to(self.layout_canvas(area)[\"center\"])",
            f"{body}return title",
        ])
    if needs_add_title:
        helper_lines.extend([
            "",
            f"{indent}def add_title(self, text, area=\"top\", font_size=42, color=None, **kwargs):",
            f"{body}title = self.create_title(text, area=area, font_size=font_size, color=color, **kwargs)",
            f"{body}line_color = color or getattr(self, \"TITLE_COLOR\", WHITE)",
            f"{body}try:",
            f"{body}    half_width = max(0.65, float(getattr(title, \"width\", 1.3)) * 0.42)",
            f"{body}except Exception:",
            f"{body}    half_width = 0.85",
            f"{body}underline = Line(LEFT * half_width, RIGHT * half_width, color=line_color, stroke_width=3)",
            f"{body}try:",
            f"{body}    underline.next_to(title, DOWN, buff=0.08)",
            f"{body}except Exception:",
            f"{body}    underline.shift(DOWN * 0.35)",
            f"{body}group = VGroup(title, underline)",
            f"{body}self.add(group)",
            f"{body}return group",
        ])

    lines = code.splitlines()
    lines[end:end] = helper_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    names = []
    if needs_subcaption:
        names.append("create_subcaption")
    if needs_wrap_text:
        names.append("_wrap_generate_from_text")
    if needs_create_title:
        names.append("create_title")
    if needs_add_title:
        names.append("add_title")
    return current, f"Voiceover运行时helper补全: {', '.join(names)}"


def _fix_bare_narrate_calls(code: str) -> Tuple[Optional[str], str]:
    """Route method-local ``narrate(...)`` calls through the scene instance."""
    if "narrate(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str]] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self._self_method_depth = 0

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            is_self_method = bool(node.args.args and node.args.args[0].arg == "self")
            if is_self_method:
                self._self_method_depth += 1
            self.generic_visit(node)
            if is_self_method:
                self._self_method_depth -= 1

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self.visit_FunctionDef(node)  # type: ignore[arg-type]

        def visit_Call(self, node: ast.Call) -> None:
            if (
                self._self_method_depth > 0
                and isinstance(node.func, ast.Name)
                and node.func.id == "narrate"
            ):
                span = _source_span_for_node(node.func, lines, line_offsets)
                if span:
                    replacements.append((span[0], span[1], "self.narrate"))
            self.generic_visit(node)

    Visitor().visit(tree)
    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True
    ):
        current = current[:start] + replacement + current[end:]
    return current, f"narrate裸调用修复: {len(replacements)}处"


def _class_range_by_name(code: str, class_name: str) -> tuple[int, int, str] | None:
    lines = code.splitlines()
    for index, line in enumerate(lines):
        match = re.match(
            rf"^(?P<indent>\s*)class\s+{re.escape(class_name)}\b.*:\s*$",
            line,
        )
        if not match:
            continue
        class_indent = match.group("indent")
        end = index + 1
        while end < len(lines):
            body_line = lines[end]
            if body_line.strip() and len(body_line) - len(body_line.lstrip()) <= len(class_indent):
                break
            end += 1
        return index, end, class_indent + "    "
    return None


def _class_defines_method(node: ast.ClassDef, method_name: str) -> bool:
    return any(
        isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
        and child.name == method_name
        for child in node.body
    )


def _class_uses_self_narrate(node: ast.ClassDef) -> bool:
    for child in ast.walk(node):
        if (
            isinstance(child, ast.Attribute)
            and isinstance(child.value, ast.Name)
            and child.value.id == "self"
            and child.attr == "narrate"
            and isinstance(child.ctx, ast.Load)
        ):
            return True
    return False


def _narrate_voiceover_helper_lines(indent: str) -> list[str]:
    body = indent + "    "
    return [
        "",
        f'{indent}def narrate(self, text="", **kwargs):',
        f'{body}voiceover_fn = getattr(self, "voiceover", None)',
        f"{body}if callable(voiceover_fn):",
        f"{body}    return voiceover_fn(text=text, **kwargs)",
        f"{body}class _MathPiNullNarration:",
        f"{body}    def __enter__(self_inner):",
        f"{body}        return None",
        f"{body}    def __exit__(self_inner, exc_type, exc, tb):",
        f"{body}        return False",
        f"{body}return _MathPiNullNarration()",
    ]


def _inject_narrate_voiceover_helper(code: str) -> Tuple[Optional[str], str]:
    """Route generated ``self.narrate(...)`` blocks to the project voiceover API."""
    if "self.narrate(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    class_nodes = [
        node for node in getattr(tree, "body", []) if isinstance(node, ast.ClassDef)
    ]
    base_node = next((node for node in class_nodes if node.name == "BaseConfigScene"), None)
    target_names: list[str] = []
    if base_node is not None:
        if _class_defines_method(base_node, "narrate"):
            return None, ""
        target_names = ["BaseConfigScene"]
    else:
        target_names = [
            node.name
            for node in class_nodes
            if _class_uses_self_narrate(node)
            and not _class_defines_method(node, "narrate")
        ]
    if not target_names:
        return None, ""

    lines = code.splitlines()
    inserted: list[str] = []
    for class_name in reversed(target_names):
        class_range = _class_range_by_name("\n".join(lines), class_name)
        if not class_range:
            continue
        _start, end, indent = class_range
        lines[end:end] = _narrate_voiceover_helper_lines(indent)
        inserted.append(class_name)
    if not inserted:
        return None, ""
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, "Voiceover narrate helper补全: " + ",".join(reversed(inserted))


def _inject_pythagorean_geometry_scene_helpers(code: str) -> Tuple[Optional[str], str]:
    """Inject deterministic geometry helpers for recurring Pythagorean scenes."""
    needs_intro = (
        "self.build_intro_triangle(" in code
        and "def build_intro_triangle" not in code
    )
    needs_area = (
        "self.build_area_proof_diagram(" in code
        and "def build_area_proof_diagram" not in code
    )
    if not (needs_intro or needs_area) or "class BaseConfigScene" not in code:
        return None, ""
    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines: list[str] = []
    if needs_intro:
        helper_lines.extend([
            "",
            f"{indent}def build_intro_triangle(self, numeric=False, **_kwargs):",
            f"{body}p0 = LEFT * 1.25 + DOWN * 0.75",
            f"{body}p1 = p0 + RIGHT * 2.5",
            f"{body}p2 = p0 + UP * 1.85",
            f"{body}triangle = Polygon(p0, p1, p2, color=getattr(self, \"MAIN_COLOR\", BLUE), stroke_width=4)",
            f"{body}triangle.set_fill(getattr(self, \"MAIN_COLOR\", BLUE), opacity=0.08)",
            f"{body}right_mark = RightAngle(Line(p0, p1), Line(p0, p2), length=0.28, color=getattr(self, \"ANNOTATION_COLOR\", YELLOW))",
            f"{body}a_text, b_text, c_text = (\"3\", \"4\", \"5\") if numeric else (\"a\", \"b\", \"c\")",
            f"{body}label_a = MathTex(a_text, font_size=34, color=getattr(self, \"SECONDARY_COLOR\", GREEN)).move_to((p0 + p1) / 2 + DOWN * 0.28)",
            f"{body}label_b = MathTex(b_text, font_size=34, color=getattr(self, \"SECONDARY_COLOR\", GREEN)).move_to((p0 + p2) / 2 + LEFT * 0.30)",
            f"{body}label_c = MathTex(c_text, font_size=34, color=getattr(self, \"ACCENT_COLOR\", YELLOW)).move_to((p1 + p2) / 2 + UP * 0.25 + RIGHT * 0.18)",
            f"{body}full_group = VGroup(triangle, right_mark, label_a, label_b, label_c)",
            f"{body}return full_group, triangle, right_mark, label_a, label_b, label_c",
        ])
    if needs_area:
        helper_lines.extend([
            "",
            f"{indent}def build_area_proof_diagram(self, **_kwargs):",
            f"{body}main_color = getattr(self, \"MAIN_COLOR\", BLUE)",
            f"{body}accent = getattr(self, \"ACCENT_COLOR\", YELLOW)",
            f"{body}secondary = getattr(self, \"SECONDARY_COLOR\", GREEN)",
            f"{body}big_square = Square(side_length=3.25, color=main_color, stroke_width=4)",
            f"{body}big_square.set_fill(main_color, opacity=0.04)",
            f"{body}base_tri = Polygon(LEFT * 1.35 + DOWN * 1.35, RIGHT * 1.35 + DOWN * 1.35, LEFT * 1.35 + UP * 0.55, color=secondary, stroke_width=2.8)",
            f"{body}base_tri.set_fill(secondary, opacity=0.14)",
            f"{body}triangles = VGroup(*[base_tri.copy().rotate(k * PI / 2, about_point=ORIGIN) for k in range(4)])",
            f"{body}inner_square = Square(side_length=1.08, color=accent, stroke_width=3).rotate(PI / 4)",
            f"{body}inner_square.set_fill(accent, opacity=0.10)",
            f"{body}right_marks = VGroup(*[RightAngle(Line(ORIGIN, RIGHT * 0.34), Line(ORIGIN, UP * 0.34), length=0.12, color=getattr(self, \"ANNOTATION_COLOR\", YELLOW)).shift(pos) for pos in (LEFT * 1.18 + DOWN * 1.18, RIGHT * 1.18 + DOWN * 1.18, RIGHT * 1.18 + UP * 1.18, LEFT * 1.18 + UP * 1.18)])",
            f"{body}diagram_labels = VGroup(",
            f"{body}    MathTex(r\"a+b\", font_size=26, color=main_color).next_to(big_square, UP, buff=0.12),",
            f"{body}    MathTex(r\"a\", font_size=24, color=secondary).move_to(DOWN * 1.55 + LEFT * 0.55),",
            f"{body}    MathTex(r\"b\", font_size=24, color=secondary).move_to(LEFT * 1.55 + DOWN * 0.45),",
            f"{body}    MathTex(r\"c^2\", font_size=28, color=accent).move_to(inner_square.get_center()),",
            f"{body})",
            f"{body}diagram = VGroup(big_square, triangles, inner_square, right_marks, diagram_labels)",
            f"{body}return diagram, big_square, triangles, inner_square, right_marks, diagram_labels",
        ])
    lines = code.splitlines()
    lines[end:end] = helper_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    names = []
    if needs_intro:
        names.append("build_intro_triangle")
    if needs_area:
        names.append("build_area_proof_diagram")
    return current, "勾股几何helper补全: " + ", ".join(names)


def _function_source_span(
    node: ast.AST,
    lines: list[str],
    line_offsets: list[int],
) -> Optional[tuple[int, int]]:
    lineno = getattr(node, "lineno", None)
    col_offset = getattr(node, "col_offset", None)
    end_lineno = getattr(node, "end_lineno", None)
    end_col_offset = getattr(node, "end_col_offset", None)
    if (
        lineno is None
        or col_offset is None
        or end_lineno is None
        or end_col_offset is None
    ):
        return None
    end_line = lines[end_lineno - 1]
    start = line_offsets[lineno - 1]
    end = line_offsets[end_lineno - 1] + _byte_col_to_char_col(end_line, end_col_offset)
    return start, end


def _right_angle_mark_method_source(indent: str, *, include_self: bool) -> str:
    body = indent + "    "
    args = (
        "self, vertex, dir1, dir2, size=0.25, color=None, **_kwargs"
        if include_self
        else "vertex, dir1, dir2, size=0.25, color=None, **_kwargs"
    )
    color_expr = (
        'color or getattr(self, "SECONDARY_COLOR", globals().get("YELLOW", WHITE))'
        if include_self
        else 'color or globals().get("YELLOW", WHITE)'
    )
    return "\n".join([
        f"{indent}def create_right_angle_mark({args}):",
        f"{body}if \"np\" not in globals():",
        f"{body}    globals()[\"np\"] = __import__(\"numpy\")",
        f"{body}vertex_arr = np.array(vertex, dtype=float)",
        f"{body}dir1_arr = np.array(dir1, dtype=float)",
        f"{body}dir2_arr = np.array(dir2, dtype=float)",
        f"{body}raw_dir1_arr = dir1_arr.copy()",
        f"{body}raw_dir2_arr = dir2_arr.copy()",
        f"{body}point_dir1 = raw_dir1_arr - vertex_arr",
        f"{body}point_dir2 = raw_dir2_arr - vertex_arr",
        f"{body}def _unit(vec):",
        f"{body}    norm = float(np.linalg.norm(vec))",
        f"{body}    return vec / norm if norm > 1e-9 else vec",
        f"{body}def _orth_score(v1, v2):",
        f"{body}    u1 = _unit(v1)",
        f"{body}    u2 = _unit(v2)",
        f"{body}    return abs(float(np.dot(u1, u2))) if np.linalg.norm(u1) > 1e-9 and np.linalg.norm(u2) > 1e-9 else 1.0",
        f"{body}if _orth_score(point_dir1, point_dir2) + 1e-6 < _orth_score(raw_dir1_arr, raw_dir2_arr):",
        f"{body}    dir1_arr = dir1_arr - vertex_arr",
        f"{body}    dir2_arr = dir2_arr - vertex_arr",
        f"{body}d1 = _unit(dir1_arr) * float(size or 0.25)",
        f"{body}d2 = _unit(dir2_arr) * float(size or 0.25)",
        f"{body}corner = vertex_arr + d1 + d2",
        f"{body}mark_color = {color_expr}",
        f"{body}return VGroup(",
        f"{body}    Line(start=vertex_arr + d1, end=corner, color=mark_color, stroke_width=2),",
        f"{body}    Line(start=corner, end=vertex_arr + d2, color=mark_color, stroke_width=2),",
        f"{body})",
    ])


_LOCAL_NUMPY_IMPORT_SCOPE_RE = re.compile(
    r"(?m)^(?P<indent>[ \t]+)if\s+[\"']np[\"']\s+not\s+in\s+globals\(\):\s*\n"
    r"(?P<child>[ \t]+)import\s+numpy\s+as\s+np\s*$"
)


def _fix_local_numpy_import_scope(code: str) -> Tuple[Optional[str], str]:
    """Avoid function-local ``import numpy as np`` shadowing global ``np``.

    In Python, an ``import numpy as np`` statement inside a function marks ``np``
    as a local variable for the whole function. If the import is guarded by
    ``if "np" not in globals()`` and the module already imported ``np``,
    the branch is skipped and later ``np.array(...)`` raises UnboundLocalError.
    """
    if "import numpy as np" not in code or "not in globals()" not in code:
        return None, ""

    def _replace(match: re.Match[str]) -> str:
        indent = match.group("indent")
        child = match.group("child")
        return (
            f'{indent}if "np" not in globals():\n'
            f'{child}globals()["np"] = __import__("numpy")'
        )

    current, changed = _LOCAL_NUMPY_IMPORT_SCOPE_RE.subn(_replace, code)
    if changed <= 0 or current == code:
        return None, ""
    return current, f"函数内numpy导入作用域修复: {changed}处"


def _fix_create_right_angle_mark_contract(code: str) -> Tuple[Optional[str], str]:
    """Normalize BaseConfigScene right-angle helper scope and point/vector inputs."""
    if (
        "create_right_angle_mark(" not in code
        or "class BaseConfigScene" not in code
    ):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    has_defined_right_angle_mark_alias = any(
        isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == "RightAngleMark"
        for node in getattr(tree, "body", [])
    )
    lines, line_offsets = _line_offsets(code)
    has_scene_right_angle_call = False
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef) or node.name == "BaseConfigScene":
            continue
        if "BaseConfigScene" not in [_class_base_name(base) for base in node.bases]:
            continue
        for child in node.body:
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            first_arg = child.args.args[0].arg if child.args.args else ""
            if first_arg != "self":
                continue
            for call in ast.walk(child):
                if not isinstance(call, ast.Call):
                    continue
                func = call.func
                if isinstance(func, ast.Name) and func.id == "create_right_angle_mark":
                    has_scene_right_angle_call = True
                    break
                if (
                    isinstance(func, ast.Name)
                    and func.id == "RightAngleMark"
                    and not has_defined_right_angle_mark_alias
                ):
                    has_scene_right_angle_call = True
                    break
                if (
                    isinstance(func, ast.Attribute)
                    and func.attr == "create_right_angle_mark"
                    and isinstance(func.value, ast.Name)
                    and func.value.id == "self"
                ):
                    has_scene_right_angle_call = True
                    break
            if has_scene_right_angle_call:
                break
        if has_scene_right_angle_call:
            break
    if not has_scene_right_angle_call:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    patched_method = False
    rewritten_calls = 0
    rewritten_alias_calls = 0
    base_has_helper = False

    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef) or node.name != "BaseConfigScene":
            continue
        for child in node.body:
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if child.name != "create_right_angle_mark":
                continue
            base_has_helper = True
            span = _function_source_span(child, lines, line_offsets)
            if not span:
                break
            has_staticmethod = any(
                isinstance(deco, ast.Name) and deco.id == "staticmethod"
                for deco in child.decorator_list
            )
            first_arg = child.args.args[0].arg if child.args.args else ""
            include_self = not has_staticmethod and first_arg == "self"
            indent = re.match(r"^(\s*)", lines[child.lineno - 1]).group(1)
            source = _right_angle_mark_method_source(indent, include_self=include_self)
            original = code[span[0]:span[1]]
            if "point_dir1 = dir1_arr - vertex_arr" not in original:
                replacements.append((span[0], span[1], source))
                patched_method = True
            break
        break

    if not base_has_helper:
        return None, ""

    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef) or node.name == "BaseConfigScene":
            continue
        if "BaseConfigScene" not in [_class_base_name(base) for base in node.bases]:
            continue
        for child in node.body:
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            first_arg = child.args.args[0].arg if child.args.args else ""
            if first_arg != "self":
                continue
            for call in ast.walk(child):
                if not (isinstance(call, ast.Call) and isinstance(call.func, ast.Name)):
                    continue
                if call.func.id == "create_right_angle_mark":
                    replacement_name = "self.create_right_angle_mark"
                    rewritten_calls += 1
                elif call.func.id == "RightAngleMark" and not has_defined_right_angle_mark_alias:
                    replacement_name = "self.create_right_angle_mark"
                    rewritten_alias_calls += 1
                else:
                    continue
                span = _source_span_for_node(call.func, lines, line_offsets)
                if not span:
                    continue
                replacements.append((span[0], span[1], replacement_name))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    parts: list[str] = []
    if rewritten_calls:
        parts.append(f"裸调用转self: {rewritten_calls}处")
    if rewritten_alias_calls:
        parts.append(f"RightAngleMark别名修复: {rewritten_alias_calls}处")
    if patched_method:
        parts.append("点/向量参数兼容")
    return current, "create_right_angle_mark裸调用修复: " + ", ".join(parts)


def _fix_add_title_tuple_unpack(code: str) -> Tuple[Optional[str], str]:
    """Make ``title, underline = self.add_title(...)`` work with single-return helpers."""
    if "self.add_title(" not in code or "," not in code:
        return None, ""

    pattern = re.compile(
        r"(?m)^(?P<indent>\s*)"
        r"(?P<title>[A-Za-z_][A-Za-z0-9_]*)\s*,\s*"
        r"(?P<underline>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
        r"self\.add_title\((?P<args>[^\n]*)\)\s*$"
    )
    counter = 0

    def repl(match: re.Match[str]) -> str:
        nonlocal counter
        counter += 1
        indent = match.group("indent")
        title_name = match.group("title")
        underline_name = match.group("underline")
        args = match.group("args")
        temp_name = f"__mathpi_title_pair_{counter}"
        line_half_width = (
            f"max(0.65, float(getattr({title_name}, \"width\", 1.3)) * 0.42)"
        )
        lines = [
            f"{indent}{temp_name} = self.add_title({args})",
            f"{indent}if isinstance({temp_name}, (tuple, list, VGroup)) and len({temp_name}) >= 2:",
            f"{indent}    {title_name}, {underline_name} = {temp_name}[0], {temp_name}[1]",
            f"{indent}else:",
            f"{indent}    {title_name} = {temp_name}",
            f"{indent}    {underline_name} = Line(LEFT * {line_half_width}, RIGHT * {line_half_width}, color=getattr(self, \"TITLE_COLOR\", WHITE), stroke_width=3)",
            f"{indent}    try:",
            f"{indent}        {underline_name}.next_to({title_name}, DOWN, buff=0.08)",
            f"{indent}    except Exception:",
            f"{indent}        {underline_name}.shift(DOWN * 0.35)",
            f"{indent}    self.add({underline_name})",
        ]
        return "\n".join(lines)

    current, count = pattern.subn(repl, code)
    if count == 0:
        return None, ""
    return current, f"add_title双返回解包兜底: {count}处"


def _string_literal_value(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        parts: list[str] = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
            else:
                return None
        return "".join(parts)
    return None


def _safe_text_box_first_arg_literal(node: ast.AST) -> str | None:
    if not isinstance(node, ast.Call) or not node.args:
        return None
    func = node.func
    if not (
        isinstance(func, ast.Attribute)
        and func.attr == "safe_text_box"
    ):
        return None
    return _string_literal_value(node.args[0])


def _extract_question_layout_defaults(
    code: str,
    prompt_context: str | None = None,
) -> tuple[list[str], list[str]]:
    """Extract recurring question paragraphs/options from the first intro scene."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        tree = None

    paragraph_by_name: dict[str, str] = {}
    option_by_name: dict[str, str] = {}
    if tree is not None:
        for cls in getattr(tree, "body", []):
            if not isinstance(cls, ast.ClassDef):
                continue
            if not re.match(r"Scene(?:_|\d)", cls.name):
                continue
            for stmt in ast.walk(cls):
                if not isinstance(stmt, ast.Assign):
                    continue
                value_literal = _string_literal_value(stmt.value)
                safe_text_literal = _safe_text_box_first_arg_literal(stmt.value)
                for target in stmt.targets:
                    if not isinstance(target, ast.Name):
                        continue
                    name = target.id
                    if re.fullmatch(r"p\d+_display", name) and value_literal:
                        paragraph_by_name[name] = value_literal
                        continue
                    if re.fullmatch(r"p\d+", name) and safe_text_literal:
                        paragraph_by_name.setdefault(
                            f"{name}_display",
                            safe_text_literal,
                        )
                        continue
                    if re.fullmatch(r"opt_[a-d]", name) and safe_text_literal:
                        option_by_name[name] = safe_text_literal
            if paragraph_by_name or option_by_name:
                break

    paragraphs = [
        value
        for _name, value in sorted(
            paragraph_by_name.items(),
            key=lambda item: (
                int(re.search(r"\d+", item[0]).group(0))
                if re.search(r"\d+", item[0])
                else 999
            ),
        )
    ]
    options = [
        option_by_name[name]
        for name in ("opt_a", "opt_b", "opt_c", "opt_d")
        if name in option_by_name
    ]

    if (not paragraphs or not options) and prompt_context:
        prompt = _normalize_prompt_text(prompt_context)
        question_part = re.split(r"\n\s*(?:答案|解析|解答)\s*[：:]", prompt, maxsplit=1)[0]
        option_matches = list(_OPTION_RE.finditer(question_part))
        if option_matches and not options:
            options = [
                "{}. {}".format(
                    match.group(1).upper(),
                    re.sub(r"\s+", " ", match.group(2)).strip(),
                )
                for match in option_matches[:4]
                if match.group(2).strip()
            ]
        if option_matches and not paragraphs:
            stem = question_part[: option_matches[0].start()].strip()
            stem_parts = [
                part.strip()
                for part in re.split(r"\n+", stem)
                if part.strip() and not re.match(r"^\s*(?:题目|问题)\s*[：:]\s*$", part)
            ]
            if not stem_parts and stem:
                stem_parts = [stem]
            paragraphs = stem_parts[:3]
    return paragraphs[:4], options[:4]


_CORRECT_ANSWER_RE = re.compile(r"(?:正确答案|答案)\s*(?:为|是|：|:)?\s*([A-D])")
_OPTION_RE = re.compile(
    r"(?:^|\n|\s{2,})([A-D])\s*[.．、]\s*(.*?)"
    r"(?=(?:\n|\s{2,})[A-D]\s*[.．、]\s*|\n\s*\n|$)",
    re.S,
)


def _normalize_prompt_text(prompt_context: str | None) -> str:
    return re.sub(r"[ \t\u3000]+", " ", (prompt_context or "").replace("\r\n", "\n").replace("\r", "\n"))


def _compact_inline_text(text: str) -> str:
    return re.sub(r"\s+", "", text or "").strip()


def _extract_correct_option_quote(prompt_context: str | None) -> tuple[str, str] | None:
    """Extract a deterministic quote anchor from fill-in quotation questions."""
    prompt = _normalize_prompt_text(prompt_context)
    if not prompt:
        return None
    if not re.search(r"习近平\s*总\s*书记\s*强调", prompt):
        return None

    answer_match = None
    for match in _CORRECT_ANSWER_RE.finditer(prompt):
        answer_match = match
    if not answer_match:
        return None
    answer = answer_match.group(1).upper()

    question_part = re.split(r"\n\s*\n", prompt, maxsplit=1)[0]
    options: dict[str, str] = {}
    for match in _OPTION_RE.finditer(question_part):
        letter = match.group(1).upper()
        option_text = _compact_inline_text(match.group(2))
        if option_text:
            options[letter] = option_text
    quote = options.get(answer)
    if not quote or len(quote) > 90:
        return None
    return "习近平总书记强调", quote


def _scene_quote_candidate_score(scene_text: str, quote: str) -> int:
    score = 0
    for token in {quote[:8], quote[-8:], "担当", "作为", "辩证", "横线", "选项"}:
        if token and token in scene_text:
            score += 1
    return score


def _inject_prompt_quote_anchor(
    code: str,
    prompt_context: str | None,
) -> Tuple[Optional[str], str]:
    quote_parts = _extract_correct_option_quote(prompt_context)
    if not quote_parts:
        return None, ""
    speaker, quote = quote_parts
    if speaker in code and quote in code:
        return None, ""

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines()
    best: tuple[int, int, str] | None = None
    for cls in tree.body:
        if not isinstance(cls, ast.ClassDef) or not re.match(r"Scene(?:_|\d)", cls.name):
            continue
        if getattr(cls, "end_lineno", None) is None:
            continue
        scene_text = "\n".join(lines[cls.lineno - 1: cls.end_lineno])
        score = _scene_quote_candidate_score(scene_text, quote)
        if score <= 0:
            continue
        construct = next(
            (node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "construct"),
            None,
        )
        if construct is None:
            continue
        insert_after = None
        for stmt in construct.body[:5]:
            if (
                isinstance(stmt, ast.Expr)
                and isinstance(stmt.value, ast.Call)
                and isinstance(stmt.value.func, ast.Attribute)
                and stmt.value.func.attr == "setup_layout"
            ):
                insert_after = getattr(stmt, "end_lineno", stmt.lineno)
                break
        if insert_after is None and construct.body:
            insert_after = getattr(construct.body[0], "end_lineno", construct.body[0].lineno)
        if insert_after is None:
            insert_after = construct.lineno
        indent_match = re.match(r"^(\s*)", lines[min(insert_after, len(lines) - 1)])
        indent = indent_match.group(1) if indent_match else "        "
        candidate = (score, insert_after, indent)
        if best is None or candidate[0] > best[0]:
            best = candidate
    if best is None:
        return None, ""

    _score, insert_after, indent = best
    anchor_text = f"{speaker}：\n“{quote}”"
    anchor_literal = json.dumps(anchor_text, ensure_ascii=False)
    insert_lines = [
        f"{indent}# mathpi deterministic quote anchor from prompt answer",
        f"{indent}try:",
        f"{indent}    quote_anchor = self.safe_text_box({anchor_literal}, area=\"none\", font_size=18, color=getattr(self, \"SECONDARY_COLOR\", GREEN), width=5.8, max_height=0.92)",
        f"{indent}except Exception:",
        f"{indent}    quote_anchor = Text({anchor_literal}, font_size=18, color=getattr(self, \"SECONDARY_COLOR\", GREEN), line_spacing=0.8)",
        f"{indent}    if getattr(quote_anchor, \"width\", 0) > 5.8:",
        f"{indent}        quote_anchor.scale_to_fit_width(5.8)",
        f"{indent}try:",
        f"{indent}    quote_anchor.to_edge(DOWN, buff=0.35)",
        f"{indent}except Exception:",
        f"{indent}    quote_anchor.move_to(DOWN * 2.85)",
        f"{indent}self.add(quote_anchor)",
    ]
    lines[insert_after:insert_after] = insert_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    return current, "题干正确引语锚点补全: 1处"


def _fix_next_to_align_to_keyword(code: str) -> Tuple[Optional[str], str]:
    """Manim CE next_to has no align_to kwarg; chain align_to after placement."""
    if "align_to" not in code or ".next_to(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "next_to"
            and node.args
        ):
            continue
        align_keyword = next((kw for kw in node.keywords if kw.arg == "align_to"), None)
        if align_keyword is None:
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        target_src = ast.get_source_segment(code, node.args[0]) or ast.unparse(node.args[0])
        align_src = (
            ast.get_source_segment(code, align_keyword.value)
            or ast.unparse(align_keyword.value)
        )
        original_keywords = node.keywords
        node.keywords = [kw for kw in node.keywords if kw.arg != "align_to"]
        try:
            next_to_src = ast.unparse(node)
        finally:
            node.keywords = original_keywords
        replacement = f"{next_to_src}.align_to({target_src}, {align_src})"
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"next_to align_to兼容修复: {len(replacements)}处"


def _inject_exam_question_runtime_helpers(
    code: str,
    prompt_context: str | None = None,
) -> Tuple[Optional[str], str]:
    """Install fallbacks for recurring multiple-choice question scene helpers."""
    if "class BaseConfigScene" not in code:
        return None, ""

    needs_draw_layout_base = (
        "self.draw_layout_base(" in code and "def draw_layout_base" not in code
    )
    needs_show_title = "self.show_title(" in code and "def show_title" not in code
    needs_get_stem = "self.get_stem(" in code and "def get_stem" not in code
    needs_create_options = (
        "self.create_options(" in code and "def create_options" not in code
    )
    needs_draw_question_and_choices = (
        "self.draw_question_and_choices(" in code
        and "def draw_question_and_choices" not in code
    )
    needs_get_analysis_card = (
        "self.get_analysis_card(" in code and "def get_analysis_card" not in code
    )
    needs_get_option_highlight = (
        "self.get_option_highlight(" in code and "def get_option_highlight" not in code
    )
    needs_get_check_mark = (
        "self.get_check_mark(" in code and "def get_check_mark" not in code
    )
    needs_get_check = "self.get_check(" in code and "def get_check" not in code
    needs_get_cross_mark = (
        "self.get_cross_mark(" in code and "def get_cross_mark" not in code
    )
    needs_get_checkmark = (
        "self.get_checkmark(" in code and "def get_checkmark" not in code
    )
    needs_get_cross = "self.get_cross(" in code and "def get_cross" not in code
    needs_get_quote_box = (
        "self.get_quote_box(" in code and "def get_quote_box" not in code
    )
    needs_show_law_card = (
        "self.show_law_card(" in code and "def show_law_card" not in code
    )
    needs_rebuild_question_layout = (
        "self.rebuild_question_layout(" in code
        and "def rebuild_question_layout" not in code
    )
    needs_get_stamp = "self.get_stamp(" in code and "def get_stamp" not in code
    needs_choice_marker = (
        "self.choice_marker(" in code and "def choice_marker" not in code
    )
    if not (
        needs_draw_layout_base
        or needs_show_title
        or needs_get_stem
        or needs_create_options
        or needs_draw_question_and_choices
        or needs_get_analysis_card
        or needs_get_option_highlight
        or needs_get_check_mark
        or needs_get_check
        or needs_get_cross_mark
        or needs_get_checkmark
        or needs_get_cross
        or needs_get_quote_box
        or needs_show_law_card
        or needs_rebuild_question_layout
        or needs_get_stamp
        or needs_choice_marker
    ):
        return None, ""

    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines: list[str] = []
    default_paragraphs, default_options = _extract_question_layout_defaults(
        code,
        prompt_context=prompt_context,
    )
    paragraphs_literal = json.dumps(
        default_paragraphs
        or [
            "题干第一句：请根据语境分析空格。",
            "题干第二句：结合选项逐步排除。",
        ],
        ensure_ascii=False,
    )
    options_literal = json.dumps(
        default_options
        or ["A. 选项A", "B. 选项B", "C. 选项C", "D. 选项D"],
        ensure_ascii=False,
    )

    if needs_show_title:
        helper_lines.extend([
            "",
            f'{indent}def show_title(self, text, area="top", font_size=34, color=None, add=True, **kwargs):',
            f"{body}title_color = color or getattr(self, \"TITLE_COLOR\", getattr(self, \"MAIN_COLOR\", WHITE))",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    title = self.safe_text_box(text, area=area, font_size=font_size, color=title_color, **kwargs)",
            f"{body}else:",
            f"{body}    title = Text(str(text), font_size=font_size, color=title_color)",
            f"{body}try:",
            f"{body}    if hasattr(self, \"layout_canvas\"):",
            f"{body}        title.move_to(self.layout_canvas(area).get(\"center\", UP * 3.2))",
            f"{body}    else:",
            f"{body}        title.to_edge(UP, buff=0.35)",
            f"{body}except Exception:",
            f"{body}    title.to_edge(UP, buff=0.35)",
            f"{body}if add:",
            f"{body}    self.add(title)",
            f"{body}return title",
        ])
    if needs_draw_layout_base:
        helper_lines.extend([
            "",
            f"{indent}def draw_layout_base(self, **_kwargs):",
            f"{body}return VGroup()",
        ])
    if needs_get_stem:
        helper_lines.extend([
            "",
            f'{indent}def get_stem(self, text="题干与选项", area="left", font_size=18, width=None, **_kwargs):',
            f"{body}max_width = width or 5.4",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    stem = self.safe_text_box(text, area=\"none\", font_size=font_size, color=getattr(self, \"PRIMARY_TEXT\", WHITE), width=max_width)",
            f"{body}else:",
            f"{body}    stem = Text(str(text), font_size=font_size, color=getattr(self, \"PRIMARY_TEXT\", WHITE), line_spacing=0.8)",
            f"{body}try:",
            f"{body}    if getattr(stem, \"width\", 0) > max_width:",
            f"{body}        stem.scale_to_fit_width(max_width)",
            f"{body}    stem.to_edge(LEFT, buff=0.65).shift(UP * 2.15)",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}return stem",
        ])
    if needs_create_options:
        helper_lines.extend([
            "",
            f'{indent}def create_options(self, options=None, area="left", font_size=18, width=5.4, **_kwargs):',
            f"{body}raw_options = list(options or [\"A\", \"B\", \"C\", \"D\"])",
            f"{body}cards = VGroup()",
            f"{body}for index, raw in enumerate(raw_options[:4]):",
            f"{body}    label = str(raw)",
            f"{body}    if len(label) == 1 and label in \"ABCD\":",
            f"{body}        label = f\"{{label}}. 选项{{label}}\"",
            f"{body}    txt = Text(label, font_size=font_size, color=getattr(self, \"PRIMARY_TEXT\", WHITE), line_spacing=0.8)",
            f"{body}    if getattr(txt, \"width\", 0) > width - 0.35:",
            f"{body}        txt.scale_to_fit_width(width - 0.35)",
            f"{body}    box = RoundedRectangle(width=width, height=max(0.5, txt.height + 0.22), corner_radius=0.08, stroke_color=getattr(self, \"MUTED_COLOR\", GRAY), stroke_width=1.5, fill_color=getattr(self, \"BG_COLOR\", BLACK), fill_opacity=0.04)",
            f"{body}    txt.move_to(box.get_center())",
            f"{body}    cards.add(VGroup(box, txt))",
            f"{body}while len(cards.submobjects) < 4:",
            f"{body}    label = \"ABCD\"[len(cards.submobjects)]",
            f"{body}    txt = Text(f\"{{label}}. 选项{{label}}\", font_size=font_size, color=getattr(self, \"PRIMARY_TEXT\", WHITE))",
            f"{body}    box = RoundedRectangle(width=width, height=0.58, corner_radius=0.08, stroke_color=getattr(self, \"MUTED_COLOR\", GRAY), stroke_width=1.5, fill_opacity=0.04)",
            f"{body}    txt.move_to(box.get_center())",
            f"{body}    cards.add(VGroup(box, txt))",
            f"{body}cards.arrange(DOWN, aligned_edge=LEFT, buff=0.16)",
            f"{body}try:",
            f"{body}    cards.to_edge(LEFT, buff=0.65).shift(DOWN * 0.65)",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}return cards",
        ])
    if needs_draw_question_and_choices:
        helper_lines.extend([
            "",
            f'{indent}def draw_question_and_choices(self, paragraphs=None, options=None, area="left", stem_width=None, option_width=None, font_size=16, add=False, **_kwargs):',
            f"{body}primary = getattr(self, \"PRIMARY_TEXT\", globals().get(\"BLACK\", WHITE))",
            f"{body}muted = getattr(self, \"MUTED_COLOR\", globals().get(\"GRAY\", primary))",
            f"{body}bg = getattr(self, \"BG_COLOR\", globals().get(\"WHITE\", BLACK))",
            f"{body}accent = getattr(self, \"EMPHASIS_COLOR\", getattr(self, \"SECONDARY_COLOR\", globals().get(\"YELLOW\", primary)))",
            f"{body}raw_paragraphs = list(paragraphs or {paragraphs_literal})",
            f"{body}raw_options = list(options or {options_literal})",
            f"{body}while len(raw_options) < 4:",
            f"{body}    label = \"ABCD\"[len(raw_options)]",
            f"{body}    raw_options.append(f\"{{label}}. 选项{{label}}\")",
            f"{body}try:",
            f"{body}    zone = self.layout_canvas(area) if hasattr(self, \"layout_canvas\") else {{\"center\": LEFT * 3.0, \"width\": 5.8, \"height\": 5.7}}",
            f"{body}except Exception:",
            f"{body}    zone = {{\"center\": LEFT * 3.0, \"width\": 5.8, \"height\": 5.7}}",
            f"{body}zone_center = zone.get(\"center\", LEFT * 3.0)",
            f"{body}zone_width = float(zone.get(\"width\", 5.8) or 5.8)",
            f"{body}card_width = float(stem_width or option_width or min(5.9, max(3.8, zone_width - 0.25)))",
            f"{body}question_text = \"\\n\".join(str(part) for part in raw_paragraphs[:3] if str(part).strip()) or \"题干与材料信息\"",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    q_text = self.safe_text_box(question_text, area=\"none\", font_size=max(12, int(font_size) - 1), color=primary, width=card_width - 0.36, max_height=1.75)",
            f"{body}else:",
            f"{body}    q_text = Text(question_text, font_size=max(12, int(font_size) - 1), color=primary, line_spacing=0.82)",
            f"{body}try:",
            f"{body}    if getattr(q_text, \"width\", 0) > card_width - 0.36:",
            f"{body}        q_text.scale_to_fit_width(card_width - 0.36)",
            f"{body}    if getattr(q_text, \"height\", 0) > 1.75:",
            f"{body}        q_text.scale_to_fit_height(1.75)",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}q_box_shape = RoundedRectangle(width=card_width, height=max(0.72, float(getattr(q_text, \"height\", 0.4)) + 0.32), corner_radius=0.1, stroke_color=accent, stroke_width=2, fill_color=bg, fill_opacity=0.055)",
            f"{body}q_text.move_to(q_box_shape.get_center())",
            f"{body}question_card = VGroup(q_box_shape, q_text)",
            f"{body}choices_group = VGroup()",
            f"{body}for index, raw in enumerate(raw_options[:4]):",
            f"{body}    label = str(raw).strip()",
            f"{body}    if label and label[0].upper() in \"ABCD\" and (len(label) == 1 or label[1] not in \".．、\"):",
            f"{body}        label = f\"{{label[0].upper()}}. {{label[1:].lstrip(' .．、')}}\"",
            f"{body}    elif not label[:1].upper() in \"ABCD\":",
            f"{body}        label = f\"{{'ABCD'[index]}}. {{label}}\"",
            f"{body}    option_text = Text(label, font_size=max(12, int(font_size) - 2), color=primary, line_spacing=0.82)",
            f"{body}    try:",
            f"{body}        if getattr(option_text, \"width\", 0) > card_width - 0.42:",
            f"{body}            option_text.scale_to_fit_width(card_width - 0.42)",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}    row_height = max(0.48, float(getattr(option_text, \"height\", 0.3)) + 0.2)",
            f"{body}    row_box = RoundedRectangle(width=card_width, height=row_height, corner_radius=0.08, stroke_color=muted, stroke_width=1.3, fill_color=bg, fill_opacity=0.035)",
            f"{body}    option_text.move_to(row_box.get_center())",
            f"{body}    choices_group.add(VGroup(row_box, option_text))",
            f"{body}choices_group.arrange(DOWN, aligned_edge=LEFT, buff=0.12)",
            f"{body}left_layout = VGroup(question_card, choices_group).arrange(DOWN, aligned_edge=LEFT, buff=0.28)",
            f"{body}left_layout.move_to(zone_center)",
            f"{body}try:",
            f"{body}    if hasattr(self, \"fit_to_canvas\"):",
            f"{body}        self.fit_to_canvas(left_layout, area=area, move=True)",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}if add:",
            f"{body}    self.add(left_layout)",
            f"{body}return left_layout, choices_group",
        ])
    if needs_get_option_highlight:
        helper_lines.extend([
            "",
            f"{indent}def get_option_highlight(self, option, color=None, buff=0.08, **_kwargs):",
            f"{body}return SurroundingRectangle(option, color=color or getattr(self, \"EMPHASIS_COLOR\", YELLOW), buff=buff, corner_radius=0.08)",
        ])
    if needs_get_analysis_card:
        helper_lines.extend([
            "",
            f'{indent}def get_analysis_card(self, title="", is_correct=False, text="", key_point="", **_kwargs):',
            f"{body}mark = \"正确\" if bool(is_correct) else \"排除\"",
            f"{body}content = \"\\n\".join([str(part) for part in (title, mark, text, key_point) if str(part).strip()])",
            f"{body}card_color = getattr(self, \"SECONDARY_COLOR\", GREEN) if bool(is_correct) else getattr(self, \"ACCENT_COLOR\", ORANGE)",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    label = self.safe_text_box(content, area=\"none\", font_size=17, color=getattr(self, \"PRIMARY_TEXT\", WHITE), width=5.4)",
            f"{body}else:",
            f"{body}    label = Text(content, font_size=17, color=getattr(self, \"PRIMARY_TEXT\", WHITE), line_spacing=0.78)",
            f"{body}if getattr(label, \"width\", 0) > 5.4:",
            f"{body}    label.scale_to_fit_width(5.4)",
            f"{body}if getattr(label, \"height\", 0) > 2.5:",
            f"{body}    label.scale_to_fit_height(2.5)",
            f"{body}box = RoundedRectangle(width=max(5.8, label.width + 0.35), height=max(1.05, label.height + 0.3), corner_radius=0.1, stroke_color=card_color, stroke_width=2, fill_color=card_color, fill_opacity=0.08)",
            f"{body}label.move_to(box.get_center())",
            f"{body}card = VGroup(box, label)",
            f"{body}card.to_edge(RIGHT, buff=0.65).shift(DOWN * 0.1)",
            f"{body}return card",
        ])
    if needs_get_check_mark:
        helper_lines.extend(["", *_choice_mark_helper_lines(indent, body, "get_check_mark")])
    if needs_get_check:
        helper_lines.extend(["", *_choice_mark_helper_lines(indent, body, "get_check")])
    if needs_get_checkmark:
        helper_lines.extend(["", *_choice_mark_helper_lines(indent, body, "get_checkmark")])
    if needs_get_cross_mark:
        helper_lines.extend(["", *_choice_mark_helper_lines(indent, body, "get_cross_mark")])
    if needs_get_cross:
        helper_lines.extend(["", *_choice_mark_helper_lines(indent, body, "get_cross")])
    if needs_get_quote_box:
        helper_lines.extend([
            "",
            f'{indent}def get_quote_box(self, text="", title="", area="right", width=5.1, max_height=4.4, **_kwargs):',
            f"{body}quote_color = getattr(self, \"SECONDARY_COLOR\", GREEN)",
            f"{body}text_color = getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}header = Text(str(title or \"材料原文\"), font_size=16, color=quote_color, weight=BOLD)",
            f"{body}if hasattr(self, \"safe_text_box\"):",
            f"{body}    body_text = self.safe_text_box(str(text), area=\"none\", font_size=16, color=text_color, max_width=max(0.5, width - 0.45), max_height=max(0.5, max_height - 0.75))",
            f"{body}else:",
            f"{body}    lines = str(text).split(\"\\n\") or [str(text)]",
            f"{body}    body_text = Paragraph(*lines, font_size=16, color=text_color, line_spacing=0.85)",
            f"{body}content = VGroup(header, body_text).arrange(DOWN, aligned_edge=LEFT, buff=0.16)",
            f"{body}box_width = max(float(width), float(getattr(content, \"width\", 0)) + 0.36)",
            f"{body}box_height = max(1.05, min(float(max_height), float(getattr(content, \"height\", 0)) + 0.36))",
            f"{body}if getattr(content, \"width\", 0) > box_width - 0.3:",
            f"{body}    content.scale_to_fit_width(box_width - 0.3)",
            f"{body}if getattr(content, \"height\", 0) > box_height - 0.3:",
            f"{body}    content.scale_to_fit_height(box_height - 0.3)",
            f"{body}box = RoundedRectangle(width=box_width, height=box_height, corner_radius=0.12, stroke_color=quote_color, stroke_width=2, fill_color=quote_color, fill_opacity=0.06)",
            f"{body}content.move_to(box.get_center())",
            f"{body}group = VGroup(box, content)",
            f"{body}if hasattr(self, \"layout_canvas\") and area not in (None, \"none\", \"raw\"):",
            f"{body}    group.move_to(self.layout_canvas(area).get(\"center\", ORIGIN))",
            f"{body}return group",
        ])
    if needs_show_law_card:
        helper_lines.extend([
            "",
            f'{indent}def show_law_card(self, title="", lines=None, area="right", width=None, max_height=None, **_kwargs):',
            f"{body}law_color = getattr(self, \"SECONDARY_COLOR\", GREEN)",
            f"{body}text_color = getattr(self, \"PRIMARY_TEXT\", WHITE)",
            f"{body}center = ORIGIN",
            f"{body}area_width = 5.2",
            f"{body}area_height = 4.3",
            f"{body}if isinstance(area, dict):",
            f"{body}    center = area.get(\"center\", ORIGIN)",
            f"{body}    area_width = float(area.get(\"width\", area_width) or area_width)",
            f"{body}    area_height = float(area.get(\"height\", area_height) or area_height)",
            f"{body}else:",
            f"{body}    try:",
            f"{body}        zone = self.layout_canvas(area) if hasattr(self, \"layout_canvas\") else {{}}",
            f"{body}        center = zone.get(\"center\", ORIGIN)",
            f"{body}        area_width = float(zone.get(\"width\", area_width) or area_width)",
            f"{body}        area_height = float(zone.get(\"height\", area_height) or area_height)",
            f"{body}    except Exception:",
            f"{body}        center = ORIGIN",
            f"{body}card_width = float(width or min(5.3, max(3.0, area_width - 0.25)))",
            f"{body}card_height = float(max_height or min(4.4, max(1.4, area_height - 0.25)))",
            f"{body}header = Text(str(title or \"法条依据\"), font_size=16, color=law_color, weight=BOLD)",
            f"{body}raw_lines = lines if isinstance(lines, (list, tuple)) else ([lines] if lines is not None else [])",
            f"{body}line_group = VGroup()",
            f"{body}for raw in raw_lines:",
            f"{body}    line = Text(str(raw), font_size=14, color=text_color, line_spacing=0.8)",
            f"{body}    if getattr(line, \"width\", 0) > card_width - 0.45:",
            f"{body}        line.scale_to_fit_width(card_width - 0.45)",
            f"{body}    line_group.add(line)",
            f"{body}if not line_group.submobjects:",
            f"{body}    line_group.add(Text(\"重点依据\", font_size=14, color=text_color))",
            f"{body}line_group.arrange(DOWN, aligned_edge=LEFT, buff=0.1)",
            f"{body}content = VGroup(header, line_group).arrange(DOWN, aligned_edge=LEFT, buff=0.18)",
            f"{body}if getattr(content, \"width\", 0) > card_width - 0.36:",
            f"{body}    content.scale_to_fit_width(card_width - 0.36)",
            f"{body}if getattr(content, \"height\", 0) > card_height - 0.36:",
            f"{body}    content.scale_to_fit_height(card_height - 0.36)",
            f"{body}box = RoundedRectangle(width=card_width, height=card_height, corner_radius=0.12, stroke_color=law_color, stroke_width=2, fill_color=law_color, fill_opacity=0.06)",
            f"{body}content.move_to(box.get_center())",
            f"{body}group = VGroup(box, header, line_group)",
            f"{body}group.move_to(center)",
            f"{body}if hasattr(self, \"clamp_to_canvas\"):",
            f"{body}    self.clamp_to_canvas(group)",
            f"{body}return group",
        ])
    if needs_rebuild_question_layout:
        helper_lines.extend([
            "",
            f"{indent}def rebuild_question_layout(self, paragraphs=None, options=None, add=True, **_kwargs):",
            f"{body}raw_paragraphs = list(paragraphs or {paragraphs_literal})",
            f"{body}raw_options = list(options or {options_literal})",
            f"{body}while len(raw_paragraphs) < 2:",
            f"{body}    raw_paragraphs.append(\"\")",
            f"{body}while len(raw_options) < 4:",
            f"{body}    label = \"ABCD\"[len(raw_options)]",
            f"{body}    raw_options.append(f\"{{label}}. 选项{{label}}\")",
            f"{body}title = self.safe_text_box(\"题目呈现与题型识别\", area=\"none\", font_size=26, color=getattr(self, \"TITLE_COLOR\", WHITE), width=5.8)",
            f"{body}try:",
            f"{body}    title.move_to(self.layout_canvas(\"title\").get(\"center\", UP * 3.1))",
            f"{body}except Exception:",
            f"{body}    title.to_edge(UP, buff=0.35)",
            f"{body}paragraph_mobs = VGroup()",
            f"{body}for raw in raw_paragraphs[:2]:",
            f"{body}    para = self.safe_text_box(str(raw), area=\"none\", font_size=15, color=getattr(self, \"PRIMARY_TEXT\", WHITE), width=5.8, max_height=1.55)",
            f"{body}    paragraph_mobs.add(para)",
            f"{body}paragraph_mobs.arrange(DOWN, aligned_edge=LEFT, buff=0.24)",
            f"{body}try:",
            f"{body}    paragraph_mobs.move_to(self.layout_canvas(\"left_col\").get(\"center\", LEFT * 3.0) + UP * 0.85)",
            f"{body}except Exception:",
            f"{body}    paragraph_mobs.to_edge(LEFT, buff=0.65).shift(UP * 0.8)",
            f"{body}option_mobs = VGroup()",
            f"{body}for raw in raw_options[:4]:",
            f"{body}    opt = self.safe_text_box(str(raw), area=\"none\", font_size=14, color=getattr(self, \"PRIMARY_TEXT\", WHITE), width=5.8, max_height=0.54)",
            f"{body}    option_mobs.add(opt)",
            f"{body}option_mobs.arrange(DOWN, aligned_edge=LEFT, buff=0.14)",
            f"{body}try:",
            f"{body}    option_mobs.next_to(paragraph_mobs, DOWN, buff=0.35, aligned_edge=LEFT)",
            f"{body}except Exception:",
            f"{body}    option_mobs.to_edge(LEFT, buff=0.65).shift(DOWN * 1.35)",
            f"{body}if add:",
            f"{body}    self.add(title, paragraph_mobs, option_mobs)",
            f"{body}p1 = paragraph_mobs[0]",
            f"{body}p2 = paragraph_mobs[1]",
            f"{body}opt_a = option_mobs[0]",
            f"{body}opt_b = option_mobs[1]",
            f"{body}opt_c = option_mobs[2]",
            f"{body}opt_d = option_mobs[3]",
            f"{body}return title, p1, p2, option_mobs, opt_a, opt_b, opt_c, opt_d",
        ])
    if needs_get_stamp:
        helper_lines.extend([
            "",
            f"{indent}def get_stamp(self, is_correct=True, text=None, color=None, **_kwargs):",
            f"{body}label = str(text or (\"正确\" if bool(is_correct) else \"错误\"))",
            f"{body}stamp_color = color or (getattr(self, \"SECONDARY_COLOR\", GREEN) if bool(is_correct) else getattr(self, \"ACCENT_COLOR\", RED))",
            f"{body}label_mob = Text(label, font_size=22, color=stamp_color, weight=BOLD)",
            f"{body}box = RoundedRectangle(width=max(1.25, label_mob.width + 0.38), height=max(0.62, label_mob.height + 0.22), corner_radius=0.12, stroke_color=stamp_color, stroke_width=2.5, fill_color=stamp_color, fill_opacity=0.08)",
            f"{body}label_mob.move_to(box.get_center())",
            f"{body}return VGroup(box, label_mob)",
        ])
    if needs_choice_marker:
        helper_lines.extend([
            "",
            f"{indent}def choice_marker(self, is_correct=True, color=None, scale=1.25, **_kwargs):",
            f"{body}if bool(is_correct):",
            f"{body}    if hasattr(self, \"get_check_mark\"):",
            f"{body}        return self.get_check_mark(color=color, scale=scale, **_kwargs)",
            f"{body}    try:",
            f"{body}        return MathTex(r\"\\checkmark\", color=color or getattr(self, \"SECONDARY_COLOR\", GREEN)).scale(scale)",
            f"{body}    except Exception:",
            f"{body}        return Text(\"OK\", font_size=26, color=color or getattr(self, \"SECONDARY_COLOR\", GREEN))",
            f"{body}if hasattr(self, \"get_cross_mark\"):",
            f"{body}    return self.get_cross_mark(color=color, scale=scale, **_kwargs)",
            f"{body}try:",
            f"{body}    return MathTex(r\"\\times\", color=color or getattr(self, \"ACCENT_COLOR\", RED)).scale(scale)",
            f"{body}except Exception:",
            f"{body}    return Text(\"X\", font_size=26, color=color or getattr(self, \"ACCENT_COLOR\", RED))",
        ])

    lines = code.splitlines()
    lines[end:end] = helper_lines
    current = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    names = []
    if needs_show_title:
        names.append("show_title")
    if needs_draw_layout_base:
        names.append("draw_layout_base")
    if needs_get_stem:
        names.append("get_stem")
    if needs_create_options:
        names.append("create_options")
    if needs_draw_question_and_choices:
        names.append("draw_question_and_choices")
    if needs_get_option_highlight:
        names.append("get_option_highlight")
    if needs_get_analysis_card:
        names.append("get_analysis_card")
    if needs_get_check_mark:
        names.append("get_check_mark")
    if needs_get_check:
        names.append("get_check")
    if needs_get_cross_mark:
        names.append("get_cross_mark")
    if needs_get_checkmark:
        names.append("get_checkmark")
    if needs_get_cross:
        names.append("get_cross")
    if needs_get_quote_box:
        names.append("get_quote_box")
    if needs_show_law_card:
        names.append("show_law_card")
    if needs_rebuild_question_layout:
        names.append("rebuild_question_layout")
    if needs_get_stamp:
        names.append("get_stamp")
    if needs_choice_marker:
        names.append("choice_marker")
    return current, f"选择题运行期helper补全: {', '.join(names)}"


def _choice_mark_helper_lines(indent: str, body: str, name: str) -> list[str]:
    is_check = "check" in name
    symbol = r"\checkmark" if is_check else r"\times"
    fallback = "OK" if is_check else "X"
    color_attr = "SECONDARY_COLOR" if is_check else "ACCENT_COLOR"
    color_default = "GREEN" if is_check else "RED"
    lines = [
        f"{indent}def {name}(self, target_or_color=None, scale=1.4, color=None, target=None, **_kwargs):",
        f"{body}mark_target = target if hasattr(target, \"get_center\") else None",
        f"{body}if mark_target is None and hasattr(target_or_color, \"get_center\"):",
        f"{body}    mark_target = target_or_color",
        f"{body}positional_color = None if mark_target is not None else target_or_color",
        f"{body}mark_color = color or positional_color or getattr(self, \"{color_attr}\", {color_default})",
    ]
    if name in {"get_check", "get_checkmark"}:
        lines.extend([
            f"{body}if mark_target is None and color is None and hasattr(self, \"get_check_mark\"):",
            f"{body}    return self.get_check_mark(color=mark_color, scale=scale, **_kwargs)",
        ])
    if name == "get_cross":
        lines.extend([
            f"{body}if mark_target is None and color is None and hasattr(self, \"get_cross_mark\"):",
            f"{body}    return self.get_cross_mark(color=mark_color, scale=scale, **_kwargs)",
        ])
    lines.extend([
        f"{body}try:",
        f"{body}    mark = MathTex(r\"{symbol}\", color=mark_color).scale(scale)",
        f"{body}except Exception:",
        f"{body}    mark = Text(\"{fallback}\", font_size=28, color=mark_color)",
        f"{body}if mark_target is not None:",
        f"{body}    try:",
        f"{body}        mark.move_to(mark_target.get_center())",
        f"{body}    except Exception:",
        f"{body}        pass",
        f"{body}return mark",
    ])
    return lines


def _fix_choice_mark_helper_mobject_targets(code: str) -> Tuple[Optional[str], str]:
    """Make generated check/cross helpers accept a target mobject as first arg."""
    if not any(token in code for token in ("self.get_cross(", "self.get_check(", "self.get_checkmark(", "self.get_cross_mark(", "self.get_check_mark(")):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""
    replacements: list[tuple[int, int, str]] = []
    target_names = {"get_check_mark", "get_check", "get_checkmark", "get_cross_mark", "get_cross"}
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef) or node.name not in target_names:
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        span = (code.rfind("\n", 0, span[0]) + 1, span[1])
        indent = " " * int(getattr(node, "col_offset", 0))
        body = indent + "    "
        replacements.append((span[0], span[1], "\n".join(_choice_mark_helper_lines(indent, body, node.name))))
    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    return current, f"选择题勾叉目标对象合同修复: {len(replacements)}处"


def _create_left_column_helper_lines(indent: str, body: str) -> list[str]:
    return [
        f'{indent}def create_left_column(self, items=None, highlight_index=None, area="left", width=3.6, font_size=18, title="选项列", **_kwargs):',
        f"{body}if isinstance(items, (list, tuple)):",
        f"{body}    raw_items = list(items)",
        f"{body}elif items is None:",
        f"{body}    raw_items = []",
        f"{body}else:",
        f"{body}    raw_items = [str(items)]",
        f"{body}if not raw_items and title:",
        f"{body}    raw_items = [str(title)]",
        f"{body}while len(raw_items) < 5:",
        f"{body}    label = \"ABCDE\"[len(raw_items)] if len(raw_items) < 5 else str(len(raw_items) + 1)",
        f"{body}    raw_items.append(f\"{{label}}. 选项{{label}}\")",
        f"{body}primary = getattr(self, \"PRIMARY_TEXT\", globals().get(\"BLACK\", WHITE))",
        f"{body}muted = getattr(self, \"MUTED_COLOR\", globals().get(\"GRAY\", primary))",
        f"{body}accent = getattr(self, \"SECONDARY_COLOR\", getattr(self, \"ACCENT_COLOR\", globals().get(\"GREEN\", primary)))",
        f"{body}bg = getattr(self, \"BG_COLOR\", globals().get(\"WHITE\", BLACK))",
        f"{body}try:",
        f"{body}    if isinstance(highlight_index, str) and highlight_index.strip().upper() in \"ABCDE\":",
        f"{body}        active_index = \"ABCDE\".index(highlight_index.strip().upper())",
        f"{body}    else:",
        f"{body}        active_index = int(highlight_index) if highlight_index is not None else -1",
        f"{body}except Exception:",
        f"{body}    active_index = -1",
        f"{body}rows = VGroup()",
        f"{body}for index, raw in enumerate(raw_items[:5]):",
        f"{body}    row_color = accent if index == active_index else muted",
        f"{body}    text_color = accent if index == active_index else primary",
        f"{body}    label = str(raw)",
        f"{body}    try:",
        f"{body}        text = Text(label, font_size=int(font_size), color=text_color, line_spacing=0.82)",
        f"{body}    except Exception:",
        f"{body}        text = Text(label, font_size=18, color=text_color)",
        f"{body}    try:",
        f"{body}        if getattr(text, \"width\", 0) > float(width) - 0.42:",
        f"{body}            text.scale_to_fit_width(max(0.4, float(width) - 0.42))",
        f"{body}    except Exception:",
        f"{body}        pass",
        f"{body}    height = max(0.46, float(getattr(text, \"height\", 0.28)) + 0.22)",
        f"{body}    box = RoundedRectangle(width=float(width), height=height, corner_radius=0.08, stroke_color=row_color, stroke_width=2 if index == active_index else 1.2, fill_color=row_color if index == active_index else bg, fill_opacity=0.10 if index == active_index else 0.035)",
        f"{body}    try:",
        f"{body}        text.move_to(box.get_center())",
        f"{body}    except Exception:",
        f"{body}        pass",
        f"{body}    row = VGroup(box, text)",
        f"{body}    if index == active_index:",
        f"{body}        try:",
        f"{body}            row.set_color(accent)",
        f"{body}        except Exception:",
        f"{body}            pass",
        f"{body}    rows.add(row)",
        f"{body}try:",
        f"{body}    rows.arrange(DOWN, aligned_edge=LEFT, buff=0.12)",
        f"{body}except Exception:",
        f"{body}    pass",
        f"{body}try:",
        f"{body}    if hasattr(self, \"layout_canvas\") and area not in (None, \"none\", \"raw\"):",
        f"{body}        rows.move_to(self.layout_canvas(area).get(\"center\", LEFT * 3.0))",
        f"{body}    else:",
        f"{body}        rows.to_edge(LEFT, buff=0.65).shift(DOWN * 0.2)",
        f"{body}except Exception:",
        f"{body}    pass",
        f"{body}return rows",
    ]


def _fix_create_left_column_contract(code: str) -> Tuple[Optional[str], str]:
    """Replace narrow create_left_column helpers with an indexable option list."""
    if "def create_left_column" not in code or "self.create_left_column(" not in code:
        return None, ""
    risky_usage = (
        "highlight_index" in code
        or (
            re.search(r"\b\w+\s*=\s*self\.create_left_column\(", code)
            and re.search(r"\b\w+\[[2-9]\]", code)
        )
    )
    if not risky_usage:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for cls in tree.body:
        if not isinstance(cls, ast.ClassDef) or cls.name != "BaseConfigScene":
            continue
        for node in cls.body:
            if not isinstance(node, ast.FunctionDef) or node.name != "create_left_column":
                continue
            span = _source_span_for_multiline_node(node, code)
            if not span:
                continue
            method_text = code[span[0]:span[1]]
            if "while len(raw_items) < 5" in method_text and "highlight_index" in method_text:
                continue
            span = (code.rfind("\n", 0, span[0]) + 1, span[1])
            indent = " " * int(getattr(node, "col_offset", 0))
            body = indent + "    "
            replacements.append((span[0], span[1], "\n".join(_create_left_column_helper_lines(indent, body))))
    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    return current, f"create_left_column合同修复: {len(replacements)}处"


def _fix_add_voiceover_text_duplicate_text_keyword(code: str) -> Tuple[Optional[str], str]:
    if "add_voiceover_text" not in code or "text=" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "add_voiceover_text":
            continue
        if not node.args:
            continue
        if not any(keyword.arg == "text" for keyword in node.keywords):
            continue
        if any(keyword.arg is None for keyword in node.keywords):
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        args = [ast.get_source_segment(code, arg) or ast.unparse(arg) for arg in node.args]
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
            if keyword.arg != "text"
        ]
        call_args = [*args, *kwargs]
        func_source = _call_func_source(node, code)
        if len(call_args) <= 2 and node.lineno == getattr(node, "end_lineno", node.lineno):
            replacement = f"{func_source}({', '.join(call_args)})"
        else:
            replacement = (
                f"{func_source}(\n"
                + ",\n".join(f"{inner_indent}{arg}" for arg in call_args)
                + f"\n{indent})"
            )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"add_voiceover_text重复text参数修复: {len(replacements)}处"


def _inject_visible_objects_default(code: str) -> Tuple[Optional[str], str]:
    """Initialize generated scene scratch storage before helper code touches it."""
    if "self.visible_objects" not in code or "class BaseConfigScene" not in code:
        return None, ""

    lines = code.splitlines()
    for class_index, line in enumerate(lines):
        class_match = re.match(r"^(?P<indent>\s*)class\s+BaseConfigScene\b.*:\s*$", line)
        if not class_match:
            continue
        class_indent = class_match.group("indent")
        body_indent = class_indent + "    "
        index = class_index + 1
        while index < len(lines):
            current = lines[index]
            if current.strip() and len(current) - len(current.lstrip()) <= len(class_indent):
                break
            init_match = re.match(rf"^{re.escape(body_indent)}def\s+__init__\s*\(", current)
            if not init_match:
                index += 1
                continue
            init_indent = body_indent
            method_body_indent = init_indent + "    "
            body_end = index + 1
            while body_end < len(lines):
                body_line = lines[body_end]
                if body_line.strip() and len(body_line) - len(body_line.lstrip()) <= len(init_indent):
                    break
                body_end += 1
            if any("self.visible_objects" in item for item in lines[index:body_end]):
                return None, ""
            insert_at = index + 1
            for offset in range(index + 1, body_end):
                if "super().__init__(" in lines[offset]:
                    insert_at = offset + 1
                    break
            lines.insert(insert_at, f"{method_body_indent}self.visible_objects = []")
            return (
                "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
                "visible_objects初始化补全: 1处",
            )
        break
    return None, ""


def _base_config_scene_class_range(code: str) -> tuple[int, int, str] | None:
    lines = code.splitlines()
    for index, line in enumerate(lines):
        match = re.match(r"^(?P<indent>\s*)class\s+BaseConfigScene\b.*:\s*$", line)
        if not match:
            continue
        class_indent = match.group("indent")
        end = index + 1
        while end < len(lines):
            body_line = lines[end]
            if body_line.strip() and len(body_line) - len(body_line.lstrip()) <= len(class_indent):
                break
            end += 1
        return index, end, class_indent + "    "
    return None


_TEXT_HELPER_FALLBACK_NAME_RE = re.compile(
    r"(?:^|_)(?:text|title|subtitle|caption|label|sentence|content|cjk|note)(?:_|$)",
    re.I,
)
_TEXT_HELPER_FALLBACK_LABEL_RE = re.compile(
    r"(?:text|title|subtitle|caption|label|sentence|content|cjk|card|line)",
    re.I,
)


def _fix_text_helper_fallback_icon_returns(code: str) -> Tuple[Optional[str], str]:
    """Replace text/content helper icon placeholders with real Text mobjects."""
    if "_mathpi_fallback_icon" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines()
    replacements: list[tuple[int, int, list[str], str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        if not _TEXT_HELPER_FALLBACK_NAME_RE.search(node.name):
            continue
        placeholder = _text_helper_fallback_return(node)
        if placeholder is None:
            continue
        label, _line_no = placeholder
        if label and not _TEXT_HELPER_FALLBACK_LABEL_RE.search(label):
            continue
        if not node.body:
            continue
        body_start = int(getattr(node.body[0], "lineno", node.lineno + 1)) - 1
        body_end = max(
            int(getattr(child, "end_lineno", getattr(child, "lineno", node.lineno)) or node.lineno)
            for child in node.body
        )
        def_indent = re.match(r"^(\s*)", lines[node.lineno - 1]).group(1)
        body_indent = def_indent + "    "
        replacements.append(
            (
                body_start,
                body_end,
                _real_text_helper_body_lines(body_indent),
                node.name,
            )
        )

    if not replacements:
        return None, ""
    for start, end, replacement, _name in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        lines[start:end] = replacement
    helper_names = ", ".join(name for *_rest, name in replacements[:5])
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"文本helper圆点兜底改真实Text: {len(replacements)}处 ({helper_names})",
    )


def _text_helper_fallback_return(
    function_node: ast.FunctionDef,
) -> tuple[str, int] | None:
    for node in ast.walk(function_node):
        if not isinstance(node, ast.Return) or node.value is None:
            continue
        for child in ast.walk(node.value):
            if not isinstance(child, ast.Call):
                continue
            call_name = ""
            if isinstance(child.func, ast.Attribute):
                call_name = child.func.attr
            elif isinstance(child.func, ast.Name):
                call_name = child.func.id
            if call_name != "_mathpi_fallback_icon":
                continue
            label = ""
            if child.args and isinstance(child.args[0], ast.Constant):
                label = str(child.args[0].value or "")
            return label, int(getattr(child, "lineno", node.lineno))
    return None


_VISIBLE_FALLBACK_CALL_NAMES = frozenset({
    "_mathpi_fallback_icon",
    "_mathpi_runtime_visual_icon",
})


def _disable_visible_fallback_icon_paths(code: str) -> Tuple[Optional[str], str]:
    """Turn visible placeholder helper paths into explicit repairable errors."""
    if not any(name in code for name in _VISIBLE_FALLBACK_CALL_NAMES):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines()
    replacements: list[tuple[int, int, list[str], str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        fallback = _function_visible_fallback_return(node)
        if node.name in _VISIBLE_FALLBACK_CALL_NAMES:
            fallback = fallback or (node.name, int(getattr(node, "lineno", 1)))
        if fallback is None:
            continue
        body_start = int(getattr(node.body[0], "lineno", node.lineno + 1)) - 1 if node.body else node.lineno
        body_end = max(
            int(getattr(child, "end_lineno", getattr(child, "lineno", node.lineno)) or node.lineno)
            for child in node.body
        ) if node.body else node.lineno
        def_indent = re.match(r"^(\s*)", lines[node.lineno - 1]).group(1)
        body_indent = def_indent + "    "
        label, _line = fallback
        message = (
            f"MATHPI_FORBIDDEN_VISIBLE_FALLBACK: {node.name}"
            f"->{label or '_mathpi_fallback_icon'}; implement the real visual helper"
        )
        replacements.append(
            (
                body_start,
                body_end,
                [f"{body_indent}raise RuntimeError({message!r})"],
                node.name,
            )
        )

    if not replacements:
        return None, ""
    for start, end, replacement, _name in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        lines[start:end] = replacement
    helper_names = ", ".join(name for *_rest, name in replacements[:5])
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"可见fallback禁用: {len(replacements)}处 ({helper_names})",
    )


def _function_visible_fallback_return(
    function_node: ast.FunctionDef,
) -> tuple[str, int] | None:
    for node in ast.walk(function_node):
        if not isinstance(node, ast.Return) or node.value is None:
            continue
        for child in ast.walk(node.value):
            if not isinstance(child, ast.Call):
                continue
            call_name = ""
            if isinstance(child.func, ast.Attribute):
                call_name = child.func.attr
            elif isinstance(child.func, ast.Name):
                call_name = child.func.id
            if call_name not in _VISIBLE_FALLBACK_CALL_NAMES:
                continue
            label = ""
            if child.args and isinstance(child.args[0], ast.Constant):
                label = str(child.args[0].value or "")
            return label, int(getattr(child, "lineno", node.lineno))
    return None


def _real_text_helper_body_lines(indent: str) -> list[str]:
    return [
        f"{indent}kwargs = locals().get(\"_kwargs\", locals().get(\"kwargs\", {{}})) or {{}}",
        f"{indent}parts = locals().get(\"args\", ()) or ()",
        f"{indent}if isinstance(parts, (str, bytes)):",
        f"{indent}    parts = (parts,)",
        f"{indent}text_value = \"\".join(str(item) for item in parts if item is not None)",
        f"{indent}if not text_value:",
        f"{indent}    for _name in (\"text\", \"label\", \"title\", \"content\", \"sentence\", \"caption\", \"note\"):",
        f"{indent}        _value = locals().get(_name)",
        f"{indent}        if _value not in (None, \"\"):",
        f"{indent}            text_value = str(_value)",
        f"{indent}            break",
        f"{indent}if not text_value:",
        f"{indent}    text_value = str(kwargs.get(\"text\") or kwargs.get(\"label\") or kwargs.get(\"title\") or kwargs.get(\"content\") or \"\")",
        f"{indent}font_name = getattr(globals().get(\"GlobalConfig\", object), \"CJK_TEXT_FONT\", \"AR PL KaitiM GB\")",
        f"{indent}size_value = kwargs.get(\"font_size\") or locals().get(\"font_size\") or kwargs.get(\"size\") or locals().get(\"size\", 0.8)",
        f"{indent}try:",
        f"{indent}    font_size_value = int(size_value)",
        f"{indent}    if font_size_value < 10:",
        f"{indent}        font_size_value = int(max(18, float(size_value or 0.8) * 28))",
        f"{indent}except Exception:",
        f"{indent}    font_size_value = 28",
        f"{indent}mob = Text(text_value, font=font_name, font_size=font_size_value, color=locals().get(\"color\") or getattr(self, \"TEXT_COLOR\", globals().get(\"WHITE\", \"#FFFFFF\")))",
        f"{indent}try:",
        f"{indent}    frame_width = float(getattr(globals().get(\"config\", None), \"frame_width\", 14.222))",
        f"{indent}    max_width = float(kwargs.get(\"max_width\") or frame_width - 1.2)",
        f"{indent}    if getattr(mob, \"width\", 0) > max_width:",
        f"{indent}        mob.scale_to_fit_width(max_width)",
        f"{indent}except Exception:",
        f"{indent}    pass",
        f"{indent}return mob",
    ]


def _fix_semantic_icon_text_box_fallback_calls(code: str) -> Tuple[Optional[str], str]:
    """Deprecated: do not hide semantic/text content loss behind fallback icons."""
    del code
    return None, ""


def _inject_asset_icon_helper(code: str) -> Tuple[Optional[str], str]:
    """Provide a local asset_icon contract without drawing visible placeholders."""
    if "self.asset_icon" not in code or "def asset_icon" in code:
        return None, ""
    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines = [
        "",
        f"{indent}def asset_icon(self, name, width=1.0, size=None, color=None, stroke_width=None, inner_scale=None, **_kwargs):",
        f"{body}raise RuntimeError(f'MATHPI_ICON_ASSET_MISSING: {{name}}')",
    ]
    lines = code.splitlines()
    lines[end:end] = helper_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "asset_icon缺资产显式错误补全: 1处",
    )


def _fix_generated_asset_icon_calls(code: str) -> Tuple[Optional[str], str]:
    """Keep generated:* asset ids on asset_icon so they resolve to real SVG assets."""
    return None, ""


def _fix_get_icon_alias(code: str) -> Tuple[Optional[str], str]:
    """Map hallucinated self.get_icon(...) to the project asset_icon helper."""
    if re.search(r"(?m)^\s*def\s+get_icon\s*\(", code):
        return None, ""
    fixed, count = re.subn(r"\bself\.get_icon\s*\(", "self.asset_icon(", code)
    if count == 0:
        return None, ""
    return fixed, f"get_icon别名修复: {count}处"


def _fix_narrow_asset_icon_signature(code: str) -> Tuple[Optional[str], str]:
    """Broaden fallback asset_icon(width=...) helpers to accept project kwargs."""
    fallback_pattern = re.compile(
        r"(?m)^(?P<indent>\s*)def\s+asset_icon"
        r"\(\s*self\s*,\s*name\s*,\s*width\s*=\s*1\.0\s*,\s*color\s*=\s*None\s*\)\s*:"
    )
    resource_pattern = re.compile(
        r"(?m)^(?P<indent>\s*)def\s+asset_icon"
        r"\(\s*self\s*,\s*asset_id\s*,\s*size\s*=\s*0\.72\s*,\s*color\s*=\s*None\s*,"
        r"\s*stroke_width\s*=\s*None\s*,\s*inner_scale\s*=\s*None\s*\)\s*:"
    )
    if not fallback_pattern.search(code) and not resource_pattern.search(code):
        return None, ""

    def replace_fallback(match: re.Match) -> str:
        indent = match.group("indent")
        return (
            f"{indent}def asset_icon(self, name, width=1.0, size=None, color=None, "
            "stroke_width=None, inner_scale=None, **_kwargs):\n"
            f"{indent}    width = size if size is not None else width"
        )

    def replace_resource(match: re.Match) -> str:
        indent = match.group("indent")
        return (
            f"{indent}def asset_icon(self, asset_id, size=None, width=None, color=None, "
            "stroke_width=None, inner_scale=None, **_kwargs):"
        )

    current, fallback_count = fallback_pattern.subn(replace_fallback, code)
    current, resource_count = resource_pattern.subn(replace_resource, current)
    current = current.replace(
        "target_size = float(size)",
        "target_size = float(size if size is not None else width if width is not None else 0.72)",
    )
    count = fallback_count + resource_count
    return current, f"asset_icon签名兼容: {count}处"


def _make_helper_label(name: str) -> str:
    raw = name.removeprefix("make_")
    return raw.replace("_", " ").title() or "Animal"


def _animal_helper_block(missing: list[str]) -> str:
    animal_defs: list[str] = [
        "def _mathpi_animal_card(label, color=\"#3498DB\"):",
        "    box = RoundedRectangle(width=1.65, height=1.15, corner_radius=0.18, color=color, stroke_width=2)",
        "    box.set_fill(\"#FFFFFF\", opacity=0.92)",
        "    text = Text(str(label)[:14], font_size=18, color=color)",
        "    text.move_to(box.get_center())",
        "    return VGroup(box, text)",
        "",
    ]

    color_map = {
        "make_giraffe": "#E67E22",
        "make_penguin": "#3498DB",
        "make_eagle": "#8E44AD",
        "make_wolf": "#34495E",
        "make_monkey": "#27AE60",
        "make_panda": "#2C3E50",
        "make_lion": "#F39C12",
        "make_tiger": "#E74C3C",
        "make_fox": "#D35400",
    }
    for name in missing:
        if name == "make_student":
            animal_defs.extend([
                "def make_student(name=\"Student\", color=\"#3498DB\"):",
                "    head = Circle(radius=0.22, color=color, fill_color=color, fill_opacity=0.18)",
                "    body = RoundedRectangle(width=0.9, height=0.42, corner_radius=0.12, color=color, stroke_width=2).next_to(head, DOWN, buff=0.05)",
                "    label = Text(str(name), font_size=14, color=color).next_to(body, DOWN, buff=0.06)",
                "    return VGroup(head, body, label)",
                "",
            ])
            continue
        if name == "make_zoo_map":
            animal_defs.extend([
                "def make_zoo_map():",
                "    area = RoundedRectangle(width=3.2, height=2.0, corner_radius=0.18, color=\"#27AE60\", stroke_width=2)",
                "    area.set_fill(\"#FFFFFF\", opacity=0.9)",
                "    title = Text(\"Zoo Map\", font_size=20, color=\"#27AE60\")",
                "    title.move_to(area.get_center())",
                "    return VGroup(area, title)",
                "",
            ])
            continue
        label = _make_helper_label(name)
        color = color_map.get(name, "#3498DB")
        animal_defs.extend([
            f"def {name}():",
            f"    return _mathpi_animal_card({label!r}, {color!r})",
            "",
        ])
    return "\n".join(animal_defs).rstrip()


def _inject_missing_animal_helpers(code: str) -> Tuple[Optional[str], str]:
    """Provide simple visual fallbacks for generated make_giraffe/make_student calls."""
    calls = sorted(set(_MAKE_HELPER_CALL_RE.findall(code)))
    if not calls:
        return None, ""
    defined = set(_MAKE_HELPER_DEF_RE.findall(code))
    missing = [name for name in calls if name not in defined]
    if not missing:
        return None, ""
    helper_block = _animal_helper_block(missing)
    if not helper_block:
        return None, ""

    lines = code.splitlines()
    insert_at = _voiceover_import_insert_index(lines)
    updated = [
        *lines[:insert_at],
        "",
        helper_block,
        "",
        *lines[insert_at:],
    ]
    current = "\n".join(updated) + ("\n" if code.endswith("\n") else "")
    return current, f"动物辅助函数补全: {', '.join(missing)}"


def _fix_wait_until_bookmark(code: str) -> Tuple[Optional[str], str]:
    """修复 wait_until_bookmark("mark", extra_arg) 多参数调用。"""
    pattern = re.compile(
        r'\.wait_until_bookmark\(\s*(["\'][^"\']*["\'])\s*,\s*[^)]+\)'
    )
    modified = pattern.sub(r'.wait_until_bookmark(\1)', code)
    if modified != code:
        count = len(pattern.findall(code))
        return modified, f"修复 {count} 处 wait_until_bookmark 多余参数"
    return None, ""


def _fix_unconsumed_bookmarks(code: str) -> Tuple[Optional[str], str]:
    """删除没有被 wait/time 消费的 bookmark，避免 tracker 依赖无意义标记。"""
    marks = [m.group("mark") for m in _BOOKMARK_TAG_RE.finditer(code)]
    if not marks:
        return None, ""
    consumed = {m.group("mark") for m in _BOOKMARK_CONSUME_RE.finditer(code)}
    unused = {mark for mark in marks if mark not in consumed}
    if not unused:
        return None, ""

    def _replace(match: re.Match) -> str:
        return "" if match.group("mark") in unused else match.group(0)

    modified = _BOOKMARK_TAG_RE.sub(_replace, code)
    if modified != code:
        return modified, f"移除 {len(unused)} 个未消费 bookmark"
    return None, ""


def _fix_overlong_voiceover_segments(code: str) -> Tuple[Optional[str], str]:
    """Split long literal voiceover blocks before the static TTS gate.

    The validator's 45-CJK hard cap is still useful as a last guard, but most
    generated long narration can be repaired deterministically by splitting the
    text into short consecutive voiceover blocks and distributing the existing
    visual statements across them.
    """
    if "self.voiceover(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.With):
            continue
        info = _literal_voiceover_with_info(node, code)
        if info is None:
            continue
        call, text_node, text, tracker_name = info
        chunks = _split_voiceover_text_for_sync(text)
        if len(chunks) <= 1:
            continue
        replacement = _build_split_voiceover_replacement(
            code,
            node=node,
            call=call,
            text_node=text_node,
            chunks=chunks,
            tracker_name=tracker_name,
        )
        if not replacement:
            continue
        span = _source_span_for_multiline_node(node, code)
        if span is None:
            continue
        line_start = code.rfind("\n", 0, span[0]) + 1
        replacements.append((line_start, span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current = current[:start] + replacement + current[end:]
    return current, f"长配音块拆分: {len(replacements)}处"


def _fix_wait_only_voiceover_preadd_reveals(code: str) -> Tuple[Optional[str], str]:
    """Animate objects that were pre-added immediately before a wait-only voiceover."""
    if "self.voiceover(" not in code or "self.add" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    fixed_count = 0
    for parent in ast.walk(tree):
        body = getattr(parent, "body", None)
        if not isinstance(body, list):
            continue
        for index in range(1, len(body)):
            previous = body[index - 1]
            current = body[index]
            if not isinstance(current, ast.With) or not _is_wait_only_voiceover_block(current):
                continue

            previous_call = _single_expr_call(previous)
            method = _self_call_method_name(previous_call)
            if method not in {
                "add",
                "add_fixed_in_frame_mobjects",
                "add_fixed_orientation_mobjects",
            }:
                continue
            if previous_call is None or previous_call.keywords:
                continue
            arg_sources = _simple_call_arg_sources(previous_call, code)
            if not arg_sources:
                continue
            if method != "add" and not all(_is_simple_name_source(arg) for arg in arg_sources):
                continue

            previous_span = _source_span_for_multiline_node(previous, code)
            current_span = _source_span_for_multiline_node(current, code)
            if previous_span is None or current_span is None:
                continue

            previous_start = code.rfind("\n", 0, previous_span[0]) + 1
            previous_end = _extend_span_to_trailing_newline(code, previous_span[1])
            current_start = code.rfind("\n", 0, current_span[0]) + 1
            current_end = _extend_span_to_trailing_newline(code, current_span[1])
            with_header = code.splitlines()[current.lineno - 1].rstrip()
            if not with_header.endswith(":"):
                continue
            body_indent = _voiceover_body_indent(current, code)

            if method == "add":
                play_args = ", ".join(f"FadeIn({arg})" for arg in arg_sources)
                with_replacement = (
                    f"{with_header}\n"
                    f"{body_indent}self.play({play_args}, run_time=1.0)"
                )
                replacements.append((previous_start, previous_end, ""))
                replacements.append((current_start, current_end, with_replacement + "\n"))
            else:
                previous_indent = re.match(
                    r"\s*", code.splitlines()[previous.lineno - 1],
                ).group(0)
                previous_source = (
                    previous_indent + code[previous_span[0]:previous_span[1]].rstrip()
                )
                hidden_lines = [
                    f"{previous_indent}{arg}.set_opacity(0)"
                    for arg in arg_sources
                ]
                previous_replacement = "\n".join([*hidden_lines, previous_source])
                play_args = ", ".join(
                    f"{arg}.animate.set_opacity(1)" for arg in arg_sources
                )
                with_replacement = (
                    f"{with_header}\n"
                    f"{body_indent}self.play({play_args}, run_time=1.0)"
                )
                replacements.append((previous_start, previous_end, previous_replacement + "\n"))
                replacements.append((current_start, current_end, with_replacement + "\n"))
            fixed_count += 1

    if not replacements:
        return None, ""

    current_code = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current_code = current_code[:start] + replacement + current_code[end:]
    return current_code, f"wait_only_voiceover_reveal: {fixed_count}处"


def _fix_wait_only_voiceover_focus_indicates(code: str) -> Tuple[Optional[str], str]:
    """Replace dead-air voiceover blocks with a small focus animation."""
    if "self.voiceover(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    fixed_count = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.With):
            continue
        if _voiceover_body_has_sync_helper_or_bookmark(node):
            continue
        body_indent = _voiceover_body_indent(node, code)
        setup_statements = _dead_air_voiceover_setup_sources(node, code, body_indent)
        if setup_statements is None:
            continue

        span = _source_span_for_multiline_node(node, code)
        if span is None:
            continue
        with_header = code.splitlines()[node.lineno - 1].rstrip()
        if not with_header.endswith(":"):
            continue
        tracker_name = _voiceover_tracker_name(node, code)
        run_time = (
            f"min(0.8, float({tracker_name}.duration))"
            if tracker_name and _is_simple_name_source(tracker_name)
            else "0.6"
        )
        replacement = "\n".join(
            [
                with_header,
                *setup_statements,
                (
                    f"{body_indent}focus = self.mobjects[-1] "
                    "if self.mobjects else Dot(ORIGIN, fill_opacity=0, stroke_opacity=0)"
                ),
                (
                    f"{body_indent}self.play("
                    "Indicate(focus, color=getattr(self, \"EMPHASIS_COLOR\", YELLOW)), "
                    f"run_time={run_time})"
                ),
            ]
        )
        start = code.rfind("\n", 0, span[0]) + 1
        end = _extend_span_to_trailing_newline(code, span[1])
        replacements.append((start, end, replacement + "\n"))
        fixed_count += 1

    if not replacements:
        return None, ""

    current_code = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current_code = current_code[:start] + replacement + current_code[end:]
    return current_code, f"wait_only_voiceover_focus: {fixed_count}处"


def _inject_tts_timing_helpers(code: str) -> Tuple[Optional[str], str]:
    if "self.play_steps_evenly(" not in code and "self.play_synced_steps(" not in code:
        return None, ""
    if "def play_steps_evenly" in code and "def play_synced_steps" in code:
        return None, ""
    class_range = _base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines = [
        "",
        (
            f"{indent}def play_synced_steps(self, tracker, steps, active_fraction=0.85, "
            "tail_reserve=0.2, min_run_time=0.4, max_run_time=1.2, max_tail_wait=0.8):"
        ),
        f"{body}duration = max(0.0, float(getattr(tracker, \"duration\", 0.0) or 0.0))",
        f"{body}steps = list(steps or [])",
        f"{body}if not steps:",
        f"{body}    return",
        f"{body}active_window = max(0.1, duration * active_fraction - tail_reserve)",
        f"{body}elapsed = 0.0",
        f"{body}for anchor, animation, run_time in steps:",
        f"{body}    target = max(0.0, min(1.0, anchor)) * active_window",
        f"{body}    wait_time = max(0.0, target - elapsed)",
        f"{body}    if wait_time > 0:",
        f"{body}        self.wait(wait_time)",
        f"{body}        elapsed += wait_time",
        f"{body}    rt = max(min_run_time, min(max_run_time, run_time))",
        f"{body}    self.play(animation, run_time=rt)",
        f"{body}    elapsed += rt",
        f"{body}tail = min(max_tail_wait, max(0.0, duration - elapsed))",
        f"{body}if tail > 0:",
        f"{body}    self.wait(tail)",
        "",
        (
            f"{indent}def play_steps_evenly(self, animations, tracker, active_fraction=0.85, "
            "default_run_time=0.7, **kwargs):"
        ),
        f"{body}if \"spread_fraction\" in kwargs:",
        f"{body}    active_fraction = kwargs[\"spread_fraction\"]",
        f"{body}if \"min_run_time\" in kwargs:",
        f"{body}    default_run_time = kwargs[\"min_run_time\"]",
        f"{body}animations = list(animations or [])",
        f"{body}count = len(animations)",
        f"{body}if count == 0:",
        f"{body}    return",
        f"{body}steps = []",
        f"{body}for i, animation in enumerate(animations):",
        f"{body}    anchor = 0.05 if count == 1 else 0.05 + 0.8 * i / (count - 1)",
        f"{body}    steps.append((anchor, animation, default_run_time))",
        f"{body}self.play_synced_steps(tracker, steps, active_fraction=active_fraction)",
    ]
    lines = code.splitlines()
    lines[end:end] = helper_lines
    return "\n".join(lines) + ("\n" if code.endswith("\n") else ""), "TTS时间轴helper补全: 1处"


def _dead_air_voiceover_setup_sources(
    node: ast.With,
    code: str,
    body_indent: str,
) -> list[str] | None:
    if not any(_is_self_voiceover_call(item.context_expr) for item in node.items):
        return None
    if not node.body:
        return None

    setup_statements: list[str] = []
    for statement in node.body:
        if _is_self_wait_expr(statement) or isinstance(statement, ast.Pass):
            continue
        if not _is_voiceover_setup_statement(statement):
            return None
        setup_statement = _voiceover_statement_source(statement, code, body_indent)
        if not setup_statement:
            return None
        setup_statements.append(setup_statement)
    return setup_statements


def _fix_multi_play_voiceover_blocks_to_even_helper(code: str) -> Tuple[Optional[str], str]:
    """Convert simple raw-play voiceover bodies to the timeline helper."""
    if "self.voiceover(" not in code or "self.play(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    fixed_count = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.With):
            continue
        info = _literal_voiceover_with_info(node, code)
        if info is None:
            continue
        _, _, _, tracker_name = info
        if not tracker_name or not _is_simple_name_source(tracker_name):
            continue
        if _voiceover_body_has_sync_helper_or_bookmark(node):
            continue

        setup_statements: list[str] = []
        animations: list[str] = []
        has_wait = False
        convertible = True
        for statement in node.body:
            call = _single_expr_call(statement)
            method = _self_call_method_name(call)
            if method == "play" and call is not None:
                animation = _play_call_animation_source(call, code)
                if not animation:
                    convertible = False
                    break
                animations.append(animation)
                continue
            if _is_fixed_numeric_self_wait_expr(statement):
                has_wait = True
                continue
            if _is_voiceover_setup_statement(statement):
                setup_statement = _voiceover_statement_source(statement, code, _voiceover_body_indent(node, code))
                if not setup_statement:
                    convertible = False
                    break
                setup_statements.append(setup_statement)
                continue
            convertible = False
            break

        if not convertible:
            continue
        if len(animations) < 2 and not (len(animations) == 1 and has_wait):
            continue

        replacement = _build_even_helper_voiceover_replacement(
            node,
            code,
            tracker_name=tracker_name,
            animations=animations,
            setup_statements=setup_statements,
        )
        if not replacement:
            continue
        span = _source_span_for_multiline_node(node, code)
        if span is None:
            continue
        start = code.rfind("\n", 0, span[0]) + 1
        end = _extend_span_to_trailing_newline(code, span[1])
        replacements.append((start, end, replacement + "\n"))
        fixed_count += 1

    if not replacements:
        return None, ""

    current_code = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current_code = current_code[:start] + replacement + current_code[end:]
    return current_code, f"multi_play_voiceover_to_helper: {fixed_count}处"


def _voiceover_body_has_sync_helper_or_bookmark(node: ast.With) -> bool:
    for statement in node.body:
        for child in ast.walk(statement):
            if not isinstance(child, ast.Call):
                continue
            method = _self_call_method_name(child)
            if method in {
                "play_steps_evenly",
                "play_synced_steps",
                "wait_until_bookmark",
                "time_until_bookmark",
            }:
                return True
    return False


def _is_voiceover_setup_statement(statement: ast.stmt) -> bool:
    if not isinstance(
        statement,
        (
            ast.Assign,
            ast.AnnAssign,
            ast.AugAssign,
            ast.Expr,
        ),
    ):
        return False
    for child in ast.walk(statement):
        if not isinstance(child, ast.Call):
            continue
        method = _self_call_method_name(child)
        if method in {
            "play",
            "wait",
            "wait_for_voiceover",
            "wait_until_bookmark",
            "play_steps_evenly",
            "play_synced_steps",
            "add",
            "remove",
            "clear",
            "add_foreground_mobject",
            "add_foreground_mobjects",
            "add_fixed_in_frame_mobjects",
            "add_fixed_orientation_mobjects",
        }:
            return False
    return True


def _voiceover_statement_source(
    statement: ast.stmt,
    code: str,
    body_indent: str,
) -> str | None:
    span = _source_span_for_multiline_node(statement, code)
    if span is None:
        return None
    raw_source = code[span[0]:span[1]].rstrip()
    if not raw_source:
        return None
    return "\n".join(
        body_indent + line if line.strip() else line
        for line in raw_source.splitlines()
    )


def _is_fixed_numeric_self_wait_expr(statement: ast.stmt) -> bool:
    call = _single_expr_call(statement)
    if call is None or _self_call_method_name(call) != "wait":
        return False
    if len(call.args) != 1 or call.keywords:
        return False
    value = call.args[0]
    return (
        isinstance(value, ast.Constant)
        and isinstance(value.value, (int, float))
        and float(value.value) >= 0
    )


def _play_call_animation_source(call: ast.Call, code: str) -> str | None:
    if not call.args:
        return None
    if any(keyword.arg != "run_time" for keyword in call.keywords):
        return None
    arg_sources: list[str] = []
    for arg in call.args:
        if isinstance(arg, ast.Starred):
            return None
        source = ast.get_source_segment(code, arg)
        if not source:
            source = ast.unparse(arg)
        source = source.strip()
        if not source or "\n" in source:
            return None
        arg_sources.append(source)
    if len(arg_sources) == 1:
        return arg_sources[0]
    return f"AnimationGroup({', '.join(arg_sources)})"


def _build_even_helper_voiceover_replacement(
    node: ast.With,
    code: str,
    *,
    tracker_name: str,
    animations: list[str],
    setup_statements: list[str] | None = None,
) -> str | None:
    with_header = code.splitlines()[node.lineno - 1].rstrip()
    if not with_header.endswith(":"):
        return None
    body_indent = _voiceover_body_indent(node, code)
    item_indent = body_indent + "    "
    lines = [
        with_header,
    ]
    lines.extend(setup_statements or [])
    lines.append(f"{body_indent}self.play_steps_evenly([")
    lines.extend(f"{item_indent}{animation}," for animation in animations)
    lines.append(f"{body_indent}], {tracker_name})")
    return "\n".join(lines)


def _is_wait_only_voiceover_block(node: ast.With) -> bool:
    if not any(_is_self_voiceover_call(item.context_expr) for item in node.items):
        return False
    if not node.body:
        return False
    return all(_is_self_wait_expr(statement) for statement in node.body)


def _is_wait_or_pass_only_voiceover_block(node: ast.With) -> bool:
    if not any(_is_self_voiceover_call(item.context_expr) for item in node.items):
        return False
    if not node.body:
        return False
    return all(_is_self_wait_expr(statement) or isinstance(statement, ast.Pass) for statement in node.body)


def _voiceover_tracker_name(node: ast.With, code: str) -> str | None:
    for item in node.items:
        if not _is_self_voiceover_call(item.context_expr):
            continue
        if item.optional_vars is None:
            return None
        source = ast.get_source_segment(code, item.optional_vars)
        return source.strip() if source else None
    return None


def _is_self_wait_expr(statement: ast.stmt) -> bool:
    call = _single_expr_call(statement)
    if call is None:
        return False
    return (
        isinstance(call.func, ast.Attribute)
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "self"
        and "wait" in call.func.attr
        and call.func.attr != "wait_until_bookmark"
    )


def _single_expr_call(statement: ast.AST) -> ast.Call | None:
    if (
        isinstance(statement, ast.Expr)
        and isinstance(statement.value, ast.Call)
    ):
        return statement.value
    return None


def _self_call_method_name(call: ast.Call | None) -> str:
    if (
        isinstance(call, ast.Call)
        and isinstance(call.func, ast.Attribute)
        and isinstance(call.func.value, ast.Name)
        and call.func.value.id == "self"
    ):
        return call.func.attr
    return ""


def _simple_call_arg_sources(call: ast.Call, code: str) -> list[str]:
    sources: list[str] = []
    for arg in call.args:
        if isinstance(arg, ast.Starred):
            return []
        source = ast.get_source_segment(code, arg)
        if not source or "\n" in source:
            return []
        sources.append(source.strip())
    return sources


def _is_simple_name_source(source: str) -> bool:
    return re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", source or "") is not None


def _voiceover_body_indent(node: ast.With, code: str) -> str:
    if node.body:
        line = code.splitlines()[max(0, node.body[0].lineno - 1)]
        return re.match(r"\s*", line).group(0)
    header_line = code.splitlines()[max(0, node.lineno - 1)]
    return re.match(r"\s*", header_line).group(0) + "    "


def _extend_span_to_trailing_newline(code: str, end: int) -> int:
    if end < len(code) and code[end] == "\n":
        return end + 1
    return end


def _literal_voiceover_with_info(
    node: ast.With,
    code: str,
) -> tuple[ast.Call, ast.AST, str, str | None] | None:
    voiceover_items = [
        item for item in node.items if _is_self_voiceover_call(item.context_expr)
    ]
    if len(voiceover_items) != 1:
        return None
    item = voiceover_items[0]
    call = item.context_expr
    if not isinstance(call, ast.Call):
        return None
    text_node: ast.AST | None = None
    text_keyword = next(
        (keyword for keyword in call.keywords if keyword.arg == "text"),
        None,
    )
    if text_keyword is not None:
        text_node = text_keyword.value
    elif call.args:
        text_node = call.args[0]
    if text_node is None:
        return None
    text = _literal_string_value_for_voiceover(text_node)
    if text is None:
        return None
    tracker_name = None
    if item.optional_vars is not None:
        tracker_name = ast.get_source_segment(code, item.optional_vars) or None
    return call, text_node, text, tracker_name


def _is_self_voiceover_call(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "voiceover"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _literal_string_value_for_voiceover(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        parts: list[str] = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
            else:
                return None
        return "".join(parts)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _literal_string_value_for_voiceover(node.left)
        right = _literal_string_value_for_voiceover(node.right)
        if left is not None and right is not None:
            return left + right
    return None


def _split_voiceover_text_for_sync(text: str) -> list[str]:
    clean = _BOOKMARK_TAG_RE.sub("", text or "")
    if _count_cjk(clean) <= _VOICEOVER_SHORT_TARGET_MAX_CJK:
        return [text]

    chunks: list[str] = []
    buffer: list[str] = []
    cjk_count = 0
    for char in text:
        buffer.append(char)
        if _is_cjk_char(char):
            cjk_count += 1
        if cjk_count < _VOICEOVER_SHORT_TARGET_MIN_CJK:
            continue
        should_split = (
            char in _VOICEOVER_SPLIT_PUNCTUATION
            or cjk_count >= _VOICEOVER_SHORT_TARGET_MAX_CJK
        )
        if should_split:
            chunks.append("".join(buffer).strip())
            buffer = []
            cjk_count = 0
    tail = "".join(buffer).strip()
    if tail:
        chunks.append(tail)

    chunks = [chunk for chunk in chunks if chunk]
    if len(chunks) <= 1:
        return [text]
    return _merge_tiny_voiceover_tail(chunks)


def _merge_tiny_voiceover_tail(chunks: list[str]) -> list[str]:
    if len(chunks) <= 1:
        return chunks
    merged = chunks[:]
    tail_count = _count_cjk(_BOOKMARK_TAG_RE.sub("", merged[-1]))
    prev_count = _count_cjk(_BOOKMARK_TAG_RE.sub("", merged[-2]))
    if (
        tail_count < _VOICEOVER_SHORT_TARGET_MIN_CJK
        and prev_count + tail_count <= _VOICEOVER_SHORT_TARGET_MAX_CJK
    ):
        merged[-2] = merged[-2] + merged[-1]
        merged.pop()
    elif tail_count < _VOICEOVER_SHORT_TARGET_MIN_CJK:
        combined = merged[-2] + merged[-1]
        combined_count = _count_cjk(_BOOKMARK_TAG_RE.sub("", combined))
        left, right = _split_text_by_cjk_target(
            combined,
            max(_VOICEOVER_SHORT_TARGET_MIN_CJK, combined_count // 2),
        )
        if (
            left
            and right
            and _VOICEOVER_SHORT_TARGET_MIN_CJK
            <= _count_cjk(_BOOKMARK_TAG_RE.sub("", left))
            <= _VOICEOVER_SHORT_TARGET_MAX_CJK
            and _VOICEOVER_SHORT_TARGET_MIN_CJK
            <= _count_cjk(_BOOKMARK_TAG_RE.sub("", right))
            <= _VOICEOVER_SHORT_TARGET_MAX_CJK
        ):
            merged[-2] = left
            merged[-1] = right
    return merged


def _split_text_by_cjk_target(text: str, target_cjk: int) -> tuple[str, str]:
    buffer: list[str] = []
    cjk_count = 0
    for index, char in enumerate(text):
        buffer.append(char)
        if _is_cjk_char(char):
            cjk_count += 1
        if cjk_count >= target_cjk:
            return "".join(buffer).strip(), text[index + 1:].strip()
    return text.strip(), ""


def _build_split_voiceover_replacement(
    code: str,
    *,
    node: ast.With,
    call: ast.Call,
    text_node: ast.AST,
    chunks: list[str],
    tracker_name: str | None,
) -> str | None:
    call_span = _source_span_for_multiline_node(call, code)
    value_span = _source_span_for_multiline_node(text_node, code)
    if call_span is None or value_span is None:
        return None
    call_source = code[call_span[0]:call_span[1]]
    value_start = value_span[0] - call_span[0]
    value_end = value_span[1] - call_span[0]

    def call_for_chunk(chunk: str) -> str:
        literal = json.dumps(chunk, ensure_ascii=False)
        return call_source[:value_start] + literal + call_source[value_end:]

    line_start = code.rfind("\n", 0, call_span[0]) + 1
    line_prefix = code[line_start:call_span[0]]
    with_indent = re.match(r"\s*", line_prefix).group(0)
    if node.body:
        first_stmt_line = code.splitlines()[max(0, node.body[0].lineno - 1)]
        body_indent = re.match(r"\s*", first_stmt_line).group(0)
    else:
        body_indent = with_indent + "    "
    statement_sources = _with_body_statement_sources(node, code, body_indent)
    groups = _distribute_voiceover_statements(statement_sources, len(chunks))
    as_clause = f" as {tracker_name}" if tracker_name else ""
    wait_line = _voiceover_wait_line(body_indent, tracker_name)

    blocks: list[str] = []
    for index, chunk in enumerate(chunks):
        lines = [f"{with_indent}with {call_for_chunk(chunk)}{as_clause}:"]
        group = groups[index] if index < len(groups) else []
        if group:
            lines.extend(group)
        else:
            lines.append(wait_line)
        blocks.append("\n".join(lines))
    return "\n".join(blocks)


def _with_body_statement_sources(
    node: ast.With,
    code: str,
    body_indent: str,
) -> list[str]:
    sources: list[str] = []
    for statement in node.body:
        span = _source_span_for_multiline_node(statement, code)
        if span is None:
            return []
        raw_source = code[span[0]:span[1]].rstrip()
        reindented = "\n".join(
            body_indent + line if line.strip() else line
            for line in raw_source.splitlines()
        )
        sources.append(reindented)
    return sources


def _distribute_voiceover_statements(
    statements: list[str],
    chunk_count: int,
) -> list[list[str]]:
    groups: list[list[str]] = [[] for _ in range(max(1, chunk_count))]
    if not statements:
        return groups
    for index, statement in enumerate(statements):
        bucket = min(len(groups) - 1, index * len(groups) // len(statements))
        groups[bucket].append(statement)
    return groups


def _voiceover_wait_line(indent: str, tracker_name: str | None) -> str:
    if tracker_name:
        return f"{indent}self.wait(min(0.8, float({tracker_name}.duration)))"
    return f"{indent}self.wait(0.6)"


def _count_cjk(text: str) -> int:
    return sum(1 for char in text if _is_cjk_char(char))


def _is_cjk_char(char: str) -> bool:
    return "\u4e00" <= char <= "\u9fff" or "\u3400" <= char <= "\u4dbf"


# LaTeX 命令 → 期望的 {arg} 组数
_LATEX_CMD_ARGS = {
    'frac': 2, 'dfrac': 2, 'tfrac': 2, 'cfrac': 2,
    'sqrt': 1, 'text': 1, 'textbf': 1, 'textit': 1,
    'mathrm': 1, 'mathbf': 1, 'mathit': 1, 'mathcal': 1,
    'overline': 1, 'underline': 1, 'hat': 1, 'bar': 1,
    'vec': 1, 'dot': 1, 'ddot': 1, 'tilde': 1,
    'overbrace': 1, 'underbrace': 1,
    'overrightarrow': 1, 'overleftarrow': 1, 'overleftrightarrow': 1,
}
# 匹配 LaTeX 字符串：r"..." 或 "..." 中含 \cmd
_LATEX_STR_RE = re.compile(
    r'''(r?)(["'])(.*?)\2''', re.DOTALL
)
_LATEX_OVER_ARROW_RE = re.compile(
    r'(\\(?:overrightarrow|overleftarrow|overleftrightarrow)\{)([^{}]*?)(\})'
)
_LATEX_POINT_PRIME_RE = re.compile(r"([A-Za-z])('+)")
_POINT_PRIME_LABEL_RE = re.compile(r"^([A-Z])(?:['\u2019\u2018\u2032])$")
_MATHTEX_INDEX_SET_COLOR_RE = re.compile(
    r"^(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*"
    r"\[\s*(?P<index>\d+)\s*\]\.set_color\s*\([^#\n]*\)\s*(?:#.*)?$"
)
_LATEX_SPACING_COMMAND_RE = re.compile(
    r"(?:\\(?:;|,|!| |quad|qquad)|\s)+"
)
_CTEX_TEMPLATE_ASSIGN_RE = re.compile(
    r"(?m)^(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"TexTemplateLibrary\.ctex(?:\.copy\(\))?\s*$"
)
_CTEX_TEMPLATE_CT_TYPO_RE = re.compile(r"\bTexTemplateLibrary\.ct\b(?!ex)")
_HANDMADE_TEX_TEMPLATE_ASSIGN_RE = re.compile(
    r"^(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*TexTemplate\(\)\s*(?:#.*)?$"
)
_MATHTEX_SET_DEFAULT_SINGLE_LINE_RE = re.compile(
    r"(?m)^(?P<indent>\s*)MathTex\.set_default\((?P<args>[^\n()]*)\)\s*$"
)
_TEX_SET_DEFAULT_CTEX_LINE_RE = re.compile(
    r"(?m)^(?P<indent>\s*)Tex\.set_default\((?P<args>[^\n]*tex_template\s*=\s*"
    r"(?P<var>[A-Za-z_][A-Za-z0-9_]*)[^\n]*)\)\s*$"
)
def _call_func_source(node: ast.Call, code: str) -> str:
    return ast.get_source_segment(code, node.func) or "MathTex"


def _call_func_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""


def _source_span_for_multiline_node(
    node: ast.AST,
    code: str,
) -> Optional[tuple[int, int]]:
    lineno = getattr(node, "lineno", None)
    col_offset = getattr(node, "col_offset", None)
    end_lineno = getattr(node, "end_lineno", None)
    end_col_offset = getattr(node, "end_col_offset", None)
    if (
        lineno is None
        or col_offset is None
        or end_lineno is None
        or end_col_offset is None
    ):
        return None

    lines = code.splitlines(keepends=True)
    if lineno < 1 or end_lineno < 1 or lineno > len(lines) or end_lineno > len(lines):
        return None

    offsets: list[int] = []
    pos = 0
    for line in lines:
        offsets.append(pos)
        pos += len(line)

    start_line = lines[lineno - 1]
    end_line = lines[end_lineno - 1]
    start = offsets[lineno - 1] + _byte_col_to_char_col(start_line, col_offset)
    end = offsets[end_lineno - 1] + _byte_col_to_char_col(end_line, end_col_offset)
    return start, end


def _line_offsets(code: str) -> tuple[list[str], list[int]]:
    lines = code.splitlines(keepends=True)
    offsets: list[int] = []
    pos = 0
    for line in lines:
        offsets.append(pos)
        pos += len(line)
    return lines, offsets


def _normalize_align_star_environment(value: str) -> tuple[str, bool]:
    fixed = (
        value
        .replace("\\begin{align*}", "\\begin{aligned}")
        .replace("\\end{align*}", "\\end{aligned}")
        .replace("\\\\begin{align*}", "\\\\begin{aligned}")
        .replace("\\\\end{align*}", "\\\\end{aligned}")
    )
    return fixed, fixed != value


def _fix_mathtex_align_star_environments(code: str) -> Tuple[Optional[str], str]:
    """Convert align* environments inside MathTex/Tex to aligned.

    MathTex is already placed inside math mode by Manim. A nested align*
    environment is fragile there and has shown up in production as
    ``Argument of \align* has an extra }``.
    """
    if "align*" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    changed_calls = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) not in {"MathTex", "Tex"}:
            continue
        if not node.args or any(keyword.arg is None for keyword in node.keywords):
            continue

        changed = False
        args: list[str] = []
        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                normalized, part_changed = _normalize_align_star_environment(arg.value)
                args.append(repr(normalized))
                changed = changed or part_changed
            else:
                args.append(ast.get_source_segment(code, arg) or ast.unparse(arg))
        if not changed:
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        call_args = [*args, *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in call_args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))
        changed_calls += 1

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"MathTex align*环境归一: {changed_calls}处"


def _merge_fragmented_fraction_parts(parts: list[str]) -> tuple[list[str], bool]:
    merged: list[str] = []
    work = list(parts)
    changed = False
    i = 0
    empty_denominator_re = re.compile(r"\\frac\{(?P<num>[^{}]+)\}\{\}\s*$")
    while i < len(work):
        part = work[i]
        if i + 1 < len(work):
            denominator = work[i + 1].strip()
            match = empty_denominator_re.search(part)
            if match and denominator:
                fixed = (
                    part[:match.start()]
                    + f"\\frac{{{match.group('num')}}}{{{denominator}}}"
                    + part[match.end():]
                )
                merged.append(fixed)
                changed = True
                i += 2
                if i < len(work) and work[i].startswith("}"):
                    work[i] = work[i][1:]
                continue
            if "\\frac" in part and part.rstrip().endswith("{") and denominator:
                merged.append(part + denominator + "}")
                changed = True
                i += 2
                if i < len(work) and work[i].startswith("}"):
                    work[i] = work[i][1:]
                continue
        merged.append(part)
        i += 1
    if not changed:
        return parts, False
    return ["".join(merged)], True


def _fix_fragmented_fraction_mathtex_args(code: str) -> Tuple[Optional[str], str]:
    """Merge LLM-split denominator fragments such as ``\\frac{x^2}{}``, ``3-m``.

    Short-video generation sometimes splits one formula into MathTex arguments
    to later index subparts. Manim compiles those fragments through an internal
    align environment; unmatched denominator braces then fail before rendering.
    """
    if "\\frac" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "MathTex":
            continue
        if len(node.args) < 2 or any(keyword.arg is None for keyword in node.keywords):
            continue
        if not all(isinstance(arg, ast.Constant) and isinstance(arg.value, str) for arg in node.args):
            continue

        parts = [
            _normalize_align_star_environment(arg.value)[0]
            for arg in node.args
        ]  # type: ignore[union-attr]
        merged_parts, changed = _merge_fragmented_fraction_parts(parts)
        if not changed:
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        call_args = [*(repr(part) for part in merged_parts), *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in call_args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"MathTex分片分母合并: {len(replacements)}处"


def _call_keyword_sources(node: ast.Call, code: str) -> Optional[list[str]]:
    parts: list[str] = []
    for keyword in node.keywords:
        if keyword.arg is None:
            return None
        value_source = ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)
        parts.append(f"{keyword.arg}={value_source}")
    return parts


def _fix_split_dollar_vec_formula_group(code: str) -> Tuple[Optional[str], str]:
    """Merge a dollar-wrapped vector equation split across Text/MathTex calls."""
    if "$" not in code or "\\vec" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    first_re = re.compile(r"^(?P<prefix>.*?)\$(?P<head>\\vec\{[^{}]+\})$")
    tail_re = re.compile(r"^\{(?P<label>[^{}]+)\}\$$")

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or _call_func_name(node.func) != "VGroup":
            continue
        if len(node.args) != 3:
            continue
        first, second, third = node.args
        if not (
            isinstance(first, ast.Call)
            and isinstance(second, ast.Call)
            and isinstance(third, ast.Call)
            and _call_func_name(first.func) == "Text"
            and _call_func_name(second.func) == "MathTex"
            and _call_func_name(third.func) == "MathTex"
            and first.args
            and second.args
            and third.args
            and isinstance(first.args[0], ast.Constant)
            and isinstance(first.args[0].value, str)
            and isinstance(second.args[0], ast.Constant)
            and isinstance(second.args[0].value, str)
            and isinstance(third.args[0], ast.Constant)
            and isinstance(third.args[0].value, str)
        ):
            continue

        first_match = first_re.match(first.args[0].value)
        tail_match = tail_re.match(third.args[0].value)
        if (
            not first_match
            or not tail_match
            or not re.fullmatch(r"=\s*-\s*\\vec", second.args[0].value.strip())
        ):
            continue
        if any(keyword.arg is None for call in (first, second, third) for keyword in call.keywords):
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        text_kwargs = _call_keyword_sources(first, code)
        math_kwargs = _call_keyword_sources(second, code)
        if text_kwargs is None or math_kwargs is None:
            continue

        prefix = first_match.group("prefix").strip()
        formula = f"{first_match.group('head')} = -\\vec{{{tail_match.group('label')}}}"
        vgroup_func = ast.get_source_segment(code, node.func) or "VGroup"
        text_func = ast.get_source_segment(code, first.func) or "Text"
        math_func = ast.get_source_segment(code, second.func) or "MathTex"
        replacement = (
            f"{vgroup_func}("
            f"{text_func}({', '.join([repr(prefix), *text_kwargs])}), "
            f"{math_func}({', '.join([repr(formula), *math_kwargs])})"
            f")"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"split_dollar_vec_formula_group: {len(replacements)}处"


def _fix_split_aligned_mathtex_args(code: str) -> Tuple[Optional[str], str]:
    """Merge split MathTex aligned-table arguments into one LaTeX string.

    Manim compiles each MathTex argument as an independent fragment for
    submobject coloring/matching. If ``\\begin{aligned}`` and ``\\end{aligned}``
    are split across arguments, the first fragment becomes an unterminated
    align environment and LaTeX fails before rendering starts.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "MathTex":
            continue
        if len(node.args) < 2:
            continue
        if not all(isinstance(arg, ast.Constant) and isinstance(arg.value, str) for arg in node.args):
            continue

        parts = [arg.value for arg in node.args]  # type: ignore[union-attr]
        if not parts or not _latex_has_aligned_begin(parts[0]):
            continue
        if not any(_latex_has_aligned_end(part) for part in parts[1:]):
            continue
        if any(keyword.arg is None for keyword in node.keywords):
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        combined = "\n".join(part.strip() for part in parts if part.strip())
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        args = [repr(combined), *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"MathTex aligned参数合并: {len(replacements)}处"


def _strip_latex_spacing_commands(value: str) -> str:
    return _LATEX_SPACING_COMMAND_RE.sub("", value.strip())


def _replace_fragile_xrightarrow(value: str) -> tuple[str, bool]:
    needle = r"\xrightarrow"
    result: list[str] = []
    pos = 0
    changed = False

    while True:
        start = value.find(needle, pos)
        if start < 0:
            result.append(value[pos:])
            break

        result.append(value[pos:start])
        brace_start = start + len(needle)
        while brace_start < len(value) and value[brace_start].isspace():
            brace_start += 1

        if brace_start >= len(value) or value[brace_start] != "{":
            result.append(needle)
            pos = start + len(needle)
            continue

        depth = 0
        end = brace_start
        while end < len(value):
            char = value[end]
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    break
            end += 1

        if end >= len(value) or depth != 0:
            result.append(r"\longrightarrow")
            changed = True
            pos = len(value)
            continue

        label = value[brace_start + 1:end]
        if (
            r"\circlearrowleft" in label
            or r"\text" in label
            or r"^\circ" in label
            or "°" in label
        ):
            result.append(r"\longrightarrow")
            changed = True
        else:
            result.append(value[start:end + 1])
        pos = end + 1

    return "".join(result), changed


def _normalize_split_arrow_latex(value: str) -> tuple[str, bool]:
    fixed, changed = _replace_fragile_xrightarrow(value)
    if r"\longmapsto" in fixed:
        fixed = fixed.replace(r"\longmapsto", r"\longrightarrow")
        changed = True
    return fixed, changed


def _is_latex_arrow_only_argument(value: str) -> bool:
    compact = _strip_latex_spacing_commands(value)
    if compact.startswith(r"\xrightarrow"):
        return True
    return compact in {
        r"\to",
        r"\mapsto",
        r"\rightarrow",
        r"\longmapsto",
        r"\longrightarrow",
    }


def _fix_fragile_mathtex_latex_args(code: str) -> Tuple[Optional[str], str]:
    """Downgrade fragile MathTex arrow labels inside string arguments."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "MathTex":
            continue
        if not node.args:
            continue
        if any(keyword.arg is None for keyword in node.keywords):
            continue

        changed = False
        args: list[str] = []
        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                normalized, part_changed = _normalize_split_arrow_latex(arg.value)
                args.append(repr(normalized))
                changed = changed or part_changed
            else:
                args.append(ast.get_source_segment(code, arg) or ast.unparse(arg))

        if not changed:
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        call_args = [*args, *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in call_args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"MathTex脆弱箭头降级: {len(replacements)}处"


def _fix_overescaped_mathtex_latex_commands(code: str) -> Tuple[Optional[str], str]:
    """Repair MathTex/Tex arguments like ``"\\\\le"`` to ``"\\le"``.

    Generated code sometimes double-escapes command names after a repair pass.
    LaTeX interprets ``\\le`` as a line break followed by text instead of the
    less-or-equal command, which produces repeat render failures.  We only
    collapse backslashes immediately before known command names, so real line
    breaks such as ``\\`` before whitespace are left alone.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) not in {"MathTex", "Tex"}:
            continue
        if not node.args or any(keyword.arg is None for keyword in node.keywords):
            continue

        changed = False
        args: list[str] = []
        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                normalized, part_changed = _normalize_overescaped_latex_commands(
                    arg.value
                )
                args.append(repr(normalized))
                changed = changed or part_changed
            else:
                args.append(ast.get_source_segment(code, arg) or ast.unparse(arg))

        if not changed:
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        call_args = [*args, *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in call_args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"MathTex/Tex过度转义命令修复: {len(replacements)}处"


_CJK_TEXT_MODE_EXTRA_CHARS = set("，。、：；？！《》“”‘’（）()【】[]·")


def _is_cjk_text_mode_char(ch: str) -> bool:
    return bool(_CHINESE_RE.match(ch)) or ch in _CJK_TEXT_MODE_EXTRA_CHARS


def _copy_latex_brace_group(value: str, start: int) -> int:
    depth = 0
    i = start
    while i < len(value):
        ch = value[i]
        if ch == "\\":
            i += 2
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth <= 0:
                return i + 1
        i += 1
    return start


def _wrap_cjk_runs_for_mathtex(value: str) -> tuple[str, bool]:
    if not _CHINESE_RE.search(value):
        return value, False

    parts: list[str] = []
    changed = False
    i = 0
    while i < len(value):
        if value.startswith(r"\text{", i) or value.startswith(r"\mbox{", i):
            end = _copy_latex_brace_group(value, value.find("{", i))
            parts.append(value[i:end])
            i = end
            continue
        if value[i] == "\\":
            j = i + 1
            while j < len(value) and value[j].isalpha():
                j += 1
            parts.append(value[i:j if j > i + 1 else i + 2])
            i = j if j > i + 1 else i + 2
            continue
        if _is_cjk_text_mode_char(value[i]):
            j = i + 1
            while j < len(value) and _is_cjk_text_mode_char(value[j]):
                j += 1
            text = value[i:j].replace("{", "").replace("}", "")
            parts.append(r"\text{" + text + "}")
            changed = True
            i = j
            continue
        parts.append(value[i])
        i += 1
    return "".join(parts), changed


def _fix_mathtex_cjk_runs_to_text_commands(code: str) -> Tuple[Optional[str], str]:
    """Wrap raw CJK runs in MathTex/Tex string literals with ``\text{}``.

    ctex enables CJK glyphs, but raw Chinese characters inside MathTex math mode
    can still fail as "Unicode character X". Wrapping only the CJK text keeps the
    formula as formula while making units like "元" render safely.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) not in {"MathTex", "Tex"}:
            continue
        if not node.args or any(keyword.arg is None for keyword in node.keywords):
            continue

        changed = False
        args: list[str] = []
        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                normalized, part_changed = _wrap_cjk_runs_for_mathtex(arg.value)
                args.append(repr(normalized))
                changed = changed or part_changed
            else:
                args.append(ast.get_source_segment(code, arg) or ast.unparse(arg))

        if not changed:
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        call_args = [*args, *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in call_args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"MathTex/Tex中文文本模式包裹: {len(replacements)}处"


def _fix_brace_get_text_cjk_labels(code: str) -> Tuple[Optional[str], str]:
    """Convert ``Brace.get_text("32元")`` CJK labels to Text next_to labels."""
    if ".get_text(" not in code or not _CHINESE_RE.search(code):
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute) or node.func.attr != "get_text":
            continue
        if not node.args:
            continue

        text_parts: list[str] = []
        for arg in node.args:
            if not isinstance(arg, ast.Constant) or not isinstance(arg.value, str):
                text_parts = []
                break
            text_parts.append(arg.value)
        if not text_parts:
            continue
        label_text = "".join(text_parts)
        if not _CHINESE_RE.search(label_text):
            continue

        target = ast.get_source_segment(code, node.func.value) or ast.unparse(node.func.value)
        font_size = "24"
        for keyword in node.keywords:
            if keyword.arg == "font_size":
                font_size = ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)
                break

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        replacement = (
            f"Text({label_text!r}, font_size={font_size})"
            f".next_to({target}, getattr({target}, \"direction\", UP), buff=0.12)"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"Brace中文标签Text化: {len(replacements)}处"


def _fix_handmade_ctex_template(code: str) -> Tuple[Optional[str], str]:
    """Use Manim's ctex template instead of raw ``TexTemplate()+\\usepackage{ctex}``."""
    if "TexTemplate()" not in code or "ctex" not in code:
        return None, ""

    lines = code.splitlines()
    converted: set[str] = set()
    for index, line in enumerate(lines):
        match = _HANDMADE_TEX_TEMPLATE_ASSIGN_RE.match(line)
        if not match:
            continue
        var_name = match.group("var")
        preamble_re = re.compile(
            rf"^\s*{re.escape(var_name)}\.add_to_preamble\(\s*r?['\"]\\usepackage\{{ctex\}}['\"]\s*\)\s*(?:#.*)?$"
        )
        lookahead = lines[index + 1:index + 8]
        if not any(preamble_re.match(candidate) for candidate in lookahead):
            continue
        lines[index] = f"{match.group('indent')}{var_name} = TexTemplateLibrary.ctex.copy()"
        converted.add(var_name)

    if not converted:
        return None, ""

    filtered: list[str] = []
    for line in lines:
        should_drop = False
        for var_name in converted:
            preamble_re = re.compile(
                rf"^\s*{re.escape(var_name)}\.add_to_preamble\(\s*r?['\"]\\usepackage\{{ctex\}}['\"]\s*\)\s*(?:#.*)?$"
            )
            if preamble_re.match(line):
                should_drop = True
                break
        if not should_drop:
            filtered.append(line)

    return (
        "\n".join(filtered) + ("\n" if code.endswith("\n") else ""),
        f"手写ctex模板归一化: {len(converted)}处",
    )


def _fix_mathtex_ctex_default(code: str) -> Tuple[Optional[str], str]:
    """Ensure MathTex uses the same ctex template configured for Tex."""
    template_match = _CTEX_TEMPLATE_ASSIGN_RE.search(code)
    if not template_match:
        return None, ""
    template_var = template_match.group("var")
    if not re.search(
        rf"(?m)^\s*Tex\.set_default\([^\n]*tex_template\s*=\s*{re.escape(template_var)}",
        code,
    ):
        return None, ""

    changed = 0

    def _replace_mathtex_default(match: re.Match) -> str:
        nonlocal changed
        args = match.group("args").strip()
        if "tex_template" in args:
            return match.group(0)
        changed += 1
        prefix = f"{match.group('indent')}MathTex.set_default("
        if args:
            return f"{prefix}tex_template={template_var}, {args})"
        return f"{prefix}tex_template={template_var})"

    modified = _MATHTEX_SET_DEFAULT_SINGLE_LINE_RE.sub(_replace_mathtex_default, code)
    if changed:
        return modified, f"MathTex默认ctex模板补齐: {changed}处"
    if re.search(r"MathTex\.set_default\([^\n]*tex_template\s*=", modified):
        return None, ""

    tex_default_match = _TEX_SET_DEFAULT_CTEX_LINE_RE.search(code)
    if not tex_default_match or tex_default_match.group("var") != template_var:
        return None, ""

    insert_at = tex_default_match.end()
    indent = tex_default_match.group("indent")
    line_sep = "\n"
    insertion = f"{line_sep}{indent}MathTex.set_default(tex_template={template_var})"
    modified = code[:insert_at] + insertion + code[insert_at:]
    return modified, "MathTex默认ctex模板补齐: 1处"


def _has_cjk_tex_payload(code: str) -> bool:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return False
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) not in {"MathTex", "Tex"}:
            continue
        for arg in node.args:
            value = _literal_string_value_for_voiceover(arg)
            if value is not None and _CHINESE_RE.search(value):
                return True
    return False


def _inject_ctex_defaults_for_cjk_mathtex(code: str) -> Tuple[Optional[str], str]:
    """Install ctex defaults when formula repair leaves CJK units in MathTex."""
    if "TexTemplateLibrary.ctex" in code or "_mathpi_ctex_template" in code:
        return None, ""
    if not _has_cjk_tex_payload(code):
        return None, ""

    lines = code.splitlines()
    insert_at = _voiceover_import_insert_index(lines)
    block = [
        "try:",
        "    _mathpi_ctex_template = TexTemplateLibrary.ctex.copy()",
        "    Tex.set_default(tex_template=_mathpi_ctex_template)",
        "    MathTex.set_default(tex_template=_mathpi_ctex_template)",
        "except Exception:",
        "    pass",
        "",
    ]
    updated = [*lines[:insert_at], *block, *lines[insert_at:]]
    return (
        "\n".join(updated) + ("\n" if code.endswith("\n") else ""),
        "MathTex中文公式ctex模板补齐: 1处",
    )


def _mathtex_index_color_removal_spans(
    code: str,
    *,
    var_name: str,
    after_lineno: int,
) -> list[tuple[int, int]]:
    lines, offsets = _line_offsets(code)
    spans: list[tuple[int, int]] = []

    for line_index in range(after_lineno, len(lines)):
        line = lines[line_index]
        match = _MATHTEX_INDEX_SET_COLOR_RE.match(line.rstrip("\r\n"))
        if not match or match.group("var") != var_name:
            break
        if int(match.group("index")) > 0:
            spans.append((offsets[line_index], offsets[line_index] + len(line)))

    return spans


def _fix_split_arrow_mathtex_args(code: str) -> Tuple[Optional[str], str]:
    """Merge split MathTex arrow fragments before LaTeX sees them.

    Generated code often splits formula parts to color submobjects, for example
    ``MathTex("(x,y)", "\\;\\xrightarrow{...}\\;", "(-y,x)")``.  Fragile
    arrow labels and standalone arrow fragments can fail LaTeX compilation, and
    merging the args means old ``formula[1].set_color(...)`` lines become
    out-of-range.  We collapse only arrow-only split calls and remove those
    now-invalid color lines deterministically before the LLM repair loop starts.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    assigned_calls: dict[int, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    assigned_calls[id(node.value)] = target.id
                    break
        elif isinstance(node, ast.AnnAssign) and isinstance(node.value, ast.Call):
            if isinstance(node.target, ast.Name):
                assigned_calls[id(node.value)] = node.target.id

    replacements: list[tuple[int, int, str]] = []
    removal_spans: list[tuple[int, int]] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "MathTex":
            continue
        if len(node.args) < 2:
            continue
        if any(keyword.arg is None for keyword in node.keywords):
            continue
        if not all(
            isinstance(arg, ast.Constant) and isinstance(arg.value, str)
            for arg in node.args
        ):
            continue

        parts = [arg.value for arg in node.args]  # type: ignore[union-attr]
        normalized_parts: list[str] = []
        changed = False
        has_arrow_only_part = False
        for part in parts:
            normalized, part_changed = _normalize_split_arrow_latex(part)
            normalized_parts.append(normalized)
            changed = changed or part_changed
            has_arrow_only_part = (
                has_arrow_only_part
                or _is_latex_arrow_only_argument(part)
                or _is_latex_arrow_only_argument(normalized)
            )

        if not has_arrow_only_part and not changed:
            continue

        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue

        line = code.splitlines()[node.lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        inner_indent = indent + "    "
        combined = "".join(part.strip() for part in normalized_parts if part.strip())
        kwargs = [
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
        ]
        args = [repr(combined), *kwargs]
        func_source = _call_func_source(node, code)
        replacement = (
            f"{func_source}(\n"
            + ",\n".join(f"{inner_indent}{arg}" for arg in args)
            + f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))
        assigned_var = assigned_calls.get(id(node))
        if assigned_var:
            removal_spans.extend(
                _mathtex_index_color_removal_spans(
                    code,
                    var_name=assigned_var,
                    after_lineno=getattr(node, "end_lineno", None) or node.lineno,
                )
            )

    if not replacements:
        return None, ""

    current = code
    edits = [*replacements, *((start, end, "") for start, end in removal_spans)]
    for start, end, replacement in sorted(edits, reverse=True):
        current = current[:start] + replacement + current[end:]

    desc = f"MathTex箭头参数合并: {len(replacements)}处"
    if removal_spans:
        desc += f", 移除越界索引着色{len(removal_spans)}行"
    return current, desc


def _fix_latex_point_primes_in_over_arrows(code: str) -> Tuple[Optional[str], str]:
    r"""Normalize point primes inside \overrightarrow{...}.

    XeLaTeX can fail on generated formulas such as
    ``\overrightarrow{DD'}`` or ``\overrightarrow{A'B'}``.  The equivalent
    braced form renders reliably and is still compact:
    ``\overrightarrow{DD^{\prime}}``.
    """
    fix_count = 0

    def _fix_arrow_body(match: re.Match) -> str:
        nonlocal fix_count
        prefix, body, suffix = match.groups()

        def _replace_prime(prime_match: re.Match) -> str:
            nonlocal fix_count
            fix_count += 1
            letter = prime_match.group(1)
            primes = prime_match.group(2)
            prime_cmd = r"\prime" * len(primes)
            return f"{letter}^{{{prime_cmd}}}"

        fixed_body = _LATEX_POINT_PRIME_RE.sub(_replace_prime, body)
        return f"{prefix}{fixed_body}{suffix}"

    def _replace_latex_string(match: re.Match) -> str:
        prefix, quote, content = match.groups()
        if "\\over" not in content or "'" not in content:
            return match.group(0)
        fixed = _LATEX_OVER_ARROW_RE.sub(_fix_arrow_body, content)
        if fixed == content:
            return match.group(0)
        return f"{prefix}{quote}{fixed}{quote}"

    modified = _LATEX_STR_RE.sub(_replace_latex_string, code)
    if fix_count > 0:
        return modified, f"LaTeX向量撇号修复: {fix_count}处"
    return None, ""


def _fix_prime_point_text_labels(code: str) -> Tuple[Optional[str], str]:
    """Render standalone point labels such as C' as MathTex prime labels.

    This intentionally only rewrites single-letter point labels. Sentences like
    ``Text("折叠后 C' 落在 AC 上")`` remain normal text and are handled by the
    formula/text boundary compiler when needed.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "Text":
            continue
        if not node.args or not isinstance(node.args[0], ast.Constant):
            continue
        value = node.args[0].value
        if not isinstance(value, str):
            continue
        match = _POINT_PRIME_LABEL_RE.match(value.strip())
        if not match:
            continue
        span = _source_span_for_multiline_node(node, code)
        if not span:
            continue
        letter = match.group(1)
        args = [f'"{letter}^{{\\\\prime}}"']
        args.extend(
            ast.get_source_segment(code, arg) or ast.unparse(arg)
            for arg in node.args[1:]
        )
        args.extend(
            f"{keyword.arg}={ast.get_source_segment(code, keyword.value) or ast.unparse(keyword.value)}"
            for keyword in node.keywords
            if keyword.arg is not None
        )
        replacements.append((span[0], span[1], f"MathTex({', '.join(args)})"))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, reverse=True):
        current = current[:start] + replacement + current[end:]
    return current, f"prime_point_label_to_mathtex: {len(replacements)}处"


def _fix_latex_brace_mismatch(
    code: str,
) -> Tuple[Optional[str], str]:
    """检测并修复 LaTeX 字符串中大括号不匹配问题。

    常见错误模式:
    - \\dfrac{a}{b 缺少右括号
    - \\text{hello}} 多余右括号
    - 嵌套 \\dfrac{\\frac{a}{b}}{c} 中的层级错误
    """
    fix_count = 0

    def _fix_latex_in_string(latex: str) -> str:
        """修复单个 LaTeX 字符串中的大括号。"""
        nonlocal fix_count
        # 只处理包含 LaTeX 命令的字符串
        if '\\' not in latex:
            return latex
        # 检查整体括号平衡
        depth = 0
        for ch in latex:
            if ch == '{':
                depth += 1
            elif ch == '}':
                depth -= 1
        if depth == 0:
            return latex  # 已平衡
        if depth > 0:
            # 缺少右括号 — 在末尾补上
            latex = latex + '}' * depth
            fix_count += depth
        elif depth < 0:
            # 多余右括号 — 从右往左删除多余的 }
            excess = -depth
            chars = list(latex)
            removed = 0
            for i in range(len(chars) - 1, -1, -1):
                if removed >= excess:
                    break
                if chars[i] == '}':
                    # 确认这个 } 是多余的
                    # 重新计算到 i 为止的平衡
                    d = 0
                    for j in range(i + 1):
                        if chars[j] == '{':
                            d += 1
                        elif chars[j] == '}':
                            d -= 1
                    if d < 0:
                        chars[i] = ''
                        removed += 1
            if removed > 0:
                latex = ''.join(chars)
                fix_count += removed
        return latex

    def _replace_str(m):
        prefix = m.group(1)  # r or ''
        quote = m.group(2)
        content = m.group(3)
        if re.search(r"\.replace\(\s*$", code[max(0, m.start() - 20):m.start()]):
            return m.group(0)
        # 只处理像 LaTeX 的字符串
        if '\\' not in content:
            return m.group(0)
        # 检查是否在 MathTex/Tex/Text 参数中
        # 简单方法：只处理含 LaTeX 命令的字符串
        has_latex_cmd = False
        for cmd in _LATEX_CMD_ARGS:
            if f'\\{cmd}' in content:
                has_latex_cmd = True
                break
        if not has_latex_cmd:
            return m.group(0)
        fixed = _fix_latex_in_string(content)
        if fixed != content:
            return f'{prefix}{quote}{fixed}{quote}'
        return m.group(0)

    modified = _LATEX_STR_RE.sub(_replace_str, code)
    if fix_count > 0:
        return modified, f"LaTeX大括号修复: {fix_count}处"
    return None, ""
def _fix_deprecated_get_vector(code: str) -> Tuple[Optional[str], str]:
    """修复 Manim v0.19.0 中已移除的 .get_vector() 调用。

    Angle/Arc 对象的 .get_vector() 在新版本中已被移除，
    替换为 (obj.get_end() - obj.get_start()) 来获取方向向量。
    """
    pattern = re.compile(r'(\w+)\.get_vector\(\)')
    modified = pattern.sub(r'(\1.get_end() - \1.get_start())', code)
    if modified != code:
        count = len(pattern.findall(code))
        return modified, f"废弃API修复: {count}处 .get_vector() → (end - start)"
    return None, ""
def _fix_text_with_latex(code: str) -> Tuple[Optional[str], str]:
    r"""Fix Text() calls that contain LaTeX \text{} syntax.

    LLM sometimes writes Text(r"1. \text{content} X") instead of Text("1. content X").
    Strip \text{...} wrappers inside Text() calls, keeping inner content.
    """
    text_call_re = re.compile(r'(Text\s*\()(.+?)(\))')
    latex_text_re = re.compile(r'\\text\{([^}]*)\}')

    count = 0

    def fix_line(line):
        nonlocal count

        def replacer(m):
            nonlocal count
            prefix, inner, suffix = m.group(1), m.group(2), m.group(3)
            new_inner = latex_text_re.sub(r'\1', inner)
            if new_inner != inner:
                count += 1
                return prefix + new_inner + suffix
            return m.group(0)
        return text_call_re.sub(replacer, line)

    new_lines = [fix_line(line) for line in code.split("\n")]
    if count > 0:
        return "\n".join(new_lines), f"修复 {count} 处 Text() 内的 LaTeX \\text{{}} 语法"
    return None, ""


def _positioned_node_span(node: ast.AST, code: str) -> Optional[tuple[int, int]]:
    lineno = getattr(node, "lineno", None)
    col_offset = getattr(node, "col_offset", None)
    end_lineno = getattr(node, "end_lineno", None)
    end_col_offset = getattr(node, "end_col_offset", None)
    if (
        lineno is None
        or col_offset is None
        or end_lineno is None
        or end_col_offset is None
    ):
        return None
    lines = code.splitlines(keepends=True)
    if lineno < 1 or end_lineno < 1 or lineno > len(lines) or end_lineno > len(lines):
        return None
    offsets: list[int] = []
    pos = 0
    for line in lines:
        offsets.append(pos)
        pos += len(line)
    start_line = lines[lineno - 1]
    end_line = lines[end_lineno - 1]
    start = offsets[lineno - 1] + _byte_col_to_char_col(start_line, col_offset)
    end = offsets[end_lineno - 1] + _byte_col_to_char_col(end_line, end_col_offset)
    return start, end


def _keyword_removal_span(code: str, start: int, end: int) -> tuple[int, int]:
    after = end
    while after < len(code) and code[after] in " \t\r\n":
        after += 1
    if after < len(code) and code[after] == ",":
        return start, after + 1

    before = start
    while before > 0 and code[before - 1] in " \t\r\n":
        before -= 1
    if before > 0 and code[before - 1] == ",":
        return before - 1, end
    return start, end


def _ensure_dashed_line_import(code: str) -> str:
    if "DashedLine(" not in code or "from manim import *" in code:
        return code

    def _replace(match: re.Match) -> str:
        imported = [part.strip() for part in match.group("names").split(",")]
        if "DashedLine" in imported or "Line" not in imported:
            return match.group(0)
        return f"from manim import {match.group('names')}, DashedLine"

    return re.sub(
        r"(?m)^from\s+manim\s+import\s+(?P<names>[A-Za-z0-9_, \t]+)$",
        _replace,
        code,
        count=1,
    )


def _fix_line_stroke_dash_ratio(code: str) -> Tuple[Optional[str], str]:
    """Line(stroke_dash_ratio=...) is invalid in Manim 0.19; use DashedLine."""
    if "stroke_dash_ratio" not in code or "Line" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    converted = 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "Line":
            continue
        dash_keywords = [
            keyword
            for keyword in node.keywords
            if keyword.arg == "stroke_dash_ratio"
        ]
        if not dash_keywords:
            continue

        func_span = _positioned_node_span(node.func, code)
        if not func_span:
            continue
        func_source = ast.get_source_segment(code, node.func) or ""
        if isinstance(node.func, ast.Name):
            replacements.append((func_span[0], func_span[1], "DashedLine"))
        elif isinstance(node.func, ast.Attribute) and func_source.endswith(".Line"):
            replacements.append((func_span[1] - len("Line"), func_span[1], "DashedLine"))
        else:
            continue

        removed_any_keyword = False
        for keyword in dash_keywords:
            keyword_span = _positioned_node_span(keyword, code)
            if not keyword_span:
                continue
            start, end = _keyword_removal_span(code, *keyword_span)
            replacements.append((start, end, ""))
            removed_any_keyword = True
        if removed_any_keyword:
            converted += 1

    if converted == 0 or not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(replacements, key=lambda item: item[0], reverse=True):
        current = current[:start] + replacement + current[end:]
    current = re.sub(r",([ \t]{2,})", ", ", current)
    current = re.sub(r"(?m)^[ \t]+\n", "", current)
    current = _ensure_dashed_line_import(current)
    if current == code:
        return None, ""
    return current, f"Manim 0.19虚线参数修复: {converted}处 Line→DashedLine"


def _fix_use_smoothing_unsupported_kwargs(code: str) -> Tuple[Optional[str], str]:
    """Remove Manim 0.19 incompatible use_smoothing defaults before render."""
    if "use_smoothing" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    parents: dict[int, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parents[id(child)] = parent

    lines, line_offsets = _line_offsets(code)
    edits: list[tuple[int, int, str]] = []
    changed = 0
    set_default_targets = {"ParametricFunction", "Surface"}
    constructor_targets = {"ParametricFunction", "Surface"}

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        target_name = _call_func_name(node.func)
        is_target_constructor = target_name in constructor_targets
        is_target_set_default = (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "set_default"
            and _call_func_name(node.func.value) in set_default_targets
        )
        if not is_target_constructor and not is_target_set_default:
            continue

        smoothing_keywords = [
            keyword for keyword in node.keywords if keyword.arg == "use_smoothing"
        ]
        if not smoothing_keywords:
            continue

        if is_target_set_default and not node.args and len(node.keywords) == len(smoothing_keywords):
            parent = parents.get(id(node))
            if isinstance(parent, ast.Expr):
                statement_span = _positioned_node_span(parent, code)
                if statement_span:
                    edits.append((statement_span[0], statement_span[1], "pass"))
                    changed += 1
                    continue

        for keyword in smoothing_keywords:
            span = _keyword_removal_span_for_repair(keyword, code, lines, line_offsets)
            if not span:
                continue
            edits.append((*span, ""))
            changed += 1

    if not edits:
        return None, ""

    current = _apply_keyword_edits_for_repair(code, edits)
    if current == code:
        return None, ""
    return current, f"Manim use_smoothing参数清理: {changed}处"


def _fix_manim_019_api_kwargs(code: str) -> Tuple[Optional[str], str]:
    """Fix common Manim 0.19 keyword mismatches before rendering.

    These patterns are cheap to repair and otherwise trigger runtime TypeError
    followed by an expensive LLM repair round.
    """
    current = code
    fix_count = 0

    def _fix_set_stroke(match: re.Match) -> str:
        nonlocal fix_count
        args = match.group(1)
        fixed_args = args
        replacements = (
            ("stroke_color", "color"),
            ("stroke_width", "width"),
            ("stroke_opacity", "opacity"),
        )
        for old, new in replacements:
            fixed_args, changed = re.subn(
                rf"(?<!\w){old}\s*=", f"{new}=", fixed_args
            )
            fix_count += changed
        for value_re in (r"\[[^\]]*\]", r"\([^)]*\)", r"[^,\)]+"):
            fixed_args, changed = re.subn(
                rf",\s*dash_array\s*=\s*{value_re}",
                "",
                fixed_args,
            )
            fix_count += changed
            fixed_args, changed = re.subn(
                rf"(?<!\w)dash_array\s*=\s*{value_re}\s*,\s*",
                "",
                fixed_args,
            )
            fix_count += changed
            fixed_args, changed = re.subn(
                rf"(?<!\w)dash_array\s*=\s*{value_re}\s*$",
                "",
                fixed_args,
            )
            fix_count += changed
        return f".set_stroke({fixed_args})"

    current = re.sub(
        r"\.set_stroke\((.*?)\)",
        _fix_set_stroke,
        current,
        flags=re.DOTALL,
    )

    def _drop_keyword_arg(args: str, keyword: str) -> tuple[str, int]:
        fixed, count = re.subn(
            rf",\s*{keyword}\s*=\s*[^,\)]+",
            "",
            args,
        )
        fixed, count2 = re.subn(
            rf"(?<!\w){keyword}\s*=\s*[^,\)]+\s*,\s*",
            "",
            fixed,
        )
        fixed, count3 = re.subn(
            rf"(?<!\w){keyword}\s*=\s*[^,\)]+\s*$",
            "",
            fixed,
        )
        return fixed, count + count2 + count3

    def _fix_next_to(match: re.Match) -> str:
        nonlocal fix_count
        args = match.group(1)
        fixed_args, changed = _drop_keyword_arg(args, "font_size")
        fix_count += changed
        fixed_args, changed = re.subn(
            r"(?<!\w)alignment\s*=",
            "aligned_edge=",
            fixed_args,
        )
        fix_count += changed
        return f".next_to({fixed_args})"

    current = re.sub(
        r"\.next_to\((.*?)\)",
        _fix_next_to,
        current,
        flags=re.DOTALL,
    )

    def _fix_arrange(match: re.Match) -> str:
        nonlocal fix_count
        args = match.group(1)
        fixed_args, changed = re.subn(
            r"(?<!\w)alignment\s*=",
            "aligned_edge=",
            args,
        )
        fix_count += changed
        return f".arrange({fixed_args})"

    current = re.sub(
        r"\.arrange\((.*?)\)",
        _fix_arrange,
        current,
        flags=re.DOTALL,
    )

    if "alignment" in current and any(
        f"{name}(" in current for name in ("Text", "Tex", "MathTex", "MarkupText")
    ):
        try:
            tree = ast.parse(current)
        except SyntaxError:
            tree = None
        if tree is not None:
            edits: list[tuple[int, int, str]] = []
            text_constructor_names = {"Text", "Tex", "MathTex", "MarkupText"}
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                if _call_func_name(node.func) not in text_constructor_names:
                    continue
                for keyword in node.keywords:
                    if keyword.arg != "alignment":
                        continue
                    keyword_span = _positioned_node_span(keyword, current)
                    if not keyword_span:
                        continue
                    start, end = _keyword_removal_span(current, *keyword_span)
                    edits.append((start, end, ""))
                    fix_count += 1
            for start, end, replacement in sorted(
                edits, key=lambda item: item[0], reverse=True
            ):
                current = current[:start] + replacement + current[end:]

    animation_names = (
        "Create", "Write", "FadeIn", "FadeOut", "Indicate", "Circumscribe",
        "Uncreate", "GrowArrow", "DrawBorderThenFill", "ShowPassingFlash",
        "FocusOn", "Flash",
    )
    animation_re = re.compile(
        r"\b("
        + "|".join(re.escape(name) for name in animation_names)
        + r")\(\s*mobject\s*=\s*([^,\)\n\(]+)"
    )

    def _fix_animation_mobject(match: re.Match) -> str:
        nonlocal fix_count
        fix_count += 1
        return f"{match.group(1)}({match.group(2)}"

    current = animation_re.sub(_fix_animation_mobject, current)

    mobject_constructor_names = (
        "SurroundingRectangle",
        "BackgroundRectangle",
    )
    constructor_re = re.compile(
        r"\b("
        + "|".join(re.escape(name) for name in mobject_constructor_names)
        + r")\(\s*mobject\s*=\s*([^,\)\n\(]+)"
    )

    def _fix_constructor_mobject(match: re.Match) -> str:
        nonlocal fix_count
        fix_count += 1
        return f"{match.group(1)}({match.group(2)}"

    current = constructor_re.sub(_fix_constructor_mobject, current)

    if "Line3D(" in current and "width" in current:
        try:
            tree = ast.parse(current)
        except SyntaxError:
            tree = None
        if tree is not None:
            lines, line_offsets = _line_offsets(current)
            edits: list[tuple[int, int, str]] = []
            for node in ast.walk(tree):
                if not (
                    isinstance(node, ast.Call)
                    and _call_func_name(node.func) == "Line3D"
                ):
                    continue
                has_thickness = any(
                    keyword.arg == "thickness" for keyword in node.keywords
                )
                for keyword in node.keywords:
                    if keyword.arg != "width":
                        continue
                    if has_thickness:
                        span = _keyword_removal_span_for_repair(
                            keyword,
                            current,
                            lines,
                            line_offsets,
                        )
                        replacement = ""
                    else:
                        span = _keyword_name_span_for_repair(
                            keyword,
                            current,
                            lines,
                            line_offsets,
                        )
                        replacement = "thickness"
                    if span:
                        edits.append((*span, replacement))
            if edits:
                current = _apply_keyword_edits_for_repair(current, edits)
                fix_count += len(edits)

    if "Code(" in current:
        try:
            tree = ast.parse(current)
        except SyntaxError:
            tree = None
        if tree is not None:
            lines, line_offsets = _line_offsets(current)
            edits: list[tuple[int, int, str]] = []
            unsupported_code_keywords = {
                "font",
                "font_size",
                "line_spacing",
                "margin",
                "background_stroke_width",
                "background_stroke_color",
                "corner_radius",
                "generate_html_file",
                "warn_missing_font",
            }
            rename_code_keywords = {
                "code": "code_string",
                "style": "formatter_style",
                "insert_line_no": "add_line_numbers",
            }
            for node in ast.walk(tree):
                if not (
                    isinstance(node, ast.Call)
                    and _call_func_name(node.func) == "Code"
                ):
                    continue
                for keyword in node.keywords:
                    if not keyword.arg:
                        continue
                    if keyword.arg in rename_code_keywords:
                        span = _keyword_name_span_for_repair(
                            keyword,
                            current,
                            lines,
                            line_offsets,
                        )
                        if span:
                            edits.append((*span, rename_code_keywords[keyword.arg]))
                    elif keyword.arg in unsupported_code_keywords:
                        span = _keyword_removal_span_for_repair(
                            keyword,
                            current,
                            lines,
                            line_offsets,
                        )
                        if span:
                            edits.append((*span, ""))
            if edits:
                current = _apply_keyword_edits_for_repair(current, edits)
                fix_count += len(edits)

    unsupported_stroke_style_constructors = {
        "Mobject",
        "Polygon",
        "Rectangle",
        "Square",
        "Circle",
        "Line",
        "Arrow",
        "DoubleArrow",
    }
    unsupported_style_keywords = {"stroke_style", "stroke_dash_pattern"}
    if any(keyword in current for keyword in unsupported_style_keywords):
        try:
            tree = ast.parse(current)
        except SyntaxError:
            tree = None
        if tree is not None:
            lines, line_offsets = _line_offsets(current)
            removals: list[tuple[int, int]] = []
            for node in ast.walk(tree):
                if not (
                    isinstance(node, ast.Call)
                    and _call_func_name(node.func) in unsupported_stroke_style_constructors
                ):
                    continue
                for keyword in node.keywords:
                    if keyword.arg not in unsupported_style_keywords:
                        continue
                    span = _keyword_removal_span_for_repair(
                        keyword,
                        current,
                        lines,
                        line_offsets,
                    )
                    if span:
                        removals.append(span)
            if removals:
                for start, end in sorted(removals, reverse=True):
                    current = current[:start] + current[end:]
                fix_count += len(removals)

    if "left=" in current and "right=" in current and any(
        f"{name}(" in current for name in ("Line", "Arrow", "DoubleArrow", "DashedLine")
    ):
        try:
            tree = ast.parse(current)
        except SyntaxError:
            tree = None
        if tree is not None:
            line_like_constructors = {"Line", "Arrow", "DoubleArrow", "DashedLine"}
            edits: list[tuple[int, int, str]] = []
            for node in ast.walk(tree):
                if not (
                    isinstance(node, ast.Call)
                    and _call_func_name(node.func) in line_like_constructors
                ):
                    continue
                left_keyword = next((kw for kw in node.keywords if kw.arg == "left"), None)
                right_keyword = next((kw for kw in node.keywords if kw.arg == "right"), None)
                if left_keyword is None or right_keyword is None:
                    continue
                call_span = _source_span_for_multiline_node(node, current)
                func_src = ast.get_source_segment(current, node.func)
                left_src = ast.get_source_segment(current, left_keyword.value)
                right_src = ast.get_source_segment(current, right_keyword.value)
                if not call_span or not func_src or not left_src or not right_src:
                    continue
                parts = [left_src, right_src]
                parts.extend(
                    arg_src
                    for arg in node.args
                    if (arg_src := ast.get_source_segment(current, arg))
                )
                parts.extend(
                    kw_src
                    for kw in node.keywords
                    if kw.arg not in {"left", "right"}
                    if (kw_src := ast.get_source_segment(current, kw))
                )
                edits.append((call_span[0], call_span[1], f"{func_src}({', '.join(parts)})"))
            if edits:
                for start, end, replacement in sorted(
                    edits, key=lambda item: item[0], reverse=True
                ):
                    current = current[:start] + replacement + current[end:]
                fix_count += len(edits)

    curved_arrow_refs = {
        match.group("ref")
        for match in re.finditer(
            r"(?m)^[ \t]*(?P<ref>(?:self\.)?[A-Za-z_]\w*)\s*=\s*CurvedArrow\s*\(",
            current,
        )
    }
    if curved_arrow_refs:
        ref_pattern = "|".join(
            re.escape(ref)
            for ref in sorted(curved_arrow_refs, key=len, reverse=True)
        )
        current, changed = re.subn(
            rf"\bGrowArrow\(\s*({ref_pattern})\s*\)",
            r"Create(\1)",
            current,
        )
        fix_count += changed

    current, changed = re.subn(
        r"\bGrowArrow\(\s*(?=(?:[A-Za-z_]\w*\.)?CurvedArrow\s*\()",
        "Create(",
        current,
    )
    fix_count += changed

    fixed, _desc = _fix_line_stroke_dash_ratio(current)
    if fixed:
        current = fixed
        fix_count += 1

    if current != code:
        return current, f"Manim 0.19 API参数修复: {fix_count}处"
    return None, ""


_SCENE_PLAY_ANIMATION_NAMES = {
    "AddTextLetterByLetter",
    "AnimationGroup",
    "ApplyFunction",
    "ApplyMethod",
    "ApplyPointwiseFunction",
    "ApplyWave",
    "Broadcast",
    "Circumscribe",
    "Create",
    "DrawBorderThenFill",
    "FadeIn",
    "FadeOut",
    "FadeToColor",
    "Flash",
    "FocusOn",
    "GrowArrow",
    "GrowFromCenter",
    "GrowFromEdge",
    "GrowFromPoint",
    "Indicate",
    "LaggedStart",
    "MoveAlongPath",
    "ReplacementTransform",
    "Restore",
    "Rotate",
    "Rotating",
    "ShowCreation",
    "ShowIncreasingSubsets",
    "ShowPassingFlash",
    "Succession",
    "Transform",
    "TransformFromCopy",
    "TransformMatchingShapes",
    "TransformMatchingTex",
    "Uncreate",
    "Unwrite",
    "UpdateFromAlphaFunc",
    "Wait",
    "Write",
}

_SCENE_PLAY_RAW_MOBJECT_CONSTRUCTORS = {
    "Angle",
    "AnnularSector",
    "Arc",
    "Arrow",
    "Axes",
    "Brace",
    "BraceBetweenPoints",
    "Circle",
    "DashedLine",
    "Dot",
    "Ellipse",
    "Graph",
    "Line",
    "MathTex",
    "NumberLine",
    "NumberPlane",
    "ParametricFunction",
    "Polygon",
    "Rectangle",
    "RegularPolygon",
    "RoundedRectangle",
    "Square",
    "Star",
    "SurroundingRectangle",
    "Tex",
    "Text",
    "Triangle",
    "VGroup",
    "VMobject",
}


def _is_self_play_call(node: ast.Call) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == "play"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _contains_animate_attr(node: ast.AST) -> bool:
    for child in ast.walk(node):
        if isinstance(child, ast.Attribute) and child.attr == "animate":
            return True
    return False


def _mobject_constructor_name_from_expr(node: ast.AST) -> str:
    if not isinstance(node, ast.Call):
        return ""
    name = _call_func_name(node.func)
    if name in _SCENE_PLAY_RAW_MOBJECT_CONSTRUCTORS:
        return name
    if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Call):
        return _mobject_constructor_name_from_expr(node.func.value)
    return ""


def _assigned_mobject_names(func: ast.FunctionDef) -> set[str]:
    names: set[str] = set()
    for statement in ast.walk(func):
        value = getattr(statement, "value", None)
        if not isinstance(value, ast.AST):
            continue
        if not _mobject_constructor_name_from_expr(value):
            continue
        targets = getattr(statement, "targets", None)
        if not isinstance(targets, list):
            continue
        for target in targets:
            if isinstance(target, ast.Name):
                names.add(target.id)
    return names


def _scene_play_arg_needs_create(arg: ast.AST, mobject_names: set[str]) -> bool:
    if isinstance(arg, ast.Starred):
        return False
    if _contains_animate_attr(arg):
        return False
    if isinstance(arg, ast.Call):
        name = _call_func_name(arg.func)
        if name in _SCENE_PLAY_ANIMATION_NAMES:
            return False
        return bool(_mobject_constructor_name_from_expr(arg))
    return isinstance(arg, ast.Name) and arg.id in mobject_names


def _fix_raw_mobject_scene_play_args(code: str) -> Tuple[Optional[str], str]:
    """Wrap raw Mobjects passed to self.play() in Create(...)."""
    if "self.play(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef) or node.name != "construct":
            continue
        mobject_names = _assigned_mobject_names(node)
        for call in ast.walk(node):
            if not isinstance(call, ast.Call) or not _is_self_play_call(call):
                continue
            for arg in call.args:
                if not _scene_play_arg_needs_create(arg, mobject_names):
                    continue
                span = _positioned_node_span(arg, code)
                if not span:
                    continue
                segment = ast.get_source_segment(code, arg) or ast.unparse(arg)
                replacements.append((span[0], span[1], f"Create({segment})"))

    if not replacements:
        return None, ""

    current = code
    changed = 0
    seen_spans: set[tuple[int, int]] = set()
    for start, end, replacement in sorted(replacements, reverse=True):
        key = (start, end)
        if key in seen_spans:
            continue
        seen_spans.add(key)
        current = current[:start] + replacement + current[end:]
        changed += 1
    return current, f"Scene.play裸Mobject修复: {changed}处"


def _dedup_scene_classes(code: str) -> Tuple[Optional[str], str]:
    """Remove duplicate Scene class definitions, keeping the last (complete) one.

    When LLM output is truncated mid-class and the fix mechanism appends
    a new complete copy, the file ends up with two definitions of the same
    class. Python would silently use the last one, but the truncated first
    copy may cause SyntaxError. This function detects and removes duplicates.
    """
    import ast

    # Find all class definitions with their positions
    class_pattern = re.compile(
        r'^class\s+(Scene_\d+_\w+)\s*\(', re.MULTILINE)
    matches = list(class_pattern.finditer(code))

    # Count occurrences of each class name
    name_positions = {}
    for m in matches:
        name = m.group(1)
        name_positions.setdefault(name, []).append(m.start())

    duplicates = {
        name: positions
        for name, positions in name_positions.items()
        if len(positions) > 1
    }

    if not duplicates:
        return None, ""

    # For each duplicate, remove all but the last occurrence
    # Strategy: find boundaries of each class definition, remove earlier ones
    lines = code.split('\n')
    line_starts = [0]
    for line in lines:
        line_starts.append(line_starts[-1] + len(line) + 1)

    ranges_to_remove = []  # (start_line, end_line) 0-indexed
    removed_names = []

    for name, positions in duplicates.items():
        # Keep the last one, remove all earlier ones
        for pos in positions[:-1]:
            # Find the line number of this class def
            start_line = None
            for i, ls in enumerate(line_starts):
                if ls > pos:
                    start_line = i - 1
                    break
            if start_line is None:
                continue

            # Find the end of this class: next top-level class or end of file
            end_line = len(lines)
            for j in range(start_line + 1, len(lines)):
                stripped = lines[j]
                if re.match(r'^class\s+\w+', stripped):
                    end_line = j
                    break
                # Also stop at section comment blocks
                if re.match(r'^#\s*={10,}', stripped) and j > start_line + 2:
                    end_line = j
                    break

            ranges_to_remove.append((start_line, end_line))
            removed_names.append(name)

    if not ranges_to_remove:
        return None, ""

    # Sort ranges in reverse order to remove from bottom up
    ranges_to_remove.sort(reverse=True)

    new_lines = list(lines)
    for start, end in ranges_to_remove:
        del new_lines[start:end]

    result = '\n'.join(new_lines)

    # Verify the result parses (or at least doesn't make things worse)
    try:
        ast.parse(result)
    except SyntaxError:
        # If removing duplicates broke syntax, check if original was also broken
        try:
            ast.parse(code)
            return None, ""  # Original was fine, don't break it
        except SyntaxError:
            pass  # Original was also broken, our fix might help
            # Return the deduped version anyway — it removes the truncated copy

    desc = f"去重 {len(removed_names)} 个重复Scene类: {', '.join(removed_names)}"
    return result, desc
# --- 背景色契约 -------------------------------------------------------
# 用户在前端选择的 color_scheme 是产品契约，必须强制执行：
#   1/2 = 浅色背景，3/4 = 深色背景
# LLM 经常擅自把背景改成「白板/米白」或者把黑底改成浅色，
# 这里在落盘前做一次最小化校验：只动「确实属于背景的赋值」，
# 不会一刀切替换正文颜色（避免把强调色/公式色一起抹平）。

# 配色方案对应的官方背景色（与 prompts/header_template.py 一致）
_CORRECT_BG = {
    1: '#F5F5F0',  # 米白
    2: '#FBF9FF',  # 淡紫
    3: '#000000',  # 经典黑底
    4: '#1E1E2E',  # 深蓝黑
}
# 哪些方案算「浅色」「深色」
_LIGHT_SCHEMES = {1, 2}
_DARK_SCHEMES = {3, 4}

# 视为背景写法的标识符（左值）。为了避免误伤，必须能枚举：
# - self.camera.background_color
# - GlobalConfig.BG_COLOR  /  cls.BG_COLOR
# - 模块级 BG / BG_COLOR / BACKGROUND_COLOR / BACKGROUND
_BG_LHS_RE = re.compile(
    r'(?P<lhs>'
    r'self\.camera\.background_color'
    r'|(?:GlobalConfig|cls|self)\.BG_COLOR'
    r'|\bBG_COLOR\b'
    r'|\bBACKGROUND_COLOR\b'
    r'|\bBACKGROUND\b'
    r'|\bBG\b'
    r')\s*=\s*'
    r'(?P<rhs>"#[0-9A-Fa-f]{3,8}"|\'#[0-9A-Fa-f]{3,8}\'|[A-Z_][A-Z0-9_]{1,20})'
)

# 常见 manim 命名色 → 是否「浅色」（亮度 > 0.5）
_NAMED_COLOR_IS_LIGHT = {
    'WHITE': True, 'GREY_A': True, 'GRAY_A': True, 'LIGHT_GREY': True,
    'LIGHT_GRAY': True, 'YELLOW': True, 'GOLD': True, 'GOLD_A': True,
    'LIGHT_PINK': True, 'LIGHT_BROWN': True, 'GREEN_A': True, 'BLUE_A': True,
    'BLACK': False, 'DARK_GREY': False, 'DARK_GRAY': False, 'GREY_E': False,
    'GRAY_E': False, 'GREY_D': False, 'GRAY_D': False, 'DARKER_GRAY': False,
    'DARKER_GREY': False,
}


def _hex_is_light(hex_value: str) -> Optional[bool]:
    """判断 #RRGGBB 是否为浅色（按 ITU-R BT.601 亮度公式）。

    None 表示无法解析，调用方应跳过。
    """
    h = hex_value.strip().lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    if len(h) not in (6, 8):
        return None
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        return None
    luma = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    return luma > 0.5


def _rhs_is_light(rhs: str) -> Optional[bool]:
    """判断背景赋值右值是否为浅色。"""
    raw = rhs.strip()
    if raw.startswith(('"', "'")):
        return _hex_is_light(raw.strip('"\''))
    return _NAMED_COLOR_IS_LIGHT.get(raw)


def _enforce_background_contract(
    code: str, color_scheme: int,
) -> Tuple[str, list]:
    """背景色契约校验：强制保证最终背景色与用户所选方案一致。

    覆盖的写法：
        self.camera.background_color = "#xxx" / WHITE / BG_COLOR
        GlobalConfig.BG_COLOR = "#xxx" / BLACK
        BG = "#xxx"  / BG_COLOR = "#xxx"  / BACKGROUND_COLOR = "#xxx"

    判定逻辑：根据亮度，判定方向是否与用户选择相反；只有在「方向相反」
    时才替换为该方案的官方背景色，避免误伤同方向的细微差异。
    """
    correct_bg = _CORRECT_BG.get(color_scheme)
    if not correct_bg:
        return code, []

    want_light = color_scheme in _LIGHT_SCHEMES
    want_dark = color_scheme in _DARK_SCHEMES
    if not (want_light or want_dark):
        return code, []

    notes: list = []

    def _sub(match: re.Match) -> str:
        rhs = match.group('rhs')
        is_light = _rhs_is_light(rhs)
        if is_light is None:
            # 未知命名色（例如自定义变量），不动
            return match.group(0)
        # 方向一致就放行；只有方向相反才强制覆盖
        if (want_light and is_light) or (want_dark and not is_light):
            return match.group(0)
        notes.append(f"{match.group('lhs')}={rhs}→{correct_bg}")
        return f'{match.group("lhs")} = "{correct_bg}"'

    new_code = _BG_LHS_RE.sub(_sub, code)
    return new_code, notes


def _fix_low_contrast_colors(
    code: str, color_scheme: int,
) -> Tuple[Optional[str], str]:
    """根据背景色修复低对比度颜色。

    1) 背景契约：覆盖 self.camera.background_color / GlobalConfig.BG_COLOR /
       BG / BG_COLOR / BACKGROUND_COLOR 等多种写法，按亮度方向校验。
    2) 前景色：只在 color=/fill_color=/stroke_color= 上替换 WHITE/BLACK 等
       与背景同向的命名色，避免把所有颜色抹平、误伤强调色与公式色。
    """
    replacements: list = []
    current = code

    # --- 1) 背景色契约校验（多写法） ---
    new_code, bg_notes = _enforce_background_contract(current, color_scheme)
    if bg_notes:
        current = new_code
        replacements.extend(bg_notes)

    # --- 2) 前景色对比度修复 ---
    # 匹配 color=, fill_color=, stroke_color= 的 Manim 颜色常量
    _COLOR_ATTRS = r'(?:color|fill_color|stroke_color)\s*=\s*'

    if color_scheme in (1, 2):
        # 浅色背景：WHITE 和 YELLOW 不可见
        _white_re = re.compile(r'\b(' + _COLOR_ATTRS + r')WHITE\b')
        _yellow_re = re.compile(r'\b(' + _COLOR_ATTRS + r')YELLOW\b')
        wm = _white_re.findall(current)
        if wm:
            current = _white_re.sub(r'\1BLUE', current)
            replacements.append(f"WHITE→BLUE x{len(wm)}")
        ym = _yellow_re.findall(current)
        if ym:
            current = _yellow_re.sub(r'\1GOLD', current)
            replacements.append(f"YELLOW→GOLD x{len(ym)}")
    elif color_scheme in (3, 4):
        # 深色背景：BLACK/DARK_GRAY 不可见
        _black_re = re.compile(r'\b(' + _COLOR_ATTRS + r')BLACK\b')
        _darkgray_re = re.compile(r'\b(' + _COLOR_ATTRS + r')DARK_GRAY\b')
        bm = _black_re.findall(current)
        if bm:
            current = _black_re.sub(r'\1WHITE', current)
            replacements.append(f"BLACK→WHITE x{len(bm)}")
        dm = _darkgray_re.findall(current)
        if dm:
            current = _darkgray_re.sub(r'\1GREY', current)
            replacements.append(f"DARK_GRAY→GREY x{len(dm)}")

    if replacements and current != code:
        return current, f"低对比度修复: {', '.join(replacements)}"
    return None, ""


def _inject_safe_interpolate_color_helper(code: str) -> str:
    if "def _mathpi_safe_interpolate_color(" in code:
        return code
    lines = code.splitlines()
    insert_at = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("import ") or stripped.startswith("from "):
            insert_at = index + 1
            continue
        break
    helper = [
        "",
        "try:",
        "    from manim.utils.color import ManimColor as _MathPiManimColor",
        "    from manim.utils.color import interpolate_color as _mathpi_manim_interpolate_color",
        "except Exception:",
        "    _MathPiManimColor = None",
        "    _mathpi_manim_interpolate_color = None",
        "",
        "def _mathpi_safe_interpolate_color(color_a, color_b, alpha):",
        "    try:",
        "        if _MathPiManimColor is not None and _mathpi_manim_interpolate_color is not None:",
        "            return _mathpi_manim_interpolate_color(",
        "                _MathPiManimColor(color_a), _MathPiManimColor(color_b), alpha",
        "            )",
        "    except Exception:",
        "        pass",
        "    return color_b if float(alpha) >= 0.5 else color_a",
        "",
    ]
    lines[insert_at:insert_at] = helper
    return "\n".join(lines) + ("\n" if code.endswith("\n") else "")


def _fix_interpolate_color_string_inputs(code: str) -> Tuple[Optional[str], str]:
    """Wrap interpolate_color calls so generated string hex colors are accepted."""
    if "interpolate_color(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    replacements: list[tuple[int, int]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Name) or node.func.id != "interpolate_color":
            continue
        span = _source_span_for_node(node.func, lines, line_offsets)
        if span is not None:
            replacements.append(span)

    if not replacements:
        return None, ""

    current = code
    for start, end in sorted(set(replacements), reverse=True):
        current = current[:start] + "_mathpi_safe_interpolate_color" + current[end:]
    current = _inject_safe_interpolate_color_helper(current)
    return current, f"interpolate_color字符串色值安全包装: {len(replacements)}处"


_GLOBAL_CONFIG_COLOR_CANDIDATES = {
    "BLUE": ("MAIN_COLOR", "SECONDARY_COLOR", "ACCENT_COLOR", "PRIMARY_TEXT"),
    "GREEN": ("SECONDARY_COLOR", "MAIN_COLOR", "ACCENT_COLOR", "PRIMARY_TEXT"),
    "TEAL": ("SECONDARY_COLOR", "MAIN_COLOR", "ACCENT_COLOR", "PRIMARY_TEXT"),
    "YELLOW": ("ACCENT_COLOR", "ANNOTATION_COLOR", "MAIN_COLOR", "PRIMARY_TEXT"),
    "GOLD": ("ACCENT_COLOR", "ANNOTATION_COLOR", "MAIN_COLOR", "PRIMARY_TEXT"),
    "ORANGE": ("ACCENT_COLOR", "ANNOTATION_COLOR", "MAIN_COLOR", "PRIMARY_TEXT"),
    "RED": ("ANNOTATION_COLOR", "ACCENT_COLOR", "PRIMARY_TEXT", "MAIN_COLOR"),
    "PINK": ("ANNOTATION_COLOR", "ACCENT_COLOR", "PRIMARY_TEXT", "MAIN_COLOR"),
    "PURPLE": ("ANNOTATION_COLOR", "ACCENT_COLOR", "PRIMARY_TEXT", "MAIN_COLOR"),
    "WHITE": ("PRIMARY_TEXT", "MAIN_COLOR", "ACCENT_COLOR"),
    "BLACK": ("PRIMARY_TEXT", "MAIN_COLOR", "ACCENT_COLOR"),
    "GREY": ("PRIMARY_TEXT", "MAIN_COLOR", "ACCENT_COLOR"),
    "GRAY": ("PRIMARY_TEXT", "MAIN_COLOR", "ACCENT_COLOR"),
    "DARK_GRAY": ("PRIMARY_TEXT", "MAIN_COLOR", "ACCENT_COLOR"),
}
_GLOBAL_CONFIG_COLOR_KWARGS = {"color", "fill_color", "stroke_color"}


_SELF_LOWERCASE_THEME_COLOR_ALIASES = {
    "main_color": "MAIN_COLOR",
    "primary_color": "MAIN_COLOR",
    "secondary_color": "SECONDARY_COLOR",
    "secondary_text": "SECONDARY_TEXT",
    "accent_color": "ACCENT_COLOR",
    "emphasis_color": "EMPHASIS_COLOR",
    "annotation_color": "ANNOTATION_COLOR",
    "formula_color": "FORMULA_COLOR",
    "text_color": "TEXT_COLOR",
    "primary_text": "PRIMARY_TEXT",
    "title_color": "TITLE_COLOR",
    "muted_color": "MUTED_COLOR",
    "muted_text": "MUTED_TEXT",
    "geometry_color": "GEOMETRY_COLOR",
    "grid_color": "GRID_COLOR",
    "axis_color": "AXIS_COLOR",
    "stroke_color": "STROKE_COLOR",
    "fill_color": "FILL_COLOR",
    "bg_color": "BG_COLOR",
    "background_color": "BG_COLOR",
    "highlight_color": "HIGHLIGHT_COLOR",
}


def _fix_lowercase_self_theme_color_aliases(code: str) -> Tuple[Optional[str], str]:
    """Normalize generated ``self.main_color`` style refs to theme constants."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines, line_offsets = _line_offsets(code)
    replacements: list[tuple[int, int, str, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id == "self"
            and isinstance(node.ctx, ast.Load)
            and node.attr in _SELF_LOWERCASE_THEME_COLOR_ALIASES
        ):
            continue
        span = _source_span_for_node(node, lines, line_offsets)
        if not span:
            continue
        target = _SELF_LOWERCASE_THEME_COLOR_ALIASES[node.attr]
        replacements.append((span[0], span[1], f"self.{target}", node.attr))

    if not replacements:
        return None, ""

    current = code
    changed: list[str] = []
    for start, end, replacement, attr in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current = current[:start] + replacement + current[end:]
        changed.append(f"self.{attr}→{replacement}")

    return current, f"小写主题色别名归一: {', '.join(reversed(changed))}"


def _global_config_attrs_for_repair(tree: ast.AST) -> set[str]:
    attrs: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == "GlobalConfig":
            for child in node.body:
                if isinstance(child, ast.Assign):
                    for target in child.targets:
                        if isinstance(target, ast.Name) and target.id.isupper():
                            attrs.add(target.id)
                elif (
                    isinstance(child, ast.AnnAssign)
                    and isinstance(child.target, ast.Name)
                    and child.target.id.isupper()
                ):
                    attrs.add(child.target.id)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = [node.target] if isinstance(node, ast.AnnAssign) else node.targets
            for target in targets:
                if (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "GlobalConfig"
                    and target.attr.isupper()
                ):
                    attrs.add(target.attr)
    return attrs


def _global_config_class_attrs_for_repair(tree: ast.AST) -> set[str]:
    attrs: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef) or node.name != "GlobalConfig":
            continue
        for child in node.body:
            if isinstance(child, ast.Assign):
                for target in child.targets:
                    if isinstance(target, ast.Name) and target.id.isupper():
                        attrs.add(target.id)
            elif (
                isinstance(child, ast.AnnAssign)
                and isinstance(child.target, ast.Name)
                and child.target.id.isupper()
            ):
                attrs.add(child.target.id)
        break
    return attrs


def _global_config_color_attr(color_name: str, attrs: set[str]) -> Optional[str]:
    base_name = re.sub(r"_[A-E]$", "", color_name)
    candidates = _GLOBAL_CONFIG_COLOR_CANDIDATES.get(base_name)
    if not candidates:
        return None
    for candidate in candidates:
        if candidate in attrs:
            return candidate
    return None


def _byte_col_to_char_col(line: str, byte_col: int) -> int:
    return len(line.encode("utf-8")[:byte_col].decode("utf-8"))


def _source_span_for_node(
    node: ast.AST,
    lines: list[str],
    line_offsets: list[int],
) -> Optional[tuple[int, int]]:
    lineno = getattr(node, "lineno", None)
    col_offset = getattr(node, "col_offset", None)
    end_lineno = getattr(node, "end_lineno", None)
    end_col_offset = getattr(node, "end_col_offset", None)
    if (
        lineno is None
        or col_offset is None
        or end_lineno is None
        or end_col_offset is None
        or lineno != end_lineno
    ):
        return None
    line = lines[lineno - 1]
    start = line_offsets[lineno - 1] + _byte_col_to_char_col(line, col_offset)
    end = line_offsets[lineno - 1] + _byte_col_to_char_col(line, end_col_offset)
    return start, end


def _fix_default_manim_color_constants(code: str) -> Tuple[Optional[str], str]:
    """把 Manim 默认命名色常量归一到当前 GlobalConfig 配色。

    只处理 `color=` / `fill_color=` / `stroke_color=` 和同名函数默认参数，
    且只引用代码中已经定义过的 GlobalConfig 属性，避免引入新的
    AttributeError。
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    attrs = _global_config_attrs_for_repair(tree)
    if not attrs:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, str]] = []

    def _add_replacement(name_node: ast.Name) -> None:
        target_attr = _global_config_color_attr(name_node.id, attrs)
        if not target_attr:
            return
        span = _source_span_for_node(name_node, lines, line_offsets)
        if not span:
            return
        start, end = span
        replacements.append(
            (start, end, f"GlobalConfig.{target_attr}", name_node.id)
        )

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for keyword in node.keywords:
                if (
                    keyword.arg in _GLOBAL_CONFIG_COLOR_KWARGS
                    and isinstance(keyword.value, ast.Name)
                ):
                    _add_replacement(keyword.value)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            positional_args = [*node.args.posonlyargs, *node.args.args]
            defaults = node.args.defaults
            defaulted_args = positional_args[len(positional_args) - len(defaults):]
            for arg, default in zip(defaulted_args, defaults, strict=False):
                if (
                    arg.arg in _GLOBAL_CONFIG_COLOR_KWARGS
                    and isinstance(default, ast.Name)
                ):
                    _add_replacement(default)
            for arg, default in zip(
                node.args.kwonlyargs, node.args.kw_defaults, strict=False,
            ):
                if (
                    arg.arg in _GLOBAL_CONFIG_COLOR_KWARGS
                    and isinstance(default, ast.Name)
                ):
                    _add_replacement(default)

    if not replacements:
        return None, ""

    current = code
    changed_colors: list[str] = []
    for start, end, replacement, color_name in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        if current[start:end] != color_name:
            continue
        current = current[:start] + replacement + current[end:]
        changed_colors.append(f"{color_name}→{replacement}")

    if current == code:
        return None, ""
    return current, f"默认Manim颜色常量归一: {', '.join(reversed(changed_colors))}"


def _global_config_alias_target(attr: str, attrs: set[str]) -> Optional[str]:
    return resolve_global_config_alias_target(attr, attrs)


def _global_config_class_insert_index(code: str) -> tuple[int, str] | None:
    lines = code.splitlines()
    for index, line in enumerate(lines):
        match = re.match(r"^(?P<indent>\s*)class\s+GlobalConfig\b.*:\s*$", line)
        if not match:
            continue
        class_indent = match.group("indent")
        body_indent = class_indent + "    "
        last_assignment = index
        body_index = index + 1
        while body_index < len(lines):
            body_line = lines[body_index]
            if body_line.strip():
                indent_len = len(body_line) - len(body_line.lstrip())
                if indent_len <= len(class_indent):
                    break
            if re.match(
                rf"^{re.escape(body_indent)}[A-Z][A-Z0-9_]*\s*(?::[^=]+)?=",
                body_line,
            ):
                last_assignment = body_index
            body_index += 1
        return last_assignment + 1, body_indent
    return None


def _missing_global_config_alias_refs(
    tree: ast.AST,
    attrs: set[str],
) -> list[str]:
    refs: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id == "GlobalConfig"
            and isinstance(node.ctx, ast.Load)
            and node.attr.isupper()
            and node.attr not in attrs
        ):
            continue
        refs.append((
            getattr(node, "lineno", 0),
            getattr(node, "col_offset", 0),
            node.attr,
        ))
    ordered: list[str] = []
    seen: set[str] = set()
    for _lineno, _col, attr in sorted(refs):
        if attr in seen:
            continue
        seen.add(attr)
        ordered.append(attr)
    return ordered


def _inject_global_config_alias_assignments(code: str) -> Tuple[Optional[str], str]:
    """Add safe class-level aliases for missing GlobalConfig attributes.

    This keeps generated references such as ``GlobalConfig.TITLE_COLOR`` valid
    when the class already exposes the canonical target (for example
    ``PRIMARY_TEXT``). Unknown aliases are intentionally left untouched so the
    static quality gate can fail closed before Manim runs.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    class_attrs = _global_config_class_attrs_for_repair(tree)
    if not class_attrs:
        return None, ""

    missing_refs = _missing_global_config_alias_refs(tree, class_attrs)
    if not missing_refs:
        return None, ""

    aliases: list[tuple[str, str]] = []
    planned_attrs = set(class_attrs)
    for attr in missing_refs:
        target = _global_config_alias_target(attr, planned_attrs)
        if not target:
            continue
        aliases.append((attr, target))
        planned_attrs.add(attr)

    if not aliases:
        return None, ""

    insertion = _global_config_class_insert_index(code)
    if not insertion:
        return None, ""
    insert_at, indent = insertion
    lines = code.splitlines()
    alias_lines = [f"{indent}{attr} = {target}" for attr, target in aliases]
    lines[insert_at:insert_at] = alias_lines
    suffix = "\n" if code.endswith("\n") else ""
    current = "\n".join(lines) + suffix
    changed = ", ".join(f"GlobalConfig.{attr}={target}" for attr, target in aliases)
    return current, f"GlobalConfig别名补全: {changed}"


def _fix_global_config_alias_references(code: str) -> Tuple[Optional[str], str]:
    """修复 LLM 常见的 GlobalConfig 短别名引用。

    例如配置里只有 SECONDARY_COLOR，但代码引用 GlobalConfig.SECONDARY。
    只在目标属性已经存在时替换，未知别名继续交给静态检查拦截。
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    attrs = _global_config_attrs_for_repair(tree)
    if not attrs:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Attribute)
            and isinstance(node.value, ast.Name)
            and node.value.id == "GlobalConfig"
            and isinstance(node.ctx, ast.Load)
            and node.attr not in attrs
        ):
            continue
        target_attr = _global_config_alias_target(node.attr, attrs)
        if not target_attr:
            continue
        span = _source_span_for_node(node, lines, line_offsets)
        if not span:
            continue
        start, end = span
        replacements.append(
            (start, end, f"GlobalConfig.{target_attr}", node.attr)
        )

    if not replacements:
        return None, ""

    current = code
    changed_aliases: list[str] = []
    for start, end, replacement, attr in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        original = f"GlobalConfig.{attr}"
        if current[start:end] != original:
            continue
        current = current[:start] + replacement + current[end:]
        changed_aliases.append(f"{original}→{replacement}")

    if current == code:
        return None, ""
    return current, f"GlobalConfig别名修复: {', '.join(reversed(changed_aliases))}"


def _call_name_for_repair(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _literal_number_for_repair(node: ast.AST) -> Optional[float]:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, ast.USub)
        and isinstance(node.operand, ast.Constant)
        and isinstance(node.operand.value, (int, float))
    ):
        return -float(node.operand.value)
    return None


def _fix_undersized_2d_axes(code: str) -> Tuple[Optional[str], str]:
    """放大过小的 2D 坐标图主体，避免缩略图式画面。"""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, str]] = []
    min_lengths = {"x_length": 5.0, "y_length": 4.0}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) not in {"Axes", "NumberPlane"}:
            continue
        for keyword in node.keywords:
            if keyword.arg not in min_lengths:
                continue
            current_value = _literal_number_for_repair(keyword.value)
            if current_value is None or current_value >= min_lengths[keyword.arg]:
                continue
            span = _source_span_for_node(keyword.value, lines, line_offsets)
            if not span:
                continue
            start, end = span
            replacement = f"{min_lengths[keyword.arg]:.1f}"
            replacements.append((start, end, replacement, keyword.arg))

    if not replacements:
        return None, ""

    current = code
    changed: list[str] = []
    for start, end, replacement, arg_name in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        old_value = current[start:end]
        current = current[:start] + replacement + current[end:]
        changed.append(f"{arg_name}:{old_value}→{replacement}")

    if current == code:
        return None, ""
    return current, f"2D坐标轴尺寸修复: {', '.join(reversed(changed))}"


def _is_int_cast_call_for_repair(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "int"
        and len(node.args) == 1
    )


def _font_size_expr_needs_int_cast(node: ast.AST) -> bool:
    if _is_int_cast_call_for_repair(node):
        return False
    if isinstance(node, ast.Constant):
        return isinstance(node.value, float)
    if isinstance(node, ast.UnaryOp):
        return _font_size_expr_needs_int_cast(node.operand)
    if isinstance(node, ast.BinOp):
        if isinstance(node.op, (ast.Mult, ast.Div)):
            return True
        return (
            _font_size_expr_needs_int_cast(node.left)
            or _font_size_expr_needs_int_cast(node.right)
        )
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "float"
    ):
        return True
    return False


def _fix_safe_text_box_invalid_keywords(code: str) -> Tuple[Optional[str], str]:
    """Drop unsupported safe_text_box() kwargs that otherwise cause TypeError."""
    if "safe_text_box" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    accepted, accepts_kwargs = _safe_text_box_signature_for_repair(tree)
    if not accepted or accepts_kwargs:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    edits: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) != "safe_text_box":
            continue
        for keyword in node.keywords:
            if not keyword.arg or keyword.arg in accepted:
                continue
            mapped = None
            if keyword.arg == "width" and "max_width" in accepted:
                mapped = "max_width"
            elif keyword.arg == "height" and "max_height" in accepted:
                mapped = "max_height"
            if mapped:
                name_span = _keyword_name_span_for_repair(
                    keyword, code, lines, line_offsets,
                )
                if name_span:
                    edits.append((name_span[0], name_span[1], mapped))
                continue

            removal_span = _keyword_removal_span_for_repair(
                keyword, code, lines, line_offsets,
            )
            if removal_span:
                edits.append((removal_span[0], removal_span[1], ""))

    if not edits:
        return None, ""

    current = _apply_keyword_edits_for_repair(code, edits)
    current = re.sub(r",\s*\)", ")", current)
    current = re.sub(
        r"(fit_to_canvas\([^()\n]*?),\s*(?=\n|$)",
        r"\1)",
        current,
    )
    try:
        ast.parse(current)
    except SyntaxError:
        return None, ""

    if current == code:
        return None, ""
    return current, f"safe_text_box无效参数修复: {len(edits)}处"


def _fix_layout_helper_zone_keyword_alias(code: str) -> Tuple[Optional[str], str]:
    """Map LLM's zone= layout alias to area= for local layout helpers."""
    if "zone=" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    helper_names = {
        "safe_text_box",
        "fit_to_canvas",
        "clamp_to_canvas",
        "place_non_overlapping",
        "safe_group",
    }
    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    edits: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) not in helper_names:
            continue
        has_area = any(keyword.arg == "area" for keyword in node.keywords)
        for keyword in node.keywords:
            if keyword.arg != "zone":
                continue
            if has_area:
                removal_span = _keyword_removal_span_for_repair(
                    keyword, code, lines, line_offsets,
                )
                if removal_span:
                    edits.append((removal_span[0], removal_span[1], ""))
                continue
            name_span = _keyword_name_span_for_repair(
                keyword, code, lines, line_offsets,
            )
            if name_span:
                edits.append((name_span[0], name_span[1], "area"))

    if not edits:
        return None, ""

    current = _apply_keyword_edits_for_repair(code, edits)
    current = re.sub(r",\s*\)", ")", current)
    try:
        ast.parse(current)
    except SyntaxError:
        return None, ""
    if current == code:
        return None, ""
    return current, f"layout helper zone参数修复: {len(edits)}处"


def _fix_unpositioned_title_objects_to_top(code: str) -> Tuple[Optional[str], str]:
    """Move title-like objects that were created but never positioned to the top band.

    LLMs often write ``title = self.safe_text_box("...", font_size=36)`` and then
    immediately add it. Since safe_text_box defaults to area="full", that title
    lands in the exact screen center. Only title-like variable names without any
    explicit positioning are touched here.
    """
    if "title" not in code.lower() and "heading" not in code.lower() and "header" not in code.lower():
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    inserts: list[tuple[int, str]] = []
    title_constructors = {"safe_text_box", "Text", "MarkupText", "Tex"}

    for node in ast.walk(tree):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value = node.value
        if not isinstance(value, ast.Call):
            continue
        call_name = _call_name_for_repair(value.func)
        if call_name not in title_constructors:
            continue

        target_names: list[str] = []
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    target_names.append(target.id)
        elif isinstance(node.target, ast.Name):
            target_names.append(node.target.id)
        if not target_names:
            continue

        if call_name == "safe_text_box":
            if len(value.args) >= 2:
                continue
            if any(keyword.arg in {"area", "zone"} for keyword in value.keywords if keyword.arg):
                continue

        end_lineno = int(getattr(node, "end_lineno", getattr(node, "lineno", 0)) or 0)
        if end_lineno <= 0 or end_lineno > len(lines):
            continue
        line = lines[end_lineno - 1]
        indent = line[: len(line) - len(line.lstrip())]
        lookahead = "".join(lines[end_lineno : min(len(lines), end_lineno + 3)])
        if "MathPi title top-anchor repair" in lookahead:
            continue

        for var_name in target_names:
            if not _TITLE_LIKE_VAR_RE.search(var_name):
                continue
            if _title_var_has_explicit_positioning(lines, var_name, end_lineno):
                continue
            inserts.append((
                end_lineno,
                f"{indent}{var_name}.to_edge(UP, buff=0.45).set_x(0)  # MathPi title top-anchor repair\n",
            ))

    if not inserts:
        return None, ""

    current_lines = list(lines)
    inserted = 0
    for line_no, insert_line in sorted(inserts, key=lambda item: item[0], reverse=True):
        current_lines.insert(line_no, insert_line)
        inserted += 1
    current = "".join(current_lines)
    try:
        ast.parse(current)
    except SyntaxError:
        return None, ""
    if current == code:
        return None, ""
    return current, f"未定位标题置顶修复: {inserted}处"


def _title_var_has_explicit_positioning(lines: list[str], var_name: str, start_line: int) -> bool:
    method_pattern = re.compile(
        _TITLE_POSITIONING_METHOD_RE.pattern.format(var=re.escape(var_name))
    )
    reassignment_pattern = re.compile(rf"^\s*{re.escape(var_name)}\s*(?::[^=]+)?=")
    for line in lines[start_line:]:
        if reassignment_pattern.search(line):
            return False
        if method_pattern.search(line):
            return True
    return False


def _fix_fit_to_canvas_invalid_keywords(code: str) -> Tuple[Optional[str], str]:
    """Drop unsupported fit_to_canvas() kwargs on locally generated helpers."""
    if "fit_to_canvas" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    accepted, accepts_kwargs = _function_signature_for_repair(tree, "fit_to_canvas")
    if not accepted or accepts_kwargs:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    edits: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) != "fit_to_canvas":
            continue
        for keyword in node.keywords:
            if not keyword.arg or keyword.arg in accepted:
                continue
            mapped = None
            if keyword.arg == "width" and "max_width" in accepted:
                mapped = "max_width"
            elif keyword.arg == "height" and "max_height" in accepted:
                mapped = "max_height"
            if mapped:
                name_span = _keyword_name_span_for_repair(
                    keyword, code, lines, line_offsets,
                )
                if name_span:
                    edits.append((name_span[0], name_span[1], mapped))
                continue

            removal_span = _keyword_removal_span_for_repair(
                keyword, code, lines, line_offsets,
            )
            if removal_span:
                edits.append((removal_span[0], removal_span[1], ""))

    if not edits:
        return None, ""

    current = _apply_keyword_edits_for_repair(code, edits)
    current = re.sub(r",\s*\)", ")", current)
    current = re.sub(
        r"(fit_to_canvas\([^()\n]*?),\s*(?=\n|$)",
        r"\1)",
        current,
    )
    try:
        ast.parse(current)
    except SyntaxError:
        return None, ""

    if current == code:
        return None, ""
    return current, f"fit_to_canvas无效参数修复: {len(edits)}处"


def _fix_safe_text_box_font_size_casts(code: str) -> Tuple[Optional[str], str]:
    """safe_text_box() 的 font_size 参数需要 int，LLM 常生成乘法浮点表达式。"""
    if "safe_text_box" not in code or "font_size" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) != "safe_text_box":
            continue
        for keyword in node.keywords:
            if keyword.arg != "font_size":
                continue
            if not _font_size_expr_needs_int_cast(keyword.value):
                continue
            span = _source_span_for_node(keyword.value, lines, line_offsets)
            if not span:
                continue
            start, end = span
            replacements.append((start, end, f"int({code[start:end]})"))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current = current[:start] + replacement + current[end:]

    if current == code:
        return None, ""
    return current, f"safe_text_box字号类型修复: {len(replacements)}处"


def _fix_landscape_oversized_text_font_sizes(
    code: str,
    *,
    is_portrait: bool | None = False,
) -> Tuple[Optional[str], str]:
    """Clamp clearly oversized landscape Text/MathTex font literals."""
    if is_portrait:
        return None, ""
    if "font_size" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    text_like_helpers = {
        "Text",
        "Tex",
        "MathTex",
        "MarkupText",
        "safe_text_box",
        "inline_math_text",
        "portrait_title",
        "portrait_formula",
    }
    max_font_size = 52
    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, int]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name_for_repair(node.func) not in text_like_helpers:
            continue
        for keyword in node.keywords:
            if keyword.arg != "font_size":
                continue
            value = keyword.value
            if not isinstance(value, ast.Constant) or not isinstance(
                value.value,
                (int, float),
            ):
                continue
            numeric = float(value.value)
            if numeric <= max_font_size:
                continue
            span = _source_span_for_node(value, lines, line_offsets)
            if not span:
                continue
            replacements.append((span[0], span[1], str(max_font_size), int(numeric)))

    if not replacements:
        return None, ""

    current = code
    for start, end, replacement, _old in sorted(
        replacements,
        key=lambda item: item[0],
        reverse=True,
    ):
        current = current[:start] + replacement + current[end:]
    if current == code:
        return None, ""
    changed = ", ".join(
        f"{old}->{max_font_size}"
        for _start, _end, _replacement, old in replacements[:5]
    )
    return current, f"横屏超大字号归一化: {len(replacements)}处 ({changed})"


def _fix_tex_template_library_ct_typo(code: str) -> Tuple[Optional[str], str]:
    """Repair LLM typo ``TexTemplateLibrary.ct`` to Manim's ctex template."""
    if "TexTemplateLibrary.ct" not in code:
        return None, ""
    current, changed = _CTEX_TEMPLATE_CT_TYPO_RE.subn(
        "TexTemplateLibrary.ctex",
        code,
    )
    if changed <= 0 or current == code:
        return None, ""
    return current, f"TexTemplateLibrary.ct笔误修复: {changed}处"


def _vgroup_assigned_names_for_repair(tree: ast.AST) -> set[str]:
    assignments: list[tuple[list[ast.expr], ast.AST | None]] = []
    for node in ast.walk(tree):
        targets: list[ast.expr]
        value: ast.AST | None
        if isinstance(node, ast.Assign):
            targets = list(node.targets)
            value = node.value
        elif isinstance(node, ast.AnnAssign):
            targets = [node.target]
            value = node.value
        else:
            continue
        assignments.append((targets, value))

    names: set[str] = set()
    while True:
        before = len(names)
        for targets, value in assignments:
            if not _expr_is_vgroup_for_repair(value, names):
                continue
            for target in targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        if len(names) == before:
            return names


class _LocalRepairScopeVisitor(ast.NodeVisitor):
    def __init__(self, root: ast.AST):
        self.root = root
        self.assignments: list[tuple[list[ast.expr], ast.AST | None]] = []
        self.len_submobjects_calls: list[ast.Call] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        if node is self.root:
            self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        self.assignments.append((list(node.targets), node.value))
        self.visit(node.value)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        self.assignments.append(([node.target], node.value))
        if node.value is not None:
            self.visit(node.value)

    def visit_Call(self, node: ast.Call) -> None:
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "len"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Attribute)
            and node.args[0].attr == "submobjects"
            and isinstance(node.args[0].value, ast.Name)
        ):
            self.len_submobjects_calls.append(node)
        self.generic_visit(node)


def _repair_scopes(tree: ast.AST) -> list[ast.AST]:
    scopes: list[ast.AST] = [tree]
    scopes.extend(
        node
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    )
    return scopes


def _target_names(targets: list[ast.expr]) -> set[str]:
    return {target.id for target in targets if isinstance(target, ast.Name)}


def _expr_is_list_for_repair(node: ast.AST | None, names: set[str]) -> bool:
    if isinstance(node, (ast.List, ast.Tuple, ast.ListComp)):
        return True
    if not isinstance(node, ast.Call):
        return False
    call_name = _call_name_for_repair(node.func)
    if call_name in {"list", "tuple", "sorted"}:
        return True
    if call_name == "_children":
        return True
    if not isinstance(node.func, ast.Attribute):
        return False
    owner = node.func.value
    if node.func.attr == "split":
        return True
    if node.func.attr == "copy" and isinstance(owner, ast.Name):
        return owner.id in names
    return False


def _assigned_names_by_expr_type(
    assignments: list[tuple[list[ast.expr], ast.AST | None]],
    predicate: Callable[[ast.AST | None, set[str]], bool],
) -> set[str]:
    names: set[str] = set()
    while True:
        before = len(names)
        for targets, value in assignments:
            if not predicate(value, names):
                continue
            names.update(_target_names(targets))
        if len(names) == before:
            return names


def _expr_is_vgroup_for_repair(node: ast.AST | None, names: set[str]) -> bool:
    if not isinstance(node, ast.Call):
        return False
    if _call_name_for_repair(node.func) == "VGroup":
        return True
    if not isinstance(node.func, ast.Attribute):
        return False
    owner = node.func.value
    if node.func.attr == "copy" and isinstance(owner, ast.Name):
        return owner.id in names
    if isinstance(owner, ast.Call):
        return _expr_is_vgroup_for_repair(owner, names)
    return False


def _fix_list_len_submobjects_calls(code: str) -> Tuple[Optional[str], str]:
    """Generated text-wrap helpers sometimes treat Python lists as Manim groups."""
    if ".submobjects" not in code or "len(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, str]] = []
    for scope in _repair_scopes(tree):
        visitor = _LocalRepairScopeVisitor(scope)
        visitor.visit(scope)
        if not visitor.len_submobjects_calls:
            continue
        list_names = _assigned_names_by_expr_type(
            visitor.assignments,
            _expr_is_list_for_repair,
        )
        if not list_names:
            continue
        vgroup_names = _assigned_names_by_expr_type(
            visitor.assignments,
            _expr_is_vgroup_for_repair,
        )
        for node in visitor.len_submobjects_calls:
            attr = node.args[0]
            if not isinstance(attr, ast.Attribute) or not isinstance(
                attr.value, ast.Name
            ):
                continue
            name = attr.value.id
            if name not in list_names or name in vgroup_names:
                continue
            span = _source_span_for_node(attr, lines, line_offsets)
            if not span:
                continue
            start, end = span
            replacements.append((start, end, name, f"{name}.submobjects"))

    if not replacements:
        return None, ""

    current = code
    changed: list[str] = []
    seen_spans: set[tuple[int, int]] = set()
    for start, end, replacement, original in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        if (start, end) in seen_spans or current[start:end] != original:
            continue
        current = current[:start] + replacement + current[end:]
        changed.append(original)
        seen_spans.add((start, end))

    if current == code:
        return None, ""
    return current, f"list长度修复: {len(changed)}处"


def _fix_string_indent_len_submobjects_calls(code: str) -> Tuple[Optional[str], str]:
    """Generated code-block helpers sometimes compute string indent via submobjects."""
    if ".submobjects" not in code or ".lstrip" not in code or "len(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, str]] = []

    def len_submobjects_name(node: ast.AST) -> tuple[str, ast.Attribute] | None:
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "len"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Attribute)
            and node.args[0].attr == "submobjects"
            and isinstance(node.args[0].value, ast.Name)
        ):
            return None
        return node.args[0].value.id, node.args[0]

    def len_lstrip_name(node: ast.AST) -> str | None:
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "len"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Call)
            and isinstance(node.args[0].func, ast.Attribute)
            and node.args[0].func.attr == "lstrip"
            and isinstance(node.args[0].func.value, ast.Name)
        ):
            return None
        return node.args[0].func.value.id

    for node in ast.walk(tree):
        if not isinstance(node, ast.BinOp) or not isinstance(node.op, ast.Sub):
            continue
        left = len_submobjects_name(node.left)
        right_name = len_lstrip_name(node.right)
        if left is None or right_name is None:
            continue
        left_name, attr = left
        if left_name != right_name:
            continue
        span = _source_span_for_node(attr, lines, line_offsets)
        if not span:
            continue
        start, end = span
        replacements.append((start, end, left_name, f"{left_name}.submobjects"))

    if not replacements:
        return None, ""

    current = code
    changed = 0
    seen_spans: set[tuple[int, int]] = set()
    for start, end, replacement, original in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        if (start, end) in seen_spans or current[start:end] != original:
            continue
        current = current[:start] + replacement + current[end:]
        changed += 1
        seen_spans.add((start, end))

    if current == code:
        return None, ""
    return current, f"字符串缩进长度修复: {changed}处"


def _fix_code_object_code_attribute_access(code: str) -> Tuple[Optional[str], str]:
    """Manim 0.19 Code exposes highlighted lines as code_lines, not code."""
    if "Code(" not in code or ".code" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    code_object_names: set[str] = set()

    def is_code_call(node: ast.AST) -> bool:
        return isinstance(node, ast.Call) and _call_func_name(node.func) == "Code"

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and is_code_call(node.value):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    code_object_names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and node.value and is_code_call(node.value):
            if isinstance(node.target, ast.Name):
                code_object_names.add(node.target.id)

    if not code_object_names:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    replacements: list[tuple[int, int, str, str]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Attribute)
            and node.attr == "code"
            and isinstance(node.value, ast.Name)
            and node.value.id in code_object_names
            and hasattr(node, "end_lineno")
            and hasattr(node, "end_col_offset")
            and node.lineno == node.end_lineno
        ):
            continue
        start = line_offsets[node.lineno - 1] + node.col_offset
        end = line_offsets[node.end_lineno - 1] + node.end_col_offset
        original = f"{node.value.id}.code"
        if code[start:end] != original:
            continue
        replacements.append((start, end, f"{node.value.id}.code_lines", original))

    if not replacements:
        return None, ""

    current = code
    changed = 0
    seen_spans: set[tuple[int, int]] = set()
    for start, end, replacement, original in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        if (start, end) in seen_spans or current[start:end] != original:
            continue
        current = current[:start] + replacement + current[end:]
        changed += 1
        seen_spans.add((start, end))

    if current == code:
        return None, ""
    return current, f"Code.code兼容修复: {changed}处"


def _fix_vgroup_len_calls(code: str) -> Tuple[Optional[str], str]:
    """Manim VGroup is not Sized; use its submobjects for generated len() loops."""
    if "VGroup" not in code or "len(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    lines = code.splitlines(keepends=True)
    line_offsets: list[int] = []
    offset = 0
    for line in lines:
        line_offsets.append(offset)
        offset += len(line)

    class _LocalVGroupLenVisitor(ast.NodeVisitor):
        def __init__(self, root: ast.AST):
            self.root = root
            self.assignments: list[tuple[list[ast.expr], ast.AST | None]] = []
            self.len_name_calls: list[ast.Call] = []

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            if node is self.root:
                self.generic_visit(node)

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            if node is self.root:
                self.generic_visit(node)

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            if node is self.root:
                self.generic_visit(node)

        def visit_Assign(self, node: ast.Assign) -> None:
            self.assignments.append((list(node.targets), node.value))
            self.visit(node.value)

        def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
            self.assignments.append(([node.target], node.value))
            if node.value is not None:
                self.visit(node.value)

        def visit_Call(self, node: ast.Call) -> None:
            if (
                isinstance(node.func, ast.Name)
                and node.func.id == "len"
                and len(node.args) == 1
                and isinstance(node.args[0], ast.Name)
            ):
                self.len_name_calls.append(node)
            self.generic_visit(node)

    replacements: list[tuple[int, int, str, str]] = []
    for scope in _repair_scopes(tree):
        visitor = _LocalVGroupLenVisitor(scope)
        visitor.visit(scope)
        if not visitor.len_name_calls:
            continue
        vgroup_names = _assigned_names_by_expr_type(
            visitor.assignments,
            _expr_is_vgroup_for_repair,
        )
        if not vgroup_names:
            continue
        for node in visitor.len_name_calls:
            if not isinstance(node.args[0], ast.Name):
                continue
            name = node.args[0].id
            if name not in vgroup_names:
                continue
            span = _source_span_for_node(node.args[0], lines, line_offsets)
            if not span:
                continue
            start, end = span
            replacements.append((start, end, f"{name}.submobjects", name))

    if not replacements:
        return None, ""

    current = code
    changed_names: list[str] = []
    for start, end, replacement, name in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        if current[start:end] != name:
            continue
        current = current[:start] + replacement + current[end:]
        changed_names.append(name)

    if current == code:
        return None, ""
    return current, f"VGroup长度修复: {len(changed_names)}处"


_MOBJECT_LIKE_CONSTRUCTORS_FOR_SAFE_PART = {
    "Angle",
    "AnnularSector",
    "Arc",
    "Arrow",
    "Axes",
    "Brace",
    "Circle",
    "Code",
    "DashedLine",
    "Dot",
    "DoubleArrow",
    "Line",
    "MathTex",
    "Mobject",
    "NumberLine",
    "ParametricFunction",
    "Polygon",
    "Rectangle",
    "Sector",
    "Square",
    "SurroundingRectangle",
    "Tex",
    "Text",
    "ThreeDAxes",
    "VGroup",
    "VMobject",
}


def _expr_is_mobject_like_for_safe_part(node: ast.AST | None, names: set[str]) -> bool:
    if isinstance(node, ast.Call):
        func_name = _call_func_name(node.func)
        if func_name in {"MathTex", "Tex"}:
            # Multi-argument MathTex intentionally creates addressable parts.
            # Single-string formulas do not, but generated code often still
            # indexes them for highlighting.
            return len(node.args) <= 1
        if func_name in _MOBJECT_LIKE_CONSTRUCTORS_FOR_SAFE_PART:
            return False
        if isinstance(node.func, ast.Attribute):
            if node.func.attr in {"copy", "scale", "scale_to_fit_width", "scale_to_fit_height", "move_to", "next_to", "to_edge", "shift", "arrange"}:
                return _expr_is_mobject_like_for_safe_part(node.func.value, names)
            return _expr_is_mobject_like_for_safe_part(node.func.value, names)
    if isinstance(node, ast.Name):
        return node.id in names
    return False


def _inject_safe_mobject_part_helper(code: str) -> str:
    if "def _safe_mobject_part" in code:
        return code
    lines = code.splitlines()
    insert_at = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("import ") or stripped.startswith("from "):
            insert_at = index + 1
            continue
        break
    helper = [
        "",
        "def _safe_mobject_part(mobject, index):",
        "    try:",
        "        return mobject[index]",
        "    except (IndexError, TypeError):",
        "        return mobject",
        "",
    ]
    lines[insert_at:insert_at] = helper
    return "\n".join(lines) + ("\n" if code.endswith("\n") else "")


def _fix_mobject_index_accesses(code: str) -> Tuple[Optional[str], str]:
    """Guard generated MathTex/Text part indexing without changing normal lists."""
    if "[" not in code or "]" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    parent_by_id: dict[int, ast.AST] = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            parent_by_id[id(child)] = parent

    class _ScopeSubscriptVisitor(ast.NodeVisitor):
        def __init__(self, root: ast.AST):
            self.root = root
            self.subscripts: list[ast.Subscript] = []

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            if node is self.root:
                self.generic_visit(node)

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            if node is self.root:
                self.generic_visit(node)

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            if node is self.root:
                self.generic_visit(node)

        def visit_Subscript(self, node: ast.Subscript) -> None:
            self.subscripts.append(node)
            self.generic_visit(node)

    lines, line_offsets = _line_offsets(code)
    edits: list[tuple[int, int, str]] = []
    for scope in _repair_scopes(tree):
        assignment_visitor = _LocalRepairScopeVisitor(scope)
        assignment_visitor.visit(scope)
        mobject_names = _assigned_names_by_expr_type(
            assignment_visitor.assignments,
            _expr_is_mobject_like_for_safe_part,
        )
        if not mobject_names:
            continue
        subscript_visitor = _ScopeSubscriptVisitor(scope)
        subscript_visitor.visit(scope)
        for node in subscript_visitor.subscripts:
            if not (
                isinstance(node.value, ast.Name)
                and node.value.id in mobject_names
            ):
                continue
            parent = parent_by_id.get(id(node))
            if isinstance(parent, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                continue
            index_node = node.slice
            if isinstance(index_node, ast.Constant) and isinstance(index_node.value, int):
                index = index_node.value
            else:
                continue
            span = _source_span_for_node(node, lines, line_offsets)
            if not span:
                continue
            start, end = span
            edits.append((start, end, f"_safe_mobject_part({node.value.id}, {index})"))

    if not edits:
        return None, ""
    current = _apply_keyword_edits_for_repair(code, edits)
    current = _inject_safe_mobject_part_helper(current)
    if current == code:
        return None, ""
    return current, f"Manim对象索引兜底: {len(edits)}处"


def _fix_transform_from_copy_label_group_overlap(code: str) -> Tuple[Optional[str], str]:
    """Split geometry-copy and label-reveal for translated point-label groups."""
    if "TransformFromCopy" not in code or "labels_" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    original_label_groups: set[str] = set()
    target_label_groups: set[str] = set()
    target_outline_groups: set[str] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign) or not isinstance(node.value, ast.Call):
            continue
        if _call_func_name(node.value.func) != "VGroup":
            continue
        segment = ast.get_source_segment(code, node.value) or ""
        names = [target.id for target in node.targets if isinstance(target, ast.Name)]
        if not names:
            continue
        if "labels_orig" in segment:
            original_label_groups.update(names)
        if "labels_target" in segment:
            target_label_groups.update(names)
            for name in names:
                if "outline" in name or ".copy(" in segment:
                    target_outline_groups.add(name)

    if not original_label_groups or not target_label_groups:
        return None, ""

    outline_name = "target_outline" if "target_outline" in target_outline_groups else ""
    replacements: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_func_name(node.func) != "TransformFromCopy" or len(node.args) < 2:
            continue
        source = node.args[0]
        target = node.args[1]
        if not isinstance(source, ast.Name) or not isinstance(target, ast.Name):
            continue
        if source.id not in original_label_groups or target.id not in target_label_groups:
            continue
        span = _source_span_for_multiline_node(node, code)
        if span is None:
            continue
        line_start = code.rfind("\n", 0, span[0]) + 1
        indent = code[line_start:span[0]]
        replacement = (
            "AnimationGroup("
            f"\n{indent}    TransformFromCopy({source.id}[0], {target.id}[0]),"
        )
        if outline_name:
            replacement += f"\n{indent}    FadeOut({outline_name}[1]),"
        replacement += (
            f"\n{indent}    FadeIn({target.id}[1]),"
            f"\n{indent}    lag_ratio=0.15"
            f"\n{indent})"
        )
        replacements.append((span[0], span[1], replacement))

    if not replacements:
        return None, ""
    current = code
    for start, end, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True,
    ):
        current = current[:start] + replacement + current[end:]
    return current, f"平移标签TransformFromCopy重影修复: {len(replacements)}处"


_EDU_POLITICAL_ATTRIBUTION_RE = re.compile(
    r"(?:习近平总书记|习总书记|总书记)在[^，。；\n]{0,60}?讲话中指出"
)


def _soften_educational_political_attribution(code: str) -> Tuple[Optional[str], str]:
    """Neutralize citation attribution in exam explanations without changing answers."""
    if "总书记" not in code and "习总书记" not in code and "习近平总书记" not in code:
        return None, ""

    current, changed = _EDU_POLITICAL_ATTRIBUTION_RE.subn("材料原文指出", code)
    replacements = [
        ("习近平总书记讲话支撑", "材料原文支撑"),
        ("习总书记讲话支撑", "材料原文支撑"),
        ("总书记讲话支撑", "材料原文支撑"),
        ("习近平总书记指出", "材料原文指出"),
        ("习总书记指出", "材料原文指出"),
        ("总书记指出", "材料原文指出"),
        ("总书记还指出", "材料原文还指出"),
        ("习近平总书记", "材料原文"),
        ("习总书记", "材料原文"),
        ("总书记", "材料原文"),
    ]
    for old, new in replacements:
        count = current.count(old)
        if count:
            current = current.replace(old, new)
            changed += count

    if current == code or changed <= 0:
        return None, ""
    return current, f"教育题政治引用归因中性化: {changed}处"


def _soften_educational_ideology_entities(code: str) -> Tuple[Optional[str], str]:
    """Neutralize high-risk political entity names in exam explanations."""
    triggers = ("马克思", "恩格斯", "共产党宣言", "共产党", "社会主义")
    if not any(item in code for item in triggers):
        return None, ""

    replacements = [
        ("马克思主义理论辨析", "理论方法辨析"),
        ("马克思主义一般原理", "该理论一般原理"),
        ("马克思主义理论", "该理论"),
        ("马克思主义", "该理论"),
        ("马克思和恩格斯", "两位学者"),
        ("马克思、恩格斯", "两位学者"),
        ("《共产党宣言》", "相关经典文本"),
        ("共产党宣言", "相关经典文本"),
        ("科学社会主义基本原则", "相关理论基本原则"),
        ("科学社会主义原则", "相关理论原则"),
        ("科学社会主义", "相关理论"),
        ("社会主义", "相关理论"),
        ("马克思", "相关学者"),
        ("恩格斯", "材料作者"),
        ("共产党", "相关组织"),
    ]
    current = code
    changed = 0
    for old, new in replacements:
        count = current.count(old)
        if count:
            current = current.replace(old, new)
            changed += count

    if current == code or changed <= 0:
        return None, ""
    return current, f"教育题政治实体中性化: {changed}处"


def pre_render_scan(
    code: str, *, color_scheme: int = 1,
    enable_visual_overflow_fixes: bool = True,
    is_portrait: bool | None = False,
    prompt_context: str | None = None,
) -> Tuple[str, list]:
    """渲染前全文扫描 + 自动修复（流式管线专用）。

    在提交给 Docker 容器渲染之前调用，拦截常见 LLM 幻觉错误。
    成本接近 0（纯 Python 正则 + AST）。
    包含 MathTex→Text 转换和重复 Scene 去重。

    Returns:
        (fixed_code, fix_descriptions)
    """
    return _pre_render_scan_core(
        code, color_scheme=color_scheme,
        skip_mathtex_to_text=False, skip_dedup=False,
        enable_visual_overflow_fixes=enable_visual_overflow_fixes,
        is_portrait=is_portrait,
        prompt_context=prompt_context,
    )


def pre_render_scan_planning(
    code: str, *, color_scheme: int = 1,
) -> Tuple[str, list]:
    """渲染前全文扫描 + 自动修复（规划管线专用）。

    与 pre_render_scan 相同的安全修复，但跳过：
    - MathTex/Tex 含中文→Text 转换（规划管线 header 已配置 ctex）
    - 重复 Scene 去重（规划管线单 Scene 单文件，不存在重复）

    Returns:
        (fixed_code, fix_descriptions)
    """
    return _pre_render_scan_core(
        code, color_scheme=color_scheme,
        skip_mathtex_to_text=True, skip_dedup=True,
    )


def _pre_render_scan_core(
    code: str, *,
    color_scheme: int = 1,
    skip_mathtex_to_text: bool = False,
    skip_dedup: bool = False,
    enable_visual_overflow_fixes: bool = True,
    is_portrait: bool | None = False,
    prompt_context: str | None = None,
) -> Tuple[str, list]:
    """统一的渲染前扫描核心逻辑。"""
    fixes = []
    current = code

    fixed, desc = _soften_educational_political_attribution(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = _soften_educational_ideology_entities(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0. LLM 偶尔返回完整 Markdown code fence；渲染前直接剥掉外壳
    fixed, desc = _strip_markdown_code_fence(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.1 MathTex("\tan\theta") 这类普通字符串会被 Python 先转义，需先改成 raw
    fixed, desc = _fix_mathtex_plain_string_latex_escapes(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.11 inline_math_text(("math", r"\\cos\\theta")) 会让 MathTex 显示反斜杠源码
    fixed, desc = _fix_inline_math_tuple_overescaped_latex_commands(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2 续写/修复偶尔从 Scene class 开始，模块加载前必须恢复固定 header
    fixed, desc = _ensure_base_config_scene_header(current, color_scheme=color_scheme)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.25 生成代码可能使用 area="left/right" 但 header 映射缺失
    fixed, desc = _fix_missing_left_right_canvas_areas(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.265 更早的历史切片 layout_canvas 直接返回透明 Rectangle；
    # 当前修改/生成合同要求返回 dict(center/width/height/边界)。
    fixed, desc = _fix_legacy_rectangle_layout_canvas_helper(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.27 旧版 layout_canvas 将 left/right/top/bottom 返回为向量，生成代码常按数字边界使用
    fixed, desc = _fix_layout_canvas_vector_edges(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.275 layout_canvas 是方法，LLM 偶尔误写成 self.layout_canvas["top_center"]。
    fixed, desc = _fix_layout_canvas_method_subscripts(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2755 layout_canvas("top_center")["center"] 需要归一到当前支持的 area key。
    fixed, desc = _fix_layout_canvas_center_alias_method_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.276 旧式 layout_canvas(mobject, zone_name=..., align=...) 与当前 area-only 签名不兼容。
    fixed, desc = _fix_legacy_layout_canvas_mobject_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.277 canvas/layout 返回 dict，不能直接与 float 做向量运算。
    fixed, desc = _fix_canvas_dict_arithmetic(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2772 已经转成中心向量的变量，后续不能再按 dict 读取 ["center"]。
    fixed, desc = _fix_canvas_center_vector_subscripts(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2775 旧版代码把 layout_canvas 返回值当 (left, right, bottom, top) 四元组索引。
    fixed, desc = _fix_canvas_dict_legacy_bounds_indexing(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2778 layout_canvas(...) 返回 dict，不能写成 center, width, height 三元组解包。
    fixed, desc = _fix_layout_canvas_tuple_unpack(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.278 layout_canvas(...) 返回 dict，不能作为 area 位置参数传给 fit/clamp helper。
    fixed, desc = _fix_layout_canvas_dict_positional_area(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.279 layout_canvas(...) 返回 dict，不能直接作为 move_to/next_to 点位。
    fixed, desc = _fix_layout_canvas_dict_point_arguments(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2792 layout_canvas(...) 返回 dict，不能继续当 mobject 读 .width/.get_center()。
    fixed, desc = _fix_layout_canvas_dict_attribute_access(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2795 area= 关键字同样不能传 layout_canvas 返回的 dict。
    fixed, desc = _fix_layout_canvas_dict_keyword_area(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2796 generated code sometimes passes [left, right, bottom, top] as a region.
    # The base helper treats unknown list areas as full canvas, so preserve the region
    # by converting it into size limits plus an explicit center.
    fixed, desc = _fix_fit_to_canvas_numeric_bounds_area(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2797 fit_to_zone is not part of the runtime contract; use fit_to_canvas.
    fixed, desc = fix_fit_to_zone_alias_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2798 next_to(self, getattr(self, "direction", UP)) 把 Scene 当 mobject。
    fixed, desc = _fix_next_to_self_direction_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.280 3D 多 Scene 立方体常把 edge_pairs 留在前一 Scene 的局部作用域。
    fixed, desc = _fix_missing_cube_edge_pairs_global(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.281 NumberLine.add_labels 在 Manim 0.19 需要 dict_values；自动刻度数字用 add_numbers。
    fixed, desc = _fix_number_line_add_labels_without_values(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2812 Shape/VGroup/Square 没有坐标系 coords_to_point，保守转成屏幕点。
    fixed, desc = _fix_shape_coords_to_point_misuse(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.2814 VGroup 字面项少于解包目标时，会触发 not enough values to unpack。
    fixed, desc = _fix_vgroup_tuple_unpack_shortfall(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.282 tex_to_color_map 会把 \frac{\text{...}} 拆成不可编译的 \frac{}。
    fixed, desc = _fix_mathtex_frac_text_color_map_split(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.283 get_base_geometry 经常返回 dict，但后续 Scene 按 (group,A,B,C,D) 解包。
    fixed, desc = _fix_get_base_geometry_dict_contract(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.284 勾股面积模型经常在 VGroup/list/dict 三种合同之间漂移。
    fixed, desc = fix_pythagorean_area_model_dict_contract(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.35 Text 上 get_tex_string 可能存在但内部访问 tex_string 抛 AttributeError
    fixed, desc = _fix_unsafe_inline_get_tex_string(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.37 几何 helper 常把中心点称为 O，但忘记 O = center
    fixed, desc = _fix_undefined_center_point_o(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3 续写/修复偶尔丢掉 header，模块加载前必须恢复核心导入
    fixed, desc = _ensure_core_manim_imports(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30005 模型常写 self.FONT_LABEL，但 BaseConfigScene 未定义类属性；统一转模块级 token。
    fixed, desc = _normalize_self_font_size_tokens(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3001 生成代码常把字号配置写成自由变量，确定性补默认值即可继续渲染。
    fixed, desc = _inject_common_font_size_defaults(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30015 CJK text must not depend on Manim/Pango fallback aliases such as KaiTi.
    fixed, desc = _normalize_cjk_text_typography_font(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3002 块级修复偶尔用 Text = PatchedText 全局替换，Manim Text.__new__ 会被破坏。
    fixed, desc = _remove_dangerous_global_text_monkey_patch(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3005 引语填空题必须把题干中的权威引用锚点带进画面，且只能来自正确选项。
    fixed, desc = _inject_prompt_quote_anchor(current, prompt_context)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3008 self.make_triangle_and_labels 漏定义时，改走模块级确定性 helper。
    fixed, desc = _fix_self_make_triangle_and_labels_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.301 生成代码常凭空调用局部几何 helper，直接注入确定性 shim。
    fixed, desc = _inject_deterministic_generated_helper_shims(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30105 动物场景 helper 要先于泛化未定义 helper，避免专用视觉实现被通用 shim 抢走。
    fixed, desc = _inject_missing_animal_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3011 泛化闭环：AI 自行封装但漏写的裸 helper 必须在渲染前补成可执行代码。
    fixed, desc = inject_undefined_symbol_runtime_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3012 Manim Brace 对部分生成的 ragged VGroup 会在取边界时报 numpy 维度错误。
    fixed, desc = _inject_safe_brace_wrapper(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3015 面积拼图 helper 必须返回统一的几何、边框、标签、分区合同。
    fixed, desc = _fix_square_partition_helper_contract(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.302 helper 被插到 GlobalConfig 前时，默认参数不能引用尚未定义的类。
    fixed, desc = _fix_global_config_default_refs_before_definition(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304 VoiceoverScene 正确初始化 API 是 set_speech_service(...)
    fixed, desc = _fix_init_voiceover_call(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30405 VoiceoverScene.add_voiceover_text(text, text=...) 会触发 Python 参数冲突
    fixed, desc = _fix_add_voiceover_text_duplicate_text_keyword(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3041 BaseConfigScene 只有 setup_layout 时，生成场景不能误调用 Scene.setup() 空实现
    fixed, desc = _fix_scene_setup_calls_to_setup_layout(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30412 setup_layout 不接收标题/区域参数；LLM 误传参时保留初始化语义。
    fixed, desc = _fix_setup_layout_call_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30413 setup_scene 是 LLM 幻觉初始化入口，映射为项目标准 setup_layout。
    fixed, desc = _fix_setup_scene_calls_to_setup_layout(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30414 Manim 只会自动调用 setup()，生成的 setup_layout() 必须挂到标准入口。
    fixed, desc = _ensure_base_config_setup_layout_auto_entry(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304145 LLM 常把 title_zone/content_zone 当中心点属性直接 move_to。
    fixed, desc = _ensure_layout_zone_vector_attrs(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304147 LLM 会把标题基线写成未定义的 self.title_y。
    fixed, desc = _fix_missing_title_y_attr(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30415 Scene 使用布局/配音 helper 时，construct 入口必须先初始化 layout/TTS。
    fixed, desc = _ensure_construct_setup_layout_entry(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3042 禁止退回 gTTS demo provider；真实渲染只走项目 TTS 合同。
    fixed, desc = _fix_unsupported_gtts_voiceover_provider(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304205 manim-voiceover 新版本已移除 BaseSpeechService，旧导入映射到 SpeechService。
    fixed, desc = _fix_legacy_base_speech_service_import(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304208 纯对错符号不走 Tex，避免 \checkmark 等在最小 LaTeX 模板里渲染失败。
    fixed, desc = _fix_pure_latex_markers_to_text(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304209 make_check/make_cross 常被作为目标定位工厂调用，签名必须宽容。
    fixed, desc = _fix_module_choice_factory_signatures(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30421 生成代码偶尔写 if SYSTEM_TTS_AVAILABLE 但没有定义该运行期开关。
    fixed, desc = _inject_system_tts_available_flag(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30425 start_voiceover 是 LLM 幻觉裸调用，转为真实 voiceover 上下文。
    fixed, desc = _fix_bare_start_voiceover_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.304251 self.voiceover 只能作为上下文管理器进入，否则不会生成音频流。
    fixed, desc = _fix_bare_voiceover_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30426 get_pt/rotate_about_axis 等几何 helper 偶尔被写成裸函数调用。
    fixed, desc = _fix_bare_geometry_helper_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30427 Brace.get_text 默认走 Tex，中文单位会触发 LaTeX Unicode 错误。
    fixed, desc = _fix_brace_get_text_cjk_to_text(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3043 custom_services 是项目挂载的顶层包，不在 manim_voiceover.services 下。
    fixed, desc = _fix_nested_custom_services_import(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3045 Manim 0.19 的 Sector 使用 radius=，不是 AnnularSector 的 outer_radius=
    fixed, desc = _fix_sector_outer_radius_keyword(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.30455 AnnularSector 生成代码有时重复传 outer_radius，提前静态去重。
    fixed, desc = _fix_annular_sector_duplicate_outer_radius_keyword(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.3048 BaseConfigScene 的默认 3D 镜头应正对画面；局部深度展示再 move_camera。
    fixed, desc = _normalize_oblique_base_3d_camera_orientation(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.305 3D provider 生成链应主动补齐镜头初始角度，减少静态返工和空深度画面
    fixed, desc = _inject_missing_3d_camera_orientation(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.306 竖屏手机端可读性优先：低字号直接放大，后续布局修复再处理拥挤。
    if is_portrait:
        fixed, desc = _boost_portrait_tiny_font_sizes(current)
        if fixed:
            current = fixed
            fixes.append(desc)

    # 0.31 Mobject/MathTex 没有 bounding_box 属性，Manim CE 需调用 get_bounding_box()
    fixed, desc = _fix_mobject_bounding_box_attribute(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.315 LLM 偶尔调用 Text/Mobject.is_overlapping()，Manim CE 没有内置该方法。
    fixed, desc = _inject_mobject_is_overlapping_compat(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 0.32 英语长课动物场景偶尔引用 make_giraffe/make_student 但漏掉 helper
    fixed, desc = _inject_missing_animal_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1. 中文标点修复
    fixed, desc = _auto_fix_chinese_punctuation(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.5 嵌套 ASCII 双引号修复（Text("抓住"成数"关键词") → 中文引号）
    fixed, desc = _fix_nested_ascii_quotes(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.55 Manim/Pango markup 不支持 HTML <br>，统一换成普通换行。
    fixed, desc = _fix_markup_br_tags_in_string_literals(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.7 raw 字符串末尾单反斜杠修复（r"$^_{}\" → "$^_{}\\"）
    fixed, desc = _fix_raw_string_trailing_backslash(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.78 短视频常把单个 \frac 公式拆成多个 MathTex 字符串，先合并分母碎片
    fixed, desc = _fix_fragmented_fraction_mathtex_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.79 MathTex 内部不能嵌套 align*，归一到 aligned
    fixed, desc = _fix_mathtex_align_star_environments(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.8 MathTex(r"\begin{aligned}", ..., r"\end{aligned}") 合并为单一参数
    fixed, desc = _fix_split_aligned_mathtex_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.82 单字符串 MathTex 中的复杂 \xrightarrow{...} 标签容易触发 LaTeX 参数错误
    fixed, desc = _fix_fragile_mathtex_latex_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.83 MathTex("\\le") 这类 LLM 过度转义命令会被 LaTeX 当成换行
    fixed, desc = _fix_overescaped_mathtex_latex_commands(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.85 MathTex("(x,y)", "\;\xrightarrow{...}\;", "(-y,x)") 这类箭头分片先合并
    fixed, desc = _fix_split_arrow_mathtex_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.9 \overrightarrow{DD'} 这类撇号写法在 xelatex 下不稳定，先转成显式 \prime
    fixed, desc = _fix_latex_point_primes_in_over_arrows(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 1.95 C'/A' 这类几何点像标必须走 MathTex 上标 prime，避免渲染成普通引号或偏移标点
    fixed, desc = _fix_prime_point_text_labels(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2. \u{XXXXX} -> \UXXXXXXXX
    fixed, desc = _fix_unicode_brace_escapes(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.44 TexTemplateLibrary.ct 是 LLM 常见拼写错误，真实 Manim 只有 ctex。
    fixed, desc = _fix_tex_template_library_ct_typo(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.45 手写 TexTemplate()+ctex 会走 latex 并在容器中缺 CJKutf8；统一用项目 ctex 模板
    fixed, desc = _fix_handmade_ctex_template(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.5 如果 header 只给 Tex 配了 ctex，MathTex 含中文仍会走默认 LaTeX 失败
    fixed, desc = _fix_mathtex_ctex_default(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.51 Brace.get_text 内部走 Tex，中文单位标签必须改成普通 Text
    fixed, desc = _fix_brace_get_text_cjk_labels(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.52 MathTex 数学模式里的原始中文单位需包进 \text{}，例如 6元
    fixed, desc = _fix_mathtex_cjk_runs_to_text_commands(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.54 包入 \text{} 后必须确保 ctex 模板存在，否则中文仍无法编译
    fixed, desc = _inject_ctex_defaults_for_cjk_mathtex(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.6 动态 MathTex(variable) 无法静态确认 LaTeX 纯净性，长课总结页降级为 Text 更稳
    fixed, desc = _fix_dynamic_mathtex_name_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.65 formula repair 会传 font_size/color 等 kwargs，本地窄签名 helper 需兼容
    fixed, desc = _fix_inline_math_text_kwargs_signature(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.66 inline_math_text 的 math tuple 必须用 MathTex，避免 \sin/\frac 按普通文本显示
    fixed, desc = _fix_inline_math_text_math_branch_uses_mathtex(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.665 inline_math_text 的 text/unknown tuple 只能显示 payload，不能把 tuple repr 上屏
    fixed, desc = _fix_inline_math_text_tuple_text_payloads(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.666 inline_math_text([("text", ...), ("math", ...)], kwargs) 展开为变参 parts
    fixed, desc = _fix_inline_math_text_single_list_parts_argument(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.67 make_cjk_fraction(r"\sin \theta =", ...) 的公式前缀不能用 Text
    fixed, desc = _fix_make_cjk_fraction_latex_prefix_uses_mathtex(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.675 Text(str(cell).replace(r"\frac"...)) 会把公式表格渲成普通文字。
    fixed, desc = _fix_sanitized_dynamic_formula_text_to_runtime_dispatch(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.68 Text('...$\\vec{DE}') + MathTex('= -\\vec') + MathTex('{DA}$') 是同一公式
    fixed, desc = _fix_split_dollar_vec_formula_group(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 2.7 高置信纯公式边界: Text("a^2+b^2=c^2") -> MathTex(...)
    fixed, formula_text_fixes = rewrite_formula_text_payloads_to_mathtex(current)
    if formula_text_fixes:
        current = fixed
        fixes.extend(formula_text_fixes)

    # 2.8 高置信中文+公式混排边界: Text("证明 OP=OP'") -> self.inline_math_text(...)
    fixed, boundary_fixes = compile_formula_text_boundaries(current)
    if boundary_fixes:
        current = fixed
        fixes.extend(boundary_fixes)

    # 3. MathTex/Tex 含中文 → Text（规划管线跳过：ctex 已处理）
    if not skip_mathtex_to_text:
        fixed, desc = _fix_mathtex_chinese_pre(current)
        if fixed:
            current = fixed
            fixes.append(desc)

    # 4. wait_until_bookmark 多参数修复
    fixed, desc = _fix_wait_until_bookmark(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.5 删除没有 wait/time 消费的 bookmark 标签
    fixed, desc = _fix_unconsumed_bookmarks(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    if _tts_timeline_rewrites_enabled():
        # 4.55-4.59 are legacy timeline rewrites.  They are opt-in only because
        # they change narration/visual semantics after generate_stream.
        fixed, desc = _fix_overlong_voiceover_segments(current)
        if fixed:
            current = fixed
            fixes.append(desc)

        fixed, desc = _fix_wait_only_voiceover_preadd_reveals(current)
        if fixed:
            current = fixed
            fixes.append(desc)

        fixed, desc = _fix_wait_only_voiceover_focus_indicates(current)
        if fixed:
            current = fixed
            fixes.append(desc)

        fixed, desc = _fix_multi_play_voiceover_blocks_to_even_helper(current)
        if fixed:
            current = fixed
            fixes.append(desc)

    # 4.595 生成代码使用 play_steps_evenly 时必须保证 BaseConfigScene 带 helper
    fixed, desc = _inject_tts_timing_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.6 tracker.duration 剩余补时改成短尾巴，避免配音后长时间静止
    fixed, desc = _fix_tracker_remainder_waits(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.65 tracker.time_remaining() 不是当前 VoiceoverTracker API，改成短尾巴
    fixed, desc = _fix_tracker_time_remaining_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.655 文字/公式动画不要绑定整段配音时长，先收敛成短动画
    fixed, desc = _fix_tracker_duration_direct_bindings(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.66 Manim 没有 TOP/BOTTOM 方向常量，统一到 UP/DOWN
    fixed, desc = _fix_direction_alias_constants(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.7 首个动画前批量 add 文字/公式，改成短 FadeIn 逐步揭示
    fixed, desc = _fix_bulk_pre_reveal_text_adds(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.75 生成代码调用 fit_to_canvas 但漏掉 helper 时，注入运行期兜底
    fixed, desc = _inject_missing_fit_to_canvas_helper(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.77 生成代码保留了简化版 BaseConfigScene 时，补齐最常用运行期 helper。
    fixed, desc = _inject_missing_base_config_runtime_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.772 add_title 有些脚本按 (title, underline) 解包，但旧 helper 只返回 title。
    fixed, desc = _fix_add_title_tuple_unpack(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.775 create_triangle_figure 需同时支持 unpack 与直接作为 VGroup 缩放/移动。
    fixed, desc = _fix_triangle_figure_tuple_helper_return(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 4.8 横向排列多个几何对象时补最终边界适配，避免竖屏中左右飞出
    fixed, desc = _fix_wide_horizontal_geometry_groups(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 5. LaTeX 大括号配对校验与修复
    fixed, desc = _fix_latex_brace_mismatch(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6. 废弃 API 修复：Angle.get_vector() → (end - start)
    fixed, desc = _fix_deprecated_get_vector(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5 根据配色方案修复低对比度颜色
    fixed, desc = _fix_low_contrast_colors(current, color_scheme)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.52 interpolate_color 不能直接吃 "#RRGGBB" 字符串，先包装成安全色值转换
    fixed, desc = _fix_interpolate_color_string_inputs(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.55 Manim 默认命名色归一到 GlobalConfig，避免绕过配色合同
    fixed, desc = _fix_default_manim_color_constants(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.551 颜色归一可能重新把早于 GlobalConfig 的默认参数改成前置引用。
    fixed, desc = _fix_global_config_default_refs_before_definition(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.555 修复脚本可能直接用 TITLE_COLOR/MAIN_COLOR 等全局色名。
    fixed, desc = _inject_module_color_aliases(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.56 GlobalConfig.TITLE_COLOR 等缺失别名补成类属性，避免进入 Manim 后 AttributeError
    fixed, desc = _inject_global_config_alias_assignments(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57 GlobalConfig.SECONDARY 等短别名归一到已定义属性
    fixed, desc = _fix_global_config_alias_references(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.572 块级修复可能留下裸 MAIN_COLOR 等变量，统一回 GlobalConfig。
    fixed, desc = _inject_module_global_config_color_aliases(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5722 RED_COLOR/GREEN_COLOR 等裸语义色没有主题别名时，直接给模块级安全兜底。
    fixed, desc = _inject_module_theme_color_fallbacks(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5725 LLM 常把 BaseConfigScene 的主题色常量写成 self.main_color 等小写实例属性。
    fixed, desc = _fix_lowercase_self_theme_color_aliases(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.573 使用项目 helper 的 Scene 不能绕开 BaseConfigScene。
    fixed, desc = _fix_scene_classes_requiring_base_config_inheritance(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5732 BaseConfigScene 已经继承具体 Scene 基类时，Scene 不可再重复多继承。
    fixed, desc = _fix_scene_classes_redundant_base_config_mro(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.575 self.MUTED_COLOR 等引用需要同步暴露到 BaseConfigScene
    fixed, desc = _inject_base_config_scene_global_aliases(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57505 选择题/结论切片常用的 self.SUCCESS_COLOR/CARD_BG 等要有安全兜底。
    fixed, desc = _inject_base_config_scene_theme_color_fallbacks(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5751 standalone slice 只在 setup() 里设置 PRIMARY_TEXT 时，也要支持 self.TEXT_COLOR。
    fixed, desc = _inject_base_config_text_color_fallback(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5752 共享场景基类被 LLM/块级修复漏掉时，先别让 NameError 中断渲染。
    fixed, desc = _inject_missing_scene_base_aliases(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5755 VoiceoverScene 历史 helper 名称漂移，用本地 BaseConfigScene 兜底
    fixed, desc = _inject_voiceover_runtime_compat_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57551 裸 narrate(...) 在 Scene 方法内会 NameError，先转成实例合同。
    fixed, desc = _fix_bare_narrate_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57552 LLM 常生成 with self.narrate(...)，转接到项目 voiceover 合同。
    fixed, desc = _inject_narrate_voiceover_helper(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57553 勾股定理场景常幻觉构图 helper，先用确定性几何兜底。
    fixed, desc = _inject_pythagorean_geometry_scene_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57554 BaseConfigScene.create_right_angle_mark 不能在 Scene 内裸调用。
    fixed, desc = _fix_create_right_angle_mark_contract(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.575545 函数内 guard import 会让 np 变成本地变量，导致 UnboundLocalError。
    fixed, desc = _fix_local_numpy_import_scope(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57555 选择题模板式 helper 漏生成时，用确定性运行期 shim 避免进入 LLM slice repair。
    fixed, desc = _inject_exam_question_runtime_helpers(
        current,
        prompt_context=prompt_context,
    )
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57556 勾叉 helper 常被生成代码用作“覆盖到目标对象”的语义，不能把 Mobject 当颜色。
    fixed, desc = _fix_choice_mark_helper_mobject_targets(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57557 选择题左栏 helper 必须可索引，避免 left_group[4] 这类模板访问越界。
    fixed, desc = _fix_create_left_column_contract(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5756 Voiceover 兼容 helper 可能引入 safe_text_box/layout_canvas 调用，再补一轮 BaseConfig helper。
    fixed, desc = _inject_missing_base_config_runtime_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = _fix_triangle_figure_tuple_helper_return(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.576 生成代码常把 visible_objects 当实例状态使用，但漏初始化
    fixed, desc = _inject_visible_objects_default(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5765 get_icon 是 LLM 幻觉别名，项目运行时 helper 名称是 asset_icon
    fixed, desc = _fix_get_icon_alias(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5768 兜底版 asset_icon 需兼容官方图标 helper 的 size/stroke_width 等参数
    fixed, desc = _fix_narrow_asset_icon_signature(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5769 generated:* 是项目生成资产命名空间，必须保留给 asset_icon 解析。
    fixed, desc = _fix_generated_asset_icon_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57694 文本/标题 helper 不能退化为 fallback icon；直接恢复真实 Text。
    fixed, desc = _fix_text_helper_fallback_icon_returns(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57695 已废弃：不再把 _semantic_visual_icon/generated_icon 全局回调成圆点 icon。
    fixed, desc = _fix_semantic_icon_text_box_fallback_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.57696 可见圆点/文字框 fallback 不能进入最终画面；转成明确可修复错误。
    fixed, desc = _disable_visible_fallback_icon_paths(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.577 asset_icon 是提示词推荐 helper，漏定义时只能显式报缺资产，不能画占位图。
    fixed, desc = _inject_asset_icon_helper(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.579 LLM 偶尔把 Manim 的 Axes 幻觉成不存在的 NumberAxes
    fixed, desc = _fix_number_axes_alias(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.58 坐标轴主体尺寸下限，避免 2D 图形缩成小角落
    fixed, desc = _fix_undersized_2d_axes(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.59 safe_text_box() 无效关键字兜底，避免低级 TypeError 进入 LLM 修复
    fixed, desc = _fix_safe_text_box_invalid_keywords(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.591 LLM 偶尔用 zone= 表示布局区域，统一改为项目 helper 支持的 area=
    fixed, desc = _fix_layout_helper_zone_keyword_alias(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.5915 标题对象如果没有任何定位，safe_text_box/Text 默认会落在屏幕中心；补到顶部标题区。
    fixed, desc = _fix_unpositioned_title_objects_to_top(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.592 fit_to_canvas() 无效关键字兜底，兼容 LLM 自定义窄签名 helper
    fixed, desc = _fix_fit_to_canvas_invalid_keywords(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.595 LLM 偶尔把 safe_text_box 缩写为 self.safe(...)
    fixed, desc = _fix_hallucinated_self_safe_call(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.596 自定义 safe_text_box 里 Text(..., color=..., **kwargs) 会和外部 color 冲突
    fixed, desc = _fix_safe_text_box_duplicate_color_kwargs(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.60 safe_text_box(font_size=...) 的静态类型兜底，避免 float 进 int 参数
    fixed, desc = _fix_safe_text_box_font_size_casts(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.6005 横屏超大字号会制造明显 UI 不协调和后续重叠，先压到安全上限。
    fixed, desc = _fix_landscape_oversized_text_font_sizes(
        current,
        is_portrait=is_portrait,
    )
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.60 Manim VGroup 没有 __len__；生成代码常用 len(vgroup) 循环索引
    fixed, desc = _fix_vgroup_len_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.602 VoiceoverScene 的 self.mobjects 可能混入非 VMobject，VGroup 前先过滤
    fixed, desc = _fix_unfiltered_self_mobjects_vgroup(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.605 普通 list 没有 submobjects；文本换行 helper 常被 LLM 写反
    fixed, desc = _fix_list_len_submobjects_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.606 代码块 helper 常把单行字符串误当 Manim 对象计算缩进
    fixed, desc = _fix_string_indent_len_submobjects_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.6065 Manim 0.19 Code 没有 .code 属性，逐行高亮应使用 .code_lines
    fixed, desc = _fix_code_object_code_attribute_access(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.607 MathTex/Text 子对象拆分数量不可依赖，索引越界时退回整体对象
    fixed, desc = _fix_mobject_index_accesses(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.61 平移/变换动画不要把原标签整体 TransformFromCopy 到目标标签
    fixed, desc = _fix_transform_from_copy_label_group_overlap(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.6 Text() 内含 LaTeX \text{} 语法修复
    fixed, desc = _fix_text_with_latex(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.65 后续 Text/MathTex 降级可能撤销早期公式修复，末端再执行一次合同兜底
    fixed, formula_text_fixes = rewrite_formula_text_payloads_to_mathtex(current)
    if formula_text_fixes:
        current = fixed
        fixes.extend(formula_text_fixes)

    fixed, boundary_fixes = compile_formula_text_boundaries(current)
    if boundary_fixes:
        current = fixed
        fixes.extend(boundary_fixes)

    fixed, desc = _inject_ctex_defaults_for_cjk_mathtex(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.69 Surface/ParametricFunction 的 use_smoothing 默认值会污染构造器 kwargs。
    fixed, desc = _fix_use_smoothing_unsupported_kwargs(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.7 Manim 0.19 API 参数兼容修复
    fixed, desc = fix_manim_arrow_size_keyword(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = fix_clamp_to_canvas_buff_keyword(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = _fix_manim_019_api_kwargs(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = fix_get_layout_area_get_center_calls(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = inject_cylinder_cone_mobject_contracts(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    fixed, desc = fix_label_arc_and_outside_label_icon_fallbacks(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.705 Manim 0.19 next_to 不支持 align_to=，应链式调用 align_to。
    fixed, desc = _fix_next_to_align_to_keyword(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.71 Scene.play() 只能接收 Animation，裸 Mobject 先包 Create()
    fixed, desc = _fix_raw_mobject_scene_play_args(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.72 VoiceoverScene 基类必须先导入，避免类定义阶段 NameError
    fixed, desc = _fix_missing_voiceover_scene_import(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.73 避免覆盖 manim-voiceover 的 wait_for_voiceover() 生命周期方法
    fixed, desc = _fix_voiceover_wait_method_collision(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.74 3D Text/MathTex 必须先 fixed 注册，再参与 Write/FadeIn/Transform
    fixed, desc = _fix_3d_text_registration_order(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.75 Manim 0.19 无内置 Polyline；注入开放折线兼容类
    fixed, desc = inject_polyline_compat(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.755 部分修复器会引入新的裸 helper，收尾再做一次 undefined-symbol 闭环。
    fixed, desc = inject_undefined_symbol_runtime_helpers(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.756 泛化 self.helper() 闭环必须晚于专用 helper，避免把精细修复降级成通用兜底。
    fixed, desc = inject_missing_self_helper_methods(current)
    if fixed:
        current = fixed
        fixes.append(desc)

    # 6.8 重复类定义清理（规划管线跳过：单 Scene 单文件）
    if not skip_dedup:
        fixed, desc = _dedup_scene_classes(current)
        if fixed:
            current = fixed
            fixes.append(desc)

    if enable_visual_overflow_fixes:
        # 6.9 未保护文本溢出修复（长中文 Text 添加宽度限制）
        fixed, desc = _fix_unprotected_text_overflow(current)
        if fixed:
            current = fixed
            fixes.append(desc)

        # 6.10 长MathTex公式溢出修复
        fixed, desc = _fix_mathtex_overflow(current)
        if fixed:
            current = fixed
            fixes.append(desc)

    # 7. ast.parse 语法检查 + 自动补全截断
    import ast
    try:
        ast.parse(current)
    except SyntaxError:
        fixed, desc = _auto_fix_truncation(current)
        if fixed:
            try:
                ast.parse(fixed)
                current = fixed
                fixes.append(desc)
            except SyntaxError:
                pass  # 补全后仍有语法错误，交给后续处理

    return current, fixes
