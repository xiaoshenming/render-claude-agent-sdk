"""Runtime helper closure for generated undefined symbol calls.

Generated Manim code often invents small helper functions and then forgets to
emit their definitions. This module repairs that class by adding executable
fallback helpers before container render. It is intentionally repair-first:
the generated scene keeps its structure, while missing helper calls become
safe, renderable primitives.
"""

from __future__ import annotations

import ast
import builtins
import re
from dataclasses import dataclass, field
from typing import Optional

try:
    from app.workers.repair.static_guard import _COMMON_ALLOWED_NAMES
except Exception:  # pragma: no cover - import-time safety for isolated tools
    _COMMON_ALLOWED_NAMES = set()


_KNOWN_LOWER_MANIM_NAMES = {
    "always_redraw",
    "angle_of_vector",
    "color_gradient",
    "interpolate",
    "interpolate_color",
    "linear",
    "smooth",
    "there_and_back",
    "there_and_back_with_pause",
    "rush_from",
    "rush_into",
    "wiggle",
}

_PROJECT_CONTRACT_HELPERS = {
    "add_title",
    "clamp_to_canvas",
    "fit_to_canvas",
    "inline_math_text",
    "layout_canvas",
    "make_title",
    "narrate",
    "place_non_overlapping",
    "play_voiceover",
    "safe_math_box",
    "safe_text_box",
    "setup_layout",
    "wait_until_bookmark",
}

_IGNORED_HELPER_NAMES = (
    set(dir(builtins))
    | set(_COMMON_ALLOWED_NAMES)
    | _KNOWN_LOWER_MANIM_NAMES
    | _PROJECT_CONTRACT_HELPERS
)

_VERTICAL_DIVISION_HELPER_NAMES = {
    "create_division_grid",
    "create_division_layout",
    "create_division_mobject",
    "create_long_division",
    "make_division_layout",
}
_VERTICAL_DIVISION_CLASS_NAMES = {"VerticalDivision"}


from .undefined_symbol_analysis import *
def _infer_return_kind(info: _MissingCall) -> str:
    name = info.name.lower()
    if info.unpack_count >= 2:
        return f"point_tuple:{info.unpack_count}"
    if any(part in name for part in ("point", "pos", "coord", "center", "intersection", "projection")):
        return "point"
    if any(part in name for part in ("points", "intersections", "vertices")):
        return "point_tuple:3"
    if any(part in name for part in ("length", "distance", "radius", "angle", "ratio", "scale")):
        return "scalar"
    if "subscript" in info.contexts:
        return "dict"
    if any(ctx in info.contexts for ctx in ("arg:Dot", "arg:Line", "arg:move_to", "arg:next_to")):
        return "point"
    return "mobject"
def _generic_helper_lines(name: str, kind: str) -> list[str]:
    lines = [f"def {name}(*args, **kwargs):"]
    if kind.startswith("point_tuple:"):
        try:
            count = max(1, int(kind.split(":", 1)[1]))
        except Exception:
            count = 2
        lines.extend([
            "    base = _mathpi_runtime_point3(kwargs.get('center', ORIGIN))",
            "    radius = _mathpi_runtime_scalar(kwargs.get('radius', 1.0), 1.0)",
            f"    offsets = [RIGHT * radius * (i - ({count} - 1) / 2.0) for i in range({count})]",
            "    return tuple(base + offset for offset in offsets)",
            "",
        ])
        return lines
    if kind == "point":
        lines.extend([
            "    return _mathpi_fallback_point(*args, **kwargs)",
            "",
        ])
        return lines
    if kind == "scalar":
        lines.extend([
            "    return _mathpi_runtime_scalar(kwargs.get('value', args[0] if args else 1.0), 1.0)",
            "",
        ])
        return lines
    if kind == "dict":
        lines.extend([
            "    return _mathpi_fallback_geometry_dict(*args, **kwargs)",
            "",
        ])
        return lines
    lines.extend([
        f"    return _mathpi_fallback_mobject(*args, label={name!r}, **kwargs)",
        "",
    ])
    return lines
def _tangent_point_helper_lines() -> list[str]:
    return [
        "def get_tangent_point(point=None, center=ORIGIN, radius=1.0, select_top=True, **_kwargs):",
        "    p = _mathpi_runtime_point3(point, fallback=RIGHT * 3)",
        "    c = _mathpi_runtime_point3(center)",
        "    r = abs(_mathpi_runtime_scalar(radius, 1.0)) or 1.0",
        "    v = p - c",
        "    d = np.linalg.norm(v)",
        "    if d <= r + 1e-9:",
        "        return c + RIGHT * r",
        "    base = c + v * (r * r / (d * d))",
        "    perp = np.array([-v[1], v[0], 0.0], dtype=float) / d",
        "    h = r * np.sqrt(max(d * d - r * r, 0.0)) / d",
        "    t1 = base + perp * h",
        "    t2 = base - perp * h",
        "    return t1 if (t1[1] >= t2[1]) == bool(select_top) else t2",
        "",
    ]
def _secant_points_helper_lines() -> list[str]:
    return [
        "def get_secant_points(",
        "    point=None, center=ORIGIN, radius=1.0, angle_offset_deg=0.0, direction=None, **_kwargs",
        "):",
        "    p = _mathpi_runtime_point3(point, fallback=RIGHT * 3)",
        "    c = _mathpi_runtime_point3(center)",
        "    r = abs(_mathpi_runtime_scalar(radius, 1.0)) or 1.0",
        "    if direction is None:",
        "        base_dir = _mathpi_runtime_unit(c - p, fallback=LEFT)",
        "        angle = np.deg2rad(_mathpi_runtime_scalar(angle_offset_deg, 0.0))",
        "        ca, sa = np.cos(angle), np.sin(angle)",
        "        direction_vec = np.array([",
        "            base_dir[0] * ca - base_dir[1] * sa,",
        "            base_dir[0] * sa + base_dir[1] * ca,",
        "            0.0,",
        "        ], dtype=float)",
        "    else:",
        "        direction_vec = _mathpi_runtime_unit(direction, fallback=c - p)",
        "    direction_vec = _mathpi_runtime_unit(direction_vec, fallback=LEFT)",
        "    rel = p - c",
        "    b = 2.0 * np.dot(rel, direction_vec)",
        "    cc = np.dot(rel, rel) - r * r",
        "    disc = max(b * b - 4.0 * cc, 0.0)",
        "    t_near = (-b - np.sqrt(disc)) / 2.0",
        "    t_far = (-b + np.sqrt(disc)) / 2.0",
        "    pts = [p + t_near * direction_vec, p + t_far * direction_vec]",
        "    pts.sort(key=lambda item: np.linalg.norm(item - p))",
        "    return pts[0], pts[-1]",
        "",
    ]
def _helper_insert_position(code: str) -> int:
    lines = code.splitlines()
    last_assignment = -1
    for index, line in enumerate(lines):
        if re.match(r"^class\s+", line):
            break
        if re.match(r"^[A-Z][A-Z0-9_]*\s*(?::[^=]+)?=", line):
            last_assignment = index
    if last_assignment >= 0:
        return last_assignment + 1

    last_import = -1
    for index, line in enumerate(lines):
        if re.match(r"^(?:from\s+\S+\s+import\s+|import\s+)", line):
            last_import = index
            continue
        if line.strip() and last_import >= 0:
            break
    return last_import + 1 if last_import >= 0 else 0
