"""Fast pre-render pool case 输入规整。"""
from __future__ import annotations
from pathlib import Path
from typing import Any, Mapping, Callable

def load_pool_cases(pool_path: Path, read_json: Callable[[Path], Any], scene_names_from_case: Callable[[Mapping[str, Any]], list[str]]) -> list[dict[str, Any]]:
    payload = read_json(pool_path)
    raw_cases = payload.get("cases") if isinstance(payload, Mapping) else None
    if raw_cases is None: raw_cases = payload.get("items") if isinstance(payload, Mapping) else None
    if not isinstance(raw_cases, list): raise ValueError("pool must contain a cases or items list")
    cases = []
    for index, item in enumerate(raw_cases, start=1):
        if isinstance(item, str):
            raw_source, case_id, scene_names = item, Path(item).stem or f"case-{index:03d}", []
        elif isinstance(item, Mapping):
            raw_source = item.get("source_path") or item.get("source") or item.get("candidate_path") or item.get("code_path") or item.get("path")
            case_id = str(item.get("case_id") or item.get("id") or Path(str(raw_source or "")).stem or f"case-{index:03d}")
            scene_names = scene_names_from_case(item)
        else: raise ValueError(f"pool case #{index} must be an object or source path string")
        if not raw_source: raise ValueError(f"pool case {case_id} missing source_path")
        source_path = Path(str(raw_source)); source_path = source_path if source_path.is_absolute() else pool_path.parent / source_path
        cases.append({"case_id": case_id, "source_path": source_path, "scene_names": scene_names or None})
    return cases
