"""Strict block repair 结果摘要构造。"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Mapping, Sequence


def build_summary(*, root: Path, source: Path, status: str, scenes: Sequence[str], checks: Mapping[str, Mapping[str, Any]], llm_call_count: int, repair_round_count: int, render_round_count: int, rejected_repair_count: int, rejected_repair_reasons: Sequence[str], common_root_repair_count: int, source_contract_repairs: Sequence[Mapping[str, Any]], started: float, max_rounds: int) -> dict[str, Any]:
    failed_scenes = [scene for scene in scenes if not bool(checks.get(scene, {}).get("render_ok"))]
    final_scene_mp4_paths = {scene: str(checks.get(scene, {}).get("mp4") or "") for scene in scenes if checks.get(scene, {}).get("render_ok") and checks.get(scene, {}).get("mp4")}
    categories: dict[str, int] = {}
    visual_mutation_count = 0
    for item in source_contract_repairs:
        category = str(item.get("category") or "unknown")
        categories[category] = categories.get(category, 0) + 1
        visual_mutation_count += int(bool(item.get("visual_mutation")))
    return {
        "final_status": status, "source_path": str(source), "final_path": str(root / "final.py"),
        "scene_count": len(scenes), "render_ok_count": len(scenes) - len(failed_scenes), "failed_scenes": failed_scenes,
        "llm_call_count": llm_call_count, "repair_round_count": repair_round_count, "common_root_repair_count": common_root_repair_count,
        "render_round_count": render_round_count, "rejected_repair_count": rejected_repair_count, "rejected_repair_reasons": list(rejected_repair_reasons),
        "source_contract_repair_count": len(source_contract_repairs), "source_contract_repairs": list(source_contract_repairs),
        "source_contract_repair_categories": categories, "source_contract_visual_mutation_count": visual_mutation_count,
        "final_scene_mp4_paths": final_scene_mp4_paths, "max_rounds": max_rounds,
        "duration_sec": round(time.monotonic() - started, 3), "per_scene_results_path": str(root / "per_scene_results.jsonl"),
    }
