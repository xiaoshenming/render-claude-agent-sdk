from __future__ import annotations

import ast
import re
from .self_helper_patterns import *

def _self_vertical_division_helper_lines(
    calls: dict[str, _SelfHelperUse],
    *,
    indent: str,
    body: str,
) -> list[str]:
    lines: list[str] = [
        "",
        f"{indent}def _mathpi_vertical_division_value(self, kwargs, names, default='?'):",
        f"{body}for name in names:",
        f"{body}    value = kwargs.get(name)",
        f"{body}    if value is not None and str(value) != '':",
        f"{body}        return str(value)",
        f"{body}return str(default)",
        "",
        f"{indent}def _mathpi_vertical_division_sequence(self, kwargs, whole_name, part_names, default):",
        f"{body}raw = kwargs.get(whole_name)",
        f"{body}if raw is not None and str(raw) != '':",
        f"{body}    chars = list(str(raw))",
        f"{body}else:",
        f"{body}    chars = []",
        f"{body}    for name in part_names:",
        f"{body}        value = kwargs.get(name)",
        f"{body}        chars.append(str(value) if value is not None else '')",
        f"{body}    if not any(chars):",
        f"{body}        chars = list(str(default))",
        f"{body}chars = [char for char in chars if char != '']",
        f"{body}return chars or list(str(default))",
        "",
        f"{indent}def _mathpi_vertical_division_digit(self, value, color=None, font_size=40):",
        f"{body}text = str(value if value is not None else '')",
        f"{body}if text == '':",
        f"{body}    return VGroup()",
        f"{body}draw_color = color or getattr(self, 'PRIMARY_TEXT', globals().get('BLACK', globals().get('WHITE')))",
        f"{body}try:",
        f"{body}    return MathTex(text, font_size=font_size, color=draw_color)",
        f"{body}except Exception:",
        f"{body}    return Text(text, font_size=font_size, color=draw_color)",
        "",
        f"{indent}def _mathpi_vertical_division_layout(self, *args, **kwargs):",
        f"{body}try:",
        f"{body}    import numpy as _np",
        f"{body}except Exception:",
        f"{body}    _np = None",
        f"{body}def vec(x, y):",
        f"{body}    return _np.array([x, y, 0.0]) if _np is not None else [x, y, 0.0]",
        f"{body}color_map = kwargs.get('color_map') or {{}}",
        f"{body}text_color = kwargs.get('text_color') or kwargs.get('color') or getattr(self, 'PRIMARY_TEXT', globals().get('BLACK', globals().get('WHITE')))",
        f"{body}line_color = color_map.get('lines') or kwargs.get('stroke_color') or getattr(self, 'MAIN_COLOR', text_color)",
        f"{body}try:",
        f"{body}    font_size = int(float(kwargs.get('font_size', 40)))",
        f"{body}except Exception:",
        f"{body}    font_size = 40",
        f"{body}divisor_text = self._mathpi_vertical_division_value(kwargs, ('divisor', 'divisor_text'), '6')",
        f"{body}dividend_chars = self._mathpi_vertical_division_sequence(kwargs, 'dividend', ('dividend_h', 'dividend_t', 'dividend_u'), '256')[-3:]",
        f"{body}quotient_chars = self._mathpi_vertical_division_sequence(kwargs, 'quotient', ('quotient_h', 'quotient_t', 'quotient_u'), '42')[-3:]",
        f"{body}while len(dividend_chars) < 3:",
        f"{body}    dividend_chars.insert(0, '')",
        f"{body}while len(quotient_chars) < 3:",
        f"{body}    quotient_chars.insert(0, '')",
        f"{body}sub1_text = self._mathpi_vertical_division_value(kwargs, ('sub1', 'subtract1', 'first_sub'), '')",
        f"{body}diff_t_text = self._mathpi_vertical_division_value(kwargs, ('diff_t', 'diff_tens', 'remainder_t'), '')",
        f"{body}diff_u_text = self._mathpi_vertical_division_value(kwargs, ('diff_u', 'diff_units', 'bring_down'), dividend_chars[-1])",
        f"{body}sub2_t_text = self._mathpi_vertical_division_value(kwargs, ('sub2_t', 'sub2_tens', 'second_sub_t'), '')",
        f"{body}sub2_u_text = self._mathpi_vertical_division_value(kwargs, ('sub2_u', 'sub2_units', 'second_sub_u'), '')",
        f"{body}rem_text = self._mathpi_vertical_division_value(kwargs, ('rem', 'remainder'), '0')",
        f"{body}def color_for(name):",
        f"{body}    return color_map.get(name, text_color)",
        f"{body}xs = [-0.62, -0.02, 0.58]",
        f"{body}divisor = self._mathpi_vertical_division_digit(divisor_text, color_for('divisor'), font_size)",
        f"{body}dividend_h = self._mathpi_vertical_division_digit(dividend_chars[0], color_for('dividend_h'), font_size)",
        f"{body}dividend_t = self._mathpi_vertical_division_digit(dividend_chars[1], color_for('dividend_t'), font_size)",
        f"{body}dividend_u = self._mathpi_vertical_division_digit(dividend_chars[2], color_for('dividend_u'), font_size)",
        f"{body}quotient_h = self._mathpi_vertical_division_digit(quotient_chars[0], color_for('quotient_h'), font_size)",
        f"{body}quotient_t = self._mathpi_vertical_division_digit(quotient_chars[1], color_for('quotient_t'), font_size)",
        f"{body}quotient_u = self._mathpi_vertical_division_digit(quotient_chars[2], color_for('quotient_u'), font_size)",
        f"{body}sub1 = self._mathpi_vertical_division_digit(sub1_text, color_for('sub1'), font_size)",
        f"{body}diff_t = self._mathpi_vertical_division_digit(diff_t_text, color_for('diff_t'), font_size)",
        f"{body}diff_u = self._mathpi_vertical_division_digit(diff_u_text, color_for('diff_u'), font_size)",
        f"{body}sub2_t = self._mathpi_vertical_division_digit(sub2_t_text, color_for('sub2_t'), font_size)",
        f"{body}sub2_u = self._mathpi_vertical_division_digit(sub2_u_text, color_for('sub2_u'), font_size)",
        f"{body}rem = self._mathpi_vertical_division_digit(rem_text, color_for('rem'), font_size)",
        f"{body}divisor.move_to(vec(-1.32, 0.05))",
        f"{body}for mob, x in zip((dividend_h, dividend_t, dividend_u), xs):",
        f"{body}    mob.move_to(vec(x, 0.05))",
        f"{body}for mob, x in zip((quotient_h, quotient_t, quotient_u), xs):",
        f"{body}    mob.move_to(vec(x, 0.82))",
        f"{body}sub1.move_to(vec(xs[0], -0.48))",
        f"{body}diff_t.move_to(vec(xs[1], -1.02))",
        f"{body}diff_u.move_to(vec(xs[2], -1.02))",
        f"{body}sub2_t.move_to(vec(xs[1], -1.56))",
        f"{body}sub2_u.move_to(vec(xs[2], -1.56))",
        f"{body}rem.move_to(vec(xs[2], -2.1))",
        f"{body}bracket_x = xs[0] - 0.34",
        f"{body}line_end = xs[-1] + 0.38",
        f"{body}bracket_vertical = Line(vec(bracket_x, 0.46), vec(bracket_x, -0.24), color=line_color)",
        f"{body}bracket_top = Line(vec(bracket_x, 0.46), vec(line_end, 0.46), color=line_color)",
        f"{body}first_line = Line(vec(xs[0] - 0.22, -0.22), vec(line_end, -0.22), color=line_color)",
        f"{body}second_line = Line(vec(xs[1] - 0.22, -1.3), vec(line_end, -1.3), color=line_color)",
        f"{body}lines = VGroup(bracket_vertical, bracket_top, first_line, second_line)",
        f"{body}quotient = VGroup(quotient_h, quotient_t, quotient_u)",
        f"{body}dividend = VGroup(dividend_h, dividend_t, dividend_u)",
        f"{body}subtraction_1 = VGroup(sub1)",
        f"{body}remainder_step = VGroup(diff_t, diff_u)",
        f"{body}subtraction_2 = VGroup(sub2_t, sub2_u)",
        f"{body}group = VGroup(divisor, dividend, quotient, subtraction_1, remainder_step, subtraction_2, rem, lines)",
        f"{body}try:",
        f"{body}    scale = float(kwargs.get('scale', 1.0))",
        f"{body}except Exception:",
        f"{body}    scale = 1.0",
        f"{body}if abs(scale - 1.0) > 1e-6:",
        f"{body}    group.scale(scale)",
        f"{body}if kwargs.get('center') is not None:",
        f"{body}    group.move_to(kwargs.get('center'))",
        f"{body}parts = {{",
        f"{body}    'divisor': divisor,",
        f"{body}    'dividend_h': dividend_h,",
        f"{body}    'dividend_t': dividend_t,",
        f"{body}    'dividend_u': dividend_u,",
        f"{body}    'dividend': dividend,",
        f"{body}    'quotient_h': quotient_h,",
        f"{body}    'quotient_t': quotient_t,",
        f"{body}    'quotient_u': quotient_u,",
        f"{body}    'quotient': quotient,",
        f"{body}    'sub1': sub1,",
        f"{body}    'diff_t': diff_t,",
        f"{body}    'diff_u': diff_u,",
        f"{body}    'sub2_t': sub2_t,",
        f"{body}    'sub2_u': sub2_u,",
        f"{body}    'rem': rem,",
        f"{body}    'remainder': rem,",
        f"{body}    'lines': lines,",
        f"{body}    'group': group,",
        f"{body}}}",
        f"{body}return group, parts",
        "",
    ]
    for name, use in sorted(calls.items()):
        lines.append(f"{indent}def {name}(self, *args, **kwargs):")
        if use.unpack_count >= 2:
            lines.append(f"{body}return self._mathpi_vertical_division_layout(*args, **kwargs)")
        elif "subscript" in use.contexts:
            lines.append(f"{body}return self._mathpi_vertical_division_layout(*args, **kwargs)[1]")
        else:
            lines.append(f"{body}return self._mathpi_vertical_division_layout(*args, **kwargs)[0]")
        lines.append("")
    return lines
def _base_config_scene_class_range(code: str) -> tuple[int, int, str] | None:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None
    lines = code.splitlines()
    for node in tree.body:
        if not isinstance(node, ast.ClassDef) or node.name != "BaseConfigScene":
            continue
        if node.end_lineno is None:
            return None
        class_line = lines[node.lineno - 1] if 0 <= node.lineno - 1 < len(lines) else ""
        indent = class_line[: len(class_line) - len(class_line.lstrip())]
        end = node.end_lineno
        body = node.body
        if len(body) == 1 and isinstance(body[0], ast.Pass):
            return node.lineno - 1, body[0].lineno, indent
        return node.lineno - 1, end, indent
    return None

