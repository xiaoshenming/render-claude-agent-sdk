"""Production per-scene render-before-repair loop for generate_stream code."""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Mapping
from app.workers.repair.pre_render.fast_pool_summary import pool_summary, pool_summary_markdown
from app.workers.repair.pre_render.pool_case_loader import load_pool_cases
from app.workers.repair.pre_render.fast_render_llm import (
    openai_protocol_repair_client as _openai_protocol_repair_client,
    _chat_completions_url,
    stream_delta_content as _stream_delta_content,
)
from app.workers.repair.pre_render.fast_render_validation import (
    missing_base_name as _missing_base_name,
    scene_base_reference_errors as _scene_base_reference_errors,
    validate_repair_candidate as _validate_repair_candidate,
)


from app.repair_lab.video_render import _scene_class_names, run_manim_docker_render


RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
CaseRunner = Callable[..., Mapping[str, Any]]



from .fast_render_runner_cases import *
from .fast_render_runner_pool_flow import run_pool, run_self_test
from .fast_render_runner_file_flow import run_file

def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.self_test:
        summary = run_self_test(
            out_dir=args.out,
            max_rounds=args.max_rounds,
            workers=args.workers,
        )
        print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if summary["success_count"] == summary["case_count"] else 1

    if not args.source and not args.pool:
        parser.error("one of --source, --pool, or --self-test is required")

    repair_client = _openai_protocol_repair_client(
        base_url=args.base_url or os.environ.get("PRERENDER_LLM_BASE_URL", ""),
        model=args.model or os.environ.get("PRERENDER_LLM_MODEL", ""),
        api_key=os.environ.get("PRERENDER_LLM_API_KEY", ""),
        timeout_sec=args.llm_timeout_sec,
        require_google=not args.allow_non_google_model,
    )
    if args.pool:
        summary = run_pool(
            pool_path=args.pool,
            out_dir=args.out,
            max_rounds=args.max_rounds,
            workers=args.workers,
            case_concurrency=args.case_concurrency,
            image=args.image,
            network=args.network,
            timeout_sec=args.timeout_sec,
            repair_client=repair_client,
        )
        print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if summary["success_count"] == summary["case_count"] else 1

    summary = run_file(
        source_path=args.source,
        out_dir=args.out,
        max_rounds=args.max_rounds,
        workers=args.workers,
        scene_names=args.scene,
        image=args.image,
        network=args.network,
        timeout_sec=args.timeout_sec,
        repair_client=repair_client,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if summary["final_status"] == "all_scenes_render_ok" else 1
def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pre_render_slice_fast_repair.py",
        description="Repair only failed slices until every Scene renders or max rounds is reached.",
    )
    parser.add_argument("--source")
    parser.add_argument("--pool", help="selected_cases.json with generate_stream source paths")
    parser.add_argument("--out", required=True)
    parser.add_argument("--scene", action="append", help="Limit to specific Scene; repeatable")
    parser.add_argument("--max-rounds", type=int, default=3)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--case-concurrency", type=int, default=1)
    parser.add_argument("--self-test", action="store_true", help="Run built-in fake render/repair harness test")
    parser.add_argument("--image")
    parser.add_argument("--network")
    parser.add_argument("--timeout-sec", type=int)
    parser.add_argument("--base-url", help="OpenAI-compatible base URL; env PRERENDER_LLM_BASE_URL")
    parser.add_argument("--model", help="Google/Gemini model; env PRERENDER_LLM_MODEL")
    parser.add_argument("--llm-timeout-sec", type=int, default=240)
    parser.add_argument("--allow-non-google-model", action="store_true")
    return parser

