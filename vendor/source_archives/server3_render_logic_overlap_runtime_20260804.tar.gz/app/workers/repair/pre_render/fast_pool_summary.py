"""Fast pre-render 批次汇总统计。"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
from typing import Any, Callable


def pool_summary(results: list[dict[str, Any]], *, pool_path: Path, out_dir: Path, duration_sec: float, rate: Callable[[int, int], float]) -> dict[str, Any]:
    by_status = Counter(str(item.get("final_status") or "unknown") for item in results)
    success_count = by_status.get("all_scenes_render_ok", 0)
    case_count = len(results)
    failed_cases = [{"case_id": item.get("case_id"), "final_status": item.get("final_status"), "failed_scenes": item.get("failed_scenes") or [], "case_out": item.get("case_out")} for item in results if item.get("final_status") != "all_scenes_render_ok"]
    llm_calls = [int(item.get("llm_call_count") or 0) for item in results]
    rejected = [int(item.get("rejected_repair_count") or 0) for item in results]
    return {"pool_path": str(pool_path), "out_dir": str(out_dir), "case_count": case_count, "success_count": success_count, "success_rate": rate(success_count, case_count), "by_status": dict(sorted(by_status.items())), "failed_cases": failed_cases, "total_scene_count": sum(int(item.get("scene_count") or 0) for item in results), "render_ok_scene_count": sum(int(item.get("render_ok_count") or 0) for item in results), "total_llm_calls": sum(llm_calls), "avg_llm_calls_per_case": round(sum(llm_calls) / case_count, 4) if case_count else 0.0, "max_llm_calls_per_case": max(llm_calls) if llm_calls else 0, "total_rejected_repair_count": sum(rejected), "max_rejected_repair_count_per_case": max(rejected) if rejected else 0, "duration_sec": round(duration_sec, 3)}


def pool_summary_markdown(summary: Mapping[str, Any], results: list[dict[str, Any]]) -> str:
    status_rows = "\n".join(f"| `{status}` | {count} |" for status, count in dict(summary.get("by_status") or {}).items()) or "| none | 0 |"
    case_rows = "\n".join(f"| `{item.get('case_id')}` | `{item.get('final_status')}` | {item.get('render_ok_count')}/{item.get('scene_count')} | {item.get('llm_call_count')} | `{', '.join(item.get('failed_scenes') or [])}` |" for item in results) or "| none | none | 0/0 | 0 |  |"
    return "\n".join(["# Pre-render Slice Fast Repair Batch", "", f"- cases: `{summary.get('case_count')}`", f"- success: `{summary.get('success_count')}`", f"- success_rate: `{summary.get('success_rate')}`", f"- total_llm_calls: `{summary.get('total_llm_calls')}`", f"- max_llm_calls_per_case: `{summary.get('max_llm_calls_per_case')}`", "", "## Status", "", "| status | count |", "|---|---:|", status_rows, "", "## Cases", "", "| case | status | scenes | llm_calls | failed_scenes |", "|---|---|---:|---:|---|", case_rows, ""])
