"""Production per-scene render-before-repair loop for generate_stream code."""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Mapping
from app.workers.repair.pre_render.fast_pool_summary import pool_summary, pool_summary_markdown
from app.workers.repair.pre_render.pool_case_loader import load_pool_cases
from app.workers.repair.pre_render.fast_render_llm import (
    openai_protocol_repair_client as _openai_protocol_repair_client,
    _chat_completions_url,
    stream_delta_content as _stream_delta_content,
)
from app.workers.repair.pre_render.fast_render_validation import (
    missing_base_name as _missing_base_name,
    scene_base_reference_errors as _scene_base_reference_errors,
    validate_repair_candidate as _validate_repair_candidate,
)


from app.repair_lab.video_render import _scene_class_names, run_manim_docker_render


RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
CaseRunner = Callable[..., Mapping[str, Any]]



from . import fast_render_runner_cases as _cases
globals().update({k: v for k, v in vars(_cases).items() if k not in {"__builtins__"}})
from .fast_render_runner_render import _run_pool_case

def run_pool(
    *,
    pool_path: str | Path,
    out_dir: str | Path,
    max_rounds: int = 3,
    workers: int = 4,
    case_concurrency: int = 1,
    image: str | None = None,
    network: str | None = None,
    timeout_sec: int | None = None,
    render_fn: RenderFn = run_manim_docker_render,
    repair_client: RepairClient | None = None,
    case_runner: CaseRunner | None = None,
) -> dict[str, Any]:
    started = time.monotonic()
    pool = Path(pool_path)
    root = Path(out_dir)
    root.mkdir(parents=True, exist_ok=True)
    cases = _load_pool_cases(pool)
    run_case = case_runner or _run_pool_case
    max_case_workers = max(1, int(case_concurrency or 1))

    def invoke(case: Mapping[str, Any]) -> dict[str, Any]:
        case_id = str(case["case_id"])
        case_out = root / "cases" / _safe_path_name(case_id)
        try:
            result = dict(
                run_case(
                    case_id=case_id,
                    source_path=case["source_path"],
                    out_dir=case_out,
                    max_rounds=max_rounds,
                    workers=workers,
                    scene_names=case.get("scene_names"),
                    image=image,
                    network=network,
                    timeout_sec=timeout_sec,
                    render_fn=render_fn,
                    repair_client=repair_client,
                ),
            )
        except Exception as exc:  # noqa: BLE001 - batch runs must keep other cases moving.
            case_out.mkdir(parents=True, exist_ok=True)
            result = {
                "final_status": "tool_error",
                "source_path": str(case["source_path"]),
                "final_path": "",
                "scene_count": 0,
                "render_ok_count": 0,
                "failed_scenes": [],
                "llm_call_count": 0,
                "max_rounds": max_rounds,
                "duration_sec": 0.0,
                "errors": [f"tool_error:{type(exc).__name__}:{exc}"],
            }
            _write_json(case_out / "summary.json", result)
        result.setdefault("case_id", case_id)
        result.setdefault("source_path", str(case["source_path"]))
        result["case_id"] = case_id
        result["case_out"] = str(case_out)
        result["scene_names_requested"] = list(case.get("scene_names") or [])
        return result

    if max_case_workers == 1:
        results = [invoke(case) for case in cases]
    else:
        by_index: dict[int, dict[str, Any]] = {}
        with ThreadPoolExecutor(max_workers=max_case_workers) as pool_executor:
            future_map = {
                pool_executor.submit(invoke, case): index
                for index, case in enumerate(cases)
            }
            for future in as_completed(future_map):
                by_index[future_map[future]] = future.result()
        results = [by_index[index] for index in range(len(cases))]

    summary = _pool_summary(
        results,
        pool_path=pool,
        out_dir=root,
        duration_sec=time.monotonic() - started,
    )
    _write_json(root / "batch_results.json", {"summary": summary, "results": results})
    (root / "SUMMARY.md").write_text(_pool_summary_markdown(summary, results), encoding="utf-8")
    return summary
def run_self_test(
    out_dir: str | Path,
    *,
    max_rounds: int = 3,
    workers: int = 1,
) -> dict[str, Any]:
    root = Path(out_dir)
    sources_dir = root / "self_test_sources"
    sources_dir.mkdir(parents=True, exist_ok=True)
    cases = _write_self_test_sources(sources_dir)
    pool_path = root / "self_test_pool.json"
    _write_json(
        pool_path,
        {
            "schema_version": "pre_render_fast_repair_pool.v1",
            "cases": cases,
        },
    )
    summary = run_pool(
        pool_path=pool_path,
        out_dir=root,
        max_rounds=max_rounds,
        workers=workers,
        case_concurrency=1,
        render_fn=_self_test_render,
        repair_client=_self_test_repair_client,
    )
    summary["self_test"] = True
    payload_path = root / "batch_results.json"
    payload = _read_json(payload_path)
    payload["summary"] = summary
    _write_json(payload_path, payload)
    return summary

