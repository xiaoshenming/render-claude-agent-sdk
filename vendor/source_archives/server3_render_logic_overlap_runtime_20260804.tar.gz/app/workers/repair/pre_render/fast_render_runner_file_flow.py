"""Production per-scene render-before-repair loop for generate_stream code."""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Mapping
from app.workers.repair.pre_render.fast_pool_summary import pool_summary, pool_summary_markdown
from app.workers.repair.pre_render.pool_case_loader import load_pool_cases
from app.workers.repair.pre_render.fast_render_llm import (
    openai_protocol_repair_client as _openai_protocol_repair_client,
    _chat_completions_url,
    stream_delta_content as _stream_delta_content,
)
from app.workers.repair.pre_render.fast_render_validation import (
    missing_base_name as _missing_base_name,
    scene_base_reference_errors as _scene_base_reference_errors,
    validate_repair_candidate as _validate_repair_candidate,
)


from app.repair_lab.video_render import _scene_class_names, run_manim_docker_render


RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
CaseRunner = Callable[..., Mapping[str, Any]]



from . import fast_render_runner_cases as _cases
globals().update({k: v for k, v in vars(_cases).items() if k not in {"__builtins__"}})
from .fast_render_runner_render import _render_all, _render_scene

def run_file(
    *,
    source_path: str | Path,
    out_dir: str | Path,
    max_rounds: int = 3,
    workers: int = 4,
    scene_names: list[str] | None = None,
    image: str | None = None,
    network: str | None = None,
    timeout_sec: int | None = None,
    render_fn: RenderFn = run_manim_docker_render,
    repair_client: RepairClient | None = None,
) -> dict[str, Any]:
    started = time.monotonic()
    source = Path(source_path)
    root = Path(out_dir)
    root.mkdir(parents=True, exist_ok=True)
    input_dir = root / "input"
    input_dir.mkdir(exist_ok=True)
    current_path = root / "current.py"
    current_code = source.read_text(encoding="utf-8", errors="ignore")
    current_path.write_text(current_code, encoding="utf-8")
    (input_dir / "source.py").write_text(current_code, encoding="utf-8")

    scenes = scene_names or _scene_class_names(current_code)
    if not scenes:
        summary = {
            "final_status": "no_scenes_found",
            "source_path": str(source),
            "scene_count": 0,
            "render_ok_count": 0,
            "failed_scenes": [],
            "llm_call_count": 0,
            "duration_sec": round(time.monotonic() - started, 3),
        }
        _write_json(root / "summary.json", summary)
        return summary

    repair_client = repair_client or _missing_repair_client
    max_rounds = max(0, int(max_rounds))
    llm_call_count = 0
    rejected_repair_count = 0
    rejected_repair_reasons: list[str] = []
    validation_feedback: list[str] = []
    repair_log: list[dict[str, Any]] = []
    round_log: list[dict[str, Any]] = []
    final_checks: dict[str, dict[str, Any]] = {}
    terminal_failure_status = ""
    non_repairable_errors: list[str] = []

    for round_index in range(0, max_rounds + 1):
        checks = _render_all(
            source_path=current_path,
            scene_names=scenes,
            out_dir=root / "checks" / f"round_{round_index:02d}",
            workers=workers,
            image=image,
            network=network,
            timeout_sec=timeout_sec,
            render_fn=render_fn,
        )
        final_checks = checks
        failures = [
            {
                "scene_name": scene,
                "error_summary": _error_summary(checks[scene]),
            }
            for scene in scenes
            if not checks[scene]["render_ok"]
        ]
        round_log.append(
            {
                "round_index": round_index,
                "render_ok_count": len(scenes) - len(failures),
                "failed_scenes": [failure["scene_name"] for failure in failures],
            },
        )
        if not failures or round_index >= max_rounds:
            break

        non_repairable_failures = [
            failure
            for failure in failures
            if _is_non_repairable_render_failure(failure["error_summary"])
        ]
        if non_repairable_failures:
            terminal_failure_status = "non_repairable_render_probe_error"
            non_repairable_errors = _dedupe(
                failure["error_summary"]
                for failure in non_repairable_failures
            )
            repair_log.append(
                {
                    "round_index": round_index + 1,
                    "accepted": False,
                    "skipped": True,
                    "skip_reason": terminal_failure_status,
                    "failed_scenes": [failure["scene_name"] for failure in failures],
                    "failures": failures,
                    "non_repairable_errors": non_repairable_errors,
                },
            )
            break

        repair_dir = root / "repairs" / f"round_{round_index + 1:02d}"
        repair_dir.mkdir(parents=True, exist_ok=True)
        before = current_path.read_text(encoding="utf-8")
        (repair_dir / "before.py").write_text(before, encoding="utf-8")
        _write_json(
            repair_dir / "repair_request.json",
            {
                "round_index": round_index + 1,
                "failures": failures,
                "validation_feedback": validation_feedback,
            },
        )

        try:
            llm_call_count += 1
            fixed = extract_code(
                repair_client(
                    source=before,
                    failures=failures,
                    validation_feedback=validation_feedback,
                    round_index=round_index + 1,
                    max_rounds=max_rounds,
                ),
            )
            validation_errors = _validate_repair_candidate(
                fixed,
                required_scene_names=scenes,
            )
        except Exception as exc:  # noqa: BLE001 - retry provider/transient repair failures.
            fixed = before
            validation_errors = [f"repair_client_error:{type(exc).__name__}:{exc}"]

        (repair_dir / "after.py").write_text(fixed, encoding="utf-8")
        if validation_errors:
            rejected_repair_count += 1
            rejected_repair_reasons.extend(validation_errors)
            validation_feedback = [
                error
                if error.startswith("repair_client_error:")
                else f"repair_response_rejected:{error}"
                for error in validation_errors
            ]
            _write_json(
                repair_dir / "repair_validation.json",
                {
                    "accepted": False,
                    "errors": validation_errors,
                },
            )
            repair_log.append(
                {
                    "round_index": round_index + 1,
                    "accepted": False,
                    "failed_scenes": [failure["scene_name"] for failure in failures],
                    "failures": failures,
                    "validation_errors": validation_errors,
                    "before": str(repair_dir / "before.py"),
                    "after": str(repair_dir / "after.py"),
                },
            )
            continue

        validation_feedback = []
        _write_json(
            repair_dir / "repair_validation.json",
            {
                "accepted": True,
                "errors": [],
            },
        )
        current_path.write_text(fixed, encoding="utf-8")
        repair_log.append(
            {
                "round_index": round_index + 1,
                "accepted": True,
                "failed_scenes": [failure["scene_name"] for failure in failures],
                "failures": failures,
                "before": str(repair_dir / "before.py"),
                "after": str(repair_dir / "after.py"),
            },
        )

    failed_scenes = [scene for scene, check in final_checks.items() if not check["render_ok"]]
    final_path = root / "final.py"
    final_path.write_text(current_path.read_text(encoding="utf-8"), encoding="utf-8")
    per_scene_rows = [
        {
            "scene_name": scene,
            "final_render_ok": final_checks[scene]["render_ok"],
            "final_check": final_checks[scene],
        }
        for scene in scenes
    ]
    (root / "per_scene_results.jsonl").write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in per_scene_rows),
        encoding="utf-8",
    )
    _write_json(root / "repair_log.json", {"rounds": round_log, "repairs": repair_log})
    final_scene_mp4_paths = {
        scene: str(final_checks[scene].get("mp4") or "")
        for scene in scenes
        if final_checks[scene].get("render_ok") and final_checks[scene].get("mp4")
    }
    summary = {
        "final_status": (
            "all_scenes_render_ok"
            if not failed_scenes
            else terminal_failure_status or "render_failed_after_max_rounds"
        ),
        "source_path": str(source),
        "final_path": str(final_path),
        "scene_count": len(scenes),
        "render_ok_count": len(scenes) - len(failed_scenes),
        "failed_scenes": failed_scenes,
        "llm_call_count": llm_call_count,
        "repair_round_count": llm_call_count,
        "render_round_count": len(round_log),
        "rejected_repair_count": rejected_repair_count,
        "rejected_repair_reasons": _dedupe(rejected_repair_reasons),
        "non_repairable_errors": non_repairable_errors,
        "final_scene_mp4_paths": final_scene_mp4_paths,
        "per_scene_results_path": str(root / "per_scene_results.jsonl"),
        "max_rounds": max_rounds,
        "duration_sec": round(time.monotonic() - started, 3),
    }
    _write_json(root / "summary.json", summary)
    return summary

