"""Runtime helper closure for generated undefined symbol calls.

Generated Manim code often invents small helper functions and then forgets to
emit their definitions. This module repairs that class by adding executable
fallback helpers before container render. It is intentionally repair-first:
the generated scene keeps its structure, while missing helper calls become
safe, renderable primitives.
"""

from __future__ import annotations

import ast
import builtins
import re
from dataclasses import dataclass, field
from typing import Optional

try:
    from app.workers.repair.static_guard import _COMMON_ALLOWED_NAMES
except Exception:  # pragma: no cover - import-time safety for isolated tools
    _COMMON_ALLOWED_NAMES = set()


_KNOWN_LOWER_MANIM_NAMES = {
    "always_redraw",
    "angle_of_vector",
    "color_gradient",
    "interpolate",
    "interpolate_color",
    "linear",
    "smooth",
    "there_and_back",
    "there_and_back_with_pause",
    "rush_from",
    "rush_into",
    "wiggle",
}

_PROJECT_CONTRACT_HELPERS = {
    "add_title",
    "clamp_to_canvas",
    "fit_to_canvas",
    "inline_math_text",
    "layout_canvas",
    "make_title",
    "narrate",
    "place_non_overlapping",
    "play_voiceover",
    "safe_math_box",
    "safe_text_box",
    "setup_layout",
    "wait_until_bookmark",
}

_IGNORED_HELPER_NAMES = (
    set(dir(builtins))
    | set(_COMMON_ALLOWED_NAMES)
    | _KNOWN_LOWER_MANIM_NAMES
    | _PROJECT_CONTRACT_HELPERS
)

_VERTICAL_DIVISION_HELPER_NAMES = {
    "create_division_grid",
    "create_division_layout",
    "create_division_mobject",
    "create_long_division",
    "make_division_layout",
}
_VERTICAL_DIVISION_CLASS_NAMES = {"VerticalDivision"}


@dataclass

class _MissingCall:
    name: str
    unpack_count: int = 0
    contexts: set[str] = field(default_factory=set)
    assigned_names: set[str] = field(default_factory=set)
def inject_undefined_symbol_runtime_helpers(code: str) -> tuple[Optional[str], str]:
    """Inject executable helpers for undefined lower_snake_case call names."""
    if not code or "(" not in code:
        return None, ""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, ""

    defined = _collect_defined_names(tree)
    calls = _collect_missing_calls(tree, defined)
    if not calls:
        return None, ""

    helper_lines = _runtime_support_lines(calls)
    if not helper_lines:
        return None, ""
    if "import numpy as np" not in code:
        helper_lines.insert(0, "import numpy as np")
        helper_lines.insert(1, "")

    lines = code.splitlines()
    insert_at = _helper_insert_position(code)
    if insert_at > 0 and lines[insert_at - 1].strip():
        helper_lines.insert(0, "")
    lines[insert_at:insert_at] = helper_lines
    fixed = "\n".join(lines) + ("\n" if code.endswith("\n") else "")
    names = ",".join(sorted(calls))
    return fixed, f"未定义符号运行期helper补全: {names}"
def _collect_defined_names(tree: ast.AST) -> set[str]:
    defined: set[str] = {"self", "cls"}

    class Visitor(ast.NodeVisitor):
        def visit_Import(self, node: ast.Import) -> None:
            for alias in node.names:
                defined.add(alias.asname or alias.name.split(".", 1)[0])

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            for alias in node.names:
                if alias.name != "*":
                    defined.add(alias.asname or alias.name)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            defined.add(node.name)
            self._visit_args(node.args)
            for child in node.body:
                self.visit(child)

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self.visit_FunctionDef(node)

        def visit_Lambda(self, node: ast.Lambda) -> None:
            self._visit_args(node.args)
            self.visit(node.body)

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            defined.add(node.name)
            for child in node.body:
                self.visit(child)

        def visit_For(self, node: ast.For) -> None:
            for name in _target_names(node.target):
                defined.add(name)
            self.visit(node.iter)
            for child in node.body + node.orelse:
                self.visit(child)

        def visit_With(self, node: ast.With) -> None:
            for item in node.items:
                self.visit(item.context_expr)
                if item.optional_vars is not None:
                    for name in _target_names(item.optional_vars):
                        defined.add(name)
            for child in node.body:
                self.visit(child)

        def visit_Assign(self, node: ast.Assign) -> None:
            self.visit(node.value)
            for target in node.targets:
                for name in _target_names(target):
                    defined.add(name)

        def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
            if node.value is not None:
                self.visit(node.value)
            for name in _target_names(node.target):
                defined.add(name)

        def visit_AugAssign(self, node: ast.AugAssign) -> None:
            self.visit(node.value)
            for name in _target_names(node.target):
                defined.add(name)

        def visit_NamedExpr(self, node: ast.NamedExpr) -> None:
            self.visit(node.value)
            for name in _target_names(node.target):
                defined.add(name)

        def _visit_args(self, args: ast.arguments) -> None:
            for arg in (
                list(args.posonlyargs)
                + list(args.args)
                + list(args.kwonlyargs)
            ):
                defined.add(arg.arg)
            if args.vararg is not None:
                defined.add(args.vararg.arg)
            if args.kwarg is not None:
                defined.add(args.kwarg.arg)

    Visitor().visit(tree)
    return defined
def _target_names(target: ast.AST) -> list[str]:
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        names: list[str] = []
        for item in target.elts:
            names.extend(_target_names(item.value if isinstance(item, ast.Starred) else item))
        return names
    return []
def _collect_missing_calls(tree: ast.AST, defined: set[str]) -> dict[str, _MissingCall]:
    parent: dict[ast.AST, ast.AST] = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parent[child] = node

    missing: dict[str, _MissingCall] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name):
            continue
        name = node.func.id
        if not _is_repairable_missing_call(name, defined):
            continue
        item = missing.setdefault(name, _MissingCall(name=name))
        item.contexts.update(_call_contexts(node, parent))
        item.assigned_names.update(_assignment_target_names(node, parent))
        unpack_count = _assignment_unpack_count(node, parent)
        if unpack_count:
            item.unpack_count = max(item.unpack_count, unpack_count)
    subscripted_names = _subscripted_name_values(tree)
    for item in missing.values():
        if item.assigned_names & subscripted_names:
            item.contexts.add("subscript")
    return missing
def _is_repairable_missing_call(name: str, defined: set[str]) -> bool:
    if name in defined or name in _IGNORED_HELPER_NAMES:
        return False
    if name in _VERTICAL_DIVISION_CLASS_NAMES:
        return True
    if name.startswith("__") and name.endswith("__"):
        return False
    if not re.fullmatch(r"[a-z][A-Za-z0-9_]*", name):
        return False
    return "_" in name or name.startswith(("make", "build", "create", "draw", "get", "calc", "compute"))
def _assignment_unpack_count(node: ast.Call, parent: dict[ast.AST, ast.AST]) -> int:
    current: ast.AST = node
    while current in parent:
        owner = parent[current]
        if isinstance(owner, ast.Assign) and current is owner.value:
            for target in owner.targets:
                if isinstance(target, (ast.Tuple, ast.List)):
                    return len(target.elts)
            return 0
        current = owner
    return 0
def _assignment_target_names(node: ast.Call, parent: dict[ast.AST, ast.AST]) -> set[str]:
    current: ast.AST = node
    while current in parent:
        owner = parent[current]
        if isinstance(owner, ast.Assign) and current is owner.value:
            names: set[str] = set()
            for target in owner.targets:
                names.update(_target_names(target))
            return names
        if isinstance(owner, ast.AnnAssign) and current is owner.value:
            return set(_target_names(owner.target))
        current = owner
    return set()
def _subscripted_name_values(tree: ast.AST) -> set[str]:
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name):
            names.add(node.value.id)
    return names
def _call_contexts(node: ast.Call, parent: dict[ast.AST, ast.AST]) -> set[str]:
    contexts: set[str] = set()
    current: ast.AST = node
    for _ in range(4):
        owner = parent.get(current)
        if owner is None:
            break
        if isinstance(owner, ast.Call):
            callee = _call_name(owner.func)
            if callee:
                contexts.add(f"arg:{callee}")
        elif isinstance(owner, ast.Assign):
            for target in owner.targets:
                if isinstance(target, (ast.Tuple, ast.List)):
                    contexts.add("tuple_unpack")
        current = owner
    return contexts
def _call_name(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""

