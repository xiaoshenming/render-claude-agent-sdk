"""快速预渲染候选代码的语法与 Scene 继承合同校验。"""

from __future__ import annotations

import ast

from app.repair_lab.video_render import _scene_class_names


def validate_repair_candidate(source: str, *, required_scene_names: list[str]) -> list[str]:
    text = source or ""
    if not text.strip():
        return ["empty_repair_response"]
    try:
        tree = ast.parse(text)
    except SyntaxError as exc:
        location = f"line {exc.lineno}" if exc.lineno else "unknown line"
        return [f"syntax_error:{exc.msg} ({location})"]
    scene_names = set(_scene_class_names(text))
    missing = [scene for scene in required_scene_names if scene not in scene_names]
    if missing:
        return [f"missing_scene_classes:{','.join(missing)}"]
    return scene_base_reference_errors(tree, required_scene_names)


def scene_base_reference_errors(tree: ast.AST, required_scene_names: list[str]) -> list[str]:
    defined_names: set[str] = set()
    imported_names: set[str] = set()
    has_manim_star_import = False
    class_nodes: dict[str, ast.ClassDef] = {}
    for node in getattr(tree, "body", []):
        if isinstance(node, ast.ClassDef):
            defined_names.add(node.name)
            class_nodes[node.name] = node
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            defined_names.add(node.name)
        elif isinstance(node, ast.Import):
            imported_names.update(alias.asname or alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.module == "manim" and any(alias.name == "*" for alias in node.names):
                has_manim_star_import = True
            imported_names.update(alias.asname or alias.name for alias in node.names if alias.name != "*")
        elif isinstance(node, ast.Assign):
            defined_names.update(target.id for target in node.targets if isinstance(target, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            defined_names.add(node.target.id)
    errors: list[str] = []
    for scene_name in required_scene_names:
        node = class_nodes.get(scene_name)
        if not node:
            continue
        for base in node.bases:
            missing = missing_base_name(base, defined_names=defined_names, imported_names=imported_names, has_manim_star_import=has_manim_star_import)
            if missing:
                errors.append(f"undefined_scene_base:{scene_name}:{missing}")
    return errors


def missing_base_name(base: ast.expr, *, defined_names: set[str], imported_names: set[str], has_manim_star_import: bool) -> str:
    if isinstance(base, ast.Name):
        name = base.id
        return "" if name in defined_names or name in imported_names or has_manim_star_import else name
    if isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name):
        owner = base.value.id
        return "" if owner in imported_names else owner
    return ""
