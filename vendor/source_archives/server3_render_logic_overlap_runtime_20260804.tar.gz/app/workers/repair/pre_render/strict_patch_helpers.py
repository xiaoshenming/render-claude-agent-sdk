"""Strict block patch application helpers."""
from __future__ import annotations
import re
from typing import Any, Mapping, Sequence
from app.quality_repair.repair.patch_applier import PatchApplier, _helper_bounds, _line_bounds_to_offsets

class _RejectedRepair(Exception):
    def __init__(self, reasons: list[str], metadata: dict[str, Any] | None = None):
        super().__init__(";".join(reasons))
        self.reasons = reasons
        self.metadata = metadata or {}

def _direct_helpers(source: str, scene_name: str) -> list[str]:
    from app.workers.repair.pre_render.strict_block_repair import _direct_helpers as fn
    return fn(source, scene_name)

def _function_source(source: str, helper_name: str) -> str:
    from app.workers.repair.pre_render.strict_block_repair import _function_source as fn
    return fn(source, helper_name)

def _common_root_failure_context(
    *,
    source: str,
    scene_names: Sequence[str],
    failures: Sequence[Mapping[str, Any]],
) -> dict[str, Any] | None:
    failed_scene_names = [str(failure.get("scene_name") or "") for failure in failures]
    if len(scene_names) < 2 or len(failed_scene_names) != len(scene_names):
        return None
    if set(failed_scene_names) != {str(scene) for scene in scene_names}:
        return None

    helper_sets: list[set[str]] = []
    for scene_name in failed_scene_names:
        helper_sets.append(set(_direct_helpers(source, scene_name)))
    common_helpers = sorted(set.intersection(*helper_sets)) if helper_sets else []
    common_sources = {
        helper_name: _function_source(source, helper_name)
        for helper_name in common_helpers
        if _function_source(source, helper_name)
    }
    if not common_sources:
        return None
    signature = _common_error_signature(failures)

    return {
        "repair_scope": "common_root",
        "failed_scene_count": len(failed_scene_names),
        "scene_names": failed_scene_names,
        "common_error_signature": signature,
        "common_helper_names": list(common_sources),
        "common_source": "\n\n".join(common_sources.values()),
        "shared_failures": [dict(failure) for failure in failures],
        "guidance": (
            "All requested scenes failed in the same pre-render probe. Prefer one "
            "shared helper/header/import contract patch over repeating equivalent "
            "patches for every scene."
        ),
    }


def _common_error_signature(failures: Sequence[Mapping[str, Any]]) -> str:
    normalized: list[str] = []
    for failure in failures:
        text = str(failure.get("error_summary") or "")
        text = re.sub(r"Scene_[A-Za-z0-9_]+", "Scene_*", text)
        text = re.sub(r"/[^\s:]+", "<path>", text)
        text = re.sub(r"line \d+", "line *", text, flags=re.I)
        text = text.strip()[:500]
        if text:
            normalized.append(text)
    if not normalized:
        return ""
    first = normalized[0]
    if all(item == first for item in normalized):
        return first
    return ""


def _apply_common_root_patches(
    *,
    source: str,
    scene_names: Sequence[str],
    context: Mapping[str, Any],
    payload: Mapping[str, Any],
) -> tuple[str, dict[str, Any]]:
    patches = payload.get("block_patches")
    if payload.get("repair_mode") != "block_patch" or not isinstance(patches, list):
        raise _RejectedRepair(["non_block_patch_response"])
    common_helpers = {str(name) for name in context.get("common_helper_names") or []}
    if not common_helpers:
        raise _RejectedRepair(["common_root_no_shared_helper_context"])

    candidate = source
    patched_helpers: list[str] = []
    patch_results: list[dict[str, Any]] = []
    for patch in patches:
        if not isinstance(patch, Mapping):
            raise _RejectedRepair(["block_patch_item_invalid"])
        target = str(patch.get("target") or "")
        if target not in {"shared_helper", "common_helper", "direct_helper"}:
            raise _RejectedRepair([f"unsupported_common_root_target:{target or 'missing'}"])
        helper_name = str(patch.get("helper_name") or "")
        if helper_name not in common_helpers:
            raise _RejectedRepair([f"common_helper_not_allowed:{helper_name or 'missing'}"])
        old_code = str(patch.get("old_code") or "")
        new_code = str(patch.get("new_code") or "")
        if not old_code:
            raise _RejectedRepair(["old_code_missing:common_root"])
        if new_code == old_code:
            raise _RejectedRepair(["new_code_unchanged:common_root"])
        candidate, applied = _replace_common_helper_block(
            candidate,
            helper_name=helper_name,
            old_code=old_code,
            new_code=new_code,
        )
        patch_results.append({
            "helper_name": helper_name,
            "applied": applied,
            "target": target,
            "reason": str(patch.get("reason") or ""),
        })
        patched_helpers.append(helper_name)

    return candidate, {
        "repair_scope": "common_root",
        "patched_scenes": [str(scene) for scene in scene_names],
        "patched_helpers": sorted(set(patched_helpers)),
        "patch_results": patch_results,
    }


def _replace_common_helper_block(
    source: str,
    *,
    helper_name: str,
    old_code: str,
    new_code: str,
) -> tuple[str, bool]:
    lines = source.splitlines(keepends=True)
    bounds_list = _helper_bounds(lines, helper_name, exclude_class_name="")
    if not bounds_list:
        raise _RejectedRepair([f"helper_not_found:{helper_name}"])
    if len(bounds_list) > 1:
        raise _RejectedRepair([f"helper_ambiguous:{helper_name}"])
    start, end = _line_bounds_to_offsets(lines, bounds_list[0])
    scoped_text = source[start:end]
    matches = [match.start() for match in re.finditer(re.escape(old_code), scoped_text)]
    if not matches:
        raise _RejectedRepair([f"old_code_not_found:common_root:{helper_name}"])
    if len(matches) > 1:
        raise _RejectedRepair([f"old_code_ambiguous:common_root:{helper_name}"])
    absolute_start = start + matches[0]
    absolute_end = absolute_start + len(old_code)
    return source[:absolute_start] + new_code + source[absolute_end:], True


def _apply_failure_scene_patches(
    *,
    source: str,
    failures: Sequence[Mapping[str, Any]],
    payload: Mapping[str, Any],
) -> tuple[str, dict[str, Any]]:
    patches = payload.get("block_patches")
    if payload.get("repair_mode") != "block_patch" or not isinstance(patches, list):
        raise _RejectedRepair(["non_block_patch_response"])
    failed_scenes = [str(failure["scene_name"]) for failure in failures]
    patches_by_scene: dict[str, list[Mapping[str, Any]]] = {scene: [] for scene in failed_scenes}
    for patch in patches:
        if not isinstance(patch, Mapping):
            raise _RejectedRepair(["block_patch_item_invalid"])
        scene_name = str(patch.get("scene_name") or patch.get("target_scene") or "")
        if not scene_name:
            if len(failed_scenes) == 1:
                scene_name = failed_scenes[0]
            else:
                raise _RejectedRepair(["block_patch_scene_missing"])
        if scene_name not in patches_by_scene:
            raise _RejectedRepair([f"block_patch_scene_not_failed:{scene_name}"])
        patches_by_scene[scene_name].append(patch)

    missing = [scene for scene, scene_patches in patches_by_scene.items() if not scene_patches]
    if missing:
        raise _RejectedRepair([f"missing_patch_for_scene:{','.join(missing)}"])

    candidate = source
    patched_scenes: list[str] = []
    patched_helpers: list[str] = []
    patch_results: dict[str, Any] = {}
    applier = PatchApplier()
    for scene_name in failed_scenes:
        allowed_helpers = _direct_helpers(candidate, scene_name)
        result = applier.apply(
            original_code=candidate,
            target_scene=scene_name,
            llm_payload={
                "repair_mode": "block_patch",
                "block_patches": patches_by_scene[scene_name],
            },
            allowed_helper_names=allowed_helpers,
            issue_ids=[f"pre_render_failure:{scene_name}"],
            patch_summary="strict pre-render block patch",
            code_ref=f"strict-pre-render:{scene_name}",
        )
        patch_results[scene_name] = result.to_dict()
        if not result.ok or not result.repaired_code:
            reasons = [
                violation.code
                for violation in (result.violations or [])
                if getattr(violation, "code", "")
            ]
            raise _RejectedRepair(
                reasons or [f"block_patch_failed:{scene_name}"],
                metadata={"patch_results": patch_results},
            )
        candidate = result.repaired_code
        if result.candidate:
            patched_scenes.extend(result.candidate.changed_scenes)
            patched_helpers.extend(result.candidate.changed_helpers)

    return candidate, {
        "patched_scenes": sorted(set(patched_scenes or failed_scenes)),
        "patched_helpers": sorted(set(patched_helpers)),
        "patch_results": patch_results,
    }


