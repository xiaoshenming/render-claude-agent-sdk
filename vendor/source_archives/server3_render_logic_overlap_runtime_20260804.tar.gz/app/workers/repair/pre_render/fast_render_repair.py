"""Production adapter for the fast render-before-repair lab loop.

This module keeps the expensive Docker/LLM pre-render loop out of the legacy
deterministic ``pre_render_scan`` facade.  Callers opt in at the single point
where code is about to be rendered for real.
"""

from __future__ import annotations

import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

from app.workers.repair.pre_render import fast_render_runner, strict_block_repair


RepairRunner = Callable[..., Mapping[str, Any]]


@dataclass(slots=True)
class FastPreRenderRepairConfig:
    enabled: bool = False
    strategy: str = "strict_block_patch"
    max_rounds: int = 3
    workers: int = 4
    scene_timeout_sec: int | None = 180
    llm_timeout_sec: int = 600
    model: str = ""
    api_base: str = ""
    api_key: str = ""
    allow_non_google_model: bool = False
    image: str | None = None
    network: str | None = None
    backend_fallbacks: list[Mapping[str, Any]] = field(default_factory=list)
    runner_extra: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class FastPreRenderRepairResult:
    render_ok: bool
    changed: bool
    final_code: str
    artifact_dir: str
    summary: dict[str, Any]
    error: str = ""

    def metadata(self) -> dict[str, Any]:
        return {
            "render_ok": self.render_ok,
            "changed": self.changed,
            "artifact_dir": self.artifact_dir,
            "error": self.error,
            "summary": self.summary,
        }


def run_fast_pre_render_repair_on_code(
    *,
    code: str,
    scene_names: list[str] | None,
    artifact_root: str | Path,
    job_id: str,
    config: FastPreRenderRepairConfig,
    repair_runner: RepairRunner | None = None,
) -> FastPreRenderRepairResult:
    """Run the three-round real-render pre-repair loop for a code string.

    A failed or disabled run never mutates the code.  It returns structured
    evidence so the caller can fall back to the existing render path.
    """
    artifact_dir = Path(artifact_root) / _safe_path_name(job_id or "unknown-job")
    artifact_dir.mkdir(parents=True, exist_ok=True)
    if not config.enabled:
        return FastPreRenderRepairResult(
            render_ok=False,
            changed=False,
            final_code=code,
            artifact_dir=str(artifact_dir),
            summary={"final_status": "disabled"},
        )

    _archive_stale_run_dir(artifact_dir / "run")
    source_path = artifact_dir / "source.py"
    source_path.write_text(code, encoding="utf-8")
    try:
        runner = repair_runner or _default_production_runner(config)
        summary = dict(
            runner(
                source_path=source_path,
                out_dir=artifact_dir / "run",
                max_rounds=max(0, int(config.max_rounds or 0)),
                workers=max(1, int(config.workers or 1)),
                scene_names=list(scene_names or []) or None,
                timeout_sec=config.scene_timeout_sec,
                image=config.image,
                network=config.network,
                **dict(config.runner_extra or {}),
            ),
        )
    except (Exception, SystemExit) as exc:  # noqa: BLE001 - adapter must fail open.
        return FastPreRenderRepairResult(
            render_ok=False,
            changed=False,
            final_code=code,
            artifact_dir=str(artifact_dir),
            summary={"final_status": "tool_error"},
            error=f"{type(exc).__name__}:{exc}",
        )

    final_code = code
    final_path = str(summary.get("final_path") or "")
    if final_path:
        try:
            final_code = Path(final_path).read_text(encoding="utf-8")
        except OSError as exc:
            summary.setdefault("adapter_errors", []).append(
                f"final_read_error:{type(exc).__name__}:{exc}"
            )
            final_code = code

    render_ok = summary.get("final_status") == "all_scenes_render_ok"
    changed = render_ok and final_code != code
    if not render_ok:
        final_code = code

    return FastPreRenderRepairResult(
        render_ok=render_ok,
        changed=changed,
        final_code=final_code,
        artifact_dir=str(artifact_dir),
        summary=summary,
    )


def _default_production_runner(config: FastPreRenderRepairConfig) -> RepairRunner:
    strategy = str(config.strategy or "").strip().lower()
    if strategy in {"strict_block_patch", "block_patch_strict", "line1_strict_block"}:
        repair_client = _fallback_openai_protocol_repair_client(
            config,
            strict=True,
        )

        def run(**kwargs: Any) -> Mapping[str, Any]:
            kwargs.setdefault("repair_client", repair_client)
            return strict_block_repair.run_file(**kwargs)

        return run

    repair_client = _fallback_openai_protocol_repair_client(
        config,
        strict=False,
    )

    def run(**kwargs: Any) -> Mapping[str, Any]:
        kwargs.setdefault("repair_client", repair_client)
        return fast_render_runner.run_file(**kwargs)

    return run


def _fallback_openai_protocol_repair_client(
    config: FastPreRenderRepairConfig,
    *,
    strict: bool,
) -> Callable[..., str]:
    """Create a repair client that tries configured FAST_PRE backends in order."""

    def _make_client(entry: Mapping[str, Any]) -> Callable[..., str]:
        base_url = str(entry.get("api_base") or "").strip()
        model = str(entry.get("model") or "").strip()
        api_key = str(entry.get("api_key") or "").strip()
        timeout_sec = max(1, int(config.llm_timeout_sec or 240))
        require_google = not bool(config.allow_non_google_model)
        if strict:
            return strict_block_repair.openai_protocol_block_patch_repair_client(
                base_url=base_url,
                model=model,
                api_key=api_key,
                timeout_sec=timeout_sec,
                require_google=require_google,
            )
        return fast_render_runner._openai_protocol_repair_client(
            base_url=base_url,
            model=model,
            api_key=api_key,
            timeout_sec=timeout_sec,
            require_google=require_google,
        )

    entries = _fast_pre_backend_entries(config)
    if not entries:
        raise RuntimeError("Missing FAST_PRE repair backend config")

    def repair_client(**kwargs: Any) -> str:
        errors: list[str] = []
        for entry in entries:
            name = str(entry.get("name") or entry.get("model") or "backend")
            try:
                return _make_client(entry)(**kwargs)
            except Exception as exc:  # noqa: BLE001 - provider fallback is the point here.
                errors.append(f"{name}:{type(exc).__name__}:{str(exc)[:500]}")
                continue
        joined = " | ".join(errors)[:1800]
        raise RuntimeError(f"all_fast_pre_repair_backends_failed:{joined}")

    return repair_client


def _fast_pre_backend_entries(
    config: FastPreRenderRepairConfig,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for raw_backend in list(config.backend_fallbacks or []):
        if not isinstance(raw_backend, Mapping):
            continue
        keys = raw_backend.get("keys") if isinstance(raw_backend.get("keys"), list) else []
        for key in keys:
            api_key = str(key or "").strip()
            if not api_key:
                continue
            model = str(raw_backend.get("model") or raw_backend.get("name") or "").strip()
            api_base = str(raw_backend.get("api_base") or "").strip()
            if not model or not api_base:
                continue
            entries.append({
                "name": raw_backend.get("name") or model,
                "model": model,
                "api_base": api_base,
                "api_key": api_key,
            })
    if entries:
        return entries
    model = config.model or os.environ.get("PRERENDER_LLM_MODEL", "")
    api_base = config.api_base or os.environ.get("PRERENDER_LLM_BASE_URL", "")
    api_key = config.api_key or os.environ.get("PRERENDER_LLM_API_KEY", "")
    if not model or not api_base or not api_key:
        return []
    return [{
        "name": config.model or "settings",
        "model": model,
        "api_base": api_base,
        "api_key": api_key,
    }]


def _safe_path_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip())
    return text[:120] or "item"


def _archive_stale_run_dir(run_dir: Path) -> None:
    """Keep each production fast-repair attempt isolated from stale evidence."""
    if not run_dir.exists():
        return
    history_dir = run_dir.parent / "history"
    history_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = history_dir / f"run_{stamp}_{os.getpid()}"
    index = 1
    while target.exists():
        index += 1
        target = history_dir / f"run_{stamp}_{os.getpid()}_{index}"
    try:
        shutil.move(str(run_dir), str(target))
    except FileNotFoundError:
        return
    except OSError:
        shutil.rmtree(run_dir, ignore_errors=True)
