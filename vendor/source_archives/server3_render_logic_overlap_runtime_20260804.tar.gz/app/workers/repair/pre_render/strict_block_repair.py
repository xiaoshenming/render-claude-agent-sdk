"""Strict block-patch pre-render repair facade."""
from __future__ import annotations
import json
import re
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence
from app.workers.repair.pre_render.strict_run_loop import run_file
from app.workers.repair.pre_render.strict_patch_helpers import (_RejectedRepair, _apply_common_root_patches, _apply_failure_scene_patches, _common_root_failure_context)
from app.workers.repair.pre_render.strict_contract_normalizers import normalize_render_contracts as _normalize_render_contracts
from app.workers.repair.pre_render.fast_render_runner import (_chat_completions_url, _stream_delta_content, _safe_path_name, _error_summary, _is_non_repairable_render_failure, _validate_repair_candidate)
from app.workers.repair.pre_render.strict_summary import build_summary
from app.workers.repair.pre_render.strict_repair_sources import direct_helpers as _direct_helpers, function_source as _function_source
from app.quality_repair.repair.patch_applier import PatchApplier
from app.repair_lab.video_render import run_manim_docker_render
RenderFn = Callable[..., Mapping[str, Any]]
RepairClient = Callable[..., str]
def openai_protocol_block_patch_repair_client(
    *,
    base_url: str,
    model: str,
    api_key: str,
    timeout_sec: int,
    require_google: bool,
) -> RepairClient:
    if not base_url:
        raise RuntimeError("Missing --base-url or PRERENDER_LLM_BASE_URL")
    if not model:
        raise RuntimeError("Missing --model or PRERENDER_LLM_MODEL")
    if not api_key:
        raise RuntimeError("Missing PRERENDER_LLM_API_KEY")
    identity = model.lower()
    if require_google and not any(token in identity for token in ("gemini", "google")):
        raise RuntimeError("Model must be a Google/Gemini model unless non-Google is allowed")
    url = _chat_completions_url(base_url)
    def repair_client(
        *,
        source: str,
        failures: list[dict[str, Any]],
        validation_feedback: list[str] | None = None,
        round_index: int,
        max_rounds: int,
    ) -> str:
        req = urllib.request.Request(
            url,
            data=json.dumps(
                {
                    "model": model,
                    "messages": [
                        {
                            "role": "user",
                            "content": _repair_prompt(
                                source=source,
                                failures=failures,
                                validation_feedback=validation_feedback or [],
                                round_index=round_index,
                                max_rounds=max_rounds,
                            ),
                        },
                    ],
                    "temperature": 0,
                    "max_tokens": 65536,
                    "stream": True,
                },
                ensure_ascii=False,
            ).encode("utf-8"),
            headers={
                "Authorization": "Bearer " + api_key,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        chunks: list[str] = []
        try:
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                while True:
                    line = resp.readline()
                    if not line:
                        break
                    item = line.decode("utf-8", "ignore").strip()
                    if not item or not item.startswith("data:"):
                        continue
                    data = item[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        obj = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    delta = _stream_delta_content(obj)
                    if delta:
                        chunks.append(str(delta))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", "ignore")[:500]
            raise RuntimeError(f"llm_http_error:{exc.code}:{body}") from exc
        if not chunks:
            raise RuntimeError("llm_empty_response")
        return "".join(chunks)
    return repair_client
def _render_selected(
    *,
    source_path: Path,
    scene_names: Sequence[str],
    out_dir: Path,
    workers: int,
    image: str | None,
    network: str | None,
    timeout_sec: int | None,
    render_fn: RenderFn,
) -> dict[str, dict[str, Any]]:
    max_workers = max(1, min(int(workers or 1), max(1, len(scene_names))))
    if max_workers == 1:
        return {
            scene: _render_scene(
                source_path=source_path,
                scene_name=scene,
                out_dir=out_dir / _safe_path_name(scene),
                image=image,
                network=network,
                timeout_sec=timeout_sec,
                render_fn=render_fn,
            )
            for scene in scene_names
        }
    results: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_map = {
            pool.submit(
                _render_scene,
                source_path=source_path,
                scene_name=scene,
                out_dir=out_dir / _safe_path_name(scene),
                image=image,
                network=network,
                timeout_sec=timeout_sec,
                render_fn=render_fn,
            ): scene
            for scene in scene_names
        }
        for future in as_completed(future_map):
            results[future_map[future]] = future.result()
    return {scene: results[scene] for scene in scene_names}
def _render_scene(
    *,
    source_path: Path,
    scene_name: str,
    out_dir: Path,
    image: str | None,
    network: str | None,
    timeout_sec: int | None,
    render_fn: RenderFn,
) -> dict[str, Any]:
    try:
        check = dict(
            render_fn(
                script_path=source_path,
                scene_name=scene_name,
                output_dir=out_dir,
                image=image,
                network=network,
                timeout_sec=timeout_sec,
            )
        )
    except Exception as exc:  # noqa: BLE001 - probe crashes become repair feedback.
        out_dir.mkdir(parents=True, exist_ok=True)
        return {
            "render_ok": False,
            "returncode": None,
            "mp4": "",
            "mp4_bytes": 0,
            "log": "",
            "errors": [f"render_probe_error:{type(exc).__name__}:{exc}"],
            "scene_name": scene_name,
        }
    check["scene_name"] = scene_name
    return {
        "render_ok": bool(check.get("render_ok")),
        "returncode": check.get("returncode"),
        "mp4": str(check.get("mp4") or ""),
        "mp4_bytes": int(check.get("mp4_bytes") or 0),
        "log": str(check.get("log") or ""),
        "check_json": str(check.get("check_json") or ""),
        "errors": [str(item) for item in check.get("errors", []) or []],
        "scene_name": scene_name,
    }
def _parse_block_patch_payload(response: str) -> Mapping[str, Any]:
    text = str(response or "").strip()
    fenced = re.search(r"```(?:json)?\s*(?P<body>.*?)```", text, flags=re.I | re.S)
    if fenced:
        text = fenced.group("body").strip()
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise _RejectedRepair([f"json_parse_error:{exc.msg}"]) from exc
    if not isinstance(payload, Mapping):
        raise _RejectedRepair(["json_payload_not_object"])
    forbidden = [
        key
        for key in (
            "candidate_code",
            "code",
            "full_code",
            "final_code",
            "target_scene_source",
            "scene_source",
            "target_scene_code",
        )
        if str(payload.get(key) or "").strip()
    ]
    if forbidden:
        raise _RejectedRepair(
            [f"forbidden_full_code_payload:{key}" for key in forbidden]
        )
    return payload
def _repair_prompt(
    *,
    source: str,
    failures: Sequence[Mapping[str, Any]],
    validation_feedback: Sequence[str],
    round_index: int,
    max_rounds: int,
) -> str:
    failure_text = json.dumps(failures, ensure_ascii=False, indent=2)
    feedback = "\n".join(f"- {item}" for item in validation_feedback)
    feedback_block = f"\n上一轮拒收原因:\n{feedback}\n" if feedback else ""
    return (
        "你是 MathPi Manim 局部代码修复器。只依据本消息提供的失败 Scene 源码、direct_helpers 和报错修复代码。\n"
        "目标：让失败 Scene 保留原教学意图并成功渲染。\n"
        "可编辑范围：失败 Scene 的 scene_source，以及该 Scene 在 direct_helpers 中列出的 helper。不要修改其他 Scene。\n"
        "缺少变量、函数、helper、字典 key 或 Manim API 参数错误时，请在可编辑范围内改调用、补局部变量，或补最小确定性的真实 helper 实现。\n"
        "不要依赖未提供的外部代码、后续修复步骤或隐藏兜底。不要使用 _mathpi_fallback_*、VGroup() 空对象、Text('fixed')/Text('placeholder') 等占位结果掩盖错误。\n"
        "不要删除数学对象来绕过错误；如果对象构造失败，要按当前 Scene 语义补真实坐标、真实 mobject、真实标签或正确参数。\n"
        "只返回 JSON：repair_mode 固定为 block_patch，block_patches 内每项必须有 scene_name、old_code、new_code、reason。\n"
        "old_code 必须逐字复制自 scene_source 或 direct_helpers 中的可编辑代码片段；new_code 是替换后的可运行片段。\n"
        f"修复轮次: {round_index}/{max_rounds}\n"
        f"{feedback_block}\n"
        "失败 Scene、报错、可编辑源码如下:\n"
        f"{failure_text}\n"
    )
def _update_ledger(
    ledger: dict[str, dict[str, Any]],
    checks: Mapping[str, Mapping[str, Any]],
) -> None:
    for scene, check in checks.items():
        ledger.setdefault(scene, {"scene_name": scene})
        ledger[scene].update(dict(check))
        ledger[scene]["dirty"] = False
def _failures_from_checks(
    scene_names: Sequence[str],
    checks: Mapping[str, Mapping[str, Any]],
) -> list[dict[str, str]]:
    return [
        {
            "scene_name": scene,
            "error_summary": _error_summary(checks[scene]),
        }
        for scene in scene_names
        if not bool(checks[scene].get("render_ok"))
    ]
def _round_record(
    round_index: int,
    scene_names: Sequence[str],
    failures: Sequence[Mapping[str, Any]],
    *,
    scope: str,
) -> dict[str, Any]:
    return {
        "round_index": round_index,
        "scope": scope,
        "rendered_scenes": list(scene_names),
        "render_ok_count": len(scene_names) - len(failures),
        "failed_scenes": [failure["scene_name"] for failure in failures],
    }
def _summary(
    *,
    root: Path,
    source: Path,
    status: str,
    scenes: Sequence[str],
    checks: Mapping[str, Mapping[str, Any]],
    llm_call_count: int,
    repair_round_count: int,
    render_round_count: int,
    rejected_repair_count: int,
    rejected_repair_reasons: Sequence[str],
    common_root_repair_count: int,
    source_contract_repairs: Sequence[Mapping[str, Any]],
    started: float,
    max_rounds: int,
) -> dict[str, Any]:
    return build_summary(root=root, source=source, status=status, scenes=scenes, checks=checks, llm_call_count=llm_call_count, repair_round_count=repair_round_count, render_round_count=render_round_count, rejected_repair_count=rejected_repair_count, rejected_repair_reasons=rejected_repair_reasons, common_root_repair_count=common_root_repair_count, source_contract_repairs=source_contract_repairs, started=started, max_rounds=max_rounds)
def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
def _dedupe(items: Sequence[str]) -> list[str]:
    return list(dict.fromkeys(str(item) for item in items if str(item)))
def _missing_repair_client(**kwargs: Any) -> str:
    raise RuntimeError("repair_client_required_after_render_failure")
