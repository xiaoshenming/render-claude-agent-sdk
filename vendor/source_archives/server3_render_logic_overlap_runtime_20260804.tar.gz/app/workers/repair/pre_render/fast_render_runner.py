"""Compatibility facade for fast render runner flows."""
from . import fast_render_runner_entry as _entry
from . import fast_render_runner_pool_flow as _pool_flow
from . import fast_render_runner_file_flow as _file_flow
from . import fast_render_runner_render as _render
from . import fast_render_runner_cases as _cases

for _module in (_entry, _pool_flow, _file_flow, _render, _cases):
    globals().update({
        _name: _value
        for _name, _value in vars(_module).items()
        if _name not in {"_module", "__builtins__"}
    })
del _module
