"""Compatibility-only normalizers for generated render contracts."""

from __future__ import annotations

import ast
import re
from typing import Any

from app.workers.repair.pre_render.layout_contract_helpers import (
    body_indent as _body_indent,
    class_can_call_setup_layout as _class_can_call_setup_layout,
    construct_has_setup_layout_call as _construct_has_setup_layout_call,
    first_layout_contract_usage_line as _first_layout_contract_usage_line,
)


def _compat_repair(repair_type: str, *, target: str = "", old_code: str = "", new_code: str = "") -> dict[str, Any]:
    payload: dict[str, Any] = {
        "type": repair_type,
        "category": "compat",
        "visual_mutation": False,
        "allowed_modes": ["compat-only"],
    }
    if target:
        payload["target"] = target
    if old_code:
        payload["old_code"] = old_code
    if new_code:
        payload["new_code"] = new_code
    return payload


def normalize_render_contracts(source: str) -> tuple[str, list[dict[str, Any]]]:
    source, setup_repairs = _normalize_setup_layout_contracts(source)
    lines = source.splitlines()
    repaired: list[str] = []
    repairs: list[dict[str, Any]] = list(setup_repairs)
    simple_call = re.compile(r"^(?P<indent>\s*)(?P<name>[A-Za-z_][A-Za-z0-9_]*)\.set_default\((?P<args>.*)\)\s*$")
    globals_call = re.compile(r"^(?P<indent>\s*)globals\(\)\[[\"'](?P<name>[A-Za-z_][A-Za-z0-9_]*)[\"']\]\.set_default\((?P<args>.*)\)\s*$")
    guarded_names = {"Mobject", "VMobject", "Text", "Tex", "MathTex", "MarkupText", "Paragraph"}
    for line in lines:
        simple = simple_call.match(line)
        if simple and simple.group("name") in guarded_names:
            indent, name = simple.group("indent"), simple.group("name")
            repaired += [f'{indent}if hasattr({name}, "set_default"):', f"{indent}    {name}.set_default({simple.group('args')})"]
            repairs.append(_compat_repair("guard_optional_set_default", target=name, old_code=line))
            continue
        via_globals = globals_call.match(line)
        if via_globals and via_globals.group("name") in guarded_names:
            indent, name = via_globals.group("indent"), via_globals.group("name")
            var_name = f"_mathpi_default_{name}"
            repaired += [f'{indent}{var_name} = globals().get("{name}")', f'{indent}if hasattr({var_name}, "set_default"):', f"{indent}    {var_name}.set_default({via_globals.group('args')})"]
            repairs.append(_compat_repair("guard_optional_set_default", target=f"globals.{name}", old_code=line))
            continue
        repaired.append(line)
    normalized = source if not repairs else "\n".join(repaired) + ("\n" if source.endswith("\n") else "")
    normalized, header_repairs = _restore_project_base_config_header(normalized)
    repairs.extend(header_repairs)
    return (source, []) if not repairs else (normalized, repairs)


def _restore_project_base_config_header(source: str) -> tuple[str, list[dict[str, Any]]]:
    references_base = bool(re.search(r"\bclass\s+\w+\s*\(\s*BaseConfigScene\s*\)", source))
    defines_base = bool(re.search(r"\bclass\s+BaseConfigScene\s*\(", source))
    if not references_base or defines_base:
        return source, []
    from app.prompts.header_template import COLOR_VARS, HEADER_TEMPLATE, THREED_HEADER_TEMPLATE, THREED_VOICE_HEADER_TEMPLATE, VOICE_HEADER_TEMPLATE, apply_render_canvas_config
    uses_voice = "self.voiceover(" in source or "VoiceoverScene" in source or "manim_voiceover" in source
    uses_3d = bool(re.search(r"\b(?:ThreeD|ThreeDAxes|Surface|set_camera_orientation|move_camera)\b", source))
    template = THREED_VOICE_HEADER_TEMPLATE if uses_3d and uses_voice else THREED_HEADER_TEMPLATE if uses_3d else VOICE_HEADER_TEMPLATE if uses_voice else HEADER_TEMPLATE
    header = apply_render_canvas_config(template.replace("__COLOR__", COLOR_VARS[1]).replace("__VOICE__", "longxiaoxia_v3"), "16:9").rstrip()
    return f"{header}\n\n{source.lstrip()}", [_compat_repair("restore_project_base_config_header", target="BaseConfigScene", new_code="project_header")]


def _normalize_setup_layout_contracts(source: str) -> tuple[str, list[dict[str, Any]]]:
    if "def setup_layout" not in source:
        return source, []
    lines, repairs = source.splitlines(), []
    setup_call = re.compile(r"^(?P<indent>\s*)self\.(?P<method>setup|setup_scene)\s*\([^)]*\)(?P<tail>\s*(?:#.*)?)$")
    setup_layout_args = re.compile(r"^(?P<indent>\s*)self\.setup_layout\((?P<args>[^)]*\S[^)]*)\)(?P<tail>\s*(?:#.*)?)$")
    for index, line in enumerate(lines):
        match = setup_call.match(line)
        if match:
            new_line = f"{match.group('indent')}self.setup_layout(){match.group('tail')}"
            if new_line != line:
                lines[index] = new_line; repairs.append(_compat_repair("setup_layout_entry_call", target=f"line:{index + 1}", old_code=line, new_code=new_line))
            continue
        layout_args = setup_layout_args.match(line)
        if layout_args:
            new_line = f"{layout_args.group('indent')}self.setup_layout(){layout_args.group('tail')}"
            if new_line != line:
                lines[index] = new_line; repairs.append(_compat_repair("setup_layout_arg_compat", target=f"line:{index + 1}", old_code=line, new_code=new_line))
    current = "\n".join(lines) + ("\n" if source.endswith("\n") else "")
    current, inserted = _insert_setup_layout_for_construct_layout_usage(current)
    return current, repairs + inserted


def _insert_setup_layout_for_construct_layout_usage(source: str) -> tuple[str, list[dict[str, Any]]]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source, []
    lines, insertions = source.splitlines(), []
    for node in tree.body:
        if not isinstance(node, ast.ClassDef) or not _class_can_call_setup_layout(node):
            continue
        for member in node.body:
            if not isinstance(member, ast.FunctionDef) or member.name != "construct" or _construct_has_setup_layout_call(member):
                continue
            first_usage = _first_layout_contract_usage_line(member)
            if first_usage is None:
                continue
            insert_after = member.lineno
            if member.body and isinstance(member.body[0], ast.Expr) and isinstance(getattr(member.body[0], "value", None), ast.Constant) and isinstance(member.body[0].value.value, str):
                insert_after = getattr(member.body[0], "end_lineno", member.body[0].lineno)
            insertions.append((insert_after, f"{_body_indent(lines, member)}self.setup_layout()", node.name))
    if not insertions:
        return source, []
    repairs = []
    for insert_after, new_line, class_name in sorted(insertions, reverse=True):
        lines.insert(insert_after, new_line); repairs.append(_compat_repair("setup_layout_construct_entry", target=class_name, new_code=new_line))
    repairs.reverse()
    return "\n".join(lines) + ("\n" if source.endswith("\n") else ""), repairs
