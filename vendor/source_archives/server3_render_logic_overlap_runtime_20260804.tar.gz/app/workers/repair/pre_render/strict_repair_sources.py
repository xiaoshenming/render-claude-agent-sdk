"""严格修复流程中的 Scene 与直接 helper 源码提取。"""

from __future__ import annotations

import ast
from typing import Any

from app.quality_repair.contracts.scene_scope import SceneScopeExtractor


def failures_with_scene_sources(source: str, failures: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{**dict(failure), "scene_source": scene_source(source, str(failure["scene_name"])), "direct_helpers": direct_helper_sources(source, str(failure["scene_name"]))} for failure in failures]


def scene_source(source: str, scene_name: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return ""
    lines = source.splitlines()
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == scene_name:
            return "\n".join(lines[node.lineno - 1 : getattr(node, "end_lineno", node.lineno)])
    return ""


def direct_helper_sources(source: str, scene_name: str) -> dict[str, str]:
    try:
        scope = SceneScopeExtractor(source).extract(scene_name)
    except Exception:
        return {}
    return {name: function_source(source, name) for name in scope.direct_helper_names if function_source(source, name)}


def function_source(source: str, helper_name: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return ""
    lines = source.splitlines()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == helper_name:
            return "\n".join(lines[node.lineno - 1 : getattr(node, "end_lineno", node.lineno)])
    return ""


def direct_helpers(source: str, scene_name: str) -> list[str]:
    try:
        return SceneScopeExtractor(source).extract(scene_name).direct_helper_names
    except Exception:
        return []
