from __future__ import annotations

from .error_patterns_constants import *
def _auto_fix_mathtex_chinese(scene_code: str, has_ctex: bool = False) -> Tuple[Optional[str], str]:
    """将含中文的 MathTex(...) 调用替换为 Text(...)。

    xelatex error 的常见原因是 MathTex/Tex 里混了中文字符，
    LaTeX 的 math mode 不支持中文。

    注意：如果代码已配置 ctex 模板，Tex/MathTex 本身就支持中文，
    不需要转换。盲目转成 Text() 会导致 LaTeX 命令被原样显示。
    """
    # 如果代码中已有 ctex 模板，Tex() 可以正确渲染中文，跳过转换
    if has_ctex or 'ctex' in scene_code or 'TexTemplateLibrary' in scene_code:
        return None, ""

    fixes = []

    def _replace_call(match):
        func_name = match.group(1)  # MathTex 或 Tex
        args_str = match.group(2)
        # 检查参数里有没有中文
        if _CHINESE_RE.search(args_str):
            fixes.append(f"{func_name}→Text (含中文)")
            # 清理 LaTeX 专用参数
            cleaned = re.sub(r',\s*tex_template\s*=[^,)]+', '', args_str)
            # 清理 r"$$..$$" 包裹 → 纯文本
            cleaned = re.sub(r'r?"?\$\$\\text\{([^}]+)\}\$\$"?', r'"\1"', cleaned)
            cleaned = re.sub(r'r?"?\$\$([^$]+)\$\$"?', r'"\1"', cleaned)
            return f"Text({cleaned})"
        return match.group(0)  # 无中文，保持原样

    # 匹配 MathTex(...) 和 Tex(...)，支持多行和嵌套括号
    modified = re.sub(
        r'\b(MathTex|Tex)\(([^)]*[\u4e00-\u9fff\u3400-\u4dbf][^)]*)\)',
        _replace_call,
        scene_code
    )

    if fixes and modified != scene_code:
        return modified, f"xelatex修复: {', '.join(fixes)}"
    return None, ""
def _auto_fix_chinese_punctuation(scene_code: str) -> Tuple[Optional[str], str]:
    """将代码中的中文标点替换为英文标点。

    LLM 有时在字符串外使用中文标点（，。；：），导致 SyntaxError。
    只替换字符串外的中文标点。
    """
    replacements = {
        '\uff0c': ',',   # ，→ ,
        '\u3002': '.',   # 。→ .
        '\uff1b': ';',   # ；→ ;
        '\uff1a': ':',   # ：→ :
        '\uff08': '(',   # （→ (
        '\uff09': ')',   # ）→ )
        '\u3010': '[',   # 【→ [
        '\u3011': ']',   # 】→ ]
        '\u201c': '"',   # "→ "
        '\u201d': '"',   # "→ "
        '\u2018': "'",   # '→ '
        '\u2019': "'",   # '→ '
    }

    lines = scene_code.splitlines(keepends=True)
    protected_spans: dict[int, list[tuple[int, int]]] = {}

    try:
        token_iter = tokenize.generate_tokens(io.StringIO(scene_code).readline)
        for tok in token_iter:
            if tok.type not in (tokenize.STRING, tokenize.COMMENT):
                continue
            (start_line, start_col), (end_line, end_col) = tok.start, tok.end
            for line_no in range(start_line, end_line + 1):
                if line_no < 1 or line_no > len(lines):
                    continue
                line_len = len(lines[line_no - 1])
                start = start_col if line_no == start_line else 0
                end = end_col if line_no == end_line else line_len
                protected_spans.setdefault(line_no, []).append((start, end))
    except (tokenize.TokenError, IndentationError, SyntaxError):
        # Best effort: keep spans already collected and avoid a risky fallback to
        # whole-file replacement, which can corrupt user-visible Chinese text.
        pass

    def _is_protected(line_no: int, col: int) -> bool:
        return any(start <= col < end for start, end in protected_spans.get(line_no, ()))

    counts = {ch: 0 for ch in replacements}
    fixed_lines = []
    for line_no, line in enumerate(lines, start=1):
        chars = []
        for col, ch in enumerate(line):
            replacement = replacements.get(ch)
            if replacement is not None and not _is_protected(line_no, col):
                chars.append(replacement)
                counts[ch] += 1
            else:
                chars.append(ch)
        fixed_lines.append("".join(chars))

    modified = "".join(fixed_lines)
    applied = [
        f"'{ch_punct}'→'{en_punct}' x{counts[ch_punct]}"
        for ch_punct, en_punct in replacements.items()
        if counts[ch_punct]
    ]

    if applied and modified != scene_code:
        return modified, f"中文标点修复: {', '.join(applied)}"
    return None, ""
def _auto_fix_truncation(scene_code: str) -> Tuple[Optional[str], str]:
    """自动补全 LLM 截断导致的未闭合括号/引号。

    适用于切片修复路径（_retry_failed_slice）中的 SyntaxError。
    """
    # 统计未闭合的括号
    open_parens = 0
    open_brackets = 0
    open_braces = 0
    in_string = None  # None, "'", '"', "'''", '"""'
    i = 0
    code = scene_code
    length = len(code)

    while i < length:
        ch = code[i]
        # 跳过字符串内容
        if in_string:
            if in_string in ('"""', "'''") and code[i:i+3] == in_string:
                in_string = None
                i += 3
                continue
            elif in_string in ('"', "'") and ch == in_string and (i == 0 or code[i-1] != '\\'):
                in_string = None
                i += 1
                continue
            i += 1
            continue
        # 检测字符串开始
        if code[i:i+3] in ('"""', "'''"):
            in_string = code[i:i+3]
            i += 3
            continue
        if ch in ('"', "'"):
            in_string = ch
            i += 1
            continue
        # 跳过注释
        if ch == '#':
            while i < length and code[i] != '\n':
                i += 1
            continue
        # 统计括号
        if ch == '(':
            open_parens += 1
        elif ch == ')':
            open_parens -= 1
        elif ch == '[':
            open_brackets += 1
        elif ch == ']':
            open_brackets -= 1
        elif ch == '{':
            open_braces += 1
        elif ch == '}':
            open_braces -= 1
        i += 1

    # 补全
    fixes = []
    suffix = ""
    if open_parens > 0:
        suffix += ")" * open_parens
        fixes.append(f"补全 {open_parens} 个 ')'")
    if open_brackets > 0:
        suffix += "]" * open_brackets
        fixes.append(f"补全 {open_brackets} 个 ']'")
    if open_braces > 0:
        suffix += "}" * open_braces
        fixes.append(f"补全 {open_braces} 个 '}}'")
    if in_string:
        suffix += in_string
        fixes.append(f"补全字符串闭合 {in_string}")

    if suffix:
        fixed = code.rstrip() + suffix + "\n"
        return fixed, f"自动补全截断: {', '.join(fixes)}"
    return None, ""
def _auto_fix_nonpositive_waits(scene_code: str) -> Tuple[Optional[str], str]:
    """把可能为 0 的 wait 改成条件等待，不插入固定停顿。"""
    fixed_lines: list[str] = []
    changed = 0
    for line in scene_code.splitlines():
        match = _NONPOSITIVE_WAIT_MAX_RE.match(line)
        if match:
            changed += 1
            indent = match.group("indent")
            expr = match.group("expr").strip()
            var_name = f"_safe_wait_{changed}"
            fixed_lines.append(f"{indent}{var_name} = max(0.0, {expr})")
            fixed_lines.append(f"{indent}if {var_name} > 0:")
            fixed_lines.append(f"{indent}    self.wait({var_name})")
            continue
        match = _ZERO_WAIT_RE.match(line)
        if match:
            changed += 1
            fixed_lines.append(f"{match.group('indent')}pass  # skipped zero-duration wait")
            continue
        fixed_lines.append(line)
    if not changed:
        return None, ""
    trailing_newline = "\n" if scene_code.endswith("\n") else ""
    return (
        "\n".join(fixed_lines) + trailing_newline,
        f"非正数wait条件化: {changed}处",
    )
def _auto_fix_numpy_math(scene_code: str, error_msg: str) -> Tuple[Optional[str], str]:
    """NumPy 2.x 移除了 np.math，直接改走标准库 math。

    该错误在帕斯卡三角形 / 组合数场景中很常见，属于确定性 API 兼容修复，
    不需要再消耗 LLM patch。
    """
    if not re.search(
        r"AttributeError:.*numpy.*(?:has no attribute|object has no attribute).*math",
        error_msg,
        re.IGNORECASE,
    ):
        return None, ""
    fixed = re.sub(
        r"\bnp\.math\.([A-Za-z_]\w*)\(",
        r'__import__("math").\1(',
        scene_code,
    )
    if fixed == scene_code:
        return None, ""
    return fixed, "np.math 标准库兼容修复"

