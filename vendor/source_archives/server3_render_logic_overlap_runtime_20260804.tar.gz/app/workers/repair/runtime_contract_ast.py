"""AST visitors and violation construction for runtime contract evidence."""

from __future__ import annotations

import ast
import builtins
from collections.abc import Iterable

from .runtime_contract_constants import (
    ALLOWED_LLM_RUNTIME_HELPERS,
    ALLOWED_MANIM_SCENE_METHODS,
    MISSING_LATEST_RUNTIME_HELPERS,
    Violation,
)


def _call_helper_name(func: ast.AST) -> str | None:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute) and _is_direct_self_or_cls(func.value):
        return func.attr
    return None


def _is_direct_self_or_cls(node: ast.AST) -> bool:
    return isinstance(node, ast.Name) and node.id in {"self", "cls"}


def _hallucinated_helper_violation(
    helper: str,
    line: int,
    *,
    receiver: str = "",
) -> Violation:
    return {
        "helper": helper,
        "receiver": receiver,
        "kind": "unauthorized_hallucinated_helper",
        "line": line,
        "message": (
            f"Helper '{receiver + '.' if receiver else ''}{helper}' is not part of the generated-code runtime "
            "contract and is treated as a hallucinated helper."
        ),
        "recommended_action": (
            "Do not inject a fake helper shim. Rewrite the code with allowed "
            "runtime helpers such as safe_text_box, safe_tex, layout_canvas, "
            "make_title, narrate, play_voiceover, or Manim primitives."
        ),
    }


def _missing_runtime_helper_violation(
    helper: str, line: int, *, receiver: str
) -> Violation:
    prefix = f"{receiver}." if receiver else ""
    return {
        "helper": helper,
        "receiver": receiver,
        "kind": "missing_runtime_helper",
        "line": line,
        "message": (
            f"Helper '{prefix}{helper}' is called but is not defined in the "
            "current Scene/BaseConfigScene contract."
        ),
        "recommended_action": (
            "Do not inject a fake helper shim. Rewrite the code so the helper is "
            "defined before first use in the same script/class, or replace it "
            "with allowed runtime helpers such as safe_text_box, safe_tex, "
            "layout_canvas, make_title, narrate, play_voiceover, or Manim primitives."
        ),
    }


def _syntax_error_violation(exc: SyntaxError) -> Violation:
    return {
        "helper": "<syntax>",
        "kind": "syntax_error",
        "line": exc.lineno or 1,
        "message": exc.msg,
        "recommended_action": "Fix Python syntax before checking runtime helpers.",
    }


def _class_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Subscript):
        return _class_name(node.value)
    return ""


class _ClassContractIndex(ast.NodeVisitor):
    def __init__(self) -> None:
        self.class_methods: dict[str, set[str]] = {}
        self.class_bases: dict[str, set[str]] = {}
        self.module_functions: set[str] = set()
        self.imported_names: set[str] = set()

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self.imported_names.add(alias.asname or alias.name.split(".", 1)[0])

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for alias in node.names:
            if alias.name != "*":
                self.imported_names.add(alias.asname or alias.name)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.module_functions.add(node.name)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.module_functions.add(node.name)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.class_bases[node.name] = {
            name for name in (_class_name(base) for base in node.bases) if name
        }
        self.class_methods[node.name] = {
            item.name
            for item in node.body
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        for item in node.body:
            if isinstance(item, ast.ClassDef):
                self.visit(item)

    def methods_for_class(self, class_name: str) -> set[str]:
        seen: set[str] = set()
        methods: set[str] = set()

        def visit(name: str) -> None:
            if not name or name in seen:
                return
            seen.add(name)
            methods.update(self.class_methods.get(name, set()))
            for base in self.class_bases.get(name, set()):
                visit(base)

        visit(class_name)
        return methods


class _RuntimeContractVisitor(ast.NodeVisitor):
    def __init__(
        self,
        hallucinated_helpers: Iterable[str],
        contract_index: _ClassContractIndex,
        allowed_runtime_helpers: Iterable[str] | None = None,
    ) -> None:
        self.hallucinated_helpers = set(hallucinated_helpers)
        self.contract_index = contract_index
        self.allowed_runtime_helpers = set(ALLOWED_LLM_RUNTIME_HELPERS)
        self.allowed_runtime_helpers.update(allowed_runtime_helpers or ())
        self.violations: list[Violation] = []
        self._class_stack: list[str] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._class_stack.append(node.name)
        try:
            self.generic_visit(node)
        finally:
            self._class_stack.pop()

    def visit_Call(self, node: ast.Call) -> None:
        helper = _call_helper_name(node.func)
        if helper in self.hallucinated_helpers:
            self.violations.append(
                _hallucinated_helper_violation(
                    helper,
                    getattr(node, "lineno", 1),
                    receiver=self._self_receiver(node.func) or "",
                )
            )
        elif self._is_missing_self_runtime_helper(node, helper):
            receiver = self._self_receiver(node.func)
            self.violations.append(
                _missing_runtime_helper_violation(
                    helper,
                    getattr(node, "lineno", 1),
                    receiver=receiver or "self",
                )
            )
        elif self._is_missing_bare_runtime_helper(node, helper):
            self.violations.append(
                _missing_runtime_helper_violation(
                    helper,
                    getattr(node, "lineno", 1),
                    receiver="",
                )
            )
        self.generic_visit(node)

    def _self_receiver(self, func: ast.AST) -> str | None:
        if (
            isinstance(func, ast.Attribute)
            and isinstance(func.value, ast.Name)
            and func.value.id in {"self", "cls"}
        ):
            return func.value.id
        return None

    def _is_missing_self_runtime_helper(
        self, node: ast.Call, helper: str | None
    ) -> bool:
        if not helper or helper in self.allowed_runtime_helpers:
            return False
        if helper.startswith("_"):
            return False
        if helper in ALLOWED_MANIM_SCENE_METHODS:
            return False
        if helper in dir(builtins):
            return False
        if self._self_receiver(node.func) is None:
            return False
        current_class = self._class_stack[-1] if self._class_stack else ""
        class_methods = self.contract_index.methods_for_class(current_class)
        if helper in class_methods:
            return False
        return True

    def _is_missing_bare_runtime_helper(
        self,
        node: ast.Call,
        helper: str | None,
    ) -> bool:
        if not helper or helper not in MISSING_LATEST_RUNTIME_HELPERS:
            return False
        if not isinstance(node.func, ast.Name):
            return False
        if helper in self.contract_index.module_functions:
            return False
        if helper in self.contract_index.imported_names:
            return False
        if helper in self.allowed_runtime_helpers or helper in dir(builtins):
            return False
        return True
