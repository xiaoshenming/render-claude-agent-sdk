"""Pure parsing helpers for replaying known render-failure signatures.

This module intentionally avoids Manim/runtime imports. It validates failure
corpus records so tests can pin incident signatures without rendering videos.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True)
class ClassifiedFailureSignature:
    signature: str
    lane: str
    stage: str


@dataclass(frozen=True)
class FailureReplaySample:
    job_id: str
    prompt: str
    terminal_error_type: str
    first_failure_signature: str
    failure_codes: tuple[str, ...]
    expected_repair_lane: str
    notes: str
    signature: str
    lane: str
    stage: str
    before: str
    expected_action: str


_SIGNATURE_CLASSIFICATIONS: dict[str, tuple[str, str]] = {
    "create_card": ("helper_contract_static_repair", "static_analysis"),
    "get_sectors": ("math_logic_geometry_repair", "static_analysis"),
    "init_tts": ("tts_backend_recovery", "tts_setup"),
    "set_speech_service": ("tts_backend_recovery", "tts_setup"),
    "layout_repair_failed": ("layout_visual_recheck_repair", "visual_review"),
    "math_logic_repair_failed": ("math_logic_geometry_repair", "math_logic_review"),
    "numpy_truthiness": ("numpy_truthiness_repair", "render_runtime"),
    "data_shape_unpack": ("data_shape_unpack_repair", "render_runtime"),
    "container_index_template": ("container_index_template_repair", "render_runtime"),
    "geometry_helper_contract": ("compound_geometry_helper_repair", "static_analysis"),
}


def classify_failure_signature(signature: str) -> ClassifiedFailureSignature:
    normalized = signature.strip()
    if not normalized:
        raise ValueError("failure signature must not be blank")

    if normalized in _SIGNATURE_CLASSIFICATIONS:
        lane, stage = _SIGNATURE_CLASSIFICATIONS[normalized]
        return ClassifiedFailureSignature(signature=normalized, lane=lane, stage=stage)

    for known_signature, (lane, stage) in _SIGNATURE_CLASSIFICATIONS.items():
        if known_signature in normalized:
            return ClassifiedFailureSignature(
                signature=known_signature,
                lane=lane,
                stage=stage,
            )

    raise ValueError(f"unknown failure replay signature: {normalized}")


def load_failure_replay_corpus(path: str | Path) -> list[FailureReplaySample]:
    fixture_path = Path(path)
    records: list[FailureReplaySample] = []
    for line_number, line in enumerate(fixture_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        raw_record = json.loads(line)
        if not isinstance(raw_record, dict):
            raise ValueError(f"line {line_number} must be a JSON object")
        records.append(_sample_from_record(raw_record, line_number=line_number))
    return records


def _sample_from_record(record: Mapping[str, Any], *, line_number: int) -> FailureReplaySample:
    signature = _required_str(record, "signature", line_number=line_number)
    classified = classify_failure_signature(signature)

    lane = _required_str(record, "lane", line_number=line_number)
    stage = _required_str(record, "stage", line_number=line_number)
    expected_repair_lane = _required_str(record, "expected_repair_lane", line_number=line_number)
    if lane != classified.lane:
        raise ValueError(
            f"line {line_number} lane {lane!r} does not match signature {signature!r}"
        )
    if stage != classified.stage:
        raise ValueError(
            f"line {line_number} stage {stage!r} does not match signature {signature!r}"
        )
    if expected_repair_lane != lane:
        raise ValueError(
            f"line {line_number} expected_repair_lane {expected_repair_lane!r} "
            f"does not match lane {lane!r}"
        )

    return FailureReplaySample(
        job_id=_required_str(record, "job_id", line_number=line_number),
        prompt=_required_str(record, "prompt", line_number=line_number),
        terminal_error_type=_required_str(record, "terminal_error_type", line_number=line_number),
        first_failure_signature=_required_str(
            record,
            "first_failure_signature",
            line_number=line_number,
        ),
        failure_codes=_required_failure_codes(record, line_number=line_number),
        expected_repair_lane=expected_repair_lane,
        notes=_required_str(record, "notes", line_number=line_number),
        signature=classified.signature,
        lane=lane,
        stage=stage,
        before=_required_str(record, "before", line_number=line_number),
        expected_action=_required_str(record, "expected_action", line_number=line_number),
    )


def _required_str(record: Mapping[str, Any], key: str, *, line_number: int) -> str:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"line {line_number} field {key!r} must be a non-blank string")
    return value


def _required_failure_codes(record: Mapping[str, Any], *, line_number: int) -> tuple[str, ...]:
    value = record.get("failure_codes")
    if not isinstance(value, list) or not value:
        raise ValueError(f"line {line_number} field 'failure_codes' must be a non-empty list")

    codes: list[str] = []
    for code in value:
        if not isinstance(code, str) or not code.strip():
            raise ValueError(
                f"line {line_number} field 'failure_codes' must contain non-blank strings"
            )
        codes.append(code)
    if len(codes) != len(set(codes)):
        raise ValueError(f"line {line_number} field 'failure_codes' must be unique")
    return tuple(codes)
