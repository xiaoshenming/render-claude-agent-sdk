"""Normalized signatures and task_data bookkeeping for slice repair."""

from __future__ import annotations

import re
from typing import Any

from app.workers.repair import error_fixer


_IDENT = r"[A-Za-z_][A-Za-z0-9_]*"
_STATIC_UNDEFINED_RE = re.compile(
    rf"(?:static[_ -]?undefined[_ -]?name|StaticUndefinedName)"
    rf"\s*[:=]\s*['\"]?(?P<name>{_IDENT})",
    re.IGNORECASE,
)
_NAME_NOT_DEFINED_RE = re.compile(
    rf"(?:NameError:\s*)?name ['\"](?P<name>{_IDENT})['\"] is not defined",
    re.IGNORECASE,
)
_MISSING_ATTR_RE = re.compile(
    rf"has no attribute ['\"](?P<name>{_IDENT})['\"]",
    re.IGNORECASE,
)
_SUBMOBJECTS_ATTR_RE = re.compile(
    r"['\"]?(?P<owner>tuple|list|str|string)['\"]? object has no attribute "
    r"['\"]submobjects['\"]",
    re.IGNORECASE,
)
_TEX_TEMPLATE_CT_RE = re.compile(
    r"TexTemplateLibrary\.ct(?!ex)\b|"
    r"TexTemplateLibrary[^\n]{0,120}has no attribute ['\"]ct['\"]",
    re.IGNORECASE,
)


def normalize_slice_failure_signature(error: str) -> str:
    """Return a stable, human-readable repair signature for one slice failure."""
    text = str(error or "")
    if not text.strip():
        return "unknown"

    if _TEX_TEMPLATE_CT_RE.search(text):
        return "TexTemplateLibrary.ct"

    match = _STATIC_UNDEFINED_RE.search(text) or _NAME_NOT_DEFINED_RE.search(text)
    if match:
        return f"StaticUndefinedName:{match.group('name')}"

    match = _SUBMOBJECTS_ATTR_RE.search(text)
    if match:
        owner = match.group("owner").lower()
        if owner == "string":
            owner = "str"
        family = {
            "tuple": "TupleSubmobjects",
            "list": "ListSubmobjects",
            "str": "StringSubmobjects",
        }.get(owner, "SubmobjectsAttribute")
        return f"{family}:{owner}.submobjects"

    if "not enough values to unpack" in text.lower():
        return "ValueError:not enough values to unpack"

    match = _MISSING_ATTR_RE.search(text)
    if match:
        name = match.group("name")
        if name != "submobjects":
            return f"MissingHelperMethod:{name}"

    if "list index out of range" in text.lower():
        return "IndexError:list index out of range"

    signature = error_fixer.error_signature(text)
    signature = re.sub(
        r'File "[^"]+", line \d+',
        'File "<path>", line <n>',
        signature,
    )
    signature = re.sub(
        r"\bline\s+\d+\b",
        "line <n>",
        signature,
        flags=re.IGNORECASE,
    )
    signature = re.sub(r"0x[0-9a-fA-F]+", "0x<addr>", signature)
    signature = re.sub(r"\s+", " ", signature).strip()
    return signature or "unknown"


def record_repair_failure_signature(
    task_data: dict[str, Any] | None,
    *,
    scene_name: str,
    error: str,
    attempt: int,
) -> tuple[str, int]:
    """Record a scene-scoped signature hit in task_data.

    attempt=0 represents the original render failure before slice repair starts.
    Positive attempts represent repair loop attempts that produced the failure.
    """
    signature = normalize_slice_failure_signature(error)
    if task_data is None:
        return signature, 0

    counts_root = task_data.setdefault("_repair_signature_counts", {})
    scene_counts = counts_root.setdefault(scene_name, {})
    count = int(scene_counts.get(signature, 0)) + 1
    scene_counts[signature] = count

    attempts_root = task_data.setdefault("_repair_attempts_by_signature", {})
    scene_attempts = attempts_root.setdefault(scene_name, {})
    attempts = scene_attempts.setdefault(signature, [])
    attempts.append(attempt)

    first = {"scene_name": scene_name, "signature": signature}
    task_data.setdefault("_first_failure_signature", first)
    task_data["_last_failure_signature"] = {
        "scene_name": scene_name,
        "signature": signature,
        "count": count,
    }
    return signature, count
