"""Static guardrails for repaired Manim code before container render."""

from __future__ import annotations

import ast
import builtins
import re
import tokenize
import io
from typing import Iterable


_KNOWN_MANIM_NAME_ALIASES = {
    "ease_out": "smooth",
    "ease_in_sine": "smooth",
}

_COMMON_ALLOWED_NAMES = {
    "np",
    "math",
    "random",
    "itertools",
    "rate_functions",
    "there_and_back",
    "interpolate_color",
    "config",
    "settings",
    "always_redraw",
    "angle_of_vector",
    "GlobalConfig",
    "BaseConfigScene",
    "_resolve_icon_asset",
    "asset_icon",
    "icon_card",
    "icon_row",
    "Scene",
    "ThreeDScene",
    "MovingCameraScene",
    "Mobject",
    "VMobject",
    "VGroup",
    "Group",
    "Text",
    "MarkupText",
    "Tex",
    "MathTex",
    "DecimalNumber",
    "Integer",
    "Dot",
    "Line",
    "Arrow",
    "DoubleArrow",
    "Vector",
    "Polygon",
    "Triangle",
    "Square",
    "Rectangle",
    "RoundedRectangle",
    "Circle",
    "Arc",
    "Angle",
    "RightAngle",
    "Axes",
    "NumberPlane",
    "Brace",
    "BraceBetweenPoints",
    "SurroundingRectangle",
    "Underline",
    "ImageMobject",
    "SVGMobject",
    "Write",
    "Create",
    "FadeIn",
    "FadeOut",
    "Transform",
    "ReplacementTransform",
    "TransformMatchingTex",
    "AnimationGroup",
    "LaggedStart",
    "Succession",
    "Indicate",
    "Circumscribe",
    "Flash",
    "GrowArrow",
    "DrawBorderThenFill",
    "Restore",
    "Wait",
    "UP",
    "DOWN",
    "LEFT",
    "RIGHT",
    "ORIGIN",
    "UL",
    "UR",
    "DL",
    "DR",
    "IN",
    "OUT",
    "PI",
    "TAU",
    "DEGREES",
    "WHITE",
    "BLACK",
    "GRAY",
    "GREY",
    "RED",
    "GREEN",
    "BLUE",
    "YELLOW",
    "ORANGE",
    "PURPLE",
    "PINK",
    "TEAL",
    "GOLD",
}


def normalize_known_manim_name_aliases(code: str) -> tuple[str | None, str]:
    """Replace known generated Manim alias names with symbols available in the worker."""
    if not code or not any(name in code for name in _KNOWN_MANIM_NAME_ALIASES):
        return None, ""
    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(code).readline))
    except (IndentationError, tokenize.TokenError):
        return None, ""

    changed: dict[str, int] = {}
    rewritten: list[tokenize.TokenInfo] = []
    for token in tokens:
        if token.type == tokenize.NAME and token.string in _KNOWN_MANIM_NAME_ALIASES:
            replacement = _KNOWN_MANIM_NAME_ALIASES[token.string]
            changed[token.string] = changed.get(token.string, 0) + 1
            token = token._replace(string=replacement)
        rewritten.append(token)
    if not changed:
        return None, ""
    fixed = tokenize.untokenize(rewritten)
    details = ", ".join(f"{name}->{_KNOWN_MANIM_NAME_ALIASES[name]}:{count}" for name, count in sorted(changed.items()))
    return fixed, f"Manim rate_func别名归一: {details}"


def _store_target_names(target: ast.AST) -> Iterable[str]:
    if isinstance(target, ast.Name):
        yield target.id
    elif isinstance(target, (ast.Tuple, ast.List)):
        for item in target.elts:
            yield from _store_target_names(item)
    elif isinstance(target, ast.Starred):
        yield from _store_target_names(target.value)


class _NameCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.assigned: set[str] = {"self", "cls"}
        self.loaded: set[str] = set()

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self.assigned.add(alias.asname or alias.name.split(".", 1)[0])

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        for alias in node.names:
            if alias.name == "*":
                continue
            self.assigned.add(alias.asname or alias.name)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.assigned.add(node.name)
        for base in node.bases:
            self.visit(base)
        for keyword in node.keywords:
            self.visit(keyword)
        for child in node.body:
            self.visit(child)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.assigned.add(node.name)
        self._visit_args(node.args)
        for child in node.body:
            self.visit(child)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.visit_FunctionDef(node)

    def visit_Lambda(self, node: ast.Lambda) -> None:
        self._visit_args(node.args)
        self.visit(node.body)

    def visit_For(self, node: ast.For) -> None:
        for name in _store_target_names(node.target):
            self.assigned.add(name)
        self.visit(node.iter)
        for child in node.body + node.orelse:
            self.visit(child)

    def visit_comprehension(self, node: ast.comprehension) -> None:
        for name in _store_target_names(node.target):
            self.assigned.add(name)
        self.visit(node.iter)
        for item in node.ifs:
            self.visit(item)

    def visit_With(self, node: ast.With) -> None:
        for item in node.items:
            self.visit(item.context_expr)
            if item.optional_vars is not None:
                for name in _store_target_names(item.optional_vars):
                    self.assigned.add(name)
        for child in node.body:
            self.visit(child)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        if node.name:
            self.assigned.add(str(node.name))
        if node.type is not None:
            self.visit(node.type)
        for child in node.body:
            self.visit(child)

    def visit_NamedExpr(self, node: ast.NamedExpr) -> None:
        self.visit(node.value)
        for name in _store_target_names(node.target):
            self.assigned.add(name)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            self.loaded.add(node.id)
        elif isinstance(node.ctx, (ast.Store, ast.Del)):
            self.assigned.add(node.id)

    def _visit_args(self, args: ast.arguments) -> None:
        for arg in (
            list(args.posonlyargs)
            + list(args.args)
            + list(args.kwonlyargs)
        ):
            self.assigned.add(arg.arg)
        if args.vararg is not None:
            self.assigned.add(args.vararg.arg)
        if args.kwarg is not None:
            self.assigned.add(args.kwarg.arg)


def _looks_like_generated_local_name(name: str) -> bool:
    if name.startswith("__") and name.endswith("__"):
        return False
    if name in _COMMON_ALLOWED_NAMES:
        return False
    if name in dir(builtins):
        return False
    if not re.fullmatch(r"[a-z][a-z0-9_]*", name):
        return False
    return "_" in name


def find_probable_undefined_names(code: str) -> list[str]:
    """Return high-confidence undefined local-looking names.

    This intentionally catches only lower_snake_case generated temporaries. Manim
    star imports expose many symbols, so flagging every unknown name would create
    false positives; the production failure class here is typo-like variables
    such as ``m_bc_d`` emitted by repair LLMs.
    """
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return []

    collector = _NameCollector()
    collector.visit(tree)
    unknown = collector.loaded - collector.assigned
    return sorted(
        name
        for name in unknown
        if _looks_like_generated_local_name(name)
    )
