"""修复文本、公式和纵向列表的确定性视觉溢出问题。"""

import re
import logging
from typing import Optional, Tuple

from app.workers.repair import visual_fix_patterns as patterns

logger = logging.getLogger("render")

_UNPROTECTED_TEXT_RE = patterns.UNPROTECTED_TEXT_RE
_CHINESE_CHAR_RE = patterns.CHINESE_CHAR_RE
_SCALE_WIDTH_RE = patterns.SCALE_WIDTH_RE
_SCALE_HEIGHT_RE = patterns.SCALE_HEIGHT_RE
_VERTICAL_LIST_VGROUP_RE = patterns.VERTICAL_LIST_VGROUP_RE
_LIST_WRAP_TARGET_CN = patterns.LIST_WRAP_TARGET_CN
_LIST_WRAP_MIN_LINE_CN = patterns.LIST_WRAP_MIN_LINE_CN
_LIST_WRAP_MIN_REMAINING_CN = patterns.LIST_WRAP_MIN_REMAINING_CN
_LIST_WRAP_PUNCTUATION = patterns.LIST_WRAP_PUNCTUATION


def _find_vertical_list_item_vars(code: str) -> set[str]:
    """找出纵向列表 VGroup 中直接引用的变量名。"""
    item_vars: set[str] = set()
    for match in _VERTICAL_LIST_VGROUP_RE.finditer(code or ""):
        for item in match.group("args").split(","):
            name = item.strip()
            if name.isidentifier():
                item_vars.add(name)
    return item_vars


def _count_chinese_chars(text: str) -> int:
    return len(_CHINESE_CHAR_RE.findall(text or ""))


def _choose_list_wrap_index(text: str) -> Optional[int]:
    total_cn = _count_chinese_chars(text)
    if total_cn <= _LIST_WRAP_TARGET_CN:
        return None

    preferred: list[tuple[int, int]] = []
    fallback: list[tuple[int, int]] = []
    seen_cn = 0
    for idx, char in enumerate(text, start=1):
        if _CHINESE_CHAR_RE.match(char):
            seen_cn += 1
        remaining_cn = total_cn - seen_cn
        if seen_cn < _LIST_WRAP_MIN_LINE_CN:
            continue
        if remaining_cn < _LIST_WRAP_MIN_REMAINING_CN:
            continue

        score = abs(_LIST_WRAP_TARGET_CN - seen_cn)
        if char in _LIST_WRAP_PUNCTUATION:
            preferred.append((score, idx))
        elif seen_cn >= _LIST_WRAP_TARGET_CN - 1:
            fallback.append((score, idx))

    candidates = preferred or fallback
    if not candidates:
        return None
    return min(candidates, key=lambda item: item[0])[1]


def _wrap_vertical_list_text(content: str) -> Optional[str]:
    """给列表项长中文自动换行，优先保持字号一致。"""
    if "\\n" in content or "\n" in content:
        return None

    remaining = content
    lines: list[str] = []
    changed = False
    while True:
        wrap_index = _choose_list_wrap_index(remaining)
        if wrap_index is None:
            break
        lines.append(remaining[:wrap_index].rstrip())
        remaining = remaining[wrap_index:].lstrip()
        changed = True

    if not changed:
        return None
    lines.append(remaining)
    return "\\n".join(line for line in lines if line)


def _with_compact_line_spacing(call_tail: str) -> str:
    if "line_spacing" in call_tail:
        return call_tail
    close_index = call_tail.rfind(")")
    if close_index < 0:
        return call_tail
    return (
        f"{call_tail[:close_index]}, line_spacing=0.88"
        f"{call_tail[close_index:]}"
    )


def _scale_guard_line_indices(
    lines: list[str],
    text_line_index: int,
    var_name: str,
) -> set[int]:
    """删除纵向列表项的单项缩放，避免同一列表里局部字体异常变小。"""
    escaped = re.escape(var_name)
    if_guard_re = re.compile(
        rf'^\s*if\s+{escaped}\.(?:width|height)\s*>\s*[^:]+:\s*$'
    )
    scale_re = re.compile(
        rf'^\s*{escaped}\.scale_to_fit_(?:width|height)\('
    )

    indices: set[int] = set()
    limit = min(len(lines), text_line_index + 7)
    i = text_line_index + 1
    while i < limit:
        if if_guard_re.match(lines[i]) and i + 1 < len(lines) and scale_re.match(lines[i + 1]):
            indices.update({i, i + 1})
            i += 2
            continue
        if scale_re.match(lines[i]):
            indices.add(i)
        i += 1
    return indices


def _fix_unprotected_text_overflow(
    code: str,
) -> Tuple[Optional[str], str]:
    """为未受保护的长中文 Text() 添加宽度限制。

    检测模式：
    - `var = Text(">=10个中文字", ...)` 且后续无 scale_to_fit_width
    修复方式：在赋值后追加 `var.scale_to_fit_width(TEXT_MAX_WIDTH)`
    （TEXT_MAX_WIDTH 已在 BaseConfigScene.setup_layout 中定义为 4.0）
    """
    lines = code.split('\n')
    list_item_vars = _find_vertical_list_item_vars(code)
    removed_scale_guard_lines: set[int] = set()
    wrapped_count = 0

    for i, line in enumerate(lines):
        m = _UNPROTECTED_TEXT_RE.match(line)
        if not m:
            continue

        assign_part = m.group(1).strip()
        var_name = assign_part.rstrip('= ').strip()
        if var_name not in list_item_vars or not var_name.isidentifier():
            continue
        if "r\"" in m.group(2) or "r'" in m.group(2):
            continue

        wrapped = _wrap_vertical_list_text(m.group(3))
        if not wrapped:
            continue

        lines[i] = (
            f"{m.group(1)}{m.group(2)}{wrapped}"
            f"{_with_compact_line_spacing(m.group(4))}{m.group(5)}"
        )
        removed_scale_guard_lines.update(_scale_guard_line_indices(lines, i, var_name))
        wrapped_count += 1

    if removed_scale_guard_lines:
        lines = [
            line for idx, line in enumerate(lines)
            if idx not in removed_scale_guard_lines
        ]

    insertions = []  # (line_index, indent, var_name)

    for i, line in enumerate(lines):
        m = _UNPROTECTED_TEXT_RE.match(line)
        if not m:
            continue

        text_content = m.group(3)
        cn_count = len(_CHINESE_CHAR_RE.findall(text_content))
        if cn_count < 10:
            continue

        # 提取变量名
        assign_part = m.group(1).strip()
        var_name = assign_part.rstrip('= ').strip()
        if not var_name.isidentifier():
            continue
        if var_name in list_item_vars:
            continue

        # 检查后续 5 行是否已有 scale_to_fit_width / height
        following = '\n'.join(lines[i+1:i+6])
        has_width_guard = bool(_SCALE_WIDTH_RE.search(following))
        has_height_guard = bool(_SCALE_HEIGHT_RE.search(following))
        if has_width_guard and has_height_guard:
            continue

        indent = ' ' * (len(line) - len(line.lstrip()))
        insertions.append((i, indent, var_name, has_width_guard, has_height_guard))

    if not wrapped_count and not insertions:
        return None, ""

    # 从后往前插入，避免行号偏移
    for line_idx, indent, var_name, has_width_guard, has_height_guard in reversed(insertions):
        # 插入宽度保护行（使用 4.0 作为默认最大宽度）
        protection_lines = []
        if not has_width_guard:
            protection_lines.extend([
                f"{indent}if {var_name}.width > 4.0:",
                f"{indent}    {var_name}.scale_to_fit_width(4.0)",
            ])
        if not has_height_guard:
            protection_lines.extend([
                f"{indent}if {var_name}.height > 0.9:",
                f"{indent}    {var_name}.scale_to_fit_height(0.9)",
            ])
        protection = "\n".join(protection_lines)
        lines.insert(line_idx + 1, protection)

    result = '\n'.join(lines)
    descriptions = []
    if wrapped_count:
        descriptions.append(
            f"列表文本换行保护: {wrapped_count} 处 Text() 自动换行保持字号一致"
        )
    if insertions:
        descriptions.append(
            f"文本溢出保护: {len(insertions)} 处 Text() 添加宽度/高度限制"
        )
    return result, "；".join(descriptions)


# ============================================================
# MathTex 长公式溢出修复
# ============================================================

# 匹配 var = MathTex(r"长公式", ...) 赋值
_UNPROTECTED_MATHTEX_RE = re.compile(
    r'^(\s*(\w+)\s*=\s*)'                 # var =
    r'(MathTex\(\s*(?:r)?["\'])'          # MathTex(r"
    r'([^"\']{0,1000}?)'                  # 公式内容
    r'(["\'][^)]*\))'                     # ", ...) 闭合
    r'(\s*$)',
    re.MULTILINE,
)

_MATHTEX_LEN_THRESHOLD = 60  # 公式长度阈值


def _fix_mathtex_overflow(
    code: str,
) -> Tuple[Optional[str], str]:
    """为长 MathTex 公式添加宽度限制。"""
    lines = code.split('\n')
    insertions = []

    for i, line in enumerate(lines):
        m = _UNPROTECTED_MATHTEX_RE.match(line)
        if not m:
            continue

        var_name = m.group(2)
        formula = m.group(4)
        has_fraction = any(cmd in formula for cmd in ("\\frac", "\\dfrac", "\\tfrac", "\\cfrac"))
        if len(formula) < _MATHTEX_LEN_THRESHOLD and not has_fraction:
            continue

        # 检查后续行是否已有 scale
        following = '\n'.join(lines[i+1:i+6])
        has_width_guard = bool(_SCALE_WIDTH_RE.search(following))
        has_height_guard = bool(_SCALE_HEIGHT_RE.search(following))
        if has_width_guard and has_height_guard:
            continue

        indent = ' ' * (len(line) - len(line.lstrip()))
        insertions.append((i, indent, var_name, has_width_guard, has_height_guard))

    if not insertions:
        return None, ""

    for line_idx, indent, var_name, has_width_guard, has_height_guard in reversed(insertions):
        protection_lines = []
        if not has_width_guard:
            protection_lines.extend([
                f"{indent}if {var_name}.width > 5.0:",
                f"{indent}    {var_name}.scale_to_fit_width(5.0)",
            ])
        if not has_height_guard:
            protection_lines.extend([
                f"{indent}if {var_name}.height > 0.9:",
                f"{indent}    {var_name}.scale_to_fit_height(0.9)",
            ])
        protection = "\n".join(protection_lines)
        lines.insert(line_idx + 1, protection)

    result = '\n'.join(lines)
    return result, f"公式溢出保护: {len(insertions)} 处 MathTex 添加宽度/高度限制"
