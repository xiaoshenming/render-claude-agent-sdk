from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from typing import Callable

from app.workers.repair import pre_render_fixes
from app.workers.repair.post_patch_guard import (
    PostPatchGuardIssue,
    scan_post_patch_guard,
)


@dataclass(frozen=True)
class PostPatchAutoHealResult:
    code: str
    fixes: tuple[str, ...]
    remaining_issues: tuple[str, ...]

    @property
    def changed(self) -> bool:
        return bool(self.fixes)


_Healer = Callable[[str], tuple[str | None, str]]


def auto_heal_post_patch_candidate(
    full_code: str,
    *,
    scene_name: str,
) -> PostPatchAutoHealResult:
    """Complete known runtime helper dependencies after an LLM repair.

    This converts candidates that already contain a useful scene repair but
    forgot common project helpers into runnable candidates, instead of burning
    another LLM round for the same missing-helper error.
    """

    current = full_code or ""
    fixes: list[str] = []

    for _ in range(4):
        helper_issues = _helper_missing_issues(current, scene_name=scene_name)
        if not helper_issues and not _has_proactive_heal_trigger(current):
            break

        changed_this_round = False
        for healer in _known_helper_healers():
            fixed, desc = healer(current)
            if not fixed or fixed == current:
                continue
            ast.parse(fixed)
            current = fixed
            fixes.append(f"post_patch_auto_heal:{desc}")
            changed_this_round = True

        if not changed_this_round:
            break

    remaining = tuple(
        issue.reason
        for issue in scan_post_patch_guard(current, scene_name=scene_name)
    )
    return PostPatchAutoHealResult(
        code=current,
        fixes=tuple(fixes),
        remaining_issues=remaining,
    )


def _helper_missing_issues(
    code: str,
    *,
    scene_name: str,
) -> list[PostPatchGuardIssue]:
    return [
        issue
        for issue in scan_post_patch_guard(code, scene_name=scene_name)
        if issue.code == "helper_missing"
    ]


def _known_helper_healers() -> tuple[_Healer, ...]:
    return (
        _prefix_bare_timeline_helper_calls,
        _add_missing_tracker_to_voiceover_play_steps_evenly,
        pre_render_fixes._inject_tts_timing_helpers,
        pre_render_fixes._inject_missing_fit_to_canvas_helper,
        pre_render_fixes._inject_missing_base_config_runtime_helpers,
        _inject_setup_layout_fallback,
        _inject_mathpi_runtime_fallbacks,
        _inject_safe_text_alias,
    )


def _has_proactive_heal_trigger(code: str) -> bool:
    return (
        _needs_setup_layout_fallback(code)
        or bool(_needed_mathpi_runtime_methods(code))
        or _needs_play_steps_evenly_tracker_repair(code)
    )


def _prefix_bare_timeline_helper_calls(code: str) -> tuple[str | None, str]:
    if "play_steps_evenly(" not in code and "play_synced_steps(" not in code:
        return None, ""
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return None, ""

    helpers = {"play_steps_evenly", "play_synced_steps"}
    replacements: list[tuple[int, int, int, str]] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.class_depth = 0
            self.function_depth = 0

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            self.class_depth += 1
            try:
                self.generic_visit(node)
            finally:
                self.class_depth -= 1

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.function_depth += 1
            try:
                self.generic_visit(node)
            finally:
                self.function_depth -= 1

        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_Call(self, node: ast.Call) -> None:
            if (
                self.class_depth > 0
                and self.function_depth > 0
                and isinstance(node.func, ast.Name)
                and node.func.id in helpers
                and getattr(node.func, "end_col_offset", None) is not None
            ):
                replacements.append(
                    (
                        node.func.lineno - 1,
                        node.func.col_offset,
                        node.func.end_col_offset,
                        f"self.{node.func.id}",
                    )
                )
            self.generic_visit(node)

    Visitor().visit(tree)
    if not replacements:
        return None, ""

    lines = code.splitlines()
    for line_index, start, end, replacement in sorted(
        replacements,
        key=lambda item: (item[0], item[1]),
        reverse=True,
    ):
        if line_index < 0 or line_index >= len(lines):
            continue
        lines[line_index] = (
            lines[line_index][:start] + replacement + lines[line_index][end:]
        )
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"裸timeline helper调用补self: {len(replacements)}处",
    )


def _add_missing_tracker_to_voiceover_play_steps_evenly(
    code: str,
) -> tuple[str | None, str]:
    if not _needs_play_steps_evenly_tracker_repair(code):
        return None, ""
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return None, ""

    replacements: list[tuple[int, int, str]] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.voiceover_trackers: list[str] = []

        def visit_With(self, node: ast.With) -> None:
            tracker = _voiceover_tracker_name(node)
            if tracker:
                self.voiceover_trackers.append(tracker)
                try:
                    self.generic_visit(node)
                finally:
                    self.voiceover_trackers.pop()
                return
            self.generic_visit(node)

        def visit_Call(self, node: ast.Call) -> None:
            if (
                self.voiceover_trackers
                and _is_self_method_call(node, "play_steps_evenly")
                and len(node.args) == 1
                and not any(keyword.arg == "tracker" for keyword in node.keywords)
            ):
                first_arg = node.args[0]
                line_no = getattr(first_arg, "end_lineno", None)
                col_no = getattr(first_arg, "end_col_offset", None)
                if line_no is not None and col_no is not None:
                    replacements.append(
                        (line_no - 1, col_no, f", {self.voiceover_trackers[-1]}")
                    )
            self.generic_visit(node)

    Visitor().visit(tree)
    if not replacements:
        return None, ""

    lines = code.splitlines()
    for line_index, col_no, insert_text in sorted(
        replacements,
        key=lambda item: (item[0], item[1]),
        reverse=True,
    ):
        if line_index < 0 or line_index >= len(lines):
            continue
        lines[line_index] = (
            lines[line_index][:col_no] + insert_text + lines[line_index][col_no:]
        )
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        f"voiceover内play_steps_evenly缺tracker补全: {len(replacements)}处",
    )


def _needs_play_steps_evenly_tracker_repair(code: str) -> bool:
    return (
        "play_steps_evenly(" in (code or "")
        and "voiceover(" in (code or "")
    )


def _voiceover_tracker_name(node: ast.With) -> str:
    for item in node.items:
        context_expr = item.context_expr
        if not isinstance(context_expr, ast.Call):
            continue
        if not _is_voiceover_call(context_expr):
            continue
        optional_vars = item.optional_vars
        if isinstance(optional_vars, ast.Name):
            return optional_vars.id
    return ""


def _is_voiceover_call(node: ast.Call) -> bool:
    func = node.func
    return (
        isinstance(func, ast.Attribute)
        and func.attr == "voiceover"
        and isinstance(func.value, ast.Name)
        and func.value.id == "self"
    )


def _is_self_method_call(node: ast.Call, name: str) -> bool:
    func = node.func
    return (
        isinstance(func, ast.Attribute)
        and func.attr == name
        and isinstance(func.value, ast.Name)
        and func.value.id == "self"
    )


def _inject_setup_layout_fallback(code: str) -> tuple[str | None, str]:
    if not _needs_setup_layout_fallback(code):
        return None, ""
    class_range = pre_render_fixes._base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines = [
        "",
        f"{indent}def setup_layout(self):",
        f'{body}if not hasattr(self, "full_canvas"):',
        f'{body}    fw = float(getattr(config, "frame_width", 14.222))',
        f'{body}    fh = float(getattr(config, "frame_height", 8.0))',
        f'{body}    margin = 0.45',
        f'{body}    self.full_canvas = {{"center": ORIGIN, "width": fw - 2 * margin, "height": fh - 2 * margin}}',
        f"{body}return None",
    ]
    lines = code.splitlines()
    lines[end:end] = helper_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "setup_layout兜底helper补全: 1处",
    )


def _needs_setup_layout_fallback(code: str) -> bool:
    return (
        "self.setup_layout(" in (code or "")
        and "class BaseConfigScene" in (code or "")
        and not _base_config_has_method(code, "setup_layout")
    )


def _inject_mathpi_runtime_fallbacks(code: str) -> tuple[str | None, str]:
    needed = _needed_mathpi_runtime_methods(code)
    if not needed:
        return None, ""
    class_range = pre_render_fixes._base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines: list[str] = []
    for name in needed:
        helper_lines.extend(_mathpi_runtime_method_lines(name, indent=indent, body=body))
    lines = code.splitlines()
    lines[end:end] = helper_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "mathpi_runtime helper补全: " + ", ".join(needed),
    )


def _needed_mathpi_runtime_methods(code: str) -> tuple[str, ...]:
    if (
        "self._mathpi_runtime_" not in (code or "")
        or "class BaseConfigScene" not in (code or "")
    ):
        return ()
    names = sorted(
        set(re.findall(r"self\.(_mathpi_runtime_[A-Za-z0-9_]+)\s*\(", code))
    )
    return tuple(
        name
        for name in names
        if not _base_config_method_is_flexible(code, name)
    )


def _mathpi_runtime_method_lines(name: str, *, indent: str, body: str) -> list[str]:
    if name == "_mathpi_runtime_column_layout":
        return [
            "",
            f"{indent}def _mathpi_runtime_column_layout(self, items=None, *args, title=None, direction=None, buff=0.18, **_kwargs):",
            f"{body}mobs = []",
            f"{body}if title:",
            f"{body}    try:",
            f"{body}        mobs.append(Text(str(title), font_size=24, color=getattr(self, 'PRIMARY_TEXT', BLACK)))",
            f"{body}    except Exception:",
            f"{body}        pass",
            f"{body}for item in (items if isinstance(items, (list, tuple)) else []):",
            f"{body}    if hasattr(item, 'move_to'):",
            f"{body}        mobs.append(item)",
            f"{body}    else:",
            f"{body}        try:",
            f"{body}            mobs.append(Text(str(item), font_size=20, color=getattr(self, 'PRIMARY_TEXT', BLACK)))",
            f"{body}        except Exception:",
            f"{body}            pass",
            f"{body}group = VGroup(*mobs) if mobs else VGroup()",
            f"{body}try:",
            f"{body}    group.arrange(direction or DOWN, buff=float(buff or 0.18), aligned_edge=LEFT)",
            f"{body}except Exception:",
            f"{body}    pass",
            f"{body}return group",
        ]
    if name == "_mathpi_runtime_visual_icon":
        return [
            "",
            f"{indent}def _mathpi_runtime_visual_icon(self, label='Icon', *args, size=0.8, color=None, **_kwargs):",
            f"{body}raise RuntimeError('MATHPI_FORBIDDEN_VISIBLE_FALLBACK: _mathpi_runtime_visual_icon is disabled; implement the real visual helper')",
        ]
    suffix = name.removeprefix("_mathpi_runtime_")
    return [
        "",
        f"{indent}def {name}(self, *args, **kwargs):",
        f"{body}target = getattr(self, {suffix!r}, None)",
        f"{body}if callable(target):",
        f"{body}    try:",
        f"{body}        return target(*args, **kwargs)",
        f"{body}    except Exception:",
        f"{body}        pass",
        f"{body}lower = {suffix!r}.lower()",
        f"{body}if any(key in lower for key in ('point', 'center', 'coord')):",
        f"{body}    return ORIGIN",
        f"{body}if any(key in lower for key in ('unit', 'vector', 'direction')):",
        f"{body}    return RIGHT",
        f"{body}if any(key in lower for key in ('scalar', 'radius', 'width', 'height', 'value')):",
        f"{body}    return 1.0",
        f"{body}return args[0] if args else VGroup()",
    ]


def _inject_safe_text_alias(code: str) -> tuple[str | None, str]:
    if (
        "self.safe_text(" not in code
        or _has_function_def(code, "safe_text")
        or "class BaseConfigScene" not in code
    ):
        return None, ""

    class_range = pre_render_fixes._base_config_scene_class_range(code)
    if not class_range:
        return None, ""
    _start, end, indent = class_range
    body = indent + "    "
    helper_lines = [
        "",
        f"{indent}def safe_text(self, text, **kwargs):",
        f"{body}return self.safe_text_box(text, **kwargs)",
    ]
    lines = code.splitlines()
    lines[end:end] = helper_lines
    return (
        "\n".join(lines) + ("\n" if code.endswith("\n") else ""),
        "safe_text别名helper补全: 1处",
    )


def _has_function_def(code: str, name: str) -> bool:
    return bool(re.search(rf"(?m)^\s*def\s+{re.escape(name)}\s*\(", code or ""))


def _base_config_has_method(code: str, name: str) -> bool:
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return False
    for node in getattr(tree, "body", []):
        if isinstance(node, ast.ClassDef) and node.name == "BaseConfigScene":
            return any(
                isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                and item.name == name
                for item in node.body
            )
    return False


def _base_config_method_is_flexible(code: str, name: str) -> bool:
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return False
    for node in getattr(tree, "body", []):
        if not isinstance(node, ast.ClassDef) or node.name != "BaseConfigScene":
            continue
        methods = [
            item
            for item in node.body
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
            and item.name == name
        ]
        if not methods:
            return False
        method = methods[-1]
        return bool(method.args.vararg and method.args.kwarg)
    return False
