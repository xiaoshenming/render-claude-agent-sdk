"""Evidence-only post-patch diagnostics with compatibility exports."""
# ruff: noqa: F401

from __future__ import annotations

import ast

from .post_patch_contracts import (
    COMMON_POST_PATCH_HELPERS,
    GEOMETRY_ALLOWED_POINT_NAMES,
    GEOMETRY_NUMERIC_CALLS,
    PostPatchGuardIssue,
)
from .post_patch_validation import (
    _MissingCommonHelperVisitor,
    _ast_full_name,
    _bound_names_for_guard,
    _class_method_index,
    _class_name,
    _dedupe_guard_issues,
    _geometry_numeric_guard_issues,
    _is_float_nan_call,
    _is_unbound_geometry_point_name,
    _is_zero_literal,
    _load_names_in_positional_args,
    _methods_for_class,
    _missing_common_helper_calls,
)


def scan_post_patch_guard(
    full_code: str,
    *,
    scene_name: str,
    undefined_names: list[str] | None = None,
    syntax_only: bool = False,
) -> list[PostPatchGuardIssue]:
    try:
        tree = ast.parse(full_code or "")
    except SyntaxError as exc:
        line = exc.lineno or 1
        offset = exc.offset or 0
        return [
            PostPatchGuardIssue(
                code="syntax_error",
                message=f"SyntaxError: {exc.msg} at line {line}:{offset}",
                metadata={"lineno": line, "offset": offset, "scene_name": scene_name},
            )
        ]

    if syntax_only:
        return []

    issues: list[PostPatchGuardIssue] = []
    helper_issues = _missing_common_helper_calls(tree)
    if helper_issues:
        helpers = sorted({issue["helper"] for issue in helper_issues})
        evidence = "; ".join(issue["evidence"] for issue in helper_issues[:8])
        issues.append(
            PostPatchGuardIssue(
                code="helper_missing",
                message="修复后仍调用未定义 helper: " + evidence,
                metadata={"helpers": helpers, "scene_name": scene_name},
            )
        )

    if undefined_names:
        names = sorted(set(undefined_names))
        issues.append(
            PostPatchGuardIssue(
                code="static_undefined_name",
                message="修复后仍引用未定义变量: " + ",".join(names[:5]),
                metadata={"names": names, "scene_name": scene_name},
            )
        )

    geometry_issues = _geometry_numeric_guard_issues(tree)
    if geometry_issues:
        issues.append(
            PostPatchGuardIssue(
                code="geometry_numeric",
                message="; ".join(geometry_issues[:10]),
                metadata={"issues": geometry_issues[:10], "scene_name": scene_name},
            )
        )

    return issues


def first_post_patch_guard_error(
    full_code: str,
    *,
    scene_name: str,
    undefined_names: list[str] | None = None,
) -> str | None:
    issues = scan_post_patch_guard(
        full_code,
        scene_name=scene_name,
        undefined_names=undefined_names,
    )
    if not issues:
        return None
    return issues[0].reason
