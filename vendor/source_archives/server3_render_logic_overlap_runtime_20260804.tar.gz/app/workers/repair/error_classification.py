"""Render error classification and context normalization."""

import logging
import os
import re
from datetime import datetime

logger = logging.getLogger("render")


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


# ─── 错误分析 ──────────────────────────────────────────


def extract_render_error(
    stderr: str, stdout: str, output_dir: str, media_root: str
) -> str:
    """从渲染失败中提取有用的错误信息。
    优先读取 LaTeX .log 文件获取真正错误，
    否则从 stderr/stdout 提取关键行。
    结果限制在 800 字符以内，避免挤爆修复 prompt。
    """
    MAX_LEN = 800

    # 1. 尝试从 stderr/stdout 中找 .log 文件路径并读取
    log_path_match = re.search(r"(/[^\s]+\.log)", stderr + stdout)
    if log_path_match:
        log_path = log_path_match.group(1)
        host_log = log_path
        if log_path.startswith("/media/"):
            host_log = os.path.join(media_root, log_path[len("/media/") :].lstrip("/"))
        try:
            if os.path.exists(host_log):
                with open(host_log, "r", errors="ignore") as f:
                    log_content = f.read()
                error_lines = []
                for line in log_content.split("\n"):
                    ll = line.strip()
                    if (
                        ll.startswith("!")
                        or "Error" in ll
                        or "Undefined" in ll
                        or "Missing" in ll
                        or "Extra" in ll
                    ):
                        error_lines.append(ll)
                if error_lines:
                    result = "LaTeX编译错误:\n" + "\n".join(error_lines[:10])
                    logger.info(
                        f"[RENDER] [{_ts()}] 从 .log 提取到 {len(error_lines)} 行错误"
                    )
                    return result[:MAX_LEN]
        except Exception as e:
            logger.warning(f"[RENDER] [{_ts()}] 读取 .log 失败: {e}")

    # 2. 从 stderr 提取 Python 异常信息
    lines = stderr.strip().split("\n")
    error_lines = []
    for line in reversed(lines):
        stripped = line.strip()
        if not stripped:
            continue
        error_lines.insert(0, stripped)
        if re.match(r"\w+Error:", stripped) or re.match(r"\w+Exception:", stripped):
            break
        if len(error_lines) >= 15:
            break

    if error_lines:
        return "\n".join(error_lines)[:MAX_LEN]

    # 3. fallback
    if stderr.strip():
        return stderr.strip()[-200:]
    return "unknown render error"


def error_signature(error: str) -> str:
    """提取错误类型签名（忽略行号等变化部分）"""
    lower_error = error.lower()
    if (
        "xelatex error converting to xdv" in lower_error
        or "latex error converting to dvi" in lower_error
        or "latex compilation error" in lower_error
        or "tex compilation error" in lower_error
    ):
        return "LatexCompilationError"
    m = re.search(r"(\w+Error):\s*(.*?)(?:\n|$)", error)
    if m:
        err_type = m.group(1)
        detail = m.group(2)[:30]
        return f"{err_type}:{detail}"
    if "Tex" in error and ".log" in error:
        return "TexCompilationError"
    if "未找到输出" in error or "not found" in error.lower():
        return "OutputNotFound"
    return error[:50]


def extract_error_context(code: str, error_msg: str, context_lines: int = 30) -> str:
    """提取错误附近的代码，而不是发全量代码给 LLM。"""
    line_match = re.search(r"line (\d+)", error_msg)
    if not line_match:
        return code

    error_line = int(line_match.group(1))
    lines = code.split("\n")

    if error_line > len(lines):
        return code

    start = max(0, error_line - context_lines - 1)
    end = min(len(lines), error_line + context_lines)

    context = "\n".join(lines[start:end])
    logger.info(
        f"[SYNTAX-FIX] [{_ts()}] 提取错误上下文: "
        f"行 {start + 1}-{end} (共 {end - start} 行，"
        f"原始 {len(lines)} 行)"
    )
    return context


def _restore_missing_header(original_code: str, fixed_code: str) -> str:
    """如果 LLM 返回了 BaseConfigScene/Scene 代码但丢了 import/header，则补回原始头部。"""
    stripped = (fixed_code or "").lstrip()
    if "from manim import *" in fixed_code:
        return fixed_code
    if "from manim import *" not in original_code:
        return fixed_code

    # 既支持直接从 class 开头的返回，也支持 helper 函数在前、Scene 类在后的返回。
    has_scene_or_helper = bool(
        re.search(
            r"(?m)^(class\s+\w+\s*\(|def\s+(create_right_angle_mark|get_outward_square)\s*\()",
            stripped,
        )
    )
    if not has_scene_or_helper:
        return fixed_code

    first_class = re.search(r"^class\s+\w+\s*\(", original_code, re.MULTILINE)
    if not first_class:
        return fixed_code

    header = original_code[: first_class.start()].rstrip()
    if not header:
        return fixed_code
    return f"{header}\n\n{fixed_code.lstrip()}"
