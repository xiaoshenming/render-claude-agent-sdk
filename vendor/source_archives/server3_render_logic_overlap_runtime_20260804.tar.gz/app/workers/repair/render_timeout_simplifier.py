from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class RenderTimeoutSimplifyResult:
    code: str
    actions: tuple[dict[str, Any], ...]

    @property
    def changed(self) -> bool:
        return bool(self.actions)


def simplify_render_timeout_scene(
    full_code: str,
    *,
    scene_name: str,
) -> RenderTimeoutSimplifyResult:
    """Reduce known Manim timeout amplifiers in one scene.

    This is a repair step, not a quality gate: it only rewrites local timing and
    loop-count knobs that make an already generated scene too expensive to
    render. If no deterministic simplification is safe, it returns the original
    code and lets the existing LLM scene-regeneration path continue.
    """

    if not full_code or scene_name not in full_code:
        return RenderTimeoutSimplifyResult(code=full_code or "", actions=())
    try:
        tree = ast.parse(full_code)
    except SyntaxError:
        return RenderTimeoutSimplifyResult(code=full_code, actions=())

    replacements: list[tuple[int, int, int, str, dict[str, Any]]] = []

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.in_target_scene = False
            self.function_depth = 0

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            was_target = self.in_target_scene
            self.in_target_scene = node.name == scene_name
            try:
                self.generic_visit(node)
            finally:
                self.in_target_scene = was_target

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.function_depth += 1
            try:
                self.generic_visit(node)
            finally:
                self.function_depth -= 1

        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_Call(self, node: ast.Call) -> None:
            if self.in_target_scene and self.function_depth > 0:
                _collect_wait_replacement(node, replacements)
                _collect_play_run_time_replacement(node, replacements)
                _collect_range_replacement(node, replacements)
            self.generic_visit(node)

    Visitor().visit(tree)
    if not replacements:
        return RenderTimeoutSimplifyResult(code=full_code, actions=())

    lines = full_code.splitlines()
    actions: list[dict[str, Any]] = []
    applied_spans: set[tuple[int, int, int]] = set()
    for line_index, start, end, replacement, action in sorted(
        replacements,
        key=lambda item: (item[0], item[1]),
        reverse=True,
    ):
        span = (line_index, start, end)
        if span in applied_spans or line_index < 0 or line_index >= len(lines):
            continue
        applied_spans.add(span)
        lines[line_index] = (
            lines[line_index][:start] + replacement + lines[line_index][end:]
        )
        actions.append(action)
    actions.reverse()
    fixed = "\n".join(lines) + ("\n" if full_code.endswith("\n") else "")
    return RenderTimeoutSimplifyResult(code=fixed, actions=tuple(actions))


def _collect_wait_replacement(
    node: ast.Call,
    replacements: list[tuple[int, int, int, str, dict[str, Any]]],
) -> None:
    if not _is_self_method(node, "wait") or not node.args:
        return
    value = _numeric_constant(node.args[0])
    if value is None or value <= 0.5:
        return
    _append_expr_replacement(
        node.args[0],
        "0.2",
        replacements,
        {"method": "clamp_wait", "from": value, "to": 0.2},
    )


def _collect_play_run_time_replacement(
    node: ast.Call,
    replacements: list[tuple[int, int, int, str, dict[str, Any]]],
) -> None:
    if not _is_self_method(node, "play"):
        return
    for keyword in node.keywords:
        if keyword.arg != "run_time":
            continue
        value = _numeric_constant(keyword.value)
        if value is None or value <= 1.0:
            continue
        _append_expr_replacement(
            keyword.value,
            "0.6",
            replacements,
            {"method": "clamp_play_run_time", "from": value, "to": 0.6},
        )


def _collect_range_replacement(
    node: ast.Call,
    replacements: list[tuple[int, int, int, str, dict[str, Any]]],
) -> None:
    if not isinstance(node.func, ast.Name) or node.func.id != "range":
        return
    if len(node.args) != 1:
        return
    value = _numeric_constant(node.args[0])
    if value is None or value <= 36:
        return
    target = 24
    _append_expr_replacement(
        node.args[0],
        str(target),
        replacements,
        {"method": "cap_range_loop", "from": value, "to": target},
    )


def _append_expr_replacement(
    node: ast.AST,
    replacement: str,
    replacements: list[tuple[int, int, int, str, dict[str, Any]]],
    action: dict[str, Any],
) -> None:
    if getattr(node, "end_col_offset", None) is None:
        return
    replacements.append(
        (
            node.lineno - 1,
            node.col_offset,
            node.end_col_offset,
            replacement,
            action,
        )
    )


def _is_self_method(node: ast.Call, method_name: str) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == method_name
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _numeric_constant(node: ast.AST) -> float | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    return None
