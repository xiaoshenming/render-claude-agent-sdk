"""Static syntax/text compatibility entrypoints for pre-render repair.

This layer may only contain deterministic Python/text-string repairs. It must
not add subject-specific geometry helpers or generated-scene business logic.
"""

from app.workers.repair.pre_render_text_fixes import (
    _fix_hallucinated_self_safe_call,
    _fix_markup_br_tags_in_string_literals,
    _fix_nested_ascii_quotes,
    _fix_raw_string_trailing_backslash,
    _fix_unicode_brace_escapes,
    _strip_markdown_code_fence,
)

__all__ = [
    "_fix_hallucinated_self_safe_call",
    "_fix_markup_br_tags_in_string_literals",
    "_fix_nested_ascii_quotes",
    "_fix_raw_string_trailing_backslash",
    "_fix_unicode_brace_escapes",
    "_strip_markdown_code_fence",
]
