from __future__ import annotations

from dataclasses import dataclass
from typing import Any


COMMON_POST_PATCH_HELPERS = frozenset(
    {
        "fit_to_canvas",
        "play_steps_evenly",
        "play_synced_steps",
        "safe_text",
        "safe_text_box",
    }
)
GEOMETRY_NUMERIC_CALLS = frozenset(
    {
        "Angle",
        "Arrow",
        "BraceBetweenPoints",
        "DashedLine",
        "Dot",
        "DoubleArrow",
        "Line",
        "Polygon",
        "RightAngle",
        "math.dist",
        "np.linalg.norm",
        "numpy.linalg.norm",
    }
)
GEOMETRY_ALLOWED_POINT_NAMES = frozenset(
    {
        "ORIGIN",
        "UP",
        "DOWN",
        "LEFT",
        "RIGHT",
        "UL",
        "UR",
        "DL",
        "DR",
        "IN",
        "OUT",
        "PI",
        "TAU",
        "DEGREES",
        "WHITE",
        "BLACK",
        "GRAY",
        "GREY",
        "RED",
        "GREEN",
        "BLUE",
        "YELLOW",
        "ORANGE",
        "PURPLE",
        "PINK",
        "TEAL",
        "GOLD",
    }
)


@dataclass(frozen=True)
class PostPatchGuardIssue:
    code: str
    message: str
    metadata: dict[str, Any]

    @property
    def reason(self) -> str:
        names = self.metadata.get("helpers") or self.metadata.get("names")
        if self.code in {"helper_missing", "static_undefined_name"} and names:
            suffix = f"{self.code}:{','.join(list(names)[:5])}"
        else:
            suffix = self.code
        return "deterministic_guard_failed:" + suffix

    def diagnostic(self) -> str:
        return f"{self.reason}: {self.message}"
