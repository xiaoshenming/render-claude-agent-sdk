"""Structured repair lanes and no-progress tracking for slice repair.

This module is intentionally pure: it does not call Manim, LLMs, Docker, or
storage. Runtime repair, math-logic repair, and layout repair can share these
contracts without sharing execution budgets.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.workers.repair import repair_progress as _progress

RepairLane = _progress.RepairLane
RepairProgressDecision = _progress.RepairProgressDecision
RepairProgressTracker = _progress.RepairProgressTracker
RepairStrategy = _progress.RepairStrategy
classify_repair_lane = _progress.classify_repair_lane
code_hash = _progress.code_hash
next_strategy_after = _progress.next_strategy_after
strategy_escalation_decision = _progress.strategy_escalation_decision


@dataclass(frozen=True)
class BackhalfRepairBudget:
    enabled: bool = False
    per_job_llm_calls: int = 8
    per_scene_slice_fix_patch: int = 2
    per_scene_slice_fix: int = 1
    per_scene_quality_multimodal_review: int = 1
    per_scene_same_signature: int = 1


@dataclass(frozen=True)
class BackhalfRepairCallDecision:
    allowed: bool
    reason: str
    call_type: str
    scene_name: str
    job_llm_calls: int
    scene_call_count: int
    signature_hit_count: int = 0


_BACKHALF_BUDGET_KEY = "_backhalf_repair_budget"
_BACKHALF_BUDGET_EVENTS_KEY = "_backhalf_repair_budget_events"
_BACKHALF_LLM_CALL_TYPES = {
    "math_logic_fast",
    "layout_judge",
    "slice_fix_patch",
    "slice_fix",
    "quality_multimodal_review",
}


def _budget_limit_for_call_type(
    budget: BackhalfRepairBudget,
    call_type: str,
) -> int | None:
    if call_type == "slice_fix_patch":
        return budget.per_scene_slice_fix_patch
    if call_type == "slice_fix":
        return budget.per_scene_slice_fix
    if call_type == "quality_multimodal_review":
        return budget.per_scene_quality_multimodal_review
    return None


def _budget_store(task_data: dict[str, Any]) -> dict[str, Any]:
    store = task_data.setdefault(_BACKHALF_BUDGET_KEY, {})
    if not isinstance(store, dict):
        store = {}
        task_data[_BACKHALF_BUDGET_KEY] = store
    store.setdefault("job_llm_calls", 0)
    store.setdefault("scene_calls", {})
    store.setdefault("signature_hits", {})
    return store


def _budget_key(scene_name: str, call_type: str) -> str:
    return f"{scene_name or 'unknown'}:{call_type or 'unknown'}"


def _signature_key(scene_name: str, call_type: str, signature: str) -> str:
    digest = code_hash(signature) if len(signature) > 120 else signature
    return f"{scene_name or 'unknown'}:{call_type or 'unknown'}:{digest}"


def record_backhalf_repair_call(
    task_data: dict[str, Any] | None,
    *,
    scene_name: str,
    call_type: str,
    signature: str | None = None,
    budget: BackhalfRepairBudget | None = None,
) -> BackhalfRepairCallDecision:
    """Record a high-cost back-half repair call and return budget decision.

    This helper is intentionally pure-ish and stateful only through task_data so
    layout, slice repair, and multimodal review share one stop-loss contract.
    """
    call_type = str(call_type or "unknown")
    scene_name = str(scene_name or "unknown")
    budget = budget or BackhalfRepairBudget()
    if task_data is None:
        return BackhalfRepairCallDecision(
            allowed=True,
            reason="no_task_data",
            call_type=call_type,
            scene_name=scene_name,
            job_llm_calls=0,
            scene_call_count=0,
        )

    store = _budget_store(task_data)
    scene_calls = store.setdefault("scene_calls", {})
    signature_hits = store.setdefault("signature_hits", {})
    if not isinstance(scene_calls, dict):
        scene_calls = {}
        store["scene_calls"] = scene_calls
    if not isinstance(signature_hits, dict):
        signature_hits = {}
        store["signature_hits"] = signature_hits

    job_calls = int(store.get("job_llm_calls") or 0)
    scene_key = _budget_key(scene_name, call_type)
    scene_count = int(scene_calls.get(scene_key) or 0)
    sig_count = 0
    sig_key = ""
    if signature:
        sig_key = _signature_key(scene_name, call_type, str(signature))
        sig_count = int(signature_hits.get(sig_key) or 0)

    counts_as_job_llm = call_type in _BACKHALF_LLM_CALL_TYPES
    if not budget.enabled:
        if counts_as_job_llm:
            job_calls += 1
            store["job_llm_calls"] = job_calls
        scene_count += 1
        scene_calls[scene_key] = scene_count
        if sig_key:
            sig_count += 1
            signature_hits[sig_key] = sig_count
        decision = BackhalfRepairCallDecision(
            allowed=True,
            reason="budget_disabled",
            call_type=call_type,
            scene_name=scene_name,
            job_llm_calls=job_calls,
            scene_call_count=scene_count,
            signature_hit_count=sig_count,
        )
        _record_backhalf_budget_event(task_data, decision, signature=signature)
        return decision

    if signature:
        if sig_count >= budget.per_scene_same_signature:
            decision = BackhalfRepairCallDecision(
                allowed=False,
                reason="same_signature_no_progress",
                call_type=call_type,
                scene_name=scene_name,
                job_llm_calls=job_calls,
                scene_call_count=scene_count,
                signature_hit_count=sig_count,
            )
            _record_backhalf_budget_event(task_data, decision, signature=signature)
            return decision

    per_scene_limit = _budget_limit_for_call_type(budget, call_type)
    if per_scene_limit is not None and scene_count >= per_scene_limit:
        decision = BackhalfRepairCallDecision(
            allowed=False,
            reason=f"per_scene_{call_type}_budget_exceeded",
            call_type=call_type,
            scene_name=scene_name,
            job_llm_calls=job_calls,
            scene_call_count=scene_count,
            signature_hit_count=sig_count,
        )
        _record_backhalf_budget_event(task_data, decision, signature=signature)
        return decision

    if counts_as_job_llm and job_calls >= budget.per_job_llm_calls:
        decision = BackhalfRepairCallDecision(
            allowed=False,
            reason="per_job_llm_budget_exceeded",
            call_type=call_type,
            scene_name=scene_name,
            job_llm_calls=job_calls,
            scene_call_count=scene_count,
            signature_hit_count=sig_count,
        )
        _record_backhalf_budget_event(task_data, decision, signature=signature)
        return decision

    if counts_as_job_llm:
        job_calls += 1
        store["job_llm_calls"] = job_calls
    scene_count += 1
    scene_calls[scene_key] = scene_count
    if sig_key:
        sig_count += 1
        signature_hits[sig_key] = sig_count

    decision = BackhalfRepairCallDecision(
        allowed=True,
        reason="recorded",
        call_type=call_type,
        scene_name=scene_name,
        job_llm_calls=job_calls,
        scene_call_count=scene_count,
        signature_hit_count=sig_count,
    )
    _record_backhalf_budget_event(task_data, decision, signature=signature)
    return decision


def _record_backhalf_budget_event(
    task_data: dict[str, Any],
    decision: BackhalfRepairCallDecision,
    *,
    signature: str | None,
) -> None:
    events = task_data.setdefault(_BACKHALF_BUDGET_EVENTS_KEY, [])
    if not isinstance(events, list):
        events = []
        task_data[_BACKHALF_BUDGET_EVENTS_KEY] = events
    events.append(
        {
            "allowed": decision.allowed,
            "reason": decision.reason,
            "scene_name": decision.scene_name,
            "call_type": decision.call_type,
            "job_llm_calls": decision.job_llm_calls,
            "scene_call_count": decision.scene_call_count,
            "signature_hit_count": decision.signature_hit_count,
            "signature": (signature or "")[:240],
        }
    )
