"""Compatibility facade for repair error patterns."""
from .error_patterns_constants import *
from .error_patterns_fixes import *
from .error_patterns_dispatch import *
