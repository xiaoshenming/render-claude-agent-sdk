"""Deterministic repair-first handling for truncated generated code."""

import ast
import logging
from typing import Optional

from .error_classification import _ts

logger = logging.getLogger("render")


def has_empty_call_after_truncation(code: str) -> bool:
    """检测截断补全后是否产生了空参数函数调用。
    典型案例：always_redraw( 被截断 → 补 ) → always_redraw() 缺少参数。
    检查代码最后 10 行是否存在这类明显的空调用。
    """
    must_have_args = (
        "always_redraw()",
        "Tex()",
        "MathTex()",
        "Text()",
        "Write()",
        "Create()",
        "FadeIn()",
        "FadeOut()",
        "Transform()",
        "ReplacementTransform()",
        "Dot()",
        "Line()",
        "Circle()",
        "Arrow()",
        "VGroup()",
        "Polygon()",
        "Arc()",
        "ValueTracker()",
        "Indicate()",
    )
    tail = "\n".join(code.strip().split("\n")[-10:])
    for pattern in must_have_args:
        if pattern in tail:
            return True
    return False


def auto_fix_truncation(code: str, error_msg: str) -> Optional[str]:
    """自动修复 LLM 输出截断导致的语法错误。
    截断特征：代码末尾括号/引号未闭合。
    不需要 LLM，程序直接补全。
    """
    truncation_patterns = [
        "'(' was never closed",
        "'[' was never closed",
        "'{' was never closed",
        "unterminated string literal",
        "unexpected EOF while parsing",
        "EOF while scanning",
        "expected an indented block",
    ]
    if not any(p in error_msg for p in truncation_patterns):
        return None

    logger.info(f"[SYNTAX-FIX] [{_ts()}] 检测到截断类错误，尝试自动补全")

    # 策略 1：找到最后一个完整的 class 定义，截断后面的不完整代码
    lines = code.split("\n")
    for i in range(len(lines) - 1, -1, -1):
        line = lines[i].strip()
        if line and not line.startswith("#") and line.endswith(")"):
            try:
                partial = "\n".join(lines[: i + 1])
                open_parens = partial.count("(") - partial.count(")")
                open_brackets = partial.count("[") - partial.count("]")
                open_braces = partial.count("{") - partial.count("}")
                closing = ")" * max(0, open_parens)
                closing += "]" * max(0, open_brackets)
                closing += "}" * max(0, open_braces)
                candidate = partial + closing + "\n"
                ast.parse(candidate)
                logger.info(
                    f"[SYNTAX-FIX] [{_ts()}] 自动截断到第 {i + 1} 行"
                    f"，补全 '{closing}' 后语法正确"
                )
                return candidate
            except SyntaxError:
                continue

    # 策略 2：简单补全
    open_parens = code.count("(") - code.count(")")
    open_brackets = code.count("[") - code.count("]")
    open_braces = code.count("{") - code.count("}")

    if open_parens > 0 or open_brackets > 0 or open_braces > 0:
        trimmed = code.rstrip()
        for quote in ['"""', "'''", '"', "'"]:
            if trimmed.count(quote) % 2 != 0:
                trimmed = "\n".join(trimmed.split("\n")[:-1])
                break

        closing = ")" * max(0, open_parens)
        closing += "]" * max(0, open_brackets)
        closing += "}" * max(0, open_braces)
        candidate = trimmed + closing + "\n"
        try:
            ast.parse(candidate)
            logger.info(f"[SYNTAX-FIX] [{_ts()}] 简单补全成功: 补充 '{closing}'")
            return candidate
        except SyntaxError:
            pass

    return None
