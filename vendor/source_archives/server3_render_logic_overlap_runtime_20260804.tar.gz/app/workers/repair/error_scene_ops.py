"""Scene code replacement and render-cache result helpers."""

import hashlib
import logging
import os
import re
from typing import Optional

from .error_classification import _ts

logger = logging.getLogger("render")


def replace_scene_code(full_code: str, scene_name: str, new_scene_code: str) -> str:
    """在完整代码中替换指定 Scene 类的代码，保留其他部分不变。

    旧实现使用 ``new_scene_code.strip()`` 会一并吃掉新片段尾部的空行，
    而正则 ``(?=\\nclass...)`` 又只保留下一个 class 前的最后一个 ``\\n``，
    导致每次切片修复后相邻两个 Scene 之间的空行从 2 个被压缩到 0~1 个，
    多轮修复会让 Scene 互相紧贴，LLM 在拿上下文修后续切片时把
    "上一个 Scene 的尾巴"误当成本场景前置代码 → 产生切片间内容污染。

    本函数保证：
    - 中间 scene 替换：与下一个 class 之间恰好 2 个空行（PEP8 顶层 class 间距）
    - 末尾 scene 替换：保留与原文件一致的尾随换行（最多 1 个）
    - 多次连续替换是幂等的，不会让 scene 互相紧贴
    """
    pattern = (
        rf"(class\s+{re.escape(scene_name)}\s*\([^)]*\)\s*:.*?)(?=\nclass\s+\w|\Z)"
    )
    match = re.search(pattern, full_code, re.DOTALL)
    if not match:
        raise ValueError(f"Cannot find {scene_name} in code")
    # 去掉新片段所有前导/尾随空白：由本函数统一控制 scene 间分隔符。
    # 顶层 class 始终从第 0 列开始，不会有"必须保留"的前导空白。
    body = new_scene_code.strip()
    prefix = full_code[: match.start()]
    suffix = full_code[match.end() :]
    if suffix.lstrip("\n").startswith("class"):
        # 后面还有兄弟 class：归一化为 PEP8 推荐的 2 个空行（共 3 个 \n）。
        # suffix 由 lookahead 保留了 1 个 \n（紧贴 "class"），这里再前置 2 个 \n。
        normalized_suffix = "\n" + suffix.lstrip("\n")
        return prefix + body + "\n\n" + normalized_suffix
    # 末尾 scene：保持与原文件相同的尾随换行（最多 1 个）。
    trailing = "\n" if full_code.endswith("\n") else ""
    return prefix + body + trailing


def extract_scene_code(full_code: str, scene_name: str) -> Optional[str]:
    """从完整代码中提取指定 Scene 类的代码段"""
    pattern = (
        rf"(class\s+{re.escape(scene_name)}\s*\([^)]*\)\s*:.*?)(?=\nclass\s+\w|\Z)"
    )
    match = re.search(pattern, full_code, re.DOTALL)
    return match.group(1).strip() if match else None


# ─── 场景缓存 ──────────────────────────────────────────


def scene_cache_key(scene_code: str, aspect_ratio: str) -> str:
    """计算 Scene 代码的缓存 key"""
    content = f"{scene_code}|{aspect_ratio}"
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def check_scene_cache(
    scene_code: str, aspect_ratio: str, cache_dir: str
) -> Optional[bytes]:
    """检查 Scene 渲染缓存，命中返回 video bytes，未命中返回 None"""
    key = scene_cache_key(scene_code, aspect_ratio)
    cache_path = os.path.join(cache_dir, f"{key}.mp4")
    if os.path.exists(cache_path):
        with open(cache_path, "rb") as f:
            return f.read()
    return None


def save_scene_cache(
    scene_code: str, aspect_ratio: str, video_bytes: bytes, cache_dir: str
):
    """保存 Scene 渲染结果到缓存"""
    key = scene_cache_key(scene_code, aspect_ratio)
    cache_path = os.path.join(cache_dir, f"{key}.mp4")
    try:
        with open(cache_path, "wb") as f:
            f.write(video_bytes)
    except Exception as e:
        logger.warning(f"[CACHE] [{_ts()}] 缓存写入失败: {e}")
