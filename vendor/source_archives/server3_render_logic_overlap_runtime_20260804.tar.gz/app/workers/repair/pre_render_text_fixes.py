"""Pure text/string-level pre-render repairs.

This module intentionally stays independent from Manim runtime helpers.  It is
safe to import from the pre-render facade and from focused unit tests.
"""

import ast
import io
import re
import tokenize
from typing import Optional, Tuple

_UNICODE_BRACE_RE = re.compile(r"\\u\{([0-9a-fA-F]+)\}")
_MATHTEX_PLAIN_STRING_ARG_RE = re.compile(
    r"(?P<prefix>\b(?:MathTex|Tex)\(\s*)"
    r"(?P<quote>['\"])(?P<body>(?:\\.|(?!['\"]).)*?)(?P=quote)"
)
_INLINE_MATH_PLAIN_STRING_ARG_RE = re.compile(
    r"(?P<prefix>\b(?:self\.)?(?:inline_math_text|safe_math|safe_math_box)\(\s*)"
    r"(?P<quote>['\"])(?P<body>(?:\\.|(?!['\"]).)*?)(?P=quote)"
)
_INLINE_MATH_TUPLE_STRING_RE = re.compile(
    r"(?P<prefix>\(\s*['\"]math['\"]\s*,\s*)"
    r"(?P<raw>[rR]?)(?P<quote>['\"])(?P<body>(?:\\.|(?!['\"]).)*?)(?P=quote)"
)
_SINGLE_LATEX_COMMAND_ESCAPE_RE = re.compile(r"(?<!\\)\\[A-Za-z]+")
_SELF_SAFE_CALL_RE = re.compile(r"\bself\.safe\(")
_MARKDOWN_CODE_FENCE_RE = re.compile(
    r"^\s*```(?:python|Python|py)?\s*\n?(?P<body>[\s\S]*?)\n?```\s*$"
)
_MARKUP_BR_TAG_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)
_RAW_STRING_TRAILING_BACKSLASH_RE = re.compile(
    r"(?<!\w)(?P<prefix>[rR])(?P<quote>['\"])(?P<body>.*?)(?P<slashes>\\+)(?P=quote)"
)
_LATEX_OVERESCAPED_CMD_RE = re.compile(
    r"\\{2,}(?=("
    r"alpha|beta|gamma|delta|theta|pi|infty|"
    r"le|leq|ge|geq|ne|neq|approx|equiv|pm|mp|"
    r"times|cdot|div|frac|dfrac|tfrac|sqrt|"
    r"sin|cos|tan|log|ln|lim|sum|prod|int|"
    r"vec|hat|bar|tilde|overline|underline|overrightarrow|"
    r"left|right|to|mapsto|rightarrow|leftarrow|leftrightarrow|longrightarrow|"
    r"Rightarrow|Leftarrow|Leftrightarrow|Longrightarrow|Longleftrightarrow|"
    r"implies|iff|"
    r"angle|perp|parallel|circ|degree|"
    r"text|mathrm|mathbf|mathit|mathbb|mathcal|"
    r"begin|end"
    r")\b)"
)


def _strip_markdown_code_fence(code: str) -> Tuple[Optional[str], str]:
    """Remove a full Markdown code fence wrapper around generated Python."""
    match = _MARKDOWN_CODE_FENCE_RE.match(code)
    if not match:
        return None, ""
    body = match.group("body").strip("\n")
    return body + ("\n" if code.endswith("\n") else ""), "Markdown代码围栏清理: 1处"


def _fix_markup_br_tags_in_string_literals(code: str) -> Tuple[Optional[str], str]:
    """Pango markup used by Manim accepts newlines, not HTML <br> tags."""
    if "<br" not in code.lower():
        return None, ""
    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(code).readline))
    except (tokenize.TokenError, IndentationError):
        return None, ""

    changed = 0
    rewritten: list[tokenize.TokenInfo] = []
    for token in tokens:
        if token.type == tokenize.STRING and "<br" in token.string.lower():
            replaced = _MARKUP_BR_TAG_RE.sub(r"\\n", token.string)
            if replaced != token.string:
                token = token._replace(string=replaced)
                changed += 1
        rewritten.append(token)
    if changed == 0:
        return None, ""
    return tokenize.untokenize(rewritten), f"Markup br标签换行修复: {changed}处"


def _fix_unicode_brace_escapes(code: str) -> Tuple[Optional[str], str]:
    r"""Replace JS/Swift style ``\u{1F4CF}`` escapes with Python escapes."""

    def _replacer(match: re.Match) -> str:
        hex_val = match.group(1)
        if len(hex_val) <= 4:
            return f"\\u{hex_val.zfill(4)}"
        return f"\\U{hex_val.zfill(8)}"

    modified = _UNICODE_BRACE_RE.sub(_replacer, code)
    if modified != code:
        count = len(_UNICODE_BRACE_RE.findall(code))
        return modified, f"修复 {count} 处 \\u{{}} -> \\UXXXXXXXX"
    return None, ""


def _fix_mathtex_plain_string_latex_escapes(code: str) -> Tuple[Optional[str], str]:
    """Prefix MathTex/Tex string literals with r when they contain LaTeX commands."""
    if (
        "MathTex(" not in code
        and "Tex(" not in code
        and "inline_math_text(" not in code
        and "safe_math(" not in code
        and "safe_math_box(" not in code
    ):
        return None, ""

    fix_count = 0

    def _replace(match: re.Match) -> str:
        nonlocal fix_count
        body = match.group("body")
        if not _SINGLE_LATEX_COMMAND_ESCAPE_RE.search(body):
            return match.group(0)
        if body.endswith("\\") and not body.endswith("\\\\"):
            return match.group(0)
        fix_count += 1
        return f"{match.group('prefix')}r{match.group('quote')}{body}{match.group('quote')}"

    modified = _MATHTEX_PLAIN_STRING_ARG_RE.sub(_replace, code)
    modified = _INLINE_MATH_PLAIN_STRING_ARG_RE.sub(_replace, modified)
    if not fix_count or modified == code:
        return None, ""
    return modified, f"MathTex/Tex普通字符串LaTeX转raw: {fix_count}处"


def _latex_has_aligned_begin(value: str) -> bool:
    stripped = value.strip()
    return (
        stripped.startswith("\\begin{aligned}")
        or stripped.startswith("\\\\begin{aligned}")
        or stripped.startswith("\\begin{align*}")
        or stripped.startswith("\\\\begin{align*}")
    )


def _latex_has_aligned_end(value: str) -> bool:
    return (
        "\\end{aligned}" in value
        or "\\\\end{aligned}" in value
        or "\\end{align*}" in value
        or "\\\\end{align*}" in value
    )


def _normalize_overescaped_latex_commands(value: str) -> tuple[str, bool]:
    """Collapse LLM-overescaped LaTeX commands while preserving line breaks."""
    if _latex_has_aligned_begin(value) and _latex_has_aligned_end(value):
        return value, False
    fixed = _LATEX_OVERESCAPED_CMD_RE.sub(r"\\", value)
    return fixed, fixed != value


def _fix_inline_math_tuple_overescaped_latex_commands(
    code: str,
) -> Tuple[Optional[str], str]:
    """Collapse overescaped LaTeX commands inside inline_math_text math tuples."""
    if '"math"' not in code and "'math'" not in code:
        return None, ""

    fix_count = 0

    def _replace(match: re.Match) -> str:
        nonlocal fix_count
        body = match.group("body")
        normalized, changed = _normalize_overescaped_latex_commands(body)
        if not changed:
            return match.group(0)
        fix_count += 1
        quote = match.group("quote")
        return f"{match.group('prefix')}r{quote}{normalized}{quote}"

    modified = _INLINE_MATH_TUPLE_STRING_RE.sub(_replace, code)
    if not fix_count or modified == code:
        return None, ""
    return modified, f"inline_math_text数学参数过度转义修复: {fix_count}处"


def _fix_hallucinated_self_safe_call(code: str) -> Tuple[Optional[str], str]:
    modified, count = _SELF_SAFE_CALL_RE.subn("self.safe_text_box(", code)
    if count and modified != code:
        return modified, f"self.safe幻觉调用修复: {count}处"
    return None, ""


def _fix_nested_ascii_quotes(code: str) -> Tuple[Optional[str], str]:
    """Repair nested ASCII quotes that break generated Python strings."""
    try:
        ast.parse(code)
        return None, ""
    except SyntaxError as syntax_error:
        target_lineno = syntax_error.lineno

    lines = code.split("\n")
    fixed_lines = []
    fix_count = 0

    def _unescaped_double_quotes(line: str) -> list[int]:
        return [
            index for index, char in enumerate(line)
            if char == '"' and (index == 0 or line[index - 1] != "\\")
        ]

    def _is_nested_quote_candidate(line: str, first_quote: int) -> bool:
        prefix = line[:first_quote]
        if re.search(
            r"\b(Text|MathTex|Tex|Title|Paragraph|MarkupText)\s*\([^#]*$",
            prefix,
        ):
            return True
        return bool(re.search(r"(?:^|\s)(?:[\w.]+\s*=|text\s*=)\s*$", prefix))

    for lineno, line in enumerate(lines, start=1):
        new_line = line
        if target_lineno is None or lineno == target_lineno:
            quote_positions = _unescaped_double_quotes(line)
            if len(quote_positions) >= 4:
                first_quote = quote_positions[0]
                if not _is_nested_quote_candidate(line, first_quote):
                    fixed_lines.append(new_line)
                    continue
                chars = list(line)
                inner_quotes = quote_positions[1:-1]
                for index, pos in enumerate(inner_quotes):
                    chars[pos] = "\u201c" if index % 2 == 0 else "\u201d"
                new_line = "".join(chars)
                if new_line != line:
                    fix_count += 1
        fixed_lines.append(new_line)

    if fix_count == 0:
        return None, ""

    result = "\n".join(fixed_lines)
    try:
        ast.parse(result)
    except SyntaxError:
        return None, ""

    return result, f"修复 {fix_count} 处嵌套ASCII双引号"


def _fix_raw_string_trailing_backslash(code: str) -> Tuple[Optional[str], str]:
    """Repair raw strings ending with an odd number of backslashes."""
    try:
        ast.parse(code)
        return None, ""
    except SyntaxError as syntax_error:
        target_lineno = syntax_error.lineno

    lines = code.split("\n")
    fix_count = 0

    def _replace(match: re.Match) -> str:
        nonlocal fix_count
        trailing = match.group("slashes")
        if len(trailing) % 2 == 0:
            return match.group(0)
        quote = match.group("quote")
        raw_content = match.group("body") + trailing
        escaped = raw_content.replace("\\", "\\\\")
        escaped = escaped.replace(quote, "\\" + quote)
        fix_count += 1
        return f"{quote}{escaped}{quote}"

    fixed_lines = []
    for lineno, line in enumerate(lines, start=1):
        if target_lineno is not None and lineno != target_lineno:
            fixed_lines.append(line)
            continue
        fixed_lines.append(_RAW_STRING_TRAILING_BACKSLASH_RE.sub(_replace, line))

    if fix_count == 0:
        return None, ""

    result = "\n".join(fixed_lines)
    return result, f"修复 {fix_count} 处raw字符串末尾反斜杠"
