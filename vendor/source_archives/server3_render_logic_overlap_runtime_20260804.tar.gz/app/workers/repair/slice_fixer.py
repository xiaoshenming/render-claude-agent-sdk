"""Compatibility boundary for the removed slice post-repair loop.

Failed slices now remain failed so the owning generation flow can decide how
to regenerate them. This module performs no code mutation and no LLM repair.
"""

import logging

logger = logging.getLogger("render")


async def retry_failed_slice(*args, **kwargs):
    task_data = kwargs.get("task_data")
    if isinstance(task_data, dict):
        task_data["_slice_post_repair_removed"] = True
    logger.info("slice post-repair removed; returning original render failure")
    return None
