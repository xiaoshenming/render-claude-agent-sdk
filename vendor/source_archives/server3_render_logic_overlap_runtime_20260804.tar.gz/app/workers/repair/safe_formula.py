"""Formula-string compatibility entrypoints for pre-render repair.

This layer may repair deterministic TeX/string escaping mistakes. It must not
turn formulas into plain Text or hide unparseable generated math.
"""

from app.workers.repair.pre_render_text_fixes import (
    _fix_inline_math_tuple_overescaped_latex_commands,
    _fix_mathtex_plain_string_latex_escapes,
    _latex_has_aligned_begin,
    _latex_has_aligned_end,
    _normalize_overescaped_latex_commands,
)

__all__ = [
    "_fix_inline_math_tuple_overescaped_latex_commands",
    "_fix_mathtex_plain_string_latex_escapes",
    "_latex_has_aligned_begin",
    "_latex_has_aligned_end",
    "_normalize_overescaped_latex_commands",
]
