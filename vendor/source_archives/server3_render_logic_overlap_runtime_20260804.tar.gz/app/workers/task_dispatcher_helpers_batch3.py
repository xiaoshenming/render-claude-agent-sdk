"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
def _failure_attribution_payload(
    task_data: Optional[Dict[str, Any]],
    *,
    error_msg: str | None,
    error_type: str | None,
    error_stage: str | None,
) -> Dict[str, Any]:
    if not task_data:
        return {}

    has_attribution_source = any(
        task_data.get(key)
        for key in (
            "_first_failure_signature",
            "_last_failure_signature",
            "_repair_signature_counts",
            "_slice_repair_circuit_breaker",
            "_slice_repair_full_regenerate_signal",
            "_slice_render_error_contract",
            "_layout_repair_residual_issue_top3",
            "_layout_repair_events",
        )
    )
    if not has_attribution_source:
        return {}

    payload: Dict[str, Any] = {}
    first_failure = _failure_signature_payload(
        task_data.get("_first_failure_signature")
    )
    if first_failure:
        payload["first_failure"] = first_failure

    final_failure = _failure_signature_payload(
        task_data.get("_last_failure_signature")
    ) or {}
    final_failure.update(
        _without_none(
            {
                "terminal_error_type": error_type,
                "terminal_error_stage": error_stage,
                "terminal_error_message": (error_msg or "")[:500] or None,
            }
        )
    )
    if final_failure:
        payload["final_failure"] = final_failure

    repair_counts = _repair_signature_counts_payload(
        task_data.get("_repair_signature_counts")
    )
    if repair_counts:
        payload["repair_signature_counts"] = repair_counts

    circuit_breaker = _json_safe_failure_value(
        task_data.get("_slice_repair_circuit_breaker")
    )
    if circuit_breaker:
        payload["slice_repair_circuit_breaker"] = circuit_breaker

    full_regenerate_signal = _json_safe_failure_value(
        task_data.get("_slice_repair_full_regenerate_signal")
    )
    if full_regenerate_signal:
        payload["slice_repair_full_regenerate_signal"] = full_regenerate_signal

    slice_render_error_contract = _json_safe_failure_value(
        task_data.get("_slice_render_error_contract")
    )
    if slice_render_error_contract:
        payload["slice_render_error_contract"] = slice_render_error_contract

    residual_top3 = _json_safe_failure_value(
        task_data.get("_layout_repair_residual_issue_top3"),
        max_items=3,
    )
    if residual_top3:
        payload["layout_repair_residual_issue_top3"] = residual_top3

    failed_layout_events = _layout_repair_failed_events_payload(
        task_data.get("_layout_repair_events")
    )
    if failed_layout_events:
        payload["layout_repair_failed_events"] = failed_layout_events

    return payload
def record_queue_event(
    task_data: Optional[Dict[str, Any]],
    level: str,
    stage: str,
    message: str,
    **context: Any,
) -> None:
    collector = task_data.get("_error_collector") if task_data else None
    if collector is None:
        return
    emit = getattr(collector, level, None)
    if emit is None:
        return
    emit("MQ", stage, message, context={k: v for k, v in context.items() if v is not None})
def _failed_code_fallback(task_data: Dict[str, Any]) -> str | bytes | None:
    for key in ("_code", "_agent_failed_code", "code"):
        value = task_data.get(key)
        if isinstance(value, bytes) and value.strip():
            return value
        if isinstance(value, str) and value.strip():
            return value
    return None
