"""Execute one accepted RabbitMQ task and finalize its broker outcome."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class MessageDependencies:
    asyncio: Any
    job_repository: Any
    task_dispatcher: Any
    video_task_processor: Any
    hard_timeout_for_task: Callable
    bind_container_lock_job: Callable
    reset_container_lock_job: Callable


async def execute_task(
    worker,
    message,
    task_data: dict,
    *,
    queue_type: str,
    queue_name: str,
    job_id: str,
    retry_count: int,
    message_bytes: int,
    deps: MessageDependencies,
) -> tuple[bool, str | None, float]:
    task_start = time.time()
    await deps.task_dispatcher.log_mq_quality_event(
        "mq_message_processing_started",
        task_data,
        queue_type=queue_type,
        queue_name=queue_name,
        routing_key=queue_name,
        retry_count=retry_count,
        message_bytes=message_bytes,
        redelivered=task_data.get("_rabbitmq_redelivered"),
        result="started",
        detail="RabbitMQ message processing started",
    )
    hard_timeout = deps.hard_timeout_for_task(task_data)
    lock_context_token = deps.bind_container_lock_job(job_id)
    try:
        try:
            result = await deps.asyncio.wait_for(
                worker.process_video_task(task_data), timeout=hard_timeout
            )
        finally:
            deps.reset_container_lock_job(lock_context_token)
    except deps.asyncio.TimeoutError:
        duration = time.time() - task_start
        logger.error(
            "[QUEUE] [%s] task hard timeout(%ss): job_id=%s duration=%.0fs",
            queue_type,
            hard_timeout,
            job_id,
            duration,
        )
        await worker._cleanup_hard_timeout_containers(job_id)
        worker._release_claimed_active_job_marker(task_data, job_id)
        persisted = await worker._handle_final_failure(
            job_id,
            f"任务硬超时({duration:.0f}s)被强制中止",
            refund_points=task_data.get("refund_points", 0),
            error_type="hard_timeout",
            error_stage="task_watchdog",
            retry_count=retry_count,
            task_data=task_data,
        )
        if deps.task_dispatcher._final_failure_ackable(persisted):
            await deps.task_dispatcher.ack_with_queue_evidence(
                message,
                task_data,
                stage="QUEUE_ACK",
                detail="Hard timeout final failure persisted and acked",
                queue_type=queue_type,
                job_id=job_id,
                retry_count=retry_count,
                flush=False,
            )
        else:
            await deps.task_dispatcher.handle_final_failure_persist_failed(
                message,
                task_data,
                queue_type=queue_type,
                job_id=job_id,
                retry_count=retry_count,
                error_msg=f"任务硬超时({duration:.0f}s)被强制中止",
                error_type="hard_timeout",
                error_stage="task_watchdog",
                nack_detail="Hard timeout final failure persist failed, message nacked",
                flush=False,
            )
        return True, None, duration
    except deps.job_repository.JobStatusWriteError as exc:
        worker._release_claimed_active_job_marker(task_data, job_id)
        logger.error(
            "[QUEUE] [%s] job status write failed; nack: job_id=%s error=%s",
            queue_type,
            job_id,
            exc,
        )
        await deps.task_dispatcher.nack_with_queue_evidence(
            message,
            task_data,
            stage="QUEUE_NACK",
            detail="Job status write failed, message nacked",
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
            flush=False,
        )
        return True, None, time.time() - task_start
    return False, str(result), time.time() - task_start


async def finish_task(
    worker,
    message,
    task_data: dict,
    result: str,
    duration: float,
    *,
    queue_type: str,
    queue_name: str,
    job_id: str,
    retry_count: int,
    message_bytes: int,
    deps: MessageDependencies,
) -> None:
    await deps.task_dispatcher.log_mq_quality_event(
        "mq_task_processing_finished",
        task_data,
        queue_type=queue_type,
        queue_name=queue_name,
        routing_key=queue_name,
        retry_count=retry_count,
        message_bytes=message_bytes,
        duration_ms=int(duration * 1000),
        redelivered=task_data.get("_rabbitmq_redelivered"),
        result=result,
        detail=f"RabbitMQ task processing returned {result}",
    )
    if result != "success":
        await deps.video_task_processor.record_stage_timing_summary(task_data, status=result)
    if result in {"success", "skipped"}:
        stage = "QUEUE_ACK_READY" if result == "success" else "QUEUE_ACK_SKIPPED_READY"
        deps.task_dispatcher.record_queue_event(
            task_data,
            "info",
            stage,
            f"Task {result}; preparing to ack message",
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
        )
    await deps.task_dispatcher.flush_error_collector(task_data)
    if result in {"success", "skipped"}:
        stage = "QUEUE_ACK" if result == "success" else "QUEUE_ACK_SKIPPED"
        await deps.task_dispatcher.ack_with_queue_evidence(
            message,
            task_data,
            stage=stage,
            detail=f"Task {result} and message acked",
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
            flush=False,
        )
        logger.info(
            "[QUEUE] [%s] task %s and acked: job_id=%s duration=%.2fs",
            queue_type,
            result,
            job_id,
            duration,
        )
        return
    worker._release_claimed_active_job_marker(task_data, job_id)
    await worker._handle_task_failure(message, task_data, job_id, retry_count, queue_type)
