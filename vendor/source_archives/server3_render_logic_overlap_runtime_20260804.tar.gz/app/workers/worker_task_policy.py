"""Task-level timeout policy shared by worker responsibilities."""

import os
from typing import Any, Dict

from app.core.config import settings

INTERNAL_LONG_COURSE_HARD_TIMEOUT = 5400


def hard_timeout_for_task(task_data: Dict[str, Any]) -> int:
    base_timeout = int(settings.FINAL_RENDER_TIMEOUT) + 60
    if task_data.get("_internal_long_course") is True:
        return max(base_timeout, INTERNAL_LONG_COURSE_HARD_TIMEOUT)
    return base_timeout


def pid_is_alive(pid: int | None) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True
