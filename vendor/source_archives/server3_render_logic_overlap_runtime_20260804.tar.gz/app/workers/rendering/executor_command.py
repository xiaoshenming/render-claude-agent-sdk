"""Render command, telemetry parsing, and canvas override helpers."""

import json
import logging
from typing import Any, Dict, Optional

from app.core.render_canvas_profile import get_render_canvas_profile

logger = logging.getLogger("render")
_SENSITIVE_ENV_KEY_PARTS = ("KEY", "SECRET", "TOKEN", "PASSWORD")
_TTS_TELEMETRY_PREFIX = "MATHPI_TTS_TELEMETRY "


def _masked_cmd(cmd: list[str]) -> list[str]:
    masked: list[str] = []
    mask_next_env = False
    for part in cmd:
        if mask_next_env:
            key = part.split("=", 1)[0]
            if any(token in key.upper() for token in _SENSITIVE_ENV_KEY_PARTS):
                masked.append(f"{key}=***")
            else:
                masked.append(part)
            mask_next_env = False
            continue
        masked.append(part)
        mask_next_env = part == "-e"
    return masked


def _extract_tts_telemetry(*outputs: str | None) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for output in outputs:
        if not output:
            continue
        for line in output.splitlines():
            if not line.startswith(_TTS_TELEMETRY_PREFIX):
                continue
            raw_payload = line[len(_TTS_TELEMETRY_PREFIX):].strip()
            try:
                payload = json.loads(raw_payload)
            except json.JSONDecodeError:
                logger.debug("Invalid TTS telemetry payload: %s", raw_payload)
                continue
            if isinstance(payload, dict) and payload.get("event") == "tts_synthesis":
                entries.append(payload)
    return entries


def _build_manim_resolution_args(
    aspect_ratio: object,
    profile_name: str | None = None,
) -> list[str]:
    profile = get_render_canvas_profile(aspect_ratio, profile_name=profile_name)
    return profile.resolution_args


def _render_canvas_profile_name_from_task_data(
    task_data: Optional[Dict[str, Any]] = None,
) -> str | None:
    if not isinstance(task_data, dict):
        return None
    value = str(task_data.get("render_canvas_profile_name") or "").strip()
    return value or None


def _append_render_canvas_config_override(script_path: str, profile) -> None:
    """Make the selected runtime canvas profile win over generated header drift."""
    marker = (
        "# MathPi enforced render canvas profile: "
        f"{profile.profile_name}"
    )
    try:
        with open(script_path, "r", encoding="utf-8") as handle:
            code = handle.read()
    except Exception:
        logger.debug(
            "failed to read script before canvas profile override: %s",
            script_path,
            exc_info=True,
        )
        return
    if marker in code:
        return
    override = (
        "\n\n"
        f"{marker}\n"
        f"{profile.to_manim_config_source().rstrip()}\n"
    )
    try:
        with open(script_path, "a", encoding="utf-8") as handle:
            handle.write(override)
    except Exception:
        logger.warning(
            "failed to append render canvas profile override: %s",
            script_path,
            exc_info=True,
        )
