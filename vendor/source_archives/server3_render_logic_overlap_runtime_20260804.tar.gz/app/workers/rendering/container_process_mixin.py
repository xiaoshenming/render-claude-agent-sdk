"""容器生命周期管理：锁文件、健康检查、空闲容器选择。

从 video_worker.py 提取的容器管理逻辑，
保持原有锁文件机制（稳定优先），后期可升级为 Redis 锁。
"""
import os
import re
import secrets
import time
import asyncio
import logging
import subprocess
import contextvars
from datetime import datetime
from typing import Any, Dict, List, Optional

from app.core.config import normalize_container_names, settings

logger = logging.getLogger(__name__)
_current_lock_job_id: contextvars.ContextVar[str | None] = (
    contextvars.ContextVar("mathpi_container_lock_job_id", default=None)
)


def _ts() -> str:
    """返回当前时间戳字符串，用于日志"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _is_manim_process_line(line: str) -> bool:
    normalized = line.strip().lower()
    if not normalized:
        return False
    if "manim" not in normalized:
        return False
    return bool(re.search(r"(^|[/\s])(?:python3?|manim)(?:\s|$)", normalized))


def bind_container_lock_job(job_id: str | None):
    return _current_lock_job_id.set(str(job_id) if job_id else None)


def reset_container_lock_job(token) -> None:
    _current_lock_job_id.reset(token)




class ContainerProcessMixin:
    async def kill_manim_processes(
            self,
            containers: List[str],
            *,
            job_id: str | None = None,
        ) -> None:
            """Best-effort cleanup for container child processes after hard timeout."""
            for container in containers:
                try:
                    await self._run_cmd_async(
                        [
                            "docker", "exec", container, "sh", "-c",
                            "pkill -TERM -f manim 2>/dev/null || true; "
                            "sleep 1; "
                            "pkill -KILL -f manim 2>/dev/null || true",
                        ],
                        timeout=8,
                    )
                    logger.warning(
                        "[CONTAINER] [%s] hard-timeout killed manim processes: "
                        "container=%s job_id=%s",
                        _ts(), container, job_id,
                    )
                except Exception as exc:
                    logger.warning(
                        "[CONTAINER] [%s] hard-timeout kill skipped/failed: "
                        "container=%s job_id=%s error=%s",
                        _ts(), container, job_id, exc,
                    )
    def _cleanup_stale_locks_on_startup(self):
            """启动时清理所有过期的锁文件，防止死锁"""
            logger.info(f"[INIT] [{_ts()}] 检查并清理过期锁文件...")
            cleaned = 0
            for c in self.container_names:
                lockfile = self._lock_path(c)
                if os.path.exists(lockfile):
                    try:
                        stat = os.stat(lockfile)
                        age = time.time() - stat.st_mtime
                        if self._is_lock_stale(lockfile):
                            os.remove(lockfile)
                            logger.warning(
                                f"[INIT] [{_ts()}] 清理过期锁: {lockfile} (age={age:.0f}s)")
                            cleaned += 1
                        else:
                            logger.info(
                                f"[INIT] [{_ts()}] 保留锁: {lockfile} "
                                f"(age={age:.0f}s < {self.lock_stale_seconds}s)")
                    except Exception as e:
                        logger.warning(
                            f"[INIT] [{_ts()}] 清理锁文件失败: {lockfile}, error={e}")
            logger.info(f"[INIT] [{_ts()}] 锁文件清理完成, 清理数量={cleaned}")
    async def _run_cmd_async(
            self, cmd: List[str], timeout: Optional[int] = None
        ) -> subprocess.CompletedProcess:
            """异步执行命令，不阻塞事件循环"""
            logger.debug(f"Executing command: {' '.join(cmd)}; timeout={timeout}")
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                try:
                    stdout, stderr = await asyncio.wait_for(
                        proc.communicate(), timeout=timeout)
                    return subprocess.CompletedProcess(
                        cmd, proc.returncode, stdout.decode(), stderr.decode())
                except asyncio.TimeoutError:
                    proc.kill()
                    await proc.wait()
                    raise subprocess.TimeoutExpired(cmd, timeout)
            except subprocess.TimeoutExpired:
                raise
            except Exception:
                logger.exception(f"Command execution failed: {' '.join(cmd)}")
                raise
    async def _is_container_running(self, container: str) -> bool:
            """检查容器是否正在运行（带缓存）"""
            now = time.time()
            last_check = self._container_running_cache.get(container, 0)
            if now - last_check < self._container_running_ttl:
                return True
            try:
                cp = await self._run_cmd_async([
                    "docker", "inspect", "-f", "{{.State.Running}}", container
                ], timeout=5)
                if cp.returncode == 0 and cp.stdout.strip().lower() == "true":
                    self._container_running_cache[container] = now
                    return True
                logger.warning(
                    f"[CONTAINER] [{_ts()}] 容器 {container} 未运行: {cp.stdout.strip()}")
                self._container_running_cache.pop(container, None)
                return False
            except subprocess.TimeoutExpired:
                logger.warning(
                    f"[CONTAINER] [{_ts()}] 检查容器 {container} 状态超时")
                return False
            except Exception as e:
                logger.warning(
                    f"[CONTAINER] [{_ts()}] 检查容器 {container} 状态失败: {e}")
                return False
    async def _container_has_manim(self, container: str) -> bool:
            """检查容器内是否有正在运行的 manim 渲染进程"""
            try:
                cp = await self._run_cmd_async([
                    "docker", "exec", container,
                    "sh", "-c",
                    "ps -eo args= 2>/dev/null",
                ], timeout=5)
                if cp.returncode != 0:
                    logger.warning(
                        f"[CONTAINER] [{_ts()}] 检查 {container} manim进程失败: "
                        f"returncode={cp.returncode}, stderr={cp.stderr.strip()[:200]}")
                    return True
                manim_processes = [
                    line for line in cp.stdout.splitlines()
                    if _is_manim_process_line(line)
                ]
                if cp.returncode == 0 and manim_processes:
                    logger.debug(
                        f"{container}: found manim process: "
                        f"{'; '.join(manim_processes)}")
                    return True
                return False
            except subprocess.TimeoutExpired:
                logger.warning(
                    f"[CONTAINER] [{_ts()}] 检查 {container} manim进程超时，假设繁忙")
                return True
            except Exception as e:
                logger.warning(
                    f"[CONTAINER] [{_ts()}] 检查 {container} manim进程失败: {e}")
                return True
    async def select_idle_container(
            self, wait: bool = True, max_wait: Optional[int] = 600
        ) -> Optional[str]:
            """选择一个空闲容器并加锁返回。调用方用完后须 release_lock()。"""
            if not self.container_names:
                logger.error(
                    f"[CONTAINER] [{_ts()}] 未配置任何可用容器名，无法执行渲染")
                return None
            start = time.time()
            logger.info(
                f"[CONTAINER] [{_ts()}] 开始选择空闲容器, "
                f"可用容器列表: {self.container_names}")
            attempt = 0
            while True:
                attempt += 1
                container_status = []
                for c in self.container_names:
                    if not self.try_acquire_lock(c):
                        if await self._reclaim_orphaned_idle_lock(c):
                            if self.try_acquire_lock(c):
                                container_status.append(f"{c}:回收坏锁后可用")
                            else:
                                container_status.append(f"{c}:锁定")
                                continue
                        else:
                            container_status.append(f"{c}:锁定")
                            continue
                    else:
                        container_status.append(f"{c}:已加锁检查")
                    if not await self._is_container_running(c):
                        container_status.append(f"{c}:未运行")
                        self.release_lock(c)
                        continue
                    try:
                        has_manim = await self._container_has_manim(c)
                        if has_manim:
                            container_status.append(f"{c}:渲染中")
                            self.release_lock(c)
                            continue
                        elapsed = time.time() - start
                        logger.info(
                            f"[CONTAINER] [{_ts()}] ✓ 选中容器 {c} "
                            f"(无渲染进程), 等待耗时={elapsed:.1f}s, "
                            f"尝试次数={attempt}")
                        return c
                    except Exception as e:
                        container_status.append(f"{c}:异常({str(e)[:30]})")
                        logger.exception(
                            f"[CONTAINER] [{_ts()}] 检查容器 {c} 时异常")
                        self.release_lock(c)
    
                if attempt == 1 or attempt % 10 == 0:
                    elapsed = time.time() - start
                    logger.info(
                        f"[CONTAINER] [{_ts()}] 第{attempt}次尝试, "
                        f"无可用容器, 状态: {', '.join(container_status)}, "
                        f"已等待={elapsed:.1f}s")
    
                if not wait:
                    logger.warning(
                        f"[CONTAINER] [{_ts()}] 无可用容器且不等待, 返回None")
                    return None
                if max_wait is not None and (time.time() - start) > max_wait:
                    logger.error(
                        f"[CONTAINER] [{_ts()}] 等待容器超时 ({max_wait}s), "
                        f"容器状态: {', '.join(container_status)}")
                    return None
                await asyncio.sleep(self.container_check_interval)
