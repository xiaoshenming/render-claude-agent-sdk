"""Render container environment, scene, and asset helpers."""

import json
import logging
import os
import re as _re
import shutil
from datetime import datetime
from typing import Any, Dict, Optional

from app.core.config import settings

logger = logging.getLogger("render")

_TTS_FATAL_PATTERNS = [
    "Speech synthesis canceled",
    "Connection failed (no connection to the remote host)",
    "WS_OPEN_ERROR_UNDERLYING_IO_OPEN_FAILED",
]
_CONTAINER_RUNTIME_ENV_KEYS = [
    "DASHSCOPE_API_KEY",
    "DASHSCOPE_API_BASE",
    "MATHPI_SYSTEM_TTS_PROVIDER",
    "COSYVOICE_MODEL",
    "COSYVOICE_DEFAULT_VOICE",
    "COSYVOICE_ALLOW_TTS_FALLBACK",
    "COSYVOICE_SYNTHESIS_RETRIES",
    "COSYVOICE_SYNTHESIS_RETRY_BASE_SEC",
    "DOUBAO_API_KEY",
    "DOUBAO_TTS_RESOURCE_ID",
    "DOUBAO_TTS_DEFAULT_VOICE",
    "DOUBAO_TTS_EMOTION",
    "DOUBAO_TTS_EMOTION_SCALE",
    "DOUBAO_TTS_LOUDNESS_RATE",
    "DOUBAO_TTS_PITCH",
    "DOUBAO_TTS_SILENCE_MS",
    "DOUBAO_TTS_SPEECH_RATE",
    "XIAOMI_MIMO_API_KEY",
    "MIMO_API_KEY",
    "XIAOMI_MIMO_API_BASE",
    "MIMO_API_BASE",
    "MIMO_TTS_MODEL",
    "MIMO_TTS_VOICECLONE_MODEL",
    "MIMO_TTS_DEFAULT_VOICE",
    "MIMO_TTS_STYLE_PROMPT",
    "MIMO_TTS_TIMEOUT",
    "MIMO_TTS_SYNTHESIS_RETRIES",
    "MIMO_TTS_RETRY_BASE_SEC",
    "MIMO_TTS_SYNTHESIS_RETRY_BASE_SEC",
    "MIMO_TTS_RATE_LIMIT_COOLDOWN_SEC",
    "MIMO_TTS_ALLOW_FALLBACK",
    "MIMO_TTS_VOICECLONE_SYSTEM_FALLBACK",
    "MATHPI_TTS_PROVIDER_CONCURRENCY",
    "MATHPI_TTS_PROVIDER_RPM_LIMIT",
    "MATHPI_TTS_PROVIDER_MIN_INTERVAL_SEC",
    "MATHPI_TTS_SLOT_TIMEOUT_SEC",
    "MATHPI_TTS_LOCK_POLL_SEC",
    "OPENAI_API_KEY",
]
_SENSITIVE_ENV_KEY_PARTS = ("KEY", "SECRET", "TOKEN", "PASSWORD")
_TTS_TELEMETRY_PREFIX = "MATHPI_TTS_TELEMETRY "
_CONTAINER_RENDER_ASSETS_DIR = "/home/manimuser/manim_media/assets"
_SCENE_CLASS_DEF_RE = _re.compile(
    r"(?m)^\s*class\s+([A-Za-z_][A-Za-z0-9_]*)\s*\("
)
_ZERO_PADDED_SCENE_RE = _re.compile(r"^Scene_0([1-9])(_.*)?$")
_UNPADDED_SCENE_RE = _re.compile(r"^Scene_([1-9])(_.*)?$")
_SCENE_NUMBER_RE = _re.compile(r"^Scene_0*([1-9][0-9]*)(?:_|$)")


class TTSConnectionError(Exception):
    """Azure TTS 服务不可达 — 属于外部服务故障，重试代码无意义。"""
    pass


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _normalize_tts_provider(provider: str) -> str:
    normalized = str(provider or "").strip().lower()
    if normalized in {"ali", "aliyun", "dashscope", "cosy", "cosyvoice"}:
        return "cosyvoice"
    if normalized in {"doubao", "bytedance", "volcengine", "volcano"}:
        return "doubao"
    if normalized in {"mimo", "xiaomi", "xiaomi_mimo"}:
        return "mimo"
    return ""


def _tts_snapshot_env_overrides(
    task_data: Optional[Dict[str, Any]] = None,
) -> dict[str, str]:
    if not isinstance(task_data, dict):
        return {}
    snapshot = task_data.get("tts_voice_snapshot")
    if isinstance(snapshot, str):
        try:
            snapshot = json.loads(snapshot)
        except json.JSONDecodeError:
            snapshot = None
    if not isinstance(snapshot, dict):
        return {}

    provider = _normalize_tts_provider(str(snapshot.get("provider") or ""))
    if not provider:
        return {}

    target_model = str(
        snapshot.get("target_model") or snapshot.get("model") or ""
    ).strip()
    voice_id = str(
        snapshot.get("provider_voice_id")
        or snapshot.get("voice_id")
        or task_data.get("tts_voice")
        or ""
    ).strip()
    overrides = {"MATHPI_SYSTEM_TTS_PROVIDER": provider}
    if provider == "cosyvoice":
        if target_model:
            overrides["COSYVOICE_MODEL"] = target_model
        if voice_id:
            overrides["COSYVOICE_DEFAULT_VOICE"] = voice_id
    elif provider == "doubao":
        if target_model:
            overrides["DOUBAO_TTS_RESOURCE_ID"] = target_model
        if voice_id:
            overrides["DOUBAO_TTS_DEFAULT_VOICE"] = voice_id
    elif provider == "mimo":
        if target_model:
            overrides["MIMO_TTS_MODEL"] = target_model
        if voice_id:
            overrides["MIMO_TTS_DEFAULT_VOICE"] = voice_id
    return overrides


def _runtime_container_env_args(
    task_data: Optional[Dict[str, Any]] = None,
) -> list[str]:
    args: list[str] = [
        "-e",
        f"MATHPI_RENDER_ASSETS_DIR={_CONTAINER_RENDER_ASSETS_DIR}",
    ]
    overrides = _tts_snapshot_env_overrides(task_data)
    for key in _CONTAINER_RUNTIME_ENV_KEYS:
        value = str(
            overrides.get(key)
            or os.environ.get(key, "")
            or getattr(settings, key, "")
            or ""
        )
        if value:
            args.extend(["-e", f"{key}={value}"])
    return args


def _scene_class_name_candidates(class_name: str) -> list[str]:
    candidates: list[str] = []
    zero_padded = _ZERO_PADDED_SCENE_RE.match(class_name)
    if zero_padded:
        candidates.append(f"Scene_{zero_padded.group(1)}{zero_padded.group(2) or ''}")
    unpadded = _UNPADDED_SCENE_RE.match(class_name)
    if unpadded:
        candidates.append(f"Scene_0{unpadded.group(1)}{unpadded.group(2) or ''}")
    return candidates


def _resolve_compatible_scene_class_name(
    script_path: str,
    class_name: Optional[str],
) -> Optional[str]:
    """Resolve harmless scene class drift before invoking Manim."""
    if not class_name:
        return class_name
    candidates = _scene_class_name_candidates(class_name)
    if not candidates:
        return class_name
    try:
        with open(script_path, "r", encoding="utf-8") as handle:
            code = handle.read()
    except Exception:
        return class_name
    defined_classes = _SCENE_CLASS_DEF_RE.findall(code)
    defined = set(defined_classes)
    if class_name in defined:
        return class_name
    for candidate in candidates:
        if candidate in defined:
            logger.warning(
                "[RENDER] [%s] Scene类名兼容: requested=%s resolved=%s script=%s",
                _ts(),
                class_name,
                candidate,
                script_path,
            )
            return candidate
    requested_number = _SCENE_NUMBER_RE.match(class_name)
    if requested_number:
        same_number_classes = [
            scene_class
            for scene_class in defined_classes
            if (
                (defined_number := _SCENE_NUMBER_RE.match(scene_class))
                and defined_number.group(1) == requested_number.group(1)
            )
        ]
        if len(same_number_classes) == 1:
            resolved = same_number_classes[0]
            logger.warning(
                "[RENDER] [%s] Scene编号兼容: requested=%s resolved=%s script=%s",
                _ts(),
                class_name,
                resolved,
                script_path,
            )
            return resolved
    return class_name


def _ensure_custom_services_available(manim_media_root: str) -> None:
    """Expose app/custom_services through the shared manim_media mount."""
    source = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "custom_services")
    )
    if not os.path.isdir(source):
        return

    destination = os.path.join(manim_media_root, "custom_services")
    try:
        shutil.copytree(
            source,
            destination,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
        os.chmod(destination, 0o755)
    except Exception:
        logger.warning(
            "[RENDER] [%s] 同步 custom_services 到 manim_media 失败: src=%s dst=%s",
            _ts(),
            source,
            destination,
            exc_info=True,
        )


def _ensure_render_assets_available(manim_media_root: str) -> None:
    """Expose apps/render/assets through the shared manim_media mount."""
    source = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "assets")
    )
    if not os.path.isdir(source):
        return

    destination = os.path.join(manim_media_root, "assets")
    try:
        shutil.copytree(
            source,
            destination,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
        os.chmod(destination, 0o755)
    except Exception:
        logger.warning(
            "[RENDER] [%s] 同步 render assets 到 manim_media 失败: src=%s dst=%s",
            _ts(),
            source,
            destination,
            exc_info=True,
        )


def _prepare_tts_lock_dir(manim_media_root: str) -> str:
    lock_dir = os.path.join(manim_media_root, "locks", "tts_provider")
    os.makedirs(lock_dir, exist_ok=True)
    try:
        os.chmod(lock_dir, 0o777)
    except OSError:
        logger.debug("failed to chmod TTS lock dir: %s", lock_dir, exc_info=True)
    return "/home/manimuser/manim_media/locks/tts_provider"
