"""容器生命周期管理：锁文件、健康检查、空闲容器选择。

从 video_worker.py 提取的容器管理逻辑，
保持原有锁文件机制（稳定优先），后期可升级为 Redis 锁。
"""
import os
import re
import secrets
import time
import asyncio
import logging
import subprocess
import contextvars
from datetime import datetime
from typing import Any, Dict, List, Optional

from app.core.config import normalize_container_names, settings

logger = logging.getLogger(__name__)
_current_lock_job_id: contextvars.ContextVar[str | None] = (
    contextvars.ContextVar("mathpi_container_lock_job_id", default=None)
)

def _ts() -> str:
    """返回当前时间戳字符串，用于日志"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

def _is_manim_process_line(line: str) -> bool:
    normalized = line.strip().lower()
    if not normalized:
        return False
    if "manim" not in normalized:
        return False
    return bool(re.search(r"(^|[/\s])(?:python3?|manim)(?:\s|$)", normalized))

def bind_container_lock_job(job_id: str | None):
    return _current_lock_job_id.set(str(job_id) if job_id else None)

def reset_container_lock_job(token) -> None:
    _current_lock_job_id.reset(token)

class ContainerLockMixin:
    def _lock_path(self, container: str) -> str:
            return os.path.join(self.locks_dir, f"{container}.lock")
    def _lock_info(self, container: str) -> Dict[str, Any]:
            lockfile = self._lock_path(container)
            stat_result = None
            try:
                stat_result = os.stat(lockfile)
                with open(lockfile, "r", encoding="utf-8") as f:
                    lines = f.read().splitlines()
            except FileNotFoundError:
                return {
                    "path": lockfile,
                    "exists": False,
                    "job_id": None,
                    "owner_pid": None,
                    "created_at": None,
                    "age_sec": None,
                }
            except Exception as exc:
                logger.warning(
                    "[CONTAINER] [%s] 读取锁文件失败: %s error=%s",
                    _ts(), lockfile, exc,
                )
                return {
                    "path": lockfile,
                    "exists": True,
                    "job_id": None,
                    "owner_pid": None,
                    "created_at": None,
                    "age_sec": (
                        max(0, int(time.time() - stat_result.st_mtime))
                        if stat_result is not None
                        else None
                    ),
                    "error": str(exc)[:120],
                }
    
            owner_pid: int | None = None
            created_at: int | None = None
            try:
                owner_pid = int(lines[0]) if lines else None
            except (TypeError, ValueError):
                owner_pid = None
            try:
                created_at = int(lines[1]) if len(lines) >= 2 else None
            except (TypeError, ValueError):
                created_at = None
            if created_at is None:
                created_at = int(stat_result.st_mtime)
            job_id = None
            for line in lines[3:]:
                if line.startswith("job_id="):
                    job_id = line.split("=", 1)[1] or None
                    break
            return {
                "path": lockfile,
                "exists": True,
                "job_id": job_id,
                "owner_pid": owner_pid,
                "created_at": created_at,
                "age_sec": max(0, int(time.time() - created_at)),
            }
    @staticmethod
    def _pid_is_alive(pid: int) -> bool:
            if pid <= 0:
                return False
            try:
                os.kill(pid, 0)
                return True
            except ProcessLookupError:
                return False
            except PermissionError:
                return True
            except OSError:
                return False
    @staticmethod
    def _lock_owner_pid(lockfile: str) -> Optional[int]:
            try:
                with open(lockfile, "r", encoding="utf-8") as f:
                    first_line = f.readline().strip()
                return int(first_line)
            except (FileNotFoundError, ValueError, OSError):
                return None
    def _is_lock_stale(self, lockfile: str) -> bool:
            try:
                stat = os.stat(lockfile)
                age = time.time() - stat.st_mtime
                owner_pid = self._lock_owner_pid(lockfile)
                if owner_pid is not None and not self._pid_is_alive(owner_pid):
                    logger.warning(
                        f"Lock {lockfile} owner pid {owner_pid} is gone "
                        "-> will be removed"
                    )
                    return True
                if age > self.lock_stale_seconds:
                    logger.warning(
                        f"Lock {lockfile} is stale (age={age}s) -> will be removed")
                    return True
                return False
            except FileNotFoundError:
                return False
            except Exception:
                logger.exception("Error checking lock staleness")
                return False
    def try_acquire_lock(self, container: str, job_id: str | None = None) -> bool:
            lockfile = self._lock_path(container)
            try:
                if os.path.exists(lockfile) and self._is_lock_stale(lockfile):
                    try:
                        os.remove(lockfile)
                        logger.info(f"Removed stale lock: {lockfile}")
                    except Exception:
                        logger.exception(
                            f"Failed to remove stale lock: {lockfile}")
    
                token = secrets.token_hex(16)
                lock_job_id = str(job_id or _current_lock_job_id.get() or "")
                lock_job_id = lock_job_id.replace("\n", "")[:128]
                created_at = int(time.time())
                fd = os.open(lockfile, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(f"{os.getpid()}\n{created_at}\n{token}\n")
                    if lock_job_id:
                        f.write(f"job_id={lock_job_id}\n")
                self._lock_tokens[container] = token
                logger.debug(
                    f"Acquired lock for container {container} -> {lockfile}")
                return True
            except FileExistsError:
                logger.debug(
                    f"Could not acquire lock for {container}: lock exists {lockfile}")
                return False
            except Exception:
                logger.exception(
                    f"Unexpected error acquiring lock for {container}")
                return False
    def release_lock(self, container: str) -> None:
            lockfile = self._lock_path(container)
            try:
                if os.path.exists(lockfile):
                    expected_token = self._lock_tokens.get(container)
                    if not expected_token:
                        logger.warning(
                            f"Skip releasing lock without local owner token: {lockfile}")
                        return
                    try:
                        with open(lockfile, "r", encoding="utf-8") as f:
                            lines = f.read().splitlines()
                    except FileNotFoundError:
                        self._lock_tokens.pop(container, None)
                        return
                    current_token = lines[2] if len(lines) >= 3 else ""
                    if current_token != expected_token:
                        logger.warning(
                            f"Skip releasing lock owned by another task: {lockfile}")
                        self._lock_tokens.pop(container, None)
                        return
                    os.remove(lockfile)
                    self._lock_tokens.pop(container, None)
                    logger.debug(f"Released lock for container {container}")
            except Exception:
                logger.exception(
                    f"Failed to release lock for container {container}")
    @staticmethod
    def _orphaned_lock_reclaim_seconds_from_env() -> int:
            raw = os.getenv("CONTAINER_ORPHANED_LOCK_RECLAIM_SECONDS", "60")
            try:
                return max(5, int(raw or 60))
            except (TypeError, ValueError):
                return 60
    async def _reclaim_orphaned_idle_lock(self, container: str) -> bool:
            """Remove an old anonymous lock when the container is actually idle.
    
            Some repair/probe paths can leave a lock without a job_id when a caller
            is externally timed out before it reaches release_lock(). We only reclaim
            anonymous locks after a short grace period and after confirming there is
            no Manim process in the container.
            """
            info = self._lock_info(container)
            if not info.get("exists"):
                return False
            if info.get("job_id"):
                return False
            age_sec = info.get("age_sec")
            try:
                age = int(age_sec)
            except (TypeError, ValueError):
                return False
            if age < self.orphaned_lock_reclaim_seconds:
                return False
            if await self._container_has_manim(container):
                return False
    
            lockfile = self._lock_path(container)
            try:
                os.remove(lockfile)
                self._lock_tokens.pop(container, None)
                logger.warning(
                    "[CONTAINER] [%s] reclaimed orphaned idle lock: "
                    "container=%s age=%ss path=%s",
                    _ts(), container, age, lockfile,
                )
                return True
            except FileNotFoundError:
                self._lock_tokens.pop(container, None)
                return True
            except Exception:
                logger.exception(
                    "[CONTAINER] [%s] failed to reclaim orphaned idle lock: "
                    "container=%s path=%s",
                    _ts(), container, lockfile,
                )
                return False
    def available_container_count(self) -> int:
            """Return containers not currently guarded by a local lock file."""
            if not self.container_names:
                return 0
            return sum(
                1
                for container in self.container_names
                if not os.path.exists(self._lock_path(container))
            )
    def locked_containers_for_job(self, job_id: str | None) -> List[str]:
            if not job_id:
                return []
            expected = str(job_id)
            containers: List[str] = []
            for container in self.container_names:
                info = self._lock_info(container)
                if info.get("exists") and info.get("job_id") == expected:
                    containers.append(container)
            return containers
    def cleanup_task_locks(self, job_id: str | None) -> List[str]:
            """Remove lock files owned by a specific job and return affected containers."""
            containers = self.locked_containers_for_job(job_id)
            for container in containers:
                lockfile = self._lock_path(container)
                try:
                    os.remove(lockfile)
                    self._lock_tokens.pop(container, None)
                    logger.warning(
                        "[CONTAINER] [%s] hard-timeout released lock: "
                        "container=%s job_id=%s",
                        _ts(), container, job_id,
                    )
                except FileNotFoundError:
                    self._lock_tokens.pop(container, None)
                except Exception:
                    logger.exception(
                        "[CONTAINER] [%s] hard-timeout failed to release lock: "
                        "container=%s job_id=%s",
                        _ts(), container, job_id,
                    )
            return containers
