"""容器生命周期管理：锁文件、健康检查、空闲容器选择。

从 video_worker.py 提取的容器管理逻辑，
保持原有锁文件机制（稳定优先），后期可升级为 Redis 锁。
"""
import os
import re
import secrets
import time
import asyncio
import logging
import subprocess
import contextvars
from datetime import datetime
from typing import Any, Dict, List, Optional

from app.core.config import normalize_container_names, settings

logger = logging.getLogger(__name__)
_current_lock_job_id: contextvars.ContextVar[str | None] = (
    contextvars.ContextVar("mathpi_container_lock_job_id", default=None)
)


def _ts() -> str:
    """返回当前时间戳字符串，用于日志"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _is_manim_process_line(line: str) -> bool:
    normalized = line.strip().lower()
    if not normalized:
        return False
    if "manim" not in normalized:
        return False
    return bool(re.search(r"(^|[/\s])(?:python3?|manim)(?:\s|$)", normalized))


def bind_container_lock_job(job_id: str | None):
    return _current_lock_job_id.set(str(job_id) if job_id else None)


def reset_container_lock_job(token) -> None:
    _current_lock_job_id.reset(token)


from app.workers.rendering.container_lock_mixin import ContainerLockMixin
from app.workers.rendering.container_process_mixin import ContainerProcessMixin

class ContainerManager(ContainerLockMixin, ContainerProcessMixin):
    def __init__(
            self,
            container_names: Optional[List[str]] = None,
            locks_dir: str = "",
            container_check_interval: float = 1.0,
            lock_stale_seconds: int = 60 * 30,
            orphaned_lock_reclaim_seconds: int | None = None,
        ):
            if container_names is None:
                self.container_names = normalize_container_names(
                    settings.CONTAINER_NAMES)
            else:
                self.container_names = normalize_container_names(container_names)
            if not locks_dir:
                project_root = os.path.abspath(
                    os.path.join(os.path.dirname(__file__), "..", ".."))
                locks_dir = os.path.join(project_root, "manim_media", "locks")
            self.locks_dir = locks_dir
            os.makedirs(self.locks_dir, exist_ok=True)
    
            self.container_check_interval = container_check_interval
            self.lock_stale_seconds = lock_stale_seconds
            self.orphaned_lock_reclaim_seconds = (
                orphaned_lock_reclaim_seconds
                if orphaned_lock_reclaim_seconds is not None
                else self._orphaned_lock_reclaim_seconds_from_env()
            )
    
            # 容器运行状态缓存（避免每次都 docker inspect）
            self._container_running_cache: Dict[str, float] = {}
            self._container_running_ttl = 30.0
            self._lock_tokens: Dict[str, str] = {}
    
            # 启动时清理可能残留的过期锁文件
            self._cleanup_stale_locks_on_startup()

