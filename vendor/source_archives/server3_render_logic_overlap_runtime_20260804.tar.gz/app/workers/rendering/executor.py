"""Compatibility facade for Docker Manim render execution."""

import asyncio  # noqa: F401 - compatibility monkeypatch surface
import sys

from app.core.config import settings  # noqa: F401 - compatibility monkeypatch surface
from app.services import ffmpeg_service  # noqa: F401 - compatibility monkeypatch surface
from app.workers.repair import error_fixer  # noqa: F401 - compatibility monkeypatch surface
from app.workers.rendering import executor_command as _command
from app.workers.rendering import executor_environment as _environment
from app.workers.rendering import executor_runtime as _runtime
from app.workers.rendering import executor_telemetry as _telemetry

_telemetry.facade_provider = lambda: sys.modules[__name__]
_runtime.facade_provider = lambda: sys.modules[__name__]

TTSConnectionError = _environment.TTSConnectionError
_TTS_FATAL_PATTERNS = _environment._TTS_FATAL_PATTERNS
_CONTAINER_RUNTIME_ENV_KEYS = _environment._CONTAINER_RUNTIME_ENV_KEYS
_SENSITIVE_ENV_KEY_PARTS = _environment._SENSITIVE_ENV_KEY_PARTS
_TTS_TELEMETRY_PREFIX = _environment._TTS_TELEMETRY_PREFIX
_CONTAINER_RENDER_ASSETS_DIR = _environment._CONTAINER_RENDER_ASSETS_DIR
_ts = _environment._ts
_normalize_tts_provider = _environment._normalize_tts_provider
_tts_snapshot_env_overrides = _environment._tts_snapshot_env_overrides
_runtime_container_env_args = _environment._runtime_container_env_args
_scene_class_name_candidates = _environment._scene_class_name_candidates
_resolve_compatible_scene_class_name = _environment._resolve_compatible_scene_class_name
_ensure_custom_services_available = _environment._ensure_custom_services_available
_ensure_render_assets_available = _environment._ensure_render_assets_available
_prepare_tts_lock_dir = _environment._prepare_tts_lock_dir

_masked_cmd = _command._masked_cmd
_extract_tts_telemetry = _command._extract_tts_telemetry
_build_manim_resolution_args = _command._build_manim_resolution_args
_render_canvas_profile_name_from_task_data = _command._render_canvas_profile_name_from_task_data
_append_render_canvas_config_override = _command._append_render_canvas_config_override

_record_tts_telemetry = _telemetry._record_tts_telemetry
_kill_container_manim = _telemetry._kill_container_manim
render_in_container = _runtime.render_in_container
