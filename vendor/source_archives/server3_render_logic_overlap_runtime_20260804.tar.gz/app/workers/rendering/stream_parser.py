"""流式 LLM 输出解析器 -- 从流式输出中实时提取完整的 Scene 类代码。"""
import re
from typing import List, Tuple, Optional

# Scene 类定义的正则模式
_SCENE_CLASS_RE = re.compile(r'^class\s+(Scene_\d+_\w+)\s*\([^)]*\)\s*:', re.MULTILINE)

# 用于判断"纯代码模式"（LLM 未用 markdown 包裹）的特征行
_CODE_HINT_PATTERNS = (
    'from manim import',
    'from manim ',
    'import numpy',
    'import math',
)
_PYTHON_CODE_ANCHOR_RE = re.compile(
    r'(?m)^(?:'
    r'from\s+manim\s+import\b.*|'
    r'from\s+manim\b.*|'
    r'import\s+(?:numpy|math)\b.*|'
    r'class\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*Scene[^)]*\)\s*:.*'
    r')$'
)
_END_SENTINEL_RE = re.compile(r'(?m)^\s*#\s*END\s*$')
_CONTROL_ARTIFACT_LINE_RE = re.compile(r'^\s*<ctrl\d+>')


class SceneStreamParser:
    """解析 LLM 流式输出，实时提取完整的 Manim Scene 类。

    工作原理：
    1. feed() 接收每个 chunk，累积到 buffer
    2. 自动检测 ```python ... ``` 代码块，提取代码内容
    3. 从代码流中识别 header（import / GlobalConfig / BaseConfigScene）
       和各 Scene 类（class Scene_XX_Name(...)）
    4. 当检测到第 N+1 个 Scene 的 class 定义时，第 N 个 Scene 就完整了
    5. pop_completed() 返回已完成的 Scene 列表
    """

    def __init__(self):
        self._raw_buffer = ""          # 原始 LLM 输出（含 markdown）
        self._code_buffer = ""         # 提取出的纯代码
        self._header = ""              # import + GlobalConfig + BaseConfigScene
        self._header_extracted = False
        self._completed: List[Tuple[str, str]] = []  # [(scene_name, code)]
        self._current_scene_name: Optional[str] = None
        self._current_scene_start: int = -1  # code_buffer 中的起始位置
        self._scenes_processed: int = 0      # 已处理过的 Scene 匹配数
        self._in_code_block = False
        self._pure_code_mode = False   # 是否为纯代码模式（无 markdown 包裹）
        self._code_block_start_checked = False  # 是否已检查过开头模式

    # ------------------------------------------------------------------
    # 公开 API
    # ------------------------------------------------------------------

    def feed(self, chunk: str):
        """接收一个流式 chunk"""
        self._raw_buffer += chunk
        self._extract_code_from_raw()
        self._try_extract_scenes()

    def pop_completed(self) -> List[Tuple[str, str]]:
        """返回并清空已完成的 Scene 列表"""
        result = self._completed[:]
        self._completed.clear()
        return result

    def get_header(self) -> str:
        """返回 header 代码（import + GlobalConfig + BaseConfigScene）"""
        return self._header

    def flush(self) -> Optional[Tuple[str, str]]:
        """流结束时调用，返回最后一个可能未提交的 Scene（仅当代码完整时）"""
        # 如果处于代码块中，关闭它（LLM 可能没发结束标记）
        if self._in_code_block:
            self._in_code_block = False

        # 重新解析一次，确保 code_buffer 最新
        self._extract_code_from_raw()
        self._try_extract_scenes()

        # 如果还有未提交的 current scene
        if self._current_scene_name and self._current_scene_start >= 0:
            code = self._code_buffer[self._current_scene_start:].rstrip()
            if code:
                # 完整性检查：最后一个 Scene 可能被 token 截断
                import ast
                try:
                    # 用 header + scene_code 做语法检查
                    test_code = (self._header or "") + "\n\n" + code
                    ast.parse(test_code)
                except SyntaxError:
                    # 语法不合法 = 截断了，丢弃这个 Scene
                    return None
                result = (self._current_scene_name, code)
                self._current_scene_name = None
                self._current_scene_start = -1
                return result
        return None

    def get_all_code(self) -> str:
        """返回目前为止的全部代码"""
        return self._trim_artifact_tail(self._code_buffer)

    def get_raw_output(self) -> str:
        """返回原始 LLM 输出。"""
        return self._raw_buffer

    def get_salvaged_code(self) -> str:
        """从带说明文字的裸代码输出中兜底提取可解析 Python。

        有些模型没有使用 Markdown 代码块，且先输出一两句说明，再开始
        `from manim import *` 或 `class XxxScene(...)`。常规流式解析会把
        这种输出视为普通文本；这里只从明确 Python 锚点开始截取，并要求
        截取结果能通过 ast.parse，避免把解释文字写入 script.py。
        """
        for source in (self._code_buffer, self._raw_buffer):
            salvaged = self._salvage_python_suffix(source)
            if salvaged:
                return salvaged
        return ""

    # ------------------------------------------------------------------
    # 内部实现
    # ------------------------------------------------------------------

    def _extract_code_from_raw(self):
        """从原始输出中提取代码块内容到 _code_buffer"""
        buf = self._raw_buffer

        # 第一次收到足够内容时，判断是纯代码还是 markdown 包裹
        if not self._code_block_start_checked and len(buf) > 30:
            self._code_block_start_checked = True
            stripped = buf.lstrip()
            # 如果开头就是代码特征行，认为是纯代码模式
            for hint in _CODE_HINT_PATTERNS:
                if stripped.startswith(hint):
                    self._pure_code_mode = True
                    break
            # 如果开头不是 ``` 也不是代码特征，再看 class 开头
            if not self._pure_code_mode and not stripped.startswith('```'):
                if stripped.startswith('class '):
                    self._pure_code_mode = True

        # 纯代码模式：整个 raw_buffer 就是代码
        if self._pure_code_mode:
            self._code_buffer = buf
            return

        # Markdown 模式：提取 ```python ... ``` 之间的内容
        new_code = self._parse_markdown_code_blocks(buf)
        self._code_buffer = new_code

    def _parse_markdown_code_blocks(self, text: str) -> str:
        """从 markdown 文本中提取所有 python 代码块的内容，拼接返回。

        处理方式：逐字符扫描，跟踪 ``` 标记的开闭状态。
        支持 ```python 和裸 ```（如果内部看起来像 Python 代码）。
        """
        result_parts: List[str] = []
        i = 0
        length = len(text)
        in_block = False
        block_start = 0

        while i < length:
            # 检测 ``` 标记
            if text[i:i + 3] == '```':
                if not in_block:
                    # 可能是代码块开始
                    # 跳过 ``` 后面的语言标识（如 python）
                    j = i + 3
                    # 跳过语言标识直到换行
                    while j < length and text[j] != '\n':
                        j += 1
                    if j < length:
                        j += 1  # 跳过换行
                    in_block = True
                    block_start = j
                    i = j
                    continue
                else:
                    # 代码块结束
                    code_content = text[block_start:i]
                    if code_content.strip():
                        result_parts.append(code_content)
                    in_block = False
                    i += 3
                    # 跳过可能的换行
                    if i < length and text[i] == '\n':
                        i += 1
                    continue
            i += 1

        # 如果还在代码块中（流未结束，没收到关闭标记）
        if in_block and block_start < length:
            code_content = text[block_start:]
            if code_content.strip():
                result_parts.append(code_content)

        return '\n'.join(result_parts)

    def _salvage_python_suffix(self, text: str) -> str:
        if not text or not text.strip():
            return ""

        for match in _PYTHON_CODE_ANCHOR_RE.finditer(text):
            candidate = text[match.start():].strip()
            fence_pos = candidate.find('```')
            if fence_pos >= 0:
                candidate = candidate[:fence_pos].strip()
            salvaged = self._trim_to_parseable_python(candidate)
            if salvaged:
                return salvaged
        return ""

    def _trim_artifact_tail(self, code: str) -> str:
        if not code:
            return ""

        end_match = _END_SENTINEL_RE.search(code)
        if end_match:
            return code[:end_match.end()].rstrip() + '\n'

        lines = code.splitlines()
        for idx, line in enumerate(lines):
            if not _CONTROL_ARTIFACT_LINE_RE.match(line):
                continue
            prefix = '\n'.join(lines[:idx]).rstrip()
            if self._is_parseable_python(prefix):
                return prefix + '\n'
        return code

    def _is_parseable_python(self, code: str) -> bool:
        if not code or not code.strip():
            return False
        import ast

        try:
            ast.parse(code)
        except SyntaxError:
            return False
        return True

    def _trim_to_parseable_python(self, candidate: str) -> str:
        if not candidate:
            return ""
        import ast

        lines = candidate.splitlines()
        for end in range(len(lines), 0, -1):
            code = '\n'.join(lines[:end]).rstrip()
            if not code:
                continue
            try:
                ast.parse(code)
            except SyntaxError:
                continue
            return code + '\n'
        return ""

    def _try_extract_scenes(self):
        """尝试从 code_buffer 中提取完整的 Scene 类。

        策略：
        - 找到所有 class Scene_XX_Name(...): 的位置
        - header = 第一个 Scene 之前的所有内容
        - 当第 N+1 个 Scene 出现时，第 N 个就完整了
        """
        code = self._code_buffer
        if not code:
            return

        matches = list(_SCENE_CLASS_RE.finditer(code))
        if not matches:
            return

        # 提取 header（第一个 Scene 之前的所有内容）
        if not self._header_extracted:
            first_pos = matches[0].start()
            if first_pos > 0:
                self._header = code[:first_pos].rstrip() + '\n'
            self._header_extracted = True

        # 遍历所有匹配，提取已完成的 Scene
        # 跳过已经处理过的匹配
        for idx, match in enumerate(matches):
            if idx < self._scenes_processed:
                continue

            scene_name = match.group(1)
            scene_start = match.start()

            # 如果有一个"当前 Scene"正在积累中
            if self._current_scene_name is not None:
                # 新的 Scene 出现 => 当前 Scene 完整了
                scene_code = code[self._current_scene_start:scene_start].rstrip()
                if scene_code:
                    self._completed.append((self._current_scene_name, scene_code))
                # 新 Scene 成为 current
                self._current_scene_name = scene_name
                self._current_scene_start = scene_start
            else:
                # 第一次遇到 Scene
                self._current_scene_name = scene_name
                self._current_scene_start = scene_start

            self._scenes_processed = idx + 1
