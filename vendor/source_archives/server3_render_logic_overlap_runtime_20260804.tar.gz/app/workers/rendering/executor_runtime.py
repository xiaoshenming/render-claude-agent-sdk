"""Docker Manim render execution."""
import asyncio
import logging
import os
import subprocess
import time
import uuid
from typing import Any, Dict, List, Optional, Callable
from app.core.render_canvas_profile import get_render_canvas_profile
from app.services import ffmpeg_service
from app.workers.repair import error_fixer

logger = logging.getLogger("render")
facade_provider: Callable[[], Any] | None = None

async def render_in_container(
    container: str, job_id: str, script_path: str,
    class_name: Optional[str], job_output_dir: str,
    aspect_ratio: str, timeout_sec: int,
    manim_media_root: str, media_root: str,
    collector: Any = None,
    task_data: Optional[Dict[str, Any]] = None,
) -> bytes:
    """在 Docker 容器内执行 Manim 渲染并返回 MP4 字节。"""
    render_start = time.time()
    profile_name = facade_provider()._render_canvas_profile_name_from_task_data(task_data)
    profile = get_render_canvas_profile(aspect_ratio, profile_name=profile_name)
    class_name = facade_provider()._resolve_compatible_scene_class_name(script_path, class_name)
    facade_provider()._append_render_canvas_config_override(script_path, profile)
    logger.info(
        f"[RENDER] [{facade_provider()._ts()}] 开始渲染 job_id={job_id}, "
        f"容器={container}, 脚本={script_path}, "
        f"类名={class_name or '(自动检测)'}")
    logger.info(
        "[RENDER] [%s] render_canvas_profile: name=%s version=%s "
        "aspect_ratio=%s pixel=%sx%s frame=%sx%s",
        facade_provider()._ts(),
        profile.profile_name,
        profile.version,
        profile.aspect_ratio,
        profile.pixel_width,
        profile.pixel_height,
        profile.frame_width,
        profile.frame_height,
    )

    # 脚本路径映射
    rel = os.path.relpath(script_path, manim_media_root)
    container_script_path = f"manim_media/{rel}".replace("\\", "/")
    rel_output = os.path.relpath(job_output_dir, media_root)
    container_media_dir = f"/media/{rel_output}".replace("\\", "/")
    logger.info(
        f"[RENDER] [{facade_provider()._ts()}] 路径映射: "
        f"脚本={container_script_path}, 输出={container_media_dir}")

    # Manim 0.19 在某些路径组合下不会自动补建 images/videos 父目录，
    # 先在宿主机建立好，避免容器内 mkdir(images/script_*) 时直接失败。
    for path in (
        job_output_dir,
        os.path.join(job_output_dir, "images"),
        os.path.join(job_output_dir, "videos"),
    ):
        os.makedirs(path, exist_ok=True)
        os.chmod(path, 0o777)
    facade_provider()._ensure_custom_services_available(manim_media_root)
    facade_provider()._ensure_render_assets_available(manim_media_root)
    container_tts_lock_dir = facade_provider()._prepare_tts_lock_dir(manim_media_root)

    output_name = f"video_{job_id}_{uuid.uuid4().hex[:10]}"
    expected_mp4_name = f"{output_name}.mp4"

    cmd = [
        "docker", "exec",
        "-u", "manimuser",
        "-w", "/home/manimuser",
        "-e", "PYTHONUNBUFFERED=1",
        "-e", "PYTHONPATH=/home/manimuser/manim_media",
        "-e", f"MATHPI_TTS_LOCK_DIR={container_tts_lock_dir}",
        *facade_provider()._runtime_container_env_args(task_data),
        container,
        "manim",
        container_script_path,
    ]
    if class_name:
        cmd.append(class_name)
    cmd.append("-qm")
    cmd.extend(facade_provider()._build_manim_resolution_args(profile.aspect_ratio, profile.profile_name))

    cmd.extend([
        "--media_dir", container_media_dir,
        "-o", output_name,
    ])

    full_cmd = " ".join(facade_provider()._masked_cmd(cmd))
    logger.info(f"[RENDER] [{facade_provider()._ts()}] ========== 渲染命令 ==========")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] 完整命令: {full_cmd}")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] 容器: {container}")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] 工作目录: /home/manimuser")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] 脚本路径: {container_script_path}")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] 输出目录: {container_media_dir}")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] 输出文件名: {output_name}")
    logger.info(f"[RENDER] [{facade_provider()._ts()}] ==============================")

    try:
        cp = await ffmpeg_service.run_cmd_async(cmd, timeout=timeout_sec)
        await facade_provider()._record_tts_telemetry(
            collector,
            facade_provider()._extract_tts_telemetry(cp.stdout, cp.stderr),
            scene_name=class_name,
            task_data=task_data,
        )
        render_duration = time.time() - render_start
        logger.info(
            f"[RENDER] [{facade_provider()._ts()}] 渲染进程完成: job_id={job_id}, "
            f"返回码={cp.returncode}, 耗时={render_duration:.2f}s")

        if cp.returncode != 0:
            logger.error(
                f"[RENDER] [{facade_provider()._ts()}] 渲染失败 job_id={job_id}, "
                f"stderr:\n{cp.stderr[:3000] if cp.stderr else 'N/A'}")
            if cp.stdout:
                logger.error(
                    f"[RENDER] [{facade_provider()._ts()}] stdout:\n{cp.stdout[:2000]}")
        else:
            if cp.stderr and (
                'error' in cp.stderr.lower()
                or 'warning' in cp.stderr.lower()
            ):
                logger.warning(
                    f"[RENDER] [{facade_provider()._ts()}] 渲染有警告 job_id={job_id}: "
                    f"{cp.stderr[:1000]}")
    except subprocess.TimeoutExpired:
        render_duration = time.time() - render_start
        logger.error(
            f"[RENDER] [{facade_provider()._ts()}] 渲染超时! job_id={job_id}, "
            f"容器={container}, 超时={timeout_sec}s, "
            f"已运行={render_duration:.2f}s")
        await facade_provider()._kill_container_manim(container)
        raise Exception(f"Render timeout after {render_duration:.0f}s")
    except asyncio.CancelledError:
        render_duration = time.time() - render_start
        logger.warning(
            f"[RENDER] [{facade_provider()._ts()}] 渲染任务被取消: job_id={job_id}, "
            f"容器={container}, 已运行={render_duration:.2f}s")
        await facade_provider()._kill_container_manim(container)
        raise

    if cp.returncode != 0:
        # 优先检测 TTS 外部服务故障 — 修复代码无意义，快速失败
        combined_output = (cp.stderr or "") + (cp.stdout or "")
        if any(pat in combined_output for pat in facade_provider()._TTS_FATAL_PATTERNS):
            logger.error(
                f"[RENDER] [{facade_provider()._ts()}] ⚡ TTS 服务不可达 job_id={job_id}，"
                f"跳过修复直接失败")
            raise facade_provider().TTSConnectionError(
                "Azure TTS 服务连接失败，请检查 Docker 容器网络")

        from app.workers.repair.error_patterns import is_tts_error

        if is_tts_error(combined_output):
            err_detail = error_fixer.extract_render_error(
                cp.stderr or "", cp.stdout or "",
                job_output_dir, media_root)
            raise Exception(
                "manim渲染失败: TTS_PROVIDER_TRANSIENT: "
                f"{err_detail}")

        err_detail = error_fixer.extract_render_error(
            cp.stderr or "", cp.stdout or "",
            job_output_dir, media_root)
        raise Exception(f"manim渲染失败: {err_detail}")

    # 查找 mp4 文件（带重试，渲染可能延迟写入）
    logger.info(
        f"[RENDER] [{facade_provider()._ts()}] 搜索输出视频文件: {job_output_dir}, "
        f"expected={expected_mp4_name}")
    videos_root = os.path.join(job_output_dir, "videos")
    images_root = os.path.join(job_output_dir, "images")

    max_wait_seconds = 480
    check_interval = 5
    max_attempts = max_wait_seconds // check_interval
    mp4_candidates: List[str] = []

    for attempt in range(max_attempts):
        mp4_candidates = []
        try:
            if os.path.exists(videos_root):
                for root, dirs, files in os.walk(videos_root):
                    for f in files:
                        if f.lower().endswith(".mp4") and \
                                "partial" not in root.lower():
                            if f == expected_mp4_name:
                                mp4_candidates.append(os.path.join(root, f))

            if not mp4_candidates and os.path.exists(job_output_dir):
                for root, dirs, files in os.walk(job_output_dir):
                    for f in files:
                        if f.lower().endswith(".mp4") and \
                                "partial" not in root.lower() and \
                                f == expected_mp4_name:
                            mp4_candidates.append(os.path.join(root, f))
        except Exception as e:
            logger.warning(
                f"[RENDER] [{facade_provider()._ts()}] 搜索mp4文件时出错 "
                f"(attempt={attempt}): {e}")

        if mp4_candidates:
            elapsed = attempt * check_interval
            logger.info(
                f"[RENDER] [{facade_provider()._ts()}] ✓ 找到 {len(mp4_candidates)} "
                f"个mp4文件 (等待={elapsed}秒, attempt={attempt})")
            break

        # 快速失败：images 目录有 PNG 但无 mp4 → Scene 无动画帧
        if attempt == 0 and os.path.exists(images_root):
            png_files = []
            for root, dirs, files in os.walk(images_root):
                for f in files:
                    if f.lower().endswith((".png", ".jpg")):
                        png_files.append(os.path.join(root, f))
            if png_files:
                logger.warning(
                    f"[RENDER] [{facade_provider()._ts()}] 检测到 images 目录有 "
                    f"{len(png_files)} 个图片但无 mp4，"
                    f"Scene 可能无动画帧，立即判定失败")
                raise Exception(
                    "Scene 没有生成视频，只生成了静态图片。"
                    "原因：代码中缺少 self.play() 或 self.wait() 调用，"
                    "Manim 无法生成视频帧。"
                    "修复方法：必须在 construct() 中添加至少一个 "
                    "self.play(...) 动画调用和 self.wait() 等待，"
                    "确保 Scene 有动画内容而非纯静态 self.add()。")

        if attempt < max_attempts - 1:
            elapsed = attempt * check_interval
            if attempt == 0 or (attempt * check_interval) % 30 == 0:
                logger.info(
                    f"[RENDER] [{facade_provider()._ts()}] 等待渲染完成... "
                    f"已等待={elapsed}秒, 最大等待={max_wait_seconds}秒")
            await asyncio.sleep(check_interval)

    if not mp4_candidates:
        try:
            if os.path.exists(job_output_dir):
                all_files = []
                for root, dirs, files in os.walk(job_output_dir):
                    for f in files:
                        all_files.append(os.path.join(root, f))
                logger.error(
                    f"[RENDER] [{facade_provider()._ts()}] 未找到mp4! job_id={job_id}, "
                    f"目录内容: {all_files[:30]}")
            else:
                logger.error(
                    f"[RENDER] [{facade_provider()._ts()}] 输出目录不存在: "
                    f"{job_output_dir}")
        except Exception:
            pass
        raise Exception(
            f"渲染完成但未找到输出mp4文件 (目录={job_output_dir})")

    mp4_path = mp4_candidates[0]
    try:
        size = os.path.getsize(mp4_path)
        logger.info(
            f"[RENDER] [{facade_provider()._ts()}] ✓ 找到视频文件: {mp4_path}, "
            f"大小={size/1024/1024:.2f}MB")
    except Exception as e:
        logger.exception(
            f"[RENDER] [{facade_provider()._ts()}] 获取文件大小失败: {e}")

    try:
        with open(mp4_path, "rb") as fh:
            data = fh.read()

            min_video_size = 10 * 1024  # 10KB
            if len(data) < min_video_size:
                raise Exception(
                    f"视频文件过小或损坏: {len(data)} bytes "
                    f"< {min_video_size} bytes")

            total_duration = time.time() - render_start
            logger.info(
                f"[RENDER] [{facade_provider()._ts()}] ✓ 渲染完成 job_id={job_id}, "
                f"视频大小={len(data)/1024/1024:.2f}MB, "
                f"总耗时={total_duration:.2f}s")
            return data
    except Exception as e:
        logger.exception(
            f"[RENDER] [{facade_provider()._ts()}] 读取mp4文件失败: {mp4_path}, "
            f"error={e}")
        raise
