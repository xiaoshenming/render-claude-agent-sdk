"""Render TTS telemetry persistence and container termination."""
import logging
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger("render")
facade_provider: Callable[[], Any] | None = None
_TTS_SUCCESS_STATUSES = {"success", "cache_hit", "fallback_openai"}

async def _record_tts_telemetry(
    collector: Any,
    telemetry_entries: list[dict[str, Any]],
    *,
    scene_name: str | None,
    task_data: Optional[Dict[str, Any]] = None,
) -> None:
    for entry in telemetry_entries:
        context = dict(entry)
        if scene_name:
            context["scene_name"] = scene_name
        status = str(entry.get("status") or "unknown")
        service = str(entry.get("service") or "unknown")
        voice_id = str(entry.get("voice_id") or "unknown")
        if collector and hasattr(collector, "info"):
            try:
                collector.info(
                    "TTS_AUDIO",
                    "TTS_SYNTHESIS",
                    f"TTS synthesis {status}: {service} voice={voice_id}",
                    context=context,
                )
            except Exception:
                logger.debug("Failed to record TTS telemetry", exc_info=True)

        if not isinstance(task_data, dict):
            continue
        payload = {
            "generation_mode": task_data.get("generation_mode") or "standard",
            "pipeline_mode": task_data.get("pipeline_mode") or "STREAMING",
            "task_type": task_data.get("task_type") or "normal",
            "scene_name": scene_name,
            "tts_enabled": bool(task_data.get("enable_tts")),
            "tts_service": service,
            "tts_voice": voice_id,
            "tts_model": entry.get("model"),
            "tts_status": status,
            "fallback_used": bool(entry.get("fallback_used")),
            "allow_tts_fallback": entry.get("allow_tts_fallback"),
            "audio_present": bool(entry.get("audio_path")) and status in _TTS_SUCCESS_STATUSES,
        }
        evidence = {
            "audio_path": entry.get("audio_path"),
            "audio_bytes": entry.get("audio_bytes"),
            "text_length": entry.get("text_length"),
            "word_boundary_count": entry.get("word_boundary_count"),
            "word_timestamps": entry.get("word_timestamps"),
            "cache_hit": entry.get("cache_hit"),
            "silence_trim": entry.get("silence_trim"),
            "speech_rate": entry.get("speech_rate"),
            "fallback_service": entry.get("fallback_service"),
            "fallback_model": entry.get("fallback_model"),
            "error_type": entry.get("error_type"),
            "error_message": entry.get("error_message"),
            "provider_status_code": entry.get("provider_status_code"),
            "provider_failure_class": entry.get("provider_failure_class"),
            "provider_retry_after_sec": entry.get("provider_retry_after_sec"),
        }
        try:
            from app.workers.task_dispatcher import log_render_quality_event

            await log_render_quality_event(
                (
                    "tts_audio_synthesized"
                    if status in _TTS_SUCCESS_STATUSES
                    else "tts_audio_failed"
                ),
                task_data,
                payload=payload,
                evidence=evidence,
            )
        except Exception:
            logger.debug("Failed to record TTS quality event", exc_info=True)


async def _kill_container_manim(container: str) -> None:
    try:
        await facade_provider().ffmpeg_service.run_cmd_async(
            ["docker", "exec", container, "pkill", "-f", "manim"],
            timeout=5)
        logger.info(
            f"[RENDER] [{facade_provider()._ts()}] 已尝试终止容器 "
            f"{container} 中的manim进程")
    except Exception as e:
        logger.exception(
            f"[RENDER] [{facade_provider()._ts()}] 终止manim进程失败: {e}")
