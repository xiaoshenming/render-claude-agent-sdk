"""quality_cases.persist — 把 case artifact 上传 COS + 入库 quality_case_reports。

约束：全 fail-soft，任何异常都只 warning，绝不影响主渲染流程。
COS Key 规则：quality-cases/job_{job_id}/{scene_name}/{case_id}/{filename}
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from sqlalchemy import text

from app.database.database import AsyncSessionLocal

from .safety import safe_scene_name
from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

JOB_COMPARISON_CASE_ID = "__job_6in1__"
JOB_COMPARISON_SCENE_NAME = "完整切片6合一"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"
LAYOUT_MVP_ROUND_ARTIFACT_TYPES = {
    "before_code": "text/x-python; charset=utf-8",
    "after_code": "text/x-python; charset=utf-8",
    "diff": "text/plain; charset=utf-8",
    "before_probe": "application/json; charset=utf-8",
    "after_probe": "application/json; charset=utf-8",
    "before_video": "video/mp4",
    "after_video": "video/mp4",
}



def _ulid_like() -> str:
    return uuid.uuid4().hex[:26].upper()
def _ts() -> str:
    return time.strftime("%H:%M:%S")
def _layout_metric_fields(manifest: QualityCaseManifest) -> dict[str, Any]:
    layout = manifest.layout_fixed
    return {
        "before_overlap_count": layout.before_overlap_count,
        "after_overlap_count": layout.after_overlap_count,
        "before_max_overlap_ratio": layout.before_max_overlap_ratio,
        "after_max_overlap_ratio": layout.after_max_overlap_ratio,
    }
def _resolve_case_path(case_dir: Path, value: Optional[str | Path]) -> Optional[Path]:
    """把 manifest 里的 artifact 路径解析到真实文件。"""
    if not value:
        return None
    path = Path(value)
    if path.is_absolute():
        return path
    return case_dir / path
def _looks_like_inline_diff(value: str | Path | None) -> bool:
    if not isinstance(value, str):
        return False
    return "\n" in value and ("--- " in value or "+++ " in value or "@@ " in value)
def _resolve_diff_artifact(case_dir: Path, value: Optional[str | Path], filename: str) -> Optional[Path]:
    if not value:
        return None
    if _looks_like_inline_diff(value):
        path = case_dir / filename
        try:
            path.write_text(str(value), encoding="utf-8")
        except Exception as exc:
            logger.warning("[QUALITY_CASE] 写入 diff artifact 失败 %s: %s", path, exc)
            return None
        return path
    return _resolve_case_path(case_dir, value)
def _layout_evidence_artifacts(
    case_dir: Path,
    manifest: QualityCaseManifest,
) -> list[tuple[str, Optional[Path], str]]:
    layout = manifest.layout_fixed
    return [
        (
            "layout_decision_before",
            _resolve_case_path(case_dir, layout.before_decision_path),
            "layout_decision_before.json",
        ),
        (
            "layout_decision_after",
            _resolve_case_path(case_dir, layout.after_decision_path),
            "layout_decision_after.json",
        ),
        (
            "layout_bbox_before",
            _resolve_case_path(case_dir, layout.bbox_before_path),
            "layout_bbox_before.json",
        ),
        (
            "layout_bbox_after",
            _resolve_case_path(case_dir, layout.bbox_after_path),
            "layout_bbox_after.json",
        ),
    ]
def _is_remote_artifact(value: Any) -> bool:
    return isinstance(value, str) and value.startswith(("http://", "https://", "cos://"))
def _record_upload_failure(
    collector: Any | None,
    *,
    job_id: str | None,
    case_id: str | None,
    artifact: str,
    cos_key: str,
    path: Path,
    exc: Exception,
) -> None:
    if collector is None:
        return
    warning = getattr(collector, "warning", None)
    if warning is None:
        return
    warning(
        "UPLOAD",
        "QUALITY_CASE_UPLOAD",
        f"quality case {artifact} 上传失败: {exc}",
        context={
            "type": "quality_case_upload",
            "job_id": job_id,
            "case_id": case_id,
            "artifact": artifact,
            "cos_key": cos_key,
            "local_path": str(path),
            "error": str(exc),
        },
    )

from . import persist_part2 as _part2
from . import persist_part3 as _part3
from . import persist_part4 as _part4
globals().update({k:v for _module in (_part2,_part3,_part4,) for k,v in vars(_module).items() if not k.startswith("__")})

