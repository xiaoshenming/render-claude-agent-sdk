"""quality_cases — 渲染质量三态对比报告。

围绕单个 Scene 的修复链路采集 baseline / logic_fixed / layout_fixed
三态证据（视频 + 代码 + diff + JSON），用于事后复盘和质量样本沉淀。

作为观测能力，所有写入都必须 fail-soft：报告失败绝不影响主业务渲染流程。
"""

from .collector import QualityCaseCollector
from .pipeline_hook import (
    all_collectors,
    capture_baseline_for_paths,
    capture_logic_fixed,
    enqueue_finalize_and_persist_all,
    finalize_all,
    finalize_and_persist_all,
    get_collector,
    init_collectors_for_scenes,
    mark_logic_not_triggered_for_scenes,
)
from .schemas import (
    QualityCaseManifest,
    StageInfo,
    SCHEMA_VERSION,
)
from .storage import (
    is_quality_case_composition_enabled,
    is_quality_cases_enabled,
    quality_case_dir,
)


__all__ = [
    "QualityCaseCollector",
    "QualityCaseManifest",
    "StageInfo",
    "SCHEMA_VERSION",
    "is_quality_case_composition_enabled",
    "is_quality_cases_enabled",
    "quality_case_dir",
    "all_collectors",
    "capture_baseline_for_paths",
    "capture_logic_fixed",
    "enqueue_finalize_and_persist_all",
    "finalize_all",
    "finalize_and_persist_all",
    "get_collector",
    "init_collectors_for_scenes",
    "mark_logic_not_triggered_for_scenes",
]
