"""quality_cases.safety — 路径与代码内容的安全化处理。"""

from __future__ import annotations

import re


_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9_\-\.]+")


def safe_scene_name(scene_name: str) -> str:
    """将 scene_name 安全化为可作为目录名的字符串。"""
    if not scene_name:
        return "unknown_scene"
    cleaned = _SAFE_NAME_RE.sub("_", scene_name).strip("._-")
    return cleaned or "unknown_scene"


# 简单的密钥关键字列表，命中即整行打码。
_SECRET_KEY_RE = re.compile(
    r"(?i)(api[_-]?key|secret|token|password|access[_-]?key|"
    r"app[_-]?secret|private[_-]?key)\s*[:=]"
)


def redact_secrets(code: str) -> str:
    """对代码内容做最小程度的脱敏：命中疑似密钥的行直接打码。

    报告里保存的是 scene 代码（已经经过 ai_guardrails），密钥泄漏风险很低，
    这里只是兜底；不抛异常，永远返回 str。
    """
    if not code:
        return code
    out_lines: list[str] = []
    for line in code.splitlines():
        if _SECRET_KEY_RE.search(line):
            out_lines.append("# [REDACTED suspicious secret line]")
        else:
            out_lines.append(line)
    return "\n".join(out_lines) + ("\n" if code.endswith("\n") else "")
