"""quality_cases.persist — 把 case artifact 上传 COS + 入库 quality_case_reports。

约束：全 fail-soft，任何异常都只 warning，绝不影响主渲染流程。
COS Key 规则：quality-cases/job_{job_id}/{scene_name}/{case_id}/{filename}
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from sqlalchemy import text

from app.database.database import AsyncSessionLocal

from .safety import safe_scene_name
from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

JOB_COMPARISON_CASE_ID = "__job_6in1__"
JOB_COMPARISON_SCENE_NAME = "完整切片6合一"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"
LAYOUT_MVP_ROUND_ARTIFACT_TYPES = {
    "before_code": "text/x-python; charset=utf-8",
    "after_code": "text/x-python; charset=utf-8",
    "diff": "text/plain; charset=utf-8",
    "before_probe": "application/json; charset=utf-8",
    "after_probe": "application/json; charset=utf-8",
    "before_video": "video/mp4",
    "after_video": "video/mp4",
}



async def _insert_quality_case_fields(fields: dict[str, Any]) -> Optional[dict[str, Any]]:
    try:
        session = AsyncSessionLocal()
        try:
            await session.execute(
                text(
                    "DELETE FROM quality_case_reports "
                    "WHERE job_id=:job_id AND case_id=:case_id"
                ),
                {"job_id": fields["job_id"], "case_id": fields["case_id"]},
            )
            await session.execute(
                text(
                    """
                    INSERT INTO quality_case_reports (
                        id, job_id, scene_name, case_id, pipeline, aspect_ratio,
                        case_status, baseline_status, logic_status, layout_status,
                        top_issue_code, issue_count,
                        logic_repair_method, logic_repair_source,
                        layout_repair_method, layout_repair_source,
                        before_overlap_count, after_overlap_count,
                        before_max_overlap_ratio, after_max_overlap_ratio,
                        baseline_video_url, logic_video_url, layout_video_url, comparison_video_url,
                        baseline_code_url, logic_code_url, layout_code_url,
                        logic_diff_url, layout_diff_url,
                        layout_decision_before_url, layout_decision_after_url,
                        layout_bbox_before_url, layout_bbox_after_url,
                        manifest_url, report_url,
                        local_case_dir, created_at
                    ) VALUES (
                        :id, :job_id, :scene_name, :case_id, :pipeline, :aspect_ratio,
                        :case_status, :baseline_status, :logic_status, :layout_status,
                        :top_issue_code, :issue_count,
                        :logic_repair_method, :logic_repair_source,
                        :layout_repair_method, :layout_repair_source,
                        :before_overlap_count, :after_overlap_count,
                        :before_max_overlap_ratio, :after_max_overlap_ratio,
                        :baseline_video_url, :logic_video_url, :layout_video_url, :comparison_video_url,
                        :baseline_code_url, :logic_code_url, :layout_code_url,
                        :logic_diff_url, :layout_diff_url,
                        :layout_decision_before_url, :layout_decision_after_url,
                        :layout_bbox_before_url, :layout_bbox_after_url,
                        :manifest_url, :report_url,
                        :local_case_dir, NOW()
                    )
                    """
                ),
                fields,
            )
            await session.commit()
            return fields
        finally:
            await session.close()
    except Exception as exc:
        logger.warning(
            "[QUALITY_CASE] DB 写入失败 job=%s case=%s: %s",
            fields.get("job_id"), fields.get("case_id"), exc,
        )
        return None
async def delete_quality_case_reports_for_job(job_id: str) -> bool:
    """Delete stale quality-case rows for a job before persisting the current run.

    A job may be retried after quality cases were already persisted. Keeping
    those stale rows makes later summaries and ABC views mix multiple attempts.
    """
    if not job_id:
        return False
    try:
        session = AsyncSessionLocal()
        try:
            await session.execute(
                text("DELETE FROM quality_case_reports WHERE job_id=:job_id"),
                {"job_id": job_id},
            )
            await session.commit()
            logger.info(
                "[QUALITY_CASE] [%s] 已清理旧质量报告 job=%s",
                _ts(), job_id,
            )
            return True
        finally:
            await session.close()
    except Exception as exc:
        logger.warning("[QUALITY_CASE] 清理旧质量报告失败 job=%s: %s", job_id, exc)
        return False

from . import persist_part4 as _part4
globals().update({k:v for _module in (_part4,) for k,v in vars(_module).items() if not k.startswith("__")})

