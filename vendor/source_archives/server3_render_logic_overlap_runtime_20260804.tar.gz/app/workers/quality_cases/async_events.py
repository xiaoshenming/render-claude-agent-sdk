"""Fail-open quality-case background event reporting."""

from __future__ import annotations

from typing import Any


async def log_quality_case_async_event(
    event_type: str,
    task_data: dict[str, Any],
    *,
    payload: dict[str, Any] | None = None,
    evidence: dict[str, Any] | None = None,
) -> None:
    """Record observational evidence without affecting the render path."""
    try:
        from app.workers.task_dispatcher import log_render_quality_event

        await log_render_quality_event(
            event_type,
            task_data,
            payload=payload or {},
            evidence=evidence or {},
        )
    except Exception:
        return
