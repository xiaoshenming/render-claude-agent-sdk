"""quality_cases.compose — 单切片 6 合一三态对比视频合成。

布局固定为 1920x1080：
- 上排：A baseline / B logic fixed / C layout fixed 三个视频。
- 下排：INFO / B 逻辑代码 diff / C 布局代码 diff 三个代码面板。

失败一律返回 None，不影响主渲染流程。
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import textwrap
import uuid
from pathlib import Path
from typing import Any, Optional

from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

COMPARISON_FILE_NAME = "comparison_6in1.mp4"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"



def _comparison_panel_lines(
    case_dir: Path,
    manifest: QualityCaseManifest,
    *,
    compact: bool = False,
) -> dict[str, list[PanelLine]]:
    baseline = _stage_dict(manifest.baseline)
    logic = _stage_dict(manifest.logic_fixed)
    layout = _stage_dict(manifest.layout_fixed)

    a_path, b_path, c_path, labels = _resolve_stage_videos(case_dir, manifest)
    info_lines = [
        _line("INFO", "title"),
        _line(f"scene: {manifest.scene_name or case_dir.parent.name}", "text"),
        _line(f"job: {manifest.job_id or '-'}", "text"),
        _line(f"case: {manifest.case_id or case_dir.name}", "text"),
        _line(f"pipeline: {manifest.pipeline or '-'}", "muted"),
        _line(f"case_status: {manifest.case_status or '-'}", "muted"),
        _line(""),
        _line(f"A: {labels['a_label']} | {baseline.get('status') or '-'}", "text"),
        _line(f"   video: {a_path.name if a_path else 'missing'}", "muted"),
        _line(f"B: {labels['b_label']} | {logic.get('status') or '-'}", "text"),
        _line(f"   video: {b_path.name if b_path else 'missing/failed placeholder'}", "muted"),
        _line(f"C: {labels['c_label']} | {layout.get('status') or '-'}", "text"),
        _line(f"   video: {c_path.name if c_path else 'missing/failed placeholder'}", "muted"),
        _line(""),
        _line(
            "top_issue: "
            f"{_stage_value(logic, 'top_issue_code') or _stage_value(layout, 'top_issue_code') or '-'}",
            "warn",
        ),
        _line(
            "issue_count: "
            f"{int(logic.get('issue_count') or 0) + int(layout.get('issue_count') or 0) + int(baseline.get('issue_count') or 0)}",
            "muted",
        ),
    ]
    if manifest.notes:
        info_lines.extend([_line(""), _line("notes:", "muted")])
        for note in manifest.notes[:6]:
            info_lines.append(_line(f"- {note}", "muted"))

    return {
        "a": _wrap_colored_lines(info_lines, max_cols=82, max_lines=120),
        "b": _diff_panel_lines(
            title="B LOGIC DIFF",
            status=logic.get("status"),
            diff_path=_resolve_case_path(case_dir, logic.get("diff_path")),
            fallback_path=_resolve_case_path(case_dir, logic.get("code_path")),
            note="baseline.py -> logic_fixed.py",
            compact=compact or logic.get("status") in ("not_triggered", "available"),
        ),
        "c": _diff_panel_lines(
            title="C LAYOUT DIFF",
            status=layout.get("status"),
            diff_path=_resolve_case_path(case_dir, layout.get("diff_path")),
            fallback_path=_resolve_case_path(case_dir, layout.get("code_path")),
            note="logic/baseline -> layout_fixed.py",
            compact=compact or layout.get("status") in ("not_triggered", "available"),
        ),
    }
def _panel_drawtext_filters(
    *,
    input_label: str,
    output_label: str,
    title: str,
    title_color: str,
    lines: list[PanelLine],
    duration: float,
    font: str,
    allow_scroll: bool = True,
    tmp_dir: Path | None = None,
    tmp_files: list[Path] | None = None,
) -> list[str]:
    filters: list[str] = []
    current = input_label
    line_height = 18
    body_y = 58
    visible_lines = 29
    safe_title_color = _safe_color(title_color, fallback_key="title")

    if not lines:
        # 没有面板文字时，直接 copy 输入到输出标签，避免 filter chain 出现悬空 label
        filters.append(f"[{current}]null[{output_label}_body]")
        title_text = _escape_drawtext(title or "")
        filters.append(
            f"[{output_label}_body]"
            f"drawbox=x=0:y=0:w=iw:h=42:color={safe_title_color}@0.94:t=fill,"
            f"drawtext=text='{title_text}':x=14:y=12:fontsize=18:fontcolor=white{font}"
            f"[{output_label}]"
        )
        return filters

    max_scroll = max(0, (len(lines) - visible_lines) * line_height) if allow_scroll else 0
    scroll_speed = max_scroll / max(1.0, duration - 1.0) if max_scroll else 0.0

    use_textfile = tmp_dir is not None and tmp_files is not None
    if use_textfile:
        try:
            tmp_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            use_textfile = False

    for index, item in enumerate(lines):
        color = _safe_color(item.get("color"), fallback_key="text")
        raw_text = str(item.get("text", ""))
        if max_scroll:
            scroll_expr = f"min(max(0\\,t-1)*{scroll_speed:.3f}\\,{max_scroll:.3f})"
            y_expr = f"{body_y + index * line_height}-{scroll_expr}"
        else:
            y_expr = str(body_y + index * line_height)
        next_label = f"{output_label}_{index}"

        text_clause: str
        if use_textfile:
            try:
                tf = tmp_dir / f"{output_label}_{index:03d}_{uuid.uuid4().hex[:6]}.txt"
                tf.write_text(raw_text, encoding="utf-8")
                tmp_files.append(tf)
                text_clause = (
                    f"textfile='{_filter_path(tf)}':text_shaping=0"
                )
            except OSError:
                text_clause = f"text='{_escape_drawtext(raw_text)}'"
        else:
            text_clause = f"text='{_escape_drawtext(raw_text)}'"

        filters.append(
            f"[{current}]"
            f"drawtext={text_clause}:x=16:y={y_expr}:fontsize=13:"
            f"fontcolor={color}:tabsize=4:expansion=none{font}"
            f"[{next_label}]"
        )
        current = next_label

    title_text = _escape_drawtext(title or "")
    filters.append(
        f"[{current}]"
        f"drawbox=x=0:y=0:w=iw:h=42:color={safe_title_color}@0.94:t=fill,"
        f"drawtext=text='{title_text}':x=14:y=12:fontsize=18:fontcolor=white{font}"
        f"[{output_label}]"
    )
    return filters
