"""quality_cases.schemas — 报告数据结构。"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


SCHEMA_VERSION = 1

StageStatus = Literal[
    "available",        # baseline 已落盘
    "repaired",         # 阶段修复成功
    "repair_failed",    # 阶段尝试修复但失败
    "repair_degraded",  # 阶段产出后态但未达到修复标准
    "repair_skipped",   # 阶段被跳过/降级为未执行
    "record_only",      # 仅采集证据/无安全补丁
    "not_triggered",    # 阶段未触发（与上一阶段保持一致）
    "missing",          # artifact 落盘失败/缺失
]

CaseStatus = Literal["captured", "partial", "failed"]


@dataclass
class StageInfo:
    """单个阶段（baseline / logic_fixed / layout_fixed）的元数据。"""

    status: StageStatus = "missing"
    code_path: str | None = None
    video_path: str | None = None
    diff_path: str | None = None
    source: str | None = None
    repair_method: str | None = None
    repair_source: str | None = None
    repair_event_path: str | None = None
    actions_path: str | None = None
    issue_count: int = 0
    top_issue_code: str | None = None
    before_overlap_count: int | None = None
    after_overlap_count: int | None = None
    before_max_overlap_ratio: float | None = None
    after_max_overlap_ratio: float | None = None
    layout_repair_outcome: str | None = None
    overlap_count_delta: int | None = None
    max_overlap_ratio_delta: float | None = None
    before_decision_path: str | None = None
    after_decision_path: str | None = None
    bbox_before_path: str | None = None
    bbox_after_path: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class QualityCaseManifest:
    """质量报告 manifest（机器可读入口）。"""

    schema_version: int = SCHEMA_VERSION
    case_id: str = ""
    job_id: str = ""
    scene_name: str = ""
    pipeline: str = "streaming"          # streaming | planning
    case_type: str = "quality_review"    # 触发类型，便于扩展
    aspect_ratio: str = "16:9"
    created_at: str = ""
    case_status: CaseStatus = "captured"
    case_dir: str = ""
    baseline: StageInfo = field(default_factory=StageInfo)
    logic_fixed: StageInfo = field(default_factory=lambda: StageInfo(status="not_triggered"))
    layout_fixed: StageInfo = field(default_factory=lambda: StageInfo(status="not_triggered"))
    artifacts: dict[str, str] = field(default_factory=dict)
    layout_mvp: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "case_id": self.case_id,
            "job_id": self.job_id,
            "scene_name": self.scene_name,
            "pipeline": self.pipeline,
            "case_type": self.case_type,
            "aspect_ratio": self.aspect_ratio,
            "created_at": self.created_at,
            "case_status": self.case_status,
            "case_dir": self.case_dir,
            "stages": {
                "baseline": self.baseline.to_dict(),
                "logic_fixed": self.logic_fixed.to_dict(),
                "layout_fixed": self.layout_fixed.to_dict(),
            },
            "artifacts": dict(self.artifacts),
        }
        if self.layout_mvp:
            payload["layout_mvp"] = dict(self.layout_mvp)
        if self.notes:
            payload["notes"] = list(self.notes)
        return payload
