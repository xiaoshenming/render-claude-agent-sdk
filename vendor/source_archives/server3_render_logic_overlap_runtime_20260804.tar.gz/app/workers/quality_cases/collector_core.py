"""quality_cases.collector — 三态证据采集器。

只负责"收集"，不参与修复决策。所有 IO 都 fail-soft：
任何写入失败都只 warning，绝不抛异常影响主业务。
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from . import storage
from .diff import write_unified_diff
from .report import write_report
from .safety import redact_secrets
from .schemas import QualityCaseManifest, StageInfo


logger = logging.getLogger("render")

_CST = timezone(timedelta(hours=8))


def _now_iso() -> str:
    return datetime.now(_CST).replace(microsecond=0).isoformat()


def _new_case_id() -> str:
    # 时间序前缀 + 短随机，便于按时间排序
    ts = time.strftime("%Y%m%dT%H%M%S")
    return f"{ts}_{uuid.uuid4().hex[:8]}"


class QualityCaseCollector:
    """单 Scene 三态证据采集器。

    使用方式::

        collector = QualityCaseCollector.create_if_enabled(
            ctx=ctx, scene_name="Scene_01_Foo", pipeline="streaming",
        )
        if collector:
            collector.capture_baseline(script_path=..., video_path=...)
            collector.capture_logic_fixed(script_path=..., video_path=..., issues=[...])
            collector.capture_layout_before(script_path=..., decision={...})
            collector.capture_layout_fixed(script_path=..., video_path=..., ...)
            artifact = collector.finalize()
    """


class CollectorCoreMixin:
    def __init__(
        self,
        *,
        case_dir: Path,
        job_id: str,
        scene_name: str,
        pipeline: str,
        aspect_ratio: str,
        case_id: str | None = None,
    ) -> None:
        self._case_dir = case_dir
        self._manifest = QualityCaseManifest(
            case_id=case_id or _new_case_id(),
            job_id=job_id,
            scene_name=scene_name,
            pipeline=pipeline,
            aspect_ratio=aspect_ratio,
            created_at=_now_iso(),
            case_dir=str(case_dir),
        )
        self._has_baseline = False
        self._baseline_code_path: Path | None = None
        self._logic_code_path: Path | None = None
        self._layout_before_code_path: Path | None = None
        self._finalized = False
        # 确保目录就绪（失败也不致命）
        storage.ensure_dir(case_dir)

    @classmethod
    def create_if_enabled(
        cls,
        *,
        ctx,
        scene_name: str,
        pipeline: str,
    ) -> "QualityCaseCollector | None":
        if not storage.is_quality_cases_enabled():
            return None
        try:
            media_root = getattr(ctx, "media_root", None) or os.getcwd()
            job_id = getattr(ctx, "job_id", "unknown")
            aspect_ratio = getattr(ctx, "aspect_ratio", "16:9")
            case_id = _new_case_id()
            case_dir = storage.quality_case_dir(
                media_root=media_root,
                job_id=str(job_id),
                scene_name=scene_name,
                case_id=case_id,
            )
            return cls(
                case_dir=case_dir,
                job_id=str(job_id),
                scene_name=scene_name,
                pipeline=pipeline,
                aspect_ratio=str(aspect_ratio),
                case_id=case_id,
            )
        except Exception as exc:
            logger.warning("[QUALITY_CASE] create collector failed: %s", exc)
            return None

    def capture_baseline(
        self,
        *,
        script_path: str | None,
        video_path: str | None,
        source: str = "initial_render",
    ) -> None:
        """采集 baseline（已通过渲染错误修复后的可播放基线）。"""
        try:
            stage = StageInfo(status="available", source=source)
            if storage.capture_code() and script_path:
                code_dst = self._case_dir / "baseline.py"
                if self._save_code(script_path, code_dst):
                    stage.code_path = code_dst.name
                    self._baseline_code_path = code_dst
            if storage.capture_video() and video_path:
                video_dst = self._case_dir / "baseline.mp4"
                if storage.safe_copy_file(video_path, video_dst):
                    stage.video_path = video_dst.name
            if not stage.code_path and not stage.video_path:
                stage.status = "missing"
            self._manifest.baseline = stage
            self._has_baseline = stage.status == "available"
        except Exception as exc:
            logger.warning("[QUALITY_CASE] capture_baseline failed: %s", exc)
            self._manifest.baseline = StageInfo(status="missing", error=str(exc))

    def capture_logic_fixed(
        self,
        *,
        script_path: str | None,
        video_path: str | None,
        issues: list[dict] | None = None,
        repair_event: dict | None = None,
        status: str = "repaired",
        error: str | None = None,
    ) -> None:
        """采集数学逻辑修复后的代码 / 视频 / diff / issue 证据。"""
        try:
            stage = StageInfo(status=status)  # type: ignore[arg-type]
            stage.error = error
            issues = issues or []
            stage.issue_count = len(issues)
            if issues:
                top = issues[0]
                if isinstance(top, dict):
                    stage.top_issue_code = top.get("code") or top.get("issue_code")
            if repair_event is not None:
                stage.repair_method = _repair_method_from_event(repair_event)
                stage.repair_source = _repair_source_from_event(repair_event)

            if storage.capture_code() and script_path:
                code_dst = self._case_dir / "logic_fixed.py"
                if self._save_code(script_path, code_dst):
                    stage.code_path = code_dst.name
                    self._logic_code_path = code_dst
                    if self._baseline_code_path and code_dst != self._baseline_code_path:
                        diff_dst = self._case_dir / "logic_fix.diff"
                        if write_unified_diff(
                            before_path=self._baseline_code_path,
                            after_path=code_dst,
                            output_path=diff_dst,
                            fromfile="baseline.py",
                            tofile="logic_fixed.py",
                        ) is not None:
                            stage.diff_path = diff_dst.name

            if storage.capture_video() and video_path and status in {
                "repaired",
                "repair_failed",
                "available",
            }:
                video_dst = self._case_dir / "logic_fixed.mp4"
                if storage.safe_copy_file(video_path, video_dst):
                    stage.video_path = video_dst.name
                    if status == "repair_failed":
                        stage.source = "fallback_original"

            if issues:
                storage.safe_write_json(
                    self._case_dir / "math_logic_issues.json",
                    {"issues": issues},
                )
            if repair_event is not None:
                if storage.safe_write_json(
                    self._case_dir / "logic_repair_event.json",
                    repair_event,
                ):
                    stage.repair_event_path = "logic_repair_event.json"

            self._manifest.logic_fixed = stage
        except Exception as exc:
            logger.warning("[QUALITY_CASE] capture_logic_fixed failed: %s", exc)
            self._manifest.logic_fixed = StageInfo(status="missing", error=str(exc))

    def mark_logic_not_triggered(self, reason: str | None = None) -> None:
        """如果数学逻辑修复未触发，沿用 baseline 作为 logic_fixed。"""
        try:
            stage = StageInfo(status="not_triggered")
            base = self._manifest.baseline
            stage.code_path = base.code_path
            stage.video_path = base.video_path
            if reason:
                stage.source = "math_logic_skipped"
                self._manifest.notes.append(f"math_logic_skipped: {reason}")
            self._manifest.logic_fixed = stage
            if self._baseline_code_path:
                self._logic_code_path = self._baseline_code_path
        except Exception as exc:
            logger.warning("[QUALITY_CASE] mark_logic_not_triggered failed: %s", exc)

