"""quality_cases.storage — 本地 artifact 存储。"""

from __future__ import annotations

import json
import logging
import os
import shutil
from pathlib import Path
from typing import Any

from .safety import safe_scene_name


logger = logging.getLogger("render")


def is_quality_cases_enabled() -> bool:
    """读取 QUALITY_CASE_REPORT_ENABLED 开关，默认关闭。"""
    raw = os.getenv("QUALITY_CASE_REPORT_ENABLED")
    if raw is None:
        return False
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def is_quality_case_composition_enabled() -> bool:
    """读取 6in1 对比视频合成开关，默认关闭以避免生产 ffmpeg 开销。"""
    return _env_bool("QUALITY_CASE_COMPOSE_ENABLED", False)


def capture_video() -> bool:
    return _env_bool("QUALITY_CASE_CAPTURE_VIDEO", True)


def capture_code() -> bool:
    return _env_bool("QUALITY_CASE_CAPTURE_CODE", True)


def capture_bbox() -> bool:
    return _env_bool("QUALITY_CASE_CAPTURE_BBOX", True)


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def quality_case_dir(
    *,
    media_root: str,
    job_id: str,
    scene_name: str,
    case_id: str,
) -> Path:
    """返回本 case 的本地落盘目录（不创建）。"""
    safe = safe_scene_name(scene_name)
    return (
        Path(media_root)
        / "quality_cases"
        / f"job_{job_id}"
        / safe
        / case_id
    )


def ensure_dir(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        return True
    except Exception as exc:
        logger.warning("[QUALITY_CASE] mkdir failed: %s: %s", path, exc)
        return False


def safe_copy_file(src: str | Path, dst: str | Path) -> bool:
    """复制文件，失败只 warning。"""
    try:
        src_path = Path(src)
        dst_path = Path(dst)
        if not src_path.exists():
            logger.warning("[QUALITY_CASE] copy src missing: %s", src_path)
            return False
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_path, dst_path)
        return True
    except Exception as exc:
        logger.warning(
            "[QUALITY_CASE] copy failed %s -> %s: %s", src, dst, exc,
        )
        return False


def safe_write_text(path: str | Path, content: str) -> bool:
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return True
    except Exception as exc:
        logger.warning("[QUALITY_CASE] write text failed %s: %s", path, exc)
        return False


def safe_write_json(path: str | Path, data: Any) -> bool:
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        return True
    except Exception as exc:
        logger.warning("[QUALITY_CASE] write json failed %s: %s", path, exc)
        return False
