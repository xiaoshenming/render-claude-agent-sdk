from __future__ import annotations

def _now_iso() -> str:
    return datetime.now(_CST).replace(microsecond=0).isoformat()
def _new_case_id() -> str:
    # 时间序前缀 + 短随机，便于按时间排序
    ts = time.strftime("%Y%m%dT%H%M%S")
    return f"{ts}_{uuid.uuid4().hex[:8]}"
def _summarize_layout_decision(decision: dict) -> dict[str, Any]:
    """从 LayoutDecision dict 抽取 issue 与 overlap 摘要。"""
    if not isinstance(decision, dict):
        return {}
    issues = decision.get("issues") or []
    if not isinstance(issues, list):
        return {}
    overlap_count = 0
    max_ratio = 0.0
    top_issue_code = None
    issue_count = 0
    for item in issues:
        if not isinstance(item, dict):
            continue
        issue_count += 1
        if top_issue_code is None:
            top_issue_code = (
                item.get("code")
                or item.get("issue_code")
                or item.get("type")
            )
        ratio = item.get("overlap_ratio")
        if isinstance(ratio, (int, float)) and ratio > 0:
            overlap_count += 1
            if ratio > max_ratio:
                max_ratio = float(ratio)
    return {
        "issue_count": issue_count,
        "top_issue_code": top_issue_code,
        "overlap_count": overlap_count,
        "max_overlap_ratio": max_ratio,
    }
def _apply_layout_issue_summary(stage: StageInfo, summary: dict[str, Any]) -> None:
    stage.issue_count = int(summary.get("issue_count") or 0)
    top_issue_code = summary.get("top_issue_code")
    if top_issue_code:
        stage.top_issue_code = str(top_issue_code)
def _is_layout_mvp_gate_pass(
    metadata: dict | None,
    *,
    repair_method: str | None,
    repair_source: str | None,
) -> bool:
    if str(repair_method or "").strip() == "layout_mvp_0llm_gate_pass":
        return True
    if str(repair_source or "").strip() == "gate":
        return True
    if not isinstance(metadata, dict):
        return False
    reason = str(metadata.get("record_only_reason") or "").strip()
    try:
        blocking_count = int(metadata.get("before_blocking_issue_count") or 0)
    except (TypeError, ValueError):
        blocking_count = 0
    return reason == "no_blocking_layout_issue" and blocking_count <= 0
def _layout_repair_outcome(
    *,
    before_count: int,
    after_count: int,
    before_max: float,
    after_max: float,
) -> str:
    eps = 1e-9
    if after_count > before_count or after_max > before_max + eps:
        return "worse"
    if after_count < before_count and after_max < before_max - eps:
        return "improved"
    return "unchanged"
def _apply_layout_repair_outcome(stage: StageInfo) -> None:
    if (
        stage.before_overlap_count is None
        or stage.after_overlap_count is None
        or stage.before_max_overlap_ratio is None
        or stage.after_max_overlap_ratio is None
    ):
        return
    before_count = int(stage.before_overlap_count)
    after_count = int(stage.after_overlap_count)
    before_max = float(stage.before_max_overlap_ratio)
    after_max = float(stage.after_max_overlap_ratio)
    stage.layout_repair_outcome = _layout_repair_outcome(
        before_count=before_count,
        after_count=after_count,
        before_max=before_max,
        after_max=after_max,
    )
    stage.overlap_count_delta = before_count - after_count
    stage.max_overlap_ratio_delta = round(before_max - after_max, 6)
def _write_layout_bbox_snapshot(
    case_dir: Path,
    filename: str,
    decision: dict[str, Any] | None,
) -> str | None:
    snapshot = _layout_bbox_snapshot(decision)
    if snapshot is None:
        return None
    return filename if storage.safe_write_json(case_dir / filename, snapshot) else None
def _repair_method_from_event(event: dict | None) -> str | None:
    if not isinstance(event, dict):
        return None
    for key in ("method", "repair_method", "source", "status"):
        value = event.get(key)
        if value:
            return str(value)
    return None
def _repair_source_from_event(event: dict | None) -> str | None:
    if not isinstance(event, dict):
        return None
    for key in ("source", "repair_source"):
        value = event.get(key)
        if value:
            return str(value)
    return _repair_source_from_method(_repair_method_from_event(event))
def _repair_method_from_actions(actions: list[dict] | None) -> str | None:
    if not actions:
        return None
    first = actions[0]
    if not isinstance(first, dict):
        return None
    for key in ("method", "repair_method", "source", "type"):
        value = first.get(key)
        if value:
            return str(value)
    return None
def _repair_source_from_method(method: str | None) -> str | None:
    if not method:
        return None
    lowered = method.lower()
    if "memory" in lowered:
        return "repair_memory"
    if "deterministic" in lowered or "nudge" in lowered:
        return "deterministic"
    if "judge" in lowered:
        return "judge"
    if "patch" in lowered or "slice" in lowered or "llm" in lowered:
        return "llm"
    return None
def _layout_bbox_snapshot(decision: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(decision, dict):
        return None
    issues = decision.get("issues") or []
    if not isinstance(issues, list):
        issues = []
    payload: dict[str, Any] = {
        "scene_name": decision.get("scene_name"),
        "artifact_path": decision.get("artifact_path"),
        "issues": [_layout_issue_bbox_snapshot(issue) for issue in issues if isinstance(issue, dict)],
    }
    return {key: value for key, value in payload.items() if value is not None}
def _layout_issue_bbox_snapshot(issue: dict[str, Any]) -> dict[str, Any]:
    objects = []
    for index, item in enumerate(issue.get("objects") or []):
        if not isinstance(item, dict) or not isinstance(item.get("bbox"), dict):
            continue
        label = _layout_object_label(item)
        objects.append({
            "object_id": _stable_layout_object_id(item, index=index),
            "label": label,
            "kind": item.get("kind"),
            "class": item.get("class"),
            "bbox": item.get("bbox"),
        })
    if isinstance(issue.get("bbox"), dict):
        fallback = {
            "label": issue.get("label"),
            "class": issue.get("class"),
            "kind": issue.get("kind"),
            "bbox": issue.get("bbox"),
        }
        objects.append({
            "object_id": _stable_layout_object_id(fallback, index=len(objects)),
            "label": _layout_object_label(fallback),
            "kind": fallback.get("kind"),
            "class": fallback.get("class"),
            "bbox": fallback.get("bbox"),
        })
    return {
        "issue_id": _stable_layout_issue_id(issue, objects),
        "code": issue.get("code") or issue.get("issue_code") or issue.get("type"),
        "overlap_ratio": issue.get("overlap_ratio"),
        "objects": objects,
    }
def _layout_object_label(item: dict[str, Any]) -> str | None:
    for key in ("label", "text", "class", "kind", "path"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value)[:160]
    return None
def _stable_layout_object_id(item: dict[str, Any], *, index: int) -> str:
    identity_parts = [
        str(item.get("path") or ""),
        str(item.get("id") or item.get("object_id") or ""),
        str(item.get("label") or item.get("text") or "")[:160],
    ]
    parts = [
        *identity_parts,
        str(item.get("class") or ""),
        str(item.get("kind") or ""),
    ]
    if not any(identity_parts):
        bbox = item.get("bbox") if isinstance(item.get("bbox"), dict) else {}
        parts.extend([
            f"fallback:{index}",
            str(bbox.get("center_x") or ""),
            str(bbox.get("center_y") or ""),
            str(bbox.get("width") or ""),
            str(bbox.get("height") or ""),
        ])
    key = "|".join(parts)
    return f"layout_obj_{uuid.uuid5(uuid.NAMESPACE_URL, key).hex[:12]}"
def _stable_layout_issue_id(
    issue: dict[str, Any],
    objects: list[dict[str, Any]],
) -> str:
    object_ids = "|".join(
        str(item.get("object_id") or "") for item in objects if isinstance(item, dict)
    )
    key = "|".join([
        str(issue.get("code") or issue.get("issue_code") or issue.get("type") or ""),
        object_ids,
    ])
    return f"layout_issue_{uuid.uuid5(uuid.NAMESPACE_URL, key).hex[:12]}"

