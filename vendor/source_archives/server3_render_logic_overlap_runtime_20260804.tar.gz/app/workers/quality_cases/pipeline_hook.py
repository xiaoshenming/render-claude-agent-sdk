"""quality_cases.pipeline_hook — 管线接入辅助函数。

对外提供薄薄一层 helper，让 streaming / planning / layout
各自只需一两行代码就能完成三态采集与最终落盘。所有函数 fail-soft。
"""
# ruff: noqa: F401  # Preserve the historical facade and monkeypatch surface.

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any

from .async_events import log_quality_case_async_event as _log_quality_case_async_event
from .case_builders import (
    TASK_DATA_KEY as _TASK_DATA_KEY,
    all_collectors,
    capture_baseline_for_paths,
    capture_logic_fixed,
    finalize_all_inner as _finalize_all_inner_impl,
    get_collector,
    init_collectors_for_scenes,
    mark_logic_not_triggered_for_scenes,
)
from .storage import is_quality_case_composition_enabled, is_quality_cases_enabled


logger = logging.getLogger("render")

_FINALIZE_SEMAPHORE: asyncio.Semaphore | None = None
_FINALIZE_SEMAPHORE_LIMIT = 0
_FFMPEG_SEMAPHORE: asyncio.Semaphore | None = None
_FFMPEG_SEMAPHORE_LIMIT = 0
_COS_SEMAPHORE: asyncio.Semaphore | None = None
_COS_SEMAPHORE_LIMIT = 0


def _env_int(name: str, default: int, *, minimum: int = 1, maximum: int = 64) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _finalize_semaphore() -> asyncio.Semaphore:
    global _FINALIZE_SEMAPHORE, _FINALIZE_SEMAPHORE_LIMIT
    limit = _env_int("QUALITY_CASE_ASYNC_FINALIZE_CONCURRENCY", 1)
    if _FINALIZE_SEMAPHORE is None or _FINALIZE_SEMAPHORE_LIMIT != limit:
        _FINALIZE_SEMAPHORE = asyncio.Semaphore(limit)
        _FINALIZE_SEMAPHORE_LIMIT = limit
    return _FINALIZE_SEMAPHORE


def _ffmpeg_semaphore() -> asyncio.Semaphore:
    global _FFMPEG_SEMAPHORE, _FFMPEG_SEMAPHORE_LIMIT
    fallback = _env_int("QUALITY_CASE_BACKGROUND_RESOURCE_CONCURRENCY", 1)
    limit = _env_int("QUALITY_CASE_FFMPEG_CONCURRENCY", fallback)
    if _FFMPEG_SEMAPHORE is None or _FFMPEG_SEMAPHORE_LIMIT != limit:
        _FFMPEG_SEMAPHORE = asyncio.Semaphore(limit)
        _FFMPEG_SEMAPHORE_LIMIT = limit
    return _FFMPEG_SEMAPHORE


def _cos_semaphore() -> asyncio.Semaphore:
    global _COS_SEMAPHORE, _COS_SEMAPHORE_LIMIT
    fallback = _env_int("QUALITY_CASE_BACKGROUND_RESOURCE_CONCURRENCY", 1)
    limit = _env_int("QUALITY_CASE_COS_UPLOAD_CONCURRENCY", fallback)
    if _COS_SEMAPHORE is None or _COS_SEMAPHORE_LIMIT != limit:
        _COS_SEMAPHORE = asyncio.Semaphore(limit)
        _COS_SEMAPHORE_LIMIT = limit
    return _COS_SEMAPHORE


async def _run_with_limit(awaitable, semaphore: asyncio.Semaphore):
    async with semaphore:
        return await awaitable


def finalize_all(task_data: dict | None) -> list[dict[str, Any]]:
    """完成所有 collector 的落盘，返回 artifact 路径列表。

    同时把每个 case 的 manifest/report 路径附加到 RenderLog（如果存在）。

    注意：这个函数只做本地落盘 + RenderLog 回写。
    若需要把 artifact 上传 COS 并写入 quality_case_reports 表，
    请改调用 `finalize_and_persist_all`（async）。
    """
    return _finalize_all_inner(task_data, _collected_for_persist=None)


async def finalize_and_persist_all(task_data: dict | None) -> list[dict[str, Any]]:
    """finalize + 可选 6in1 合成 + 上传 COS + 写 quality_case_reports。

    fail-soft：任何子步骤失败都只 warning，不影响主流程。
    返回值同 `finalize_all`。
    """
    async with _finalize_semaphore():
        return await _finalize_and_persist_all_inner(task_data)


async def _finalize_and_persist_all_inner(
    task_data: dict | None,
) -> list[dict[str, Any]]:
    collected: list[tuple[Any, Any, Any]] = []
    artifacts = _finalize_all_inner(task_data, _collected_for_persist=collected)
    if not collected:
        return artifacts
    collector_obj = (
        task_data.get("_error_collector") if isinstance(task_data, dict) else None
    )

    compose_enabled = is_quality_case_composition_enabled()

    # 延迟导入：避免在不需要时引入 ffmpeg/COS 依赖
    try:
        from .persist import (
            delete_quality_case_reports_for_job,
            persist_quality_case,
            persist_quality_job_comparison,
        )

        if compose_enabled:
            from .compose import compose_job_comparison_video, compose_three_state_video
        else:
            compose_job_comparison_video = None
            compose_three_state_video = None
    except Exception as exc:
        logger.warning("[QUALITY_CASE] persist 模块加载失败: %s", exc)
        return artifacts

    scene_entries: list[tuple[str, Any, Any]] = []
    job_id = ""
    for _, _, manifest in collected:
        job_id = job_id or getattr(manifest, "job_id", "")
    if job_id:
        try:
            await delete_quality_case_reports_for_job(job_id)
        except Exception as exc:
            logger.warning("[QUALITY_CASE] 清理旧质量报告异常 job=%s: %s", job_id, exc)
    for scene_name, case_dir, manifest in collected:
        comparison_path = None
        if compose_enabled and compose_three_state_video is not None:
            try:
                comparison_path = await _run_with_limit(
                    compose_three_state_video(case_dir, manifest),
                    _ffmpeg_semaphore(),
                )
            except Exception as exc:
                logger.warning(
                    "[QUALITY_CASE] compose %s 异常: %s",
                    scene_name,
                    exc,
                )
                comparison_path = None
        if comparison_path is not None:
            scene_entries.append((scene_name, case_dir, comparison_path))
        try:
            await _run_with_limit(
                persist_quality_case(
                    case_dir=case_dir,
                    manifest=manifest,
                    comparison_path=comparison_path,
                    collector=collector_obj,
                ),
                _cos_semaphore(),
            )
        except Exception as exc:
            logger.warning(
                "[QUALITY_CASE] persist %s 异常: %s",
                scene_name,
                exc,
            )
    if (
        compose_enabled
        and compose_job_comparison_video is not None
        and job_id
        and scene_entries
    ):
        try:
            job_comparison_path = await _run_with_limit(
                compose_job_comparison_video(job_id, scene_entries),
                _ffmpeg_semaphore(),
            )
        except Exception as exc:
            logger.warning("[QUALITY_CASE] job 级 6in1 compose 异常: %s", exc)
            job_comparison_path = None
        if job_comparison_path is not None:
            try:
                await _run_with_limit(
                    persist_quality_job_comparison(
                        job_id=job_id,
                        comparison_path=job_comparison_path,
                        collector=collector_obj,
                    ),
                    _cos_semaphore(),
                )
            except Exception as exc:
                logger.warning("[QUALITY_CASE] job 级 6in1 persist 异常: %s", exc)
    return artifacts


def enqueue_finalize_and_persist_all(task_data: dict | None) -> asyncio.Task | None:
    """Schedule full quality-case report generation without blocking the video path."""
    if not isinstance(task_data, dict):
        return None
    bag = task_data.get(_TASK_DATA_KEY)
    if not isinstance(bag, dict) or not bag:
        return None
    job_id = str(task_data.get("job_id") or "")
    jobs = task_data.setdefault("_quality_case_async_jobs", [])
    active_jobs = [
        item
        for item in jobs
        if isinstance(item, dict) and item.get("status") in {"pending", "running"}
    ]
    if len(active_jobs) >= _env_int("QUALITY_CASE_ASYNC_QUEUE_MAX", 2, minimum=1):
        skipped = {
            "status": "skipped_queue_full",
            "job_id": job_id,
            "scheduled_at": time.time(),
        }
        jobs.append(skipped)
        return None
    job = {
        "status": "pending",
        "job_id": job_id,
        "scheduled_at": time.time(),
    }
    jobs.append(job)

    async def _runner() -> None:
        try:
            job["status"] = "running"
            artifacts = await finalize_and_persist_all(task_data)
            job.update(
                {
                    "status": "succeeded",
                    "finished_at": time.time(),
                    "artifact_count": len(artifacts or []),
                }
            )
            await _log_quality_case_async_event(
                "quality_case_async_succeeded",
                task_data,
                payload={
                    "status": "succeeded",
                    "artifact_count": len(artifacts or []),
                },
            )
        except Exception as exc:
            error = {
                "error_type": type(exc).__name__,
                "error_message": str(exc)[:500],
            }
            job.update(
                {
                    "status": "failed",
                    "finished_at": time.time(),
                    **error,
                }
            )
            task_data.setdefault("_quality_case_async_errors", []).append(error)
            logger.warning(
                "[QUALITY_CASE] async finalize failed: job=%s error=%s: %s",
                job_id,
                type(exc).__name__,
                exc,
            )
            await _log_quality_case_async_event(
                "quality_case_async_failed",
                task_data,
                payload={"status": "failed"},
                evidence=error,
            )

    try:
        task = asyncio.create_task(_runner())
    except RuntimeError:
        logger.warning("[QUALITY_CASE] no running event loop for async finalize")
        job["status"] = "failed"
        job["error_type"] = "RuntimeError"
        job["error_message"] = "no running event loop"
        return None
    job["task_id"] = id(task)
    return task


def _finalize_all_inner(
    task_data: dict | None,
    *,
    _collected_for_persist: list | None,
) -> list[dict[str, Any]]:
    return _finalize_all_inner_impl(
        task_data,
        collected_for_persist=_collected_for_persist,
    )
