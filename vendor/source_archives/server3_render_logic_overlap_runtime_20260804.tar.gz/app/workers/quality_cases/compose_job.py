"""quality_cases.compose — 单切片 6 合一三态对比视频合成。

布局固定为 1920x1080：
- 上排：A baseline / B logic fixed / C layout fixed 三个视频。
- 下排：INFO / B 逻辑代码 diff / C 布局代码 diff 三个代码面板。

失败一律返回 None，不影响主渲染流程。
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import textwrap
import uuid
from pathlib import Path
from typing import Any, Optional

from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

COMPARISON_FILE_NAME = "comparison_6in1.mp4"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"



from .compose_helpers import *
from .compose_panels import *
async def compose_job_comparison_video(
    job_id: str,
    scene_entries: list[tuple[str, Path, Path]],
    *,
    timeout_sec: float = 240.0,
    force: bool = False,
) -> Optional[Path]:
    """把所有 scene 的 comparison_6in1.mp4 串成完整 job_comparison_6in1.mp4。"""
    valid_entries = [
        (scene_name, case_dir, comparison_path)
        for scene_name, case_dir, comparison_path in sorted(scene_entries, key=lambda x: x[0])
        if comparison_path.exists() and comparison_path.stat().st_size > 0
    ]
    if not valid_entries:
        logger.warning("[QUALITY_CASE] job=%s 没有可串联的 6in1 scene 片段", job_id)
        return None
    if not shutil.which("ffmpeg"):
        logger.warning("[QUALITY_CASE] ffmpeg 不可用，跳过 job 级 6in1 串联")
        return None
    if not shutil.which("ffprobe"):
        logger.warning("[QUALITY_CASE] ffprobe 不可用，跳过 job 级 6in1 验证")
        return None

    first_case_dir = valid_entries[0][1]
    job_dir = first_case_dir.parent.parent if first_case_dir.parent else first_case_dir
    output = job_dir / JOB_COMPARISON_FILE_NAME
    if output.exists() and output.stat().st_size > 0 and not force:
        if await _probe_video_size(output) == (1920, 1080):
            return output
        output.unlink()
    if force and output.exists():
        output.unlink()

    list_path = job_dir / "job_comparison_6in1.concat.txt"
    try:
        list_path.write_text(
            "\n".join(_concat_file_entry(path) for _, _, path in valid_entries) + "\n",
            encoding="utf-8",
        )
    except Exception as exc:
        logger.warning("[QUALITY_CASE] job 级 concat list 写入失败 job=%s: %s", job_id, exc)
        return None

    cmd = [
        "ffmpeg",
        "-y",
        "-loglevel",
        "error",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        str(list_path),
        "-map",
        "0:v:0",
        "-vf",
        "fps=24,format=yuv420p",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "26",
        "-movflags",
        "+faststart",
        "-an",
        str(output),
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            logger.warning("[QUALITY_CASE] job 级 6in1 串联超时 job=%s", job_id)
            return None
        if proc.returncode != 0:
            logger.warning(
                "[QUALITY_CASE] job 级 6in1 串联失败 rc=%s err=%s",
                proc.returncode,
                (stderr or b"").decode(errors="replace")[:500],
            )
            return None
        if not output.exists() or output.stat().st_size == 0:
            logger.warning("[QUALITY_CASE] job_comparison_6in1.mp4 输出为空 job=%s", job_id)
            return None
        logger.info("[QUALITY_CASE] job 级 6in1 串联成功 job=%s -> %s", job_id, output)
        return output
    except Exception as exc:
        logger.warning("[QUALITY_CASE] job 级 6in1 串联异常 job=%s: %s", job_id, exc)
        return None
def _concat_file_entry(path: Path) -> str:
    return "file '" + str(path).replace("'", "'\\''") + "'"
