"""quality_cases.report — 生成 report.md（人可读入口）。"""

from __future__ import annotations

import logging
from pathlib import Path

from .schemas import QualityCaseManifest, StageInfo
from .storage import safe_write_text


logger = logging.getLogger("render")


def render_report_markdown(manifest: QualityCaseManifest) -> str:
    """根据 manifest 渲染 Markdown 报告文本。"""
    lines: list[str] = []
    lines.append(f"# 渲染质量三态对比报告")
    lines.append("")
    lines.append(f"- 场景: `{manifest.scene_name}`")
    lines.append(f"- 任务: `{manifest.job_id}`")
    lines.append(f"- 管线: `{manifest.pipeline}`")
    lines.append(f"- 案例 ID: `{manifest.case_id}`")
    lines.append(f"- 比例: `{manifest.aspect_ratio}`")
    lines.append(f"- 创建时间: `{manifest.created_at}`")
    lines.append(f"- 整体状态: `{manifest.case_status}`")
    lines.append("")

    lines.append("## 结论")
    lines.append("")
    lines.append(f"- baseline: **{manifest.baseline.status}**"
                 + (f" (来源: {manifest.baseline.source})"
                    if manifest.baseline.source else ""))
    lines.append(f"- logic_fixed: **{manifest.logic_fixed.status}**"
                 + (f" (issue_count={manifest.logic_fixed.issue_count})"
                    if manifest.logic_fixed.issue_count else ""))
    layout = manifest.layout_fixed
    overlap_summary = ""
    if layout.before_overlap_count is not None or layout.after_overlap_count is not None:
        overlap_summary = (
            f" (overlap {layout.before_overlap_count} -> {layout.after_overlap_count}"
            f", max_ratio {layout.before_max_overlap_ratio} -> {layout.after_max_overlap_ratio})"
        )
        if layout.layout_repair_outcome:
            overlap_summary += f" [{layout.layout_repair_outcome}]"
    lines.append(f"- layout_fixed: **{layout.status}**{overlap_summary}")
    lines.append("")

    lines.append("## 三态视频")
    lines.append("")
    lines += _stage_video_lines("baseline", manifest.baseline)
    lines += _stage_video_lines("logic_fixed", manifest.logic_fixed)
    lines += _stage_video_lines("layout_fixed", manifest.layout_fixed)
    lines.append("")

    lines.append("## 代码 diff")
    lines.append("")
    if manifest.logic_fixed.diff_path:
        lines.append(f"- logic_fix.diff: `{manifest.logic_fixed.diff_path}`")
    else:
        lines.append("- logic_fix.diff: 未触发")
    if manifest.layout_fixed.diff_path:
        lines.append(f"- layout_fix.diff: `{manifest.layout_fixed.diff_path}`")
    else:
        lines.append("- layout_fix.diff: 未触发")
    lines.append("")

    lines.append("## 数学逻辑修复证据")
    lines.append("")
    if manifest.logic_fixed.status == "not_triggered":
        lines.append("- 未触发数学逻辑修复。")
    else:
        lines.append(f"- 状态: {manifest.logic_fixed.status}")
        lines.append(f"- issue_count: {manifest.logic_fixed.issue_count}")
        if manifest.logic_fixed.repair_method:
            lines.append(f"- repair_method: `{manifest.logic_fixed.repair_method}`")
        if manifest.logic_fixed.repair_source:
            lines.append(f"- repair_source: `{manifest.logic_fixed.repair_source}`")
        if manifest.logic_fixed.repair_event_path:
            lines.append(
                f"- repair_event: `{manifest.logic_fixed.repair_event_path}`"
            )
        if manifest.logic_fixed.top_issue_code:
            lines.append(f"- top_issue_code: `{manifest.logic_fixed.top_issue_code}`")
        if manifest.logic_fixed.error:
            lines.append(f"- error: `{manifest.logic_fixed.error}`")
    lines.append("")

    lines.append("## 布局修复证据")
    lines.append("")
    if manifest.layout_fixed.status == "not_triggered":
        lines.append("- 未触发布局修复。")
    else:
        lines.append(f"- 状态: {layout.status}")
        if layout.repair_method:
            lines.append(f"- repair_method: `{layout.repair_method}`")
        if layout.repair_source:
            lines.append(f"- repair_source: `{layout.repair_source}`")
        if layout.actions_path:
            lines.append(f"- repair_actions: `{layout.actions_path}`")
        if layout.before_overlap_count is not None:
            lines.append(f"- before_overlap_count: {layout.before_overlap_count}")
        if layout.after_overlap_count is not None:
            lines.append(f"- after_overlap_count: {layout.after_overlap_count}")
        if layout.before_max_overlap_ratio is not None:
            lines.append(f"- before_max_overlap_ratio: {layout.before_max_overlap_ratio}")
        if layout.after_max_overlap_ratio is not None:
            lines.append(f"- after_max_overlap_ratio: {layout.after_max_overlap_ratio}")
        if layout.layout_repair_outcome:
            lines.append(f"- quantified_outcome: `{layout.layout_repair_outcome}`")
        if layout.overlap_count_delta is not None:
            lines.append(f"- overlap_count_delta: {layout.overlap_count_delta}")
        if layout.max_overlap_ratio_delta is not None:
            lines.append(
                f"- max_overlap_ratio_delta: {layout.max_overlap_ratio_delta}"
            )
        if layout.before_decision_path:
            lines.append(f"- before_decision: `{layout.before_decision_path}`")
        if layout.after_decision_path:
            lines.append(f"- after_decision: `{layout.after_decision_path}`")
        if layout.bbox_before_path:
            lines.append(f"- bbox_before: `{layout.bbox_before_path}`")
        if layout.bbox_after_path:
            lines.append(f"- bbox_after: `{layout.bbox_after_path}`")
        if layout.error:
            lines.append(f"- error: `{layout.error}`")
    lines.append("")

    if manifest.notes:
        lines.append("## 备注")
        lines.append("")
        for note in manifest.notes:
            lines.append(f"- {note}")
        lines.append("")

    return "\n".join(lines)


def _stage_video_lines(label: str, stage: StageInfo) -> list[str]:
    if stage.video_path:
        return [f"- {label}: `{stage.video_path}`"]
    return [f"- {label}: （无视频，状态 {stage.status}）"]


def write_report(manifest: QualityCaseManifest, path: str | Path) -> bool:
    text = render_report_markdown(manifest)
    return safe_write_text(path, text)
