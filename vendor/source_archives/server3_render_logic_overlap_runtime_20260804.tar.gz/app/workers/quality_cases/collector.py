"""Compatibility facade for quality case collector."""
from .collector_core import *
from .collector_layout import *
from .collector_output import *
from .collector_helpers import *

class QualityCaseCollector(CollectorCoreMixin, CollectorLayoutMixin, CollectorOutputMixin):
    pass
