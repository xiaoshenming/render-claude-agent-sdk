"""quality_cases.collector — 三态证据采集器。

只负责"收集"，不参与修复决策。所有 IO 都 fail-soft：
任何写入失败都只 warning，绝不抛异常影响主业务。
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from . import storage
from .diff import write_unified_diff
from .report import write_report
from .safety import redact_secrets
from .schemas import QualityCaseManifest, StageInfo


logger = logging.getLogger("render")

_CST = timezone(timedelta(hours=8))


def _now_iso() -> str:
    return datetime.now(_CST).replace(microsecond=0).isoformat()


def _new_case_id() -> str:
    # 时间序前缀 + 短随机，便于按时间排序
    ts = time.strftime("%Y%m%dT%H%M%S")
    return f"{ts}_{uuid.uuid4().hex[:8]}"


class QualityCaseCollector:
    """单 Scene 三态证据采集器。

    使用方式::

        collector = QualityCaseCollector.create_if_enabled(
            ctx=ctx, scene_name="Scene_01_Foo", pipeline="streaming",
        )
        if collector:
            collector.capture_baseline(script_path=..., video_path=...)
            collector.capture_logic_fixed(script_path=..., video_path=..., issues=[...])
            collector.capture_layout_before(script_path=..., decision={...})
            collector.capture_layout_fixed(script_path=..., video_path=..., ...)
            artifact = collector.finalize()
    """


class CollectorLayoutMixin:
    def capture_layout_before(
        self,
        *,
        script_path: str | None,
        decision: dict | None = None,
    ) -> None:
        """在布局修复前快照当前代码 + 落 layout decision。

        这一步只是为后续 capture_layout_fixed 准备 before 基准；不会写入 stage status。
        """
        if not script_path and decision is None:
            return
        try:
            if storage.capture_code() and script_path:
                before_path = self._case_dir / "_layout_before.py"
                if self._save_code(script_path, before_path):
                    self._layout_before_code_path = before_path
            if decision is not None and storage.capture_bbox():
                storage.safe_write_json(
                    self._case_dir / "layout_decision_before.json",
                    decision,
                )
                self._manifest.layout_fixed.before_decision_path = (
                    "layout_decision_before.json"
                )
                self._manifest.layout_fixed.bbox_before_path = (
                    _write_layout_bbox_snapshot(
                        self._case_dir,
                        "layout_bbox_before.json",
                        decision,
                    )
                    or self._manifest.layout_fixed.bbox_before_path
                )
                summary = _summarize_layout_decision(decision)
                _apply_layout_issue_summary(
                    self._manifest.layout_fixed,
                    summary,
                )
                self._manifest.layout_fixed.before_overlap_count = summary.get(
                    "overlap_count"
                )
                self._manifest.layout_fixed.before_max_overlap_ratio = summary.get(
                    "max_overlap_ratio"
                )
        except Exception as exc:
            logger.warning("[QUALITY_CASE] capture_layout_before failed: %s", exc)

    def capture_layout_fixed(
        self,
        *,
        script_path: str | None,
        video_path: str | None,
        before_decision: dict | None = None,
        after_decision: dict | None = None,
        actions: list[dict] | None = None,
        repair_method: str | None = None,
        repair_source: str | None = None,
        layout_mvp_metadata: dict | None = None,
        status: str = "repaired",
        error: str | None = None,
    ) -> None:
        """采集布局修复后的代码 / 视频 / diff / decision / actions。"""
        try:
            stage = self._manifest.layout_fixed
            # 保留可能已经在 capture_layout_before 设置的 before_* 字段
            stage.status = status  # type: ignore[assignment]
            stage.error = error
            stage.repair_method = repair_method or _repair_method_from_actions(actions)
            stage.repair_source = repair_source or _repair_source_from_method(
                stage.repair_method
            )
            gate_pass = _is_layout_mvp_gate_pass(
                layout_mvp_metadata,
                repair_method=stage.repair_method,
                repair_source=stage.repair_source,
            )
            if gate_pass:
                stage.repair_method = "layout_mvp_0llm_gate_pass"
                stage.repair_source = "gate"
                if after_decision is None and before_decision is not None:
                    after_decision = before_decision

            if storage.capture_code() and script_path:
                code_dst = self._case_dir / "layout_fixed.py"
                if self._save_code(script_path, code_dst):
                    stage.code_path = code_dst.name
                    before_src = (
                        self._layout_before_code_path
                        or self._logic_code_path
                        or self._baseline_code_path
                    )
                    if before_src and Path(before_src).exists() and before_src != code_dst:
                        diff_dst = self._case_dir / "layout_fix.diff"
                        if write_unified_diff(
                            before_path=before_src,
                            after_path=code_dst,
                            output_path=diff_dst,
                            fromfile="logic_fixed.py",
                            tofile="layout_fixed.py",
                        ) is not None:
                            stage.diff_path = diff_dst.name

            if storage.capture_video() and video_path and status in {
                "repaired",
                "repair_failed",
                "available",
            }:
                video_dst = self._case_dir / "layout_fixed.mp4"
                if storage.safe_copy_file(video_path, video_dst):
                    stage.video_path = video_dst.name
                    if status == "repair_failed":
                        stage.source = "fallback_original"

            if storage.capture_bbox():
                if before_decision is not None and not stage.before_decision_path:
                    if storage.safe_write_json(
                        self._case_dir / "layout_decision_before.json",
                        before_decision,
                    ):
                        stage.before_decision_path = "layout_decision_before.json"
                        stage.bbox_before_path = (
                            _write_layout_bbox_snapshot(
                                self._case_dir,
                                "layout_bbox_before.json",
                                before_decision,
                            )
                            or stage.bbox_before_path
                        )
                        summary = _summarize_layout_decision(before_decision)
                        _apply_layout_issue_summary(stage, summary)
                        stage.before_overlap_count = summary.get("overlap_count")
                        stage.before_max_overlap_ratio = summary.get("max_overlap_ratio")
                if after_decision is not None:
                    if storage.safe_write_json(
                        self._case_dir / "layout_decision_after.json",
                        after_decision,
                    ):
                        stage.after_decision_path = "layout_decision_after.json"
                        stage.bbox_after_path = (
                            _write_layout_bbox_snapshot(
                                self._case_dir,
                                "layout_bbox_after.json",
                                after_decision,
                            )
                            or stage.bbox_after_path
                        )
                        summary = _summarize_layout_decision(after_decision)
                        stage.after_overlap_count = summary.get("overlap_count")
                        stage.after_max_overlap_ratio = summary.get("max_overlap_ratio")
                _apply_layout_repair_outcome(stage)

            if actions:
                if storage.safe_write_json(
                    self._case_dir / "layout_repair_actions.json",
                    {"actions": actions},
                ):
                    stage.actions_path = "layout_repair_actions.json"
            if isinstance(layout_mvp_metadata, dict) and layout_mvp_metadata:
                self._manifest.layout_mvp = dict(layout_mvp_metadata)
            if gate_pass:
                stage.issue_count = 0
                stage.top_issue_code = None

            self._manifest.layout_fixed = stage
        except Exception as exc:
            logger.warning("[QUALITY_CASE] capture_layout_fixed failed: %s", exc)
            self._manifest.layout_fixed.status = "missing"
            self._manifest.layout_fixed.error = str(exc)


