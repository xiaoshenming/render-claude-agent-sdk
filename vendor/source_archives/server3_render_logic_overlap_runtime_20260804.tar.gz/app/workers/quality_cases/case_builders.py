"""Quality-case collector construction, evidence capture, and local finalization."""

from __future__ import annotations

import logging
from typing import Any, Iterable

from .collector import QualityCaseCollector

logger = logging.getLogger("render")

TASK_DATA_KEY = "_quality_case_collectors"


def init_collectors_for_scenes(
    ctx,
    *,
    scene_names: Iterable[str],
    pipeline: str,
) -> dict[str, QualityCaseCollector]:
    """Create fail-soft collectors for the requested scenes."""
    task_data = getattr(ctx, "task_data", None)
    if not isinstance(task_data, dict):
        return {}
    # Resolve through the facade so existing monkeypatches remain effective.
    from . import pipeline_hook

    if not pipeline_hook.is_quality_cases_enabled():
        return {}
    existing = task_data.setdefault(TASK_DATA_KEY, {})
    for name in scene_names:
        if name in existing:
            continue
        try:
            collector = QualityCaseCollector.create_if_enabled(
                ctx=ctx,
                scene_name=name,
                pipeline=pipeline,
            )
        except Exception as exc:
            logger.warning("[QUALITY_CASE] init collector for %s failed: %s", name, exc)
            collector = None
        if collector is not None:
            existing[name] = collector
    return existing


def get_collector(
    task_data: dict | None, scene_name: str
) -> QualityCaseCollector | None:
    if not isinstance(task_data, dict):
        return None
    bag = task_data.get(TASK_DATA_KEY)
    if not isinstance(bag, dict):
        return None
    return bag.get(scene_name)


def all_collectors(task_data: dict | None) -> dict[str, QualityCaseCollector]:
    if not isinstance(task_data, dict):
        return {}
    bag = task_data.get(TASK_DATA_KEY)
    return bag if isinstance(bag, dict) else {}


def capture_baseline_for_paths(
    task_data: dict | None,
    *,
    script_path: str,
    mp4_paths: list[tuple[str, str]],
    source: str = "initial_render",
) -> None:
    """Capture baseline evidence for every scene that has an MP4."""
    for scene_name, video_path in mp4_paths:
        collector = get_collector(task_data, scene_name)
        if collector is None:
            continue
        try:
            collector.capture_baseline(
                script_path=script_path,
                video_path=video_path,
                source=source,
            )
        except Exception as exc:
            logger.warning(
                "[QUALITY_CASE] capture_baseline %s failed: %s", scene_name, exc
            )


def capture_logic_fixed(
    task_data: dict | None,
    *,
    scene_name: str,
    script_path: str | None,
    video_path: str | None,
    issues: list[dict] | None = None,
    repair_event: dict | None = None,
    status: str = "repaired",
    error: str | None = None,
) -> None:
    collector = get_collector(task_data, scene_name)
    if collector is None:
        return
    try:
        collector.capture_logic_fixed(
            script_path=script_path,
            video_path=video_path,
            issues=issues,
            repair_event=repair_event,
            status=status,
            error=error,
        )
    except Exception as exc:
        logger.warning(
            "[QUALITY_CASE] capture_logic_fixed %s failed: %s", scene_name, exc
        )


def mark_logic_not_triggered_for_scenes(
    task_data: dict | None,
    *,
    scene_names: Iterable[str],
) -> None:
    review_scenes = (
        task_data.get("_math_logic_review_scenes")
        if isinstance(task_data, dict)
        else {}
    )
    if not isinstance(review_scenes, dict):
        review_scenes = {}
    for name in scene_names:
        collector = get_collector(task_data, name)
        if collector is None:
            continue
        try:
            review = review_scenes.get(name)
            reason = None
            if isinstance(review, dict):
                decision = review.get("decision")
                risk = (
                    decision.get("risk_assessment")
                    if isinstance(decision, dict)
                    else {}
                )
                if isinstance(risk, dict):
                    reason = (
                        risk.get("skip_reason")
                        or ",".join(risk.get("signals") or [])
                        or review.get("status")
                    )
            collector.mark_logic_not_triggered(reason=reason)
        except Exception:
            pass


def finalize_all_inner(
    task_data: dict | None,
    *,
    collected_for_persist: list | None,
) -> list[dict[str, Any]]:
    """Finalize local evidence without allowing reporting failures to escape."""
    artifacts: list[dict[str, Any]] = []
    if not isinstance(task_data, dict):
        return artifacts
    bag = task_data.pop(TASK_DATA_KEY, None)
    if not isinstance(bag, dict) or not bag:
        return artifacts
    collector_obj = task_data.get("_error_collector")
    summary: list[dict[str, Any]] = []
    for scene_name, collector in bag.items():
        try:
            artifact = collector.finalize()
        except Exception as exc:
            logger.warning("[QUALITY_CASE] finalize %s failed: %s", scene_name, exc)
            continue
        artifacts.append(artifact)
        summary.append(
            {
                "scene_name": scene_name,
                "case_id": artifact.get("case_id"),
                "case_status": artifact.get("case_status"),
                "manifest_path": artifact.get("manifest_path"),
                "report_path": artifact.get("report_path"),
            }
        )
        if collector_obj is not None:
            try:
                collector_obj.info(
                    "QUALITY_CASE_REPORT",
                    "POST_RENDER_FIX",
                    f"质量报告 {scene_name}: {artifact.get('case_status')}",
                    context={
                        "type": "quality_case_report",
                        "scene_name": scene_name,
                        "case_id": artifact.get("case_id"),
                        "case_status": artifact.get("case_status"),
                        "manifest_path": artifact.get("manifest_path"),
                        "report_path": artifact.get("report_path"),
                        "case_dir": artifact.get("case_dir"),
                    },
                )
            except Exception:
                pass
        if collected_for_persist is not None:
            try:
                collected_for_persist.append(
                    (scene_name, collector.case_dir, collector.manifest)
                )
            except Exception:
                pass
    if summary:
        task_data["_quality_case_reports"] = summary
    return artifacts
