"""quality_cases.compose — 单切片 6 合一三态对比视频合成。

布局固定为 1920x1080：
- 上排：A baseline / B logic fixed / C layout fixed 三个视频。
- 下排：INFO / B 逻辑代码 diff / C 布局代码 diff 三个代码面板。

失败一律返回 None，不影响主渲染流程。
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import textwrap
import uuid
from pathlib import Path
from typing import Any, Optional

from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

COMPARISON_FILE_NAME = "comparison_6in1.mp4"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"



def _resolve_case_path(case_dir: Path, value: Optional[str | Path]) -> Optional[Path]:
    if not value:
        return None
    path = Path(value)
    if path.is_absolute():
        return path
    return case_dir / path
def _resolve_stage_videos(
    case_dir: Path,
    manifest: QualityCaseManifest,
) -> tuple[Optional[Path], Optional[Path], Optional[Path], dict]:
    """决定 A/B/C 三列实际播放哪个视频 + label。

    返回 (a_path, b_path, c_path, labels_dict)。
    缺失的列由调用方决定是否复用 A 占位（label 已经标明状态）。
    """
    a_path = _resolve_case_path(case_dir, manifest.baseline.video_path)
    a_label = "A 基线"

    # 兼容两条管线:
    #   streaming 管线: 只会写 repaired / not_triggered / repair_failed
    #   agent 管线 (visual_review_node): 额外会写 available (judge 跑过, 无需修复)
    if manifest.logic_fixed.status == "repaired" and manifest.logic_fixed.video_path:
        b_path = _resolve_case_path(case_dir, manifest.logic_fixed.video_path)
        b_label = "B 逻辑修复后"
    elif manifest.logic_fixed.status == "available":
        # agent 路径: judge 实际跑过且通过, 没有产出 video_path, B 视频列复用基线
        b_path = a_path
        b_label = "B 逻辑校验通过(同A)"
    elif manifest.logic_fixed.status == "not_triggered":
        b_path = a_path
        b_label = "B 未触发(同A)"
    elif manifest.logic_fixed.status == "repair_failed":
        b_path = _resolve_case_path(case_dir, manifest.logic_fixed.video_path)
        b_label = "B 逻辑修复未通过(保留原片)" if b_path else "B 逻辑修复未通过"
    else:
        b_path = None
        b_label = "B 缺失"

    if manifest.layout_fixed.status == "repaired" and manifest.layout_fixed.video_path:
        c_path = _resolve_case_path(case_dir, manifest.layout_fixed.video_path)
        c_label = "C 布局修复后"
    elif manifest.layout_fixed.status == "available":
        # agent 路径: layout inspect 跑过且无重叠, 复用 B(若有)否则 A
        c_path = b_path or a_path
        c_label = "C 布局校验通过(同B)" if b_path else "C 布局校验通过(同A)"
    elif manifest.layout_fixed.status == "not_triggered":
        c_path = b_path or a_path
        c_label = "C 未触发(同B)" if b_path else "C 未触发(同A)"
    elif manifest.layout_fixed.status == "repair_failed":
        c_path = _resolve_case_path(case_dir, manifest.layout_fixed.video_path)
        c_label = "C 布局修复未通过(保留上阶段)" if c_path else "C 布局修复未通过"
    else:
        c_path = b_path or a_path
        c_label = "C"

    return a_path, b_path, c_path, {
        "a_label": a_label,
        "b_label": b_label,
        "c_label": c_label,
    }
def _escape_drawtext(text: str) -> str:
    """ffmpeg drawtext 转义：英文冒号、单引号、反斜杠、百分号等。"""
    return (
        text.replace("\\", "\\\\")
        .replace(":", "\\:")
        .replace("'", "\\'")
        .replace("%", "\\%")
        .replace(",", "\\,")
        .replace(";", "\\;")
        .replace("[", "\\[")
        .replace("]", "\\]")
    )
def _filter_path(path: Path) -> str:
    return _escape_drawtext(str(path))
def _font_option() -> str:
    configured = os.getenv("QUALITY_CASE_DRAW_FONT")
    if configured and Path(configured).exists():
        return f":fontfile='{_filter_path(Path(configured))}'"
    for path in (
        "/usr/local/share/fonts/wqy-zenhei.ttc",
        "/usr/share/fonts/wenquanyi/wqy-zenhei/wqy-zenhei.ttc",
        "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationMono-Regular.ttf",
    ):
        if Path(path).exists():
            return f":fontfile='{_filter_path(Path(path))}'"
    return ""
def _read_text_artifact(path: Path | None, *, max_chars: int = 18000) -> str | None:
    if not path or not path.exists() or path.stat().st_size == 0:
        return None
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None
    return text[:max_chars]
def _safe_color(value: Any, fallback_key: str = "text") -> str:
    """保证传入 ffmpeg 的 color/fontcolor 永远是合法值，避免 None/逗号污染。"""
    fallback = PANEL_COLORS.get(fallback_key, PANEL_COLORS["text"])
    if value is None:
        return fallback
    if not isinstance(value, str):
        return fallback
    candidate = value.strip().rstrip(",;:")
    if not candidate or candidate.lower() == "none":
        return fallback
    if candidate in PANEL_COLORS:
        return PANEL_COLORS[candidate]
    if _VALID_COLOR_RE.match(candidate):
        return candidate
    return fallback
def _line(text: str, color: str = "text") -> PanelLine:
    if color in PANEL_COLORS:
        resolved = PANEL_COLORS[color]
    else:
        resolved = _safe_color(color)
    return {"text": text, "color": resolved}
def _stage_dict(stage: Any) -> dict[str, Any]:
    if hasattr(stage, "to_dict"):
        return stage.to_dict()
    if isinstance(stage, dict):
        return dict(stage)
    return {}
def _stage_value(stage: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = stage.get(key)
        if value not in (None, ""):
            return value
    return None
def _wrap_colored_lines(
    lines: list[PanelLine],
    *,
    max_cols: int = 78,
    max_lines: int = 220,
) -> list[PanelLine]:
    wrapped: list[PanelLine] = []
    for item in lines:
        text = str(item.get("text", "")).expandtabs(4)
        color = item.get("color", PANEL_COLORS["text"])
        parts = textwrap.wrap(
            text,
            width=max_cols,
            replace_whitespace=False,
            drop_whitespace=False,
        ) or [""]
        for index, part in enumerate(parts):
            prefix = "  " if index > 0 and text else ""
            wrapped.append(_line(f"{prefix}{part}", color))
            if len(wrapped) >= max_lines:
                wrapped.append(_line("... truncated in video panel ...", "muted"))
                return wrapped
    return wrapped
def _diff_line_color(line: str) -> str:
    if line.startswith("@@"):
        return "hunk"
    if line.startswith("+++") or line.startswith("---"):
        return "meta"
    if line.startswith("+"):
        return "add"
    if line.startswith("-"):
        return "del"
    return "text"
def _compact_diff_lines(body: str | None, *, max_lines: int = 24) -> list[PanelLine]:
    if not body:
        return []
    compact: list[PanelLine] = []
    pending_hunk: PanelLine | None = None
    for raw in body.splitlines():
        if raw.startswith("@@"):
            pending_hunk = _line(raw, "hunk")
            continue
        if raw.startswith("+++") or raw.startswith("---"):
            continue
        if raw.startswith("+") or raw.startswith("-"):
            if pending_hunk is not None:
                compact.append(pending_hunk)
                pending_hunk = None
            compact.append(_line(raw, _diff_line_color(raw)))
            if len(compact) >= max_lines:
                compact.append(_line("... 仅显示本切片前几处变动 ...", "muted"))
                break
    return compact
def _diff_panel_lines(
    *,
    title: str,
    status: str | None,
    diff_path: Path | None,
    fallback_path: Path | None = None,
    note: str,
    compact: bool = False,
) -> list[PanelLine]:
    source_path = diff_path or fallback_path
    body = _read_text_artifact(source_path)
    lines: list[PanelLine] = [
        _line(title, "title"),
        _line(f"status: {status or '-'}", "muted"),
    ]
    if source_path:
        lines.append(_line(f"file: {source_path.name}", "muted"))
    lines.append(_line(note, "muted"))
    if compact:
        lines.append(_line("本切片只展示变动行", "muted"))
    lines.append(_line(""))

    if compact:
        changed_lines = _compact_diff_lines(body)
        if changed_lines:
            lines.extend(changed_lines)
        else:
            lines.append(_line("本切片无代码变动", "muted"))
    elif body:
        for raw in body.splitlines():
            lines.append(_line(raw, _diff_line_color(raw)))
    else:
        lines.append(_line("(no diff/code artifact)", "warn"))
    return _wrap_colored_lines(lines, max_lines=38 if compact else 220)
