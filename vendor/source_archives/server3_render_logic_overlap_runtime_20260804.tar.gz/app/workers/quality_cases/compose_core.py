"""quality_cases.compose — 单切片 6 合一三态对比视频合成。

布局固定为 1920x1080：
- 上排：A baseline / B logic fixed / C layout fixed 三个视频。
- 下排：INFO / B 逻辑代码 diff / C 布局代码 diff 三个代码面板。

失败一律返回 None，不影响主渲染流程。
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import shutil
import textwrap
import uuid
from pathlib import Path
from typing import Any, Optional

from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

COMPARISON_FILE_NAME = "comparison_6in1.mp4"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"



from .compose_helpers import *
from .compose_panels import *
async def _probe_duration(path: Path, *, timeout_sec: float = 10.0) -> float:
    proc = await asyncio.create_subprocess_exec(
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "default=nokey=1:noprint_wrappers=1",
        str(path),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return 1.0
    try:
        return max(1.0, float((stdout or b"").decode().strip()))
    except ValueError:
        return 1.0
async def _probe_video_size(path: Path, *, timeout_sec: float = 10.0) -> tuple[int, int] | None:
    proc = await asyncio.create_subprocess_exec(
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=width,height",
        "-of",
        "csv=p=0",
        str(path),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return None
    try:
        width, height = (stdout or b"").decode().strip().split(",", 1)
        return int(width), int(height)
    except Exception:
        return None
async def compose_three_state_video(
    case_dir: Path,
    manifest: QualityCaseManifest,
    *,
    timeout_sec: float = 120.0,
) -> Optional[Path]:
    """生成 comparison_6in1.mp4。失败返回 None，不抛。"""
    if not shutil.which("ffmpeg"):
        logger.warning("[QUALITY_CASE] ffmpeg 不可用，跳过 comparison 合成")
        return None
    if not shutil.which("ffprobe"):
        logger.warning("[QUALITY_CASE] ffprobe 不可用，跳过 6in1 comparison 合成")
        return None

    output = case_dir / COMPARISON_FILE_NAME
    if output.exists() and output.stat().st_size > 0:
        if await _probe_video_size(output) == (1920, 1080):
            return output
        try:
            output.unlink()
        except OSError:
            return None

    a, b, c, labels = _resolve_stage_videos(case_dir, manifest)
    if not a or not a.exists():
        logger.warning(
            "[QUALITY_CASE] baseline 视频缺失，跳过 6in1 comparison job=%s scene=%s",
            manifest.job_id, manifest.scene_name,
        )
        return None
    if b and not b.exists():
        logger.warning(
            "[QUALITY_CASE] logic_fixed 视频缺失，comparison 复用 baseline 占位 job=%s scene=%s path=%s",
            manifest.job_id, manifest.scene_name, b,
        )
        b = None
        labels["b_label"] = "B 逻辑视频缺失"
    if c and not c.exists():
        logger.warning(
            "[QUALITY_CASE] layout_fixed 视频缺失，comparison 复用上一阶段占位 job=%s scene=%s path=%s",
            manifest.job_id, manifest.scene_name, c,
        )
        c = None
        labels["c_label"] = "C 布局视频缺失"

    inputs = [a, b or a, c or b or a]
    durations = [await _probe_duration(path) for path in inputs]
    duration = max(durations)
    panels = _comparison_panel_lines(case_dir, manifest)

    font = _font_option()
    top_names = ["a", "b", "c"]
    top_labels = {
        "a": labels["a_label"],
        "b": labels["b_label"],
        "c": labels["c_label"],
    }
    top_bar_colors = {"a": "0x234E70", "b": "0x8C1D13", "c": "0x155E75"}
    top_filters: list[str] = []
    for index, name in enumerate(top_names):
        pad = max(0.0, duration - durations[index])
        label = _escape_drawtext(top_labels[name])
        top_filters.append(
            f"[{index}:v]"
            f"trim=duration={duration:.3f},setpts=PTS-STARTPTS,"
            f"tpad=stop_mode=clone:stop_duration={pad:.3f},fps=24,"
            "scale=620:420:force_original_aspect_ratio=decrease,"
            "pad=640:480:(ow-iw)/2:(oh-ih)/2+28:color=0xF5F4EE,"
            f"drawbox=x=0:y=0:w=iw:h=38:color={top_bar_colors[name]}@0.96:t=fill,"
            f"drawtext=text='{label}':x=14:y=9:fontsize=20:fontcolor=white{font}"
            f"[v{name}]"
        )

    panel_titles = {
        "a": "INFO",
        "b": "B Logic Diff",
        "c": "C Layout Diff",
    }
    panel_bar_colors = {"a": "0x2563EB", "b": "0x92400E", "c": "0x155E75"}
    panel_tmp_dir = case_dir / ".panel_cache"
    panel_tmp_files: list[Path] = []
    bottom_filters: list[str] = []
    for input_index, name in enumerate(top_names, start=3):
        bottom_filters.extend(
            _panel_drawtext_filters(
                input_label=f"{input_index}:v",
                output_label=f"t{name}",
                title=panel_titles[name],
                title_color=panel_bar_colors[name],
                lines=panels[name],
                duration=duration,
                font=font,
                allow_scroll=True,
                tmp_dir=panel_tmp_dir,
                tmp_files=panel_tmp_files,
            )
        )

    filter_complex = (
        ";".join(top_filters + bottom_filters)
        + ";[va][vb][vc]hstack=inputs=3[top];"
        + "[ta][tb][tc]hstack=inputs=3[bottom];"
        + "[top][bottom]vstack=inputs=2[v]"
    )
    cmd = ["ffmpeg", "-y", "-loglevel", "error"]
    for path in inputs:
        cmd.extend(["-i", str(path)])
    for _ in top_names:
        cmd.extend([
            "-f",
            "lavfi",
            "-i",
            f"color=c=0x101820:s=640x600:d={duration:.3f}:r=24",
        ])
    cmd.extend([
        "-filter_complex", filter_complex,
        "-map", "[v]",
        "-t", f"{duration:.3f}",
        "-r", "24",
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-crf", "26",
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        "-an",
        str(output),
    ])

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            logger.warning(
                "[QUALITY_CASE] ffmpeg 6in1 compose 超时 job=%s scene=%s",
                manifest.job_id, manifest.scene_name,
            )
            return None
        if proc.returncode != 0:
            logger.warning(
                "[QUALITY_CASE] ffmpeg 6in1 compose 失败 rc=%s err=%s",
                proc.returncode,
                (stderr or b"").decode(errors="replace")[:500],
            )
            return None
        if not output.exists() or output.stat().st_size == 0:
            logger.warning("[QUALITY_CASE] comparison_6in1.mp4 输出为空")
            return None
        logger.info(
            "[QUALITY_CASE] 6in1 comparison 合成成功 job=%s scene=%s -> %s",
            manifest.job_id, manifest.scene_name, output,
        )
        return output
    except Exception as exc:
        logger.warning("[QUALITY_CASE] ffmpeg 6in1 compose 异常: %s", exc)
        return None
    finally:
        for tf in panel_tmp_files:
            try:
                tf.unlink()
            except OSError:
                pass
        try:
            if panel_tmp_dir.exists() and not any(panel_tmp_dir.iterdir()):
                panel_tmp_dir.rmdir()
        except OSError:
            pass
