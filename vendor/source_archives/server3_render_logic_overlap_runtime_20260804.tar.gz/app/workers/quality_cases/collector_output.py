"""quality_cases.collector — 三态证据采集器。

只负责"收集"，不参与修复决策。所有 IO 都 fail-soft：
任何写入失败都只 warning，绝不抛异常影响主业务。
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from . import storage
from .diff import write_unified_diff
from .report import write_report
from .safety import redact_secrets
from .schemas import QualityCaseManifest, StageInfo


logger = logging.getLogger("render")

_CST = timezone(timedelta(hours=8))


def _now_iso() -> str:
    return datetime.now(_CST).replace(microsecond=0).isoformat()


def _new_case_id() -> str:
    # 时间序前缀 + 短随机，便于按时间排序
    ts = time.strftime("%Y%m%dT%H%M%S")
    return f"{ts}_{uuid.uuid4().hex[:8]}"


class QualityCaseCollector:
    """单 Scene 三态证据采集器。

    使用方式::

        collector = QualityCaseCollector.create_if_enabled(
            ctx=ctx, scene_name="Scene_01_Foo", pipeline="streaming",
        )
        if collector:
            collector.capture_baseline(script_path=..., video_path=...)
            collector.capture_logic_fixed(script_path=..., video_path=..., issues=[...])
            collector.capture_layout_before(script_path=..., decision={...})
            collector.capture_layout_fixed(script_path=..., video_path=..., ...)
            artifact = collector.finalize()
    """


class CollectorOutputMixin:
    def add_note(self, note: str) -> None:
        try:
            self._manifest.notes.append(note)
        except Exception:
            pass

    def finalize(self) -> dict[str, Any]:
        """写出 manifest.json + report.md，返回路径字典。失败只 warning。"""
        if self._finalized:
            return self._artifact_paths()
        self._finalized = True
        try:
            self._fill_stage_fallback_paths()
            # 计算 case_status
            stages_status = [
                self._manifest.baseline.status,
                self._manifest.logic_fixed.status,
                self._manifest.layout_fixed.status,
            ]
            if "missing" in stages_status:
                self._manifest.case_status = "partial"
            elif self._manifest.baseline.status != "available":
                self._manifest.case_status = "failed"
            else:
                self._manifest.case_status = "captured"

            manifest_path = self._case_dir / "manifest.json"
            report_path = self._case_dir / "report.md"

            if storage.safe_write_json(manifest_path, self._manifest.to_dict()):
                self._manifest.artifacts["manifest"] = manifest_path.name
            if write_report(self._manifest, report_path):
                self._manifest.artifacts["report_md"] = report_path.name

            # 再写一次 manifest，包含 artifacts 引用
            storage.safe_write_json(manifest_path, self._manifest.to_dict())
        except Exception as exc:
            logger.warning("[QUALITY_CASE] finalize failed: %s", exc)
        return self._artifact_paths()

    def _artifact_paths(self) -> dict[str, Any]:
        return {
            "case_id": self._manifest.case_id,
            "case_dir": str(self._case_dir),
            "manifest_path": str(self._case_dir / "manifest.json"),
            "report_path": str(self._case_dir / "report.md"),
            "case_status": self._manifest.case_status,
            "scene_name": self._manifest.scene_name,
            "job_id": self._manifest.job_id,
        }

    def _save_code(self, src_path: str | Path, dst_path: Path) -> bool:
        try:
            text = Path(src_path).read_text(encoding="utf-8")
        except Exception as exc:
            logger.warning(
                "[QUALITY_CASE] read code failed %s: %s", src_path, exc,
            )
            return False
        text = redact_secrets(text)
        return storage.safe_write_text(dst_path, text)

    def _fill_stage_fallback_paths(self) -> None:
        """让 available/not_triggered 阶段也有可上传的 B/C artifact 路径。"""
        logic = self._manifest.logic_fixed
        baseline = self._manifest.baseline
        if logic.status in {"available", "not_triggered"}:
            if not logic.code_path:
                logic.code_path = baseline.code_path
            if not logic.video_path:
                logic.video_path = baseline.video_path
            self._manifest.logic_fixed = logic

        layout = self._manifest.layout_fixed
        if layout.status in {"available", "not_triggered"}:
            if not layout.code_path:
                layout.code_path = logic.code_path or baseline.code_path
            if not layout.video_path:
                layout.video_path = logic.video_path or baseline.video_path
            self._manifest.layout_fixed = layout

    @property
    def manifest(self) -> QualityCaseManifest:
        return self._manifest

    @property
    def case_dir(self) -> Path:
        return self._case_dir

