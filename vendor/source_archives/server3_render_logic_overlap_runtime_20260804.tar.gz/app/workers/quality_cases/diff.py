"""quality_cases.diff — 稳定的代码 diff 生成。"""

from __future__ import annotations

import difflib
import logging
from pathlib import Path


logger = logging.getLogger("render")


def write_unified_diff(
    *,
    before_path: str | Path,
    after_path: str | Path,
    output_path: str | Path,
    fromfile: str = "before",
    tofile: str = "after",
) -> str | None:
    """生成 unified diff 并写入 output_path。

    成功返回写入的 diff 文本（可能为空字符串表示无差异）。
    失败返回 None，并记录 warning，不抛异常。
    """
    try:
        before_lines = _read_lines(before_path)
        after_lines = _read_lines(after_path)
    except Exception as exc:
        logger.warning(
            "[QUALITY_CASE] read diff inputs failed: %s -> %s: %s",
            before_path, after_path, exc,
        )
        return None
    diff_iter = difflib.unified_diff(
        before_lines,
        after_lines,
        fromfile=fromfile,
        tofile=tofile,
        lineterm="",
    )
    diff_text = "\n".join(diff_iter)
    try:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_path).write_text(diff_text, encoding="utf-8")
    except Exception as exc:
        logger.warning(
            "[QUALITY_CASE] write diff failed: %s: %s",
            output_path, exc,
        )
        return None
    return diff_text


def _read_lines(path: str | Path) -> list[str]:
    text = Path(path).read_text(encoding="utf-8")
    # splitlines 不带换行，配合 lineterm="" 输出更干净
    return text.splitlines()
