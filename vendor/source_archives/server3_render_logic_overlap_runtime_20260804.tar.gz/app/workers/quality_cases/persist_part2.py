"""quality_cases.persist — 把 case artifact 上传 COS + 入库 quality_case_reports。

约束：全 fail-soft，任何异常都只 warning，绝不影响主渲染流程。
COS Key 规则：quality-cases/job_{job_id}/{scene_name}/{case_id}/{filename}
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from sqlalchemy import text

from app.database.database import AsyncSessionLocal

from .safety import safe_scene_name
from .schemas import QualityCaseManifest


logger = logging.getLogger("render")

JOB_COMPARISON_CASE_ID = "__job_6in1__"
JOB_COMPARISON_SCENE_NAME = "完整切片6合一"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"
LAYOUT_MVP_ROUND_ARTIFACT_TYPES = {
    "before_code": "text/x-python; charset=utf-8",
    "after_code": "text/x-python; charset=utf-8",
    "diff": "text/plain; charset=utf-8",
    "before_probe": "application/json; charset=utf-8",
    "after_probe": "application/json; charset=utf-8",
    "before_video": "video/mp4",
    "after_video": "video/mp4",
}



async def _upload_path(
    local: Optional[str | Path],
    cos_key: str,
    content_type: str,
    *,
    collector: Any | None = None,
    job_id: str | None = None,
    case_id: str | None = None,
    artifact: str = "artifact",
) -> Optional[str]:
    if not local:
        return None
    path = Path(local)
    try:
        if not path.exists() or path.stat().st_size == 0:
            return None
        from app.services.storage_service import storage_service  # 延迟导入，避免循环依赖
        data = path.read_bytes()
        return await storage_service.upload_file(
            cos_key, data, content_type=content_type,
        )
    except Exception as exc:
        logger.warning("[QUALITY_CASE] upload %s failed: %s", path, exc)
        _record_upload_failure(
            collector,
            job_id=job_id,
            case_id=case_id,
            artifact=artifact,
            cos_key=cos_key,
            path=path,
            exc=exc,
        )
        return None
async def _upload_layout_mvp_round_artifacts(
    *,
    case_dir: Path,
    manifest: QualityCaseManifest,
    base_key: str,
    collector: Any | None,
) -> None:
    layout_mvp = manifest.layout_mvp if isinstance(manifest.layout_mvp, dict) else {}
    rounds = layout_mvp.get("rounds")
    if not isinstance(rounds, list):
        return

    for round_index, round_item in enumerate(rounds, start=1):
        if not isinstance(round_item, dict):
            continue
        round_no = round_item.get("round") or round_index
        for artifact, content_type in LAYOUT_MVP_ROUND_ARTIFACT_TYPES.items():
            value = round_item.get(artifact)
            if not value or _is_remote_artifact(value):
                continue
            if not isinstance(value, (str, Path)):
                continue
            if artifact == "diff" and _looks_like_inline_diff(value):
                relative = Path("layout_mvp") / f"round_{round_no}" / "patch.diff"
                path = case_dir / relative
                try:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(str(value), encoding="utf-8")
                except Exception as exc:
                    logger.warning("[QUALITY_CASE] 写入 round diff artifact 失败 %s: %s", path, exc)
                    continue
            else:
                path = _resolve_case_path(case_dir, value)
                if path is None:
                    continue
                try:
                    relative = path.relative_to(case_dir)
                except ValueError:
                    relative = Path("layout_mvp") / f"round_{round_no}" / path.name
            uploaded = await _upload_path(
                path,
                f"{base_key}/{relative.as_posix()}",
                content_type,
                collector=collector,
                job_id=manifest.job_id,
                case_id=manifest.case_id,
                artifact=f"layout_mvp_{artifact}",
            )
            if uploaded:
                round_item[artifact] = uploaded

from . import persist_part3 as _part3
from . import persist_part4 as _part4
globals().update({k:v for _module in (_part3,_part4,) for k,v in vars(_module).items() if not k.startswith("__")})

