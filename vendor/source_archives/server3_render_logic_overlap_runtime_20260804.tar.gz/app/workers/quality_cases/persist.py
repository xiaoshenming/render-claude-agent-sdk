"""Compatibility facade for quality-case persistence."""
from . import persist_part1 as _part1
from . import persist_part2 as _part2
from . import persist_part3 as _part3
from . import persist_part4 as _part4
for _module in (_part1,_part2,_part3,_part4):
    globals().update({k:v for k,v in vars(_module).items() if not k.startswith("__")})
