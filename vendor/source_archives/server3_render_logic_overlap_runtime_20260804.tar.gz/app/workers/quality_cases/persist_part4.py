"""quality_cases.persist — 把 case artifact 上传 COS + 入库 quality_case_reports。

约束：全 fail-soft，任何异常都只 warning，绝不影响主渲染流程。
COS Key 规则：quality-cases/job_{job_id}/{scene_name}/{case_id}/{filename}
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Optional
from sqlalchemy import text

from app.database.database import AsyncSessionLocal

from .safety import safe_scene_name
from .schemas import QualityCaseManifest

logger = logging.getLogger("render")

JOB_COMPARISON_CASE_ID = "__job_6in1__"
JOB_COMPARISON_SCENE_NAME = "完整切片6合一"
JOB_COMPARISON_FILE_NAME = "job_comparison_6in1.mp4"
LAYOUT_MVP_ROUND_ARTIFACT_TYPES = {
    "before_code": "text/x-python; charset=utf-8",
    "after_code": "text/x-python; charset=utf-8",
    "diff": "text/plain; charset=utf-8",
    "before_probe": "application/json; charset=utf-8",
    "after_probe": "application/json; charset=utf-8",
    "before_video": "video/mp4",
    "after_video": "video/mp4",
}

async def persist_quality_case(
    *,
    case_dir: Path,
    manifest: QualityCaseManifest,
    comparison_path: Optional[Path] = None,
    collector: Any | None = None,
) -> Optional[dict[str, Any]]:
    """上传单 scene artifact + 写库。返回写入字段；失败返回 None。"""
    job_id = manifest.job_id
    case_id = manifest.case_id
    scene_name = manifest.scene_name
    if not job_id or not case_id or not scene_name:
        logger.warning("[QUALITY_CASE] persist 缺少必要字段，跳过")
        return None

    safe_scene = safe_scene_name(scene_name)
    base_key = f"quality-cases/job_{job_id}/{safe_scene}/{case_id}"

    baseline_video = await _upload_path(
        _resolve_case_path(case_dir, manifest.baseline.video_path),
        f"{base_key}/baseline.mp4",
        "video/mp4",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="baseline_video",
    )
    logic_video = await _upload_path(
        _resolve_case_path(case_dir, manifest.logic_fixed.video_path),
        f"{base_key}/logic_fixed.mp4",
        "video/mp4",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="logic_video",
    )
    layout_video = await _upload_path(
        _resolve_case_path(case_dir, manifest.layout_fixed.video_path),
        f"{base_key}/layout_fixed.mp4",
        "video/mp4",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="layout_video",
    )
    baseline_code = await _upload_path(
        _resolve_case_path(case_dir, manifest.baseline.code_path),
        f"{base_key}/baseline.py",
        "text/x-python; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="baseline_code",
    )
    logic_code = await _upload_path(
        _resolve_case_path(case_dir, manifest.logic_fixed.code_path),
        f"{base_key}/logic_fixed.py",
        "text/x-python; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="logic_code",
    )
    layout_code = await _upload_path(
        _resolve_case_path(case_dir, manifest.layout_fixed.code_path),
        f"{base_key}/layout_fixed.py",
        "text/x-python; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="layout_code",
    )
    logic_diff = await _upload_path(
        _resolve_diff_artifact(case_dir, manifest.logic_fixed.diff_path, "logic_fix.diff"),
        f"{base_key}/logic_fix.diff",
        "text/plain; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="logic_diff",
    )
    layout_diff = await _upload_path(
        _resolve_diff_artifact(case_dir, manifest.layout_fixed.diff_path, "layout_fix.diff"),
        f"{base_key}/layout_fix.diff",
        "text/plain; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="layout_diff",
    )
    layout_evidence_urls: dict[str, Optional[str]] = {}
    for artifact, path, filename in _layout_evidence_artifacts(case_dir, manifest):
        layout_evidence_urls[f"{artifact}_url"] = await _upload_path(
            path,
            f"{base_key}/{filename}",
            "application/json; charset=utf-8",
            collector=collector,
            job_id=job_id,
            case_id=case_id,
            artifact=artifact,
        )
    await _upload_layout_mvp_round_artifacts(
        case_dir=case_dir,
        manifest=manifest,
        base_key=base_key,
        collector=collector,
    )
    try:
        (case_dir / "manifest.json").write_text(
            json.dumps(manifest.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception as exc:
        logger.warning("[QUALITY_CASE] 写入 manifest.json 失败 job=%s case=%s: %s", job_id, case_id, exc)
    manifest_url = await _upload_path(
        case_dir / "manifest.json", f"{base_key}/manifest.json",
        "application/json; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="manifest",
    )
    report_url = await _upload_path(
        case_dir / "report.md", f"{base_key}/report.md",
        "text/markdown; charset=utf-8",
        collector=collector,
        job_id=job_id,
        case_id=case_id,
        artifact="report",
    )

    comparison_url = None
    comparison_local = _resolve_case_path(case_dir, comparison_path)
    if comparison_local and comparison_local.exists():
        comparison_url = await _upload_path(
            comparison_local, f"{base_key}/{comparison_local.name}", "video/mp4",
            collector=collector,
            job_id=job_id,
            case_id=case_id,
            artifact="comparison",
        )

    fields: dict[str, Any] = {
        "id": _ulid_like(),
        "job_id": job_id,
        "scene_name": scene_name[:128],
        "case_id": case_id[:64],
        "pipeline": (manifest.pipeline or None),
        "aspect_ratio": (manifest.aspect_ratio or None),
        "case_status": manifest.case_status,
        "baseline_status": manifest.baseline.status,
        "logic_status": manifest.logic_fixed.status,
        "layout_status": manifest.layout_fixed.status,
        "top_issue_code": (
            manifest.logic_fixed.top_issue_code
            or manifest.layout_fixed.top_issue_code
            or manifest.baseline.top_issue_code
        ),
        "issue_count": int(
            (manifest.logic_fixed.issue_count or 0)
            + (manifest.layout_fixed.issue_count or 0)
            + (manifest.baseline.issue_count or 0)
        ),
        "logic_repair_method": manifest.logic_fixed.repair_method,
        "logic_repair_source": manifest.logic_fixed.repair_source,
        "layout_repair_method": manifest.layout_fixed.repair_method,
        "layout_repair_source": manifest.layout_fixed.repair_source,
        **_layout_metric_fields(manifest),
        "baseline_video_url": baseline_video,
        "logic_video_url": logic_video,
        "layout_video_url": layout_video,
        "comparison_video_url": comparison_url,
        "baseline_code_url": baseline_code,
        "logic_code_url": logic_code,
        "layout_code_url": layout_code,
        "logic_diff_url": logic_diff,
        "layout_diff_url": layout_diff,
        "layout_decision_before_url": layout_evidence_urls.get(
            "layout_decision_before_url"
        ),
        "layout_decision_after_url": layout_evidence_urls.get(
            "layout_decision_after_url"
        ),
        "layout_bbox_before_url": layout_evidence_urls.get("layout_bbox_before_url"),
        "layout_bbox_after_url": layout_evidence_urls.get("layout_bbox_after_url"),
        "manifest_url": manifest_url,
        "report_url": report_url,
        "local_case_dir": str(case_dir)[:512],
    }

    result = await _insert_quality_case_fields(fields)
    if result:
        logger.info(
            "[QUALITY_CASE] [%s] ✓ 入库 job=%s scene=%s case=%s status=%s comparison=%s",
            _ts(), job_id, scene_name, case_id, manifest.case_status,
            "y" if comparison_url else "n",
        )
    return result
async def persist_quality_job_comparison(
    *,
    job_id: str,
    comparison_path: Optional[Path],
    collector: Any | None = None,
) -> Optional[dict[str, Any]]:
    """上传并写入完整 job 级 6 合一串联视频。"""
    if not job_id or not comparison_path or not comparison_path.exists():
        return None
    comparison_url = await _upload_path(
        comparison_path,
        f"quality-cases/job_{job_id}/{JOB_COMPARISON_CASE_ID}/{JOB_COMPARISON_FILE_NAME}",
        "video/mp4",
        collector=collector,
        job_id=job_id,
        case_id=JOB_COMPARISON_CASE_ID,
        artifact="job_comparison",
    )
    if not comparison_url:
        return None

    fields: dict[str, Any] = {
        "id": _ulid_like(),
        "job_id": job_id,
        "scene_name": JOB_COMPARISON_SCENE_NAME,
        "case_id": JOB_COMPARISON_CASE_ID,
        "pipeline": "summary",
        "aspect_ratio": None,
        "case_status": "available",
        "baseline_status": "available",
        "logic_status": "available",
        "layout_status": "available",
        "top_issue_code": None,
        "issue_count": 0,
        "logic_repair_method": None,
        "logic_repair_source": None,
        "layout_repair_method": None,
        "layout_repair_source": None,
        "before_overlap_count": None,
        "after_overlap_count": None,
        "before_max_overlap_ratio": None,
        "after_max_overlap_ratio": None,
        "baseline_video_url": None,
        "logic_video_url": None,
        "layout_video_url": None,
        "comparison_video_url": comparison_url,
        "baseline_code_url": None,
        "logic_code_url": None,
        "layout_code_url": None,
        "logic_diff_url": None,
        "layout_diff_url": None,
        "layout_decision_before_url": None,
        "layout_decision_after_url": None,
        "layout_bbox_before_url": None,
        "layout_bbox_after_url": None,
        "manifest_url": None,
        "report_url": None,
        "local_case_dir": str(comparison_path.parent)[:512],
    }

    result = await _insert_quality_case_fields(fields)
    if result:
        logger.info(
            "[QUALITY_CASE] [%s] ✓ job 级 6in1 入库 job=%s comparison=y",
            _ts(), job_id,
        )
    return result
