"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
async def log_render_quality_event(
    event_type: str,
    task_data: Optional[Dict[str, Any]],
    *,
    payload: Optional[Dict[str, Any]] = None,
    evidence: Optional[Dict[str, Any]] = None,
    video_id: str | None = None,
    source: str = "render",
) -> None:
    """Best-effort insert of non-MQ render quality evidence."""
    task_data = task_data or {}
    job_id = task_data.get("job_id")
    retry_count = task_data.get("retry_count")
    if retry_count is None:
        retry_count = 0
    retry_count = _safe_int(retry_count)
    attempt_id = _mq_attempt_id(
        task_data,
        job_id=job_id,
        retry_count=retry_count,
    )

    try:
        from app.database.database import AsyncSessionLocal, DATABASE_URL, engine

        session = AsyncSessionLocal()
        try:
            await session.execute(text("""
                INSERT INTO quality_events (
                    id, event_type, source, job_id, video_id, user_id,
                    request_id, trace_id, attempt_id,
                    payload, evidence, created_at
                ) VALUES (
                    :id, :event_type, :source, :job_id, :video_id, :user_id,
                    :request_id, :trace_id, :attempt_id,
                    :payload, :evidence, CURRENT_TIMESTAMP
                )
            """), {
                "id": str(uuid.uuid4()).replace("-", "")[:26],
                "event_type": event_type,
                "source": source,
                "job_id": job_id,
                "video_id": video_id or task_data.get("video_id"),
                "user_id": task_data.get("user_id"),
                "request_id": task_data.get("request_id"),
                "trace_id": task_data.get("trace_id"),
                "attempt_id": attempt_id,
                "payload": json.dumps(
                    _without_none(payload or {}),
                    ensure_ascii=False,
                    default=str,
                ),
                "evidence": json.dumps(
                    _without_none(evidence or {}),
                    ensure_ascii=False,
                    default=str,
                ),
            })
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
            if str(DATABASE_URL).startswith("sqlite"):
                await engine.dispose()
    except Exception as event_error:
        logger.warning(
            "[QUALITY_EVENT] [%s] 记录渲染质量事件失败: event=%s job_id=%s error=%s",
            _ts(), event_type, job_id, event_error,
        )
async def flush_error_collector(task_data: Optional[Dict[str, Any]]) -> None:
    collector = task_data.get("_error_collector") if task_data else None
    if collector is None:
        return
    try:
        await collector.flush()
    except Exception:
        pass
async def ack_with_queue_evidence(
    broker_message: Any,
    task_data: Optional[Dict[str, Any]],
    *,
    stage: str,
    detail: str,
    queue_type: str,
    job_id: str,
    retry_count: int,
    flush: bool = True,
) -> None:
    from app.workers.task_dispatcher import log_mq_quality_event
    await broker_message.ack()
    record_queue_event(
        task_data,
        "info",
        stage,
        detail,
        queue_type=queue_type,
        job_id=job_id,
        retry_count=retry_count,
    )
    event_task_data = dict(task_data or {})
    event_task_data.setdefault("job_id", job_id)
    event_task_data.setdefault("retry_count", retry_count)
    await log_mq_quality_event(
        "mq_message_acked",
        event_task_data,
        queue_type=queue_type,
        queue_name=_queue_name_for_type(queue_type),
        routing_key=_queue_name_for_type(queue_type),
        retry_count=retry_count,
        requeue=False,
        result=stage,
        detail=detail,
    )
    if flush:
        await flush_error_collector(task_data)
async def nack_with_queue_evidence(
    broker_message: Any,
    task_data: Optional[Dict[str, Any]],
    *,
    stage: str,
    detail: str,
    queue_type: str,
    job_id: str,
    retry_count: int,
    requeue: bool = True,
    flush: bool = True,
) -> None:
    from app.workers.task_dispatcher import log_mq_quality_event
    await broker_message.nack(requeue=requeue)
    record_queue_event(
        task_data,
        "warning",
        stage,
        detail,
        queue_type=queue_type,
        job_id=job_id,
        retry_count=retry_count,
        requeue=requeue,
    )
    event_task_data = dict(task_data or {})
    event_task_data.setdefault("job_id", job_id)
    event_task_data.setdefault("retry_count", retry_count)
    await log_mq_quality_event(
        "mq_message_nacked",
        event_task_data,
        queue_type=queue_type,
        queue_name=_queue_name_for_type(queue_type),
        routing_key=_queue_name_for_type(queue_type),
        retry_count=retry_count,
        requeue=requeue,
        result=stage,
        detail=detail,
    )
    if flush:
        await flush_error_collector(task_data)
