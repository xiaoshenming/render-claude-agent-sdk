"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
async def handle_task_failure(
    ctx: DispatchContext, message, task_data: Dict[str, Any],
    job_id: str, retry_count: int, queue_type: str,
    update_job_status_fn: Optional[Callable[..., Awaitable]] = None,
):
    """处理任务失败的重试/最终失败决策，保持旧 worker ABI。"""
    from app.workers.task_dispatcher import (
        handle_final_failure,
        publish_to_retry_queue,
        defer_retry_publish_failure,
        _final_failure_ackable,
    )
    error = task_data.get("last_error", "unknown")
    if task_data.get("_non_retryable") or retry_count >= ctx.max_retries:
        ok = await handle_final_failure(
            ctx, job_id, error, refund_points=task_data.get("refund_points", 0),
            error_type=task_data.get("_error_type", "max_retries"),
            error_stage=task_data.get("_error_stage", "unknown"),
            retry_count=retry_count, task_data=task_data,
            update_job_status_fn=update_job_status_fn,
        )
        if _final_failure_ackable(ok):
            await message.ack()
        else:
            await handle_final_failure_persist_failed(
                message, task_data, queue_type=queue_type, job_id=job_id,
                retry_count=retry_count, error_msg=error,
                error_type=task_data.get("_error_type"),
                error_stage=task_data.get("_error_stage"),
                nack_detail="Final failure persistence failed, message nacked",
            )
        return ok
    task_data["retry_count"] = retry_count + 1
    task_data["_retry_processing_takeover_allowed"] = True
    try:
        await publish_to_retry_queue(ctx, task_data)
    except Exception as pub_err:
        await defer_retry_publish_failure(
            ctx, message, task_data, queue_type=queue_type, job_id=job_id,
            retry_count=retry_count, pub_err=pub_err,
        )
        return False
    await message.ack()
    return True


async def handle_task_exception(
    ctx: DispatchContext, message, task_data: Optional[Dict[str, Any]],
    job_id: str, retry_count: int, queue_type: str, exc: Exception,
    update_job_status_fn: Optional[Callable[..., Awaitable]] = None,
):
    """处理任务执行中未捕获异常的重试/最终失败逻辑"""
    from app.workers.task_dispatcher import (
        handle_final_failure,
        publish_to_retry_queue,
        defer_retry_publish_failure,
    )
    try:
        if task_data:
            retry_count = task_data.get("retry_count", 0)
            job_id = task_data.get("job_id", "unknown")
        retry_count = _safe_int(retry_count)

        if await ack_terminal_redelivery_if_needed(
            message,
            task_data,
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
        ):
            return

        if task_data and task_data.get("_non_retryable"):
            final_error_msg = (
                task_data.get("last_error") or
                f"未捕获异常: {str(exc)[:500]}"
            )
            final_error_type = task_data.get("_error_type", "non_retryable")
            final_error_stage = task_data.get("_error_stage", "exception")
            ok = await handle_final_failure(
                ctx, job_id,
                final_error_msg,
                refund_points=task_data.get("refund_points", 0),
                error_type=final_error_type,
                error_stage=final_error_stage,
                retry_count=retry_count, task_data=task_data,
                update_job_status_fn=update_job_status_fn,
            )
            if _final_failure_ackable(ok):
                _clear_final_failure_persist_guard(
                    task_data,
                    job_id=job_id,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    error_msg=final_error_msg,
                )
                await ack_with_queue_evidence(
                    message,
                    task_data,
                    stage="QUEUE_ACK",
                    detail="Non-retryable exception persisted and acked",
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                )
            else:
                await handle_final_failure_persist_failed(
                    message,
                    task_data,
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                    error_msg=final_error_msg,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    nack_detail=(
                        "Non-retryable exception persist failed, message nacked"
                    ),
                )
            logger.error(
                f"[QUEUE] [{_ts()}] [{queue_type}] "
                f"异常任务已标记不可重试: job_id={job_id}")

        elif retry_count < ctx.max_retries and task_data:
            task_data["retry_count"] = retry_count + 1
            task_data["_retry_processing_takeover_allowed"] = True
            task_data["last_error"] = f"未捕获异常: {str(exc)[:500]}"
            try:
                await publish_to_retry_queue(ctx, task_data)
                await ack_with_queue_evidence(
                    message,
                    task_data,
                    stage="QUEUE_ACK_RETRY_PUBLISHED",
                    detail="Exception retry message published and original acked",
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                )
                logger.warning(
                    f"[QUEUE] [{_ts()}] [{queue_type}] "
                    f"异常任务已重新入队: job_id={job_id}")
            except Exception as pub_err:
                logger.exception(
                    f"[QUEUE] [{_ts()}] [{queue_type}] "
                    f"异常任务发布重试失败，保留原始异常并等待重投: "
                    f"job_id={job_id}")
                await defer_retry_publish_failure(
                    ctx,
                    message,
                    task_data,
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                    pub_err=pub_err,
                    detail_prefix="Retry publish failed during exception handling",
                )
        else:
            final_error_msg = f"未捕获异常: {str(exc)[:500]}"
            final_error_type = "uncaught_error"
            final_error_stage = "exception"
            ok = await handle_final_failure(
                ctx, job_id, final_error_msg,
                refund_points=(
                    task_data.get("refund_points", 0)
                    if task_data else 0),
                error_type=final_error_type,
                error_stage=final_error_stage,
                retry_count=retry_count, task_data=task_data,
                update_job_status_fn=update_job_status_fn,
            )
            if _final_failure_ackable(ok):
                _clear_final_failure_persist_guard(
                    task_data,
                    job_id=job_id,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    error_msg=final_error_msg,
                )
                await ack_with_queue_evidence(
                    message,
                    task_data,
                    stage="QUEUE_ACK",
                    detail="Uncaught exception final failure persisted and acked",
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                )
            else:
                await handle_final_failure_persist_failed(
                    message,
                    task_data,
                    queue_type=queue_type,
                    job_id=job_id,
                    retry_count=retry_count,
                    error_msg=final_error_msg,
                    error_type=final_error_type,
                    error_stage=final_error_stage,
                    nack_detail=(
                        "Uncaught exception final failure persist failed, message nacked"
                    ),
                )
            logger.error(
                f"[QUEUE] [{_ts()}] [{queue_type}] "
                f"异常任务达到最大重试次数: job_id={job_id}")
    except Exception:
        logger.exception(f"[QUEUE] [{_ts()}] 处理异常任务失败")
