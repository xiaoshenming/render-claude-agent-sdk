"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
async def ack_terminal_redelivery_if_needed(
    message: Any,
    task_data: Optional[Dict[str, Any]],
    *,
    queue_type: str,
    job_id: str,
    retry_count: int,
    get_job_status_fn: Optional[Callable[[str], Awaitable[Any]]] = None,
    flush: bool = False,
    redelivery_only: bool = True,
) -> bool:
    """Ack messages whose job is already terminal.

    This is an idempotency guard for late RabbitMQ deliveries.  It prevents a
    terminal job from spending another retry/final-failure path after the API
    has already accepted a success/failure write.
    """
    if not task_data or not job_id:
        return False
    if redelivery_only and not task_data.get("_rabbitmq_redelivered"):
        return False

    get_job_status = get_job_status_fn or getattr(
        job_repository,
        "get_job_status",
        None,
    )
    if get_job_status is None:
        return False

    try:
        current_status = await get_job_status(job_id)
    except Exception as exc:
        logger.warning(
            "[QUEUE] [%s] [%s] redelivery terminal precheck failed: "
            "job_id=%s error=%s",
            _ts(),
            queue_type,
            job_id,
            exc,
        )
        return False

    if not _is_terminal_job_status(current_status):
        return False

    normalized_status = _normalize_job_status(current_status) or "UNKNOWN"
    task_data["_terminal_delivery_guard_status"] = normalized_status
    task_data["_terminal_delivery_guard"] = True
    logger.warning(
        "[QUEUE] [%s] [%s] job already terminal=%s; "
        "ack without retry/final-failure path job_id=%s",
        _ts(),
        queue_type,
        normalized_status,
        job_id,
    )
    await ack_with_queue_evidence(
        message,
        task_data,
        stage="QUEUE_ACK_TERMINAL_REDELIVERY",
        detail="Terminal job delivery acked without retry or final-failure path",
        queue_type=queue_type,
        job_id=job_id,
        retry_count=retry_count,
        flush=flush,
    )
    return True
