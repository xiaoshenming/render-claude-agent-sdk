"""Message admission, backpressure, and terminal redelivery guards."""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from importlib import import_module
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _task_dispatcher():
    return import_module("app.workers.task_dispatcher")


def _job_repository():
    return import_module("app.services.job_repository")


class WorkerAdmissionMixin:
    async def _reject_poison_message(self, message, *, queue_type: str, reason: str, exc: Exception):
        queue_name = self.retry_queue_name if queue_type == "RETRY" else self.normal_queue_name
        message_bytes = len(getattr(message, "body", b"") or b"")
        logger.error(
            "[QUEUE] [%s] [%s] reject poison RabbitMQ message: reason=%s error=%s",
            _ts(), queue_type, reason, exc,
        )
        try:
            await message.nack(requeue=False)
        finally:
            await _task_dispatcher().log_mq_quality_event(
                "mq_poison_message_rejected",
                {},
                queue_type=queue_type,
                queue_name=queue_name,
                routing_key=queue_name,
                message_bytes=message_bytes,
                requeue=False,
                result="rejected",
                detail=reason,
                exception=exc,
            )

    async def _available_container_count(self) -> int:
        manager = getattr(self, "container_mgr", None)
        if manager is None:
            return 1
        counter = getattr(manager, "available_container_count", None)
        if callable(counter):
            value = counter()
            if asyncio.iscoroutine(value):
                value = await value
            try:
                return max(0, int(value))
            except (TypeError, ValueError):
                return 0
        return sum(
            1
            for container in getattr(self, "container_names", [])
            if not os.path.exists(manager._lock_path(container))
        )

    async def _defer_for_container_backpressure(
        self,
        message,
        task_data: Dict[str, Any],
        *,
        queue_type: str,
        queue_name: str,
        job_id: str,
        retry_count: int,
        message_bytes: int,
    ) -> bool:
        available = await self._available_container_count()
        if available > 0:
            return False
        delay = max(0.0, float(getattr(self, "_container_backpressure_delay", 1.0)))
        max_wait = max(
            0.0,
            float(getattr(self, "_container_backpressure_max_wait_seconds", 300.0)),
        )
        logger.warning(
            "[QUEUE] [%s] [%s] container backpressure: available=0, "
            "wait up to %.2fs before requeue job_id=%s",
            _ts(), queue_type, max_wait, job_id,
        )
        await _task_dispatcher().log_mq_quality_event(
            "mq_message_backpressured",
            task_data,
            queue_type=queue_type,
            queue_name=queue_name,
            routing_key=queue_name,
            retry_count=retry_count,
            message_bytes=message_bytes,
            redelivered=task_data.get("_rabbitmq_redelivered"),
            requeue=False,
            result="waiting",
            detail="No available render containers; message waits before task start",
        )
        if await self._wait_for_container_capacity(delay=delay, max_wait=max_wait):
            await _task_dispatcher().log_mq_quality_event(
                "mq_message_backpressure_released",
                task_data,
                queue_type=queue_type,
                queue_name=queue_name,
                routing_key=queue_name,
                retry_count=retry_count,
                message_bytes=message_bytes,
                redelivered=task_data.get("_rabbitmq_redelivered"),
                requeue=False,
                result="resumed",
                detail="Render container became available; message processing resumes",
            )
            return False
        await _task_dispatcher().nack_with_queue_evidence(
            message,
            task_data,
            stage="QUEUE_NACK_BACKPRESSURE",
            detail="No available render containers after backpressure wait; message requeued",
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
            requeue=True,
            flush=False,
        )
        return True

    async def _wait_for_container_capacity(
        self,
        *,
        delay: float,
        max_wait: float,
    ) -> bool:
        if max_wait <= 0:
            return False
        sleep_delay = delay if delay > 0 else 1.0
        max_attempts = max(1, int(max_wait / sleep_delay))
        for _ in range(max_attempts):
            if not getattr(self, "_consuming", True):
                return False
            await asyncio.sleep(sleep_delay)
            if await self._available_container_count() > 0:
                return True
        return False

    async def _ack_terminal_redelivery_if_needed(
        self,
        message,
        task_data: Dict[str, Any],
        *,
        queue_type: str,
        job_id: str,
        retry_count: int,
        redelivery_only: bool = True,
    ) -> bool:
        return await _task_dispatcher().ack_terminal_redelivery_if_needed(
            message,
            task_data,
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
            get_job_status_fn=_job_repository().get_job_status,
            flush=False,
            redelivery_only=redelivery_only,
        )

    async def _cleanup_hard_timeout_containers(self, job_id: str) -> None:
        manager = getattr(self, "container_mgr", None)
        if manager is None or not job_id:
            return
        containers: List[str] = []
        locked_for_job = getattr(manager, "locked_containers_for_job", None)
        if callable(locked_for_job):
            try:
                containers = list(locked_for_job(job_id) or [])
            except Exception:
                logger.exception(
                    "[CONTAINER] [%s] hard-timeout lock lookup failed: job_id=%s",
                    _ts(), job_id,
                )
        killer = getattr(manager, "kill_manim_processes", None)
        if containers and callable(killer):
            try:
                await killer(containers, job_id=job_id)
            except TypeError:
                await killer(containers)
            except Exception:
                logger.exception(
                    "[CONTAINER] [%s] hard-timeout process cleanup failed: job_id=%s",
                    _ts(), job_id,
                )
        cleanup = getattr(manager, "cleanup_task_locks", None)
        if callable(cleanup):
            try:
                cleanup(job_id)
            except Exception:
                logger.exception(
                    "[CONTAINER] [%s] hard-timeout lock cleanup failed: job_id=%s",
                    _ts(), job_id,
                )
