"""RabbitMQ message parsing, admission, and lifecycle orchestration."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Callable

from app.workers.worker_message_execution import (
    MessageDependencies,
    execute_task,
    finish_task,
)

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


async def _parse_message(
    worker,
    message,
    queue_type: str,
    normalize_task_data: Callable,
) -> dict | None:
    try:
        task_data = json.loads(message.body.decode())
        if not isinstance(task_data, dict):
            raise ValueError(f"message body must be an object, got {type(task_data).__name__}")
        nested_payload = task_data.get("payload")
        if not task_data.get("job_id") and isinstance(nested_payload, dict):
            task_data.update(nested_payload)
        if not task_data.get("job_id"):
            raise ValueError("message missing required job_id")
        return normalize_task_data(task_data)
    except Exception as exc:
        await worker._reject_poison_message(
            message,
            queue_type=queue_type,
            reason="invalid_message_payload",
            exc=exc,
        )
        return None


async def _record_received(
    task_data: dict,
    *,
    queue_type: str,
    queue_name: str,
    retry_count: int,
    message_bytes: int,
    deps: MessageDependencies,
) -> None:
    common = {
        "queue_type": queue_type,
        "queue_name": queue_name,
        "routing_key": queue_name,
        "retry_count": retry_count,
        "message_bytes": message_bytes,
        "redelivered": task_data.get("_rabbitmq_redelivered"),
    }
    await deps.task_dispatcher.log_mq_quality_event(
        "mq_message_received",
        task_data,
        **common,
        result="received",
        detail="RabbitMQ message received",
    )
    if task_data.get("_rabbitmq_redelivered"):
        await deps.task_dispatcher.log_mq_quality_event(
            "mq_redelivered_detected",
            task_data,
            **common,
            result="redelivered",
            detail="RabbitMQ redelivered message detected",
        )


async def _handle_exception(
    worker,
    message,
    task_data: dict | None,
    job_id: str,
    retry_count: int,
    queue_type: str,
    exc: Exception,
    deps: MessageDependencies,
) -> None:
    logger.exception("[QUEUE] [%s] handling failed: %s", queue_type, exc)
    worker._release_claimed_active_job_marker(task_data, job_id)
    if job_id and job_id != "unknown":
        try:
            current_status = await deps.job_repository.get_job_status(job_id)
        except Exception:
            current_status = None
        if current_status not in (None, "PENDING", "PROCESSING"):
            logger.warning(
                "[QUEUE] [%s] terminal job skips retry: job_id=%s status=%s",
                queue_type,
                job_id,
                current_status,
            )
            try:
                await message.ack()
            except Exception as ack_error:
                logger.warning(
                    "[QUEUE] [%s] terminal ack failed: job_id=%s error=%s",
                    queue_type,
                    job_id,
                    ack_error,
                )
            return
    await worker._handle_task_exception(
        message, task_data, job_id, retry_count, queue_type, exc
    )


async def handle_message(
    worker,
    message,
    is_retry_queue: bool,
    *,
    deps: MessageDependencies,
    normalize_task_data: Callable,
    merge_trace_context: Callable,
    message_redelivered: Callable,
    bind_log_context: Callable,
    reset_log_context: Callable,
) -> None:
    queue_type = "RETRY" if is_retry_queue else "NORMAL"
    task_data = None
    job_id = "unknown"
    retry_count = 0
    log_context_tokens = None
    async with worker._task_semaphore:
        logger.info("[QUEUE] [%s] [%s] >>> 收到新消息!", _ts(), queue_type)
        try:
            task_data = await _parse_message(worker, message, queue_type, normalize_task_data)
            if task_data is None:
                return
            merge_trace_context(task_data, message)
            task_data["_rabbitmq_redelivered"] = message_redelivered(message)
            job_id = task_data.get("job_id")
            retry_count = task_data.get("retry_count", 0)
            queue_name = worker.retry_queue_name if is_retry_queue else worker.normal_queue_name
            message_bytes = len(message.body or b"")
            await _record_received(
                task_data,
                queue_type=queue_type,
                queue_name=queue_name,
                retry_count=retry_count,
                message_bytes=message_bytes,
                deps=deps,
            )
            log_context_tokens = bind_log_context(task_data)
            logger.info(
                "[QUEUE] [%s] [%s] parsed job_id=%s retry=%s user_id=%s",
                _ts(), queue_type, job_id, retry_count, task_data.get("user_id"),
            )
            if await worker._ack_terminal_redelivery_if_needed(
                message,
                task_data,
                queue_type=queue_type,
                job_id=job_id,
                retry_count=retry_count,
                redelivery_only=False,
            ):
                return
            if await worker._ack_active_duplicate_delivery_if_needed(
                message,
                task_data,
                queue_type=queue_type,
                job_id=job_id,
                retry_count=retry_count,
            ):
                return
            if job_id and job_id != "unknown":
                if not hasattr(worker, "_inflight_task_ids"):
                    worker._inflight_task_ids = set()
                worker._inflight_task_ids.add(str(job_id))
            if await worker._defer_for_container_backpressure(
                message,
                task_data,
                queue_type=queue_type,
                queue_name=queue_name,
                job_id=job_id,
                retry_count=retry_count,
                message_bytes=message_bytes,
            ):
                return
            handled, result, duration = await execute_task(
                worker,
                message,
                task_data,
                queue_type=queue_type,
                queue_name=queue_name,
                job_id=job_id,
                retry_count=retry_count,
                message_bytes=message_bytes,
                deps=deps,
            )
            if handled:
                return
            await finish_task(
                worker,
                message,
                task_data,
                str(result),
                duration,
                queue_type=queue_type,
                queue_name=queue_name,
                job_id=job_id,
                retry_count=retry_count,
                message_bytes=message_bytes,
                deps=deps,
            )
        except Exception as exc:
            await _handle_exception(
                worker,
                message,
                task_data,
                job_id,
                retry_count,
                queue_type,
                exc,
                deps,
            )
        finally:
            if job_id and job_id != "unknown":
                try:
                    worker._inflight_task_ids.discard(str(job_id))
                except Exception:
                    pass
                worker._release_claimed_active_job_marker(task_data, job_id)
            worker.processed_jobs += 1
            logger.info("[QUEUE] [%s] processed total=%s", _ts(), worker.processed_jobs)
            reset_log_context(log_context_tokens)
