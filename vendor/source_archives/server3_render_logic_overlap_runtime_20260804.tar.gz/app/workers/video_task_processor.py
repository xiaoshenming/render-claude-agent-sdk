"""唯一视频主管线：输入、代码生成、Render Agent、归档。"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from datetime import datetime
from typing import Any

from app.agents.minimal_render_agent import render_source
from app.audio_quality import dispatch_audio_quality_observation
from app.quality_platform.minimal_bridge import run_minimal_quality_platform
from app.services.error_collector import ErrorCollector
from app.services.minimal_generation import GenerationArtifact, generate_source
from app.workers.minimal_archive import archive_success
from libs.contracts.video_task_message import (
    VideoTaskContractError,
    normalize_video_task_message,
)

logger = logging.getLogger(__name__)


def _normalize(task_data: dict[str, Any]) -> bool:
    try:
        normalized, legacy_missing = normalize_video_task_message(task_data)
    except VideoTaskContractError as exc:
        task_data.update(
            last_error=str(exc),
            _error_stage="message_contract",
            _error_type="invalid_message_contract",
            _non_retryable=True,
        )
        return False
    task_data.clear()
    task_data.update(normalized)
    if legacy_missing:
        task_data["_message_contract_legacy"] = True
    return True


def _generation_prompt(task_data: dict[str, Any]) -> str:
    prompt = str(task_data.get("prompt") or "").strip()
    if task_data.get("task_type") != "solve":
        return prompt
    problem = str(task_data.get("original_problem") or "").strip()
    static_code = str(task_data.get("manim_static_code") or "").strip()
    parts = [
        "请把下面题目和解题过程制作成完整的教学视频。",
        f"原题：\n{problem}" if problem else "",
        f"解题过程：\n{prompt}",
        f"可复用配图代码：\n{static_code}" if static_code else "",
    ]
    return "\n\n".join(part for part in parts if part)


def _apply_usage(task_data: dict[str, Any], generated: GenerationArtifact) -> None:
    usage = generated.usage
    mapping = {
        "_total_tokens": "total_tokens",
        "_input_tokens": "input_tokens",
        "_output_tokens": "output_tokens",
        "_cache_read_tokens": "cache_read_tokens",
        "_cache_creation_tokens": "cache_creation_tokens",
    }
    for target, source in mapping.items():
        task_data[target] = int(task_data.get(target, 0) or 0) + int(
            usage.get(source, 0) or 0
        )


async def _content_safe(code: str, task_data: dict[str, Any]) -> bool:
    """仅保留安全合规审核，不做质量拦截。"""
    from app.workers.validation import content_security

    visible = content_security.extract_visible_strings_from_code(code)
    if not visible.strip():
        return True
    safe, message = await asyncio.to_thread(
        content_security.check_content_security, visible
    )
    if safe:
        return True
    task_data.update(
        last_error=message or "AI 生成结果未通过内容安全检查",
        _error_stage="output_content_safety",
        _error_type="content_safety",
        _non_retryable=True,
    )
    return False


async def record_stage_timing_summary(
    task_data: dict[str, Any], *, status: str, finished_at: Any = None
) -> dict[str, float]:
    started = float(task_data.get("_task_start_wall_time", 0) or 0)
    ended = time.time()
    summary = {"total_sec": round(max(0.0, ended - started), 3)} if started else {}
    task_data["_stage_timing_summary"] = summary
    try:
        from app.workers.task_dispatcher import log_render_quality_event

        await log_render_quality_event(
            "render_stage_timing_summary",
            task_data,
            payload={
                "job_id": task_data.get("job_id"),
                "status": status,
                "stage_timing": summary,
                "source": "minimal_pipeline",
            },
            evidence={"finished_at": finished_at or datetime.now()},
        )
    except Exception:
        logger.debug("记录主管线耗时失败", exc_info=True)
    return summary


async def _enter_processing(worker: Any, task_data: dict[str, Any], job_id: str) -> bool:
    """Claim a new job, while allowing an explicit retry to resume PROCESSING."""
    if await worker._is_job_cancelled(job_id):
        return False
    retry_count = int(task_data.get("retry_count") or 0)
    if retry_count <= 0:
        return bool(await worker._update_job_status(job_id, "PROCESSING"))
    current = await worker._get_job_status(job_id)
    if current == "PROCESSING":
        logger.info(
            "显式重试继续已有 PROCESSING 任务: job=%s retry=%s",
            job_id,
            retry_count,
        )
        return True
    if current == "PENDING":
        return bool(await worker._update_job_status(job_id, "PROCESSING"))
    return False


async def process_video_task(worker: Any, task_data: dict[str, Any]) -> str:
    task_data["_task_start_wall_time"] = time.time()
    task_data.update(
        _error_stage=None,
        _error_type=None,
        _non_retryable=False,
        _llm_fix_count=0,
        _render_fix_count=0,
    )
    if not _normalize(task_data):
        return "failed"
    if task_data.get("task_type") == "modify":
        return await worker.process_modify_task(task_data)

    required = ("job_id", "user_id", "prompt", "ai_model")
    missing = [name for name in required if not task_data.get(name)]
    if missing:
        task_data.update(
            last_error=f"消息缺少必要字段: {missing}",
            _error_stage="message_contract",
            _error_type="invalid_message_contract",
            _non_retryable=True,
        )
        return "failed"

    job_id = str(task_data["job_id"])
    output_dir = os.path.join(worker.media_root, f"job_{job_id}")
    script_dir = os.path.join(worker.manim_media_root, f"job_{job_id}")
    task_data["_error_collector"] = ErrorCollector(
        job_id=job_id,
        request_id=task_data.get("request_id"),
        trace_id=task_data.get("trace_id"),
        attempt_id=task_data.get("attempt_id"),
    )
    try:
        if not await _enter_processing(worker, task_data, job_id):
            return "skipped"

        prompt = _generation_prompt(task_data)
        tts_voice = str(task_data.get("tts_voice") or "longxiaoxia_v3")
        generated = await generate_source(
            job_id=job_id,
            provider=str(task_data["ai_model"]),
            prompt=prompt,
            color_scheme=int(task_data.get("color_scheme", 1) or 1),
            enable_tts=bool(task_data.get("enable_tts", False)),
            tts_voice=tts_voice,
            voice_type=str(task_data.get("voice_type") or "system"),
            cosyvoice_id=str(task_data.get("cosyvoice_id") or ""),
            aspect_ratio=str(task_data.get("aspect_ratio") or "16:9"),
        )
        _apply_usage(task_data, generated)
        task_data["_generation_messages"] = generated.messages
        task_data["_generation_raw_response"] = generated.raw_response
        task_data["_code"] = generated.code

        rendered = await render_source(
            worker,
            job_id=job_id,
            task_data=task_data,
            code=generated.code,
            aspect_ratio=str(task_data.get("aspect_ratio") or "16:9"),
            enable_tts=bool(task_data.get("enable_tts", False)),
        )
        task_data.update(
            _code=rendered.code,
            _script_path=rendered.script_path,
            _final_video_path=rendered.final_video_path,
        )
        quality = await run_minimal_quality_platform(
            worker,
            task_data=task_data,
            code=rendered.code,
            video_bytes=rendered.video_bytes,
            video_path=rendered.final_video_path,
            prompt=prompt,
        )
        task_data.update(
            _code=quality.code,
            _final_video_path=quality.video_path,
        )
        if not await _content_safe(quality.code, task_data):
            return "failed"
        await dispatch_audio_quality_observation(
            task_data=task_data,
            code=quality.code,
            video_path=quality.video_path,
        )
        await archive_success(
            worker,
            task_data=task_data,
            code=quality.code,
            video_bytes=quality.video_bytes,
            scene_names=rendered.scene_names,
            slice_paths=(
                rendered.slice_paths
                if quality.video_path == rendered.final_video_path
                else [quality.video_path]
            ),
            original_prompt=str(task_data["prompt"]),
            cost=float(generated.usage.get("cost", 0.0) or 0.0),
        )
        worker._cleanup_job_folder(output_dir, script_dir)
        await record_stage_timing_summary(task_data, status="success")
        return "success"
    except Exception as exc:
        logger.exception("极简 Render 主管线失败: job_id=%s", job_id)
        task_data.setdefault("last_error", f"{type(exc).__name__}: {exc}")
        task_data["_error_stage"] = task_data.get("_error_stage") or "render_agent"
        task_data["_error_type"] = task_data.get("_error_type") or type(exc).__name__
        if int(task_data.get("retry_count", 0) or 0) >= int(
            getattr(worker, "max_retries", 0) or 0
        ):
            worker._cleanup_job_folder(output_dir, script_dir)
        await record_stage_timing_summary(task_data, status="failed")
        return "failed"
