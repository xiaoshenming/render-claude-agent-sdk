"""Atomic active-job marker storage and ownership."""

from __future__ import annotations

import json
import logging
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from app.workers.worker_task_policy import hard_timeout_for_task, pid_is_alive

ACTIVE_JOB_MARKER_GRACE_SECONDS = 300

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


class ActiveJobMarkerMixin:
    def _active_job_marker_path(self, job_id: str) -> Path:
        root = Path(self.locks_dir) / "active_jobs"
        root.mkdir(parents=True, exist_ok=True)
        safe_job = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(job_id or "unknown"))
        return root / f"{safe_job}.json"

    def _read_active_job_marker(self, job_id: str) -> Dict[str, Any] | None:
        path = self._active_job_marker_path(job_id)
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except Exception:
            try:
                stat = path.stat()
            except OSError:
                return None
            return {
                "token": "",
                "pid": None,
                "created_at": stat.st_mtime,
                "corrupt": True,
            }

    @staticmethod
    def _safe_marker_retry_count(value: Any) -> int:
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _active_marker_age_seconds(path: Path, marker: Dict[str, Any] | None) -> float:
        marker = marker or {}
        anchor = marker.get("updated_at") or marker.get("created_at")
        try:
            return max(0.0, time.time() - float(anchor))
        except (TypeError, ValueError):
            try:
                return max(0.0, time.time() - path.stat().st_mtime)
            except OSError:
                return 0.0

    def _claim_active_job_marker(
        self,
        job_id: str,
        *,
        retry_count: int,
        task_data: Dict[str, Any],
    ) -> tuple[bool, str, Dict[str, Any] | None]:
        """Claim a cross-process active marker for this job delivery.

        RabbitMQ may redeliver an unacked message while the previous worker
        process is still alive.  The marker prevents a second consumer from
        restarting generation from Step 2.  If the recorded pid is gone or the
        marker is older than the hard timeout window, the new delivery may
        take over.
        """
        path = self._active_job_marker_path(job_id)
        now = time.time()
        stale_after = max(
            hard_timeout_for_task(task_data) + ACTIVE_JOB_MARKER_GRACE_SECONDS,
            600,
        )
        token = f"{os.getpid()}:{time.time_ns()}"
        payload = {
            "job_id": job_id,
            "pid": os.getpid(),
            "token": token,
            "retry_count": retry_count,
            "created_at": now,
            "updated_at": now,
        }

        for _ in range(2):
            try:
                fd = os.open(
                    path,
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                    0o644,
                )
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump(payload, fh, ensure_ascii=False)
                return True, token, None
            except FileExistsError:
                existing = self._read_active_job_marker(job_id) or {}
                existing_pid = None
                try:
                    existing_pid = int(existing.get("pid") or 0)
                except (TypeError, ValueError):
                    existing_pid = None
                age = self._active_marker_age_seconds(path, existing)
                existing_retry_count = self._safe_marker_retry_count(
                    existing.get("retry_count")
                )
                incoming_retry_count = self._safe_marker_retry_count(retry_count)
                if existing_retry_count < incoming_retry_count:
                    logger.warning(
                        "[QUEUE] [%s] active marker retry takeover: "
                        "job_id=%s existing_retry=%s incoming_retry=%s "
                        "existing_pid=%s age=%.1fs",
                        _ts(),
                        job_id,
                        existing_retry_count,
                        incoming_retry_count,
                        existing_pid,
                        age,
                    )
                    try:
                        path.unlink()
                        continue
                    except FileNotFoundError:
                        continue
                    except OSError:
                        return False, "", existing
                active = pid_is_alive(existing_pid) and age < stale_after
                corrupt_but_recent = bool(existing.get("corrupt")) and age < stale_after
                if active or corrupt_but_recent:
                    return False, "", existing
                try:
                    path.unlink()
                except FileNotFoundError:
                    continue
                except OSError:
                    return False, "", existing
        return False, "", self._read_active_job_marker(job_id)

    def _release_active_job_marker(self, job_id: str, token: str | None) -> None:
        if not job_id or not token:
            return
        path = self._active_job_marker_path(job_id)
        marker = self._read_active_job_marker(job_id) or {}
        if marker.get("token") != token:
            return
        try:
            path.unlink()
        except FileNotFoundError:
            return
        except OSError:
            logger.warning(
                "[QUEUE] [%s] active job marker release failed: job_id=%s path=%s",
                _ts(),
                job_id,
                path,
            )

    def _release_claimed_active_job_marker(
        self,
        task_data: Dict[str, Any] | None,
        job_id: str | None,
    ) -> None:
        if not task_data or not job_id or job_id == "unknown":
            return
        token = task_data.pop("_active_job_marker_token", None)
        if not token:
            return
        self._release_active_job_marker(str(job_id), token)

    def _active_job_marker_dead_pid(self, marker: Dict[str, Any] | None) -> int | None:
        if not marker:
            return None
        try:
            pid = int(marker.get("pid") or 0)
        except (TypeError, ValueError):
            pid = 0
        if pid_is_alive(pid):
            return None
        return pid or None
