"""Duplicate RabbitMQ delivery handling for active jobs."""

from __future__ import annotations

import logging
from importlib import import_module
from datetime import datetime
from typing import Any, Dict

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


class ActiveJobDuplicateMixin:
    async def _ack_active_duplicate_delivery_if_needed(
        self,
        message,
        task_data: Dict[str, Any],
        *,
        queue_type: str,
        job_id: str,
        retry_count: int,
    ) -> bool:
        task_dispatcher = import_module("app.workers.task_dispatcher")
        if not task_data or not job_id or job_id == "unknown":
            return False
        claimed, token, existing = self._claim_active_job_marker(
            job_id,
            retry_count=retry_count,
            task_data=task_data,
        )
        if claimed:
            task_data["_active_job_marker_token"] = token
            return False

        task_data["_active_duplicate_delivery_guard"] = True
        task_data["_active_duplicate_delivery_existing"] = {
            "pid": (existing or {}).get("pid"),
            "retry_count": (existing or {}).get("retry_count"),
            "created_at": (existing or {}).get("created_at"),
            "corrupt": bool((existing or {}).get("corrupt")),
        }
        logger.warning(
            "[QUEUE] [%s] [%s] job already active; ack duplicate delivery "
            "without restarting generation job_id=%s existing_pid=%s retry=%s",
            _ts(),
            queue_type,
            job_id,
            (existing or {}).get("pid"),
            retry_count,
        )
        await task_dispatcher.ack_with_queue_evidence(
            message,
            task_data,
            stage="QUEUE_ACK_ACTIVE_DUPLICATE",
            detail=(
                "Active job delivery acked; previous worker process is still "
                "running, so direct_auto_planning/generate_stream is not repeated"
            ),
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
            flush=False,
        )
        return True
