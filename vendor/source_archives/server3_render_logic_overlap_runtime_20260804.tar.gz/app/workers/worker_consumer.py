"""RabbitMQ connection and consumer lifecycle."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime

from app.core.config import (
    DEFAULT_MAX_CONCURRENT_TASKS,
    normalize_max_concurrent_tasks,
    settings,
)

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


class WorkerConsumerMixin:
    async def connect(self):
        from app.services.rabbitmq_service import rabbitmq_service
        self._sync_concurrency_from_settings()
        logger.info(
            "Connecting to RabbitMQ... prefetch_count=%s",
            self._max_concurrent_tasks,
        )
        try:
            await rabbitmq_service.connect(
                prefetch_count=self._max_concurrent_tasks
            )
            self.connection = rabbitmq_service.connection
            self.channel = rabbitmq_service.channel
            await self.channel.set_qos(prefetch_count=self._max_concurrent_tasks)
            await self.channel.declare_queue(self.retry_queue_name, durable=True, arguments={"x-max-priority": 10})
            await self.channel.declare_queue(self.normal_queue_name, durable=True, arguments={"x-max-priority": 10})
            logger.info(
                "Connected to RabbitMQ and declared queues: prefetch_count=%s",
                self._max_concurrent_tasks,
            )
        except Exception as e:
            logger.exception("Failed to connect to RabbitMQ")
            raise

    def _sync_concurrency_from_settings(self) -> int:
        requested_max_concurrent_tasks = normalize_max_concurrent_tasks(
            getattr(settings, "MAX_CONCURRENT_TASKS",
                    DEFAULT_MAX_CONCURRENT_TASKS))
        max_concurrent_tasks = self._cap_concurrency_by_container_count(
            requested_max_concurrent_tasks
        )
        if max_concurrent_tasks != self._max_concurrent_tasks:
            logger.warning(
                "MAX_CONCURRENT_TASKS runtime sync: worker=%s settings=%s "
                "effective=%s",
                self._max_concurrent_tasks,
                requested_max_concurrent_tasks,
                max_concurrent_tasks,
            )
            self._max_concurrent_tasks = max_concurrent_tasks
            self._task_semaphore = asyncio.Semaphore(max_concurrent_tasks)
        return self._max_concurrent_tasks

    def _cap_concurrency_by_container_count(self, requested: int) -> int:
        container_count = len(getattr(self, "container_names", []) or [])
        if container_count <= 0:
            return requested
        return max(1, min(requested, container_count))

    async def start_consuming(self):
        if not self.channel:
            await self.connect()

        self._consuming = True
        while self._consuming:
            retry_queue = await self.channel.declare_queue(
                self.retry_queue_name,
                durable=True,
                arguments={"x-max-priority": 10},
            )
            normal_queue = await self.channel.declare_queue(
                self.normal_queue_name,
                durable=True,
                arguments={"x-max-priority": 10},
            )
            if not self._stale_active_job_recovery_checked:
                self._stale_active_job_recovery_checked = True
                await self._recover_stale_active_job_markers_on_startup()

            # 显示队列中待处理的消息数量
            logger.info(
                f"Queue status - RETRY: {retry_queue.declaration_result.message_count} messages, NORMAL: {normal_queue.declaration_result.message_count} messages")
            logger.info("Beginning consumption of queues (retry high priority).")

            retry_task = asyncio.create_task(
                self._consume_queue(retry_queue, is_retry_queue=True),
                name="rabbitmq-retry-consumer",
            )
            normal_task = asyncio.create_task(
                self._consume_queue(normal_queue, is_retry_queue=False),
                name="rabbitmq-normal-consumer",
            )
            self._consumer_tasks = [retry_task, normal_task]
            done, pending = await asyncio.wait(
                self._consumer_tasks,
                return_when=asyncio.FIRST_COMPLETED,
            )

            for task in done:
                self._last_consumer_exit_at = _ts()
                try:
                    task.result()
                except asyncio.CancelledError:
                    logger.info("[QUEUE] [%s] consumer task cancelled", _ts())
                except Exception as e:
                    self._last_consumer_error = f"{type(e).__name__}: {e}"
                    logger.exception(
                        "[QUEUE] [%s] consumer task exited with error: %s",
                        _ts(), e,
                    )
                else:
                    self._last_consumer_error = None
                    logger.warning(
                        "[QUEUE] [%s] consumer task exited while consuming=%s",
                        _ts(), self._consuming,
                    )

            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
            self._consumer_tasks = []

            if not self._consuming:
                break

            logger.warning(
                "[QUEUE] [%s] restarting RabbitMQ consumers after unexpected exit",
                _ts(),
            )
            await asyncio.sleep(5)

    async def stop_consuming(self):
        logger.info("Stopping consumption...")
        self._consuming = False
        for task in list(self._consumer_tasks):
            task.cancel()

    async def close(self):
        logger.info("Closing worker and RabbitMQ connection...")
        await self.stop_consuming()
        try:
            from app.services.rabbitmq_service import rabbitmq_service
            await rabbitmq_service.close()
            logger.info("RabbitMQ connection closed.")
        except Exception:
            logger.exception("Exception closing rabbitmq_service")

    async def _consume_queue(self, queue, is_retry_queue: bool):
        queue_type = "RETRY" if is_retry_queue else "NORMAL"
        logger.info(f"[QUEUE] [{_ts()}] 启动 {queue_type} 队列消费者（并发模式）")
        logger.info(f"[QUEUE] [{_ts()}] [{queue_type}] 等待消息中...")
        try:
            async for message in queue:
                if not self._consuming:
                    logger.info(f"[QUEUE] [{_ts()}] 消费已停止标志，退出循环")
                    break
                # 并发派发：不 await，立即取下一条消息
                task = asyncio.create_task(
                    self._handle_message(message, is_retry_queue))
                if not hasattr(self, "_inflight_tasks"):
                    self._inflight_tasks = set()
                self._inflight_tasks.add(task)
                task.add_done_callback(self._inflight_tasks.discard)
        except Exception as e:
            logger.exception(f"[QUEUE] [{_ts()}] {queue_type} 队列消费者异常退出: {e}")
            self._last_consumer_error = f"{queue_type}: {type(e).__name__}: {e}"
            self._last_consumer_exit_at = _ts()
            raise

