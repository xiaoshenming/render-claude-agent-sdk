"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
def _failure_scene_name_from_task_data(
    task_data: Optional[Dict[str, Any]],
    *,
    error_msg: str | None,
) -> str | None:
    if task_data:
        for key in (
            "_last_failure_signature",
            "_slice_repair_circuit_breaker",
            "_slice_repair_full_regenerate_signal",
            "_slice_render_error_contract",
        ):
            payload = _failure_signature_payload(task_data.get(key))
            if not payload:
                continue
            scene_name = payload.get("scene_name") or payload.get("scene")
            if scene_name:
                return str(scene_name)[:120]
    message = str(error_msg or "")
    match = re.search(r"\bscene(?:_name)?=([A-Za-z0-9_]+)", message)
    if match:
        return match.group(1)[:120]
    return None
def _append_failure_attribution_to_error_message(
    error_msg: str | None,
    attribution: Dict[str, Any],
) -> str:
    message = error_msg or ""
    if not attribution or "failure_attribution=" in message:
        return message
    encoded = json.dumps(
        attribution,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return f"{message}; failure_attribution={encoded}"
def _mq_attempt_id(
    task_data: Optional[Dict[str, Any]],
    *,
    job_id: str | None = None,
    retry_count: int | None = None,
) -> str | None:
    effective_job_id = job_id or (task_data or {}).get("job_id")
    if effective_job_id and retry_count is not None:
        return f"{effective_job_id}:{retry_count}"
    return (task_data or {}).get("attempt_id")
def _queue_name_for_type(queue_type: str | None) -> str | None:
    if queue_type == "RETRY":
        return "video_generate_retry_queue"
    if queue_type == "NORMAL":
        return "video_generate_queue"
    return queue_type
def _final_failure_state(result: Any) -> str:
    if result in {"changed", "already_terminal", "failed"}:
        return str(result)
    if result is True:
        return "changed"
    if result is False or result is None:
        return "failed"
    return "failed"
def _final_failure_ackable(result: Any) -> bool:
    return _final_failure_state(result) in {"changed", "already_terminal"}
def _terminal_failure_signature(
    *,
    job_id: str,
    error_type: str | None,
    error_stage: str | None,
    error_msg: str | None,
) -> str:
    """Stable key for repeated final-failure persist failures.

    The visible error message can contain dynamic values such as elapsed seconds
    or provider request ids. Counting by message would keep every redelivery at
    attempt 1 and defeat the poison guard.
    """
    payload = json.dumps(
        {
            "job_id": job_id,
            "error_type": error_type or "",
            "error_stage": error_stage or "",
            "message_bucket": "typed" if (error_type or error_stage) else (
                error_msg or ""
            )[:120],
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
    return f"{job_id}:{digest}"
def _record_final_failure_persist_failure(
    task_data: Optional[Dict[str, Any]],
    *,
    job_id: str,
    error_type: str | None,
    error_stage: str | None,
    error_msg: str | None,
) -> tuple[int, str]:
    signature = _terminal_failure_signature(
        job_id=job_id,
        error_type=error_type,
        error_stage=error_stage,
        error_msg=error_msg,
    )
    task_count = 0
    if task_data is not None:
        stored_signature = task_data.get("_final_failure_signature")
        if stored_signature in (None, signature):
            task_count = _safe_int(
                task_data.get("_final_failure_persist_failures"),
                0,
            )
    count = max(
        task_count,
        _FINAL_FAILURE_PERSIST_FAILURE_COUNTS.get(signature, 0),
    ) + 1
    _FINAL_FAILURE_PERSIST_FAILURE_COUNTS[signature] = count
    if task_data is not None:
        task_data["_final_failure_signature"] = signature
        task_data["_final_failure_persist_failures"] = count
    return count, signature
def _clear_final_failure_persist_guard(
    task_data: Optional[Dict[str, Any]],
    *,
    job_id: str,
    error_type: str | None,
    error_stage: str | None,
    error_msg: str | None,
) -> None:
    signature = _terminal_failure_signature(
        job_id=job_id,
        error_type=error_type,
        error_stage=error_stage,
        error_msg=error_msg,
    )
    _FINAL_FAILURE_PERSIST_FAILURE_COUNTS.pop(signature, None)
    if task_data is not None and task_data.get("_final_failure_signature") == signature:
        task_data.pop("_final_failure_signature", None)
        task_data.pop("_final_failure_persist_failures", None)
