"""render_pipeline.py — 并行渲染管线。

将多个 Scene 切片并行渲染，支持缓存 + 智能重试分组。
"""

import os
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, List

from app.workers.rendering import executor as render_executor

from app.workers.repair import error_fixer
from app.workers.pipeline.parallel_retries import repair_failed_groups

logger = logging.getLogger("render")
_CONTAINER_WAIT_ERROR_MARKERS = (
    "等待容器超时",
    "No available render containers",
    "container timeout",
    "container unavailable",
)
_TTS_RENDER_CONCURRENCY_LIMIT = 1
_SHARED_SIGNATURE_REGENERATE_MIN_SLICES = 3
_SHARED_SIGNATURE_FULL_COVERAGE_MIN_SLICES = 2
_SHARED_SIGNATURE_REGENERATE_RATIO = 0.5
_SHARED_SIGNATURE_SIGNAL_SCENE_LIMIT = 12


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _is_container_wait_error(err_msg: str | None) -> bool:
    text = str(err_msg or "")
    return any(marker in text for marker in _CONTAINER_WAIT_ERROR_MARKERS)


async def _initial_render_concurrency_limit(ctx, scene_count: int) -> int:
    """Cap initial scene rendering by currently free containers.

    Container acquisition can legitimately wait, but spawning more scene tasks
    than free containers makes queued scenes hit max_wait while earlier TTS
    scenes are still progressing. That is resource pressure, not bad Manim code.
    """
    if scene_count <= 1:
        return 1
    manager = getattr(ctx, "container_mgr", None)
    available: int | None = None
    counter = getattr(manager, "available_container_count", None)
    if callable(counter):
        try:
            value = counter()
            if asyncio.iscoroutine(value):
                value = await value
            available = int(value)
        except Exception as exc:
            logger.warning(
                f"[SLICE] [{_ts()}] 空闲容器数读取失败，使用场景数并发: {exc}")

    if available is None:
        available = scene_count

    return max(1, min(scene_count, max(1, available)))


def _task_uses_tts(task_data: Dict[str, Any] | None) -> bool:
    if not isinstance(task_data, dict):
        return False
    if task_data.get("enable_tts") is True:
        return True
    if task_data.get("needs_voiceover") is True:
        return True
    if str(task_data.get("voice_id") or "").strip():
        return True
    if str(task_data.get("tts_provider") or "").strip():
        return True
    if str(task_data.get("system_tts_voice") or "").strip():
        return True
    return False


def _shared_signature_requires_regenerate(
    failed_count: int,
    total_count: int,
) -> bool:
    if total_count <= 0:
        return False
    if failed_count >= _SHARED_SIGNATURE_REGENERATE_MIN_SLICES:
        return (failed_count / total_count) >= _SHARED_SIGNATURE_REGENERATE_RATIO
    return (
        failed_count >= _SHARED_SIGNATURE_FULL_COVERAGE_MIN_SLICES
        and failed_count == total_count
    )


def _record_shared_signature_regenerate_signal(
    task_data: Dict[str, Any] | None,
    *,
    signature: str,
    group: list[tuple[str, str]],
    total_count: int,
) -> None:
    if not isinstance(task_data, dict) or not group:
        return
    scene_names = [name for name, _ in group]
    task_data["_slice_repair_full_regenerate_signal"] = {
        "reason": "multi_slice_same_signature",
        "lane": "render_repair",
        "from_strategy": "parallel_shared_signature_repair",
        "next_strategy": "full_stream_regenerate",
        "signature": signature,
        "scene_name": scene_names[0],
        "scene_names": scene_names[:_SHARED_SIGNATURE_SIGNAL_SCENE_LIMIT],
        "failed_slice_count": len(group),
        "total_slice_count": total_count,
        "threshold_ratio": _SHARED_SIGNATURE_REGENERATE_RATIO,
        "min_slice_count": _SHARED_SIGNATURE_REGENERATE_MIN_SLICES,
        "full_coverage_min_slice_count": _SHARED_SIGNATURE_FULL_COVERAGE_MIN_SLICES,
        "first_error": str(group[0][1] or "")[:1000],
    }


async def _mark_processing_heartbeat(
    job_id: str,
    scene_name: str,
    stage: str,
) -> None:
    async def _send() -> None:
        try:
            from app.services import job_repository

            await job_repository.update_job_status(job_id, "PROCESSING")
        except Exception as exc:
            logger.warning(
                f"[HEARTBEAT] [{_ts()}] 任务 {job_id} 切片 {scene_name} "
                f"{stage} PROCESSING 打点失败，继续主流程: {exc}"
            )

    asyncio.create_task(_send())
    await asyncio.sleep(0)


async def render_slices_parallel(
    ctx, script_path: str,
    scene_names: List[str], job_output_dir: str,
    timeout_sec: int = 900,
    task_data: Dict[str, Any] = None,
    repair_failed_slices: bool = True,
) -> List[str]:
    """并行渲染所有切片，返回有序 mp4 路径列表"""
    job_id = ctx.job_id
    aspect_ratio = ctx.aspect_ratio

    slices_dir = os.path.join(job_output_dir, "slices")
    os.makedirs(slices_dir, exist_ok=True)

    async def render_one(scene_name: str):
        # --- 缓存检查：在获取容器前先查缓存 ---
        try:
            with open(script_path, "r", encoding="utf-8") as f:
                _full_code = f.read()
            _scene_code = error_fixer.extract_scene_code(
                _full_code, scene_name)
            if _scene_code:
                cached = error_fixer.check_scene_cache(
                    _scene_code, aspect_ratio,
                    ctx.cache_dir)
                if cached:
                    mp4_path = os.path.join(
                        slices_dir, f"{scene_name}.mp4")
                    with open(mp4_path, "wb") as f:
                        f.write(cached)
                    logger.info(
                        f"[CACHE] [{_ts()}] ✓ {scene_name} "
                        f"缓存命中 ({len(cached)/1024/1024:.2f}MB)")
                    return scene_name, mp4_path, None
        except Exception as ce:
            logger.warning(
                f"[CACHE] [{_ts()}] {scene_name} "
                f"缓存检查异常，继续渲染: {ce}")

        container = None
        try:
            container = await ctx.container_mgr.select_idle_container(
                wait=True, max_wait=600)
            if not container:
                raise Exception(f"切片 {scene_name} 等待容器超时")
            slice_out = os.path.join(slices_dir, scene_name)
            os.makedirs(slice_out, exist_ok=True)
            logger.info(
                f"[SLICE] [{_ts()}] 开始渲染 {scene_name} "
                f"在容器 {container}")
            await _mark_processing_heartbeat(
                job_id, scene_name, "render_start")
            video_bytes = await render_executor.render_in_container(
                    container, f"{job_id}_{scene_name}",
                    script_path, scene_name,
                    slice_out, aspect_ratio, timeout_sec,
                    ctx.manim_media_root, ctx.media_root,
                    task_data=task_data)
            mp4_path = os.path.join(
                slices_dir, f"{scene_name}.mp4")
            with open(mp4_path, "wb") as f:
                f.write(video_bytes)
            await _mark_processing_heartbeat(
                job_id, scene_name, "render_done")
            # --- 渲染成功后保存缓存 ---
            try:
                with open(script_path, "r", encoding="utf-8") as f:
                    _fc = f.read()
                _sc = error_fixer.extract_scene_code(_fc, scene_name)
                if _sc:
                    error_fixer.save_scene_cache(
                        _sc, aspect_ratio, video_bytes, ctx.cache_dir)
            except Exception as ce:
                logger.warning(
                    f"[CACHE] [{_ts()}] {scene_name} "
                    f"缓存保存异常，跳过: {ce}")
            logger.info(
                f"[SLICE] [{_ts()}] ✓ {scene_name} 渲染成功 "
                f"({len(video_bytes)/1024/1024:.2f}MB)")
            return scene_name, mp4_path, None
        except Exception as e:
            logger.warning(
                f"[SLICE] [{_ts()}] ✗ {scene_name} "
                f"渲染失败: {e}")
            return scene_name, None, str(e)
        finally:
            if container:
                try:
                    ctx.container_mgr.release_lock(container)
                except Exception:
                    pass

    # >>> 检查点C：渲染前
    if await ctx.is_job_cancelled(job_id):
        logger.info(f"[TASK] [{_ts()}] 任务 {job_id} 已被终止，跳过渲染")
        return []
    logger.info(
        f"[SLICE] [{_ts()}] 开始并行渲染 "
        f"{len(scene_names)} 个切片: {scene_names}")
    render_limit = await _initial_render_concurrency_limit(
        ctx, len(scene_names))
    if _task_uses_tts(task_data):
        render_limit = max(
            1,
            min(render_limit, _TTS_RENDER_CONCURRENCY_LIMIT),
        )
    logger.info(
        f"[SLICE] [{_ts()}] 初始渲染并发上限: {render_limit}/"
        f"{len(scene_names)}")
    render_sem = asyncio.Semaphore(render_limit)

    async def render_one_limited(name: str):
        async with render_sem:
            return await render_one(name)

    tasks = [render_one_limited(name) for name in scene_names]
    results = await asyncio.gather(*tasks)

    # 分段修复
    failed = [
        (name, err) for name, path, err in results
        if err is not None]
    success = {
        name: path for name, path, err in results
        if err is None}
    if failed and not repair_failed_slices:
        failure_summary = "; ".join(
            f"{name}: {str(err)[:240]}" for name, err in failed[:5]
        )
        raise Exception(
            "render_slices_failed_without_legacy_repair: "
            f"failed={len(failed)}/{len(scene_names)}; {failure_summary}"
        )
    if failed:
        await repair_failed_groups(
            ctx, script_path, scene_names, slices_dir, timeout_sec,
            task_data, failed, success,
        )

    ordered = [success[name] for name in scene_names]
    logger.info(
        f"[SLICE] [{_ts()}] ✓ 全部 "
        f"{len(scene_names)} 个切片渲染完成")
    return ordered
