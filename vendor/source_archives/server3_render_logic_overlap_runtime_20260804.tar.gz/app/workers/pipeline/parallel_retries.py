"""并行切片渲染的失败重试阶段。"""

import asyncio
import logging
from pathlib import Path

from app.workers.rendering import executor as render_executor
from app.workers.repair import error_fixer
from app.workers.repair.slice_fixer import retry_failed_slice
from app.workers.repair.error_patterns import is_tts_error

logger = logging.getLogger("render")
_MARKERS = ("等待容器超时", "No available render containers", "container timeout", "container unavailable")


def _ts() -> str:
    from .parallel import _ts as timestamp
    return timestamp()


def _is_container_wait_error(message: str | None) -> bool:
    text = str(message or "")
    return any(marker in text for marker in _MARKERS)


async def _heartbeat(job_id: str, scene: str, stage: str) -> None:
    from .parallel import _mark_processing_heartbeat
    await _mark_processing_heartbeat(job_id, scene, stage)


def _needs_full_regenerate(failed: int, total: int) -> bool:
    return total > 0 and ((failed >= 3 and failed / total >= 0.5) or (failed >= 2 and failed == total))


def _signal_full_regenerate(task_data, signature, group, total) -> None:
    if not isinstance(task_data, dict) or not group:
        return
    task_data["_slice_repair_full_regenerate_signal"] = {
        "reason": "multi_slice_same_signature", "lane": "render_repair",
        "from_strategy": "parallel_shared_signature_repair",
        "next_strategy": "full_stream_regenerate", "signature": signature,
        "scene_name": group[0][0], "scene_names": [n for n, _ in group][:12],
        "failed_slice_count": len(group), "total_slice_count": total,
        "threshold_ratio": 0.5, "min_slice_count": 3,
        "full_coverage_min_slice_count": 2,
        "first_error": str(group[0][1] or "")[:1000],
    }


async def repair_failed_groups(ctx, script_path, scene_names, slices_dir, timeout_sec, task_data, failed, success):
    """按错误签名执行 TTS、资源等待、共享修复和隔离并发修复。"""
    job_id, aspect_ratio = ctx.job_id, ctx.aspect_ratio
    groups = {}
    for name, message in failed:
        groups.setdefault(error_fixer.error_signature(message), []).append((name, message))

    async def rerender(scene, max_wait=600):
        container = None
        try:
            container = await ctx.container_mgr.select_idle_container(wait=True, max_wait=max_wait)
            if not container:
                raise Exception(f"切片 {scene} 等待容器超时")
            output = Path(slices_dir) / scene
            output.mkdir(parents=True, exist_ok=True)
            await _heartbeat(job_id, scene, "rerender_start")
            data = await render_executor.render_in_container(container, f"{job_id}_{scene}", script_path, scene, str(output), aspect_ratio, timeout_sec, ctx.manim_media_root, ctx.media_root, task_data=task_data)
            target = Path(slices_dir) / f"{scene}.mp4"
            target.write_bytes(data)
            await _heartbeat(job_id, scene, "rerender_done")
            return scene, str(target)
        finally:
            if container:
                try: ctx.container_mgr.release_lock(container)
                except Exception: pass

    async def retry_tts(group):
        for scene, message in group:
            await _heartbeat(job_id, scene, "tts_retry_start")
            result = await retry_failed_slice(ctx, script_path=script_path, scene_name=scene, slices_dir=slices_dir, timeout_sec=timeout_sec, last_error=message, max_retries=3, task_data=task_data)
            if result:
                await _heartbeat(job_id, scene, "tts_retry_done"); success[scene] = result
            else:
                raise Exception(f"TTS_PROVIDER_TRANSIENT: tts_retry_exhausted: 切片 {scene} TTS 重试 3 次仍失败（网络问题）; last_error={message}")

    individual = []
    for signature, group in groups.items():
        first_error = group[0][1]
        if is_tts_error(first_error):
            await retry_tts(group); continue
        if all(_is_container_wait_error(error) for _, error in group):
            for scene, _ in group:
                name, path = await rerender(scene, max_wait=900); success[name] = path
            continue
        if _needs_full_regenerate(len(group), len(scene_names)):
            _signal_full_regenerate(task_data, signature, group, len(scene_names))
            raise Exception(f"slice_repair_exhausted: multi_slice_same_signature; failed_slices={len(group)}/{len(scene_names)}; signature={signature}; next_strategy=full_stream_regenerate")
        if len(group) >= 3:
            scene, message = group[0]
            await _heartbeat(job_id, scene, "shared_repair_start")
            result = await retry_failed_slice(ctx, script_path=script_path, scene_name=scene, slices_dir=slices_dir, timeout_sec=timeout_sec, last_error=message, max_retries=3, task_data=task_data)
            if not result: raise Exception(f"切片 {scene} 重试 3 次仍失败")
            await _heartbeat(job_id, scene, "shared_repair_done"); success[scene] = result
            for name, path in await asyncio.gather(*(rerender(n) for n, _ in group[1:])): success[name] = path
        else:
            individual.extend(group)

    if individual:
        source = Path(script_path).read_text(encoding="utf-8", errors="replace")
        stem, directory = Path(script_path).stem, Path(script_path).parent
        async def isolated(scene, message):
            temporary = directory / f".{stem}_{scene}_render_repair.py"; temporary.write_text(source, encoding="utf-8")
            try:
                await _heartbeat(job_id, scene, "repair_start")
                result = await retry_failed_slice(ctx, script_path=str(temporary), scene_name=scene, slices_dir=slices_dir, timeout_sec=timeout_sec, last_error=message, max_retries=3, task_data=task_data)
                if not result: return scene, message, None, None
                repaired = temporary.read_text(encoding="utf-8", errors="replace")
                original_scene = error_fixer.extract_scene_code(source, scene); changed_scene = error_fixer.extract_scene_code(repaired, scene)
                if not changed_scene or changed_scene == original_scene: return scene, message, result, None
                if source.replace(original_scene, "__SCENE_PATCH_TARGET__", 1) != repaired.replace(changed_scene, "__SCENE_PATCH_TARGET__", 1): return scene, message, result, None
                return scene, message, result, changed_scene
            finally:
                try: temporary.unlink()
                except OSError: pass
        results = await asyncio.gather(*(isolated(*item) for item in individual))
        merged = source; fallback = []
        for scene, message, result, changed in results:
            if changed is None:
                fallback.append((scene, message)); continue
            if result: success[scene] = result
            merged = error_fixer.replace_scene_code(merged, scene, changed)
        if merged != source: Path(script_path).write_text(merged, encoding="utf-8")
        for scene, message in fallback:
            result = await retry_failed_slice(ctx, script_path=script_path, scene_name=scene, slices_dir=slices_dir, timeout_sec=timeout_sec, last_error=message, max_retries=3, task_data=task_data)
            if result: success[scene] = result
            else: raise Exception(f"切片 {scene} 重试 3 次仍失败")
