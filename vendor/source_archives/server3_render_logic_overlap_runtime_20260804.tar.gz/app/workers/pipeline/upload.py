"""upload_handler.py — 视频/代码上传处理。

上传到腾讯云 COS，带重试和回滚机制。
"""
# ruff: noqa: F401  # Preserve historical private imports.

import re
import ast
import asyncio
import logging
import time
from datetime import datetime
from typing import Any

from app.core.render_canvas_profile import get_render_canvas_profile
from app.services.storage_service import storage_service
from .upload_contracts import (
    MAX_UPLOAD_ATTEMPTS,
    _record_collector_event,
    _record_upload_attempt,
    _ts,
    _variant_path_component,
    _video_suffix,
)
from .upload_code import (
    _looks_structurally_complete_manim_code,
    _prepare_code_for_upload,
    _rollback_uploaded_files,
)

logger = logging.getLogger("render")


async def _upload_video_variant(
    job_id: str,
    user_id: str,
    video_data: bytes,
    *,
    aspect_ratio: str = "16:9",
    render_canvas_profile_name: str | None = None,
    variant: str,
    collector: Any | None = None,
) -> str:
    """上传同一任务的额外视频版本，不上传代码。"""
    suffix = _video_suffix(
        aspect_ratio,
        render_canvas_profile_name=render_canvas_profile_name,
    )
    variant_part = _variant_path_component(variant)
    video_path = f"videos/{user_id}/{job_id}_{variant_part}{suffix}"
    logger.info(
        f"[UPLOAD] [{_ts()}] 开始上传视频变体: job_id={job_id}, "
        f"variant={variant_part}, 视频大小={len(video_data) / 1024 / 1024:.2f}MB"
    )
    for attempt in range(MAX_UPLOAD_ATTEMPTS):
        try:
            video_start = time.time()
            video_url = await storage_service.upload_file(
                video_path,
                video_data,
                content_type="video/mp4",
                cache_control="public, max-age=31536000",
            )
            video_duration = time.time() - video_start
            if not video_url or not video_url.startswith("http"):
                raise Exception(f"上传返回无效URL: {video_url}")
            logger.info(
                f"[UPLOAD] [{_ts()}] ✓ 视频变体上传完成: "
                f"variant={variant_part}, 耗时={video_duration:.2f}s, "
                f"attempt={attempt + 1}"
            )
            _record_upload_attempt(
                collector,
                level="info",
                stage="VIDEO_VARIANT_UPLOAD",
                artifact=f"video:{variant_part}",
                path=video_path,
                attempt=attempt + 1,
                message="视频变体上传完成",
                url=video_url,
                size_bytes=len(video_data),
                duration_ms=int(video_duration * 1000),
            )
            return video_url
        except Exception as e:
            logger.warning(
                f"[UPLOAD] [{_ts()}] 视频变体上传失败 "
                f"(variant={variant_part}, attempt={attempt + 1}/3): {e}"
            )
            is_final_attempt = attempt == MAX_UPLOAD_ATTEMPTS - 1
            _record_upload_attempt(
                collector,
                level="error" if is_final_attempt else "warning",
                stage="VIDEO_VARIANT_UPLOAD",
                artifact=f"video:{variant_part}",
                path=video_path,
                attempt=attempt + 1,
                message="视频变体上传失败" if is_final_attempt else "视频变体上传重试",
                error=e,
                size_bytes=len(video_data),
            )
            if is_final_attempt:
                raise Exception(f"视频变体上传失败（重试3次）: {e}")
            await asyncio.sleep(1)
    raise Exception("视频变体上传失败")


async def _upload_results(
    job_id: str,
    user_id: str,
    video_data: bytes,
    code: str,
    aspect_ratio: str = "16:9",
    render_canvas_profile_name: str | None = None,
    collector: Any | None = None,
):
    """
    上传视频和代码文件，带重试机制
    如果视频上传成功但代码上传失败，会回滚已上传的视频
    """
    logger.info(
        f"[UPLOAD] [{_ts()}] 开始上传: job_id={job_id}, 视频大小={len(video_data) / 1024 / 1024:.2f}MB, 代码大小={len(code)}bytes"
    )
    video_suffix = _video_suffix(
        aspect_ratio,
        render_canvas_profile_name=render_canvas_profile_name,
    )
    video_path = f"videos/{user_id}/{job_id}{video_suffix}"
    code_path = f"codes/{user_id}/{job_id}.py"
    video_url = None

    # 上传视频（带重试）
    for attempt in range(MAX_UPLOAD_ATTEMPTS):
        try:
            video_start = time.time()
            video_url = await storage_service.upload_file(
                video_path,
                video_data,
                content_type="video/mp4",
                cache_control="public, max-age=31536000",
            )
            video_duration = time.time() - video_start

            # 验证返回的URL
            if not video_url or not video_url.startswith("http"):
                raise Exception(f"上传返回无效URL: {video_url}")

            logger.info(
                f"[UPLOAD] [{_ts()}] ✓ 视频上传完成: 耗时={video_duration:.2f}s, attempt={attempt + 1}"
            )
            _record_upload_attempt(
                collector,
                level="info",
                stage="VIDEO_UPLOAD",
                artifact="video",
                path=video_path,
                attempt=attempt + 1,
                message="视频上传完成",
                url=video_url,
                size_bytes=len(video_data),
                duration_ms=int(video_duration * 1000),
            )
            break
        except Exception as e:
            logger.warning(
                f"[UPLOAD] [{_ts()}] 视频上传失败 (attempt={attempt + 1}/3): {e}"
            )
            is_final_attempt = attempt == MAX_UPLOAD_ATTEMPTS - 1
            _record_upload_attempt(
                collector,
                level="error" if is_final_attempt else "warning",
                stage="VIDEO_UPLOAD",
                artifact="video",
                path=video_path,
                attempt=attempt + 1,
                message="视频上传失败" if is_final_attempt else "视频上传重试",
                error=e,
                size_bytes=len(video_data),
            )
            if is_final_attempt:
                raise Exception(f"视频上传失败（重试3次）: {e}")
            await asyncio.sleep(1)

    # 上传代码。若结构完整但缺少结束哨兵，补齐哨兵；只有结构异常才保留截断告警。
    code = _prepare_code_for_upload(code, collector=collector)
    for attempt in range(MAX_UPLOAD_ATTEMPTS):
        try:
            code_start = time.time()
            code_url = await storage_service.upload_file(
                code_path,
                code.encode("utf-8"),
                content_type="text/x-python; charset=utf-8",
            )
            code_duration = time.time() - code_start

            # 验证返回的URL
            if not code_url or not code_url.startswith("http"):
                raise Exception(f"上传返回无效URL: {code_url}")

            logger.info(
                f"[UPLOAD] [{_ts()}] ✓ 代码上传完成: 耗时={code_duration:.2f}s, attempt={attempt + 1}"
            )
            _record_upload_attempt(
                collector,
                level="info",
                stage="CODE_UPLOAD",
                artifact="code",
                path=code_path,
                attempt=attempt + 1,
                message="代码上传完成",
                url=code_url,
                size_bytes=len(code.encode("utf-8")),
                duration_ms=int(code_duration * 1000),
            )
            return video_url, code_url
        except Exception as e:
            logger.warning(
                f"[UPLOAD] [{_ts()}] 代码上传失败 (attempt={attempt + 1}/3): {e}"
            )
            is_final_attempt = attempt == MAX_UPLOAD_ATTEMPTS - 1
            _record_upload_attempt(
                collector,
                level="error" if is_final_attempt else "warning",
                stage="CODE_UPLOAD",
                artifact="code",
                path=code_path,
                attempt=attempt + 1,
                message="代码上传失败" if is_final_attempt else "代码上传重试",
                error=e,
                size_bytes=len(code.encode("utf-8")),
            )
            if is_final_attempt:
                # 代码上传最终失败，回滚已上传的视频
                if video_url:
                    logger.warning(
                        f"[UPLOAD] [{_ts()}] 代码上传失败，回滚已上传的视频..."
                    )
                    try:
                        await storage_service.delete_file(video_url)
                        logger.info(f"[UPLOAD] [{_ts()}] ✓ 已回滚视频: {video_url}")
                        _record_collector_event(
                            collector,
                            "info",
                            "UPLOAD",
                            "VIDEO_ROLLBACK",
                            "代码上传失败后已回滚视频",
                            context={"url": video_url, "reason": "code_upload_failed"},
                        )
                    except Exception as del_e:
                        logger.warning(f"[UPLOAD] [{_ts()}] 回滚视频失败: {del_e}")
                        _record_collector_event(
                            collector,
                            "error",
                            "UPLOAD",
                            "VIDEO_ROLLBACK",
                            "代码上传失败后回滚视频失败",
                            context={
                                "url": video_url,
                                "reason": "code_upload_failed",
                                "error": str(del_e),
                            },
                        )
                raise Exception(f"代码上传失败（重试3次）: {e}")
            await asyncio.sleep(1)
