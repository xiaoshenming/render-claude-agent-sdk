"""render_context.py — 渲染管线共享上下文。

所有从 video_worker.py 提取的渲染管线函数都接受 RenderContext
作为第一参数，避免透传大量参数。
"""

import os
import time
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, Dict, Optional

logger = logging.getLogger("render")


class TimedContainerManager:
    """Proxy container manager that records cumulative wait time in task_data."""

    def __init__(self, manager: Any, task_data: Dict[str, Any] | None):
        self._manager = manager
        self._task_data = task_data if isinstance(task_data, dict) else None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._manager, name)

    async def select_idle_container(
        self,
        wait: bool = True,
        max_wait: Optional[int] = 600,
    ) -> Optional[str]:
        started = time.monotonic()
        container = await self._manager.select_idle_container(
            wait=wait,
            max_wait=max_wait,
        )
        wait_sec = max(0.0, time.monotonic() - started)
        if self._task_data is not None:
            self._task_data["_container_wait_sec"] = round(
                float(self._task_data.get("_container_wait_sec", 0.0) or 0.0)
                + wait_sec,
                3,
            )
            self._task_data.setdefault("_container_wait_events", []).append(
                {
                    "container": container,
                    "wait_sec": round(wait_sec, 3),
                    "wait": bool(wait),
                    "max_wait": max_wait,
                }
            )
        return container

    def release_lock(self, container: Any) -> None:
        self._manager.release_lock(container)


@dataclass
class RenderContext:
    """渲染管线共享上下文"""
    job_id: str
    task_data: Dict[str, Any]
    manim_media_root: str
    media_root: str
    cache_dir: str
    container_mgr: Any          # ContainerManager
    aspect_ratio: str = "16:9"
    timeout_sec: int = 900
    is_job_cancelled: Any = None  # async callable(job_id)->bool

    def __post_init__(self) -> None:
        if not isinstance(self.container_mgr, TimedContainerManager):
            self.container_mgr = TimedContainerManager(
                self.container_mgr,
                self.task_data,
            )

    # ---- 便利属性 ----
    @property
    def job_script_dir(self) -> str:
        return os.path.join(
            self.manim_media_root, f"job_{self.job_id}")

    @property
    def job_output_dir(self) -> str:
        return os.path.join(
            self.media_root, f"job_{self.job_id}")
