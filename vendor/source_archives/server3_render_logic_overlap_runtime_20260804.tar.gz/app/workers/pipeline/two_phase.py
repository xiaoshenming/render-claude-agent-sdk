"""two_phase_pipeline.py — 两阶段生成管线。

Phase 1: LLM 生成故事板大纲 (JSON)。
Phase 2: 每个 Scene 并行生成代码 + 并行渲染。
"""

import os
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, List

from app.core.render_canvas_profile import get_render_canvas_profile
from app.workers.validation import code_validator
from app.services import ffmpeg_service
from app.workers.pipeline.parallel import render_slices_parallel

logger = logging.getLogger("render")


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


async def two_phase_generate_and_render(
    ctx,
    user_prompt: str,
    color_scheme: int,
    enable_tts: bool,
    tts_voice: str,
    voice_type: str,
    cosyvoice_id: str,
    job_output_dir: str,
    provider: str = "MathPi-2D",
    timeout_sec: int = 900,
):
    """Two-phase generation pipeline.

    Phase 1: LLM generates a storyboard outline (JSON).
    Phase 2: For each scene in the outline, LLM generates
             the Scene class code in parallel, then each
             scene is rendered as soon as its code is ready.
    Returns (full_code, slice_mp4_paths, total_cost).
    """
    job_id = ctx.job_id
    task_data = ctx.task_data
    aspect_ratio = ctx.aspect_ratio
    render_canvas_profile_name = str(
        task_data.get("render_canvas_profile_name") or ""
    ).strip() or None
    render_canvas_profile = get_render_canvas_profile(
        aspect_ratio,
        profile_name=render_canvas_profile_name,
    )

    from app.services.llm_service import (
        generate_outline, generate_single_scene,
    )
    from app.prompts.header_template import (
        apply_render_canvas_config,
        color_vars_for_header,
        HEADER_TEMPLATE,
        THREED_HEADER_TEMPLATE,
        VOICE_HEADER_TEMPLATE,
        THREED_VOICE_HEADER_TEMPLATE,
        THREED_PORTRAIT_HEADER_TEMPLATE,
        THREED_VOICE_PORTRAIT_HEADER_TEMPLATE,
    )

    # --- Phase 1: Generate outline ---
    logger.info(
        f"[TWO-PHASE] [{_ts()}] Phase 1: "
        f"generating outline for job {job_id}")
    outline, outline_cost, outline_tokens = await generate_outline(
        user_prompt,
        job_id=job_id,
    )
    total_cost = outline_cost
    task_data["_total_tokens"] = task_data.get("_total_tokens", 0) + outline_tokens
    scenes = outline.get("scenes", [])
    if not scenes:
        raise ValueError(
            "Outline contains no scenes")
    logger.info(
        f"[TWO-PHASE] [{_ts()}] Outline: "
        f"{len(scenes)} scenes, "
        f"title={outline.get('title', '?')}")

    # --- Build header: 根据 2D/3D 和 TTS 开关选择 header ---
    is_3d = provider == "MathPi-3D"
    # 确定实际 voice 名称（克隆音色 or 系统音色）
    actual_voice = tts_voice
    if enable_tts and voice_type == "clone" and cosyvoice_id:
        actual_voice = cosyvoice_id

    if is_3d:
        if aspect_ratio == "9:16" and enable_tts:
            header_code = THREED_VOICE_PORTRAIT_HEADER_TEMPLATE
        elif aspect_ratio == "9:16":
            header_code = THREED_PORTRAIT_HEADER_TEMPLATE
        elif enable_tts:
            header_code = THREED_VOICE_HEADER_TEMPLATE
        else:
            header_code = THREED_HEADER_TEMPLATE
        color_vars = color_vars_for_header(
            color_scheme,
            profile_name=render_canvas_profile_name,
        )
        header_code = header_code.replace("__COLOR__", color_vars)
    else:
        color_vars = color_vars_for_header(
            color_scheme,
            profile_name=render_canvas_profile_name,
        )
        if enable_tts:
            header_code = VOICE_HEADER_TEMPLATE.replace(
                "__COLOR__", color_vars)
        else:
            header_code = HEADER_TEMPLATE.replace(
                "__COLOR__", color_vars)
        header_code = apply_render_canvas_config(
            header_code,
            aspect_ratio,
            profile_name=render_canvas_profile_name,
        )

    if enable_tts and voice_type == "clone" and cosyvoice_id:
        from app.prompts.clone_voice_prompts import use_clone_voice_service
        header_code = use_clone_voice_service(header_code)
    if enable_tts:
        header_code = header_code.replace("__VOICE__", actual_voice)

    # 如果使用克隆音色，注入 custom_services 路径
    if enable_tts and voice_type == "clone":
        import os as _os
        app_root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
        header_code = f'import sys; sys.path.insert(0, "{app_root}")\n' + header_code

    # Extract BaseConfigScene code for the prompt
    base_class_code = header_code[
        header_code.index("class BaseConfigScene"):]

    # 根据 2D/3D + TTS 选择 scene prompt
    scene_prompt_override = ""
    if is_3d and aspect_ratio == "9:16" and enable_tts:
        from app.prompts.threed_scene_portrait_prompt import (
            THREED_SCENE_VOICE_PORTRAIT_PROMPT,
        )
        scene_prompt_override = THREED_SCENE_VOICE_PORTRAIT_PROMPT
    elif is_3d and aspect_ratio == "9:16":
        from app.prompts.threed_scene_portrait_prompt import (
            THREED_SCENE_PORTRAIT_PROMPT,
        )
        scene_prompt_override = THREED_SCENE_PORTRAIT_PROMPT
    elif is_3d and enable_tts:
        from app.prompts.threed_scene_voice_prompt import (
            THREED_SCENE_VOICE_PROMPT,
        )
        scene_prompt_override = THREED_SCENE_VOICE_PROMPT
    elif is_3d:
        from app.prompts.threed_scene_prompt import (
            THREED_SCENE_PROMPT,
        )
        scene_prompt_override = THREED_SCENE_PROMPT
    elif enable_tts:
        from app.prompts.scene_voice_prompt import (
            SCENE_VOICE_PROMPT,
        )
        scene_prompt_override = SCENE_VOICE_PROMPT
    # else: 默认使用 scene_prompt.py（generate_single_scene 内部加载）

    # --- Phase 2: Parallel scene generation ---
    logger.info(
        f"[TWO-PHASE] [{_ts()}] Phase 2: "
        f"generating {len(scenes)} scenes in parallel")

    async def gen_and_render_one(scene_info):
        """Generate code for one scene then render."""
        name, code, scene_cost, scene_tokens = await generate_single_scene(
            outline, scene_info,
            base_class_code, color_scheme,
            scene_prompt_override=scene_prompt_override,
            job_id=job_id,
            voice_type=voice_type,
            cosyvoice_id=cosyvoice_id,
        )
        task_data["_total_tokens"] = task_data.get("_total_tokens", 0) + scene_tokens
        # Assemble per-scene script
        scene_script = header_code + "\n\n" + code
        return name, code, scene_script, scene_cost

    # Run all scene generations in parallel
    gen_tasks = [
        gen_and_render_one(s) for s in scenes]
    gen_results = await asyncio.gather(
        *gen_tasks, return_exceptions=True)

    # Collect results, raise on total failure
    scene_codes = {}
    scene_scripts = {}
    for i, result in enumerate(gen_results):
        if isinstance(result, Exception):
            logger.error(
                f"[TWO-PHASE] [{_ts()}] Scene "
                f"{scenes[i]['name']} generation "
                f"failed: {result}")
            raise result
        name, code, script, scene_cost = result
        scene_codes[name] = code
        scene_scripts[name] = script
        total_cost += scene_cost

    # --- Assemble full script ---
    scene_names_ordered = [s["name"] for s in scenes]
    full_code = header_code + "\n\n"
    full_code += "\n\n".join(
        scene_codes[n] for n in scene_names_ordered)

    # --- 渲染前全文扫描 ---
    from app.workers.repair.pre_render_fixes import pre_render_scan
    full_code, scan_fixes = pre_render_scan(full_code, color_scheme=color_scheme)
    if scan_fixes:
        logger.info(
            f"[TWO-PHASE] [{_ts()}] 渲染前扫描修复: "
            f"{'; '.join(scan_fixes)}")
    if enable_tts:
        from app.workers.validation.generated_code_quality import (
            raise_for_blocking_static_contracts_with_auto_fix,
        )
        full_code = raise_for_blocking_static_contracts_with_auto_fix(full_code, enable_tts=True)
    else:
        from app.workers.validation.generated_code_quality import (
            raise_for_blocking_static_contracts_with_auto_fix,
        )
        full_code = raise_for_blocking_static_contracts_with_auto_fix(full_code)

    # Write full script
    script_path = os.path.join(
        job_output_dir, f"{job_id}_full.py")
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(full_code)
    logger.info(
        f"[TWO-PHASE] [{_ts()}] Full script "
        f"written: {script_path}")

    # --- Render via existing parallel pipeline ---
    slice_paths = await render_slices_parallel(
            ctx, script_path,
        scene_names_ordered, job_output_dir,
        aspect_ratio, timeout_sec,
        task_data=task_data)

    # --- Concat ---
    final_mp4 = os.path.join(
        job_output_dir, f"{job_id}.mp4")
    video_bytes = await ffmpeg_service.concat_slices(
        slice_paths,
        final_mp4,
        require_audio=enable_tts,
        target_resolution=(
            render_canvas_profile.pixel_width,
            render_canvas_profile.pixel_height,
        ) if render_canvas_profile_name else None,
    )

    logger.info(
        f"[TWO-PHASE] [{_ts()}] Pipeline done: "
        f"{len(slice_paths)} slices, "
        f"{len(video_bytes)/1024/1024:.2f}MB")

    return full_code, video_bytes, total_cost
