"""Upload path, suffix, retry-evidence, and timestamp helpers."""

import re
from datetime import datetime
from typing import Any
from app.core.render_canvas_profile import get_render_canvas_profile


MAX_UPLOAD_ATTEMPTS = 3


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _record_collector_event(
    collector: Any | None,
    level: str,
    category: str,
    stage: str,
    message: str,
    *,
    context: dict[str, Any] | None = None,
    duration_ms: int | None = None,
) -> None:
    if collector is None:
        return
    emit = getattr(collector, level, None)
    if emit is None:
        return
    kwargs: dict[str, Any] = {"context": context or {}}
    if duration_ms is not None:
        kwargs["duration_ms"] = duration_ms
    emit(category, stage, message, **kwargs)


def _record_upload_attempt(
    collector: Any | None,
    *,
    level: str,
    stage: str,
    artifact: str,
    path: str,
    attempt: int,
    message: str,
    error: Exception | None = None,
    url: str | None = None,
    size_bytes: int | None = None,
    duration_ms: int | None = None,
) -> None:
    context: dict[str, Any] = {
        "artifact": artifact,
        "path": path,
        "attempt": attempt,
        "max_attempts": MAX_UPLOAD_ATTEMPTS,
    }
    if url:
        context["url"] = url
    if size_bytes is not None:
        context["size_bytes"] = size_bytes
    if error is not None:
        context["error"] = str(error)
    _record_collector_event(
        collector,
        level,
        "UPLOAD",
        stage,
        message,
        context=context,
        duration_ms=duration_ms,
    )


def _video_suffix(
    aspect_ratio: str,
    *,
    render_canvas_profile_name: str | None = None,
) -> str:
    profile = get_render_canvas_profile(
        aspect_ratio,
        profile_name=render_canvas_profile_name,
    )
    return (
        "_1080p.mp4"
        if max(profile.pixel_width, profile.pixel_height) >= 1920
        else "_720p.mp4"
    )


def _variant_path_component(variant: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z_-]+", "_", str(variant or "").strip())
    return cleaned.strip("_") or "variant"
