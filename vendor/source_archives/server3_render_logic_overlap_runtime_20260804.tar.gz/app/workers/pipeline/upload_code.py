"""Generated-code preparation and uploaded-file rollback helpers."""

import ast
import logging
import re
from typing import Any
from .upload_contracts import _record_collector_event, _ts

logger = logging.getLogger("render")


def _prepare_code_for_upload(code: str, collector: Any | None = None) -> str:
    current = str(code or "")
    if re.search(r"#\s*END\s*$", current.rstrip()):
        return current
    scene_names = re.findall(r"class\s+(Scene_\d+(?:_\w+)?)\s*\(", current)
    if _looks_structurally_complete_manim_code(current, scene_names=scene_names):
        fixed = current.rstrip() + "\n\n# END\n"
        logger.info(
            f"[UPLOAD] [{_ts()}] 已补齐 # END 标记（{len(scene_names)} scenes）"
        )
        _record_collector_event(
            collector,
            "info",
            "CODE_UPLOAD_PRECHECK",
            "END_MARKER_BACKFILLED",
            "代码结构完整，上传前已补齐 # END 标记",
            context={"scene_count": len(scene_names), "code_length": len(current)},
        )
        return fixed
    logger.warning(
        f"[UPLOAD] [{_ts()}] LLM 未输出 # END 标记，"
        f"代码可能被截断（{len(scene_names)} scenes）"
    )
    _record_collector_event(
        collector,
        "warning",
        "CODE_TRUNCATION",
        "CODE_UPLOAD_PRECHECK",
        "LLM 未输出 # END 标记，代码可能被截断",
        context={"scene_count": len(scene_names), "code_length": len(current)},
    )
    return current


def _looks_structurally_complete_manim_code(
    code: str,
    *,
    scene_names: list[str],
) -> bool:
    if not code.strip() or not scene_names:
        return False
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return False
    class_names = {
        node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)
    }
    if not any(name in class_names for name in scene_names):
        return False
    return True


async def _rollback_uploaded_files(
    video_url: str,
    code_url: str,
    extra_video_urls: list[str] | None = None,
    collector: Any | None = None,
) -> None:
    """回滚已上传的文件（当数据库更新失败时调用）"""
    from app.workers.pipeline import upload as upload_facade

    active_storage_service = upload_facade.storage_service
    logger.warning(f"[ROLLBACK] [{_ts()}] 开始回滚已上传文件...")
    try:
        for extra_url in extra_video_urls or []:
            if not extra_url or extra_url == video_url:
                continue
            await active_storage_service.delete_file(extra_url)
            logger.info(f"[ROLLBACK] [{_ts()}] ✓ 已删除额外视频: {extra_url}")
            _record_collector_event(
                collector,
                "info",
                "UPLOAD",
                "VIDEO_VARIANT_ROLLBACK",
                "数据库回写失败后已删除额外视频",
                context={"url": extra_url, "reason": "db_update_failed"},
            )
    except Exception as e:
        logger.warning(f"[ROLLBACK] [{_ts()}] 删除额外视频失败: {e}")
        _record_collector_event(
            collector,
            "error",
            "UPLOAD",
            "VIDEO_VARIANT_ROLLBACK",
            "数据库回写失败后删除额外视频失败",
            context={"reason": "db_update_failed", "error": str(e)},
        )

    try:
        if video_url:
            await active_storage_service.delete_file(video_url)
            logger.info(f"[ROLLBACK] [{_ts()}] ✓ 已删除视频: {video_url}")
            _record_collector_event(
                collector,
                "info",
                "UPLOAD",
                "VIDEO_ROLLBACK",
                "数据库回写失败后已删除视频",
                context={"url": video_url, "reason": "db_update_failed"},
            )
    except Exception as e:
        logger.warning(f"[ROLLBACK] [{_ts()}] 删除视频失败: {e}")
        _record_collector_event(
            collector,
            "error",
            "UPLOAD",
            "VIDEO_ROLLBACK",
            "数据库回写失败后删除视频失败",
            context={"url": video_url, "reason": "db_update_failed", "error": str(e)},
        )

    try:
        if code_url:
            await active_storage_service.delete_file(code_url)
            logger.info(f"[ROLLBACK] [{_ts()}] ✓ 已删除代码: {code_url}")
            _record_collector_event(
                collector,
                "info",
                "UPLOAD",
                "CODE_ROLLBACK",
                "数据库回写失败后已删除代码",
                context={"url": code_url, "reason": "db_update_failed"},
            )
    except Exception as e:
        logger.warning(f"[ROLLBACK] [{_ts()}] 删除代码失败: {e}")
        _record_collector_event(
            collector,
            "error",
            "UPLOAD",
            "CODE_ROLLBACK",
            "数据库回写失败后删除代码失败",
            context={"url": code_url, "reason": "db_update_failed", "error": str(e)},
        )
