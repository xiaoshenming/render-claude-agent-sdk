"""Shared AIGC video post-processing helpers."""

from __future__ import annotations

import logging
import json
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.core.config import settings
from app.services import ffmpeg_service

logger = logging.getLogger("render")

_DEFAULT_VISIBLE_WATERMARK = {
    "enabled": True,
    "legacy_watermark_enabled": True,
    "dual_upload_enabled": True,
    "display_variant": "watermarked",
    "image_path": "ai-hecheng-02-tech.png",
    "position": "bottom_right",
    "opacity": 0.86,
    "margin": 24,
    "scale_ratio": 0.085,
}


def _mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            value = {}
    return dict(value) if isinstance(value, dict) else {}


def _resolve_aigc_visible_watermark_config(
    task_data: dict[str, Any],
) -> dict[str, Any]:
    config = dict(_DEFAULT_VISIBLE_WATERMARK)
    config.update(_mapping(getattr(settings, "AIGC_VISIBLE_WATERMARK_CONFIG_JSON", "")))
    config.update(_mapping(task_data.get("aigc_visible_watermark")))
    if config.get("display_variant") not in {"watermarked", "clean"}:
        config["display_variant"] = "watermarked"
    for key, default in (
        ("enabled", True),
        ("legacy_watermark_enabled", True),
        ("dual_upload_enabled", True),
    ):
        value = config.get(key)
        config[key] = default if value is None else str(value).lower() in {
            "1", "true", "yes", "on"
        } if not isinstance(value, bool) else value
    if task_data.get("_enterprise_disable_all_watermarks"):
        config.update(
            enabled=False,
            legacy_watermark_enabled=False,
            dual_upload_enabled=False,
            display_variant="clean",
            enterprise_disable_all_watermarks=True,
        )
    return config


def _select_watermark_tmp_dir(task_data: dict[str, Any], fallback: str) -> str:
    final_path = str(task_data.get("_final_video_path") or "")
    return os.path.dirname(final_path) if final_path else fallback


def _build_aigc_metadata_context(
    task_data: dict[str, Any], *, user_id: str | None
) -> dict[str, str]:
    generated_at = task_data.get("generated_at") or task_data.get("created_at")
    if isinstance(generated_at, datetime):
        generated_at = generated_at.isoformat()
    return {
        "user_id": str(user_id or task_data.get("user_id") or "unknown-user"),
        "generated_at": str(
            generated_at or datetime.now().astimezone().isoformat(timespec="seconds")
        ),
        "content_type": "MP4",
    }


@dataclass(slots=True)
class AigcVideoVariants:
    display_video_bytes: bytes
    clean_video_bytes: bytes | None
    watermarked_video_bytes: bytes | None
    display_variant: str
    dual_upload_enabled: bool
    metadata_injected: bool
    visible_watermark_applied: bool


async def build_aigc_video_variants(
    video_bytes: bytes,
    task_data: dict[str, Any],
    *,
    job_id: str,
    user_id: str | None,
    job_output_dir: str,
    log_prefix: str = "[AIGC]",
) -> AigcVideoVariants:
    """Create metadata-clean and visible-watermarked variants from one final MP4."""

    aigc_visible_watermark = _resolve_aigc_visible_watermark_config(task_data)
    task_data["aigc_visible_watermark"] = aigc_visible_watermark
    aigc_display_variant = str(
        aigc_visible_watermark.get("display_variant") or "watermarked"
    )
    aigc_dual_upload_enabled = bool(
        aigc_visible_watermark.get("dual_upload_enabled", True)
    )

    clean_video_bytes: bytes | None = None
    watermarked_video_bytes: bytes | None = None

    metadata_tmp_dir = _select_watermark_tmp_dir(task_data, job_output_dir)
    metadata_context = _build_aigc_metadata_context(
        task_data,
        user_id=user_id,
    )
    task_data["aigc_metadata_input_bytes"] = len(video_bytes)
    task_data["aigc_metadata_tmp_dir"] = metadata_tmp_dir
    task_data["aigc_metadata_context"] = metadata_context
    try:
        logger.info("%s 开始写入 AIGC 隐性元数据: job=%s", log_prefix, job_id)
        clean_video_bytes = await ffmpeg_service.inject_aigc_metadata(
            video_bytes,
            metadata_tmp_dir,
            job_id,
            metadata_context,
        )
        task_data["aigc_metadata_output_bytes"] = len(clean_video_bytes)
        task_data["aigc_metadata_injected"] = True
        task_data["aigc_metadata_failed"] = False
    except Exception as exc:
        task_data["aigc_metadata_failed"] = True
        task_data["aigc_metadata_error"] = str(exc)[:500]
        task_data["last_error"] = f"AIGC隐性元数据写入失败: {exc}"
        task_data["_error_stage"] = "aigc_metadata"
        task_data["_error_type"] = "aigc_metadata_error"
        task_data["_non_retryable"] = True
        raise

    if aigc_visible_watermark.get("enabled", True):
        visible_tmp_dir = _select_watermark_tmp_dir(task_data, job_output_dir)
        task_data["aigc_visible_watermark_input_bytes"] = len(clean_video_bytes)
        task_data["aigc_visible_watermark_tmp_dir"] = visible_tmp_dir
        try:
            logger.info("%s 开始烧录 AIGC 显性图片水印: job=%s", log_prefix, job_id)
            watermarked_video_bytes = await ffmpeg_service.apply_aigc_visible_watermark(
                clean_video_bytes,
                visible_tmp_dir,
                job_id,
                aigc_visible_watermark,
            )
            task_data["aigc_visible_watermark_output_bytes"] = len(
                watermarked_video_bytes
            )
            task_data["aigc_visible_watermark_applied"] = True
            task_data["aigc_visible_watermark_failed"] = False
        except Exception as exc:
            task_data["aigc_visible_watermark_failed"] = True
            task_data["aigc_visible_watermark_error"] = str(exc)[:500]
            task_data["last_error"] = f"AIGC显性水印烧录失败: {exc}"
            task_data["_error_stage"] = "aigc_visible_watermark"
            task_data["_error_type"] = "aigc_visible_watermark_error"
            task_data["_non_retryable"] = True
            raise
    else:
        task_data["aigc_visible_watermark_applied"] = False
        task_data["aigc_visible_watermark_failed"] = False

    if aigc_display_variant == "clean" or not watermarked_video_bytes:
        display_video_bytes = clean_video_bytes
        aigc_display_variant = "clean"
    else:
        display_video_bytes = watermarked_video_bytes
        aigc_display_variant = "watermarked"

    task_data["aigc_display_variant"] = aigc_display_variant
    return AigcVideoVariants(
        display_video_bytes=display_video_bytes,
        clean_video_bytes=clean_video_bytes,
        watermarked_video_bytes=watermarked_video_bytes,
        display_variant=aigc_display_variant,
        dual_upload_enabled=aigc_dual_upload_enabled,
        metadata_injected=True,
        visible_watermark_applied=bool(
            task_data.get("aigc_visible_watermark_applied")
        ),
    )
