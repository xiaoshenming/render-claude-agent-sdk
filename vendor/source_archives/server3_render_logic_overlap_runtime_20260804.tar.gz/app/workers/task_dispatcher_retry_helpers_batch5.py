"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
async def handle_final_failure(
    ctx: DispatchContext,
    job_id: str, error_msg: str,
    refund_points: int = 0,
    error_type: Optional[str] = None,
    error_stage: Optional[str] = None,
    retry_count: int = 0,
    task_data: Optional[dict] = None,
    update_job_status_fn: Optional[Callable[..., Awaitable]] = None,
) -> str:
    """写最终失败状态。返回 changed / already_terminal / failed。"""
    from app.services.error_collector import classify_render_error

    quality_rejected = mark_quality_rejected(
        task_data,
        error_type=error_type,
        error_stage=error_stage,
        message=error_msg,
    )
    failure_attribution = _failure_attribution_payload(
        task_data,
        error_msg=error_msg,
        error_type=error_type,
        error_stage=error_stage,
    )
    if task_data is not None and failure_attribution:
        task_data["_failure_attribution"] = failure_attribution
    persisted_error_msg = _append_failure_attribution_to_error_message(
        error_msg,
        failure_attribution,
    )
    log_message = (
        f"[FINAL_FAIL] [{_ts()}] 任务最终失败 job_id={job_id}, "
        f"错误: {error_msg[:500] if error_msg else 'N/A'}"
    )
    if quality_rejected:
        logger.warning(
            "%s quality_rejected code=%s stage=%s",
            log_message,
            (task_data or {}).get("_quality_rejection_code"),
            error_stage,
            extra={
                "error_code": "quality_rejected",
                "error_stage": error_stage,
            },
        )
    else:
        logger.error(log_message)

    # 将最终失败信息记录到错误采集器（如果存在）
    _collector = task_data.get("_error_collector") if task_data else None
    if _collector:
        category = error_type or classify_render_error(error_msg or "")
        if quality_rejected:
            _collector.warning(
                category="QUALITY_REJECTED",
                stage=error_stage or "final_failure",
                message=f"[质量拦截] retry={retry_count}: {error_msg}",
                context={
                    "retry_count": retry_count,
                    "refund_points": refund_points,
                    "quality_rejection_code": task_data.get("_quality_rejection_code"),
                    "original_error_type": error_type,
                    "original_error_stage": error_stage,
                },
            )
        else:
            _collector.error(
                category=category,
                stage=error_stage or "final_failure",
                message=f"[最终失败] retry={retry_count}: {error_msg}",
                context={"retry_count": retry_count, "refund_points": refund_points},
            )
        try:
            await _collector.flush()
        except Exception:
            pass

    # 上传失败代码
    task_data = task_data or {}
    failed_code_url = None
    upload_kwargs = {"persist_job_url": False}
    fallback_code = _failed_code_fallback(task_data)
    if fallback_code:
        upload_kwargs["fallback_code"] = fallback_code
    scene_name = _failure_scene_name_from_task_data(task_data, error_msg=error_msg)
    upload_kwargs.update({
        "error_type": error_type,
        "error_stage": error_stage,
        "error_message": error_msg,
        "scene_name": scene_name,
        "attempt": retry_count,
    })
    failed_code_url = await job_repository.upload_failed_code(
        job_id, ctx.manim_media_root, **upload_kwargs,
    )

    # 提取渲染统计
    llm_fix_count = 0
    render_fix_count = 0
    _tk_total = _tk_input = _tk_output = 0
    _tk_cache_read = _tk_cache_create = 0
    if task_data:
        llm_fix_count = task_data.get("_llm_fix_count", 0)
        render_fix_count = task_data.get("_render_fix_count", 0)
        _tk_total = task_data.get("_total_tokens", 0)
        _tk_input = task_data.get("_input_tokens", 0)
        _tk_output = task_data.get("_output_tokens", 0)
        _tk_cache_read = task_data.get("_cache_read_tokens", 0)
        _tk_cache_create = task_data.get("_cache_creation_tokens", 0)
    pipeline_mode, slice_count = _failure_pipeline_fields(task_data)

    if update_job_status_fn:
        raw_result = await update_job_status_fn(
            job_id, "FAILED", persisted_error_msg,
            refund_points=refund_points,
            error_type=error_type, error_stage=error_stage,
            retry_count=retry_count,
            llm_fix_count=llm_fix_count,
            render_fix_count=render_fix_count,
            total_tokens=_tk_total, input_tokens=_tk_input,
            output_tokens=_tk_output,
            cache_read_tokens=_tk_cache_read,
            cache_creation_tokens=_tk_cache_create,
            failed_code_url=failed_code_url,
            pipeline_mode=pipeline_mode,
            slice_count=slice_count,
        )
        result = "changed" if raw_result is True else _final_failure_state(raw_result)
    else:
        from app.services import internal_api_client

        payload = {
            "error_message": persisted_error_msg or "",
            "refund_points": refund_points,
            "error_type": error_type,
            "error_stage": error_stage,
            "retry_count": retry_count,
            "failed_code_url": failed_code_url,
            "llm_fix_count": llm_fix_count,
            "render_fix_count": render_fix_count,
            "total_tokens": _tk_total,
            "input_tokens": _tk_input,
            "output_tokens": _tk_output,
            "cache_read_tokens": _tk_cache_read,
            "cache_creation_tokens": _tk_cache_create,
            "pipeline_mode": pipeline_mode,
            "slice_count": slice_count or 0,
        }
        api_result = await internal_api_client.complete_video_job_failure(
            job_id,
            payload,
        )
        if api_result is True or api_result == "changed":
            result = "changed"
        elif api_result is False or api_result == "already_terminal":
            result = "already_terminal"
        else:
            logger.error(
                f"[FINAL_FAIL] [{_ts()}] internal API 失败，Render 禁止直写业务库: "
                f"job_id={job_id}")
            result = "failed"
    if result == "failed":
        logger.error(
            f"[FINAL_FAIL] [{_ts()}] 写库失败，不ack消息，"
            f"等待重投: job_id={job_id}")
    elif result == "already_terminal":
        logger.warning(
            f"[FINAL_FAIL] [{_ts()}] 任务已是终态，直接 ack 防止重投风暴: "
            f"job_id={job_id}")
    return result
