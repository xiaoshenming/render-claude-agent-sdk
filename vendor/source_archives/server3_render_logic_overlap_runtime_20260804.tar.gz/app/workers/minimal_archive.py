"""成功产物归档：AIGC 标记、COS 上传和数据库回写。"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from app.services.title_service import generate_smart_title
from app.workers.aigc_postprocess import build_aigc_video_variants


@dataclass(frozen=True, slots=True)
class ArchiveResult:
    video_url: str
    code_url: str


async def archive_success(
    worker: Any,
    *,
    task_data: dict[str, Any],
    code: str,
    video_bytes: bytes,
    scene_names: list[str],
    slice_paths: list[str],
    original_prompt: str,
    cost: float,
) -> ArchiveResult:
    job_id = str(task_data["job_id"])
    user_id = str(task_data["user_id"])
    aspect_ratio = str(task_data.get("aspect_ratio") or "16:9")
    output_dir = os.path.join(worker.media_root, f"job_{job_id}")
    variants = await build_aigc_video_variants(
        video_bytes,
        task_data,
        job_id=job_id,
        user_id=user_id,
        job_output_dir=output_dir,
    )
    profile = str(task_data.get("render_canvas_profile_name") or "").strip() or None
    extra_urls: list[str] = []
    clean_url: str | None = None
    watermarked_url: str | None = None
    try:
        if (
            variants.dual_upload_enabled
            and variants.clean_video_bytes
            and variants.display_variant != "clean"
        ):
            clean_url = await worker._upload_video_variant(
                job_id,
                user_id,
                variants.clean_video_bytes,
                aspect_ratio=aspect_ratio,
                render_canvas_profile_name=profile,
                variant="aigc_clean",
            )
            extra_urls.append(clean_url)
        video_url, code_url = await worker._upload_results(
            job_id,
            user_id,
            variants.display_video_bytes,
            code,
            aspect_ratio=aspect_ratio,
            render_canvas_profile_name=profile,
        )
        if variants.display_variant == "clean":
            clean_url = video_url
        else:
            watermarked_url = video_url
        title = await generate_smart_title(
            original_prompt, fallback_code=code, job_id=job_id
        )
        written = await worker._update_database_success(
            job_id,
            user_id,
            video_url,
            code_url,
            cost,
            title,
            original_prompt,
            has_watermark=variants.visible_watermark_applied,
            aigc_clean_video_url=clean_url,
            aigc_watermarked_video_url=watermarked_url,
            aigc_display_variant=variants.display_variant,
            aigc_visible_watermark_applied=variants.visible_watermark_applied,
            aigc_metadata_injected=variants.metadata_injected,
            pipeline_mode="AGENT",
            slice_count=len(slice_paths),
            llm_fix_count=int(task_data.get("_llm_fix_count", 0) or 0),
            render_fix_count=int(task_data.get("_render_fix_count", 0) or 0),
            total_tokens=int(task_data.get("_total_tokens", 0) or 0),
            input_tokens=int(task_data.get("_input_tokens", 0) or 0),
            output_tokens=int(task_data.get("_output_tokens", 0) or 0),
            cache_read_tokens=int(task_data.get("_cache_read_tokens", 0) or 0),
            cache_creation_tokens=int(task_data.get("_cache_creation_tokens", 0) or 0),
            retry_count=int(task_data.get("retry_count", 0) or 0),
        )
        if not written:
            raise RuntimeError("成功状态被终态保护拒绝")
        if len(slice_paths) > 1:
            await worker._upload_and_register_slices(
                job_id, user_id, scene_names, slice_paths, code
            )
        return ArchiveResult(video_url=video_url, code_url=code_url)
    except Exception:
        await worker._rollback_uploaded_files(
            locals().get("video_url"), locals().get("code_url"), extra_urls
        )
        raise
