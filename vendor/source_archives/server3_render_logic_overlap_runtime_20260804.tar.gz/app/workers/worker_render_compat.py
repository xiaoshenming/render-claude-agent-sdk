"""Compatibility facade for container and slice rendering helpers."""

from types import SimpleNamespace
from typing import Any, Dict, Optional

from app.workers.pipeline.context import RenderContext
from app.workers.repair import slice_fixer
from app.workers.rendering import executor as render_executor
from app.workers import video_task_processor


class WorkerRenderCompatMixin:
    def _lock_path(self, container: str) -> str:
        return self.container_mgr._lock_path(container)

    def try_acquire_lock(self, container: str) -> bool:
        return self.container_mgr.try_acquire_lock(container)

    def release_lock(self, container: str) -> None:
        self.container_mgr.release_lock(container)

    async def _is_container_running(self, container: str) -> bool:
        return await self.container_mgr._is_container_running(container)

    async def _container_has_manim(self, container: str) -> bool:
        return await self.container_mgr._container_has_manim(container)

    async def select_idle_container(
        self, wait: bool = True, max_wait: Optional[int] = 600
    ) -> Optional[str]:
        return await self.container_mgr.select_idle_container(wait=wait, max_wait=max_wait)

    async def _render_in_container(
        self,
        container: str,
        job_id: str,
        script_path: str,
        class_name: Optional[str],
        job_output_dir: str,
        aspect_ratio: str = "16:9",
        timeout_sec: int = 900,
        task_data: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        return await render_executor.render_in_container(
            container,
            job_id,
            script_path,
            class_name,
            job_output_dir,
            aspect_ratio,
            timeout_sec,
            self.manim_media_root,
            self.media_root,
            task_data=task_data,
        )

    async def process_video_task(self, task_data: Dict[str, Any]) -> str:
        return await video_task_processor.process_video_task(self, task_data)

    def _build_render_context(self, job_id, task_data, aspect_ratio="16:9"):
        return RenderContext(
            job_id=job_id,
            task_data=task_data,
            manim_media_root=self.manim_media_root,
            media_root=self.media_root,
            cache_dir=self.cache_dir,
            container_mgr=self.container_mgr,
            aspect_ratio=aspect_ratio,
            is_job_cancelled=self._is_job_cancelled,
        )

    async def _retry_failed_slice(
        self,
        job_id: str,
        script_path: str,
        scene_name: str,
        slices_dir: str,
        aspect_ratio: str = "16:9",
        timeout_sec: int = 900,
        last_error: str = "",
        max_retries: int = 3,
        task_data: Optional[Dict[str, Any]] = None,
    ):
        container_mgr = getattr(
            self,
            "container_mgr",
            SimpleNamespace(
                select_idle_container=self.select_idle_container,
                release_lock=self.release_lock,
            ),
        )
        ctx = RenderContext(
            job_id=job_id,
            task_data=task_data or {},
            manim_media_root=self.manim_media_root,
            media_root=self.media_root,
            cache_dir=self.cache_dir,
            container_mgr=container_mgr,
            aspect_ratio=aspect_ratio,
            is_job_cancelled=self._is_job_cancelled,
        )
        ctx.render_in_container_fn = self._render_in_container
        return await slice_fixer.retry_failed_slice(
            ctx,
            script_path=script_path,
            scene_name=scene_name,
            slices_dir=slices_dir,
            timeout_sec=timeout_sec,
            last_error=last_error,
            max_retries=max_retries,
            task_data=task_data,
        )
