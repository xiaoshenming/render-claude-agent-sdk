"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
def _strip_non_serializable(task_data: Dict[str, Any]) -> Dict[str, Any]:
    """剥离不可 JSON 序列化的运行时对象，保留可重试的纯数据。"""
    # 以 _ 开头的内部键多为运行时对象（ErrorCollector 等），重试时需要重建
    skip_keys = {
        "_error_collector", "_streaming_done", "_code", "_cost",
        "_final_video_path", "_quality_case_collectors",
    }
    serializable: Dict[str, Any] = {}
    for key, value in task_data.items():
        if key in skip_keys:
            continue
        try:
            json.dumps(value)
        except (TypeError, ValueError):
            logger.warning(
                "[RETRY] [%s] 丢弃不可序列化任务字段: key=%s type=%s",
                _ts(), key, type(value).__name__,
            )
            continue
        serializable[key] = value
    return serializable
def _without_none(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}
def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
def _normalize_job_status(status: Any) -> str | None:
    if status is None:
        return None
    normalized = str(status).strip().upper()
    return normalized or None
def _is_terminal_job_status(status: Any) -> bool:
    normalized = _normalize_job_status(status)
    return bool(normalized and normalized not in _ACTIVE_JOB_STATUSES)
def _failure_pipeline_fields(
    task_data: Optional[Dict[str, Any]],
) -> tuple[str | None, int | None]:
    if not task_data:
        return None, None

    explicit_mode = task_data.get("pipeline_mode")
    explicit_slice_count = task_data.get("slice_count")
    if explicit_mode:
        return str(explicit_mode), _safe_int(explicit_slice_count, 0)

    scene_contracts = task_data.get("scene_contracts")
    if isinstance(scene_contracts, list) and scene_contracts:
        return "PLANNING", len(scene_contracts)

    planning_json = task_data.get("planning_json")
    if isinstance(planning_json, dict):
        scenes = planning_json.get("scenes")
        if isinstance(scenes, list) and scenes:
            return "PLANNING", len(scenes)

    if (
        task_data.get("auto_planning")
        and (
            task_data.get("_auto_planning_attempted")
            or task_data.get("_auto_planning_error")
            or task_data.get("_auto_planning_error_details")
        )
    ):
        return "PLANNING", 0

    return None, None
def _json_safe_failure_value(
    value: Any,
    *,
    max_string: int = 500,
    max_items: int = 10,
    depth: int = 0,
) -> Any:
    if depth >= 4:
        return str(value)[:max_string]
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        return value[:max_string]
    if isinstance(value, dict):
        safe: Dict[str, Any] = {}
        for idx, (key, item) in enumerate(value.items()):
            if idx >= max_items:
                break
            safe[str(key)[:120]] = _json_safe_failure_value(
                item,
                max_string=max_string,
                max_items=max_items,
                depth=depth + 1,
            )
        return safe
    if isinstance(value, (list, tuple, set)):
        return [
            _json_safe_failure_value(
                item,
                max_string=max_string,
                max_items=max_items,
                depth=depth + 1,
            )
            for item in list(value)[:max_items]
        ]
    try:
        json.dumps(value, ensure_ascii=False)
        return value
    except (TypeError, ValueError):
        return str(value)[:max_string]
def _failure_signature_payload(value: Any) -> Dict[str, Any] | None:
    if not value:
        return None
    if isinstance(value, dict):
        payload = _json_safe_failure_value(value)
        return payload if isinstance(payload, dict) and payload else None
    return {"signature": str(value)[:500]}
def _repair_signature_counts_payload(value: Any) -> Dict[str, Any] | None:
    if not isinstance(value, dict) or not value:
        return None
    payload: Dict[str, Any] = {}
    for scene_name, scene_counts in list(value.items())[:20]:
        scene_key = str(scene_name)[:120]
        if isinstance(scene_counts, dict):
            sorted_counts = sorted(
                scene_counts.items(),
                key=lambda item: _safe_int(item[1], 0),
                reverse=True,
            )
            counts_payload = {
                str(signature)[:500]: _safe_int(count, 0)
                for signature, count in sorted_counts[:10]
            }
            if counts_payload:
                payload[scene_key] = counts_payload
        else:
            payload[scene_key] = _json_safe_failure_value(scene_counts)
    return payload or None
def _layout_repair_failed_events_payload(value: Any) -> list[dict[str, Any]] | None:
    if not isinstance(value, list):
        return None
    failed_events: list[dict[str, Any]] = []
    for event in value:
        if not isinstance(event, dict) or event.get("status") != "repair_failed":
            continue
        failed_events.append(
            _without_none(
                {
                    "scene_name": event.get("scene_name"),
                    "method": event.get("method"),
                    "issue_count": event.get("issue_count"),
                    "error": event.get("error"),
                    "residual_issue_top3": _json_safe_failure_value(
                        event.get("residual_issue_top3"),
                        max_items=3,
                    ),
                    "quantified_closure": _json_safe_failure_value(
                        event.get("quantified_closure"),
                    ),
                }
            )
        )
    return failed_events[-3:] or None
