"""Secondary-modification task orchestration."""

import logging
import os
import time
from datetime import datetime
from typing import Any

from app.core.config import settings
from app.services import modify_repository
from app.workers.modify import worker as modify_worker
from app.workers.modify.worker import ModifyContext
from app.workers.quality_rejection import mark_quality_rejected

logger = logging.getLogger(__name__)
_WORKER_RESULTS = {"success", "failed", "skipped"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def modify_graph_worker_result(state: Any) -> str:
    if not isinstance(state, dict):
        return "failed"
    metadata = state.get("metadata")
    if isinstance(metadata, dict) and metadata.get("worker_result") in _WORKER_RESULTS:
        return str(metadata["worker_result"])
    final_status = state.get("final_status")
    if final_status == "success":
        return "success"
    if final_status in {"failed", "degraded"}:
        return "failed"
    return "skipped"


def record_modify_graph_failure(task_data: dict, *, error_type: str, message: str) -> None:
    task_data["_error_stage"] = task_data.get("_error_stage") or "modify_state_graph"
    task_data["_error_type"] = task_data.get("_error_type") or error_type
    task_data["last_error"] = task_data.get("last_error") or message
    mark_quality_rejected(
        task_data, error_type=task_data.get("_error_type"),
        error_stage=task_data.get("_error_stage"), message=message,
    )


def should_preserve_modify_graph_artifacts(task_data: dict) -> bool:
    return bool(task_data.get("_preserve_local_artifacts"))


class WorkerModifyTaskMixin:
    async def process_modify_task(self, task_data: dict) -> str:
        job_id = task_data.get("job_id")
        user_id = task_data.get("user_id")
        aspect_ratio = task_data.get("aspect_ratio", "16:9")
        task_start_time = time.time()
        for key, default in (
            ("_non_retryable", False), ("_error_stage", None),
            ("_error_type", None), ("_total_tokens", 0),
            ("_input_tokens", 0), ("_output_tokens", 0),
            ("_cache_read_tokens", 0), ("_cache_creation_tokens", 0),
            ("_llm_fix_count", 0), ("_render_fix_count", 0),
        ):
            task_data.setdefault(key, default)
        retry_count = int(task_data.get("retry_count") or 0)
        if (
            job_id and (retry_count > 0 or task_data.get("_rabbitmq_redelivered"))
            and await self._is_job_cancelled(job_id)
        ):
            logger.info("[MODIFY] [%s] 重投前发现 job %s 已终态，skip", _ts(), job_id)
            return "skipped"
        if task_data.get("_rabbitmq_redelivered"):
            task_data.setdefault("_modify_checkpoint_resume_requested", True)

        source_slices = task_data.get("source_slices") or []
        source_job_id = task_data.get("source_job_id")
        if not source_slices and source_job_id:
            source_slices = await modify_repository.get_job_source_slices(source_job_id)
            task_data["source_slices"] = source_slices
            logger.info(
                "[MODIFY] [%s] source_slices loaded from DB: source_job_id=%s, count=%s",
                _ts(), source_job_id, len(source_slices),
            )
        ctx = ModifyContext(
            job_id=job_id, user_id=user_id,
            job_script_dir=os.path.join(self.manim_media_root, f"job_{job_id}"),
            job_output_dir=os.path.join(self.media_root, f"job_{job_id}"),
            aspect_ratio=aspect_ratio,
            source_map={item["slice_index"]: item for item in source_slices},
            task_data=task_data, container_mgr=self.container_mgr,
            manim_media_root=self.manim_media_root, media_root=self.media_root,
            job_timeout=settings.FINAL_RENDER_TIMEOUT, task_start_time=task_start_time,
            is_job_cancelled_fn=self._is_job_cancelled,
            upload_results_fn=self._upload_results,
            upload_video_variant_fn=self._upload_video_variant,
            handle_final_failure_fn=self._handle_final_failure,
            cleanup_fn=self._cleanup_job_folder,
        )
        if not getattr(settings, "USE_MODIFY_AGENT_PIPELINE", False):
            return await modify_worker.process_modify_task(ctx)
        try:
            from app.agents.modify_graph import run_modify_state_graph
            task_data["_modify_agent_observed"] = True
            graph_state = await run_modify_state_graph(ctx)
        except Exception as exc:
            message = f"ModifyStateGraph failed: {exc}"
            record_modify_graph_failure(
                task_data, error_type=type(exc).__name__, message=message,
            )
            logger.exception("[MODIFY] [%s] ModifyStateGraph 主执行失败: %s", _ts(), exc)
            if should_preserve_modify_graph_artifacts(task_data):
                logger.warning(
                    "[MODIFY] [%s] Preserve local artifacts: reason=%s output=%s script=%s",
                    _ts(), task_data.get("_preserve_local_artifacts_reason"),
                    ctx.job_output_dir, ctx.job_script_dir,
                )
            else:
                self._cleanup_job_folder(ctx.job_output_dir, ctx.job_script_dir)
            return "failed"
        result = modify_graph_worker_result(graph_state)
        if result == "failed":
            reason = graph_state.get("failure_reason") or (
                graph_state.get("metadata") or {}
            ).get("failure_reason") or "ModifyStateGraph returned failed"
            record_modify_graph_failure(
                task_data, error_type="ModifyStateGraphFailed", message=str(reason),
            )
        return result
