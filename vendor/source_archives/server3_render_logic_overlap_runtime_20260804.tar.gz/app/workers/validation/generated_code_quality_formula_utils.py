import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _formula_move_to_assignments(
    source: str,
    line_offset: int,
) -> list[tuple[str, str, int]]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _formula_move_to_assignments_regex(source, line_offset)

    formulas: list[tuple[str, str, int]] = []
    for node in ast.walk(tree):
        if (
            not isinstance(node, ast.Assign)
            or len(node.targets) != 1
            or not isinstance(node.targets[0], ast.Name)
        ):
            continue
        value = node.value
        if (
            not isinstance(value, ast.Call)
            or not isinstance(value.func, ast.Attribute)
            or value.func.attr != "move_to"
            or not value.args
            or _call_chain_root_name(value.func.value) != "MathTex"
        ):
            continue
        formulas.append(
            (
                node.targets[0].id,
                _normalize_expr(ast.unparse(value.args[0])),
                line_offset + getattr(node, "lineno", 0),
            )
        )
    return formulas


def _formula_move_to_assignments_regex(
    source: str,
    line_offset: int,
) -> list[tuple[str, str, int]]:
    formulas: list[tuple[str, str, int]] = []
    for match in re.finditer(
        r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*MathTex\s*\(.*?\)\.move_to\s*\(([^)\n]+)\)",
        source,
        re.M,
    ):
        formulas.append(
            (
                match.group(1),
                _normalize_expr(match.group(2)),
                line_offset + _line_no(source, match.start()),
            )
        )
    return formulas


def _call_chain_root_name(node: ast.AST) -> str:
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Attribute):
            return _call_chain_root_name(node.func.value)
        return _call_name(node.func)
    if isinstance(node, ast.Attribute):
        return _call_chain_root_name(node.value)
    return ""


def _normalize_expr(expr: str) -> str:
    return re.sub(r"\s+", " ", expr.strip())


def _formula_transition_segment(source: str, show_pos: int, later_show_pos: int) -> str:
    statement_end = source.find("\n", later_show_pos)
    if statement_end == -1:
        statement_end = min(len(source), later_show_pos + 500)
    return source[show_pos:statement_end]


def _formula_replaced_or_removed(segment: str, old_var: str, new_var: str) -> bool:
    faded_vars = {
        match.group("var")
        for match in re.finditer(
            r"FadeOut\s*\(\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\b",
            segment,
        )
    }
    if old_var in faded_vars:
        return True

    edges: dict[str, set[str]] = {}
    for match in re.finditer(
        r"(?:ReplacementTransform|Transform|TransformMatchingTex)\s*"
        r"\(\s*(?P<src>[A-Za-z_][A-Za-z0-9_]*)(?:\.copy\(\))?\b"
        r"[^,\n]*,\s*(?P<dst>[A-Za-z_][A-Za-z0-9_]*)\b",
        segment,
    ):
        edges.setdefault(match.group("src"), set()).add(match.group("dst"))

    seen: set[str] = set()
    stack = [old_var]
    while stack:
        current = stack.pop()
        if current in seen:
            continue
        seen.add(current)
        if current in faded_vars:
            return True
        for next_var in edges.get(current, set()):
            if next_var == new_var:
                return True
            stack.append(next_var)
    return False


def _scene_blocks(source: str) -> list[tuple[str, int]]:
    matches = list(re.finditer(r"(?m)^class\s+Scene_[A-Za-z0-9_]*\b.*:", source))
    blocks: list[tuple[str, int]] = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(source)
        blocks.append((source[match.start():end], _line_no(source, match.start()) - 1))
    return blocks


def _is_reassigned_before_direct_show(source: str, var: str, assign_pos: int) -> bool:
    show_pos = _direct_show_pos(source, var)
    if show_pos < 0:
        return False
    search_start = source.find("\n", assign_pos)
    if search_start < 0 or search_start >= show_pos:
        return False
    reassignment = re.search(
        rf"(?m)^\s*{re.escape(var)}\s*=",
        source[search_start + 1:show_pos],
    )
    return reassignment is not None


def _direct_show_pos(source: str, var: str) -> int:
    name = re.escape(var)
    patterns = [
        rf"self\.add\s*\([^)]*\b{name}\b",
        rf"self\.play\s*\([^\n]*"
        rf"(?:FadeIn|Write|Create|ReplacementTransform|Transform|TransformFromCopy)"
        rf"\s*\([^)\n]*\b{name}\b",
    ]
    positions = [
        match.start()
        for pattern in patterns
        for match in [re.search(pattern, source, re.S)]
        if match
    ]
    return min(positions) if positions else -1



def _first_line(source: str, needle: str) -> int:
    pos = source.find(needle)
    return _line_no(source, pos) if pos >= 0 else 0


def _line_matching(source: str, pattern: str) -> int:
    match = re.search(pattern, source)
    return _line_no(source, match.start()) if match else 0


def _line_no(source: str, pos: int) -> int:
    return source.count("\n", 0, max(pos, 0)) + 1


def _line_text(source: str, line_no: int) -> str:
    lines = source.splitlines()
    if 1 <= line_no <= len(lines):
        return lines[line_no - 1]
    return ""
