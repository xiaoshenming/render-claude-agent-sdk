"""Stable lanes, grades, issue-code sets, and result contracts."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

class RepairLane(str, Enum):
    RENDER_REPAIR = "render_repair"
    MATH_LOGIC_REPAIR = "math_logic_repair"
    LAYOUT_REPAIR = "layout_repair"


class RepairGrade(str, Enum):
    PASS = "PASS"
    NEEDS_REPAIR = "NEEDS_REPAIR"
    DEGRADED = "DEGRADED"
    FAILED = "FAILED"


RepairOutcome = RepairGrade

RENDER_REPAIR = RepairLane.RENDER_REPAIR.value
MATH_LOGIC_REPAIR = RepairLane.MATH_LOGIC_REPAIR.value
LAYOUT_REPAIR = RepairLane.LAYOUT_REPAIR.value

PASS = RepairGrade.PASS.value
NEEDS_REPAIR = RepairGrade.NEEDS_REPAIR.value
DEGRADED = RepairGrade.DEGRADED.value
FAILED = RepairGrade.FAILED.value

_GRADE_RANK = {
    RepairGrade.PASS: 0,
    RepairGrade.DEGRADED: 1,
    RepairGrade.NEEDS_REPAIR: 2,
    RepairGrade.FAILED: 3,
}

_MATH_HARD_ERROR_CODES = {
    "condition_error",
    "cut_fill_shape_deformation",
    "final_answer_error",
    "formula_error",
    "geometry_relation_error",
    "missing_condition",
    "missing_subquestion",
    "reasoning_step_error",
    "symbol_binding_error",
}

_LAYOUT_ERROR_CODES = {
    "layout_container_overflow",
    "layout_frame_overflow",
    "layout_overlap_error",
}

_LAYOUT_RISK_CODES = {
    "layout_container_border_overlap",
    "layout_overlap_risk",
}

_RENDER_FAILURE_CODES = {
    "container_render_failed",
    "docker_render_failed",
    "ffmpeg_failed",
    "manim_render_failed",
    "render_failed",
    "static_syntax_error",
    "static_undefined_name",
    "syntax_error",
}


@dataclass(frozen=True)
class QualityRepairClassification:
    lane: RepairLane
    grade: RepairGrade
    issues: tuple[dict[str, Any], ...]
    reason: str = ""

    @property
    def outcome(self) -> RepairGrade:
        return self.grade

    @property
    def needs_repair(self) -> bool:
        return self.grade is RepairGrade.NEEDS_REPAIR

    @property
    def failed(self) -> bool:
        return self.grade is RepairGrade.FAILED

    @property
    def degraded(self) -> bool:
        return self.grade is RepairGrade.DEGRADED

    def to_dict(self) -> dict[str, Any]:
        return {
            "lane": self.lane.value,
            "grade": self.grade.value,
            "outcome": self.outcome.value,
            "issues": list(self.issues),
            "needs_repair": self.needs_repair,
            "failed": self.failed,
            "degraded": self.degraded,
            "reason": self.reason,
        }
