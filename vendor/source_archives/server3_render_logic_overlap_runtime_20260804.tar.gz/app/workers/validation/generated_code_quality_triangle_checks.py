"""Right-triangle semantic checks extracted from inspection."""

from app.workers.validation.generated_code_quality_helpers import (
    _ambiguous_right_angle_helper_line,
    _right_triangle_numeric_side_label_mismatch_issues,
    _right_triangle_side_label_anchor_line,
    _pythagorean_three_square_semantic_issues,
)
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue


def _append_triangle_quality_issues(source, issues):
    line = _right_triangle_side_label_anchor_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(
            code="right_triangle_side_label_anchor", severity="error",
            message="直角三角形边标签使用单顶点方向偏移，容易把 a/b/c 标到三角形外侧或错误边；应绑定到对应边的两端点中点加外法线。",
            line=line, evidence="side label anchored from one vertex; use (P + Q) / 2 + outside normal",
        ))
    line = _ambiguous_right_angle_helper_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(
            code="ambiguous_right_angle_helper", severity="error",
            message="get_right_angle_mark 的参数顺序有歧义，容易把直角标在错误顶点；应使用真正的 right-angle vertex。",
            line=line, evidence="replace get_right_angle_mark(...) with create_right_angle_mark(vertex, ...)",
            failure_code="ambiguous_right_angle_helper",
        ))
    issues.extend(_right_triangle_numeric_side_label_mismatch_issues(source))
    issues.extend(_pythagorean_three_square_semantic_issues(source))
    return issues
