"""Math logic AST 纯辅助。"""
from __future__ import annotations
import ast
import re

def _integer_assignments(tree: ast.AST) -> dict[str, int]:
    constants: dict[str, int] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        value = _eval_int_expr(node.value, constants)
        if value is not None:
            constants[target.id] = value
    return constants

def _for_loop_builds_target_sector_strip(
    node: ast.For,
    *,
    constants: dict[str, int],
    source: str,
) -> bool:
    count = _range_count(node.iter, constants)
    if count is not None and count < 8:
        return False
    segment = ast.get_source_segment(source, node) or ""
    if "Sector(" not in segment or "AnnularSector(" in segment:
        return False
    if not _loop_has_mod2_branch(node):
        return False
    if not _loop_adds_to_target_group(node):
        return False
    return True

def _range_count(iter_node: ast.AST, constants: dict[str, int]) -> int | None:
    if not isinstance(iter_node, ast.Call):
        return None
    func = iter_node.func
    if not isinstance(func, ast.Name) or func.id != "range" or not iter_node.args:
        return None
    if len(iter_node.args) == 1:
        return _eval_int_expr(iter_node.args[0], constants)
    start = _eval_int_expr(iter_node.args[0], constants)
    stop = _eval_int_expr(iter_node.args[1], constants)
    step = _eval_int_expr(iter_node.args[2], constants) if len(iter_node.args) >= 3 else 1
    if start is None or stop is None or step in (None, 0):
        return None
    return max(0, (stop - start + (step - 1 if step > 0 else step + 1)) // step)

def _eval_int_expr(node: ast.AST, constants: dict[str, int]) -> int | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, int):
        return int(node.value)
    if isinstance(node, ast.Name):
        return constants.get(node.id)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        value = _eval_int_expr(node.operand, constants)
        return -value if value is not None else None
    if isinstance(node, ast.BinOp):
        left = _eval_int_expr(node.left, constants)
        right = _eval_int_expr(node.right, constants)
        if left is None or right is None:
            return None
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.FloorDiv) and right:
            return left // right
    return None

def _loop_has_mod2_branch(node: ast.For) -> bool:
    for child in ast.walk(node):
        if isinstance(child, ast.BinOp) and isinstance(child.op, ast.Mod):
            right = _eval_int_expr(child.right, {})
            if right == 2:
                return True
    return False

def _loop_adds_to_target_group(node: ast.For) -> bool:
    for child in ast.walk(node):
        if not isinstance(child, ast.Call):
            continue
        func = child.func
        if not isinstance(func, ast.Attribute) or func.attr != "add":
            continue
        group_name = _name_of(func.value)
        if group_name and re.search(r"(target|rearranged|strip|rect)", group_name, re.I):
            return True
    return False

def _has_call_named(tree: ast.AST, names: set[str]) -> bool:
    return any(_call_name(node) in names for node in ast.walk(tree) if isinstance(node, ast.Call))

def _call_name(node: ast.Call) -> str:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""

def _name_of(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _name_of(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    return ""

