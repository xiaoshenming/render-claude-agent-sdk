import ast
import re

def _call_receiver_name(func: ast.AST) -> str:
    if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
        return func.value.id
    return ""


def _assigned_text_vars(source: str) -> dict[str, int]:
    return {var: line for var, (line, _pos) in _assigned_text_assignments(source).items()}


def _default_manim_color_constant_line(source: str) -> int:
    match = _DEFAULT_COLOR_KW_RE.search(source)
    return _line_no(source, match.start()) if match else 0


def _gtts_voiceover_provider_line(source: str) -> int:
    for needle in (
        "manim_voiceover.services.gtts",
        "GTTSService",
        "GTSService",
        "manim_voiceover.services.recorder",
        "RecorderService",
        "manim_voiceover.services.stub",
        "StubService",
        "manim_voiceover.services.dummy",
        "DummyService",
    ):
        pos = source.find(needle)
        if pos >= 0:
            return _line_no(source, pos)
    return 0


_TUPLE_TEXT_LITERAL_RE = re.compile(r"^\(\s*(['\"])text\1(?:\s*,|\s*\))")


def _call_uses_up_direction(node: ast.Call) -> bool:
    return bool(node.args and _normalize_expr(ast.unparse(node.args[0])) == "UP")


def _base_name(base: ast.AST) -> str:
    if isinstance(base, ast.Name):
        return base.id
    if isinstance(base, ast.Attribute):
        prefix = _base_name(base.value)
        return f"{prefix}.{base.attr}" if prefix else base.attr
    if isinstance(base, ast.Call):
        return _base_name(base.func)
    return ""


def _stale_geometry_points_after_transform_line(source: str) -> int:
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    for block, line_offset in blocks:
        line = _stale_geometry_points_after_transform_line_in_block(block, line_offset)
        if line:
            return line
    return 0


def _is_self_voiceover_call(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "voiceover"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _is_name(node: ast.AST, name: str) -> bool:
    return isinstance(node, ast.Name) and node.id == name

