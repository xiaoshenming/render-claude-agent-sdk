import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _assigned_text_assignments(source: str) -> dict[str, tuple[int, int]]:
    return {
        match.group(1): (_line_no(source, match.start()), match.start())
        for match in _TEXT_ASSIGN_RE.finditer(source)
    }


def _registered_3d_text_var_positions(source: str) -> dict[str, int]:
    registered: dict[str, int] = {}
    group_members = _vgroup_members(source)
    for match in re.finditer(
        r"add_fixed_(?:in_frame|orientation)_mobjects\s*\(([^)]*)\)",
        source,
    ):
        for var in re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", match.group(1)):
            _record_earliest_pos(registered, var, match.start())
            for member in _expand_group_members(var, group_members):
                _record_earliest_pos(registered, member, match.start())
    return registered


def _record_earliest_pos(positions: dict[str, int], var: str, pos: int) -> None:
    previous = positions.get(var)
    if previous is None or pos < previous:
        positions[var] = pos


def _expand_group_members(var: str, group_members: dict[str, set[str]]) -> set[str]:
    expanded: set[str] = set()
    stack = list(group_members.get(var, set()))
    while stack:
        member = stack.pop()
        if member in expanded:
            continue
        expanded.add(member)
        stack.extend(group_members.get(member, set()))
    return expanded


def _vgroup_members(source: str) -> dict[str, set[str]]:
    groups: dict[str, set[str]] = {}
    for match in re.finditer(
        r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*VGroup\s*\(([^)]*)\)",
        source,
        re.M,
    ):
        groups.setdefault(match.group(1), set()).update(
            re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", match.group(2))
        )
    for match in re.finditer(
        r"^\s*([A-Za-z_][A-Za-z0-9_]*)\.add\s*\(([^)]*)\)",
        source,
        re.M,
    ):
        groups.setdefault(match.group(1), set()).update(
            re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", match.group(2))
        )
    return groups


