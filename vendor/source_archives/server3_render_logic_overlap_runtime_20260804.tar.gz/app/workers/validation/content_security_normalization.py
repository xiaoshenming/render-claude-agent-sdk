"""String candidate normalization for content-security review."""
import ast
import re

from .content_security_contracts import (
 _CJK_RE, _COMMON_FONT_NAMES, _FILELIKE_RE, _HEX_COLOR_RE,
 _SIMPLE_TECH_TOKEN_RE, _StringFragment,
)

def _extract_strings_with_regex(code: str) -> list[_StringFragment]:
    fragments: list[_StringFragment] = []
    patterns = [
        r'"""([\s\S]*?)"""',
        r"'''([\s\S]*?)'''",
        r'"([^"\\]*(?:\\.[^"\\]*)*)"',
        r"'([^'\\]*(?:\\.[^'\\]*)*)'",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, code):
            text = _normalize_candidate(match.group(1))
            if not _is_reviewable_text(text):
                continue
            lineno = code.count("\n", 0, match.start()) + 1
            fragments.append(_StringFragment(
                text=text,
                lineno=lineno,
                col_offset=match.start() - code.rfind("\n", 0, match.start()) - 1,
                end_lineno=lineno,
            ))
    return sorted(fragments, key=lambda item: (item.lineno, item.col_offset))


def _docstring_value_node_ids(tree: ast.AST) -> set[int]:
    ignored: set[int] = set()
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        body = getattr(node, "body", None) or []
        first = body[0] if body else None
        value = getattr(first, "value", None)
        if isinstance(first, ast.Expr) and isinstance(value, ast.Constant) and isinstance(value.value, str):
            ignored.add(id(value))
    return ignored


def _normalize_candidate(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _is_reviewable_text(text: str) -> bool:
    if len(text) < 2 and not _CJK_RE.search(text):
        return False
    lowered = text.lower()
    if lowered in _COMMON_FONT_NAMES:
        return False
    if _HEX_COLOR_RE.match(text):
        return False
    if text.startswith(("http://", "https://", "cos://", "s3://")):
        return False
    if "/" in text or "\\" in text:
        if _FILELIKE_RE.search(text) or text.startswith((".", "/", "~")):
            return False
    if _FILELIKE_RE.search(text):
        return False
    if not _CJK_RE.search(text) and _SIMPLE_TECH_TOKEN_RE.match(text):
        return False
    if not re.search(r"[\w\u4e00-\u9fff]", text):
        return False
    return True


def _merge_adjacent_cjk_fragments(fragments: list[_StringFragment]) -> list[str]:
    merged: list[str] = []
    current: list[_StringFragment] = []

    def flush() -> None:
        if len(current) < 2:
            current.clear()
            return
        text = "".join(item.text for item in current)
        if len(text) >= 4:
            merged.append(text)
        current.clear()

    for fragment in fragments:
        if not _is_short_cjk_fragment(fragment.text):
            flush()
            continue
        if current and not _is_close_to_previous(current[-1], fragment):
            flush()
        current.append(fragment)
    flush()
    return merged


def _is_short_cjk_fragment(text: str) -> bool:
    return len(text) <= 12 and bool(_CJK_RE.search(text))


def _is_close_to_previous(prev: _StringFragment, current: _StringFragment) -> bool:
    return current.lineno - prev.end_lineno <= 2


def _dedupe_preserve_order(strings: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in strings:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result
