"""公式文本匹配模式。"""
from __future__ import annotations

import re


def formula_match_patterns() -> tuple[re.Pattern[str], ...]:
     return (
         re.compile(
             r"(?<![A-Za-z0-9])(?:[A-Za-z]+_\{[\u4e00-\u9fffA-Za-z0-9]{1,8}\})"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:\(-?[A-Z][A-Za-z0-9₀₁₂₃₄₅₆₇₈₉]*"
             r"(?:-[A-Z][A-Za-z0-9₀₁₂₃₄₅₆₇₈₉]*)+-?\))(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?=[A-Z][A-Za-z0-9₀₁₂₃₄₅₆₇₈₉]*"
             r"[0-9₀₁₂₃₄₅₆₇₈₉])(?:[A-Z][a-z]?[0-9₀₁₂₃₄₅₆₇₈₉]*){2,}"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[=≈<>≤≥]?\s*"
             r"[\u4e00-\u9fffA-Za-z0-9_{}^ ]+"
             r"\\(?:times|cdot|frac|sqrt)"
             r"[\u4e00-\u9fffA-Za-z0-9_{}^\\ +*/-]*)"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[A-Za-z](?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079]))"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:\d+\s*[A-Za-z])(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:\d+(?:\.\d+)?\s*[μA-Za-z]{1,4}"
             r"\s*=\s*\?\s*[μA-Za-z]{1,4})"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<=[(（])\s*[A-Za-z][₀₁₂₃₄₅₆₇₈₉]+(?=\s*[)）])"
         ),
         re.compile(
             r"(?<=[(（])\s*\d+(?:\.\d+)?"
             r"(?:\s*[×*/+\-]\s*\d+(?:\.\d+)?)+"
             r"\s*(?=[)）])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:\d+(?:\.\d+)?\s*[πΠ]\s*"
             r"[A-Za-z]{1,4}(?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?"
             r"[A-Za-z]{0,3})"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[A-Za-z]\s*=\s*√\s*"
             r"(?:\([^()]+\)|[A-Za-z0-9αβγθλμσφΩπΠΔδ]+)"
             r"(?:\s*[+\-]\s*\d+)?)"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[A-Za-z]{1,4}"
             r"[\u00b2\u00b3\u00b9\u2070-\u2079]"
             r"(?:\s*[,，、]\s*[A-Za-z]{1,4}"
             r"[\u00b2\u00b3\u00b9\u2070-\u2079])+)"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<=[(（])\s*[A-Za-z](?=\s*[\u4e00-\u9fff])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:\d+\s*/\s*\d+\s*(?:=\s*\d+\s*/\s*\d+\s*)+)"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[A-Z]{1,3}'?\s*=\s*[A-Z]{1,3}'?)"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[xy]\s*=\s*-?\d+(?:\.\d+)?)"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:[A-Z][A-Za-z0-9']*\s*"
             r"\(\s*-?[A-Za-z0-9_]+(?:\s*,\s*-?[A-Za-z0-9_]+)+\s*\))"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?=[A-Za-z0-9+\-*/^.\s"
             r"\u00b2\u00b3\u00b9\u2070-\u2079]*[A-Za-z])"
             r"(?:\d+(?:\.\d+)?\s*[A-Za-z]?"
             r"(?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?|"
             r"[A-Za-z](?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?)"
             r"(?:\s*[+\-]\s*(?:\d+(?:\.\d+)?\s*[A-Za-z]?"
             r"(?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?|"
             r"[A-Za-z](?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?))+"
             r"(?![A-Za-z0-9])"
         ),
         re.compile(
             r"(?<![A-Za-z0-9])(?:\d*\s*[a-zA-Z]"
             r"(?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?"
             r"\s*(?:[+\-]\s*(?:\d*\s*[a-zA-Z]"
             r"(?:\^\d+|[\u00b2\u00b3\u00b9\u2070-\u2079])?|\d+))+)"
             r"(?![A-Za-z0-9])"
         ),
     )
 

