"""公式文本合同中的 AST payload 提取辅助。"""

from __future__ import annotations

import ast

from app.workers.validation.formula_text_ast_helpers import (
    expr_names,
    first_text_payload,
    first_text_payload_node,
    payload_is_indexed_value,
)
from app.workers.validation.formula_text_ast_utils import _call_name, _stringish_constant


def first_payload(call: ast.Call, stringish_constant=_stringish_constant) -> str | None:
    return first_text_payload(call, stringish_constant)


def first_payload_node(call: ast.Call) -> ast.AST | None:
    return first_text_payload_node(call)


def expression_names(node: ast.AST) -> list[str]:
    return expr_names(node)


def is_indexed_payload(node: ast.AST, call_name=_call_name) -> bool:
    return payload_is_indexed_value(node, call_name)
