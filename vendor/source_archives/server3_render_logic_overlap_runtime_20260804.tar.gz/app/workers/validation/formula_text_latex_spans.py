"""LaTeX 命令跨度收集。"""
import re
_COMMAND = re.compile(r"\\(?:frac|sqrt|times|cdot|sin|cos|tan|log|ln|theta|alpha|beta|gamma|pi|Delta|delta|lambda|mu|sigma|phi|Omega|angle|triangle|vec|over|perp|parallel|leq?|geq?|neq?|approx|subseteq|subset|supseteq|supset|in|notin|cup|cap|emptyset|cong|sim|because|therefore|implies|pm|to)")
_ALLOWED = set("\\{}[]()_^+-=*/<>|,.:\'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ")
def collect_latex_command_spans(text: str) -> list[tuple[int, int]]:
    spans = []
    for match in _COMMAND.finditer(text):
        start, cursor, depth, last_good = match.start(), match.end(), 0, match.end()
        while cursor < len(text):
            ch = text[cursor]
            if "\u4e00" <= ch <= "\u9fff" or ch in "，。！？；：、": break
            if ch == "{": depth += 1
            elif ch == "}": depth = max(0, depth - 1)
            if ch not in _ALLOWED: break
            cursor += 1
            if ch != " " or depth > 0: last_good = cursor
        end = max(match.end(), last_good)
        while end > start and text[end - 1].isspace(): end -= 1
        if end > start: spans.append((start, end))
    return spans
