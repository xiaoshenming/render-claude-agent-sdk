import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _fix_in_frame_method_misuse_line(source: str) -> int:
    match = _FIX_IN_FRAME_METHOD_RE.search(source)
    return _line_no(source, match.start()) if match else 0


def _mathpi_3d_camera_animate_misuse_line(
    source: str,
    *,
    is_3d: bool | None,
) -> int:
    if is_3d is not True:
        return 0
    match = _THREED_CAMERA_ANIMATE_RE.search(source)
    return _line_no(source, match.start()) if match else 0


def _mathpi_3d_camera_frame_misuse_line(
    source: str,
    *,
    is_3d: bool | None,
) -> int:
    if is_3d is not True:
        return 0
    match = _THREED_CAMERA_FRAME_RE.search(source)
    return _line_no(source, match.start()) if match else 0


def _mathpi_3d_camera_set_euler_misuse_line(
    source: str,
    *,
    is_3d: bool | None,
) -> int:
    if is_3d is not True:
        return 0
    match = _THREED_CAMERA_SET_EULER_RE.search(source)
    return _line_no(source, match.start()) if match else 0


def _prism_polygon_extrusion_misuse_line(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _line_matching(
            source,
            r"\bPrism\s*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*,\s*depth\s*=",
        )

    polygon_vars: set[str] = set()
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and _call_chain_root_name(node.value) == "Polygon"
        ):
            polygon_vars.add(node.targets[0].id)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or _call_name(node.func) != "Prism":
            continue
        if not node.args:
            continue
        first_arg = node.args[0]
        if not (
            isinstance(first_arg, ast.Name)
            and (
                first_arg.id in polygon_vars
                or re.search(r"(?:poly|polygon|face|sector)", first_arg.id, re.I)
            )
        ):
            continue
        if any(keyword.arg == "depth" for keyword in node.keywords):
            return getattr(node, "lineno", 0) or 1
    return 0


