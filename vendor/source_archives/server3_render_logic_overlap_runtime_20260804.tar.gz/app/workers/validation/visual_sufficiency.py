"""Final video visual sufficiency checks."""

from __future__ import annotations

from dataclasses import dataclass
import os
import statistics
import subprocess


@dataclass(frozen=True)
class VisualSufficiencyResult:
    passed: bool
    reason: str
    frame_count: int = 0
    max_foreground_ratio: float = 0.0
    median_foreground_ratio: float = 0.0
    threshold: float = 0.012


def inspect_video_frame_sufficiency(
    video_path: str | None,
    *,
    ffprobe_bin: str = "ffprobe",
    ffmpeg_bin: str = "ffmpeg",
    sample_width: int = 160,
    sample_height: int = 90,
    threshold: float = 0.012,
) -> VisualSufficiencyResult:
    """Sample final frames and fail only when real frames are near blank.

    Probe/extraction failures are intentionally non-blocking: many unit tests use
    fake mp4 bytes, and upload integrity is checked elsewhere. This gate exists
    to catch real rendered videos that decode but contain almost no foreground.
    """
    if not video_path:
        return VisualSufficiencyResult(True, "no_video_path", threshold=threshold)
    if not os.path.exists(video_path):
        return VisualSufficiencyResult(True, "video_path_missing", threshold=threshold)

    duration = _probe_duration(video_path, ffprobe_bin=ffprobe_bin)
    if duration <= 0:
        return VisualSufficiencyResult(True, "probe_unavailable", threshold=threshold)

    timestamps = _sample_timestamps(duration)
    ratios: list[float] = []
    for timestamp in timestamps:
        frame = _extract_rgb_frame(
            video_path,
            timestamp,
            width=sample_width,
            height=sample_height,
            ffmpeg_bin=ffmpeg_bin,
        )
        if frame:
            ratios.append(
                foreground_ratio_from_rgb_frame(
                    frame,
                    width=sample_width,
                    height=sample_height,
                )
            )

    if not ratios:
        return VisualSufficiencyResult(True, "frame_extract_unavailable", threshold=threshold)

    max_ratio = max(ratios)
    median_ratio = statistics.median(ratios)
    passed = max_ratio >= threshold
    return VisualSufficiencyResult(
        passed=passed,
        reason="ok" if passed else "low_foreground_density",
        frame_count=len(ratios),
        max_foreground_ratio=max_ratio,
        median_foreground_ratio=median_ratio,
        threshold=threshold,
    )


def foreground_ratio_from_rgb_frame(
    frame: bytes,
    *,
    width: int,
    height: int,
    color_distance_threshold: int = 42,
) -> float:
    """Estimate non-background area for a small RGB frame."""
    expected = width * height * 3
    if len(frame) < expected or width <= 0 or height <= 0:
        return 0.0

    background = _corner_median_color(frame, width=width, height=height)
    foreground = 0
    pixels = width * height
    for offset in range(0, expected, 3):
        distance = (
            abs(frame[offset] - background[0])
            + abs(frame[offset + 1] - background[1])
            + abs(frame[offset + 2] - background[2])
        )
        if distance >= color_distance_threshold:
            foreground += 1
    return foreground / max(1, pixels)


def _probe_duration(video_path: str, *, ffprobe_bin: str) -> float:
    try:
        completed = subprocess.run(
            [
                ffprobe_bin,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                video_path,
            ],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=6,
        )
    except Exception:
        return 0.0
    if completed.returncode != 0:
        return 0.0
    try:
        return max(0.0, float(completed.stdout.decode("utf-8", "ignore").strip() or 0))
    except Exception:
        return 0.0


def _sample_timestamps(duration: float) -> list[float]:
    if duration <= 1.0:
        return [max(0.0, duration * 0.5)]
    return [
        max(0.05, duration * 0.18),
        max(0.05, duration * 0.50),
        max(0.05, min(duration - 0.05, duration * 0.82)),
    ]


def _extract_rgb_frame(
    video_path: str,
    timestamp: float,
    *,
    width: int,
    height: int,
    ffmpeg_bin: str,
) -> bytes:
    try:
        completed = subprocess.run(
            [
                ffmpeg_bin,
                "-hide_banner",
                "-loglevel",
                "error",
                "-ss",
                f"{timestamp:.3f}",
                "-i",
                video_path,
                "-frames:v",
                "1",
                "-vf",
                f"scale={width}:{height}",
                "-f",
                "rawvideo",
                "-pix_fmt",
                "rgb24",
                "pipe:1",
            ],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=8,
        )
    except Exception:
        return b""
    expected = width * height * 3
    if completed.returncode != 0 or len(completed.stdout) < expected:
        return b""
    return completed.stdout[:expected]


def _corner_median_color(frame: bytes, *, width: int, height: int) -> tuple[int, int, int]:
    samples: list[tuple[int, int, int]] = []
    window = max(1, min(5, width // 8 or 1, height // 8 or 1))
    corners = (
        (0, 0),
        (max(0, width - window), 0),
        (0, max(0, height - window)),
        (max(0, width - window), max(0, height - window)),
    )
    for x0, y0 in corners:
        for y in range(y0, min(height, y0 + window)):
            for x in range(x0, min(width, x0 + window)):
                offset = (y * width + x) * 3
                samples.append((frame[offset], frame[offset + 1], frame[offset + 2]))
    if not samples:
        return (255, 255, 255)
    return (
        int(statistics.median(color[0] for color in samples)),
        int(statistics.median(color[1] for color in samples)),
        int(statistics.median(color[2] for color in samples)),
    )
