import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _invented_helper_call_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Find bare/class phantom helpers not covered by runtime_contract."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    defined_names = _module_defined_or_imported_names(tree)
    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node.func)
        if call_name not in _FORBIDDEN_FIRST_PASS_HELPER_NAMES:
            continue
        if isinstance(node.func, ast.Name) and call_name in defined_names:
            continue
        if isinstance(node.func, ast.Name):
            evidence = call_name
        else:
            continue
        line = getattr(node, "lineno", 1)
        key = (evidence, line)
        if key in seen:
            continue
        seen.add(key)
        issues.append(
            GeneratedCodeQualityIssue(
                code="invented_helper_call",
                severity="error",
                message=(
                    "生成代码调用了未授权或未本地定义的 helper；"
                    "应重写为 Manim primitives、项目运行时 helper，或在同文件先定义纯计算 helper。"
                ),
                line=line,
                evidence=evidence,
                failure_code="invented_helper_call",
            )
        )
    return issues


def _module_defined_or_imported_names(tree: ast.Module) -> set[str]:
    names: set[str] = set()
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.asname or alias.name.split(".", 1)[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == "*":
                    continue
                names.add(alias.asname or alias.name)
    return names


def _helper_abi_mismatch_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        helper = _call_name(node.func)
        allowed = _STRICT_HELPER_ALLOWED_KWARGS.get(helper)
        if allowed is None:
            continue
        bad_kwargs = [
            keyword.arg
            for keyword in node.keywords
            if keyword.arg is not None and keyword.arg not in allowed
        ]
        if not bad_kwargs:
            continue
        receiver = _call_receiver_name(node.func)
        prefix = f"{receiver}." if receiver else ""
        evidence = f"{prefix}{helper}({', '.join(bad_kwargs)})"
        line = getattr(node, "lineno", 1)
        key = (evidence, line)
        if key in seen:
            continue
        seen.add(key)
        issues.append(
            GeneratedCodeQualityIssue(
                code="helper_abi_mismatch",
                severity="error",
                message=(
                    f"{prefix}{helper} 使用了运行时 helper 合同外的关键字参数："
                    f"{', '.join(bad_kwargs)}。应按 AI-visible helper ABI 重写调用。"
                ),
                line=line,
                evidence=evidence,
                failure_code="helper_abi_mismatch",
            )
        )
    return issues


