"""公式操作数左右边界扫描。"""
import re

def expand_left(text: str, index: int, inner_chars: set[str]) -> int:
    cursor, saw_atom = index, False
    while cursor > 0:
        prev, ch = cursor - 1, text[cursor - 1]
        if ch == " ":
            if not saw_atom: cursor = prev; continue
            if prev - 1 >= 0 and (text[prev - 1] in inner_chars): cursor = prev; continue
            break
        if ch == "\\" or ch in inner_chars or "\u4e00" <= ch <= "\u9fff":
            cursor, saw_atom = prev, True; continue
        break
    return cursor

def expand_right(text: str, index: int, inner_chars: set[str], command_re: re.Pattern) -> int:
    cursor, last_atom = index, index
    while cursor < len(text):
        ch = text[cursor]
        if ch == " ":
            if cursor + 1 < len(text) and (text[cursor + 1] in inner_chars or text[cursor + 1] == "\\"): cursor += 1; continue
            if cursor + 1 >= len(text): cursor += 1; continue
            break
        if ch == "\\":
            match = command_re.match(text, cursor)
            if not match: break
            cursor = match.end(); last_atom = cursor; continue
        if ch in inner_chars or "\u4e00" <= ch <= "\u9fff":
            cursor += 1; last_atom = cursor; continue
        break
    return last_atom
