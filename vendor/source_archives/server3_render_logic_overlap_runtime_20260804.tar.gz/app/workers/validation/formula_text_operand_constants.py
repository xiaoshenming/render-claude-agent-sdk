"""公式操作数扫描常量。"""
import re
_FORMULA_OPERAND_CHARS = r"A-Za-z0-9_'+\-*/^?.\u00b2\u00b3\u00b9\u2070-\u2079\u207a\u207b\u2080-\u2089\u0370-\u03ff\u00b1\u00d7\u00f7\u00b7\u2190\u2192\u2211\u221a\u221e\u2220\u2225\u223c\u2245\u2260\u2248\u2264\u2265\u22a5\u25b3"
_FORMULA_COMPARATOR = r"(?:<=|>=|≤|≥|≠|≈|→|←|∥|⊥|∼|≅|<|>|=|\\leq|\\geq|\\le|\\ge|\\ne|\\neq|\\approx|⊆|⊂|⊇|⊃|∈|∉|∪|∩|\\subseteq|\\subset|\\supseteq|\\supset|\\in|\\notin|\\cup|\\cap|\\Rightarrow|\\rightarrow|\\Leftarrow|\\leftarrow|\\to|\\parallel|\\perp|\\sim|\\cong)"
_COMPARATOR_RE = re.compile(_FORMULA_COMPARATOR)
_OPERAND_INNER_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_'+-*/^. ?²³¹⁺⁻₀₁₂₃₄₅₆₇₈₉αβγθλμσφΩπΠΔδ±×÷·≤≥≠≈→←∑√∞∠△∼≅⊥∥⊆⊂⊇⊃∈∉∪∩∅")
_OPERAND_INNER_CHARS.update(chr(c) for c in range(0x2070, 0x2080))
_LATEX_COMMAND_RE = re.compile(r"\\[A-Za-z]+")
