import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _undefined_global_config_attribute(source: str) -> tuple[str, int] | None:
    defined_attrs = _global_config_defined_attrs(source)
    if defined_attrs is None:
        return None
    for match in re.finditer(r"\bGlobalConfig\.([A-Z][A-Z0-9_]*)\b", source):
        attr = match.group(1)
        if attr not in defined_attrs:
            return attr, _line_no(source, match.start())
    return None


def _undersized_2d_axes_line(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func_name = _call_name(node.func)
        if func_name not in {"Axes", "NumberPlane"}:
            continue
        lengths = {
            keyword.arg: _literal_number(keyword.value)
            for keyword in node.keywords
            if keyword.arg in {"x_length", "y_length"}
        }
        x_length = lengths.get("x_length")
        y_length = lengths.get("y_length")
        if (x_length is not None and x_length < 5.0) or (
            y_length is not None and y_length < 4.0
        ):
            return getattr(node, "lineno", 0)
    return 0


def _call_name(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _literal_number(node: ast.AST) -> float | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, ast.USub)
        and isinstance(node.operand, ast.Constant)
        and isinstance(node.operand.value, (int, float))
    ):
        return -float(node.operand.value)
    return None


def _global_config_defined_attrs(source: str) -> set[str] | None:
    body = _global_config_body(source)
    if body is None:
        return None
    attrs = set(re.findall(r"(?m)^\s+([A-Z][A-Z0-9_]*)\s*=", body))
    attrs.update(
        re.findall(r"(?m)^\s*GlobalConfig\.([A-Z][A-Z0-9_]*)\s*=", source)
    )
    return attrs


def _global_config_body(source: str) -> str | None:
    lines = source.splitlines()
    for index, line in enumerate(lines):
        if not re.match(r"^class\s+GlobalConfig\b.*:\s*$", line):
            continue
        body_lines: list[str] = []
        for body_line in lines[index + 1:]:
            if body_line.strip() == "":
                body_lines.append(body_line)
                continue
            if re.match(r"^\S", body_line):
                break
            body_lines.append(body_line)
        return "\n".join(body_lines)
    return None


