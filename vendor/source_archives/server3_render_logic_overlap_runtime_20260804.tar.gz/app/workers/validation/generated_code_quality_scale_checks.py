"""Scale and simple-layout checks extracted from generated-code inspection."""

from app.workers.validation.generated_code_quality_helpers import (
    _portrait_tiny_font_size_issues,
    _should_check_3d_text,
    _text_formula_tiny_scale_line,
    _undersized_2d_axes_line,
)
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue


def _append_scale_layout_issues(source, issues, *, text_vars=None, is_3d=None, is_portrait=None):
    tiny_scale_line = _text_formula_tiny_scale_line(source, text_vars)
    if tiny_scale_line:
        issues.append(GeneratedCodeQualityIssue(
            code="text_formula_tiny_scale", severity="error",
            message="Text/MathTex 被直接 scale 到 0.75 以下，手机端容易太小且诱发布局重叠；应提高 font_size、拆分内容或重新排版。",
            line=tiny_scale_line, evidence="Text/MathTex.scale(<0.75)",
        ))
    if not _should_check_3d_text(source, is_3d):
        axes_line = _undersized_2d_axes_line(source)
        if axes_line:
            issues.append(GeneratedCodeQualityIssue(
                code="undersized_2d_axes", severity="risk",
                message="2D 坐标轴尺寸明显偏小，容易形成缩略图式画面。",
                line=axes_line, evidence="Axes/NumberPlane x_length < 5.0 or y_length < 4.0",
            ))
    issues.extend(_portrait_tiny_font_size_issues(source, is_portrait=is_portrait))
    return issues
