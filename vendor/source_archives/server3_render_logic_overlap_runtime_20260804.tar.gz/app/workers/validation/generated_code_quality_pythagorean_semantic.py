import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _pythagorean_three_square_semantic_issues(
    source: str,
) -> list[GeneratedCodeQualityIssue]:
    issues: list[GeneratedCodeQualityIssue] = []
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    has_valid_square_scene = any(
        _pythagorean_block_has_valid_three_square_visual(block)
        for block, _line_offset in blocks
    )
    for block, line_offset in blocks:
        if not _has_pythagorean_three_square_context(block):
            continue
        if _uses_trusted_pythagorean_square_helper(block):
            continue
        if has_valid_square_scene and not _pythagorean_block_mentions_square_visual(block):
            continue
        issues.extend(
            _pythagorean_three_square_semantic_issues_in_block(block, line_offset)
        )
    return issues


def _pythagorean_three_square_semantic_issues_in_block(
    source: str,
    line_offset: int,
) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    square_records = _pythagorean_square_records(tree)
    square_count = len(square_records)
    bound_square_labels = {
        record["label"]
        for record in square_records
        if record["label"] in {"a", "b", "c"} and record["edge_bound"]
    }
    named_square_labels = {
        record["label"] for record in square_records if record["label"] in {"a", "b", "c"}
    }

    issues: list[GeneratedCodeQualityIssue] = []
    if len(named_square_labels) < 3 and square_count < 3:
        line = min((int(record["line"]) for record in square_records), default=1)
        evidence = (
            f"found_square_labels={','.join(sorted(named_square_labels)) or '<none>'}; "
            "expected square_a/square_b/square_c bound to the three triangle sides"
        )
        issues.append(
            GeneratedCodeQualityIssue(
                code="missing_three_squares_for_pythagorean_meaning",
                severity="error",
                message=(
                    "勾股定理面积语义缺少贴在三条边上的 a^2、b^2、c^2 三个正方形，"
                    "不能只显示公式或单个漂移正方形。"
                ),
                line=line_offset + line,
                evidence=evidence,
                failure_code="missing_three_squares_for_pythagorean_meaning",
            )
        )

    for record in square_records:
        label = str(record["label"])
        if label not in {"a", "b", "c"} or record["edge_bound"]:
            continue
        if not record["detached"]:
            continue
        issues.append(
            GeneratedCodeQualityIssue(
                code="pythagorean_square_edge_binding",
                severity="error",
                message=(
                    f"勾股定理 {label}^2 正方形没有绑定到对应三角形边；"
                    "应由该边两端点构造或调用 square_on_segment。"
                ),
                line=line_offset + int(record["line"]),
                evidence=str(record["evidence"]),
                failure_code="label_detached",
            )
        )
        break

    if square_records:
        issues.extend(
            _pythagorean_square_label_center_issues(
                tree,
                line_offset,
                named_square_labels or bound_square_labels,
            )
        )
    return issues


