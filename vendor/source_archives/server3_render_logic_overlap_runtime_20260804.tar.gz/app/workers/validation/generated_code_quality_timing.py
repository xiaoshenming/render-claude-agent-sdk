import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _formula_passed_to_show_text_line(source: str) -> int:
    return _line_matching(
        source,
        r"self\.(?:show_text|restore_text)\s*\([^)\n]*r?[\"']\$\$",
    )


def _legacy_text_slot_api_line(source: str) -> int:
    return _line_matching(
        source,
        r"self\.(?:show_text|restore_text|text_center|graph_center)\b",
    )


def _voiceover_timing_contract_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.With):
            continue
        tracker_names = [
            item.optional_vars.id
            for item in node.items
            if _is_self_voiceover_call(item.context_expr)
            and isinstance(item.optional_vars, ast.Name)
        ]
        if not tracker_names:
            continue

        voiceover_text = _voiceover_call_text(item.context_expr for item in node.items)
        if voiceover_text:
            clean_text = _clean_voiceover_text(voiceover_text)
            cjk_chars = _count_cjk_chars(clean_text)
            if cjk_chars > _VOICEOVER_SEGMENT_MAX_CJK_CHARS:
                issues.append(
                    GeneratedCodeQualityIssue(
                        code="voiceover_segment_too_long",
                        severity="error",
                        message="单个 voiceover 文本过长，长段旁白只能做到块级对齐；应拆成多个短旁白块。",
                        line=getattr(node, "lineno", 1),
                        evidence=(
                            f"{cjk_chars} CJK chars > "
                            f"{_VOICEOVER_SEGMENT_MAX_CJK_CHARS}"
                        ),
                    )
                )

        for tracker_name in tracker_names:
            helper_lines: list[int] = []
            bookmark_lines: list[int] = []
            play_lines: list[int] = []
            wait_lines: list[int] = []
            for child in ast.walk(ast.Module(body=node.body, type_ignores=[])):
                if not isinstance(child, ast.Call):
                    continue
                child_line = getattr(child, "lineno", 0) or getattr(node, "lineno", 1)
                if _is_self_raw_play_call(child):
                    play_lines.append(child_line)
                if _is_full_timeline_helper_call(child, tracker_name):
                    helper_lines.append(child_line)
                    if _is_empty_full_timeline_helper_call(child, tracker_name):
                        issues.append(
                            GeneratedCodeQualityIssue(
                                code="voiceover_empty_full_helper",
                                severity="error",
                                message="voiceover 块把空动作列表交给整段时间轴 helper，会把整段配音变成静默等待。",
                                line=child_line,
                                evidence="play_steps_evenly([], tracker)",
                            )
                        )
                if _call_uses_tracker_duration_as_run_time(child, tracker_name):
                    issues.append(
                        GeneratedCodeQualityIssue(
                            code="voice_text_run_time_tracker_duration",
                            severity="error",
                            message="配音文字动画直接绑定 tracker.duration，容易造成画面长时间静止。",
                            line=child_line,
                            evidence=f"run_time={tracker_name}.duration",
                        )
                    )
                if _is_self_wait_like_call(child):
                    wait_lines.append(child_line)
                    wait_seconds = _numeric_self_wait_seconds(child)
                    if wait_seconds is not None and wait_seconds >= 0.8:
                        issues.append(
                            GeneratedCodeQualityIssue(
                                code="voiceover_fixed_wait_padding",
                                severity="error",
                                message="voiceover 块内存在固定长等待，容易造成动画先播完再说话或切片尾部静止。",
                                line=child_line,
                                evidence=f"self.wait({wait_seconds:g})",
                            )
                        )
                    if _call_waits_for_tracker_remainder(child, tracker_name):
                        issues.append(
                            GeneratedCodeQualityIssue(
                                code="voice_tracker_remainder_wait",
                                severity="error",
                                message="配音块用 tracker.duration 减固定动画时长补等待，容易留下长时间静止尾巴。",
                                line=child_line,
                                evidence=f"wait(...{tracker_name}.duration - ...)",
                            )
                        )
                    elif _call_waits_for_full_tracker_duration(child, tracker_name):
                        issues.append(
                            GeneratedCodeQualityIssue(
                                code="voice_tracker_full_duration_wait",
                                severity="error",
                                message="配音块直接等待完整 tracker.duration，会让切片内出现大段无画面动作。",
                                line=child_line,
                                evidence=f"wait({tracker_name}.duration)",
                            )
                        )
                if _is_self_method_call(child, "wait_until_bookmark") or _is_tracker_method_call(
                    child, tracker_name, "time_until_bookmark"
                ):
                    bookmark_lines.append(child_line)

            helper_lines.sort()
            bookmark_lines.sort()
            play_lines.sort()
            wait_lines.sort()
            if not helper_lines and not bookmark_lines:
                if wait_lines and not play_lines:
                    issues.append(
                        GeneratedCodeQualityIssue(
                            code="voiceover_wait_only_block",
                            severity="error",
                            message="voiceover 块只有等待没有动画，常见于先 add 全部内容再配音，画面会闪现或先展示完再说。",
                            line=wait_lines[0],
                            evidence="with voiceover: self.wait(...)",
                        )
                    )
                if not play_lines and not wait_lines:
                    issues.append(
                        GeneratedCodeQualityIssue(
                            code="voiceover_wait_only_block",
                            severity="error",
                            message="voiceover 块没有任何动画，常见于先展示完内容再说话。",
                            line=getattr(node, "lineno", 1),
                            evidence="with voiceover: no visual animation",
                        )
                    )
                if len(play_lines) > 1:
                    issues.append(
                        GeneratedCodeQualityIssue(
                            code="voiceover_raw_multi_play_without_helper",
                            severity="error",
                            message="同一 voiceover 块里多个裸 self.play 应使用 play_steps_evenly/play_synced_steps 或 bookmark 做时间分布。",
                            line=play_lines[1],
                            evidence="multiple self.play(...) without sync helper",
                        )
                    )
            if len(helper_lines) > 1:
                issues.append(
                    GeneratedCodeQualityIssue(
                        code="voiceover_tracker_reused_full_helper",
                        severity="error",
                        message="同一个 voiceover 块多次调用整段时间轴 helper，会重复消耗 tracker.duration 并制造长停顿。",
                        line=helper_lines[1],
                        evidence=f"{tracker_name} used by play_steps_evenly/play_synced_steps more than once",
                    )
                )

            first_bookmark_line = bookmark_lines[0] if bookmark_lines else 0
            helper_after_bookmark = next(
                (line for line in helper_lines if first_bookmark_line and line > first_bookmark_line),
                0,
            )
            if helper_after_bookmark:
                issues.append(
                    GeneratedCodeQualityIssue(
                        code="voiceover_bookmark_then_full_helper",
                        severity="error",
                        message="wait_until_bookmark 后又调用整段时间轴 helper，会把后续动画重新摊到完整配音时长上。",
                        line=helper_after_bookmark,
                        evidence="wait_until_bookmark(...) before play_steps_evenly(..., tracker)",
                    )
                )

    return issues


