import ast

def _class_range(lines: list[str], class_name: str) -> tuple[int, int, str] | None:
    for index, line in enumerate(lines):
        match = re.match(
            rf"^(?P<indent>\s*)class\s+{re.escape(class_name)}\b.*:\s*$",
            line,
        )
        if not match:
            continue
        class_indent = match.group("indent")
        end = index + 1
        while end < len(lines):
            body_line = lines[end]
            if body_line.strip() and len(body_line) - len(body_line.lstrip()) <= len(class_indent):
                break
            end += 1
        return index, end, class_indent + "    "
    return None


def _method_range(
    lines: list[str],
    *,
    class_start: int,
    class_end: int,
    body_indent: str,
    method_name: str,
) -> tuple[int, int] | None:
    method_pattern = re.compile(
        rf"^{re.escape(body_indent)}def\s+{re.escape(method_name)}\s*\("
    )
    for index in range(class_start + 1, class_end):
        if not method_pattern.match(lines[index]):
            continue
        end = index + 1
        while end < len(lines):
            body_line = lines[end]
            if body_line.strip() and len(body_line) - len(body_line.lstrip()) <= len(body_indent):
                break
            end += 1
        return index, min(end, class_end)
    return None


def _is_front_facing_3d_camera_line(line: str) -> bool:
    compact = re.sub(r"\s+", "", line)
    return (
        "set_camera_orientation(" in compact
        and "phi=0*DEGREES" in compact
        and "theta=-90*DEGREES" in compact
    )


