from .generated_code_quality_models import GeneratedCodeQualityIssue

def _circle_area_base_width_mismatch_line(source: str) -> int:
    if not _CIRCLE_AREA_CONTEXT_RE.search(source):
        return 0
    if not re.search(r"(?:MathTex\s*\(\s*r?[\"']\\+pi\s*r|πr)", source):
        return 0

    count_match = _CIRCLE_SECTOR_COUNT_RE.search(source)
    half_chord_match = _CIRCLE_HALF_CHORD_ASSIGN_RE.search(source)
    if not count_match or not half_chord_match:
        return 0

    try:
        sector_count = int(count_match.group(1))
    except ValueError:
        return 0
    if sector_count < 8 or sector_count % 2 != 0:
        return 0

    half_chord_var = half_chord_match.group("var")
    bad_half_span = _format_float((sector_count - 1) / 2)
    bad_full_span = _format_float(sector_count - 1)
    var = re.escape(half_chord_var)
    bad_patterns = [
        rf"\(\s*i\s*-\s*{bad_half_span}\s*\)\s*\*\s*{var}\b",
        rf"\b-?{bad_half_span}\s*\*\s*{var}\b",
        rf"\b{bad_full_span}\s*\*\s*{var}\b",
        rf"\(\s*(?:num_sectors|n_sectors|sector_count|num_pieces|pieces)\s*-\s*1\s*\)\s*\*\s*{var}\b",
        rf"\(\s*(?:num_sectors|n_sectors|sector_count|num_pieces|pieces)\s*/\s*2\s*-\s*0\.5\s*\)\s*\*\s*2\s*\*\s*{var}\b",
    ]
    for pattern in bad_patterns:
        match = re.search(pattern, source)
        if match:
            return _line_no(source, match.start())
    return 0


def _circle_area_annularsector_misuse_line(source: str) -> int:
    if not _CIRCLE_AREA_CONTEXT_RE.search(source):
        return 0
    match = re.search(r"\bAnnularSector\s*\(", source)
    return _line_no(source, match.start()) if match else 0


def _format_float(value: float) -> str:
    text = f"{value:g}"
    if "." in text:
        return re.escape(text)
    return re.escape(text)


def _is_side_label_var(name: str) -> bool:
    return bool(_SIDE_LABEL_VAR_RE.match(name))


def _is_single_vertex_direction_offset(expr: str) -> bool:
    normalized = _normalize_expr(expr)
    if any(
        marker in normalized
        for marker in ("get_center(", "Line(", "BraceBetweenPoints(", "midpoint")
    ):
        return False
    scalar = r"(?:\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_]*)"
    direction_times_scalar = rf"{_DIRECTION_NAME_RE}(?:\s*\*\s*{scalar})?"
    scalar_times_direction = rf"{scalar}\s*\*\s*{_DIRECTION_NAME_RE}"
    offset = rf"(?:{direction_times_scalar}|{scalar_times_direction})"
    return bool(
        re.fullmatch(
            rf"[A-Z][A-Za-z0-9_]*\s*[-+]\s*{offset}",
            normalized,
        )
    )


