"""Content-security string fragment contracts and filters."""
import re
from dataclasses import dataclass

_CJK_RE = re.compile(r"[\u4e00-\u9fff]")
_HEX_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")
_FILELIKE_RE = re.compile(r"\.(?:py|mp4|mp3|wav|json|txt|png|jpg|jpeg|svg|ttf|otf)$", re.I)
_SIMPLE_TECH_TOKEN_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_./:-]*$")
_COMMON_FONT_NAMES = {
    "arial",
    "dejavu sans",
    "microsoft yahei",
    "noto sans cjk sc",
    "pingfang sc",
    "simsun",
    "simhei",
    "source han sans sc",
}


@dataclass(frozen=True)
class _StringFragment:
    text: str
    lineno: int
    col_offset: int
    end_lineno: int
