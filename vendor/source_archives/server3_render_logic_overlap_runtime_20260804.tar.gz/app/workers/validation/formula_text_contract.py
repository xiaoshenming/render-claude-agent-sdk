"""Shared AST checks for formula-like payloads in plain text helpers."""

from __future__ import annotations

import ast

from app.workers.validation.formula_text_constants import *
from app.workers.validation.formula_text_ast_utils import (
    _parent_map, _call_can_use_self_inline_helper, _module_defines_inline_math_text,
    _node_span, _byte_col_to_char_col, _stringish_constant, _call_name,
)
from app.workers.validation.formula_text_boundary_checks import (
    dollar_formula_boundary_segments,
    split_leading_cjk_prose_from_latex_math, trim_inline_math_span, strip_unanchored_cjk,
)
from app.workers.validation.formula_text_normalization import normalize_formula_text_payload
from app.workers.validation.formula_text_operand_checks import (
    is_ascii_operand, is_symbolic_operand, is_cjk_operand, is_operand_atom,
)
from app.workers.validation.formula_text_operand_constants import (
    _FORMULA_OPERAND_CHARS, _FORMULA_COMPARATOR, _COMPARATOR_RE,
    _OPERAND_INNER_CHARS, _LATEX_COMMAND_RE,
)
from app.workers.validation.formula_text_operand_expansion import (
    expand_left,
    expand_right,
)
from app.workers.validation.formula_text_ast_helpers import safe_unparse, is_str_call, expr_names, payload_is_indexed_value, call_uses_formula_color, dynamic_expression_source, first_text_payload, first_text_payload_node, looks_like_dynamic_formula_payload, first_dynamic_formula_payload
from app.workers.validation.formula_text_cjk_checks import is_cjk_symbolic_formula, is_pure_formula_payload
from app.workers.validation.formula_text_mathtex_helpers import mathtex_call_source, dynamic_mathtex_call_source, inline_vgroup_call_source, inline_math_text_call_source
from app.workers.validation.formula_text_payload_helpers import (
    expression_names as _expr_names,
    first_payload as _first_text_payload,
    first_payload_node as _first_text_payload_node,
    is_indexed_payload as _payload_is_indexed_value,
)
from app.workers.validation.formula_text_latex_spans import collect_latex_command_spans
from app.workers.validation.formula_text_patterns import formula_match_patterns
from dataclasses import dataclass
import re

from app.workers.validation.formula_boundary_collection import (
    _collect_high_confidence_formula_matches, _collect_latex_command_spans,
    _formula_match_patterns, _iter_high_confidence_formula_matches,
    _normalize_formula_text_payload, _trim_inline_math_span,
)

from app.workers.validation.formula_dynamic_helpers import (
    _call_uses_formula_color, _dynamic_formula_expression_source, _dynamic_formula_payload_is_auto_repairable, _dynamic_mathtex_call_source, _dynamic_text_payload_is_sanitized_math_label, _enclosing_function_name, _first_dynamic_formula_payload, _inline_math_text_call_source, _inline_vgroup_call_source, _is_cjk_symbolic_formula, _is_pure_formula_payload, _is_str_call, _looks_like_dynamic_formula_payload, _mathtex_call_source, _safe_unparse, _strip_cosmetic_text_replace_chain,
)

@dataclass(frozen=True, slots=True)
class FormulaTextViolation:
    call_name: str
    line: int
    column: int | None
    payload: str
    code: str = "formula_text_not_mathtex"

    @property
    def preview(self) -> str:
        preview = re.sub(r"\s+", " ", self.payload).strip()
        return preview if len(preview) <= 90 else preview[:87] + "..."

    def reason_fragment(self) -> str:
        return f"L{self.line}: {self.call_name}({self.preview})"

def inspect_formula_text_violations(code: str) -> list[FormulaTextViolation]:
    """Return formula-like strings passed to Text/safe_text_box helpers."""
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return []

    violations: list[FormulaTextViolation] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node.func)
        if call_name.split(".")[-1] == "inline_math_text":
            payload = _inline_math_text_single_list_payload(node, code or "")
            if payload is not None:
                violations.append(
                    FormulaTextViolation(
                        call_name=call_name,
                        line=getattr(node, "lineno", 0) or 1,
                        column=getattr(node, "col_offset", None),
                        payload=payload,
                        code="formula_inline_math_text_single_list_parts",
                    )
                )
            continue
        if call_name.split(".")[-1] not in TEXT_PAYLOAD_HELPERS:
            continue
        payload = _first_text_payload(node)
        if payload is not None:
            if not looks_like_formula_text(payload):
                continue
            violations.append(
                FormulaTextViolation(
                    call_name=call_name,
                    line=getattr(node, "lineno", 0) or 1,
                    column=getattr(node, "col_offset", None),
                    payload=payload,
                )
            )
            continue
        dynamic_payload = _first_dynamic_formula_payload(node, code or "")
        if not dynamic_payload:
            continue
        violations.append(
            FormulaTextViolation(
                call_name=call_name,
                line=getattr(node, "lineno", 0) or 1,
                column=getattr(node, "col_offset", None),
                payload=dynamic_payload,
            )
        )
    return violations

def _inline_math_text_single_list_payload(call: ast.Call, source: str) -> str | None:
    if len(call.args) != 1:
        return None
    parts_arg = call.args[0]
    if not isinstance(parts_arg, ast.List):
        return None
    if not _list_looks_like_inline_math_parts(parts_arg):
        return None
    return ast.get_source_segment(source, parts_arg) or _safe_unparse(parts_arg)

def _list_looks_like_inline_math_parts(node: ast.List) -> bool:
    if not node.elts:
        return False
    saw_math_part = False
    for item in node.elts:
        if not isinstance(item, (ast.Tuple, ast.List)) or len(item.elts) < 2:
            return False
        kind = _stringish_constant(item.elts[0])
        if kind not in {"text", "math"}:
            return False
        if kind == "math":
            saw_math_part = True
    return saw_math_part

def looks_like_formula_text(text: str) -> bool:
    compact = str(text or "").strip()
    if not compact:
        return False
    if _looks_like_plain_text_label(compact):
        return False
    if any(token in compact for token in FORMULA_TEXT_LATEX_TOKENS):
        return True
    if "\\" in compact:
        return True
    if re.search(r"[\^_⁰¹²³⁴⁵⁶⁷⁸⁹]", compact) and re.search(
        r"[A-Za-z0-9=+\-*/]", compact
    ):
        return True
    if re.search(r"[₀₁₂₃₄₅₆₇₈₉]", compact) and re.search(
        r"[A-Za-z0-9=+\-*/]", compact
    ):
        return True
    if re.search(
        r"[αβγθλμσφΩπΠΔδ≤≥≠≈×·÷±√∞∑∠△∼≅⊥∥→←⊆⊂⊇⊃∈∉∪∩∅]",
        compact,
    ) and re.search(
        r"[A-Za-z0-9αβγθλμσφΩπΠΔδ⁰¹²³⁴⁵⁶⁷⁸⁹²³¹₀₁₂₃₄₅₆₇₈₉]", compact
    ):
        return True
    return bool(
        len(compact) <= 120
        and re.search(r"[A-Za-z0-9]\s*(?:=|[+\-*/])\s*[A-Za-z0-9]", compact)
    )

_PLAIN_RANGE_LABEL_RE = re.compile(
    r"第\s*\d+\s*-\s*\d+\s*(?:题|问|步|页|讲|节|小题)"
)
_PLAIN_TRIANGLE_TRIPLE_LABEL_RE = re.compile(
    r"\b\d+\s*-\s*\d+\s*-\s*\d+\s*(?:直角)?三角形[\u4e00-\u9fff]*"
)
_PLAIN_CHOICE_LABEL_RE = re.compile(r"\b[A-Z]/[A-Z]\b\s*[\u4e00-\u9fff]")
_CJK_UNIT_WITH_SUPERSCRIPT_RE = re.compile(
    r"[\u4e00-\u9fff].*\d+(?:\.\d+)?\s+[A-Za-z]{1,4}[²³¹⁰⁴⁵⁶⁷⁸⁹]"
)
_CJK_STANDALONE_SYMBOL_LABEL_RE = re.compile(r"[\u4e00-\u9fff].*[αβγθλμσφΩπΠΔδ]")
_CJK_INLINE_SYMBOL_PROSE_LABEL_RE = re.compile(
    r"[\u4e00-\u9fff].*(?:\b(?:sin|cos|tan)\s*[αβγθλμσφΩπΠΔδ]?"
    r"|[αβγθλμσφΩπΠΔδ]|\b[A-Za-z]\b)"
)
_INLINE_PROSE_FORMULA_FRAGMENT_RE = re.compile(
    r"(?:\d+\s*[πΠ]|[πΠ]\s*[A-Za-z0-9]|[A-Za-z]\s*[\d₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹²³¹])"
)
_FORMULA_OPERATOR_OR_SOURCE_RE = re.compile(
    r"(?:\\[A-Za-z]+|[$^_=+\-*/⁰¹²³⁴⁵⁶⁷⁸⁹²³¹₀₁₂₃₄₅₆₇₈₉]"
    r"|[≤≥≠≈×·÷±√∞∑∠△∼≅⊥∥→←⊆⊂⊇⊃∈∉∪∩∅])"
)

def _looks_like_plain_text_label(text: str) -> bool:
    """Avoid routing lesson labels and prose with units into formula repair."""

    if _PLAIN_RANGE_LABEL_RE.search(text):
        return True
    if (
        _PLAIN_TRIANGLE_TRIPLE_LABEL_RE.search(text)
        and not _COMPARATOR_RE.search(text)
        and "\\" not in text
    ):
        return True
    if _PLAIN_CHOICE_LABEL_RE.search(text) and not _COMPARATOR_RE.search(text):
        return True
    if (
        _CJK_UNIT_WITH_SUPERSCRIPT_RE.search(text)
        and not _COMPARATOR_RE.search(text)
        and not any(token in text for token in FORMULA_TEXT_LATEX_TOKENS)
        and "\\" not in text
    ):
        return True
    if (
        _CJK_STANDALONE_SYMBOL_LABEL_RE.search(text)
        and not re.search(r"[A-Za-z0-9]", text)
        and not _COMPARATOR_RE.search(text)
        and not _FORMULA_OPERATOR_OR_SOURCE_RE.search(text)
    ):
        return True
    if (
        _CJK_INLINE_SYMBOL_PROSE_LABEL_RE.search(text)
        and "\\" not in text
        and not _COMPARATOR_RE.search(text)
        and not _INLINE_PROSE_FORMULA_FRAGMENT_RE.search(text)
        and not _FORMULA_OPERATOR_OR_SOURCE_RE.search(text)
    ):
        return True
    return False

def rewrite_formula_text_payloads_to_mathtex(code: str) -> tuple[str, list[str]]:
    """Rewrite pure formula payloads in Text/safe_text_box calls to MathTex.

    Mixed CJK prose such as ``半径 r = 1`` is intentionally left untouched so
    the semantic gate can ask an LLM to split it into Text + MathTex safely.
    High-confidence dynamic formula payloads such as
    ``Text(str(formula_prefix).replace(...), color=FORMULA_COLOR)`` are also
    rewritten because keeping TeX-like variables in Text cannot render
    correctly.
    """
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return code, []

    parent_map = _parent_map(tree)
    lines = (code or "").splitlines(keepends=True)
    replacements: list[tuple[int, int, str, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node.func)
        if call_name.split(".")[-1] not in TEXT_PAYLOAD_HELPERS:
            continue
        payload = _first_text_payload(node)
        desc = f"formula_text_to_mathtex:L{getattr(node, 'lineno', 0) or 1}"
        if payload is not None:
            if not looks_like_formula_text(payload):
                continue
            if not _is_pure_formula_payload(payload):
                continue
            replacement = _mathtex_call_source(code or "", node, payload)
        else:
            replacement = _dynamic_mathtex_call_source(code or "", node, parent_map)
            desc = f"dynamic_formula_text_to_mathtex:L{getattr(node, 'lineno', 0) or 1}"
        if not replacement:
            continue
        start, end = _node_span(node, lines)
        if start is None or end is None:
            continue
        replacements.append((start, end, replacement, desc))

    if not replacements:
        return code, []

    fixed = code or ""
    fixes: list[str] = []
    for start, end, replacement, desc in sorted(replacements, reverse=True):
        fixed = fixed[:start] + replacement + fixed[end:]
        fixes.append(desc)
    fixes.reverse()
    return fixed, fixes



def compile_formula_text_boundaries(code: str) -> tuple[str, list[str]]:
    from .formula_boundary_compiler import compile_formula_text_boundaries as _compile
    return _compile(code)
