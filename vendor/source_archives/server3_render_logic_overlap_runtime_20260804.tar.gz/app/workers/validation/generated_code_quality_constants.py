from __future__ import annotations
import ast
import math
import re
import textwrap

_TEXT_ASSIGN_RE = re.compile(
    r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"(?:(?:Text|Tex|MathTex|MarkupText)\s*\(|"
    r"self\.(?:show_text|portrait_title|portrait_formula|create_text|create_formula|"
    r"safe_text|safe_text_box)\s*\()",
    re.M,
)
_TEXT_CONSTRUCTOR_NAMES = {"Text", "Tex", "MathTex", "MarkupText"}
_SAFE_TEXT_METHOD_NAMES = {
    "show_text",
    "portrait_title",
    "portrait_formula",
    "create_text",
    "create_formula",
    "safe_text",
    "safe_text_box",
}
_LABEL_OR_ANGLE_CONSTRUCTOR_NAMES = _TEXT_CONSTRUCTOR_NAMES | {
    "DecimalNumber",
    "Integer",
    "Variable",
    "Angle",
    "RightAngle",
    "ArcBetweenPoints",
    "Brace",
    "BraceBetweenPoints",
}
_GEOMETRY_TRANSFORM_METHODS = {"shift", "scale", "move_to"}
_REVEAL_TEXT_ANIMATION_NAMES = {
    "FadeIn",
    "Write",
    "Create",
    "DrawBorderThenFill",
    "GrowFromCenter",
}
_REMOVE_TEXT_ANIMATION_NAMES = {"FadeOut", "Unwrite", "Uncreate"}
_REPLACE_TEXT_ANIMATION_NAMES = {
    "ReplacementTransform",
    "Transform",
    "TransformMatchingTex",
}
_VISUAL_CONSTRUCTOR_NAMES = {
    "VGroup",
    "Polygon",
    "Line",
    "Arrow",
    "Vector",
    "Dot",
    "Dot3D",
    "Circle",
    "Rectangle",
    "Square",
    "Triangle",
    "Axes",
    "ThreeDAxes",
    "NumberPlane",
    "AnnularSector",
    "Arc",
    "Sector",
    "Surface",
    "Sphere",
}
_VISUAL_PRIMITIVE_RE = re.compile(
    r"\b("
    r"Axes|ThreeDAxes|NumberPlane|Circle|Polygon|Line|Arrow|Vector|Dot|Dot3D|"
    r"Surface|Sphere|ParametricFunction|FunctionGraph|Graph|AnnularSector|"
    r"Rectangle|Square|Triangle|Arc|Sector"
    r")\s*\("
)
_RAW_SVG_OR_IMAGE_RE = re.compile(
    r"\b(?:SVGMobject|ImageMobject)\s*\(\s*['\"][^'\"]+['\"]"
)
_ICON_HELPER_DEFINITION_RE = re.compile(
    r"^\s*def\s+(?:asset_icon|icon_card|icon_row)\s*\(",
    re.M,
)
_OFFICIAL_ICON_HELPER_MARKERS = (
    "MATHPI_RENDER_ASSETS_DIR",
    "_prepare_icon_svg_for_manim",
)
_CUSTOM_VISUAL_GRAPH_RE = re.compile(r"\bself\.(?:fit_graph|make_curve|make_arrow)\s*\(")
_VISUAL_ASSIGN_RE = re.compile(
    r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"(?:VGroup|Polygon|Line|Arrow|Vector|Dot|Dot3D|Circle|Rectangle|"
    r"Square|Triangle|Axes|ThreeDAxes|NumberPlane|AnnularSector|Arc|"
    r"Sector|Surface|Sphere)\s*\(",
    re.M,
)
_DEFAULT_COLOR_KW_RE = re.compile(
    r"\b(?:color|fill_color|stroke_color)\s*=\s*"
    r"(?P<color>(?:RED|GREEN|BLUE|YELLOW|WHITE|BLACK|GOLD|ORANGE|"
    r"PINK|PURPLE|TEAL|GREY|GRAY|DARK_GRAY)(?:_[A-E])?)\b"
)
_CLEAR_SCREEN_TARGET_RE = re.compile(
    r"(?:^|_)(?:all|whole|full|screen|scene|canvas|content|diagram|graph|"
    r"visual|geometry|figure|construction|blackout|cover|mask)(?:_|$)"
)
_REVEAL_ANIMATION_RE = re.compile(
    r"\b(?:FadeIn|Create|Write|DrawBorderThenFill|GrowFromCenter|"
    r"ReplacementTransform|Transform|TransformMatchingTex|TransformFromCopy)\s*\("
)
_TTS_TIMING_BLOCKER_CODES = frozenset({
    "tts_voiceover_block_missing",
    "voiceover_segment_too_long",
    "voice_text_run_time_tracker_duration",
    "voice_tracker_remainder_wait",
    "voice_tracker_full_duration_wait",
    "voiceover_empty_full_helper",
    "voiceover_tracker_reused_full_helper",
    "voiceover_bookmark_then_full_helper",
    "voiceover_wait_only_block",
    "voiceover_fixed_wait_padding",
    "voiceover_raw_multi_play_without_helper",
})
_FIRST_PASS_REWRITE_STATIC_CONTRACT_CODES = frozenset({
    "invented_helper_call",
    "helper_abi_mismatch",
    "manim_set_style_dashed_misuse",
    "manim_stroke_dash_array_misuse",
    "manim_max_width_to_size_ratio_misuse",
    "geometry_dict_key_not_local",
    "durable_panel_manual_coordinates",
    "theme_semantic_token_override",
})
_BLOCKING_STATIC_CONTRACT_CODES = frozenset({
    "raw_svgmobject_path",
    "icon_asset_helper_redefined",
    "core_visual_semantic_icon_fallback",
    "formula_text_not_mathtex",
    "formula_inline_math_text_single_list_parts",
    "circle_area_annularsector_misuse",
    "circle_area_base_width_mismatch",
    "manim_prism_polygon_extrusion_misuse",
    "manim_fix_in_frame_method_misuse",
    "mathpi_3d_camera_animate_misuse",
    "mathpi_3d_camera_frame_misuse",
    "mathpi_3d_camera_set_euler_misuse",
    "mathpi_3d_scene_contract_missing",
    "mathpi_3d_camera_contract_missing",
    "mathpi_3d_default_camera_oblique",
    "portrait_tiny_font_size",
    "manim_next_to_alignment_misuse",
    "manim_parametric_surface_misuse",
    "text_formula_tiny_scale",
    "geometry_prime_label_text",
    "semantic_visual_icon_text_box_fallback",
    "generated_icon_text_box_fallback",
    "core_text_helper_fallback_icon",
    "forbidden_visible_fallback_icon",
    "right_triangle_numeric_side_label_mismatch",
    "missing_three_squares_for_pythagorean_meaning",
    "pythagorean_square_edge_binding",
    "pythagorean_square_label_center_binding",
    "runtime_helper_contract_violation",
})
_FORBIDDEN_FIRST_PASS_HELPER_NAMES = frozenset({
    "CustomCross",
    "create_geometry_objects",
    "get_angle_deg",
    "get_cylinder_mobject",
    "get_geometry_points",
})
_STRICT_HELPER_ALLOWED_KWARGS = {
    "create_right_angle_mark": frozenset({"size", "length", "color"}),
    "place_panel": frozenset({
        "area",
        "avoid",
        "others",
        "anchor",
        "buff",
        "padding",
        "max_width",
        "max_height",
        "move",
    }),
}
_GEO_MODEL_DICT_NAMES = frozenset({"geo", "model"})
_DURABLE_PANEL_VAR_RE = re.compile(
    r"(?:^|_)(?:panel|proof|formula|summary|card|content)(?:_|$)",
    re.I,
)
_SEMANTIC_COLOR_TOKEN_NAMES = frozenset({
    "TITLE_COLOR",
    "TEXT_COLOR",
    "PRIMARY_TEXT",
    "SECONDARY_TEXT",
    "MUTED_TEXT",
    "MUTED_COLOR",
    "FORMULA_COLOR",
    "MAIN_COLOR",
    "ACCENT_COLOR",
    "SECONDARY_COLOR",
    "ANNOTATION_COLOR",
    "LINE_COLOR",
    "POINT_COLOR",
    "LABEL_COLOR",
    "AUX_LINE_COLOR",
    "HIGHLIGHT_COLOR",
    "SURFACE_COLOR",
})
_RAW_MANIM_COLOR_CONSTANTS = frozenset({
    "WHITE",
    "BLACK",
    "RED",
    "GREEN",
    "BLUE",
    "YELLOW",
    "GOLD",
    "ORANGE",
    "PINK",
    "PURPLE",
    "TEAL",
    "GREY",
    "GRAY",
    "DARK_GRAY",
    "LIGHT_GRAY",
    "RED_A",
    "RED_B",
    "RED_C",
    "RED_D",
    "RED_E",
    "BLUE_A",
    "BLUE_B",
    "BLUE_C",
    "BLUE_D",
    "BLUE_E",
    "GREEN_A",
    "GREEN_B",
    "GREEN_C",
    "GREEN_D",
    "GREEN_E",
    "GREY_A",
    "GREY_B",
    "GREY_C",
    "GREY_D",
    "GREY_E",
    "GRAY_A",
    "GRAY_B",
    "GRAY_C",
    "GRAY_D",
    "GRAY_E",
})


