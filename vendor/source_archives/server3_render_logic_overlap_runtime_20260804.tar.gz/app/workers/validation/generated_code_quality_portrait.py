import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _portrait_tiny_font_size_issues(
    source: str,
    *,
    is_portrait: bool | None,
) -> list[GeneratedCodeQualityIssue]:
    if is_portrait is not True and not _looks_like_portrait_source(source):
        return []
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen_lines: set[int] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        helper_name = _call_helper_name(node)
        if helper_name not in _TEXT_CONSTRUCTOR_NAMES | _SAFE_TEXT_METHOD_NAMES:
            continue
        font_size = _numeric_keyword_value(node, "font_size")
        if font_size is None or font_size >= _PORTRAIT_TINY_FONT_THRESHOLD:
            continue
        line = getattr(node, "lineno", 1)
        if line in seen_lines:
            continue
        seen_lines.add(line)
        issues.append(
            GeneratedCodeQualityIssue(
                code="portrait_tiny_font_size",
                severity="error",
                message=(
                    "竖屏 9:16 中 Text/MathTex 字号低于 24，手机端容易变成缩略图；"
                    "请放大字号或拆分画面。"
                ),
                line=line,
                evidence=f"{helper_name}(font_size={font_size:g})",
            )
        )
    return issues


def _plain_text_prime_label_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_helper_name(node) != "Text":
            continue
        if not node.args or not isinstance(node.args[0], ast.Constant):
            continue
        value = node.args[0].value
        if not isinstance(value, str):
            continue
        match = _POINT_PRIME_LABEL_RE.match(value.strip())
        if not match:
            continue
        letter = match.group(1)
        issues.append(
            GeneratedCodeQualityIssue(
                code="geometry_prime_label_text",
                severity="error",
                message=(
                    "几何像点标签 C' / A' 不能用 Text 普通引号；"
                    f"请改成 MathTex(r\"{letter}^{{\\prime}}\")，让撇号成为上标。"
                ),
                line=getattr(node, "lineno", 1),
                evidence=f'Text("{value}")',
            )
        )
    return issues


def _looks_like_portrait_source(source: str) -> bool:
    return any(
        marker in source
        for marker in (
            "config.pixel_height = 1920",
            "config.frame_height = 14.22",
            "portrait_title(",
            "portrait_formula(",
            "竖屏 9:16",
        )
    )


def _call_helper_name(call: ast.Call) -> str:
    func = call.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _numeric_keyword_value(call: ast.Call, keyword_name: str) -> float | None:
    for keyword in call.keywords:
        if keyword.arg != keyword_name:
            continue
        value = keyword.value
        if isinstance(value, ast.Constant) and isinstance(value.value, (int, float)):
            return float(value.value)
        if (
            isinstance(value, ast.UnaryOp)
            and isinstance(value.op, ast.USub)
            and isinstance(value.operand, ast.Constant)
            and isinstance(value.operand.value, (int, float))
        ):
            return -float(value.operand.value)
    return None


