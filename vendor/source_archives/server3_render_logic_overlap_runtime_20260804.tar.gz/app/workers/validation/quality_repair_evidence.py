"""Normalize heterogeneous quality evidence into stable dictionaries."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import asdict, is_dataclass
from typing import Any

from .quality_repair_contracts import RepairLane

def _normalize_lane(lane: RepairLane | str) -> RepairLane:
    if isinstance(lane, RepairLane):
        return lane
    try:
        return RepairLane(str(lane))
    except ValueError as exc:
        allowed = ", ".join(item.value for item in RepairLane)
        raise ValueError(
            f"unknown repair lane {lane!r}; expected one of: {allowed}"
        ) from exc


def _normalize_issues(
    issue_or_issues: Mapping[str, Any] | Iterable[Mapping[str, Any]] | Any,
) -> list[dict[str, Any]]:
    if issue_or_issues is None:
        return []
    if _is_issue_mapping(issue_or_issues) or _looks_like_issue_object(issue_or_issues):
        return [_issue_to_dict(issue_or_issues)]
    if isinstance(issue_or_issues, Iterable) and not isinstance(
        issue_or_issues,
        (str, bytes),
    ):
        return [
            _issue_to_dict(issue)
            for issue in issue_or_issues
            if issue is not None
        ]
    return [_issue_to_dict(issue_or_issues)]


def _is_issue_mapping(value: Any) -> bool:
    return isinstance(value, Mapping)


def _looks_like_issue_object(value: Any) -> bool:
    return is_dataclass(value) or hasattr(value, "to_dict")


def _issue_to_dict(issue: Any) -> dict[str, Any]:
    if isinstance(issue, Mapping):
        return dict(issue)
    if is_dataclass(issue):
        return asdict(issue)
    to_dict = getattr(issue, "to_dict", None)
    if callable(to_dict):
        converted = to_dict()
        if isinstance(converted, Mapping):
            return dict(converted)
    return {
        key: getattr(issue, key)
        for key in (
            "code",
            "severity",
            "confidence",
            "hard_error",
            "policy_bucket",
            "repairable",
            "needs_repair",
            "final_action",
            "evidence",
        )
        if hasattr(issue, key)
    }

def _text(value: Any) -> str:
    return str(value or "").strip().lower()


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return bool(value)


def _float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _reason_for_issue(issue: Mapping[str, Any]) -> str:
    code = str(issue.get("code") or "quality_issue").strip()
    evidence = str(issue.get("evidence") or "").strip()
    if evidence:
        return f"{code}: {evidence[:180]}"
    return code
