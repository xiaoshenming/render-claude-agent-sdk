import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _geometry_dict_key_not_local_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef) or node.name != "construct":
            continue
        visitor = _GeometryDictKeyVisitor(source)
        for statement in node.body:
            visitor.visit(statement)
        issues.extend(visitor.issues)
    return issues


class _GeometryDictKeyVisitor(ast.NodeVisitor):
    def __init__(self, source: str) -> None:
        self.source = source
        self.local_keys: dict[str, set[str]] = {
            name: set() for name in _GEO_MODEL_DICT_NAMES
        }
        self.issues: list[GeneratedCodeQualityIssue] = []
        self._seen: set[tuple[str, int]] = set()

    def visit_Assign(self, node: ast.Assign) -> None:
        self.visit(node.value)
        for target in node.targets:
            self._record_assignment_target(target, node.value)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            self.visit(node.value)
        self._record_assignment_target(node.target, node.value)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self.visit(node.value)
        self._record_subscript_target(node.target)

    def visit_For(self, node: ast.For) -> None:
        self.visit(node.iter)
        for statement in node.body:
            self.visit(statement)
        for statement in node.orelse:
            self.visit(statement)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        return

    def visit_Lambda(self, node: ast.Lambda) -> None:
        return

    def visit_Subscript(self, node: ast.Subscript) -> None:
        name_key = _geo_model_subscript_name_key(node)
        if name_key is not None:
            dict_name, key = name_key
            if key not in self.local_keys.setdefault(dict_name, set()):
                line = getattr(node, "lineno", 1)
                evidence = _call_evidence(self.source, node)
                dedupe_key = (evidence, line)
                if dedupe_key not in self._seen:
                    self._seen.add(dedupe_key)
                    self.issues.append(
                        GeneratedCodeQualityIssue(
                            code="geometry_dict_key_not_local",
                            severity="error",
                            message=(
                                f"{dict_name}[{key!r}] 在当前 construct() 内访问前没有本地赋值；"
                                "首轮生成应使用本地变量或先完整填充 dict key。"
                            ),
                            line=line,
                            evidence=evidence,
                            failure_code="geometry_dict_key_not_local",
                        )
                    )
            return
        self.generic_visit(node)

    def _record_assignment_target(
        self,
        target: ast.AST,
        value: ast.AST | None,
    ) -> None:
        if isinstance(target, ast.Name) and target.id in _GEO_MODEL_DICT_NAMES:
            self.local_keys[target.id] = _literal_dict_string_keys(value)
            return
        self._record_subscript_target(target)

    def _record_subscript_target(self, target: ast.AST) -> None:
        name_key = _geo_model_subscript_name_key(target)
        if name_key is None:
            return
        dict_name, key = name_key
        self.local_keys.setdefault(dict_name, set()).add(key)


def _literal_dict_string_keys(node: ast.AST | None) -> set[str]:
    if not isinstance(node, ast.Dict):
        return set()
    keys: set[str] = set()
    for key_node in node.keys:
        if isinstance(key_node, ast.Constant) and isinstance(key_node.value, str):
            keys.add(key_node.value)
    return keys


def _geo_model_subscript_name_key(node: ast.AST) -> tuple[str, str] | None:
    if not isinstance(node, ast.Subscript):
        return None
    if not isinstance(node.value, ast.Name):
        return None
    dict_name = node.value.id
    if dict_name not in _GEO_MODEL_DICT_NAMES:
        return None
    slice_node = node.slice
    if isinstance(slice_node, ast.Constant) and isinstance(slice_node.value, str):
        return dict_name, slice_node.value
    return None


