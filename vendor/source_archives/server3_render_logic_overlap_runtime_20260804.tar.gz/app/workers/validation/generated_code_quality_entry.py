import re

from .generated_code_quality_models import GeneratedCodeQualityIssue

def blocking_static_contract_codes(
    *,
    enable_tts: bool | None = None,
) -> frozenset[str]:
    """Return static issue codes that must block generated code before render.

    These are first-pass generated-code contract failures. They intentionally
    trigger rewrite/error handling instead of pre-render code repair.
    """
    del enable_tts
    return _FIRST_PASS_REWRITE_STATIC_CONTRACT_CODES


_DIRECT_POSITIONING_METHODS = {"move_to", "next_to", "shift", "to_edge", "arrange"}
_DENSE_DIRECT_POSITIONING_THRESHOLD = 12
_DENSE_TEXT_OBJECT_THRESHOLD = 4
_PORTRAIT_CONCEPT_TOKENS = ("AA", "SAS", "SSS", "ASA", "AAS", "HL")
_POINT_PRIME_LABEL_RE = re.compile(r"^([A-Z])(?:['\u2019\u2018\u2032])$")
_PORTRAIT_HEADER_VAR_RE = re.compile(r"(?:^|_)(?:title|subtitle|heading|subheading|hook|headline)(?:_|$)", re.I)
_BASE_CONFIG_SCENE_DEF_RE = re.compile(
    r"^class\s+BaseConfigScene\s*\((?P<bases>[^)]*)\)\s*:",
    re.M,
)
_THREED_SCENE_BASE_RE = re.compile(
    r"^class\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\bThreeDScene\b[^)]*\)\s*:",
    re.M,
)
_THREED_CAMERA_SETUP_RE = re.compile(
    r"\b(?:self\.)?(?:set_camera_orientation|move_camera|begin_ambient_camera_rotation)\s*\("
)
_FIX_IN_FRAME_METHOD_RE = re.compile(r"\.[ \t]*fix_in_frame\s*\(")
_THREED_CAMERA_ANIMATE_RE = re.compile(r"\bself\.camera\.animate\b")
_THREED_CAMERA_FRAME_RE = re.compile(r"\bself\.camera\.frame\b")
_THREED_CAMERA_SET_EULER_RE = re.compile(r"\bself\.camera\.set_euler_angles\s*\(")
_PARAMETRIC_SURFACE_RE = re.compile(r"\bParametricSurface\s*\(")
_RIGHT_TRIANGLE_CONTEXT_RE = re.compile(
    r"(right\s*_?\s*triangle|righttriangle|pythagorean|勾股|毕达哥拉斯|"
    r"直角三角|直角边|斜边|draw_right_triangle|right_angle|RightAngle)",
    re.I,
)
_CIRCLE_AREA_CONTEXT_RE = re.compile(
    r"(circle\s*area|CircleArea|圆\s*的?\s*面积|圆面积|"
    r"\\pi\s*r|πr|平行四边形|parallelogram)",
    re.I,
)
_CIRCLE_SECTOR_COUNT_RE = re.compile(
    r"(?m)^\s*(?:num_sectors|n_sectors|sector_count|num_pieces|pieces)\s*=\s*(\d+)\b"
)
_CIRCLE_HALF_CHORD_ASSIGN_RE = re.compile(
    r"(?m)^\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
    r"[A-Za-z_][A-Za-z0-9_]*\s*\*\s*(?:np\.)?sin\s*\("
    r"\s*[A-Za-z_][A-Za-z0-9_]*\s*/\s*2\s*\)"
)
_SIDE_LABEL_VAR_RE = re.compile(
    r"^(?:label_[abc]|[abc]_label|side_[abc]_label|leg_[abc]_label|"
    r"hypo(?:tenuse)?_?label|label_hypo(?:tenuse)?)$",
    re.I,
)
_PYTHAGOREAN_SQUARE_VAR_RE = re.compile(
    r"(?:^|_)(?:square|sq)_(?P<label>[abc])(?:_|$)|"
    r"(?:^|_)(?P<label_alt>[abc])_(?:square|sq)(?:_|$)",
    re.I,
)
_DIRECTION_NAME_RE = r"(?:LEFT|RIGHT|UP|DOWN)"
_VOICEOVER_SEGMENT_MAX_CJK_CHARS = 45
_PORTRAIT_TINY_FONT_THRESHOLD = 24
_TEXT_FORMULA_TINY_SCALE_THRESHOLD = 0.75
_CORE_VISUAL_SEMANTIC_ICON_RE = re.compile(
    r"(?ms)^\s*def\s+(?P<helper>get_rope|create_grid_visual)\s*\([^)]*\):"
    r"(?P<body>.{0,1600}?return\s+self\._semantic_visual_icon\s*\(\s*"
    r"(?P<label>['\"](?:Rope|Grid Visual)['\"])\s*,?)"
)
_TEXT_HELPER_NAME_RE = re.compile(
    r"(?:^|_)(?:text|title|subtitle|caption|label|sentence|content|cjk|note)(?:_|$)",
    re.I,
)
_TEXT_FALLBACK_LABEL_RE = re.compile(
    r"(?:text|title|subtitle|caption|label|sentence|content|cjk|card|line)",
    re.I,
)
_VISIBLE_FALLBACK_CALL_NAMES = frozenset({
    "_mathpi_fallback_icon",
    "_mathpi_runtime_visual_icon",
})

