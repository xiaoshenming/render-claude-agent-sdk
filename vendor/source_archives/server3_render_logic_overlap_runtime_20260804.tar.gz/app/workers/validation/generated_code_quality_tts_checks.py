"""TTS contract checks for generated scenes."""
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue
from app.workers.validation.generated_code_quality_helpers import (
    _missing_voiceover_scene_import_line, _missing_required_voiceover_block_line,
)


def _append_tts_contract_issues(source, issues, *, enable_tts=None):
    import_line = _missing_voiceover_scene_import_line(source, enable_tts=enable_tts)
    if import_line:
        issues.append(GeneratedCodeQualityIssue(
            code="missing_voiceover_scene_import", severity="error",
            message="TTS/voiceover 代码未显式导入 VoiceoverScene，渲染时会触发 NameError 或缺少 voiceover 方法。",
            line=import_line, evidence="from manim_voiceover import VoiceoverScene",
        ))
    block_line = _missing_required_voiceover_block_line(source, enable_tts=enable_tts)
    if block_line:
        issues.append(GeneratedCodeQualityIssue(
            code="tts_voiceover_block_missing", severity="error",
            message="启用 TTS 的视频没有任何真实 voiceover 块，会渲染成无音频视频。",
            line=block_line, evidence="with self.voiceover(text=...) as tracker",
        ))
    return issues
