import ast

def _voiceover_call_text(context_exprs: object) -> str | None:
    for expr in context_exprs:
        if not _is_self_voiceover_call(expr):
            continue
        for keyword in expr.keywords:
            if keyword.arg == "text":
                return _literal_string_value(keyword.value)
    return None


def _literal_string_value(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        parts: list[str] = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
            else:
                return None
        return "".join(parts)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _literal_string_value(node.left)
        right = _literal_string_value(node.right)
        if left is not None and right is not None:
            return left + right
    return None


def _clean_voiceover_text(text: str) -> str:
    return re.sub(r"<bookmark\b[^>]*?/?>", "", str(text))


def _count_cjk_chars(text: str) -> int:
    return sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")


