import ast
import math
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _literal_triangle_vertices(
    tree: ast.AST,
) -> dict[str, tuple[float, float, float]] | None:
    env: dict[str, tuple[float, float, float]] = {
        "ORIGIN": (0.0, 0.0, 0.0),
        "UP": (0.0, 1.0, 0.0),
        "DOWN": (0.0, -1.0, 0.0),
        "LEFT": (-1.0, 0.0, 0.0),
        "RIGHT": (1.0, 0.0, 0.0),
        "IN": (0.0, 0.0, -1.0),
        "OUT": (0.0, 0.0, 1.0),
    }
    assignments = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
    ]
    assignments.sort(key=lambda node: getattr(node, "lineno", 0))
    for node in assignments:
        target = node.targets[0].id
        value = _eval_vector_expr(node.value, env)
        if value is not None:
            env[target] = value
    if not all(name in env for name in ("A", "B", "C")):
        return None
    return {name: env[name] for name in ("A", "B", "C")}


def _eval_vector_expr(
    node: ast.AST,
    env: dict[str, tuple[float, float, float]],
) -> tuple[float, float, float] | None:
    if isinstance(node, ast.Name):
        return env.get(node.id)
    if isinstance(node, (ast.List, ast.Tuple)):
        values = [_literal_number(item) for item in node.elts]
        if len(values) not in {2, 3} or any(value is None for value in values):
            return None
        nums = [float(value) for value in values if value is not None]
        if len(nums) == 2:
            nums.append(0.0)
        return (nums[0], nums[1], nums[2])
    if isinstance(node, ast.Call) and _call_name(node.func) == "array" and node.args:
        return _eval_vector_expr(node.args[0], env)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        value = _eval_vector_expr(node.operand, env)
        if value is None:
            return None
        return (-value[0], -value[1], -value[2])
    if isinstance(node, ast.BinOp):
        left = _eval_vector_expr(node.left, env)
        right = _eval_vector_expr(node.right, env)
        left_number = _literal_number(node.left)
        right_number = _literal_number(node.right)
        if isinstance(node.op, ast.Add) and left is not None and right is not None:
            return (left[0] + right[0], left[1] + right[1], left[2] + right[2])
        if isinstance(node.op, ast.Sub) and left is not None and right is not None:
            return (left[0] - right[0], left[1] - right[1], left[2] - right[2])
        if isinstance(node.op, ast.Mult):
            if left is not None and right_number is not None:
                return (
                    left[0] * right_number,
                    left[1] * right_number,
                    left[2] * right_number,
                )
            if right is not None and left_number is not None:
                return (
                    right[0] * left_number,
                    right[1] * left_number,
                    right[2] * left_number,
                )
        if (
            isinstance(node.op, ast.Div)
            and left is not None
            and right_number not in {None, 0.0}
        ):
            return (
                left[0] / right_number,
                left[1] / right_number,
                left[2] / right_number,
            )
    return None


def _literal_vertices_form_right_triangle(
    vertices: dict[str, tuple[float, float, float]],
) -> bool:
    for vertex in ("A", "B", "C"):
        others = [name for name in ("A", "B", "C") if name != vertex]
        v1 = _vector_sub(vertices[others[0]], vertices[vertex])
        v2 = _vector_sub(vertices[others[1]], vertices[vertex])
        if _vector_length(v1) < 1e-9 or _vector_length(v2) < 1e-9:
            continue
        dot = abs(_vector_dot(v1, v2))
        scale = _vector_length(v1) * _vector_length(v2)
        if dot <= max(1e-6, scale * 1e-4):
            return True
    return False


def _numeric_midpoint_side_labels(
    tree: ast.AST,
    vertices: dict[str, tuple[float, float, float]],
) -> list[tuple[str, float, float, int, str]]:
    text_vars: dict[str, float] = {}
    labels: list[tuple[str, float, float, int, str]] = []
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)]
    for node in calls:
        label_value = _numeric_text_value_from_expr(node, text_vars)
        if label_value is None:
            continue
        parent_assign = _single_target_assignment_for_value(tree, node)
        if parent_assign is not None:
            text_vars[parent_assign] = label_value
        if not isinstance(node.func, ast.Attribute) or node.func.attr != "move_to":
            continue
        if not node.args:
            continue
        moved_label_value = _numeric_text_value_from_expr(node.func.value, text_vars)
        if moved_label_value is None or moved_label_value <= 0:
            continue
        pair = _midpoint_vertex_pair(node.args[0])
        if pair is None:
            continue
        left, right = pair
        if left not in vertices or right not in vertices:
            continue
        length = _distance(vertices[left], vertices[right])
        label_name = _single_target_assignment_for_value(tree, node)
        if label_name is None:
            label_name = f"Text({moved_label_value:g})"
        labels.append(
            (
                _side_key(left, right),
                moved_label_value,
                length,
                getattr(node, "lineno", 1),
                label_name,
            )
        )
    return labels


