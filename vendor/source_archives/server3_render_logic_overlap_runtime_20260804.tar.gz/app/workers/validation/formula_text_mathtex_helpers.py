"""MathTex 调用源码生成辅助。"""
import ast

def mathtex_call_source(code: str, call: ast.Call, payload: str, normalize, safe_keywords: set[str]) -> str:
    parts = [repr(normalize(payload))]
    for keyword in call.keywords:
        if keyword.arg not in safe_keywords:
            continue
        value_source = ast.get_source_segment(code, keyword.value)
        if value_source:
            parts.append(f"{keyword.arg}={value_source}")
    return f"MathTex({', '.join(parts)})"

def dynamic_mathtex_call_source(code, call, parent_map, deps, safe_keywords):
    payload_node = deps["first_payload"](call)
    if payload_node is None or deps["stringish"](payload_node) is not None:
        return ""
    expr_source = (ast.get_source_segment(code, payload_node) or deps["unparse"](payload_node) or "").strip()
    if not expr_source or not deps["looks_dynamic"](call, payload_node, expr_source, code):
        return ""
    if not deps["repairable"](call, payload_node, expr_source, code, deps["enclosing"](call, parent_map or {})):
        return ""
    math_expr = deps["expression"](code, payload_node)
    if not math_expr:
        return ""
    parts = [math_expr]
    for keyword in call.keywords:
        if keyword.arg in safe_keywords:
            value_source = ast.get_source_segment(code, keyword.value)
            if value_source:
                parts.append(f"{keyword.arg}={value_source}")
    return f"MathTex({', '.join(parts)})"

def inline_vgroup_call_source(code, call, segments, safe_keywords) -> str:
    styles = []
    for keyword in call.keywords:
        if keyword.arg in {"text", "content"}: continue
        if keyword.arg is None: return ""
        if keyword.arg in safe_keywords:
            value = ast.get_source_segment(code, keyword.value)
            if value: styles.append(f"{keyword.arg}={value}")
    kwargs = f", {', '.join(styles)}" if styles else ""
    items = [f"MathTex({value!r}{kwargs})" if kind == "math" else f"Text({value!r}{kwargs})" for kind, value in segments]
    return f"VGroup({', '.join(items)}).arrange(RIGHT, buff=0.18)"

def inline_math_text_call_source(code, call, payload, use_inline_helper, segments_fn, vgroup_fn) -> str:
    segments = segments_fn(payload)
    if not segments: return ""
    if not use_inline_helper: return vgroup_fn(code, call, segments)
    parts = [f"('math', {value!r})" if kind == "math" else repr(value) for kind, value in segments]
    for keyword in call.keywords:
        if keyword.arg in {"text", "content"}: continue
        if keyword.arg is None: return ""
        value = ast.get_source_segment(code, keyword.value)
        if value: parts.append(f"{keyword.arg}={value}")
    return f"self.inline_math_text({', '.join(parts)})"
