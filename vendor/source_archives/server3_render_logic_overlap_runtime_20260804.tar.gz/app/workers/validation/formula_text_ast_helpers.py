"""公式文本合同的 AST 基础工具。"""
import ast

def expr_names(node: ast.AST) -> list[str]:
    names = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            names.append(child.id)
        elif isinstance(child, ast.Attribute):
            names.append(child.attr)
    return names

def payload_is_indexed_value(node: ast.AST, call_name) -> bool:
    current = node
    while isinstance(current, ast.Call) and call_name(current.func) == "str" and current.args:
        current = current.args[0]
    return isinstance(current, ast.Subscript)

def call_uses_formula_color(call: ast.Call, source: str, pattern) -> bool:
    call_source = ast.get_source_segment(source, call) or safe_unparse(call)
    return bool(pattern.search(str(call_source or "")))

def strip_replace_chain(node: ast.AST) -> ast.AST:
    current = node
    while isinstance(current, ast.Call) and isinstance(current.func, ast.Attribute) and current.func.attr == "replace":
        current = current.func.value
    return current

def dynamic_expression_source(code: str, node: ast.AST, unparse, is_str) -> str:
    base = strip_replace_chain(node)
    source = (ast.get_source_segment(code, base) or unparse(base) or "").strip()
    if not source: return ""
    return source if is_str(base) else f"str({source})"

def first_text_payload(call: ast.Call, stringish) -> str | None:
    if call.args:
        value = stringish(call.args[0])
        if value is not None: return value
    for keyword in call.keywords:
        if keyword.arg in {"text", "content"}:
            value = stringish(keyword.value)
            if value is not None: return value
    return None

def first_text_payload_node(call: ast.Call) -> ast.AST | None:
    if call.args: return call.args[0]
    for keyword in call.keywords:
        if keyword.arg in {"text", "content"}: return keyword.value
    return None

def looks_like_dynamic_formula_payload(call, payload_node, expr_source, source, source_re, name_re, names, indexed, colored) -> bool:
    if source_re.search(expr_source): return True
    if any(name_re.search(name) for name in names(payload_node)): return True
    return indexed(payload_node) and colored(call, source)

def first_dynamic_formula_payload(call, source, first_node, stringish, unparse, looks_dynamic) -> str | None:
    payload_node = first_node(call)
    if payload_node is None or stringish(payload_node) is not None: return None
    expr_source = (ast.get_source_segment(source, payload_node) or unparse(payload_node) or "").strip()
    if not expr_source or not looks_dynamic(call, payload_node, expr_source, source): return None
    return f"<dynamic:{expr_source}>"

def safe_unparse(node: ast.AST) -> str:
    try:
        return ast.unparse(node)
    except Exception:
        return ""

def is_str_call(node: ast.AST) -> bool:
    return isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str" and len(node.args) == 1
