"""Aliyun content-security client with existing fail-open transport semantics."""
import json
import logging
from typing import Tuple

from alibabacloud_green20220302.client import Client as GreenClient
from alibabacloud_green20220302 import models as green_models
from alibabacloud_tea_openapi.models import Config as GreenConfig
from app.core.config import settings

logger=logging.getLogger(__name__)

def check_content_security(content: str) -> Tuple[bool, str]:
    """使用阿里云安全护栏检查内容。

    Returns:
        (is_safe, error_message) — API 异常或凭证缺失时默认通过。
    """
    access_key_id = (
        settings.ALIYUN_ACCESS_KEY_ID
        or settings.ALIBABA_CLOUD_ACCESS_KEY_ID
    )
    access_key_secret = (
        settings.ALIYUN_ACCESS_KEY_SECRET
        or settings.ALIBABA_CLOUD_ACCESS_KEY_SECRET
    )

    if not access_key_id or not access_key_secret:
        logger.warning("[SECURITY] 阿里云安全护栏未配置，跳过输出端审核")
        return True, ""

    try:
        config = GreenConfig(
            access_key_id=access_key_id,
            access_key_secret=access_key_secret,
            connect_timeout=10000,
            read_timeout=3000,
            region_id="cn-hangzhou",
            endpoint="green-cip.cn-hangzhou.aliyuncs.com",
        )
        client = GreenClient(config)
        service_parameters = {"content": content}
        request = green_models.TextModerationPlusRequest(
            service="query_security_check",
            service_parameters=json.dumps(service_parameters),
        )
        response = client.text_moderation_plus(request)
        if response.status_code == 200:
            result = response.body
            if hasattr(result, "data") and result.data:
                data = result.data
                if hasattr(data, "result") and data.result:
                    for item in data.result:
                        if (
                            hasattr(item, "label")
                            and item.label
                            and item.label != "nonLabel"
                        ):
                            logger.warning(
                                f"Content security check failed: {item.label}")
                            return False, f"内容安全检查未通过: {item.label}"
            logger.info("Content security check passed")
            return True, ""
        else:
            logger.warning(
                f"Security check API returned non-200: {response.status_code}")
            return True, ""
    except Exception as e:
        logger.warning(f"Content security check error: {e}")
        return True, ""
