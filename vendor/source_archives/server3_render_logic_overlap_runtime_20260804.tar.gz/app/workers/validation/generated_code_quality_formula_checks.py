"""公式文本与伪文本质量检查。"""

from app.workers.validation.generated_code_quality_helpers import (
    _plain_text_prime_label_issues,
    _python_tuple_text_artifact_issues,
)
from app.workers.validation.formula_text_contract import inspect_formula_text_violations
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue


def _append_formula_quality_issues(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    for violation in inspect_formula_text_violations(source):
        issue_code = getattr(violation, "code", None) or "formula_text_not_mathtex"
        message = (
            "inline_math_text 被传入单个 parts 列表，helper 会把整段列表当普通文本显示；"
            "应改为 inline_math_text((\"text\", ...), (\"math\", ...), ...)。"
            if issue_code == "formula_inline_math_text_single_list_parts"
            else "公式-like 字符串被放入 Text/safe_text_box，容易按源码文本显示；应使用 MathTex，或拆成 Text 中文说明 + MathTex 公式。"
        )
        issues.append(GeneratedCodeQualityIssue(
            code=issue_code, severity="error", message=message,
            line=violation.line, evidence=violation.reason_fragment(), failure_code=issue_code,
        ))
    issues.extend(_python_tuple_text_artifact_issues(source))
    issues.extend(_plain_text_prime_label_issues(source))
