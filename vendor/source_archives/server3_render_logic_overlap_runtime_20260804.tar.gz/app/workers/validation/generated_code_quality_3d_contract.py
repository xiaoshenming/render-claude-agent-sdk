import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _should_check_3d_text(source: str, is_3d: bool | None) -> bool:
    if is_3d is not None:
        return is_3d
    return "ThreeDScene" in source or "move_camera(" in source


def _mathpi_3d_scene_contract_missing_line(
    source: str,
    *,
    is_3d: bool | None,
) -> int:
    if is_3d is not True:
        return 0
    base_match = _BASE_CONFIG_SCENE_DEF_RE.search(source)
    if not base_match:
        return 0
    if _THREED_SCENE_BASE_RE.search(source):
        return 0
    return _line_no(source, base_match.start())


def _mathpi_3d_camera_contract_missing_line(
    source: str,
    *,
    is_3d: bool | None,
) -> int:
    if is_3d is not True:
        return 0
    base_match = _BASE_CONFIG_SCENE_DEF_RE.search(source)
    if not base_match:
        return 0
    if _THREED_CAMERA_SETUP_RE.search(source):
        return 0
    return _line_no(source, base_match.start())


def _mathpi_3d_default_camera_oblique_line(
    source: str,
    *,
    is_3d: bool | None,
) -> int:
    if is_3d is not True:
        return 0
    lines = source.splitlines()
    class_range = _class_range(lines, "BaseConfigScene")
    if class_range is None:
        return 0
    class_start, class_end, body_indent = class_range
    for method_name in ("setup_layout", "setup"):
        method_range = _method_range(
            lines,
            class_start=class_start,
            class_end=class_end,
            body_indent=body_indent,
            method_name=method_name,
        )
        if method_range is None:
            continue
        method_start, method_end = method_range
        for index in range(method_start + 1, method_end):
            line = lines[index]
            if "set_camera_orientation(" not in re.sub(r"\s+", "", line):
                continue
            if _is_front_facing_3d_camera_line(line):
                continue
            return index + 1
    return 0


