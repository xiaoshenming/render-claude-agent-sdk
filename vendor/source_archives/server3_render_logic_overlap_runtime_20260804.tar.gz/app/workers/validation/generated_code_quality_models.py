from dataclasses import dataclass

@dataclass(frozen=True)
class GeneratedCodeQualityIssue:
    code: str
    severity: str
    message: str
    line: int
    evidence: str
    failure_code: str | None = None
    risk_flags: tuple[str, ...] = ()

