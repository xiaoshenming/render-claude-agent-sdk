"""First-frame reveal and pure-text layout checks."""

from app.workers.validation.generated_code_quality_helpers import (
    _bulk_pre_reveal_add_line,
    _first_line,
    _is_pure_text_split_layout,
    _pre_reveal_visible_object_line,
)
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue


def _append_reveal_layout_issues(source, issues):
    if _is_pure_text_split_layout(source):
        issues.append(GeneratedCodeQualityIssue(
            code="pure_text_split_layout_risk", severity="risk",
            message="纯文字 Scene 仍使用分栏槽位，容易保留空白图槽或左偏。",
            line=_first_line(source, "self.show_text("),
            evidence="self.show_text(...) without visual primitives",
        ))
    bulk_line = _bulk_pre_reveal_add_line(source)
    if bulk_line:
        issues.append(GeneratedCodeQualityIssue(
            code="bulk_pre_reveal_add", severity="error",
            message="首个动画前一次性 add 多个文字/公式对象，违反逐步揭示合同。",
            line=bulk_line, evidence="self.add(...) before first self.play(...)",
        ))
    visible_line = _pre_reveal_visible_object_line(source)
    if visible_line:
        issues.append(GeneratedCodeQualityIssue(
            code="pre_reveal_visible_object", severity="error",
            message="对象在首个动画前已通过 add_visible/add 进入画面，随后又被 Create/Write/FadeIn，容易造成首帧完整画面闪现。",
            line=visible_line, evidence="add/add_visible(obj) before Create/Write/FadeIn(obj)",
        ))
    return issues
