"""公式文本规范化。"""
import re

_LATEX_TEXT_COMMAND_RE = re.compile(r"\\text\{([^{}]+)\}")
_LATEX_SPACING_COMMANDS = ("\\quad", "\\qquad", "\\,", "\\;", "\\:", "\\!")
_LATEX_TRAILING_BACKSLASH_BEFORE_CJK_RE = re.compile(r"\\\s*(?=[\u4e00-\u9fff])")

def normalize_formula_text_payload(text: str) -> str:
    compact = _LATEX_TEXT_COMMAND_RE.sub(lambda match: match.group(1), str(text or ""))
    for marker in _LATEX_SPACING_COMMANDS:
        compact = compact.replace(marker, " ")
    compact = _LATEX_TRAILING_BACKSLASH_BEFORE_CJK_RE.sub("", compact)
    return re.sub(r"[ \t]+", " ", compact).strip()
