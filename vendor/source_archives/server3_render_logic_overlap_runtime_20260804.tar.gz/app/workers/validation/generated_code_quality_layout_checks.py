"""Layout/API checks extracted from generated-code inspection."""

from app.workers.validation.generated_code_quality_helpers import (
    _next_to_alignment_misuse_line,
    _parametric_surface_misuse_line,
)
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue


def _append_layout_api_issues(source, issues):
    next_line = _next_to_alignment_misuse_line(source)
    if next_line:
        issues.append(GeneratedCodeQualityIssue(
            code="manim_next_to_alignment_misuse", severity="error",
            message="Manim Mobject.next_to(...) 不支持 alignment 参数；应改用 aligned_edge 或 next_to 后再 align_to。",
            line=next_line, evidence="replace next_to(..., alignment=...)",
        ))
    surface_line = _parametric_surface_misuse_line(source)
    if surface_line:
        issues.append(GeneratedCodeQualityIssue(
            code="manim_parametric_surface_misuse", severity="error",
            message="Manim 0.19 不提供 ParametricSurface；3D 曲面应使用 Surface(lambda u, v: ...)。",
            line=surface_line, evidence="replace ParametricSurface(...) with Surface(...)",
        ))
    return issues
