import logging
from .generated_code_quality_models import GeneratedCodeQualityIssue

def raise_for_tts_timing_blockers(code: str) -> None:
    """Fail closed on generated-code patterns known to create TTS gaps."""
    issues = [
        issue for issue in inspect_generated_code_quality(code, enable_tts=True)
        if issue.severity == "error" and issue.code in _TTS_TIMING_BLOCKER_CODES
    ]
    if not issues:
        return
    detail = "; ".join(
        f"{issue.code}@L{issue.line}:{issue.evidence}"
        for issue in issues[:5]
    )
    raise ValueError(f"TTS视听同步静态门禁失败: {detail}")


import logging

logger = logging.getLogger(__name__)


def try_auto_fix_formula_violations(
    code: str,
) -> tuple[str, list[str]]:
    """Attempt to auto-fix formula_text_not_mathtex violations.

    Returns (fixed_code, fix_descriptions). If no fixes were applied,
    returns the original code and an empty list.
    """
    from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue

    from app.workers.validation.formula_text_contract import (
        compile_formula_text_boundaries,
        rewrite_formula_text_payloads_to_mathtex,
    )

    # Phase 1: rewrite pure formula payloads (e.g. Text("a^2+b^2") -> MathTex("a^2+b^2"))
    fixed, fixes1 = rewrite_formula_text_payloads_to_mathtex(code)
    # Phase 2: split mixed prose/formula into inline math boundaries
    fixed, fixes2 = compile_formula_text_boundaries(fixed)
    all_fixes = fixes1 + fixes2
    if all_fixes:
        logger.info(
            f"[FORMULA_AUTO_FIX] 自动修复 {len(all_fixes)} 个公式问题: "
            f"{'; '.join(all_fixes[:5])}"
        )
    return fixed, all_fixes


def try_auto_fix_icon_text_box_fallbacks(
    code: str,
) -> tuple[str, list[str]]:
    """Auto-fix text-box icon fallbacks before failing the generated code."""
    from app.workers.repair.pre_render_fixes import pre_render_scan

    fixed, fixes = pre_render_scan(code)
    icon_fixes = [
        desc for desc in fixes
        if (
            "语义图标白框兜底改矢量" in desc
            or "_mathpi_fallback_icon矢量兜底补全" in desc
            or "文本helper圆点兜底改真实Text" in desc
            or "asset_icon补全" in desc
        )
    ]
    if icon_fixes:
        logger.info(
            f"[ICON_AUTO_FIX] 自动修复 {len(icon_fixes)} 个图标白框问题: "
            f"{'; '.join(icon_fixes[:5])}"
        )
    return fixed, icon_fixes


def raise_for_blocking_static_contracts(
    code: str,
    *,
    enable_tts: bool | None = None,
) -> None:
    """Fail closed for first-pass generated-code hard-gate issues."""
    issues = inspect_generated_code_quality(code, enable_tts=enable_tts)
    blocking_codes = blocking_static_contract_codes(enable_tts=enable_tts)
    blocking_issues = [
        issue for issue in issues
        if issue.severity == "error" and issue.code in blocking_codes
    ]
    if not blocking_issues:
        return
    detail = "; ".join(
        f"{issue.code}@L{issue.line}:{issue.evidence}"
        for issue in blocking_issues[:8]
    )
    raise ValueError(f"first_pass_contract_error: {detail}")


def raise_for_blocking_static_contracts_with_auto_fix(
    code: str,
    *,
    enable_tts: bool | None = None,
) -> str:
    """Apply deterministic fixes where possible, without rejecting diagnostics."""
    raise_for_blocking_static_contracts(code, enable_tts=enable_tts)
    issues = inspect_generated_code_quality(code, enable_tts=enable_tts)

    auto_fixable_codes = frozenset({
        "formula_text_not_mathtex",
        "semantic_visual_icon_text_box_fallback",
        "generated_icon_text_box_fallback",
        "core_text_helper_fallback_icon",
    })
    auto_fixable_issues = [i for i in issues if i.code in auto_fixable_codes]
    if not auto_fixable_issues:
        return code

    fixed_code = code
    fix_descs: list[str] = []
    formula_issues = [
        issue for issue in auto_fixable_issues
        if issue.code == "formula_text_not_mathtex"
    ]
    if formula_issues:
        fixed_code, formula_fix_descs = try_auto_fix_formula_violations(fixed_code)
        fix_descs.extend(formula_fix_descs)

    icon_issues = [
        issue for issue in auto_fixable_issues
        if issue.code in {
            "semantic_visual_icon_text_box_fallback",
            "generated_icon_text_box_fallback",
            "core_text_helper_fallback_icon",
        }
    ]
    if icon_issues:
        fixed_code, icon_fix_descs = try_auto_fix_icon_text_box_fallbacks(fixed_code)
        fix_descs.extend(icon_fix_descs)

    if fix_descs:
        return fixed_code

    return fixed_code


