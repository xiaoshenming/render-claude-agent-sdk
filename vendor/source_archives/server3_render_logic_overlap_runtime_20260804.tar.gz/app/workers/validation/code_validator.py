"""Compatibility facade for generated Manim code validation helpers.

Validation remains diagnostic-only here: this module preserves the existing
boolean-and-reason contract and does not introduce pipeline enforcement.
"""
# ruff: noqa: F401  # Preserve historical private imports for diagnostics/tests.

import logging

from .code_extraction import (
    _CN_PUNCT_MAP,
    _LATEX_TYPO_PATTERNS,
    extract_python_code,
    sanitize_chinese_punctuation,
    sanitize_latex_branch_typo,
)
from .code_scene_diagnostics import (
    _NUMBERED_SCENE_CLASS_RE,
    extract_all_scene_names,
    extract_class_name,
    extract_scene_class_code,
    extract_scene_standalone_code,
    extract_slice_header,
    extract_title_from_code,
    is_slice_mode,
)
from .code_shape_rules import (
    _SCENE_ANIMATION_CALL_RE,
    _SCENE_ANIMATION_METHODS,
    _has_scene_animation_call,
    validate_generated_code_shape,
)

logger = logging.getLogger(__name__)

__all__ = [
    "extract_all_scene_names",
    "extract_class_name",
    "extract_python_code",
    "extract_scene_class_code",
    "extract_scene_standalone_code",
    "extract_slice_header",
    "extract_title_from_code",
    "is_slice_mode",
    "sanitize_chinese_punctuation",
    "sanitize_latex_branch_typo",
    "validate_generated_code_shape",
]
