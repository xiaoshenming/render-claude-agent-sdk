from . import deterministic_guard as _guard

def parse_linear_grammar_middle(prompt):
    match = REVERSED_COEFFICIENT_VARIABLE_DIVISION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(4))
            if abs(denominator) <= 1e-9:
                return None
            return match.group(3), left_value * denominator / coefficient
    match = SIMPLE_LINEAR_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            variable = match.group(2)
            right_value = _parse_simple_number_value(match.group(3))
            if right_value is None:
                return None
            return variable, right_value / coefficient
    match = SIMPLE_COEFFICIENT_VARIABLE_DIVISION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                return None
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(6))
            if right_value is None:
                return None
            adjusted = right_value - offset if match.group(4) == "+" else right_value + offset
            return match.group(2), adjusted * denominator / coefficient
    match = REVERSED_COEFFICIENT_VARIABLE_DIVISION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(4))
            if abs(denominator) <= 1e-9:
                return None
            offset = _parse_simple_number_value(match.group(6))
            if offset is None:
                return None
            adjusted = left_value - offset if match.group(5) == "+" else left_value + offset
            return match.group(3), adjusted * denominator / coefficient
    return None
