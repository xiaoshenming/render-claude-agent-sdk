from . import deterministic_guard as _guard
_has_obvious_pythagorean_error = _guard._has_obvious_pythagorean_error
_issue = _guard._issue
_probability_range_issue = _guard._probability_range_issue

def _collect_target_math_issues(target: dict[str, Any], normalized_scope: str, user_prompt: str) -> list[MathLogicIssue]:
    issues: list[MathLogicIssue] = []
    scene_name = str(target.get("scene_name") or "")
    text = f"{target.get('statement') or ''}\n{target.get('target_code') or ''}"
    start_line = int(target.get("start_line") or 1)
    end_line = int(target.get("end_line") or start_line)
    if _has_obvious_pythagorean_error(text):
                issues.append(
                    _issue(
                        code="formula_error",
                        scene_name=scene_name,
                        evidence="勾股定理公式疑似把斜边平方放到了直角边一侧。",
                        start_line=start_line,
                        end_line=end_line,
                        target=target,
                    )
                )
    if normalized_scope == "all":
                probability_issue = _probability_range_issue(text)
                if probability_issue:
                    issues.append(
                        _issue(
                            code="probability_range_error",
                            scene_name=scene_name,
                            evidence=probability_issue,
                            start_line=start_line,
                            end_line=end_line,
                            target=target,
                        )
                    )
    return issues
