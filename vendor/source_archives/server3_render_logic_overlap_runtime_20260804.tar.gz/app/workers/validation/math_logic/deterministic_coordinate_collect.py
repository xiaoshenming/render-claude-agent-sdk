from . import deterministic_guard as _guard
_origin_ccw_90_coordinate_rotation_issue = _guard._origin_ccw_90_coordinate_rotation_issue
_area_partition_issue = _guard._area_partition_issue
_pythagorean_cut_fill_inner_square_issue = _guard._pythagorean_cut_fill_inner_square_issue
_issue = _guard._issue

def collect_coordinate_area_issues(text, user_prompt, scene_name, start_line, end_line, target):
    issues = []
    coordinate_rotation_issue = _origin_ccw_90_coordinate_rotation_issue(
        text,
        user_prompt,
    )
    if coordinate_rotation_issue:
        issues.append(
            _issue(
                code="formula_error",
                scene_name=scene_name,
                evidence=coordinate_rotation_issue["evidence"],
                start_line=start_line,
                end_line=end_line,
                target=target,
                suggested_fix=coordinate_rotation_issue["suggested_fix"],
                metadata=coordinate_rotation_issue["metadata"],
            )
        )
    area_issue = _area_partition_issue(text)
    if area_issue:
        issues.append(
            _issue(
                code="cut_fill_shape_deformation",
                scene_name=scene_name,
                evidence=area_issue,
                start_line=start_line,
                end_line=end_line,
                target=target,
            )
        )
    pythagorean_cut_fill_issue = _pythagorean_cut_fill_inner_square_issue(text)
    if pythagorean_cut_fill_issue:
        issues.append(
            _issue(
                code="cut_fill_shape_deformation",
                scene_name=scene_name,
                evidence=pythagorean_cut_fill_issue["evidence"],
                start_line=start_line,
                end_line=end_line,
                target=target,
                suggested_fix=pythagorean_cut_fill_issue["suggested_fix"],
                metadata=pythagorean_cut_fill_issue["metadata"],
            )
        )
        return issues
