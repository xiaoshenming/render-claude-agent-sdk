from . import deterministic_guard as _guard

def parse_linear_grammar_batch7(prompt):
    parsed_batch6 = parse_linear_grammar_batch6(prompt)
    if parsed_batch6 is not None:
            return parsed_batch6
    match = SIMPLE_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_AFFINE_EQUATION_RE.search(
            prompt
        )
    if match:
            inner_offset = _parse_simple_number_value(match.group(3))
            if inner_offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(4))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            tail_offset = _parse_simple_number_value(match.group(7))
            if tail_offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(8))
            if right_value is None:
                return None
            adjusted = right_value - tail_offset if match.group(6) == "+" else right_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(2) == "+"
                else inner_value + inner_offset
            )
            return match.group(1), expected
    match = (
            REVERSED_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_AFFINE_EQUATION_RE.search(
                prompt
            )
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            inner_offset = _parse_simple_number_value(match.group(4))
            if inner_offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(5))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            tail_offset = _parse_simple_number_value(match.group(8))
            if tail_offset is None:
                return None
            adjusted = left_value - tail_offset if match.group(7) == "+" else left_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(3) == "+"
                else inner_value + inner_offset
            )
            return match.group(2), expected
    match = SIMPLE_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_EQUATION_RE.search(
            prompt
        )
    if match:
            offset = _parse_simple_number_value(match.group(3))
            if offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(4))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(6))
            if right_value is None:
                return None
            inner_value = right_value * denominator / coefficient
            expected = inner_value - offset if match.group(2) == "+" else inner_value + offset
            return match.group(1), expected
    return None
