from __future__ import annotations

import asyncio
import json
import os
import re
import time
from typing import Any

from app.services.llm_service import get_llm_manager
from app.services.dedicated_llm_client import call_dedicated_chat_completion
from app.services.llm_call_tracer import LLMCallTracer
from app.prompts.prompt_compiler import compile_cacheable_segmented_prompt
try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover - dependency exists in runtime image
    AsyncOpenAI = None

from app.core.config import settings
from app.core.runtime_config.client import (
    is_runtime_settings_override,
    refresh_runtime_config_if_stale,
)
from app.workers.repair.repair_state import (
    BackhalfRepairBudget,
    record_backhalf_repair_call,
)

from .policy import HARD_ERROR_TYPES
from .schemas import MathLogicIssue, MathLogicReviewResult
from .reviewer_backend_pool import first_pool_model as _first_pool_model, parse_backend_pool as _parse_backend_pool
from .reviewer_config_helpers import (
    metadata_value as _metadata_value,
    confidence as _confidence,
    severity as _severity,
    review_model_name as _review_model_name,
    review_max_tokens as _review_max_tokens,
    dedicated_backend_configs as _dedicated_backend_configs,
    dedicated_backend_config as _dedicated_backend_config,
)

MATH_LOGIC_FAST_DEFAULT_MAX_TOKENS = 4096
MATH_LOGIC_FINAL_DEFAULT_MAX_TOKENS = 8192





FIGURE_LINES_ALLOWED_CODES = {
    "geometry_relation_error",
    "symbol_binding_error",
    "cut_fill_shape_deformation",
    "condition_error",
    "formula_error",
}

FIGURE_LINES_STRICT_CODES = {
    "geometry_relation_error",
    "symbol_binding_error",
    "cut_fill_shape_deformation",
}

FIGURE_LINES_GEOMETRY_KEYWORDS = {
    "Dot",
    "Line",
    "Arrow",
    "Polygon",
    "Triangle",
    "Circle",
    "Angle",
    "RightAngle",
    "Axes",
    "NumberPlane",
    "Transform",
    "ReplacementTransform",
    "MoveAlongPath",
    "rotate",
    "shift",
    "move_to",
    "become",
    "animate",
    "\\angle",
    "\\parallel",
    "\\perp",
    "\\triangle",
    "angle",
    "parallel",
    "perpendicular",
    "area",
    "坐标",
    "角",
    "面积",
    "垂直",
    "平行",
    "全等",
    "相似",
    "旋转",
    "平移",
    "反射",
    "翻折",
    "割补",
    "图形",
    "几何",
}



def _filter_issues_for_scope(
    issues: list[MathLogicIssue],
    *,
    targets: list[dict[str, Any]],
    scope: str,
) -> list[MathLogicIssue]:
    if _normalize_scope(scope) != "figure_lines":
        return issues
    return [
        issue
        for issue in issues
        if _is_allowed_figure_lines_issue(issue, targets=targets)
    ]
def _is_allowed_figure_lines_issue(
    issue: MathLogicIssue,
    *,
    targets: list[dict[str, Any]],
) -> bool:
    if issue.code not in FIGURE_LINES_ALLOWED_CODES:
        return False
    if issue.confidence < 0.90 or issue.severity != "high":
        return False
    if issue.needs_visual_check:
        return False
    if not _span_inside_targets(issue.code_span, targets):
        return False
    if issue.code in FIGURE_LINES_STRICT_CODES:
        return True
    return _issue_has_geometry_context(issue, targets=targets)
def _span_inside_targets(
    code_span: dict[str, Any] | None,
    targets: list[dict[str, Any]],
) -> bool:
    if not code_span:
        return False
    start_line = _as_int(code_span.get("start_line"))
    end_line = _as_int(code_span.get("end_line"))
    if start_line is None or end_line is None or end_line < start_line:
        return False
    for target in targets:
        target_start = _as_int(target.get("start_line"))
        target_end = _as_int(target.get("end_line"))
        if target_start is None or target_end is None:
            continue
        if target_start <= start_line and end_line <= target_end:
            return True
    return False
def _issue_has_geometry_context(
    issue: MathLogicIssue,
    *,
    targets: list[dict[str, Any]],
) -> bool:
    snippets = [
        issue.evidence,
        issue.statement,
        issue.suggested_fix,
        str(issue.metadata.get("code_snippet") or ""),
    ]
    span = issue.code_span or {}
    start_line = _as_int(span.get("start_line"))
    end_line = _as_int(span.get("end_line"))
    for target in targets:
        if start_line is not None and end_line is not None:
            target_start = _as_int(target.get("start_line"))
            target_end = _as_int(target.get("end_line"))
            if target_start is None or target_end is None:
                continue
            if not (target_start <= start_line and end_line <= target_end):
                continue
        snippets.extend(
            str(target.get(key) or "")
            for key in ("target_code", "statement", "claim", "summary")
        )
    text = "\n".join(snippets)
    return any(keyword in text for keyword in FIGURE_LINES_GEOMETRY_KEYWORDS)
def _as_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
def _issue_from_payload(raw: dict[str, Any], *, scene_name: str) -> MathLogicIssue:
    code = str(raw.get("code") or raw.get("issue_type") or "review_error")
    severity = _severity(raw.get("severity"))
    confidence = _confidence(raw.get("confidence"))
    raw_policy_bucket = str(raw.get("policy_bucket") or "").strip()
    explicit_non_blocking = raw_policy_bucket in {
        "teaching_approximation",
        "acceptable_simplification",
        "needs_visual_check",
        "record_only",
    } or bool(raw.get("needs_visual_check"))
    hard_error = bool(raw.get("hard_error")) or (
        code in HARD_ERROR_TYPES
        and severity == "high"
        and confidence >= 0.75
        and not explicit_non_blocking
    )
    if raw_policy_bucket == "hard_error" and code in HARD_ERROR_TYPES:
        hard_error = True
    policy_bucket = raw_policy_bucket or ("hard_error" if hard_error else "record_only")
    if policy_bucket not in {
        "hard_error",
        "teaching_approximation",
        "acceptable_simplification",
        "needs_visual_check",
        "record_only",
    }:
        policy_bucket = "record_only"
    metadata = {"source": "reviewer"}
    code_snippet = str(raw.get("code_snippet") or raw.get("target_code_snippet") or "").strip()
    if code_snippet:
        metadata["code_snippet"] = code_snippet[:1200]
    for key in (
        "required_fix",
        "expected_math_statement",
        "forbidden_change_scope",
        "repair_checklist",
        "required_relations",
        "required_visual_objects",
        "forbidden_scope",
        "verification_checklist",
        "evidence_mismatch",
        "insufficient_scene_code",
    ):
        value = raw.get(key)
        if value in (None, "", [], {}):
            continue
        metadata[key] = _metadata_value(value)
    suggested_fix = str(raw.get("suggested_fix") or raw.get("required_fix") or "")
    statement = str(raw.get("statement") or raw.get("expected_math_statement") or "")
    return MathLogicIssue(
        code=code,
        severity=severity,
        confidence=confidence,
        hard_error=hard_error,
        scene_name=str(raw.get("scene_name") or raw.get("scene") or scene_name),
        evidence=str(raw.get("evidence") or raw.get("summary") or ""),
        policy_bucket=policy_bucket,  # type: ignore[arg-type]
        needs_visual_check=bool(raw.get("needs_visual_check")),
        repairable=bool(raw.get("repairable") or raw.get("fixable")),
        claim_id=raw.get("claim_id"),
        statement=statement,
        code_span=raw.get("code_span") if isinstance(raw.get("code_span"), dict) else None,
        suggested_fix=suggested_fix,
        metadata=metadata,
    )
def _env_float(name: str, default: float) -> float:
    try:
        return float(_runtime_value(name, str(default)))
    except (TypeError, ValueError):
        return default

