from __future__ import annotations

import hashlib
import json
import re
from typing import Any


WHOLE_SCENE_REPAIR_STRATEGY = "whole_scene_rebuild"

_CODE_OBLIGATIONS: dict[str, dict[str, list[str]]] = {
    "missing_condition": {
        "required_objects": ["题目条件中的关键点、线、圆、角或函数关系必须在画面中出现"],
        "required_relations": ["画面对象必须满足原题条件，不能只展示结论"],
        "required_proof_steps": ["补齐缺失条件如何参与后续推导"],
    },
    "missing_subquestion": {
        "required_proof_steps": ["逐条覆盖原题每个小问，不得只回答其中一部分"],
        "required_final_display": ["总结页必须列出每个小问对应结论"],
    },
    "teaching_structure_gap": {
        "required_proof_steps": ["补齐从题设到结论的中间推导过程"],
        "required_final_display": ["结论必须带依据，不得只有口号式总结"],
    },
    "geometry_relation_error": {
        "required_objects": ["重建相关点、线、角、圆，使坐标和几何关系一致"],
        "required_relations": ["长度、角度、平行、垂直、相切、共圆等关系必须可由坐标验证"],
        "required_proof_steps": ["证明文字必须和重建后的几何事实一致"],
    },
    "condition_error": {
        "required_relations": ["代码中的数值、坐标、比例、时间或单位必须匹配题目条件"],
        "required_proof_steps": ["所有计算步骤必须使用修正后的条件"],
    },
    "formula_error": {
        "required_formula_display": ["关键公式必须用 MathTex 展示，且公式左右两边数学含义正确"],
        "required_proof_steps": ["公式推导不能跳步到错误结论"],
    },
    "final_answer_error": {
        "required_formula_display": ["最终答案必须以题目要求的形式展示"],
        "required_proof_steps": ["最终答案前必须有可检查的推导依据"],
    },
    "symbol_binding_error": {
        "required_objects": ["所有文字中提到的点、线、角、变量必须在代码中定义并显示"],
        "required_relations": ["符号引用必须和实际图形对象绑定一致"],
    },
    "reasoning_step_error": {
        "required_proof_steps": ["重写错误推理步骤，保证每一步由前一步推出"],
    },
    "cut_fill_shape_deformation": {
        "required_objects": ["割补前后图形必须保留面积/边长/角度关系"],
        "required_relations": ["拼接、旋转、平移后的图形关系必须数值一致"],
    },
}



def _decision_issue_payloads(decision: Any | None) -> list[dict[str, Any]]:
    payloads: list[dict[str, Any]] = []
    for issue in getattr(decision, "issues", None) or []:
        if hasattr(issue, "to_dict"):
            payload = issue.to_dict()
        elif isinstance(issue, dict):
            payload = issue
        else:
            payload = {}
        if isinstance(payload, dict):
            payloads.append(payload)
    return payloads
def _issue_codes(quality_issues: list[dict[str, Any]] | None) -> list[str]:
    codes: list[str] = []
    for issue in quality_issues or []:
        if not isinstance(issue, dict):
            continue
        code = str(issue.get("code") or issue.get("issue_code") or "").strip()
        if code:
            codes.append(code)
    return _dedupe_compact(codes)
def _obligations_from_prompt(user_prompt: str) -> dict[str, list[str]]:
    prompt = user_prompt or ""
    result: dict[str, list[str]] = {}
    if re.search(r"证明|推导|derive|prove", prompt, re.I):
        result.setdefault("required_proof_steps", []).append("必须展示证明/推导过程，不能只给结论")
    if re.search(r"公式|MathTex|S\s*=|a\^2|b\^2|c\^2", prompt, re.I):
        result.setdefault("required_formula_display", []).append("关键公式必须用 MathTex 或等价公式对象清晰展示")
    if re.search(r"坐标|顶点|变换|旋转|平移|对称", prompt):
        result.setdefault("required_relations", []).append("点坐标和变换后的像点关系必须逐项一致")
    if re.search(r"相切|垂直|平行|角|圆|中点|等边|等腰|直角", prompt):
        result.setdefault("required_relations", []).append("关键几何关系必须可由画面对象和数值校验支持")
    if re.search(r"表格|函数|关系", prompt):
        result.setdefault("required_objects", []).append("表格、坐标点或函数关系必须真实出现，不能只用文字代替")
    return result
def _obligations_from_issues(
    quality_issues: list[dict[str, Any]] | None,
) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for issue in quality_issues or []:
        if not isinstance(issue, dict):
            continue
        text = " ".join(
            _compact_text(issue.get(key))
            for key in ("evidence", "suggested_fix", "message", "statement")
            if issue.get(key)
        )
        if not text:
            continue
        code = str(issue.get("code") or issue.get("issue_code") or "")
        suggested_fix = _compact_text(issue.get("suggested_fix") or "")
        if suggested_fix:
            result.setdefault("required_fix", []).append(suggested_fix)
        result.setdefault("repair_checklist", []).extend(
            _issue_repair_checklist(text)
        )
        formulas = _formula_like_terms(text)
        if formulas:
            result.setdefault("required_formula_display", []).extend(formulas)
            if code in {"geometry_relation_error", "condition_error", "formula_error"}:
                result.setdefault("required_relations", []).extend(formulas)
                result.setdefault("expected_math_statement", []).extend(formulas)
        if "面积不变" in text:
            result.setdefault("required_relations", []).append("面积不变")
            result.setdefault("required_proof_steps", []).append("面积不变证明")
        if "坐标" in text and ("规律" in text or "变化" in text):
            result.setdefault("required_proof_steps", []).append("顶点坐标变化规律")
        if "证明" in text or "推导" in text:
            result.setdefault("required_proof_steps", []).append("补齐证明/推导过程")
    return result
def _contract_fields_from_obligations(
    *,
    issue_codes: list[str],
    obligations: dict[str, list[str]],
    quality_issues: list[dict[str, Any]] | None,
) -> dict[str, list[str]]:
    required_visual_objects = list(obligations.get("required_objects") or [])
    required_relations = list(obligations.get("required_relations") or [])
    verification_checklist = list(obligations.get("repair_checklist") or [])
    forbidden_scope: list[str] = []

    if "geometry_relation_error" in issue_codes:
        required_visual_objects.extend(
            _geometry_required_visual_objects(quality_issues)
        )
        required_relations.extend(_geometry_required_relations(quality_issues))
        forbidden_scope.extend([
            "不要只改文字或公式、结论标签；必须同步重建几何对象、坐标、标签和证明链。",
            "不要修改 header/import/GlobalConfig 或非当前 Scene。",
            "不要把 geometry_relation_error 当作 bbox、overlap 或画面美观问题处理。",
        ])
        verification_checklist.extend([
            "用坐标、距离、斜率、角度或等角关系逐项核验 required_relations。",
            "确认证明文字、标签和最终结论与重建后的几何事实一致。",
        ])

    return {
        "required_visual_objects": _dedupe_compact(required_visual_objects),
        "required_relations": _dedupe_compact(required_relations),
        "forbidden_scope": _dedupe_compact(forbidden_scope),
        "verification_checklist": _dedupe_compact(verification_checklist),
    }
def _geometry_issue_texts(
    quality_issues: list[dict[str, Any]] | None,
) -> list[str]:
    texts: list[str] = []
    for issue in quality_issues or []:
        if not isinstance(issue, dict):
            continue
        code = str(issue.get("code") or issue.get("issue_code") or "")
        if code != "geometry_relation_error":
            continue
        text = " ".join(
            _compact_text(issue.get(key))
            for key in ("evidence", "suggested_fix", "message", "statement")
            if issue.get(key)
        )
        if text:
            texts.append(text)
    return texts
def _geometry_required_visual_objects(
    quality_issues: list[dict[str, Any]] | None,
) -> list[str]:
    texts = _geometry_issue_texts(quality_issues)
    objects = [
        "重建当前 Scene 中相关点、线段、角标记、圆或辅助线，使画面对象承载题设几何关系。"
    ]
    tokens: set[str] = set()
    for text in texts:
        tokens.update(
            match.group(1)
            for match in re.finditer(r"(?<![A-Za-z])([A-Z]{1,3})(?![A-Za-z])", text)
        )
    if tokens:
        objects.append(
            "重建几何对象: "
            + "、".join(sorted(tokens))
            + "，并同步坐标、线段、角标记和标签。"
        )
    return objects
def _geometry_required_relations(
    quality_issues: list[dict[str, Any]] | None,
) -> list[str]:
    relations: list[str] = []
    for text in _geometry_issue_texts(quality_issues):
        for point, segment in re.findall(
            r"([A-Z])\s*(?:应为|应是|是|不是|必须为)?\s*([A-Z]{2})\s*中点",
            text,
        ):
            relations.append(f"{point} 必须位于 {segment} 上并满足 {segment} 中点关系")
        if "外角" in text and "平分线" in text:
            line_match = re.search(r"(?<![A-Za-z])([A-Z]{2})(?![A-Za-z])", text)
            line_name = line_match.group(1) if line_match else "相关射线"
            relations.append(f"{line_name} 必须表示对应顶点的外角平分线，并满足等角关系")
        if "垂直" in text:
            relations.append("垂直关系必须可由斜率、点积或直角标记验证")
        if "平行" in text:
            relations.append("平行关系必须可由斜率或方向向量验证")
        if "相切" in text:
            relations.append("相切关系必须满足切线垂直于切点半径")
        if "共圆" in text:
            relations.append("共圆关系必须满足同一圆心半径或等角关系")
    return relations
from . import repair_contract_part4 as _part4
globals().update({k: v for k, v in vars(_part4).items() if not k.startswith("__")})
