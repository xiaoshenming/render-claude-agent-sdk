from __future__ import annotations

def _extract_simple_linear_equation_spec(user_prompt: str) -> tuple[str, float] | None:
    parsed_prefix = parse_linear_grammar_prefix(prompt)
    if parsed_prefix is not None:
        return parsed_prefix

    match = REVERSED_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_RE.search(prompt)
    if match:
        left_value = _parse_simple_number_value(match.group(1))
        if left_value is None:
            return None
        side = _parse_affine_equation_side(match.group(2))
        if side is None:
            return None
        variable, coefficient, constant = side
        if abs(coefficient) <= 1e-9:
            return None
        return variable, (left_value - constant) / coefficient

    match = TWO_SIDED_AFFINE_EQUATION_RE.search(prompt)
    if match:
        left = _parse_affine_equation_side(match.group(1))
        right = _parse_affine_equation_side(match.group(2))
        if left is None or right is None:
            return None
        left_variable, left_coefficient, left_constant = left
        right_variable, right_coefficient, right_constant = right
        if left_variable != right_variable:
            return None
        combined_coefficient = left_coefficient - right_coefficient
        if abs(combined_coefficient) <= 1e-9:
            return None
        expected = (right_constant - left_constant) / combined_coefficient
        return left_variable, expected

    match = SIMPLE_COEFFICIENT_VARIABLE_DIVISION_EQUATION_RE.search(prompt)
    if match:
        coefficient = _parse_simple_number_value(match.group(1))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(3))
        if abs(denominator) <= 1e-9:
            return None
        right_value = _parse_simple_number_value(match.group(4))
        if right_value is None:
            return None
        return match.group(2), right_value * denominator / coefficient

    parsed_batch18 = parse_linear_grammar_batch18(prompt)
    if parsed_batch18 is not None:
        return parsed_batch18

    match = REVERSED_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_AFFINE_EQUATION_RE.search(
        prompt
    )
    if match:
        left_value = _parse_simple_number_value(match.group(1))
        if left_value is None:
            return None
        coefficient = _parse_simple_number_value(match.group(2))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(6))
        if abs(denominator) <= 1e-9:
            return None
        inner_offset = _parse_simple_number_value(match.group(5))
        if inner_offset is None:
            return None
        tail_offset = _parse_simple_number_value(match.group(8))
        if tail_offset is None:
            return None
        adjusted = left_value - tail_offset if match.group(7) == "+" else left_value + tail_offset
        inner_value = adjusted * denominator / coefficient
        expected = (
            inner_value - inner_offset
            if match.group(4) == "+"
            else inner_value + inner_offset
        )
        return match.group(3), expected

    match = SIMPLE_TEX_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE.search(prompt)
    if match:
        coefficient = _parse_simple_number_value(match.group(1))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(3))
        if abs(denominator) <= 1e-9:
            return None
        offset = _parse_simple_number_value(match.group(5))
        if offset is None:
            return None
        right_value = _parse_simple_number_value(match.group(6))
        if right_value is None:
            return None
        adjusted = right_value - offset if match.group(4) == "+" else right_value + offset
        return match.group(2), adjusted * denominator / coefficient

    match = REVERSED_TEX_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE.search(prompt)
    if match:
        left_value = _parse_simple_number_value(match.group(1))
        if left_value is None:
            return None
        coefficient = _parse_simple_number_value(match.group(2))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(4))
        if abs(denominator) <= 1e-9:
            return None
        offset = _parse_simple_number_value(match.group(6))
        if offset is None:
            return None
        adjusted = left_value - offset if match.group(5) == "+" else left_value + offset
        return match.group(3), adjusted * denominator / coefficient

    match = SIMPLE_TEX_VARIABLE_TIMES_FRACTION_EQUATION_RE.search(prompt)
    if match:
        coefficient = _parse_simple_number_value(match.group(2))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(3))
        if abs(denominator) <= 1e-9:
            return None
        right_value = _parse_simple_number_value(match.group(4))
        if right_value is None:
            return None
        return match.group(1), right_value * denominator / coefficient

    match = REVERSED_TEX_VARIABLE_TIMES_FRACTION_EQUATION_RE.search(prompt)
    if match:
        left_value = _parse_simple_number_value(match.group(1))
        if left_value is None:
            return None
        coefficient = _parse_simple_number_value(match.group(3))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(4))
        if abs(denominator) <= 1e-9:
            return None
        return match.group(2), left_value * denominator / coefficient

    match = SIMPLE_TEX_VARIABLE_TIMES_FRACTION_AFFINE_EQUATION_RE.search(prompt)
    if match:
        coefficient = _parse_simple_number_value(match.group(2))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(3))
        if abs(denominator) <= 1e-9:
            return None
        offset = _parse_simple_number_value(match.group(5))
        if offset is None:
            return None
        right_value = _parse_simple_number_value(match.group(6))
        if right_value is None:
            return None
        adjusted = right_value - offset if match.group(4) == "+" else right_value + offset
        return match.group(1), adjusted * denominator / coefficient

    match = REVERSED_TEX_VARIABLE_TIMES_FRACTION_AFFINE_EQUATION_RE.search(prompt)
    if match:
        left_value = _parse_simple_number_value(match.group(1))
        if left_value is None:
            return None
        coefficient = _parse_simple_number_value(match.group(3))
        if coefficient is None:
            return None
        if abs(coefficient) <= 1e-9:
            return None
        denominator = float(match.group(4))
        if abs(denominator) <= 1e-9:
            return None
        offset = _parse_simple_number_value(match.group(6))
        if offset is None:
            return None
        adjusted = left_value - offset if match.group(5) == "+" else left_value + offset
        return match.group(2), adjusted * denominator / coefficient

    match = SIMPLE_TEX_FRACTION_EQUATION_RE.search(prompt)
    if match:
        variable = match.group(1)
        denominator = float(match.group(2))
        if abs(denominator) <= 1e-9:
            return None
        right_value = _parse_simple_number_value(match.group(3))
        if right_value is None:
            return None
        return variable, right_value * denominator

    match = SIMPLE_TEX_FRACTION_AFFINE_EQUATION_RE.search(prompt)
    if match:
        variable = match.group(1)
        denominator = float(match.group(2))
        if abs(denominator) <= 1e-9:
            return None
        operator = match.group(3)
        offset = _parse_simple_number_value(match.group(4))
        if offset is None:
            return None
        right_value = _parse_simple_number_value(match.group(5))
        if right_value is None:
            return None
        adjusted = right_value - offset if operator == "+" else right_value + offset
        return variable, adjusted * denominator

    match = SIMPLE_ADDITIVE_EQUATION_RE.search(prompt)
    if not match:
        return None
    parsed_suffix = parse_linear_grammar_suffix(prompt)
    if parsed_suffix is not None:
        return parsed_suffix
