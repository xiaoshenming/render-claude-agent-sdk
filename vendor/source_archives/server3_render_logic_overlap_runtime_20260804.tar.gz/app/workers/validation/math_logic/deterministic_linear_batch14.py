from . import deterministic_guard as _guard

def parse_linear_grammar_batch14(prompt):
    parsed_batch13 = parse_linear_grammar_batch13(prompt)
    if parsed_batch13 is not None:
            return parsed_batch13
    match = REVERSED_TEX_FRACTION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                return None
            return variable, left_value * denominator
    match = REVERSED_ADDITIVE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            expected = left_value - offset if operator == "+" else left_value + offset
            return variable, expected
    match = REVERSED_DIRECT_VARIABLE_EQUATION_RE.search(prompt)
    if match:
            right_value = _parse_simple_number_value(match.group(1))
            if right_value is None:
                return None
            variable = match.group(2)
            return variable, right_value
    return None
