"""Compatibility facade for static geometry guard."""
from . import geometry_static_guard_part1 as _part1
from . import geometry_static_guard_part2 as _part2
from . import geometry_static_guard_part3 as _part3
for _module in (_part1,_part2,_part3):
    globals().update({k:v for k,v in vars(_module).items() if not k.startswith("__")})
