"""Claim scope, statement, and geometry normalization helpers."""

from __future__ import annotations

import re

from .claim_contracts import GEOMETRY_CONTEXT_RE


def _normalize_scope(scope: str) -> str:
    normalized = (scope or "all").strip().lower()
    return normalized if normalized in {"all", "geometry", "figure_lines"} else "all"


def _statement_from_context(
    *,
    narration: str,
    planning_scene: dict | None,
    fallback: str,
) -> str:
    if planning_scene:
        math_content = str(planning_scene.get("math_content") or "").strip()
        if math_content:
            return _shorten(math_content)
        parts = [
            str(planning_scene.get(key) or "").strip()
            for key in ("purpose", "visual_description")
        ]
        joined = "；".join(part for part in parts if part)
        if joined:
            return _shorten(joined)
    if narration.strip():
        return _shorten(narration.strip())
    return fallback


def _shorten(text: str, limit: int = 240) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "..."


def _is_visual_geometry(line: str) -> bool:
    return bool(
        re.search(
            r"Angle\(|RightAngle\(|Line\(|Polygon\(|Triangle\(|Square\(|Rectangle\(|Circle\(|Dot\(",
            line,
        )
    )


def _is_geometry_context(text: str) -> bool:
    return bool(GEOMETRY_CONTEXT_RE.search(text or ""))


def _is_geometry_review_line(line: str) -> bool:
    return bool(GEOMETRY_CONTEXT_RE.search(line or ""))


def _is_figure_line_target(line: str, geometry_context: bool) -> bool:
    if re.search(r"\b(?:Text|MarkupText)\s*\(", line):
        return _is_coordinate_transform_text_line(line)
    return (
        _is_visual_geometry(line)
        or _is_geometry_formula_line(line, geometry_context)
        or (
            _is_geometry_review_line(line)
            and not re.search(r"\b(?:Text|MarkupText)\s*\(", line)
        )
    )


def _is_coordinate_transform_text_line(line: str) -> bool:
    if not re.search(r"\b(?:Text|MarkupText)\s*\(", line):
        return False
    point_coordinate = re.search(
        r"[A-Z][A-Za-z]?\s*(?:['’′]|撇)\s*[（(]\s*"
        r"[+-]?\d+(?:\.\d+)?\s*[,，]\s*[+-]?\d+(?:\.\d+)?",
        line,
    )
    transform_formula = re.search(
        r"[（(]\s*[xyXY]\s*[,，]\s*[xyXY]\s*[)）]\s*"
        r"(?:\\to|->|→|↦)\s*"
        r"[（(]\s*[-−－]?\s*[xyXY]\s*[,，]\s*[-−－]?\s*[xyXY]\s*[)）]",
        line,
        flags=re.I,
    )
    return bool(point_coordinate or transform_formula)


def _is_geometry_formula_line(line: str, geometry_context: bool) -> bool:
    if not re.search(r"\b(?:MathTex|Tex)\s*\(", line):
        return False
    if _is_geometry_review_line(line):
        return True
    if not geometry_context:
        return False
    return bool(
        re.search(
            r"(\\to|->|→|↦|rotate|rotation|reflect|translate|"
            r"\\angle|∠|\\parallel|∥|\\perp|⊥|"
            r"\([xyXY]\s*,\s*[xyXY]\)|[A-Z]{2,3}\s*=|"
            r"\b(?:sin|cos|tan)\b)",
            line,
            flags=re.I,
        )
    )
