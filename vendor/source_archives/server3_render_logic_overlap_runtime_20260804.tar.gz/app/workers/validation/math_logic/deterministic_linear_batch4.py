from . import deterministic_guard as _guard

def parse_linear_grammar_batch4(prompt):
    parsed_middle = parse_linear_grammar_middle(prompt)
    if parsed_middle is not None:
            return parsed_middle
    match = REVERSED_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            variable = match.group(3)
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            adjusted = left_value - offset if operator == "+" else left_value + offset
            return variable, adjusted / coefficient
    match = REVERSED_SIMPLE_LINEAR_EQUATION_RE.search(prompt)
    if match:
            right_value = _parse_simple_number_value(match.group(1))
            if right_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            variable = match.group(3)
            return variable, right_value / coefficient
    match = CONSTANT_FIRST_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            constant = _parse_simple_number_value(match.group(1))
            if constant is None:
                return None
            coefficient = _parse_simple_number_value(match.group(4))
            if coefficient is None:
                return None
            if match.group(2) == "-":
                coefficient *= -1
            if abs(coefficient) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            return match.group(3), (right_value - constant) / coefficient
    return None
