from __future__ import annotations

from .deterministic_chemistry import _chemical_equation_balance_issue, _chemical_symbol_case_issue, _looks_like_chemical_equation, _normalize_chemical_equation_text, _parse_chemical_equation, _parse_chemical_side

from .deterministic_numeric import _manim_render_length_conflation_issue, _numeric_key, _perpendicular_dot_issue, _probability_prefixes, _probability_range_issue, _problem_geometry_length_numbers

from .deterministic_arithmetic import _arithmetic_sequence_issue, _extract_arithmetic_sequence_spec, _find_conflicting_arithmetic_last_term, _find_conflicting_arithmetic_sum, _number_assignment, _two_number_assignment

from .deterministic_options import _parse_optional_int, _extract_correct_option_claims, _extract_final_option_answer, _option_answer_issue, _extract_option_order, _option_order_issue, _format_subquestion, _extract_subquestion_numbers, _missing_subquestion_issue

from .deterministic_conditions import _explicit_number_condition_issue, _extract_number_conditions, _append_number_condition, _satisfies_number_condition, _explicit_divisibility_condition_issue, _extract_divisibility_conditions, _satisfies_divisibility_condition, _explicit_factor_condition_issue, _extract_factor_conditions, _satisfies_factor_condition, _explicit_digit_count_condition_issue, _extract_digit_count_conditions, _satisfies_digit_count_condition

from .deterministic_domain import _explicit_domain_exclusion_issue, _extract_domain_exclusions, _explicit_domain_bound_issue, _explicit_chained_domain_bound_issue, _extract_chained_domain_bounds, _satisfies_chained_domain_bound, _format_chained_domain_bound, _extract_domain_bounds, _append_followup_domain_bounds, _normalize_domain_bound_operator, _violates_domain_bound, _format_domain_bound

from .deterministic_geometry import _format_point, _clean_zero, _same_point, _normalize_minus, _extract_named_coordinate_occurrences, _extract_named_coordinates, _origin_ccw_90_coordinate_rotation_issue

from .deterministic_equations import _extract_final_unit_dimension, _expected_unit_dimension, _unit_dimension_issue, _extract_final_root_values, _extract_square_equation_spec, _square_equation_final_answer_issue, _pythagorean_cut_fill_inner_square_issue

from .deterministic_primitives import _is_square_integer, _is_prime_integer, _is_integer_value, _has_np_array_point, _area_partition_issue, _has_obvious_pythagorean_error, _issue

from .deterministic_linear_answers import _extract_final_variable_values, _extract_final_variable_value, _extract_final_numeric_answer, _has_final_numeric_answer, _extract_final_assignment_variables, _extract_requested_variables, _requested_final_variable_issue, _linear_equation_final_answer_issue

from .deterministic_numeric import _strip_line_prefixes

from .deterministic_chemistry import _parse_formula_group, _parse_formula_counts, _strip_chemical_term_noise, _extract_chemical_equation_candidates, _find_chemical_symbol_case_issue, _extract_chemical_equation_texts

from .deterministic_guard_constants import SUBQUESTION_MARKER_RE, SUBQUESTION_FINAL_CONTEXT_RE, SUBQUESTION_LABELS, OPTION_ORDER_CONTEXT_RE, OPTION_MARKER_RE, FINAL_OPTION_ANSWER_RE, CORRECT_OPTION_CLAIM_RE, LINEAR_EQUATION_CONTEXT_RE, SIMPLE_NUMBER_VALUE_PATTERN, EQUATION_EQUALS_PATTERN, EXPLICIT_MULTIPLY_PATTERN, COEFFICIENT_VARIABLE_MULTIPLY_PATTERN, SIMPLE_LINEAR_EQUATION_RE, LINEAR_AFFINE_EQUATION_SIDE_PATTERN, PARENTHESIZED_AFFINE_EQUATION_SIDE_PATTERN, DIVISION_AFFINE_EQUATION_SIDE_PATTERN, TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_PATTERN, CONSTANT_FIRST_AFFINE_EQUATION_SIDE_PATTERN, CONSTANT_FIRST_DIVISION_AFFINE_EQUATION_SIDE_PATTERN, CONSTANT_FIRST_TEX_VARIABLE_FRACTION_EQUATION_SIDE_PATTERN

from .deterministic_guard_constants2 import AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN, VARIABLE_FIRST_AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN, VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN, CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN, TEX_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN, TEX_CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN, TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN, VARIABLE_FIRST_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN, AFFINE_EQUATION_SIDE_PATTERN, TWO_SIDED_AFFINE_EQUATION_RE, AFFINE_EQUATION_SIDE_RE, PARENTHESIZED_AFFINE_EQUATION_SIDE_RE, DIVISION_AFFINE_EQUATION_SIDE_RE, TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_RE, CONSTANT_FIRST_AFFINE_EQUATION_SIDE_RE, CONSTANT_FIRST_DIVISION_AFFINE_EQUATION_SIDE_RE, CONSTANT_FIRST_TEX_VARIABLE_FRACTION_EQUATION_SIDE_RE, AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_RE, VARIABLE_FIRST_AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_RE, VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_RE

from .deterministic_guard_constants3 import TARGET_CODE_SNIPPET_LIMIT, CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_RE, TEX_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_RE, TEX_CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_RE, SIMPLE_AFFINE_NUMERATOR_DIVISION_EQUATION_RE, REVERSED_AFFINE_NUMERATOR_DIVISION_EQUATION_RE, TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_RE, VARIABLE_FIRST_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_RE, SIMPLE_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_RE, REVERSED_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_RE, REVERSED_SIMPLE_LINEAR_EQUATION_RE, REVERSED_AFFINE_EQUATION_RE, CONSTANT_FIRST_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE, REVERSED_CONSTANT_FIRST_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE, SIMPLE_VARIABLE_MULTIPLICATION_EQUATION_RE, SIMPLE_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE, REVERSED_VARIABLE_MULTIPLICATION_EQUATION_RE, REVERSED_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE, SIMPLE_COEFFICIENT_VARIABLE_DIVISION_EQUATION_RE, REVERSED_COEFFICIENT_VARIABLE_DIVISION_EQUATION_RE

from .deterministic_guard_constants4 import SIMPLE_COEFFICIENT_VARIABLE_DIVISION_AFFINE_EQUATION_RE, REVERSED_COEFFICIENT_VARIABLE_DIVISION_AFFINE_EQUATION_RE, SIMPLE_COEFFICIENT_CONSTANT_FIRST_PARENTHESIZED_DIVISION_EQUATION_RE, REVERSED_COEFFICIENT_CONSTANT_FIRST_PARENTHESIZED_DIVISION_EQUATION_RE, SIMPLE_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_AFFINE_EQUATION_RE, REVERSED_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_AFFINE_EQUATION_RE, SIMPLE_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_EQUATION_RE, REVERSED_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_EQUATION_RE, SIMPLE_COEFFICIENT_PARENTHESIZED_DIVISION_AFFINE_EQUATION_RE, REVERSED_COEFFICIENT_PARENTHESIZED_DIVISION_AFFINE_EQUATION_RE, SIMPLE_COEFFICIENT_PARENTHESIZED_DIVISION_EQUATION_RE, REVERSED_COEFFICIENT_PARENTHESIZED_DIVISION_EQUATION_RE, SIMPLE_PARENTHESIZED_AFFINE_EQUATION_RE, SIMPLE_IMPLICIT_PARENTHESIZED_AFFINE_EQUATION_RE, REVERSED_IMPLICIT_PARENTHESIZED_AFFINE_EQUATION_RE, REVERSED_PARENTHESIZED_AFFINE_EQUATION_RE, SIMPLE_SIGNED_VARIABLE_EQUATION_RE, SIMPLE_SIGNED_ADDITIVE_EQUATION_RE, REVERSED_SIGNED_VARIABLE_EQUATION_RE, REVERSED_SIGNED_ADDITIVE_EQUATION_RE

from .deterministic_guard_constants5 import SIMPLE_DIRECT_VARIABLE_EQUATION_RE, REVERSED_DIRECT_VARIABLE_EQUATION_RE, SIMPLE_AFFINE_EQUATION_RE, SIMPLE_ADDITIVE_EQUATION_RE, REVERSED_ADDITIVE_EQUATION_RE, SIMPLE_DIVISION_EQUATION_RE, SIMPLE_DIVISION_AFFINE_EQUATION_RE, REVERSED_DIVISION_EQUATION_RE, REVERSED_DIVISION_AFFINE_EQUATION_RE, SIMPLE_TEX_COEFFICIENT_FRACTION_EQUATION_RE, REVERSED_TEX_COEFFICIENT_FRACTION_EQUATION_RE, SIMPLE_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_EQUATION_RE, REVERSED_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_EQUATION_RE, SIMPLE_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_EQUATION_RE, REVERSED_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_EQUATION_RE, SIMPLE_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE, REVERSED_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE, SIMPLE_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_AFFINE_EQUATION_RE, REVERSED_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_AFFINE_EQUATION_RE, SIMPLE_TEX_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE

from .deterministic_guard_constants6 import REVERSED_TEX_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE, SIMPLE_TEX_VARIABLE_TIMES_FRACTION_EQUATION_RE, REVERSED_TEX_VARIABLE_TIMES_FRACTION_EQUATION_RE, SIMPLE_TEX_VARIABLE_TIMES_FRACTION_AFFINE_EQUATION_RE, REVERSED_TEX_VARIABLE_TIMES_FRACTION_AFFINE_EQUATION_RE, SIMPLE_TEX_FRACTION_EQUATION_RE, SIMPLE_TEX_FRACTION_AFFINE_EQUATION_RE, REVERSED_TEX_FRACTION_EQUATION_RE, REVERSED_TEX_FRACTION_AFFINE_EQUATION_RE, SQUARE_EQUATION_RE, REVERSED_SQUARE_EQUATION_RE, REQUESTED_VARIABLE_LIST_RE, REQUESTED_VARIABLE_RE, FINAL_ASSIGNMENT_SUBJECT_SUFFIX_PATTERN, FINAL_ASSIGNMENT_OPERATOR_PATTERN, FINAL_ASSIGNMENT_VARIABLE_RE, FINAL_NUMERIC_ANSWER_RE, DOMAIN_EXCLUSION_RE, DOMAIN_BOUND_OPERATOR_PATTERN, DOMAIN_BOUND_RE

from .deterministic_guard_constants7 import FOLLOWUP_DOMAIN_BOUND_RE, CHAINED_DOMAIN_BOUND_RE, NUMBER_CONDITION_PATTERN, NUMBER_CONDITION_RE, FOLLOWUP_NUMBER_CONDITION_RE, MULTIPLE_CONDITION_RE, DIVISIBLE_BY_CONDITION_RE, FACTOR_CONDITION_RE, DIGIT_COUNT_CONDITION_RE, DIGIT_COUNT_LABELS, UNIT_PATTERN_RE, CHEMICAL_RESULT_CONTEXT_RE, CHEMICAL_EQUATION_QUOTE_RE, CHEMICAL_SUBSCRIPT_TRANSLATION, ELEMENT_SYMBOLS

import re
from typing import Any

from .geometry_static_guard import static_geometry_issues
from .schemas import MathLogicIssue

def _collect_target_math_issues(*args, **kwargs):
    from .deterministic_target_collect import _collect_target_math_issues as _impl
    return _impl(*args, **kwargs)

from .deterministic_coordinate_collect import collect_coordinate_area_issues

from .deterministic_remaining_collect import _collect_remaining_target_math_issues

def run_deterministic_math_guard(
    targets: list[dict[str, Any]],
    *,
    user_prompt: str = "",
    scope: str = "all",
) -> list[MathLogicIssue]:
    from .deterministic_guard_runner import run_deterministic_math_guard as _run
    _run.__globals__.update(globals())
    return _run(targets, user_prompt=user_prompt, scope=scope)

def _normalize_scope(scope: str) -> str:
    normalized = (scope or "all").strip().lower()
    return normalized if normalized in {"all", "geometry", "figure_lines"} else "all"

def _extract_simple_linear_equation_spec(*args, **kwargs):
    from . import extract_simple_linear_equation_spec as _helpers
    fn = _helpers._extract_simple_linear_equation_spec
    fn.__globals__.update(globals())
    return fn(*args, **kwargs)


def _parse_affine_equation_side(*args, **kwargs):
    from . import parse_affine_equation_side as _helpers
    fn = _helpers._parse_affine_equation_side
    fn.__globals__.update(globals())
    return fn(*args, **kwargs)


def _append_unique_number(values: list[float], value: float) -> None:
    if not any(_same_number(existing, value) for existing in values):
        values.append(value)

def _normalize_chained_bound_operator(operator: str) -> str:
    return "<=" if operator in {"<=", "≤"} else operator

def _display_chained_bound_operator(operator: str) -> str:
    return "≤" if operator == "<=" else operator

def _search_number(text: str, patterns: list[str]) -> float | None:
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return float(match.group(1))
    return None

def _parse_simple_number_value(value: str) -> float | None:
    token = re.sub(r"\s+", "", (value or "").replace("\\\\", "\\"))
    tex_fraction = re.fullmatch(
        r"([+-]?)\\frac\{([+-]?\d+(?:\.\d+)?)\}\{([+-]?\d+(?:\.\d+)?)\}",
        token,
    )
    if tex_fraction:
        denominator = float(tex_fraction.group(3))
        if abs(denominator) <= 1e-9:
            return None
        sign = -1 if tex_fraction.group(1) == "-" else 1
        return sign * float(tex_fraction.group(2)) / denominator
    if "/" not in token:
        return float(token)
    numerator_text, denominator_text = token.split("/", 1)
    denominator = float(denominator_text)
    if abs(denominator) <= 1e-9:
        return None
    return float(numerator_text) / denominator

def _same_number(a: float, b: float) -> bool:
    return abs(a - b) <= 1e-6

def _fmt_number(value: float) -> str:
    if abs(value - round(value)) <= 1e-6:
        return str(int(round(value)))
    return f"{value:g}"

from .deterministic_linear_batch18 import parse_linear_grammar_batch18

from .deterministic_affine_terms import parse_affine_side_terms
from .deterministic_affine_numeric import parse_affine_side_numeric_terms
