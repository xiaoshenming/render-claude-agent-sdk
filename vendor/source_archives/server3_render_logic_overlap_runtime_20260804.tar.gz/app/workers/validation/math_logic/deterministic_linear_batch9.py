from . import deterministic_guard as _guard

def parse_linear_grammar_batch9(prompt):
    parsed_batch8 = parse_linear_grammar_batch8(prompt)
    if parsed_batch8 is not None:
            return parsed_batch8
    match = SIMPLE_COEFFICIENT_PARENTHESIZED_DIVISION_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(6))
            if right_value is None:
                return None
            inner_value = right_value * denominator / coefficient
            expected = inner_value - offset if match.group(3) == "+" else inner_value + offset
            return match.group(2), expected
    match = REVERSED_COEFFICIENT_PARENTHESIZED_DIVISION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            inner_value = left_value * denominator / coefficient
            expected = inner_value - offset if match.group(4) == "+" else inner_value + offset
            return match.group(3), expected
    match = SIMPLE_PARENTHESIZED_AFFINE_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            variable = match.group(2)
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            inner_value = right_value / coefficient
            expected = inner_value - offset if operator == "+" else inner_value + offset
            return variable, expected
    return None
