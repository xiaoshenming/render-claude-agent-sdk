from __future__ import annotations

import ast
import re
from dataclasses import replace
from typing import Any

from app.workers.validation.math_logic_ast_helpers import (
    _integer_assignments, _for_loop_builds_target_sector_strip,
    _has_call_named,
)
from .schemas import MathLogicIssue
from .runtime_patterns import (
    _CIRCLE_SECTOR_REARRANGEMENT_RE, _CIRCLE_SECTOR_COUNT_FALSE_POSITIVE_RE,
    _CIRCLE_SECTOR_FALSE_POSITIVE_CODES, _OPTION_SCENE_SCOPE_FALSE_POSITIVE_CODES,
    _OPTION_LABEL_RE, _OPTION_SCENE_LABEL_RE, _OPTION_COVERAGE_GAP_RE,
)

def _downgrade_circle_sector_loop_false_positives(
    issues: list[MathLogicIssue],
    *,
    scene_code: str,
    targets: list[dict[str, Any]],
    user_prompt: str,
) -> list[MathLogicIssue]:
    if not issues:
        return issues
    if not _has_valid_circle_sector_loop_rearrangement(scene_code):
        return issues
    target_text = "\n".join(
        str(target.get(key) or "")
        for target in targets
        for key in ("statement", "target_code")
    )
    context_text = "\n".join([user_prompt, target_text, scene_code])
    if not _CIRCLE_SECTOR_REARRANGEMENT_RE.search(context_text):
        return issues

    normalized: list[MathLogicIssue] = []
    for issue in issues:
        if _is_circle_sector_count_false_positive(issue):
            metadata = dict(issue.metadata or {})
            metadata.update(
                {
                    "suppressed_by": "circle_sector_loop_recognizer",
                    "original_hard_error": issue.hard_error,
                    "original_policy_bucket": issue.policy_bucket,
                }
            )
            normalized.append(
                replace(
                    issue,
                    hard_error=False,
                    policy_bucket="record_only",
                    repairable=False,
                    confidence=min(float(issue.confidence or 0.0), 0.74),
                    metadata=metadata,
                )
            )
        else:
            normalized.append(issue)
    return normalized

def _is_circle_sector_count_false_positive(issue: MathLogicIssue) -> bool:
    if issue.code not in _CIRCLE_SECTOR_FALSE_POSITIVE_CODES:
        return False
    if not issue.hard_error or issue.policy_bucket != "hard_error":
        return False
    text = "\n".join(
        [
            issue.evidence or "",
            issue.statement or "",
            issue.suggested_fix or "",
            str((issue.metadata or {}).get("code_snippet") or ""),
            str((issue.metadata or {}).get("target_code_snippet") or ""),
        ]
    )
    return bool(_CIRCLE_SECTOR_COUNT_FALSE_POSITIVE_RE.search(text))

def _downgrade_option_scene_scope_false_positives(
    issues: list[MathLogicIssue],
    *,
    scene_name: str,
    scene_code: str,
    user_prompt: str,
    planning_scene: dict | None,
    task_data: dict | None,
) -> list[MathLogicIssue]:
    if not issues:
        return issues
    current_option = _current_option_scene_label(
        scene_name=scene_name,
        scene_code=scene_code,
        planning_scene=planning_scene,
    )
    if not current_option:
        return issues

    expected_options = _extract_option_labels(user_prompt)
    planned_options = _planned_option_scene_labels(
        task_data=task_data,
        planning_scene=planning_scene,
    )

    normalized: list[MathLogicIssue] = []
    for issue in issues:
        if _is_option_scene_scope_false_positive(
            issue,
            current_option=current_option,
            expected_options=expected_options,
            planned_options=planned_options,
        ):
            metadata = dict(issue.metadata or {})
            metadata.update(
                {
                    "suppressed_by": "option_scene_scope_recognizer",
                    "original_hard_error": issue.hard_error,
                    "original_policy_bucket": issue.policy_bucket,
                    "current_option": current_option,
                    "expected_options": sorted(expected_options),
                    "planned_option_scenes": sorted(planned_options),
                }
            )
            normalized.append(
                replace(
                    issue,
                    hard_error=False,
                    policy_bucket="record_only",
                    repairable=False,
                    confidence=min(float(issue.confidence or 0.0), 0.74),
                    metadata=metadata,
                )
            )
        else:
            normalized.append(issue)
    return normalized

def _is_option_scene_scope_false_positive(
    issue: MathLogicIssue,
    *,
    current_option: str,
    expected_options: set[str],
    planned_options: set[str],
) -> bool:
    if issue.code not in _OPTION_SCENE_SCOPE_FALSE_POSITIVE_CODES:
        return False
    if not issue.hard_error or issue.policy_bucket != "hard_error":
        return False
    text = "\n".join(
        [
            issue.evidence or "",
            issue.statement or "",
            issue.suggested_fix or "",
            str((issue.metadata or {}).get("code_snippet") or ""),
            str((issue.metadata or {}).get("target_code_snippet") or ""),
        ]
    )
    if not _OPTION_COVERAGE_GAP_RE.search(text):
        return False
    mentioned_options = _extract_option_labels(text)
    mentions_other_options = bool(mentioned_options - {current_option})
    broad_gap_claim = bool(
        re.search(r"未.{0,20}(?:全面|完整|全部|所有)|所有小问|全部选项|all options", text, re.I)
    )
    if not mentions_other_options and not broad_gap_claim:
        return False
    if planned_options:
        return current_option in planned_options and len(planned_options) >= 3
    return current_option in expected_options and len(expected_options) >= 3

def _current_option_scene_label(
    *,
    scene_name: str,
    scene_code: str,
    planning_scene: dict | None,
) -> str:
    candidates = [scene_name or ""]
    if isinstance(planning_scene, dict):
        for key in ("name", "title", "description", "goal", "type", "stage"):
            value = planning_scene.get(key)
            if value:
                candidates.append(str(value))
    class_match = re.search(r"class\s+([A-Za-z_][A-Za-z0-9_]*)", scene_code or "")
    if class_match:
        candidates.append(class_match.group(1))
    for text in candidates:
        label = _extract_option_scene_label(text)
        if label:
            return label
    return ""

def _planned_option_scene_labels(
    *,
    task_data: dict | None,
    planning_scene: dict | None,
) -> set[str]:
    labels: set[str] = set()
    scenes: list[Any] = []
    if isinstance(task_data, dict):
        for key in ("planning_json", "_planning_json"):
            payload = task_data.get(key)
            if isinstance(payload, dict) and isinstance(payload.get("scenes"), list):
                scenes.extend(payload["scenes"])
        contracts = task_data.get("scene_contracts")
        if isinstance(contracts, list):
            scenes.extend(contracts)
    if isinstance(planning_scene, dict):
        scenes.append(planning_scene)
    for scene in scenes:
        if not isinstance(scene, dict):
            continue
        parts: list[str] = []
        for key in (
            "name",
            "title",
            "description",
            "visual_description",
            "narration",
            "voiceover",
            "math_content",
            "goal",
            "type",
            "stage",
        ):
            value = scene.get(key)
            if value:
                parts.append(str(value))
        label = _extract_option_scene_label("\n".join(parts))
        if label:
            labels.add(label)
    return labels

def _extract_option_scene_label(text: str) -> str:
    match = _OPTION_SCENE_LABEL_RE.search(text or "")
    if not match:
        return ""
    for group in match.groups():
        if group:
            return group.upper()
    return ""

def _extract_option_labels(text: str) -> set[str]:
    labels = {match.group(1).upper() for match in _OPTION_LABEL_RE.finditer(text or "")}
    if re.search(r"A\s*[、,/，]\s*B\s*[、,/，]\s*C", text or "", re.I):
        labels.update({"A", "B", "C"})
    if re.search(r"A\s*[、,/，]\s*B\s*[、,/，]\s*C\s*[、,/，]\s*D", text or "", re.I):
        labels.update({"A", "B", "C", "D"})
    return labels

def _has_valid_circle_sector_loop_rearrangement(scene_code: str) -> bool:
    text = scene_code or ""
    if "Sector(" not in text or "AnnularSector(" in text:
        return False
    if not re.search(r"\b(?:Transform|ReplacementTransform|TransformFromCopy)\s*\(", text):
        return False
    if not re.search(r"\b(?:SurroundingRectangle|Rectangle|Polygon|Line)\s*\(", text):
        return False

    try:
        tree = ast.parse(text)
    except SyntaxError:
        return _has_valid_circle_sector_loop_rearrangement_text(text)

    constants = _integer_assignments(tree)
    has_transform = _has_call_named(
        tree,
        {"Transform", "ReplacementTransform", "TransformFromCopy"},
    )
    has_limit_shape = _has_call_named(
        tree,
        {"SurroundingRectangle", "Rectangle", "Polygon", "Line"},
    )
    if not has_transform or not has_limit_shape:
        return False

    for node in ast.walk(tree):
        if isinstance(node, ast.For) and _for_loop_builds_target_sector_strip(
            node,
            constants=constants,
            source=text,
        ):
            return True
    return False

def _has_valid_circle_sector_loop_rearrangement_text(text: str) -> bool:
    return bool(
        re.search(r"for\s+\w+\s+in\s+range\((?:\d{2,}|n|num_sectors|segments)", text)
        and re.search(r"\bif\s+\w+\s*%\s*2\s*==", text)
        and re.search(r"\b(?:target|rearranged|strip)\w*\.add\s*\(", text, re.I)
        and re.search(r"\bSector\s*\(", text)
        and re.search(r"\b(?:Transform|ReplacementTransform|TransformFromCopy)\s*\(", text)
    )
