from . import deterministic_guard as _guard

def parse_linear_grammar_suffix(prompt):
    variable = match.group(1)
    operator = match.group(2)
    offset = _parse_simple_number_value(match.group(3))
    if offset is None:
            return None
    right_value = _parse_simple_number_value(match.group(4))
    if right_value is None:
            return None
    expected = right_value - offset if operator == "+" else right_value + offset
    return variable, expected
    return None
