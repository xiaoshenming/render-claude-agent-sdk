import re
from typing import Any

from .deterministic_primitives import _fmt_number

def _probability_range_issue(text: str) -> str:
    normalized = (text or "").replace("\\\\", "\\")
    for prefix in _probability_prefixes():
        percent_pattern = rf"{prefix}\s*(-?\d+(?:\.\d+)?)\s*%"
        for match in re.finditer(percent_pattern, normalized):
            percent = float(match.group(1))
            if percent < 0 or percent > 100:
                return f"概率取值 {_fmt_number(percent)}% 超出 [0, 100%]。"

        fraction_pattern = rf"{prefix}\s*\\frac\s*\{{\s*(-?\d+(?:\.\d+)?)\s*\}}\s*\{{\s*(-?\d+(?:\.\d+)?)\s*\}}"
        for match in re.finditer(fraction_pattern, normalized):
            numerator = float(match.group(1))
            denominator = float(match.group(2))
            if abs(denominator) <= 1e-9:
                return "概率分母为 0，无法作为有效概率。"
            value = numerator / denominator
            if value < 0 or value > 1:
                return (
                    f"概率取值 {_fmt_number(numerator)}/{_fmt_number(denominator)} "
                    f"(={value:g}) 超出 [0, 1]。"
                )

        slash_fraction_pattern = rf"{prefix}\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)"
        for match in re.finditer(slash_fraction_pattern, normalized):
            numerator = float(match.group(1))
            denominator = float(match.group(2))
            if abs(denominator) <= 1e-9:
                return "概率分母为 0，无法作为有效概率。"
            value = numerator / denominator
            if value < 0 or value > 1:
                return (
                    f"概率取值 {_fmt_number(numerator)}/{_fmt_number(denominator)} "
                    f"(={value:g}) 超出 [0, 1]。"
                )

        decimal_pattern = rf"{prefix}\s*(-?\d+(?:\.\d+)?)(?![\d.]|\s*[%/])"
        for match in re.finditer(decimal_pattern, normalized):
            value = float(match.group(1))
            if value < 0 or value > 1:
                return f"概率取值 {value:g} 超出 [0, 1]。"
    return ""

def _probability_prefixes() -> list[str]:
    return [
        r"P\s*\([^)]*\)\s*=",
        r"概率\s*[=:：]",
    ]

def _perpendicular_dot_issue(text: str) -> str:
    if not re.search(r"垂直|perpendicular|RightAngle", text, flags=re.I):
        return ""
    match = re.search(r"dot_product\s*=\s*(-?\d+(?:\.\d+)?)", text)
    if not match:
        return ""
    value = float(match.group(1))
    if abs(value) > 1e-9:
        return f"声称垂直，但点积为 {value:g}，不是 0。"
    return ""

def _manim_render_length_conflation_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    problem_numbers = _problem_geometry_length_numbers(f"{user_prompt}\n{text}")
    if not problem_numbers:
        return None
    code = _strip_line_prefixes(text)
    if "set_length" not in code or "Line(" not in code:
        return None
    if not any(keyword in code for keyword in ("Polygon(", "Square(", "Triangle(", "pt_", "point")):
        return None
    for match in re.finditer(r"\.set_length\(\s*([0-9]+(?:\.[0-9]+)?)\s*\)", code):
        raw_value = match.group(1)
        value_key = _numeric_key(raw_value)
        if value_key not in problem_numbers:
            continue
        return {
            "evidence": (
                f"把题面数学长度 {raw_value} 直接用于 Manim .set_length({raw_value})。"
                "Manim 长度是画布渲染单位，不等于题目中的数学单位；"
                "单独拉长线段会破坏端点、正方形或三角形的几何一致性。"
            ),
            "suggested_fix": (
                "不要用题面数值直接 set_length。应保持几何点坐标、图形边和对角线在同一比例尺下构造；"
                "题面长度 10 只作为标签和公式值展示，或显式定义统一 scale 再同步所有相关点。"
            ),
            "metadata": {
                "guard": "manim_render_length_conflation",
                "problem_length": raw_value,
            },
        }
    return None

def _problem_geometry_length_numbers(text: str) -> set[str]:
    numbers: set[str] = set()
    for match in re.finditer(
        r"(?:边长|对角线长|斜边长|直角边|长度|长为|为边长|边分别为)[^0-9]{0,8}"
        r"([0-9]+(?:\.[0-9]+)?)",
        text,
    ):
        numbers.add(_numeric_key(match.group(1)))
    return numbers

def _strip_line_prefixes(text: str) -> str:
    return re.sub(r"(?m)^\s*L\d+:\s*", "", text)

def _numeric_key(value: str) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if number.is_integer():
        return str(int(number))
    return f"{number:.6f}".rstrip("0").rstrip(".")
