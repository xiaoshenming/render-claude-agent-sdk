from __future__ import annotations

import re

_CIRCLE_SECTOR_REARRANGEMENT_RE = re.compile(
    r"(圆面积|圆.*面积|扇形|拼接|交错|咬合|矩形|长方形|平行四边形|"
    r"circle\s+area|sector|rectangle|parallelogram)",
    re.I,
)
_CIRCLE_SECTOR_COUNT_FALSE_POSITIVE_RE = re.compile(
    r"("
    r"(?:仅|只).{0,12}(?:两个|2).{0,16}扇形|"
    r"(?:仅|只).{0,12}(?:一个|1).{0,16}扇形|"
    r"only\s+two.{0,16}sector|"
    r"only\s+one.{0,16}sector|"
    r"缺少.{0,20}(?:多个|很多|许多|平均分|循环|重复).{0,16}扇形|"
    r"lack(?:s|ing)?.{0,20}(?:multiple|many|loop|repeated).{0,16}sector"
    r")",
    re.I | re.S,
)
_CIRCLE_SECTOR_FALSE_POSITIVE_CODES = {
    "missing_condition",
    "reasoning_step_error",
    "teaching_structure_gap",
}
_OPTION_SCENE_SCOPE_FALSE_POSITIVE_CODES = {
    "missing_condition",
    "missing_subquestion",
    "reasoning_step_error",
    "teaching_structure_gap",
}
_OPTION_LABEL_RE = re.compile(
    r"(?:^|[\s\n\r，。；;、:：（(])([A-D])(?:\s*[\.．、:：)）]|选项)",
    re.I,
)
_OPTION_SCENE_LABEL_RE = re.compile(
    r"(?:Analyze|Analysis|Option|Choice|选项)[_\s-]*([A-D])\b|"
    r"\b([A-D])[_\s-]*(?:Option|Choice|选项)\b|"
    r"选项\s*([A-D])",
    re.I,
)
_OPTION_COVERAGE_GAP_RE = re.compile(
    r"("
    r"(?:当前场景|本场景|当前scene|target_scene).{0,40}(?:仅|只).{0,30}(?:选项|option)|"
    r"(?:仅|只).{0,30}(?:分析|讲解|说明).{0,20}(?:[A-D]|选项|option)|"
    r"缺少.{0,80}(?:[A-D].{0,12}){2,}|"
    r"未.{0,20}(?:全面|完整|全部|所有).{0,30}(?:覆盖|讲解|分析|说明)|"
    r"(?:missing|lack(?:s|ing)?|does not cover).{0,80}(?:option|choice|subquestion)"
    r")",
    re.I | re.S,
)
