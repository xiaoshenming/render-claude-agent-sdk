from . import deterministic_guard as _guard

def parse_affine_side_numeric_terms(side):
    affine_numerator_division = AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_RE.fullmatch(
            side or ""
        )
    if affine_numerator_division:
            numerator_constant = _parse_simple_number_value(
                affine_numerator_division.group(1)
            )
            if numerator_constant is None:
                return None
            denominator = float(affine_numerator_division.group(5))
            if abs(denominator) <= 1e-9:
                return None
            numerator_coefficient = 1.0
            if affine_numerator_division.group(3):
                parsed_coefficient = _parse_simple_number_value(
                    affine_numerator_division.group(3)
                )
                if parsed_coefficient is None:
                    return None
                numerator_coefficient = parsed_coefficient
            if affine_numerator_division.group(2) == "-":
                numerator_coefficient *= -1
            constant = numerator_constant / denominator
            if affine_numerator_division.group(6) and affine_numerator_division.group(7):
                tail_constant = _parse_simple_number_value(affine_numerator_division.group(7))
                if tail_constant is None:
                    return None
                constant += (
                    tail_constant if affine_numerator_division.group(6) == "+" else -tail_constant
                )
            return (
                affine_numerator_division.group(4),
                numerator_coefficient / denominator,
                constant,
            )
    variable_first_numerator = (
            VARIABLE_FIRST_AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_RE.fullmatch(
                side or ""
            )
        )
    if variable_first_numerator:
            denominator = float(variable_first_numerator.group(6))
            if abs(denominator) <= 1e-9:
                return None
            numerator_coefficient = 1.0
            if variable_first_numerator.group(2):
                parsed_coefficient = _parse_simple_number_value(
                    variable_first_numerator.group(2)
                )
                if parsed_coefficient is None:
                    return None
                numerator_coefficient = parsed_coefficient
            if variable_first_numerator.group(1) == "-":
                numerator_coefficient *= -1
            numerator_constant = _parse_simple_number_value(variable_first_numerator.group(5))
            if numerator_constant is None:
                return None
            if variable_first_numerator.group(4) == "-":
                numerator_constant *= -1
            constant = numerator_constant / denominator
            if variable_first_numerator.group(7) and variable_first_numerator.group(8):
                tail_constant = _parse_simple_number_value(variable_first_numerator.group(8))
                if tail_constant is None:
                    return None
                constant += (
                    tail_constant if variable_first_numerator.group(7) == "+" else -tail_constant
                )
            return (
                variable_first_numerator.group(3),
                numerator_coefficient / denominator,
                constant,
            )
    variable_times_numerator = (
            VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_RE.fullmatch(
                side or ""
            )
        )
    if variable_times_numerator:
            denominator = float(variable_times_numerator.group(6))
            if abs(denominator) <= 1e-9:
                return None
            coefficient = _parse_simple_number_value(variable_times_numerator.group(3))
            if coefficient is None:
                return None
            if variable_times_numerator.group(1) == "-":
                coefficient *= -1
            numerator_constant = _parse_simple_number_value(
                variable_times_numerator.group(5)
            )
            if numerator_constant is None:
                return None
            if variable_times_numerator.group(4) == "-":
                numerator_constant *= -1
            constant = numerator_constant / denominator
            if variable_times_numerator.group(7) and variable_times_numerator.group(8):
                tail_constant = _parse_simple_number_value(variable_times_numerator.group(8))
                if tail_constant is None:
                    return None
                constant += (
                    tail_constant
                    if variable_times_numerator.group(7) == "+"
                    else -tail_constant
                )
            return (
                variable_times_numerator.group(2),
                coefficient / denominator,
                constant,
            )
    constant_first_variable_times_numerator = (
            CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_RE.fullmatch(
                side or ""
            )
        )
    if constant_first_variable_times_numerator:
            denominator = float(constant_first_variable_times_numerator.group(5))
            if abs(denominator) <= 1e-9:
                return None
            numerator_constant = _parse_simple_number_value(
                constant_first_variable_times_numerator.group(1)
            )
            if numerator_constant is None:
                return None
            coefficient = _parse_simple_number_value(
                constant_first_variable_times_numerator.group(4)
            )
            if coefficient is None:
                return None
            if constant_first_variable_times_numerator.group(2) == "-":
                coefficient *= -1
            constant = numerator_constant / denominator
            if (
                constant_first_variable_times_numerator.group(6)
                and constant_first_variable_times_numerator.group(7)
            ):
                tail_constant = _parse_simple_number_value(
                    constant_first_variable_times_numerator.group(7)
                )
                if tail_constant is None:
                    return None
                constant += (
                    tail_constant
                    if constant_first_variable_times_numerator.group(6) == "+"
                    else -tail_constant
                )
            return (
                constant_first_variable_times_numerator.group(3),
                coefficient / denominator,
                constant,
            )
    return None
