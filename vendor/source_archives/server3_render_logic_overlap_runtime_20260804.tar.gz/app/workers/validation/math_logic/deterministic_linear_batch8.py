from . import deterministic_guard as _guard

def parse_linear_grammar_batch8(prompt):
    parsed_batch7 = parse_linear_grammar_batch7(prompt)
    if parsed_batch7 is not None:
            return parsed_batch7
    match = REVERSED_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_EQUATION_RE.search(
            prompt
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(5))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            inner_value = left_value * denominator / coefficient
            expected = inner_value - offset if match.group(3) == "+" else inner_value + offset
            return match.group(2), expected
    match = SIMPLE_COEFFICIENT_PARENTHESIZED_DIVISION_AFFINE_EQUATION_RE.search(
            prompt
        )
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            inner_offset = _parse_simple_number_value(match.group(4))
            if inner_offset is None:
                return None
            tail_offset = _parse_simple_number_value(match.group(7))
            if tail_offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(8))
            if right_value is None:
                return None
            adjusted = right_value - tail_offset if match.group(6) == "+" else right_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(3) == "+"
                else inner_value + inner_offset
            )
            return match.group(2), expected
    match = REVERSED_COEFFICIENT_PARENTHESIZED_DIVISION_AFFINE_EQUATION_RE.search(
            prompt
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            inner_offset = _parse_simple_number_value(match.group(5))
            if inner_offset is None:
                return None
            tail_offset = _parse_simple_number_value(match.group(8))
            if tail_offset is None:
                return None
            adjusted = left_value - tail_offset if match.group(7) == "+" else left_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(4) == "+"
                else inner_value + inner_offset
            )
            return match.group(3), expected
    return None
