from . import deterministic_guard as _guard

def parse_linear_grammar_batch6(prompt):
    parsed_batch5 = parse_linear_grammar_batch5(prompt)
    if parsed_batch5 is not None:
            return parsed_batch5
    match = REVERSED_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            coefficient = _parse_simple_number_value(match.group(3))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            adjusted = left_value - offset if operator == "+" else left_value + offset
            return variable, adjusted / coefficient
    match = SIMPLE_COEFFICIENT_CONSTANT_FIRST_PARENTHESIZED_DIVISION_EQUATION_RE.search(
            prompt
        )
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            inner_constant = _parse_simple_number_value(match.group(2))
            if inner_constant is None:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(6))
            if right_value is None:
                return None
            inner_value = right_value * denominator / coefficient
            expected = (
                inner_value - inner_constant
                if match.group(3) == "+"
                else inner_constant - inner_value
            )
            return match.group(4), expected
    match = (
            REVERSED_COEFFICIENT_CONSTANT_FIRST_PARENTHESIZED_DIVISION_EQUATION_RE.search(
                prompt
            )
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            inner_constant = _parse_simple_number_value(match.group(3))
            if inner_constant is None:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            inner_value = left_value * denominator / coefficient
            expected = (
                inner_value - inner_constant
                if match.group(4) == "+"
                else inner_constant - inner_value
            )
            return match.group(5), expected
    return None
