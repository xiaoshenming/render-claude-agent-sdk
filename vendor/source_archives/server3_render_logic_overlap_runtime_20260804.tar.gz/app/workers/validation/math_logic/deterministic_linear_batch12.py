from . import deterministic_guard as _guard

def parse_linear_grammar_batch12(prompt):
    parsed_batch11 = parse_linear_grammar_batch11(prompt)
    if parsed_batch11 is not None:
            return parsed_batch11
    match = REVERSED_SIGNED_ADDITIVE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = -1.0 if match.group(2) == "-" else 1.0
            variable = match.group(3)
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            adjusted = left_value - offset if operator == "+" else left_value + offset
            return variable, adjusted / coefficient
    match = REVERSED_SIGNED_VARIABLE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = -1.0 if match.group(2) == "-" else 1.0
            variable = match.group(3)
            return variable, left_value / coefficient
    match = SIMPLE_DIRECT_VARIABLE_EQUATION_RE.search(prompt)
    if match:
            variable = match.group(1)
            right_value = _parse_simple_number_value(match.group(2))
            if right_value is None:
                return None
            return variable, right_value
    return None
