import re

from .deterministic_guard_constants import (
    COEFFICIENT_VARIABLE_MULTIPLY_PATTERN,
    EXPLICIT_MULTIPLY_PATTERN,
    SIMPLE_NUMBER_VALUE_PATTERN,
)
from .deterministic_guard_constants import *  # noqa: F401,F403 - split constants share base patterns

AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN = (
    rf"[(（]\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*"
    rf"(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?[a-zA-Z]\s*[)）]\s*"
    rf"[/÷]\s*[+-]?\d+(?:\.\d+)?\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

VARIABLE_FIRST_AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN = (
    rf"[(（]\s*[+-]?\s*(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?[a-zA-Z]\s*[+-]\s*"
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*[)）]\s*[/÷]\s*"
    rf"[+-]?\d+(?:\.\d+)?\s*(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN = (
    rf"[(（]\s*[+-]?\s*[a-zA-Z]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*"
    rf"[)）]\s*[/÷]\s*[+-]?\d+(?:\.\d+)?\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN = (
    rf"[(（]\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*[a-zA-Z]\s*"
    rf"{EXPLICIT_MULTIPLY_PATTERN}{SIMPLE_NUMBER_VALUE_PATTERN}\s*[)）]\s*"
    rf"[/÷]\s*[+-]?\d+(?:\.\d+)?\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

TEX_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN = (
    rf"\\frac\s*\{{\s*[+-]?\s*[a-zA-Z]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*"
    rf"\}}\s*\{{\s*[+-]?\d+(?:\.\d+)?\s*\}}\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

TEX_CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN = (
    rf"\\frac\s*\{{\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*"
    rf"[a-zA-Z]\s*{EXPLICIT_MULTIPLY_PATTERN}{SIMPLE_NUMBER_VALUE_PATTERN}\s*"
    rf"\}}\s*\{{\s*[+-]?\d+(?:\.\d+)?\s*\}}\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN = (
    rf"\\frac\s*\{{\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*"
    rf"(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?[a-zA-Z]\s*\}}\s*"
    rf"\{{\s*[+-]?\d+(?:\.\d+)?\s*\}}\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

VARIABLE_FIRST_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN = (
    rf"\\frac\s*\{{\s*[+-]?\s*(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?[a-zA-Z]\s*[+-]\s*"
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*\}}\s*"
    rf"\{{\s*[+-]?\d+(?:\.\d+)?\s*\}}\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

AFFINE_EQUATION_SIDE_PATTERN = (
    rf"(?:{PARENTHESIZED_AFFINE_EQUATION_SIDE_PATTERN}|"
    rf"{TEX_CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN}|"
    rf"{TEX_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN}|"
    rf"{VARIABLE_FIRST_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN}|"
    rf"{TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_PATTERN}|"
    rf"{CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN}|"
    rf"{VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN}|"
    rf"{VARIABLE_FIRST_AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN}|"
    rf"{AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_PATTERN}|"
    rf"{TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_PATTERN}|"
    rf"{DIVISION_AFFINE_EQUATION_SIDE_PATTERN}|"
    rf"{CONSTANT_FIRST_TEX_VARIABLE_FRACTION_EQUATION_SIDE_PATTERN}|"
    rf"{CONSTANT_FIRST_DIVISION_AFFINE_EQUATION_SIDE_PATTERN}|"
    rf"{CONSTANT_FIRST_AFFINE_EQUATION_SIDE_PATTERN}|"
    rf"{LINEAR_AFFINE_EQUATION_SIDE_PATTERN})"
)

TWO_SIDED_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({AFFINE_EQUATION_SIDE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"({AFFINE_EQUATION_SIDE_PATTERN})(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

AFFINE_EQUATION_SIDE_RE = re.compile(
    rf"^\s*([+-]?)\s*(?:({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?([a-zA-Z])\s*"
    rf"(?:([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN}))?\s*$"
)

PARENTHESIZED_AFFINE_EQUATION_SIDE_RE = re.compile(
    rf"^\s*([+-]?)\s*(?:({SIMPLE_NUMBER_VALUE_PATTERN})\s*)?"
    rf"[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*$"
)

DIVISION_AFFINE_EQUATION_SIDE_RE = re.compile(
    rf"^\s*([+-]?)\s*([a-zA-Z])\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*(?:([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN}))?\s*$"
)

TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_RE = re.compile(
    rf"^\s*([+-]?)\s*\\frac\s*\{{\s*([a-zA-Z])\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*(?:([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN}))?\s*$"
)

CONSTANT_FIRST_AFFINE_EQUATION_SIDE_RE = re.compile(
    rf"^\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*"
    rf"(?:(?:({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?([a-zA-Z]))\s*$"
)

CONSTANT_FIRST_DIVISION_AFFINE_EQUATION_SIDE_RE = re.compile(
    rf"^\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*"
    rf"([a-zA-Z])\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*$"
)

CONSTANT_FIRST_TEX_VARIABLE_FRACTION_EQUATION_SIDE_RE = re.compile(
    rf"^\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*"
    rf"\\frac\s*\{{\s*([a-zA-Z])\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*$"
)

AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_RE = re.compile(
    rf"^\s*[(（]\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*"
    rf"(?:(?:({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?([a-zA-Z]))\s*[)）]\s*"
    rf"[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*(?:([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN}))?\s*$"
)

VARIABLE_FIRST_AFFINE_NUMERATOR_DIVISION_EQUATION_SIDE_RE = re.compile(
    rf"^\s*[(（]\s*([+-]?)\s*(?:({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*"
    rf"[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*(?:([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN}))?\s*$"
)

VARIABLE_TIMES_COEFFICIENT_NUMERATOR_DIVISION_EQUATION_SIDE_RE = re.compile(
    rf"^\s*[(（]\s*([+-]?)\s*([a-zA-Z])\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*(?:([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN}))?\s*$"
)
