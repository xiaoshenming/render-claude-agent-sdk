import re
from typing import Any

def _two_number_assignment(
    text: str,
    first_name: str,
    second_name: str,
) -> tuple[float, float] | None:
    number = r"(-?\d+(?:\.\d+)?)"
    match = re.search(
        rf"\b{first_name}\s*,\s*{second_name}\s*=\s*{number}\s*,\s*{number}",
        text,
    )
    if not match:
        return None
    return float(match.group(1)), float(match.group(2))

def _arithmetic_sequence_issue(text: str, user_prompt: str) -> dict[str, Any] | None:
    spec = _extract_arithmetic_sequence_spec(user_prompt)
    if spec is None:
        return None
    a1, d, n = spec
    expected_last = a1 + (n - 1) * d
    expected_sum = n * (a1 + expected_last) / 2

    wrong_last = _find_conflicting_arithmetic_last_term(text, n, expected_last)
    wrong_sum = _find_conflicting_arithmetic_sum(text, n, expected_sum)
    if wrong_last is None and wrong_sum is None:
        return None

    pieces = [
        f"等差数列首项 {_fmt_number(a1)}, 公差 {_fmt_number(d)}, n={n}; "
        f"末项应为 {_fmt_number(expected_last)}, 前{n}项和应为 {_fmt_number(expected_sum)}。"
    ]
    if wrong_last is not None:
        pieces.append(f"代码/文案中出现末项 {_fmt_number(wrong_last)}。")
    if wrong_sum is not None:
        pieces.append(f"代码/文案中出现前{n}项和 {_fmt_number(wrong_sum)}。")
    return {
        "evidence": "".join(pieces),
        "suggested_fix": (
            f"将 a{n} 改为 {_fmt_number(expected_last)}, "
            f"S{n} 改为 {_fmt_number(expected_sum)}, 并同步所有相关公式和旁白。"
        ),
        "metadata": {
            "guard": "arithmetic_sequence",
            "a1": a1,
            "d": d,
            "n": n,
            "expected_last": expected_last,
            "expected_sum": expected_sum,
            "wrong_last": wrong_last,
            "wrong_sum": wrong_sum,
        },
    }

def _extract_arithmetic_sequence_spec(user_prompt: str) -> tuple[float, float, int] | None:
    prompt = user_prompt or ""
    has_sequence_words = bool(re.search(r"等差|arithmetic\s+sequence", prompt, flags=re.I))
    a1 = _search_number(
        prompt,
        [
            r"首项\s*(?:为|是|=|:|：)?\s*(-?\d+(?:\.\d+)?)",
            r"\ba_?1\s*(?:=|:|：)\s*(-?\d+(?:\.\d+)?)",
            r"\ba\{?1\}?\s*(?:=|:|：)\s*(-?\d+(?:\.\d+)?)",
        ],
    )
    d = _search_number(
        prompt,
        [
            r"公差\s*(?:为|是|=|:|：)?\s*(-?\d+(?:\.\d+)?)",
            r"\bd\s*(?:=|:|：)\s*(-?\d+(?:\.\d+)?)",
        ],
    )
    n_value = _search_number(
        prompt,
        [
            r"前\s*(\d+)\s*项(?:和|的和)",
            r"\bn\s*(?:=|:|：)\s*(\d+)",
            r"S_\{?(\d+)\}?",
        ],
    )
    if a1 is None or d is None or n_value is None:
        return None
    if not has_sequence_words and "首项" not in prompt and "公差" not in prompt:
        return None
    n = int(n_value)
    if n <= 0 or n > 10000:
        return None
    return a1, d, n

def _find_conflicting_arithmetic_last_term(
    text: str,
    n: int,
    expected_last: float,
) -> float | None:
    compact = text.replace("{", "").replace("}", "")
    patterns = [
        r"\blast_term\s*=\s*(-?\d+(?:\.\d+)?)",
        rf"\ba_?{n}\s*=\s*(-?\d+(?:\.\d+)?)",
        rf"\ba{n}\s*=\s*(-?\d+(?:\.\d+)?)",
        rf"第\s*{n}\s*项\s*(?:=|为|是|:|：)\s*(-?\d+(?:\.\d+)?)",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, compact):
            value = float(match.group(1))
            if not _same_number(value, expected_last):
                return value
    return None

def _find_conflicting_arithmetic_sum(
    text: str,
    n: int,
    expected_sum: float,
) -> float | None:
    compact = text.replace("{", "").replace("}", "")
    assignment_patterns = [
        r"\b(?:sum_value|final_sum|total_sum)\s*=\s*(-?\d+(?:\.\d+)?)",
        rf"\bS_?{n}\s*=\s*(-?\d+(?:\.\d+)?)",
    ]
    for pattern in assignment_patterns:
        for match in re.finditer(pattern, compact):
            value = float(match.group(1))
            if not _same_number(value, expected_sum):
                return value

    for segment in re.findall(rf"S_?{n}[^\n;]*", compact):
        if "=" not in segment:
            continue
        tail = segment.rsplit("=", 1)[-1]
        match = re.match(r"\s*(-?\d+(?:\.\d+)?)", tail)
        if not match:
            continue
        value = float(match.group(1))
        if not _same_number(value, expected_sum):
            return value
    return None

def _number_assignment(text: str, name: str) -> float | None:
    match = re.search(rf"\b{name}\s*=\s*(-?\d+(?:\.\d+)?)", text)
    if not match:
        return None
    return float(match.group(1))
