from typing import Any

def _origin_ccw_90_coordinate_rotation_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    prompt = _normalize_minus(user_prompt or "")
    if not (
        re.search(r"原点", prompt)
        and re.search(r"逆时针", prompt)
        and re.search(r"90\s*[°度]?", prompt)
        and re.search(r"坐标|旋转", prompt)
    ):
        return None

    originals = _extract_named_coordinates(prompt, primed=False)
    if not originals:
        return None
    expected = {
        name: (_clean_zero(-y), _clean_zero(x))
        for name, (x, y) in originals.items()
    }
    actual_occurrences = _extract_named_coordinate_occurrences(
        _normalize_minus(text or ""),
        primed=True,
    )
    if not actual_occurrences:
        return None

    wrong: dict[str, dict[str, tuple[float, float]]] = {}
    for name, expected_xy in expected.items():
        candidates = actual_occurrences.get(name) or []
        if not candidates:
            continue
        if any(_same_point(candidate, expected_xy) for candidate in candidates):
            continue
        actual_xy = candidates[-1]
        if not _same_point(actual_xy, expected_xy):
            wrong[name] = {"actual": actual_xy, "expected": expected_xy}
    if not wrong:
        return None

    expected_label = "，".join(
        f"{name}'={_format_point(point)}" for name, point in expected.items()
    )
    wrong_label = "，".join(
        f"{name}' 当前为 {_format_point(payload['actual'])}，"
        f"应为 {_format_point(payload['expected'])}"
        for name, payload in wrong.items()
    )
    return {
        "evidence": (
            "原点逆时针旋转90度应使用 (x,y)->(-y,x)；"
            f"{wrong_label}。"
        ),
        "suggested_fix": (
            "按 (x,y)->(-y,x) 同步修正所有坐标标签、公式和总结："
            f"{expected_label}。"
        ),
        "metadata": {
            "guard": "origin_ccw_90_coordinate_rotation",
            "expected_coordinates": {
                f"{name}'": [point[0], point[1]]
                for name, point in expected.items()
            },
            "wrong_coordinates": {
                f"{name}'": {
                    "actual": [payload["actual"][0], payload["actual"][1]],
                    "expected": [
                        payload["expected"][0],
                        payload["expected"][1],
                    ],
                }
                for name, payload in wrong.items()
            },
        },
    }

def _extract_named_coordinates(
    text: str,
    *,
    primed: bool,
) -> dict[str, tuple[float, float]]:
    return {
        name: points[0]
        for name, points in _extract_named_coordinate_occurrences(
            text,
            primed=primed,
        ).items()
        if points
    }

def _extract_named_coordinate_occurrences(
    text: str,
    *,
    primed: bool,
) -> dict[str, list[tuple[float, float]]]:
    marker = r"(?:['’′]|撇)" if primed else r"(?!\s*(?:['’′]|撇))"
    pattern = re.compile(
        rf"([A-Z])\s*{marker}\s*[（(]\s*"
        rf"([+-]?\d+(?:\.\d+)?)\s*[,，]\s*"
        rf"([+-]?\d+(?:\.\d+)?)\s*[)）]"
    )
    points: dict[str, list[tuple[float, float]]] = {}
    for match in pattern.finditer(text or ""):
        points.setdefault(match.group(1), []).append(
            (
                _clean_zero(float(match.group(2))),
                _clean_zero(float(match.group(3))),
            ),
        )
    return points

def _normalize_minus(text: str) -> str:
    return (text or "").replace("−", "-").replace("－", "-")

def _same_point(
    actual: tuple[float, float],
    expected: tuple[float, float],
) -> bool:
    return (
        abs(actual[0] - expected[0]) <= 1e-9
        and abs(actual[1] - expected[1]) <= 1e-9
    )

def _clean_zero(value: float) -> float:
    return 0.0 if abs(value) <= 1e-9 else value

def _format_point(point: tuple[float, float]) -> str:
    return f"({_fmt_number(point[0])},{_fmt_number(point[1])})"
