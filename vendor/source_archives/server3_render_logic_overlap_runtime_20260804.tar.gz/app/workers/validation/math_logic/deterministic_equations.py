from typing import Any

def _pythagorean_cut_fill_inner_square_issue(text: str) -> dict[str, Any] | None:
    if not re.search(r"(勾股|Pythagorean|c\s*\^?\s*2|边长\s*c|斜边\s*c)", text, re.I):
        return None
    if "Polygon" not in text:
        return None
    if not all(
        _has_np_array_point(text, x_name, y_name)
        for x_name, y_name in (("a", "a"), ("a", "b"), ("b", "b"), ("b", "a"))
    ):
        return None

    values = _two_number_assignment(text, "a", "b")
    metadata: dict[str, Any] = {
        "guard": "pythagorean_cut_fill_inner_square",
        "actual_side_expression": "|b-a|",
        "expected_side_expression": "sqrt(a^2+b^2)",
    }
    actual_label = "|b-a|"
    expected_label = "c"
    if values:
        a_value, b_value = values
        actual_side = abs(b_value - a_value)
        expected_side = (a_value * a_value + b_value * b_value) ** 0.5
        metadata.update(
            {
                "a": a_value,
                "b": b_value,
                "actual_side": actual_side,
                "expected_side": expected_side,
            }
        )
        actual_label = f"|b-a|={_fmt_number(actual_side)}"
        expected_label = f"c={_fmt_number(expected_side)}"

    return {
        "evidence": (
            "勾股割补图中内部正方形使用 (a,a)、(a,b)、(b,b)、(b,a) "
            f"作为顶点，边长是 {actual_label}，不是四个直角三角形斜边围成的 "
            f"{expected_label}。"
        ),
        "suggested_fix": (
            "将内部正方形改为由四个三角形斜边围成的旋转正方形，"
            "不要用 (a,a)、(a,b)、(b,b)、(b,a) 画轴对齐小方块。"
        ),
        "metadata": metadata,
    }

def _square_equation_final_answer_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    spec = _extract_square_equation_spec(user_prompt)
    if spec is None:
        return None
    variable, expected_roots = spec
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None

    actual_roots = _extract_final_root_values(text, variable)
    if not actual_roots:
        numeric_answer = _extract_final_numeric_answer(text)
        if numeric_answer is not None:
            actual_roots = [numeric_answer]
    if not actual_roots:
        return None
    missing = [
        root for root in expected_roots
        if not any(_same_number(root, actual) for actual in actual_roots)
    ]
    if not missing:
        return None

    expected_label = "、".join(
        f"{variable}={_fmt_number(root)}" for root in expected_roots
    )
    missing_label = "、".join(
        f"{variable}={_fmt_number(root)}" for root in missing
    )
    actual_label = "、".join(
        f"{variable}={_fmt_number(root)}" for root in actual_roots
    )
    return {
        "evidence": (
            f"题干平方方程应包含 {expected_label}，"
            f"但当前最终答案只有 {actual_label}，缺少 {missing_label}。"
        ),
        "suggested_fix": f"补齐平方方程全部根：{expected_label}。",
        "metadata": {
            "guard": "square_equation_roots",
            "variable": variable,
            "expected_roots": expected_roots,
            "actual_roots": actual_roots,
            "missing_roots": missing,
        },
    }

def _extract_square_equation_spec(user_prompt: str) -> tuple[str, list[float]] | None:
    prompt = (user_prompt or "").replace("{", "").replace("}", "")
    if not LINEAR_EQUATION_CONTEXT_RE.search(prompt):
        return None
    match = SQUARE_EQUATION_RE.search(prompt)
    if match:
        variable = match.group(1)
        value = float(match.group(2))
    else:
        match = REVERSED_SQUARE_EQUATION_RE.search(prompt)
        if not match:
            return None
        value = float(match.group(1))
        variable = match.group(2)
    if value < 0:
        return None
    root = value ** 0.5
    if _same_number(root, 0):
        return variable, [0.0]
    return variable, [root, -root]

def _extract_final_root_values(text: str, variable: str) -> list[float]:
    normalized = (
        (text or "")
        .replace("\\\\", "\\")
        .replace("{", "")
        .replace("}", "")
        .replace("±", "\\pm")
    )
    roots: list[float] = []
    pm_pattern = re.compile(
        rf"(?<![A-Za-z0-9]){re.escape(variable)}\s*"
        rf"{FINAL_ASSIGNMENT_SUBJECT_SUFFIX_PATTERN}\s*"
        rf"(?:{FINAL_ASSIGNMENT_OPERATOR_PATTERN})\s*"
        rf"\\pm\s*(-?\d+(?:\.\d+)?)"
    )
    for match in pm_pattern.finditer(normalized):
        value = abs(float(match.group(1)))
        _append_unique_number(roots, value)
        _append_unique_number(roots, -value)

    value_pattern = re.compile(
        rf"(?<![A-Za-z0-9]){re.escape(variable)}(?:_\d+|[₁₂])?\s*=\s*(-?\d+(?:\.\d+)?)"
    )
    for match in value_pattern.finditer(normalized):
        _append_unique_number(roots, float(match.group(1)))
    for value in _extract_final_variable_values(normalized, variable):
        _append_unique_number(roots, value)
    return roots

def _unit_dimension_issue(text: str, user_prompt: str) -> dict[str, Any] | None:
    expected_dimension = _expected_unit_dimension(user_prompt)
    if expected_dimension is None:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    actual = _extract_final_unit_dimension(text)
    if actual is None:
        return None
    actual_unit, actual_dimension = actual
    if actual_dimension == expected_dimension:
        return None

    expected_label = "平方单位" if expected_dimension == 2 else "立方单位"
    return {
        "evidence": (
            f"题干要求的是{'面积' if expected_dimension == 2 else '体积'}，"
            f"结果应使用{expected_label}，但当前最终答案单位为 {actual_unit}。"
        ),
        "suggested_fix": f"将最终答案单位改为{expected_label}，并同步画面文本和旁白。",
        "metadata": {
            "guard": "unit_dimension",
            "expected_dimension": expected_dimension,
            "actual_dimension": actual_dimension,
            "actual_unit": actual_unit,
        },
    }

def _expected_unit_dimension(user_prompt: str) -> int | None:
    prompt = user_prompt or ""
    if re.search(r"体积|容积", prompt):
        return 3
    if "面积" in prompt:
        return 2
    return None

def _extract_final_unit_dimension(text: str) -> tuple[str, int] | None:
    matches = list(UNIT_PATTERN_RE.finditer(text or ""))
    if not matches:
        return None
    match = matches[-1]
    prefix = match.group(2) or ""
    unit = match.group(3)
    exponent = match.group(4) or match.group(5) or ""
    if prefix == "平方" or exponent in {"2", "²"}:
        return f"{prefix}{unit}{exponent}".strip(), 2
    if prefix == "立方" or exponent in {"3", "³"}:
        return f"{prefix}{unit}{exponent}".strip(), 3
    return unit, 1
