"""Evidence-only math-logic claim extraction compatibility facade."""
# ruff: noqa: F401

from __future__ import annotations

from typing import Any

from .claim_ast import (
    _assigned_names,
    _collect_dependency_context,
    _collect_logical_block,
    _delimiter_delta,
    _extract_identifiers,
    _is_geometry_context_assignment,
    _is_noise_line,
    _names_used_by_blocks,
    _parse_assignment,
)
from .claim_contracts import (
    GEOMETRY_CONTEXT_RE,
    MARKER_END_RE,
    MARKER_START_RE,
    NOISE_PREFIXES,
    TARGET_LINE_RE,
)
from .claim_normalization import (
    _is_coordinate_transform_text_line,
    _is_figure_line_target,
    _is_geometry_context,
    _is_geometry_formula_line,
    _is_geometry_review_line,
    _is_visual_geometry,
    _normalize_scope,
    _shorten,
    _statement_from_context,
)


def extract_math_logic_targets(
    *,
    scene_name: str,
    scene_code: str,
    narration: str = "",
    planning_scene: dict | None = None,
    scope: str = "all",
    max_chars: int = 7000,
) -> list[dict[str, Any]]:
    normalized_scope = _normalize_scope(scope)
    lines = scene_code.splitlines()
    marked = _extract_marked_targets(
        scene_name=scene_name,
        lines=lines,
        narration=narration,
        planning_scene=planning_scene,
        scope=normalized_scope,
        max_chars=max_chars,
    )
    if marked:
        return marked

    statement = _statement_from_context(
        narration=narration,
        planning_scene=planning_scene,
        fallback=f"{scene_name} math logic target",
    )
    geometry_context = _is_geometry_context(statement)
    compact_lines = _collect_auto_compact_lines(
        lines=lines,
        scope=normalized_scope,
        geometry_context=geometry_context,
    )

    if normalized_scope in {"geometry", "figure_lines"} and not (
        compact_lines or geometry_context
    ):
        return []
    if compact_lines:
        target_code = "\n".join(
            f"L{line_no}: {line}" for line_no, line in compact_lines
        )[:max_chars]
        start_line = compact_lines[0][0]
        end_line = compact_lines[-1][0]
        expression_mode = (
            "visual_geometry"
            if (
                geometry_context
                or any(
                    _is_visual_geometry(line) or _is_geometry_review_line(line)
                    for _, line in compact_lines
                )
            )
            else "text_formula"
        )
    elif planning_scene:
        if normalized_scope == "figure_lines":
            return []
        target_code = ""
        start_line = 1
        end_line = max(1, len(lines))
        expression_mode = "conceptual_summary"
    else:
        return []

    return [
        {
            "claim_id": "auto_001",
            "scene_name": scene_name,
            "statement": statement,
            "target_code": target_code,
            "start_line": start_line,
            "end_line": end_line,
            "expression_mode": expression_mode,
        }
    ]


def _extract_marked_targets(
    *,
    scene_name: str,
    lines: list[str],
    narration: str,
    planning_scene: dict | None,
    scope: str,
    max_chars: int,
) -> list[dict[str, Any]]:
    targets: list[dict[str, Any]] = []
    active_start: int | None = None
    active_statement = ""
    body: list[tuple[int, str]] = []

    for line_no, raw_line in enumerate(lines, start=1):
        stripped = raw_line.strip()
        start_match = MARKER_START_RE.search(stripped)
        if start_match:
            active_start = line_no
            active_statement = (start_match.group(1) or "").strip()
            body = []
            continue
        if active_start is None:
            continue
        if MARKER_END_RE.search(stripped):
            statement = active_statement or _statement_from_context(
                narration=narration,
                planning_scene=planning_scene,
                fallback=f"{scene_name} marked claim",
            )
            compact = _compact_marked_body(body, max_chars=max_chars)
            if scope == "figure_lines":
                geometry_context = _is_geometry_context(statement)
                body = [
                    (item_line_no, item_line)
                    for item_line_no, item_line in body
                    if _is_figure_line_target(item_line, geometry_context)
                ]
                compact = _compact_marked_body(body, max_chars=max_chars)
            if scope in {"geometry", "figure_lines"} and not (
                _is_geometry_context(statement)
                or any(_is_geometry_review_line(line) for _, line in body)
            ):
                active_start = None
                active_statement = ""
                body = []
                continue
            targets.append(
                {
                    "claim_id": f"marked_{len(targets) + 1:03d}",
                    "scene_name": scene_name,
                    "statement": statement,
                    "target_code": compact,
                    "start_line": active_start,
                    "end_line": line_no,
                    "expression_mode": (
                        "visual_geometry"
                        if any(_is_visual_geometry(line) for _, line in body)
                        else "text_formula"
                    ),
                }
            )
            active_start = None
            active_statement = ""
            body = []
            continue
        if stripped and not stripped.startswith(NOISE_PREFIXES):
            body.append((line_no, stripped))

    return targets


def _compact_marked_body(body: list[tuple[int, str]], max_chars: int) -> str:
    return "\n".join(f"L{line_no}: {line}" for line_no, line in body)[:max_chars]


def _collect_auto_compact_lines(
    *,
    lines: list[str],
    scope: str,
    geometry_context: bool,
) -> list[tuple[int, str]]:
    target_blocks: list[list[tuple[int, str]]] = []
    index = 0
    while index < len(lines):
        stripped = lines[index].strip()
        if _is_noise_line(stripped):
            index += 1
            continue
        if not TARGET_LINE_RE.search(stripped):
            index += 1
            continue
        if scope == "figure_lines":
            if not _is_figure_line_target(stripped, geometry_context):
                index += 1
                continue
        elif (
            scope == "geometry"
            and not geometry_context
            and not _is_geometry_review_line(stripped)
        ):
            index += 1
            continue

        block, next_index = _collect_logical_block(lines, index)
        if block:
            target_blocks.append(block)
        index = max(next_index, index + 1)

    if not target_blocks:
        return []

    context_lines = _collect_dependency_context(lines, target_blocks)
    merged: dict[int, str] = {}
    for line_no, line in context_lines:
        merged.setdefault(line_no, line)
    for block in target_blocks:
        for line_no, line in block:
            merged.setdefault(line_no, line)
    return sorted(merged.items())
