from __future__ import annotations

import ast
import math
import re
from dataclasses import dataclass
from typing import Any


Point = tuple[float, float]
EPSILON = 1e-6


@dataclass(frozen=True)
class ParsedGeometry:
    values: dict[str, float]
    point_vars: dict[str, Point]
    point_lists: dict[str, list[Point]]
    polygons: dict[str, list[Point]]



def _safe_eval_number(expression: str, values: dict[str, float]) -> float | None:
    try:
        node = ast.parse(expression.strip(), mode="eval")
    except SyntaxError:
        return None
    try:
        return float(_eval_number_node(node.body, values))
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return None
def _eval_number_node(node: ast.AST, values: dict[str, float]) -> float:
    if isinstance(node, ast.Constant) and isinstance(node.value, int | float):
        return float(node.value)
    if isinstance(node, ast.Name):
        return values[node.id]
    if isinstance(node, ast.UnaryOp):
        operand = _eval_number_node(node.operand, values)
        if isinstance(node.op, ast.USub):
            return -operand
        if isinstance(node.op, ast.UAdd):
            return operand
    if isinstance(node, ast.BinOp):
        left = _eval_number_node(node.left, values)
        right = _eval_number_node(node.right, values)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            return left / right
        if isinstance(node.op, ast.Pow):
            return left**right
    raise TypeError(f"unsupported numeric expression: {ast.dump(node)}")
def _split_top_level(text: str) -> list[str]:
    parts: list[str] = []
    start = 0
    depth = 0
    in_string: str | None = None
    escaped = False
    for index, char in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == in_string:
                in_string = None
            continue
        if char in ("'", '"'):
            in_string = char
            continue
        if char in "([{":
            depth += 1
        elif char in ")]}":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append(text[start:index].strip())
            start = index + 1
    tail = text[start:].strip()
    if tail:
        parts.append(tail)
    return parts
def _looks_like_keyword_arg(expression: str) -> bool:
    return bool(re.match(r"[A-Za-z_]\w*\s*=", expression))
def _claimed_collinear_point_names(text: str) -> list[str]:
    match = re.search(
        r"([A-Z](?:\s*[、,，]\s*[A-Z]){2,})[^。；;\n]{0,20}(?:共线|同一直线|collinear)",
        text,
        flags=re.I,
    )
    if not match:
        return []
    return re.findall(r"[A-Z]", match.group(1))
def _mentions_pythagorean_cut_fill(text: str, user_prompt: str) -> bool:
    combined = f"{user_prompt}\n{text}"
    return bool(re.search(r"勾股|赵爽|弦图|Pythagorean|c\s*(?:\^|\*\*)\s*2", combined, re.I))
def _outer_square_polygon(polygons: dict[str, list[Point]]) -> tuple[str, list[Point]] | None:
    candidates = [
        (name, points)
        for name, points in polygons.items()
        if len(points) == 4 and re.search(r"outer|big|large|square|sq", name, re.I)
    ]
    if not candidates:
        return None
    outer_candidates = [
        candidate for candidate in candidates if re.search(r"outer|big|large", candidate[0], re.I)
    ]
    if outer_candidates:
        return outer_candidates[0]
    return candidates[0]
def _polygon_side_lengths(points: list[Point]) -> list[float]:
    return [
        _distance(points[index], points[(index + 1) % len(points)])
        for index in range(len(points))
    ]
def _triangle_side_lengths(points: list[Point]) -> list[float]:
    return [
        _distance(points[0], points[1]),
        _distance(points[1], points[2]),
        _distance(points[2], points[0]),
    ]
def _adjacent_dot_products(points: list[Point]) -> list[float]:
    dots: list[float] = []
    for index in range(len(points)):
        current = points[index]
        previous = points[index - 1]
        next_point = points[(index + 1) % len(points)]
        first = (previous[0] - current[0], previous[1] - current[1])
        second = (next_point[0] - current[0], next_point[1] - current[1])
        dots.append(first[0] * second[0] + first[1] * second[1])
    return dots
def _is_square(points: list[Point]) -> bool:
    if len(points) != 4:
        return False
    side_lengths = _polygon_side_lengths(points)
    if min(side_lengths) <= EPSILON:
        return False
    average_side = sum(side_lengths) / 4
    if any(not _close(length, average_side) for length in side_lengths):
        return False
    return all(
        abs(dot) <= EPSILON * max(1.0, average_side**2)
        for dot in _adjacent_dot_products(points)
    )
def _shared_point_count(first: list[Point], second: list[Point]) -> int:
    count = 0
    for first_point in first:
        if any(_same_point(first_point, second_point) for second_point in second):
            count += 1
    return count
def _cross(a_point: Point, b_point: Point, c_point: Point) -> float:
    return (b_point[0] - a_point[0]) * (c_point[1] - a_point[1]) - (
        b_point[1] - a_point[1]
    ) * (c_point[0] - a_point[0])
def _distance(first: Point, second: Point) -> float:
    return math.hypot(first[0] - second[0], first[1] - second[1])
def _same_point(first: Point, second: Point) -> bool:
    return _close(first[0], second[0]) and _close(first[1], second[1])
def _close(first: float, second: float) -> bool:
    return math.isclose(first, second, rel_tol=1e-6, abs_tol=EPSILON)
def _clean_zero(value: float) -> float:
    return 0.0 if abs(value) <= EPSILON else value
def _strip_line_prefixes(text: str) -> str:
    return re.sub(r"(?m)^\s*L\d+:\s*", "", text or "")
def _fmt_number(value: float) -> str:
    if abs(value - round(value)) <= 1e-9:
        return str(int(round(value)))
    return f"{value:.6g}"
def _fmt_numbers(values: list[float]) -> str:
    return "[" + ", ".join(_fmt_number(value) for value in values) + "]"

