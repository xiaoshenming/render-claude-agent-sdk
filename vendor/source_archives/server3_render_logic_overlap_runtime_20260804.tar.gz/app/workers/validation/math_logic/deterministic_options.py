from typing import Any

def _missing_subquestion_issue(text: str, user_prompt: str) -> dict[str, Any] | None:
    prompt_numbers = _extract_subquestion_numbers(user_prompt)
    if len(prompt_numbers) < 2:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None

    covered_numbers = set(_extract_subquestion_numbers(text))
    if not covered_numbers:
        return None
    missing_numbers = [number for number in prompt_numbers if number not in covered_numbers]
    if not missing_numbers:
        return None

    covered_labels = "、".join(_format_subquestion(number) for number in sorted(covered_numbers))
    missing_labels = "、".join(_format_subquestion(number) for number in missing_numbers)
    prompt_labels = "、".join(_format_subquestion(number) for number in prompt_numbers)
    return {
        "evidence": (
            f"题干包含 {prompt_labels}，但当前最终答案/汇总只出现 {covered_labels}，"
            f"缺少 {missing_labels}。"
        ),
        "suggested_fix": f"补齐 {missing_labels} 的解题步骤和最终答案，并保持题干小问顺序。",
        "metadata": {
            "guard": "missing_subquestion",
            "prompt_subquestions": prompt_numbers,
            "covered_subquestions": sorted(covered_numbers),
            "missing_subquestions": missing_numbers,
        },
    }

def _extract_subquestion_numbers(text: str) -> list[int]:
    numbers: list[int] = []
    seen: set[int] = set()
    for match in SUBQUESTION_MARKER_RE.finditer(text or ""):
        raw = next((group for group in match.groups() if group), "")
        number = int(raw) if raw.isascii() and raw.isdigit() else SUBQUESTION_LABELS.get(raw, 0)
        if number and number not in seen:
            numbers.append(number)
            seen.add(number)
    return numbers

def _format_subquestion(number: int) -> str:
    return f"第({number})问"

def _option_order_issue(text: str, user_prompt: str) -> dict[str, Any] | None:
    prompt_order = _extract_option_order(user_prompt)
    if len(prompt_order) < 3:
        return None
    if not OPTION_ORDER_CONTEXT_RE.search(text or ""):
        return None

    generated_order = _extract_option_order(text)
    if len(generated_order) < 3:
        return None
    expected_order = [letter for letter in prompt_order if letter in generated_order]
    if generated_order == expected_order:
        return None

    expected_label = "→".join(expected_order)
    generated_label = "→".join(generated_order)
    return {
        "evidence": (
            f"题干选项顺序为 {expected_label}，但当前逐项解析顺序为 {generated_label}。"
        ),
        "suggested_fix": f"按 {expected_label} 顺序重排选项解析，保持原题选项顺序不变。",
        "metadata": {
            "guard": "option_order",
            "expected_order": expected_order,
            "generated_order": generated_order,
        },
    }

def _extract_option_order(text: str) -> list[str]:
    order: list[str] = []
    seen: set[str] = set()
    for match in OPTION_MARKER_RE.finditer(text or ""):
        letter = match.group(1)
        if letter not in seen:
            order.append(letter)
            seen.add(letter)
    return order

def _option_answer_issue(text: str, user_prompt: str) -> dict[str, Any] | None:
    prompt_options = _extract_option_order(user_prompt)
    if len(prompt_options) < 2:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    answer = _extract_final_option_answer(text)
    if not answer:
        return None
    if answer not in prompt_options:
        prompt_label = "、".join(prompt_options)
        return {
            "evidence": (
                f"题干选项只有 {prompt_label}，但当前最终答案为 {answer}。"
            ),
            "suggested_fix": "将最终答案改为题干已有选项，并同步选项解析和画面文本。",
            "metadata": {
                "guard": "option_answer",
                "prompt_options": prompt_options,
                "answer": answer,
            },
        }

    correct_claims = _extract_correct_option_claims(text)
    if len(correct_claims) != 1 or correct_claims[0] == answer:
        return None
    correct_answer = correct_claims[0]
    return {
        "evidence": (
            f"解析标记 {correct_answer} 项正确，但当前最终答案为 {answer}。"
        ),
        "suggested_fix": "同步选项解析和最终答案，确保正确项与最终答案一致。",
        "metadata": {
            "guard": "option_answer",
            "prompt_options": prompt_options,
            "answer": answer,
            "claimed_correct": correct_answer,
        },
    }

def _extract_final_option_answer(text: str) -> str | None:
    match = FINAL_OPTION_ANSWER_RE.search(text or "")
    return match.group(1) if match else None

def _extract_correct_option_claims(text: str) -> list[str]:
    claims: list[str] = []
    seen: set[str] = set()
    for match in CORRECT_OPTION_CLAIM_RE.finditer(text or ""):
        option = match.group(1)
        if option not in seen:
            claims.append(option)
            seen.add(option)
    return claims

def _parse_optional_int(text: str, index: int) -> tuple[int, int]:
    start = index
    while index < len(text) and text[index].isdigit():
        index += 1
    if index == start:
        return 1, index
    return int(text[start:index]), index
