"""Math-logic claim marker and detection contracts."""

from __future__ import annotations

import re

MARKER_START_RE = re.compile(r"MATHPI_CLAIM_START(?::\s*(.*))?$")
MARKER_END_RE = re.compile(r"MATHPI_CLAIM_END")
TARGET_LINE_RE = re.compile(
    r"("
    r"MathTex\(|Tex\(|Text\(|"
    r"Angle\(|RightAngle\(|Line\(|Polygon\(|Triangle\(|Square\(|Rectangle\(|"
    r"Circle\(|Dot\(|Arrow\(|Arc\(|Sector\(|"
    r"\b(probability|area|angle|perpendicular|parallel|dot_product)\b|"
    r"\b(概率|面积|角|垂直|平行|勾股|定理)\b"
    r")",
    re.I,
)
NOISE_PREFIXES = ("self.play", "self.wait", "return ")
GEOMETRY_CONTEXT_RE = re.compile(
    r"("
    r"Angle\(|RightAngle\(|Line\(|Polygon\(|Triangle\(|Square\(|Rectangle\(|"
    r"Circle\(|Dot\(|Arrow\(|Arc\(|Sector\(|Axes\(|NumberPlane\(|"
    r"\b(area|angle|perpendicular|parallel|dot_product|coordinate|rotation|reflection|translation|"
    r"similar|congruent|radius|diameter|slope|distance|transform)\b|"
    r"(几何|图形|坐标|点|线段|直线|射线|角|垂直|平行|面积|周长|半径|直径|圆|"
    r"三角形|四边形|正方形|矩形|菱形|梯形|多边形|轴对称|对称|中心对称|旋转|平移|"
    r"反射|翻折|位似|相似|全等|斜率|距离|割补|形变|变换|勾股)"
    r")",
    re.I,
)
