from __future__ import annotations

import re
from typing import Any

from .schemas import MathLogicIssue


SCENE_CLASS_RE = re.compile(
    r"^\s*class\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(",
    re.M,
)


def build_evidence_mismatch_issue(
    *,
    scene_name: str,
    scene_code: str,
    targets: list[dict[str, Any]],
    narration: str = "",
    user_prompt: str = "",
    planning_scene: dict | None = None,
) -> MathLogicIssue | None:
    reason = _evidence_mismatch_reason(
        scene_name=scene_name,
        scene_code=scene_code,
        targets=targets,
    )
    if not reason:
        return None

    expected = _expected_math_statement(
        targets=targets,
        planning_scene=planning_scene,
        narration=narration,
        user_prompt=user_prompt,
        scene_name=scene_name,
    )
    class_names = extract_scene_class_names(scene_code)
    evidence = (
        f"math_logic evidence mismatch: {reason}; "
        f"expected scene={scene_name or 'unknown'}; "
        f"classes={class_names or []}"
    )
    required_fix = (
        f"重新抽取并传入目标 Scene `{scene_name}` 的 construct/数学语句代码；"
        "证据包只包含 helper/base code 或为空时不得判定数学逻辑通过。"
    )
    return MathLogicIssue(
        code="evidence_mismatch",
        severity="medium",
        confidence=1.0,
        hard_error=False,
        scene_name=scene_name,
        evidence=evidence,
        policy_bucket="record_only",
        needs_visual_check=False,
        repairable=False,
        statement=expected,
        suggested_fix=required_fix,
        metadata={
            "source": "math_logic_evidence_guard",
            "evidence_mismatch": True,
            "insufficient_scene_code": True,
            "reason": reason,
            "expected_scene_name": scene_name,
            "scene_code_class_names": class_names,
            "required_fix": required_fix,
            "expected_math_statement": expected,
            "forbidden_change_scope": (
                "不要把 helper/base 证据当作目标 Scene 数学错误来修；"
                "不要改 layout、bbox、overlap 或非当前目标 Scene。"
            ),
            "repair_checklist": [
                f"scene_code 必须包含 class {scene_name}",
                "证据包应包含目标 Scene 中的公式、条件、结论或教学结构代码",
                "证据充分后再运行 math_logic_fast 逻辑审查",
            ],
        },
    )


def extract_scene_class_names(scene_code: str) -> list[str]:
    return SCENE_CLASS_RE.findall(scene_code or "")


def _evidence_mismatch_reason(
    *,
    scene_name: str,
    scene_code: str,
    targets: list[dict[str, Any]],
) -> str:
    code_text = scene_code or ""
    if not code_text.strip():
        return "empty_scene_code"

    class_names = extract_scene_class_names(code_text)
    expected_scene = (scene_name or "").strip()
    if expected_scene and class_names and expected_scene not in class_names:
        return "target_scene_class_not_found"

    if not targets and _looks_like_helper_only_code(code_text):
        return "helper_only_scene_code"

    if targets and _targets_are_only_conceptual(targets) and _looks_like_helper_only_code(code_text):
        return "insufficient_scene_code"

    return ""


def _looks_like_helper_only_code(scene_code: str) -> bool:
    code_text = scene_code or ""
    if not code_text.strip():
        return True
    class_names = extract_scene_class_names(code_text)
    if class_names and all(_is_helper_or_base_class_name(name) for name in class_names):
        return True
    return "def construct" not in code_text and bool(re.search(r"^\s*def\s+", code_text, re.M))


def _is_helper_or_base_class_name(name: str) -> bool:
    lowered = (name or "").lower()
    return (
        lowered in {"baseconfigscene", "basescene", "helperscene", "mathpihelperscene"}
        or lowered.startswith("base")
        or lowered.endswith("helper")
        or lowered.endswith("helpers")
    )


def _targets_are_only_conceptual(targets: list[dict[str, Any]]) -> bool:
    return bool(targets) and all(
        not str(target.get("target_code") or "").strip()
        or str(target.get("expression_mode") or "") == "conceptual_summary"
        for target in targets
    )


def _expected_math_statement(
    *,
    targets: list[dict[str, Any]],
    planning_scene: dict | None,
    narration: str,
    user_prompt: str,
    scene_name: str,
) -> str:
    for target in targets:
        statement = str(target.get("statement") or "").strip()
        if statement:
            return statement
    if isinstance(planning_scene, dict):
        for key in ("math_content", "goal", "description", "visual_description"):
            value = str(planning_scene.get(key) or "").strip()
            if value:
                return _compact(value)
    for value in (narration, user_prompt):
        if str(value or "").strip():
            return _compact(str(value))
    return f"{scene_name} math logic target"


def _compact(text: str, limit: int = 240) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= limit else text[: limit - 1] + "..."
