"""Configuration and field-normalization helpers for math-logic review."""

from __future__ import annotations

import os
from typing import Any, Callable

from app.core.config import settings
from app.core.runtime_config.client import is_runtime_settings_override
from app.workers.validation.math_logic.reviewer_backend_pool import (
    first_pool_model,
    parse_backend_pool,
)

FAST_DEFAULT_MAX_TOKENS = 4096
FINAL_DEFAULT_MAX_TOKENS = 8192


def runtime_value(name: str, default: str = "") -> str:
    if is_runtime_settings_override(name):
        value = getattr(settings, name, None)
        if value not in (None, ""):
            return str(value)
    env_value = os.getenv(name)
    if env_value is not None:
        return env_value
    value = getattr(settings, name, None)
    return str(value) if value not in (None, "") else default


def metadata_value(value: Any) -> Any:
    if isinstance(value, str):
        return value[:1200]
    if isinstance(value, list):
        return value[:12]
    if isinstance(value, dict):
        return dict(list(value.items())[:24])
    return value


def confidence(value: Any) -> float:
    if isinstance(value, (int, float)):
        return max(0.0, min(1.0, float(value)))
    return {"high": 0.9, "medium": 0.6, "low": 0.3}.get(str(value or "").lower(), 0.0)


def severity(value: Any) -> str:
    raw = str(value or "").lower()
    return raw if raw in {"high", "medium", "low"} else "medium"


def review_model_name(role: str) -> str:
    if role == "final":
        return runtime_value("MATH_LOGIC_FINAL_MODEL", "gpt-5.5")
    pooled_model = first_pool_model(runtime_value("MATH_LOGIC_FAST_BACKENDS_JSON"))
    return pooled_model or runtime_value("MATH_LOGIC_FAST_MODEL", "deepseek-v4-flash")


def review_max_tokens(role: str) -> int:
    env_key = "MATH_LOGIC_FINAL_MAX_TOKENS" if role == "final" else "MATH_LOGIC_FAST_MAX_TOKENS"
    default = FINAL_DEFAULT_MAX_TOKENS if role == "final" else FAST_DEFAULT_MAX_TOKENS
    raw = runtime_value(env_key).strip()
    if not raw:
        return default
    try:
        value = int(raw)
        return value if value > 0 else default
    except ValueError:
        return default


def dedicated_backend_configs(role: str) -> list[dict[str, str]]:
    prefix = "MATH_LOGIC_FINAL" if role == "final" else "MATH_LOGIC_FAST"
    pooled = parse_backend_pool(runtime_value(f"{prefix}_BACKENDS_JSON"))
    if pooled:
        return pooled
    api_key = runtime_value(f"{prefix}_API_KEY").strip()
    if not api_key:
        return []
    api_base = runtime_value(f"{prefix}_API_BASE").strip()
    model_name = runtime_value(f"{prefix}_MODEL").strip()
    return [{"backend_name": f"dedicated-{role}", "api_key": api_key, "api_base": api_base or None, "model_name": model_name or review_model_name(role)}]


def dedicated_backend_config(role: str) -> dict[str, str] | None:
    configs = dedicated_backend_configs(role)
    return configs[0] if configs else None
