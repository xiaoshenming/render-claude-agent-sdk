from typing import Any

def _linear_equation_final_answer_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    spec = _extract_simple_linear_equation_spec(user_prompt)
    if spec is None:
        return None
    variable, expected = spec
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None

    actual_values = _extract_final_variable_values(text, variable)
    actual = next(
        (value for value in actual_values if not _same_number(value, expected)),
        None,
    )
    if actual is None and not actual_values:
        numeric_answer = _extract_final_numeric_answer(text)
        if numeric_answer is not None and not _same_number(numeric_answer, expected):
            actual = numeric_answer
    if actual is None:
        return None
    return {
        "evidence": (
            f"题干方程推出 {variable} 应为 {_fmt_number(expected)}，"
            f"但当前最终答案为 {_fmt_number(actual)}。"
        ),
        "suggested_fix": (
            f"将最终答案改为 {variable}={_fmt_number(expected)}，并同步相关推导。"
        ),
        "metadata": {
            "guard": "simple_linear_equation",
            "variable": variable,
            "expected": expected,
            "actual": actual,
        },
    }

def _requested_final_variable_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    requested_variables = _extract_requested_variables(user_prompt)
    if not requested_variables:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    assigned_variables = _extract_final_assignment_variables(text)
    if not assigned_variables:
        if not _has_final_numeric_answer(text):
            return None
        requested_label = "、".join(requested_variables)
        return {
            "evidence": (
                f"题干要求求 {requested_label}，但当前最终答案未标明 "
                f"{requested_label}，只给出数值结果。"
            ),
            "suggested_fix": (
                f"补齐最终答案中的 {requested_label}=...，并同步相关推导和画面文本。"
            ),
            "metadata": {
                "guard": "requested_final_variable",
                "requested_variables": requested_variables,
                "missing_variables": requested_variables,
                "assigned_variables": [],
            },
        }
    missing_variables = [
        variable for variable in requested_variables if variable not in assigned_variables
    ]
    if not missing_variables:
        return None
    requested_label = "、".join(requested_variables)
    missing_label = "、".join(missing_variables)
    assigned_label = "、".join(assigned_variables)
    if len(requested_variables) == 1:
        evidence = (
            f"题干要求求 {requested_label}，但当前最终答案只给出 {assigned_label}。"
        )
    else:
        evidence = f"题干要求求 {requested_label}，但当前最终答案缺少 {missing_label}。"
    return {
        "evidence": evidence,
        "suggested_fix": (
            f"补齐最终答案中的 {missing_label}=...，并同步相关推导和画面文本。"
        ),
        "metadata": {
            "guard": "requested_final_variable",
            "requested_variables": requested_variables,
            "missing_variables": missing_variables,
            "assigned_variables": assigned_variables,
        },
    }

def _extract_requested_variables(user_prompt: str) -> list[str]:
    prompt = user_prompt or ""
    requested: list[str] = []
    seen: set[str] = set()
    for match in REQUESTED_VARIABLE_LIST_RE.finditer(prompt):
        for variable in re.findall(r"[a-zA-Z]", match.group(1)):
            if variable not in seen:
                requested.append(variable)
                seen.add(variable)
    for match in REQUESTED_VARIABLE_RE.finditer(prompt):
        variable = match.group(1) or match.group(2)
        if variable and variable not in seen:
            requested.append(variable)
            seen.add(variable)
    return requested

def _extract_final_assignment_variables(text: str) -> list[str]:
    variables: list[str] = []
    seen: set[str] = set()
    for match in FINAL_ASSIGNMENT_VARIABLE_RE.finditer((text or "").replace("\\\\", "\\")):
        variable = match.group(1)
        if variable not in seen:
            variables.append(variable)
            seen.add(variable)
    return variables

def _has_final_numeric_answer(text: str) -> bool:
    return FINAL_NUMERIC_ANSWER_RE.search((text or "").replace("\\\\", "\\")) is not None

def _extract_final_numeric_answer(text: str) -> float | None:
    match = FINAL_NUMERIC_ANSWER_RE.search((text or "").replace("\\\\", "\\"))
    if not match:
        return None
    return _parse_simple_number_value(match.group(1))

def _extract_final_variable_value(text: str, variable: str) -> float | None:
    matches = _extract_final_variable_values(text, variable)
    if not matches:
        return None
    return matches[-1]

def _extract_final_variable_values(text: str, variable: str) -> list[float]:
    normalized = (text or "").replace("\\\\", "\\")
    pattern = re.compile(
        rf"(?<![A-Za-z0-9]){re.escape(variable)}\s*"
        rf"{FINAL_ASSIGNMENT_SUBJECT_SUFFIX_PATTERN}\s*"
        rf"(?:{FINAL_ASSIGNMENT_OPERATOR_PATTERN})\s*"
        rf"(?:"
        rf"([+-]?)\s*\\frac\s*\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}"
        rf"|([+-]?\d+(?:\.\d+)?)\s*/\s*([+-]?\d+(?:\.\d+)?)"
        rf"|([+-]?\d+(?:\.\d+)?)(?!\s*/)"
        rf")"
    )
    values: list[float] = []
    for match in pattern.finditer(normalized):
        if match.group(2) is not None and match.group(3) is not None:
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                continue
            sign = -1 if match.group(1) == "-" else 1
            values.append(sign * float(match.group(2)) / denominator)
            continue
        if match.group(4) is not None and match.group(5) is not None:
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                continue
            values.append(float(match.group(4)) / denominator)
            continue
        values.append(float(match.group(6)))
    return values
