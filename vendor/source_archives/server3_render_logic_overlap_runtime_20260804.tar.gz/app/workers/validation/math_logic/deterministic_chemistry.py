from typing import Any

from .deterministic_guard_constants7 import (
    CHEMICAL_EQUATION_QUOTE_RE,
    CHEMICAL_RESULT_CONTEXT_RE,
    CHEMICAL_SUBSCRIPT_TRANSLATION,
)

def _chemical_symbol_case_issue(text: str) -> dict[str, Any] | None:
    if not CHEMICAL_RESULT_CONTEXT_RE.search(text or ""):
        return None
    for equation in _extract_chemical_equation_texts(text):
        issue = _find_chemical_symbol_case_issue(equation)
        if issue:
            wrong, expected = issue
            return {
                "evidence": f"化学元素符号大小写错误：{wrong} 应写作 {expected}。",
                "suggested_fix": "按元素符号规范修正大小写，并同步公式、旁白和画面文本。",
                "metadata": {
                    "guard": "chemical_symbol_case",
                    "equation": equation,
                    "wrong_symbol": wrong,
                    "expected_symbol": expected,
                },
            }
    return None

def _extract_chemical_equation_texts(text: str) -> list[str]:
    equations: list[str] = []
    for match in CHEMICAL_EQUATION_QUOTE_RE.finditer(text or ""):
        candidate = _normalize_chemical_equation_text(match.group(1))
        if "->" in candidate:
            equations.append(candidate)
    return equations

def _find_chemical_symbol_case_issue(equation: str) -> tuple[str, str] | None:
    state_stripped = re.sub(r"\((?:s|l|g|aq)\)", "", equation or "", flags=re.I)
    for match in re.finditer(r"(?<![A-Za-z])([a-z]{1,2})(?=\d|[^a-z]|$)", state_stripped):
        wrong = match.group(1)
        expected = wrong[0].upper() + wrong[1:].lower()
        if expected in ELEMENT_SYMBOLS:
            return wrong, expected

    compact = re.sub(r"[^A-Za-z]", "", equation or "")
    for index in range(len(compact) - 1):
        first = compact[index]
        second = compact[index + 1]
        if not first.isupper() or not second.isupper():
            continue
        expected = first + second.lower()
        if expected not in ELEMENT_SYMBOLS:
            continue
        if first in ELEMENT_SYMBOLS and second in ELEMENT_SYMBOLS:
            continue
        return first + second, expected
    return None

def _chemical_equation_balance_issue(text: str) -> dict[str, Any] | None:
    if not CHEMICAL_RESULT_CONTEXT_RE.search(text or ""):
        return None
    for equation in _extract_chemical_equation_candidates(text):
        parsed = _parse_chemical_equation(equation)
        if parsed is None:
            continue
        left_counts, right_counts = parsed
        if left_counts == right_counts:
            continue
        mismatches = []
        for element in sorted(set(left_counts) | set(right_counts)):
            left = left_counts.get(element, 0)
            right = right_counts.get(element, 0)
            if left != right:
                mismatches.append(f"{element}: 左{left}/右{right}")
        return {
            "evidence": f"化学方程式未配平：{'; '.join(mismatches)}。",
            "suggested_fix": "重新配平方程式，确保反应前后每种元素原子数一致。",
            "metadata": {
                "guard": "chemical_equation_balance",
                "equation": equation,
                "left_counts": left_counts,
                "right_counts": right_counts,
            },
        }
    return None

def _extract_chemical_equation_candidates(text: str) -> list[str]:
    candidates: list[str] = []
    for match in CHEMICAL_EQUATION_QUOTE_RE.finditer(text or ""):
        candidate = _normalize_chemical_equation_text(match.group(1))
        if _looks_like_chemical_equation(candidate):
            candidates.append(candidate)
    return candidates

def _normalize_chemical_equation_text(value: str) -> str:
    text = value.translate(CHEMICAL_SUBSCRIPT_TRANSLATION)
    text = text.replace("\\rightarrow", "->").replace("\\to", "->").replace("→", "->")
    text = re.sub(r"_\{(\d+)\}", r"\1", text)
    text = re.sub(r"_(\d+)", r"\1", text)
    text = re.sub(r"\\mathrm\{([^{}]+)\}", r"\1", text)
    text = text.replace("{", "").replace("}", "")
    text = text.replace("$", "")
    return re.sub(r"\s+", " ", text).strip()

def _looks_like_chemical_equation(value: str) -> bool:
    if not re.search(r"(->|=)", value):
        return False
    if "->" not in value and "+" not in value:
        return False
    return len(re.findall(r"\b[A-Z][a-z]?\b|\b[A-Z][a-z]?\d", value)) >= 2

def _parse_chemical_equation(equation: str) -> tuple[dict[str, int], dict[str, int]] | None:
    if "->" in equation:
        left, right = equation.split("->", 1)
    elif "=" in equation:
        left, right = equation.split("=", 1)
    else:
        return None
    left_counts = _parse_chemical_side(left)
    right_counts = _parse_chemical_side(right)
    if left_counts is None or right_counts is None:
        return None
    return left_counts, right_counts

def _parse_chemical_side(side: str) -> dict[str, int] | None:
    counts: dict[str, int] = {}
    terms = [term for term in side.split("+") if term.strip()]
    if not terms:
        return None
    for raw_term in terms:
        term = _strip_chemical_term_noise(raw_term)
        if not term:
            return None
        coefficient = 1
        match = re.match(r"^(\d+)(?=[A-Z(])", term)
        if match:
            coefficient = int(match.group(1))
            term = term[match.end():]
        formula_counts = _parse_formula_counts(term)
        if formula_counts is None:
            return None
        for element, count in formula_counts.items():
            counts[element] = counts.get(element, 0) + coefficient * count
    return counts

def _strip_chemical_term_noise(term: str) -> str:
    text = term.strip()
    if ":" in text or "：" in text:
        text = re.split(r"[:：]", text)[-1]
    start = re.search(r"(?=\d*[A-Z(])", text)
    if start:
        text = text[start.start():]
    text = re.sub(r"\((?:s|l|g|aq)\)$", "", text.strip(), flags=re.I)
    text = re.sub(r"[^A-Za-z0-9()]", "", text)
    return text

def _parse_formula_counts(formula: str) -> dict[str, int] | None:
    counts, index = _parse_formula_group(formula, 0)
    if counts is None or index != len(formula):
        return None
    return counts

def _parse_formula_group(formula: str, index: int) -> tuple[dict[str, int] | None, int]:
    counts: dict[str, int] = {}
    while index < len(formula):
        char = formula[index]
        if char == ")":
            return counts, index
        if char == "(":
            nested, index = _parse_formula_group(formula, index + 1)
            if nested is None or index >= len(formula) or formula[index] != ")":
                return None, index
            index += 1
            multiplier, index = _parse_optional_int(formula, index)
            for element, count in nested.items():
                counts[element] = counts.get(element, 0) + count * multiplier
            continue
        if not char.isupper():
            return None, index
        element = char
        index += 1
        if index < len(formula) and formula[index].islower():
            element += formula[index]
            index += 1
        if element not in ELEMENT_SYMBOLS:
            return None, index
        multiplier, index = _parse_optional_int(formula, index)
        counts[element] = counts.get(element, 0) + multiplier
    return counts, index
