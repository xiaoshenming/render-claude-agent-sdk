import re

from .deterministic_guard_constants6 import DOMAIN_BOUND_OPERATOR_PATTERN
from .deterministic_guard_constants6 import *  # noqa: F401,F403 - split constants share prior patterns

FOLLOWUP_DOMAIN_BOUND_RE = re.compile(
    rf"^\s*(?:且|并且|同时|并)\s*({DOMAIN_BOUND_OPERATOR_PATTERN})\s*"
    r"(?:为|是)?\s*(-?\d+(?:\.\d+)?)"
)

CHAINED_DOMAIN_BOUND_RE = re.compile(
    r"(-?\d+(?:\.\d+)?)\s*(<|<=|≤)\s*([a-zA-Z])\s*(<|<=|≤)\s*(-?\d+(?:\.\d+)?)"
)

NUMBER_CONDITION_PATTERN = (
    r"正整数|非负整数|非零自然数|自然数|整数|偶数|奇数|"
    r"非负数|非正数|正数|负数|质数|素数|合数|完全平方数|平方数"
)

NUMBER_CONDITION_RE = re.compile(
    rf"([a-zA-Z])\s*(?:为|是|属于|取值为|取)?\s*({NUMBER_CONDITION_PATTERN})"
)

FOLLOWUP_NUMBER_CONDITION_RE = re.compile(
    rf"^\s*(?:且|并且|同时|并)\s*(?:为|是)?\s*({NUMBER_CONDITION_PATTERN})"
)

MULTIPLE_CONDITION_RE = re.compile(
    r"([a-zA-Z])\s*(?:为|是|属于|取值为|取)?\s*(-?\d+)\s*的倍数"
)

DIVISIBLE_BY_CONDITION_RE = re.compile(
    r"([a-zA-Z])\s*(?:能|可|可以)?\s*被\s*(-?\d+)\s*整除"
)

FACTOR_CONDITION_RE = re.compile(
    r"([a-zA-Z])\s*(?:为|是|属于|取值为|取)?\s*(-?\d+)\s*的(因数|约数|因子)"
)

DIGIT_COUNT_CONDITION_RE = re.compile(
    r"([a-zA-Z])\s*(?:为|是|属于|取值为|取)?\s*([一二两三四五六七八九])位数"
)

DIGIT_COUNT_LABELS = {
    "一": 1,
    "二": 2,
    "两": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
}

UNIT_PATTERN_RE = re.compile(
    r"(-?\d+(?:\.\d+)?)\s*(平方|立方)?\s*"
    r"(厘米|毫米|分米|米|千米|cm|mm|dm|m|km)"
    r"(?:\s*(?:\^?\s*([23])|([²³])))?",
    re.I,
)

CHEMICAL_RESULT_CONTEXT_RE = re.compile(
    r"(最终答案|答案|配平结果|配平后|已配平|完成配平|平衡方程式|化学方程式为)"
)

CHEMICAL_EQUATION_QUOTE_RE = re.compile(
    r"""["']([^"']*(?:->|→|=|\\to|\\rightarrow)[^"']*)["']"""
)

CHEMICAL_SUBSCRIPT_TRANSLATION = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")

ELEMENT_SYMBOLS = set(
    """
    H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni
    Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe
    Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg
    Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg
    Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og
    """.split()
)
