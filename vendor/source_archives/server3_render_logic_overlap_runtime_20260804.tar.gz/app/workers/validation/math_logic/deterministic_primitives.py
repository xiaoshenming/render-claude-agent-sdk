from typing import Any

from .schemas import MathLogicIssue
from .deterministic_guard_constants3 import TARGET_CODE_SNIPPET_LIMIT

def _fmt_number(value: float) -> str:
    if abs(value - round(value)) <= 1e-6:
        return str(int(round(value)))
    return f"{value:g}"

def _issue(
    *,
    code: str,
    scene_name: str,
    evidence: str,
    start_line: int,
    end_line: int,
    target: dict[str, Any],
    suggested_fix: str = "",
    metadata: dict[str, Any] | None = None,
) -> MathLogicIssue:
    payload_metadata = {"source": "deterministic_guard"}
    target_code = str(target.get("target_code") or "").strip()
    if target_code:
        payload_metadata["target_code_snippet"] = (
            target_code
            if len(target_code) <= TARGET_CODE_SNIPPET_LIMIT
            else target_code[: TARGET_CODE_SNIPPET_LIMIT - 3].rstrip() + "..."
        )
    if metadata:
        payload_metadata.update(metadata)
    return MathLogicIssue(
        code=code,
        severity="high",
        confidence=0.9,
        hard_error=True,
        scene_name=scene_name,
        evidence=evidence,
        policy_bucket="hard_error",
        needs_visual_check=False,
        repairable=True,
        claim_id=target.get("claim_id"),
        statement=str(target.get("statement") or ""),
        code_span={"start_line": start_line, "end_line": end_line},
        suggested_fix=suggested_fix,
        metadata=payload_metadata,
    )

def _has_obvious_pythagorean_error(text: str) -> bool:
    compact = re.sub(r"\s+", "", text.replace("{", "").replace("}", ""))
    wrong_forms = {
        "a^2+c^2=b^2",
        "c^2+a^2=b^2",
        "b^2+c^2=a^2",
        "c^2+b^2=a^2",
    }
    return any(form in compact for form in wrong_forms)

def _area_partition_issue(text: str) -> str:
    outer = _number_assignment(text, "outer_area")
    piece = _number_assignment(text, "piece_area_sum")
    if outer is None or piece is None:
        return ""
    if abs(outer - piece) > 1e-6:
        return f"面积割补不闭合：外框面积 {outer:g}，内部块面积和 {piece:g}。"
    return ""

def _has_np_array_point(text: str, x_name: str, y_name: str) -> bool:
    return bool(
        re.search(
            rf"np\.array\(\[\s*{x_name}\s*,\s*{y_name}\s*,\s*(?:0|0\.0)\s*\]\)",
            text,
        )
    )

def _is_integer_value(value: float) -> bool:
    return abs(value - round(value)) <= 1e-6

def _is_prime_integer(value: int) -> bool:
    if value < 2:
        return False
    divisor = 2
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 1
    return True

def _is_square_integer(value: int) -> bool:
    if value < 0:
        return False
    root = int(value ** 0.5)
    return root * root == value or (root + 1) * (root + 1) == value
def _fmt_number(value: float) -> str:
    if abs(value - round(value)) <= 1e-6:
        return str(int(round(value)))
    return f"{value:g}"
