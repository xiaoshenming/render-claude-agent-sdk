from typing import Any

def _explicit_domain_exclusion_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    exclusions = _extract_domain_exclusions(user_prompt)
    if not exclusions:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    normalized = text.replace("{", "").replace("}", "")
    for variable, excluded in exclusions:
        for actual in _extract_final_variable_values(normalized, variable):
            if not _same_number(actual, excluded):
                continue
            condition = f"{variable}≠{_fmt_number(excluded)}"
            return {
                "evidence": (
                    f"题干明确要求 {condition}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": f"剔除不满足 {condition} 的答案，并重新核对定义域/条件。",
                "metadata": {
                    "guard": "explicit_domain_exclusion",
                    "variable": variable,
                    "excluded": excluded,
                    "actual": actual,
                },
            }
    return None

def _extract_domain_exclusions(user_prompt: str) -> list[tuple[str, float]]:
    exclusions: list[tuple[str, float]] = []
    for match in DOMAIN_EXCLUSION_RE.finditer(user_prompt or ""):
        exclusions.append((match.group(1), float(match.group(2))))
    return exclusions

def _explicit_domain_bound_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    bounds = _extract_domain_bounds(user_prompt)
    if not bounds:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    normalized = text.replace("{", "").replace("}", "")
    for variable, operator, bound in bounds:
        for actual in _extract_final_variable_values(normalized, variable):
            if not _violates_domain_bound(actual, operator, bound):
                continue
            condition = _format_domain_bound(variable, operator, bound)
            return {
                "evidence": (
                    f"题干明确要求 {condition}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": f"剔除不满足 {condition} 的答案，并重新核对定义域/条件。",
                "metadata": {
                    "guard": "explicit_domain_bound",
                    "variable": variable,
                    "operator": operator,
                    "bound": bound,
                    "actual": actual,
                },
            }
    return None

def _explicit_chained_domain_bound_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    bounds = _extract_chained_domain_bounds(user_prompt)
    if not bounds:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    normalized = text.replace("{", "").replace("}", "")
    for variable, lower, lower_operator, upper_operator, upper in bounds:
        for actual in _extract_final_variable_values(normalized, variable):
            if _satisfies_chained_domain_bound(
                actual,
                lower,
                lower_operator,
                upper_operator,
                upper,
            ):
                continue
            condition = _format_chained_domain_bound(
                variable,
                lower,
                lower_operator,
                upper_operator,
                upper,
            )
            return {
                "evidence": (
                    f"题干明确要求 {condition}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": f"剔除不满足 {condition} 的答案，并重新核对定义域/条件。",
                "metadata": {
                    "guard": "explicit_chained_domain_bound",
                    "variable": variable,
                    "lower": lower,
                    "lower_operator": lower_operator,
                    "upper_operator": upper_operator,
                    "upper": upper,
                    "actual": actual,
                },
            }
    return None

def _extract_chained_domain_bounds(
    user_prompt: str,
) -> list[tuple[str, float, str, str, float]]:
    bounds: list[tuple[str, float, str, str, float]] = []
    for match in CHAINED_DOMAIN_BOUND_RE.finditer(user_prompt or ""):
        lower = float(match.group(1))
        lower_operator = _normalize_chained_bound_operator(match.group(2))
        variable = match.group(3)
        upper_operator = _normalize_chained_bound_operator(match.group(4))
        upper = float(match.group(5))
        if lower_operator and upper_operator:
            bounds.append((variable, lower, lower_operator, upper_operator, upper))
    return bounds

def _satisfies_chained_domain_bound(
    actual: float,
    lower: float,
    lower_operator: str,
    upper_operator: str,
    upper: float,
) -> bool:
    if lower_operator == "<":
        lower_ok = actual > lower and not _same_number(actual, lower)
    else:
        lower_ok = actual > lower or _same_number(actual, lower)

    if upper_operator == "<":
        upper_ok = actual < upper and not _same_number(actual, upper)
    else:
        upper_ok = actual < upper or _same_number(actual, upper)
    return lower_ok and upper_ok

def _format_chained_domain_bound(
    variable: str,
    lower: float,
    lower_operator: str,
    upper_operator: str,
    upper: float,
) -> str:
    return (
        f"{_fmt_number(lower)}{_display_chained_bound_operator(lower_operator)}"
        f"{variable}{_display_chained_bound_operator(upper_operator)}"
        f"{_fmt_number(upper)}"
    )

def _extract_domain_bounds(user_prompt: str) -> list[tuple[str, str, float]]:
    bounds: list[tuple[str, str, float]] = []
    for match in DOMAIN_BOUND_RE.finditer(user_prompt or ""):
        operator = _normalize_domain_bound_operator(match.group(2))
        if operator:
            bounds.append((match.group(1), operator, float(match.group(3))))
    for match in NUMBER_CONDITION_RE.finditer(user_prompt or ""):
        _append_followup_domain_bounds(bounds, user_prompt, match.group(1), match.end())
    for match in MULTIPLE_CONDITION_RE.finditer(user_prompt or ""):
        _append_followup_domain_bounds(bounds, user_prompt, match.group(1), match.end())
    for match in DIVISIBLE_BY_CONDITION_RE.finditer(user_prompt or ""):
        _append_followup_domain_bounds(bounds, user_prompt, match.group(1), match.end())
    for match in FACTOR_CONDITION_RE.finditer(user_prompt or ""):
        _append_followup_domain_bounds(bounds, user_prompt, match.group(1), match.end())
    for match in DIGIT_COUNT_CONDITION_RE.finditer(user_prompt or ""):
        _append_followup_domain_bounds(bounds, user_prompt, match.group(1), match.end())
    return bounds

def _append_followup_domain_bounds(
    bounds: list[tuple[str, str, float]],
    user_prompt: str,
    variable: str,
    start_index: int,
) -> None:
    tail = (user_prompt or "")[start_index:]
    offset = 0
    while True:
        followup = FOLLOWUP_DOMAIN_BOUND_RE.match(tail[offset:])
        if not followup:
            break
        operator = _normalize_domain_bound_operator(followup.group(1))
        if operator:
            bounds.append((variable, operator, float(followup.group(2))))
        offset += followup.end()

def _normalize_domain_bound_operator(operator: str) -> str:
    if operator in {">", ">=", "<", "<="}:
        return operator
    if operator in {"≥", "大于等于", "大于或等于", "至少", "不少于", "不小于"}:
        return ">="
    if operator in {"≤", "小于等于", "小于或等于", "至多", "不超过", "不大于"}:
        return "<="
    if operator in {"大于", "超过"}:
        return ">"
    if operator in {"小于", "低于"}:
        return "<"
    return ""

def _violates_domain_bound(actual: float, operator: str, bound: float) -> bool:
    if operator == ">":
        return actual <= bound or _same_number(actual, bound)
    if operator == ">=":
        return actual < bound and not _same_number(actual, bound)
    if operator == "<":
        return actual >= bound or _same_number(actual, bound)
    if operator == "<=":
        return actual > bound and not _same_number(actual, bound)
    return False

def _format_domain_bound(variable: str, operator: str, bound: float) -> str:
    display_operator = {">=": "≥", "<=": "≤"}.get(operator, operator)
    return f"{variable}{display_operator}{_fmt_number(bound)}"
