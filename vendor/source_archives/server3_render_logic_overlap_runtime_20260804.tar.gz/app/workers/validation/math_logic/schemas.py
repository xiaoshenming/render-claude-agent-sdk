from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


Severity = Literal["high", "medium", "low"]
PolicyBucket = Literal[
    "hard_error",
    "teaching_approximation",
    "acceptable_simplification",
    "needs_visual_check",
    "record_only",
]
FinalAction = Literal["record_only", "repair_candidate", "block_candidate"]
ReviewStatus = Literal["ok", "skipped", "review_error"]


@dataclass(frozen=True)
class MathLogicIssue:
    code: str
    severity: Severity
    confidence: float
    hard_error: bool
    scene_name: str
    evidence: str
    policy_bucket: PolicyBucket = "record_only"
    needs_visual_check: bool = False
    repairable: bool = False
    claim_id: str | None = None
    statement: str = ""
    code_span: dict[str, int] | None = None
    suggested_fix: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MathLogicDecision:
    mode: str
    scene_name: str
    final_action: FinalAction
    issues: list[MathLogicIssue]
    latency_ms: int = 0
    block_reason: str | None = None
    needs_repair: bool = False
    needs_visual_check: bool = False
    hard_error_count: int = 0
    needs_visual_check_count: int = 0
    review_models: dict[str, str] = field(default_factory=dict)
    artifact_path: str | None = None
    risk_assessment: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["issues"] = [issue.to_dict() for issue in self.issues]
        return payload


@dataclass(frozen=True)
class MathLogicReviewResult:
    status: ReviewStatus
    issues: list[MathLogicIssue] = field(default_factory=list)
    backend_name: str = ""
    model_name: str = ""
    latency_ms: int = 0
    raw_output: str = ""
    error: str = ""
    summary: str = ""

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["issues"] = [issue.to_dict() for issue in self.issues]
        return payload
