from . import deterministic_guard as _guard

def parse_linear_grammar_batch11(prompt):
    parsed_batch10 = parse_linear_grammar_batch10(prompt)
    if parsed_batch10 is not None:
            return parsed_batch10
    match = REVERSED_VARIABLE_MULTIPLICATION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            coefficient = _parse_simple_number_value(match.group(3))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            return variable, left_value / coefficient
    match = SIMPLE_SIGNED_VARIABLE_EQUATION_RE.search(prompt)
    if match:
            coefficient = -1.0 if match.group(1) == "-" else 1.0
            variable = match.group(2)
            right_value = _parse_simple_number_value(match.group(3))
            if right_value is None:
                return None
            return variable, right_value / coefficient
    match = SIMPLE_SIGNED_ADDITIVE_EQUATION_RE.search(prompt)
    if match:
            coefficient = -1.0 if match.group(1) == "-" else 1.0
            variable = match.group(2)
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            adjusted = right_value - offset if operator == "+" else right_value + offset
            return variable, adjusted / coefficient
    return None
