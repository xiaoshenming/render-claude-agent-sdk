from . import deterministic_guard as _guard

def parse_linear_grammar_batch13(prompt):
    parsed_batch12 = parse_linear_grammar_batch12(prompt)
    if parsed_batch12 is not None:
            return parsed_batch12
    match = REVERSED_DIVISION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                return None
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            adjusted = left_value - offset if operator == "+" else left_value + offset
            return variable, adjusted * denominator
    match = REVERSED_DIVISION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                return None
            return variable, left_value * denominator
    match = REVERSED_TEX_FRACTION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            variable = match.group(2)
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                return None
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            adjusted = left_value - offset if operator == "+" else left_value + offset
            return variable, adjusted * denominator
    return None
