from __future__ import annotations

import asyncio
import json
import os
import re
import time
from typing import Any

from app.services.llm_service import get_llm_manager
from app.services.dedicated_llm_client import call_dedicated_chat_completion
from app.services.llm_call_tracer import LLMCallTracer
from app.prompts.prompt_compiler import compile_cacheable_segmented_prompt
try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover - dependency exists in runtime image
    AsyncOpenAI = None

from app.core.config import settings
from app.core.runtime_config.client import (
    is_runtime_settings_override,
    refresh_runtime_config_if_stale,
)
from app.workers.repair.repair_state import (
    BackhalfRepairBudget,
    record_backhalf_repair_call,
)

from .policy import HARD_ERROR_TYPES
from .schemas import MathLogicIssue, MathLogicReviewResult
from .reviewer_backend_pool import first_pool_model as _first_pool_model, parse_backend_pool as _parse_backend_pool
from .reviewer_config_helpers import (
    metadata_value as _metadata_value,
    confidence as _confidence,
    severity as _severity,
    review_model_name as _review_model_name,
    review_max_tokens as _review_max_tokens,
    dedicated_backend_configs as _dedicated_backend_configs,
    dedicated_backend_config as _dedicated_backend_config,
)

MATH_LOGIC_FAST_DEFAULT_MAX_TOKENS = 4096
MATH_LOGIC_FINAL_DEFAULT_MAX_TOKENS = 8192



def _build_review_prompt(
    *,
    scene_name: str,
    targets: list[dict[str, Any]],
    user_prompt: str,
    scope: str,
    reviewer_role: str,
    model_name: str,
) -> str:
    stable_prefix, dynamic_payload = _build_review_prompt_parts(
        scene_name=scene_name,
        targets=targets,
        user_prompt=user_prompt,
        scope=scope,
        reviewer_role=reviewer_role,
        model_name=model_name,
    )
    return f"{stable_prefix}\n\n{dynamic_payload}"
def _build_review_prompt_parts(
    *,
    scene_name: str,
    targets: list[dict[str, Any]],
    user_prompt: str,
    scope: str,
    reviewer_role: str,
    model_name: str,
) -> tuple[str, str]:
    if _normalize_scope(scope) == "figure_lines":
        return _build_figure_lines_review_prompt_parts(
            scene_name=scene_name,
            targets=targets,
            user_prompt=user_prompt,
            reviewer_role=reviewer_role,
            model_name=model_name,
        )
    scope_instruction = _scope_instruction(scope)
    stable_prefix = f"""你是 MathPi 解题内容审查器，当前为 shadow mode。
只判断会影响教学可信度的硬内容错误，不评价美观、普通措辞严谨性。
只判断数学逻辑、题目条件、公式、结论和教学结构；不要判断 bbox/overlap/视觉遮挡/排版重叠、字体大小、对象位置或画面美观。
如果证据只显示排版遮挡、bbox 交叠或视觉重叠，不要返回数学逻辑 issue；这些问题交给 layout 审查。
审查角色：{reviewer_role}
期望模型：{model_name}
审查范围：{_normalize_scope(scope)}

{scope_instruction}

硬内容错误包括公式错误、条件缺失、漏小问、定义错误、几何关系错误、符号绑定错误、推理步骤错误、循环论证、定理事实错误、定义域/单位/最终答案/概率范围错误、割补形变、选项顺序错误、化学符号错误、化学方程式错误、学科术语错误、讲题结构缺失。
P1 客户反馈重点：原题/关键条件、思路、分步推导、最终答案必须闭环；多小问必须逐一覆盖；化学题必须核对化学方程式、配平系数、离子电荷、上下标、物质名称和选项顺序。
圆面积扇形近似成长方形这类极限直观应归为 acceptable_simplification，不要作为 hard_error。
圆面积扇形拼接审查必须识别循环语义：如果 target_code 里 `for i in range(n)` 且 n>=8，循环体用 `i % 2` 上下/奇偶分支创建 Sector 并 `target_sectors.add(...)`，再 Transform 到目标组和 Rectangle/底边，则循环体中的一个或两个分支代表 n 个扇形，不得因为源码只有一个变量名或两个 `Sector(...)` 构造行就判定“仅创建一个/两个扇形”。
如果只有 needs_visual_check，必须 hard_error=false。
必须逐行核验 statement 与 target_code 的数学关系，不要默认代码里的公式正确。
明显公式矛盾必须给出 issue，例如：勾股定理语境下 `a^2+c^2=b^2` 应判为 formula_error；概率 `P(A)=1.2` 应判为 probability_range_error；声称垂直但 dot_product 非 0 应判为 geometry_relation_error。
如果原题或解题稿包含多个小问/选项/参考答案，target_code 或画面文本漏掉对应部分，应判为 missing_subquestion、missing_condition 或 option_order_error。
如果化学式、化学方程式、离子电荷、配平系数、反应条件明显错误，应判为 chemical_symbol_error 或 chemical_equation_error。
如果证据包里已有 start_line/end_line，应把 code_span 原样带回，方便后续定向修复。
如果问题能定位到 target_code，必须在 code_snippet 字段复制最相关的 1-5 行代码，方便后台 AI 小结解释具体哪里有问题。
如果切片证据包与目标 Scene 不匹配、target_code 为空、或只包含 helper/base class 代码，不要判定“无硬错”；返回 evidence_mismatch，hard_error=false，policy_bucket=record_only，并标记 insufficient_scene_code=true。
对可修复的数学问题，除 suggested_fix 外还要给出 required_fix、expected_math_statement、forbidden_change_scope 和 repair_checklist，形成明确修复合同；禁止要求修 bbox/overlap/layout。
如果 code=geometry_relation_error，还必须给出 required_relations、required_visual_objects、forbidden_scope 和 verification_checklist；这些字段只描述几何对象/坐标/关系/证明核验，不描述 layout/overlap/bbox。

只输出 JSON 对象，不要输出 Markdown。JSON schema:
{{
  "issues": [
    {{
      "code": "formula_error|condition_error|missing_condition|missing_subquestion|definition_error|geometry_relation_error|symbol_binding_error|reasoning_step_error|circular_reasoning|theorem_fact_error|domain_constraint_error|unit_error|final_answer_error|probability_range_error|cut_fill_shape_deformation|option_order_error|chemical_symbol_error|chemical_equation_error|subject_term_error|teaching_structure_gap|evidence_mismatch|review_error",
      "severity": "high|medium|low",
      "confidence": 0.0,
      "hard_error": true,
      "evidence": "直接证据",
      "policy_bucket": "hard_error|teaching_approximation|acceptable_simplification|needs_visual_check|record_only",
      "needs_visual_check": false,
      "repairable": true,
      "insufficient_scene_code": false,
      "code_snippet": "从 target_code 复制的相关代码片段",
      "suggested_fix": "只修当前 Scene 的建议",
      "required_fix": "必须完成的数学修复动作",
      "expected_math_statement": "修复后必须呈现的正确数学命题/公式/结论",
      "forbidden_change_scope": "禁止改动的范围，例如非当前 Scene、layout/bbox/overlap",
      "repair_checklist": ["核对题目条件", "修正公式", "同步最终结论"],
      "required_relations": ["必须成立的几何/数学关系"],
      "required_visual_objects": ["必须重建或保留的几何对象"],
      "forbidden_scope": ["禁止只改文字/公式或改非当前 Scene"],
      "verification_checklist": ["用坐标/距离/角度核验几何关系"]
    }}
  ],
  "needs_visual_check": false,
  "summary": "一句话摘要"
}}
"""
    dynamic_payload = f"""用户题目：{user_prompt}
Scene：{scene_name}

切片证据包 JSON:
{json.dumps(targets, ensure_ascii=False, indent=2)}
"""
    return stable_prefix, dynamic_payload
def _build_figure_lines_review_prompt(
    *,
    scene_name: str,
    targets: list[dict[str, Any]],
    user_prompt: str,
    reviewer_role: str,
    model_name: str,
) -> str:
    stable_prefix, dynamic_payload = _build_figure_lines_review_prompt_parts(
        scene_name=scene_name,
        targets=targets,
        user_prompt=user_prompt,
        reviewer_role=reviewer_role,
        model_name=model_name,
    )
    return f"{stable_prefix}\n\n{dynamic_payload}"
def _build_figure_lines_review_prompt_parts(
    *,
    scene_name: str,
    targets: list[dict[str, Any]],
    user_prompt: str,
    reviewer_role: str,
    model_name: str,
) -> tuple[str, str]:
    stable_prefix = f"""你是 MathPi 图形变换审查器，当前为 shadow mode。
只审查几何图元、几何关系和图形变换会导致画面数学不成立的硬错误。
只判断数学逻辑、几何条件、公式、结论和图形变换语义；不要判断 bbox/overlap/视觉遮挡/排版重叠、字体大小、对象位置或画面美观。
审查角色：{reviewer_role}
期望模型：{model_name}
审查范围：figure_lines

只允许关注这些对象和动作：Dot、Line、Arrow、Polygon、Triangle、Circle、Angle、RightAngle、Axes、NumberPlane、Transform、ReplacementTransform、MoveAlongPath、rotate、shift、move_to、become、几何 MathTex 绑定。
只允许返回这些 code：geometry_relation_error、symbol_binding_error、cut_fill_shape_deformation、condition_error、formula_error。
condition_error 和 formula_error 只有在证据直接绑定几何图形、坐标、角度、面积、垂直、平行、全等、相似、旋转、平移、反射、翻折、割补时才允许返回。
如果需要看最终画面才能判断，必须 needs_visual_check=true 且 hard_error=false。
如果证据包里已有 start_line/end_line，应把 code_span 原样带回。
如果问题能定位到 target_code，必须在 code_snippet 字段复制最相关的 1-5 行代码。
如果切片证据包与目标 Scene 不匹配、target_code 为空、或只包含 helper/base class 代码，不要判定“无硬错”；返回 evidence_mismatch，hard_error=false，policy_bucket=record_only，并标记 insufficient_scene_code=true。
对可修复的数学问题，除 suggested_fix 外还要给出 required_fix、expected_math_statement、forbidden_change_scope 和 repair_checklist；禁止要求修 bbox/overlap/layout。
如果 code=geometry_relation_error，还必须给出 required_relations、required_visual_objects、forbidden_scope 和 verification_checklist；这些字段只描述几何对象/坐标/关系/证明核验，不描述 layout/overlap/bbox。

只输出 JSON 对象，不要输出 Markdown。JSON schema:
{{
  "issues": [
    {{
      "code": "geometry_relation_error|symbol_binding_error|cut_fill_shape_deformation|condition_error|formula_error|evidence_mismatch",
      "severity": "high|medium|low",
      "confidence": 0.0,
      "hard_error": true,
      "evidence": "直接证据",
      "policy_bucket": "hard_error|needs_visual_check|record_only",
      "needs_visual_check": false,
      "repairable": true,
      "insufficient_scene_code": false,
      "code_span": {{"start_line": 0, "end_line": 0}},
      "code_snippet": "从 target_code 复制的相关代码片段",
      "suggested_fix": "只修当前 Scene 的建议",
      "required_fix": "必须完成的数学修复动作",
      "expected_math_statement": "修复后必须呈现的正确数学命题/公式/结论",
      "forbidden_change_scope": "禁止改动的范围，例如非当前 Scene、layout/bbox/overlap",
      "repair_checklist": ["核对几何条件", "修正图形关系/公式", "同步最终结论"],
      "required_relations": ["必须成立的几何/数学关系"],
      "required_visual_objects": ["必须重建或保留的几何对象"],
      "forbidden_scope": ["禁止只改文字/公式或改非当前 Scene"],
      "verification_checklist": ["用坐标/距离/角度核验几何关系"]
    }}
  ],
  "needs_visual_check": false,
  "summary": "一句话摘要"
}}
"""
    dynamic_payload = f"""用户题目：{user_prompt}
Scene：{scene_name}

切片证据包 JSON:
{json.dumps(targets, ensure_ascii=False, indent=2)}
"""
    return stable_prefix, dynamic_payload
def _normalize_scope(scope: str) -> str:
    normalized = (scope or "all").strip().lower()
    return normalized if normalized in {"all", "geometry", "figure_lines"} else "all"
def _scope_instruction(scope: str) -> str:
    if _normalize_scope(scope) != "geometry":
        return (
            "当前为全量 P1 快审：可以审查代数、概率、定义域、单位、最终答案、"
            "漏条件、漏小问、选项顺序和化学方程式/符号等硬错误。"
        )
    return (
        "当前为几何专注快审：只审查几何/坐标几何/图形变换/割补形变/垂直平行/角度面积/全等相似等"
        "会影响画面数学正确性的硬错误。纯代数化简、概率范围、等差数列、普通算术步骤如果没有服务于几何关系，"
        "必须忽略，不要生成 issue。坐标轴、点标签、辅助线等视觉标注需要画面判断时，只能标为 needs_visual_check，"
        "不能直接判 hard_error。"
    )



FIGURE_LINES_ALLOWED_CODES = {
    "geometry_relation_error",
    "symbol_binding_error",
    "cut_fill_shape_deformation",
    "condition_error",
    "formula_error",
}

FIGURE_LINES_STRICT_CODES = {
    "geometry_relation_error",
    "symbol_binding_error",
    "cut_fill_shape_deformation",
}

FIGURE_LINES_GEOMETRY_KEYWORDS = {
    "Dot",
    "Line",
    "Arrow",
    "Polygon",
    "Triangle",
    "Circle",
    "Angle",
    "RightAngle",
    "Axes",
    "NumberPlane",
    "Transform",
    "ReplacementTransform",
    "MoveAlongPath",
    "rotate",
    "shift",
    "move_to",
    "become",
    "animate",
    "\\angle",
    "\\parallel",
    "\\perp",
    "\\triangle",
    "angle",
    "parallel",
    "perpendicular",
    "area",
    "坐标",
    "角",
    "面积",
    "垂直",
    "平行",
    "全等",
    "相似",
    "旋转",
    "平移",
    "反射",
    "翻折",
    "割补",
    "图形",
    "几何",
}



