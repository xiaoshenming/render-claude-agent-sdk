import re

from .deterministic_guard_constants4 import EQUATION_EQUALS_PATTERN
from .deterministic_guard_constants4 import *  # noqa: F401,F403 - split constants share prior patterns
from .deterministic_guard_constants import (
    COEFFICIENT_VARIABLE_MULTIPLY_PATTERN,
    SIMPLE_NUMBER_VALUE_PATTERN,
)

SIMPLE_DIRECT_VARIABLE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([a-zA-Z])\s*(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_DIRECT_VARIABLE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([a-zA-Z])(?!\s*(?:\^|²))"
)

SIMPLE_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_ADDITIVE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_ADDITIVE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([a-zA-Z])\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([a-zA-Z])\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([a-zA-Z])\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)"
)

REVERSED_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([a-zA-Z])\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_TEX_COEFFICIENT_FRACTION_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_COEFFICIENT_FRACTION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*(?![+\-*/÷×])"
)

SIMPLE_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*(?![+\-*/÷×])"
)

SIMPLE_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*(?![+\-*/÷×])"
)

SIMPLE_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE = (
    re.compile(
        rf"\\frac\s*\{{\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
        rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
        rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
        rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
        rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
        rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    )
)

REVERSED_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE = (
    re.compile(
        rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
        rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
        rf"\\frac\s*\{{\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
        rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
        rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
        rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
        rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    )
)

SIMPLE_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_TEX_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)
