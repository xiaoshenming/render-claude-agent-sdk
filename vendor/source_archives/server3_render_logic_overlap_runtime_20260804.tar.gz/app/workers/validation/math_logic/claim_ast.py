"""AST-backed dependency extraction for math-logic claim evidence."""

from __future__ import annotations

import ast
import re

from .claim_contracts import NOISE_PREFIXES


def _is_noise_line(stripped: str) -> bool:
    return (
        not stripped or stripped.startswith("#") or stripped.startswith(NOISE_PREFIXES)
    )


def _collect_logical_block(
    lines: list[str],
    start_index: int,
    *,
    max_lines: int = 24,
) -> tuple[list[tuple[int, str]], int]:
    block: list[tuple[int, str]] = []
    balance = 0
    index = start_index
    while index < len(lines) and len(block) < max_lines:
        stripped = lines[index].strip()
        if _is_noise_line(stripped):
            break
        block.append((index + 1, stripped))
        balance += _delimiter_delta(stripped)
        index += 1
        if balance <= 0:
            break
    return block, index


def _delimiter_delta(line: str) -> int:
    return sum(line.count(open_char) for open_char in "([{") - sum(
        line.count(close_char) for close_char in ")]}"
    )


def _collect_dependency_context(
    lines: list[str],
    target_blocks: list[list[tuple[int, str]]],
) -> list[tuple[int, str]]:
    needed_names = _names_used_by_blocks(target_blocks)
    candidates: list[tuple[int, str, set[str], set[str]]] = []
    max_target_line = max(line_no for block in target_blocks for line_no, _ in block)
    for line_no, raw_line in enumerate(lines, start=1):
        if line_no > max_target_line:
            break
        stripped = raw_line.strip()
        if _is_noise_line(stripped):
            continue
        parsed = _parse_assignment(stripped)
        if not parsed:
            continue
        assigned_names, value_text = parsed
        if not _is_geometry_context_assignment(value_text):
            continue
        candidates.append(
            (line_no, stripped, assigned_names, _extract_identifiers(value_text))
        )

    selected: dict[int, str] = {}
    changed = True
    while changed:
        changed = False
        for line_no, line, assigned_names, used_names in candidates:
            if line_no in selected or not assigned_names.intersection(needed_names):
                continue
            selected[line_no] = line
            needed_names.update(used_names)
            changed = True

    return sorted(selected.items())


def _names_used_by_blocks(blocks: list[list[tuple[int, str]]]) -> set[str]:
    names: set[str] = set()
    for block in blocks:
        for _, line in block:
            parsed = _parse_assignment(line)
            if parsed:
                _, value_text = parsed
                names.update(_extract_identifiers(value_text))
            else:
                names.update(_extract_identifiers(line))
    return names


def _parse_assignment(line: str) -> tuple[set[str], str] | None:
    try:
        module = ast.parse(line)
    except SyntaxError:
        return None
    if len(module.body) != 1:
        return None
    statement = module.body[0]
    if isinstance(statement, ast.Assign):
        assigned_names: set[str] = set()
        for target in statement.targets:
            assigned_names.update(_assigned_names(target))
        value_text = ast.get_source_segment(line, statement.value) or ""
        return assigned_names, value_text
    if isinstance(statement, ast.AnnAssign):
        assigned_names = _assigned_names(statement.target)
        value_text = (
            ast.get_source_segment(line, statement.value) if statement.value else ""
        )
        return assigned_names, value_text or ""
    return None


def _assigned_names(node: ast.AST) -> set[str]:
    if isinstance(node, ast.Name):
        return {node.id}
    if isinstance(node, (ast.Tuple, ast.List)):
        names: set[str] = set()
        for item in node.elts:
            names.update(_assigned_names(item))
        return names
    return set()


def _is_geometry_context_assignment(value_text: str) -> bool:
    return bool(
        re.search(
            r"np\.array|\b(?:ORIGIN|UP|DOWN|LEFT|RIGHT|IN|OUT)\b|"
            r"[-+]?\d+(?:\.\d+)?",
            value_text,
        )
    )


def _extract_identifiers(text: str) -> set[str]:
    return set(re.findall(r"\b[A-Za-z_][A-Za-z0-9_]*\b", text or ""))
