"""Runtime runner facade for deterministic math guard."""
from __future__ import annotations
from typing import Any
from .schemas import MathLogicIssue

def run_deterministic_math_guard(
    targets: list[dict[str, Any]],
    *,
    user_prompt: str = "",
    scope: str = "all",
) -> list[MathLogicIssue]:
    normalized_scope = _normalize_scope(scope)
    issues: list[MathLogicIssue] = []
    for target in targets:
        scene_name = str(target.get("scene_name") or "")
        text = f"{target.get('statement') or ''}\n{target.get('target_code') or ''}"
        start_line = int(target.get("start_line") or 1)
        end_line = int(target.get("end_line") or start_line)
        issues.extend(_collect_target_math_issues(target, normalized_scope, user_prompt))
        dot_issue = _perpendicular_dot_issue(text)
        if dot_issue:
            issues.append(
                _issue(
                    code="geometry_relation_error",
                    scene_name=scene_name,
                    evidence=dot_issue,
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                )
            )
        for static_geometry_issue in static_geometry_issues(text, user_prompt=user_prompt):
            issues.append(
                _issue(
                    code=static_geometry_issue["code"],
                    scene_name=scene_name,
                    evidence=static_geometry_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=static_geometry_issue.get("suggested_fix", ""),
                    metadata=static_geometry_issue.get("metadata", {}),
                )
            )
        render_length_issue = _manim_render_length_conflation_issue(text, user_prompt)
        if render_length_issue:
            issues.append(
                _issue(
                    code="geometry_relation_error",
                    scene_name=scene_name,
                    evidence=render_length_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=render_length_issue["suggested_fix"],
                    metadata=render_length_issue["metadata"],
                )
            )
        issues.extend(collect_coordinate_area_issues(text, user_prompt, scene_name, start_line, end_line, target))
        issues.extend(_collect_remaining_target_math_issues(text, target, scene_name, start_line, end_line, normalized_scope, user_prompt))
    return issues
