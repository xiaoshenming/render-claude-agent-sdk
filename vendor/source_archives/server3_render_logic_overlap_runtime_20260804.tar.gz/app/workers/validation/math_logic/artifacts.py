from __future__ import annotations

import json
import os
import re
from pathlib import Path

from .schemas import MathLogicDecision


def write_math_logic_artifact(
    *,
    artifact_dir: str,
    job_id: str,
    decision: MathLogicDecision,
) -> str:
    safe_scene = re.sub(r"[^A-Za-z0-9_.-]+", "_", decision.scene_name)
    path = Path(artifact_dir) / f"{job_id}_{safe_scene}_math_logic_review.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "job_id": job_id,
        "category": "MATH_LOGIC_REVIEW",
        "decision": decision.to_dict(),
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return os.fspath(path)
