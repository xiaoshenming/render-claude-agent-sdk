"""数学逻辑审查的运行时配置读取与范围判定。"""

from __future__ import annotations

import os
import re

from app.core.config import settings


def runtime_value(name: str, default: str = "") -> str:
    if name in os.environ:
        return os.environ[name]
    value = getattr(settings, name, None)
    if value not in (None, ""):
        return str(value)
    return os.getenv(name, default)


def enabled() -> bool:
    return env_bool("MATH_LOGIC_REVIEW_ENABLED", False)


def write_artifacts() -> bool:
    return env_bool("MATH_LOGIC_WRITE_ARTIFACTS", True)


def mode() -> str:
    value = runtime_value("MATH_LOGIC_REVIEW_MODE", "shadow").strip().lower()
    return value if value in {"off", "shadow", "repair", "block"} else "shadow"


def sample_rate() -> float:
    return max(0.0, min(1.0, env_float("MATH_LOGIC_REVIEW_SAMPLE_RATE", 1.0)))


def high_risk_only_enabled() -> bool:
    return env_bool("MATH_LOGIC_HIGH_RISK_ONLY", True)


def review_scope() -> str:
    value = runtime_value("MATH_LOGIC_REVIEW_SCOPE", "auto").strip().lower()
    return value if value in {"auto", "geometry", "figure_lines", "all"} else "auto"


def effective_review_scope(*, configured_scope: str, **_: object) -> str:
    return configured_scope if configured_scope in {"all", "geometry", "figure_lines"} else "figure_lines"


def has_p1_non_geometry_signal(text: str) -> bool:
    return bool(re.search(
        r"(概率|等差|数列|函数|方程|不等式|单位|最终答案|化学|反应|方程式|配平|离子|电荷|物质的量|摩尔|生成物|小问|多问|选项|选择题|填空|\([1-9]\)|（[1-9]）|[①②③④⑤⑥])",
        text or "", flags=re.I,
    ))


def block_confidence() -> float:
    return env_float("MATH_LOGIC_BLOCK_CONFIDENCE", 0.9)


def review_concurrency() -> int:
    return max(1, env_int("MATH_LOGIC_REVIEW_CONCURRENCY", 32))


def fast_timeout() -> float:
    return env_float("MATH_LOGIC_FAST_TIMEOUT_SEC", 60.0)


def env_bool(name: str, default: bool) -> bool:
    raw = runtime_value(name, "")
    return default if not raw else raw.strip().lower() in {"1", "true", "yes", "on"}


def env_float(name: str, default: float) -> float:
    try:
        return float(runtime_value(name, str(default)))
    except (TypeError, ValueError):
        return default


def env_int(name: str, default: int) -> int:
    try:
        return int(runtime_value(name, str(default)))
    except (TypeError, ValueError):
        return default
