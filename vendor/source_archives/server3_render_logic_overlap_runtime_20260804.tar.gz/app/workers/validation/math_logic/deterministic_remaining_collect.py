from . import deterministic_guard as _guard

from . import deterministic_guard as _guard
_issue = _guard._issue

def _collect_remaining_target_math_issues(text, target, scene_name, start_line, end_line, normalized_scope, user_prompt):
    issues = []
    if normalized_scope == "all":
        arithmetic_issue = _arithmetic_sequence_issue(text, user_prompt)
        if arithmetic_issue:
            issues.append(
                _issue(
                    code="reasoning_step_error",
                    scene_name=scene_name,
                    evidence=arithmetic_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=arithmetic_issue["suggested_fix"],
                    metadata=arithmetic_issue["metadata"],
                )
            )
        missing_subquestion_issue = _missing_subquestion_issue(text, user_prompt)
        if missing_subquestion_issue:
            issues.append(
                _issue(
                    code="missing_subquestion",
                    scene_name=scene_name,
                    evidence=missing_subquestion_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=missing_subquestion_issue["suggested_fix"],
                    metadata=missing_subquestion_issue["metadata"],
                )
            )
        option_order_issue = _option_order_issue(text, user_prompt)
        if option_order_issue:
            issues.append(
                _issue(
                    code="option_order_error",
                    scene_name=scene_name,
                    evidence=option_order_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=option_order_issue["suggested_fix"],
                    metadata=option_order_issue["metadata"],
                )
            )
        option_answer_issue = _option_answer_issue(text, user_prompt)
        if option_answer_issue:
            issues.append(
                _issue(
                    code="option_answer_error",
                    scene_name=scene_name,
                    evidence=option_answer_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=option_answer_issue["suggested_fix"],
                    metadata=option_answer_issue["metadata"],
                )
            )
        requested_variable_issue = _requested_final_variable_issue(
            text,
            user_prompt,
        )
        if requested_variable_issue:
            issues.append(
                _issue(
                    code="final_answer_error",
                    scene_name=scene_name,
                    evidence=requested_variable_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=requested_variable_issue["suggested_fix"],
                    metadata=requested_variable_issue["metadata"],
                )
            )
        linear_answer_issue = _linear_equation_final_answer_issue(text, user_prompt)
        if linear_answer_issue:
            issues.append(
                _issue(
                    code="final_answer_error",
                    scene_name=scene_name,
                    evidence=linear_answer_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=linear_answer_issue["suggested_fix"],
                    metadata=linear_answer_issue["metadata"],
                )
            )
        square_equation_issue = _square_equation_final_answer_issue(text, user_prompt)
        if square_equation_issue:
            issues.append(
                _issue(
                    code="final_answer_error",
                    scene_name=scene_name,
                    evidence=square_equation_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=square_equation_issue["suggested_fix"],
                    metadata=square_equation_issue["metadata"],
                )
            )
        domain_issue = _explicit_domain_exclusion_issue(text, user_prompt)
        if domain_issue:
            issues.append(
                _issue(
                    code="domain_constraint_error",
                    scene_name=scene_name,
                    evidence=domain_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=domain_issue["suggested_fix"],
                    metadata=domain_issue["metadata"],
                )
            )
        chained_domain_bound_issue = _explicit_chained_domain_bound_issue(
            text,
            user_prompt,
        )
        if chained_domain_bound_issue:
            issues.append(
                _issue(
                    code="domain_constraint_error",
                    scene_name=scene_name,
                    evidence=chained_domain_bound_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=chained_domain_bound_issue["suggested_fix"],
                    metadata=chained_domain_bound_issue["metadata"],
                )
            )
        else:
            domain_bound_issue = _explicit_domain_bound_issue(text, user_prompt)
            if domain_bound_issue:
                issues.append(
                    _issue(
                        code="domain_constraint_error",
                        scene_name=scene_name,
                        evidence=domain_bound_issue["evidence"],
                        start_line=start_line,
                        end_line=end_line,
                        target=target,
                        suggested_fix=domain_bound_issue["suggested_fix"],
                        metadata=domain_bound_issue["metadata"],
                    )
                )
        number_condition_issue = _explicit_number_condition_issue(text, user_prompt)
        if number_condition_issue:
            issues.append(
                _issue(
                    code="domain_constraint_error",
                    scene_name=scene_name,
                    evidence=number_condition_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=number_condition_issue["suggested_fix"],
                    metadata=number_condition_issue["metadata"],
                )
            )
        divisibility_issue = _explicit_divisibility_condition_issue(text, user_prompt)
        if divisibility_issue:
            issues.append(
                _issue(
                    code="domain_constraint_error",
                    scene_name=scene_name,
                    evidence=divisibility_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=divisibility_issue["suggested_fix"],
                    metadata=divisibility_issue["metadata"],
                )
            )
        factor_issue = _explicit_factor_condition_issue(text, user_prompt)
        if factor_issue:
            issues.append(
                _issue(
                    code="domain_constraint_error",
                    scene_name=scene_name,
                    evidence=factor_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=factor_issue["suggested_fix"],
                    metadata=factor_issue["metadata"],
                )
            )
        digit_count_issue = _explicit_digit_count_condition_issue(text, user_prompt)
        if digit_count_issue:
            issues.append(
                _issue(
                    code="domain_constraint_error",
                    scene_name=scene_name,
                    evidence=digit_count_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=digit_count_issue["suggested_fix"],
                    metadata=digit_count_issue["metadata"],
                )
            )
        unit_issue = _unit_dimension_issue(text, user_prompt)
        if unit_issue:
            issues.append(
                _issue(
                    code="unit_error",
                    scene_name=scene_name,
                    evidence=unit_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=unit_issue["suggested_fix"],
                    metadata=unit_issue["metadata"],
                )
            )
        chemical_symbol_issue = _chemical_symbol_case_issue(text)
        if chemical_symbol_issue:
            issues.append(
                _issue(
                    code="chemical_symbol_error",
                    scene_name=scene_name,
                    evidence=chemical_symbol_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=chemical_symbol_issue["suggested_fix"],
                    metadata=chemical_symbol_issue["metadata"],
                )
            )
        chemical_equation_issue = _chemical_equation_balance_issue(text)
        if chemical_equation_issue:
            issues.append(
                _issue(
                    code="chemical_equation_error",
                    scene_name=scene_name,
                    evidence=chemical_equation_issue["evidence"],
                    start_line=start_line,
                    end_line=end_line,
                    target=target,
                    suggested_fix=chemical_equation_issue["suggested_fix"],
                    metadata=chemical_equation_issue["metadata"],
                )
            )
        return issues
