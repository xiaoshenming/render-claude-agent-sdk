"""Stable public API for deterministic math guard consumers."""

from .deterministic_guard import run_deterministic_math_guard

__all__ = ["run_deterministic_math_guard"]
