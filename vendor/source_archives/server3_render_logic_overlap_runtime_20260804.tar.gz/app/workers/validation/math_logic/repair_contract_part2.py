from __future__ import annotations

import hashlib
import json
import re
from typing import Any


WHOLE_SCENE_REPAIR_STRATEGY = "whole_scene_rebuild"

_CODE_OBLIGATIONS: dict[str, dict[str, list[str]]] = {
    "missing_condition": {
        "required_objects": ["题目条件中的关键点、线、圆、角或函数关系必须在画面中出现"],
        "required_relations": ["画面对象必须满足原题条件，不能只展示结论"],
        "required_proof_steps": ["补齐缺失条件如何参与后续推导"],
    },
    "missing_subquestion": {
        "required_proof_steps": ["逐条覆盖原题每个小问，不得只回答其中一部分"],
        "required_final_display": ["总结页必须列出每个小问对应结论"],
    },
    "teaching_structure_gap": {
        "required_proof_steps": ["补齐从题设到结论的中间推导过程"],
        "required_final_display": ["结论必须带依据，不得只有口号式总结"],
    },
    "geometry_relation_error": {
        "required_objects": ["重建相关点、线、角、圆，使坐标和几何关系一致"],
        "required_relations": ["长度、角度、平行、垂直、相切、共圆等关系必须可由坐标验证"],
        "required_proof_steps": ["证明文字必须和重建后的几何事实一致"],
    },
    "condition_error": {
        "required_relations": ["代码中的数值、坐标、比例、时间或单位必须匹配题目条件"],
        "required_proof_steps": ["所有计算步骤必须使用修正后的条件"],
    },
    "formula_error": {
        "required_formula_display": ["关键公式必须用 MathTex 展示，且公式左右两边数学含义正确"],
        "required_proof_steps": ["公式推导不能跳步到错误结论"],
    },
    "final_answer_error": {
        "required_formula_display": ["最终答案必须以题目要求的形式展示"],
        "required_proof_steps": ["最终答案前必须有可检查的推导依据"],
    },
    "symbol_binding_error": {
        "required_objects": ["所有文字中提到的点、线、角、变量必须在代码中定义并显示"],
        "required_relations": ["符号引用必须和实际图形对象绑定一致"],
    },
    "reasoning_step_error": {
        "required_proof_steps": ["重写错误推理步骤，保证每一步由前一步推出"],
    },
    "cut_fill_shape_deformation": {
        "required_objects": ["割补前后图形必须保留面积/边长/角度关系"],
        "required_relations": ["拼接、旋转、平移后的图形关系必须数值一致"],
    },
}



def annotate_math_logic_issues_with_contract(
    quality_issues: list[dict[str, Any]] | None,
    *,
    scene_name: str,
    user_prompt: str = "",
    planning_scene: dict[str, Any] | None = None,
    no_progress: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    contract = build_math_logic_scene_contract(
        scene_name=scene_name,
        user_prompt=user_prompt,
        planning_scene=planning_scene,
        quality_issues=quality_issues,
        no_progress=no_progress,
    )
    annotated = [
        dict(issue)
        for issue in quality_issues or []
        if isinstance(issue, dict)
        and str(issue.get("code") or issue.get("issue_code") or "")
        not in {"math_logic_scene_contract", "math_logic_scene_contract_obligations"}
    ]
    condition_obligations = build_math_logic_repair_obligations(
        scene_name=scene_name,
        user_prompt=user_prompt,
        planning_scene=planning_scene,
        quality_issues=quality_issues,
        no_progress=no_progress,
    )
    strategy = contract["repair_strategy"]
    for issue in annotated:
        metadata = issue.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        else:
            metadata = dict(metadata)
        metadata["scene_contract"] = contract
        if strategy == WHOLE_SCENE_REPAIR_STRATEGY:
            metadata["preferred_repair_strategy"] = WHOLE_SCENE_REPAIR_STRATEGY
            metadata["repair_scope"] = WHOLE_SCENE_REPAIR_STRATEGY
            metadata["rebuild_scope"] = WHOLE_SCENE_REPAIR_STRATEGY
        metadata.setdefault("condition_obligations", condition_obligations)
        issue["metadata"] = metadata
    annotated.append(
        {
            "code": "math_logic_scene_contract_obligations",
            "severity": "high",
            "confidence": 1.0,
            "scene_name": scene_name,
            "evidence": _format_contract_evidence(contract),
            "suggested_fix": "按 scene_contract.obligations 重建当前 Scene 的数学对象、关系、推导和最终展示。",
            "metadata": {
                "source": "math_logic_repair_contract",
                "scene_contract": contract,
                "condition_obligations": condition_obligations,
                "repair_strategy": strategy,
                "preferred_repair_strategy": strategy,
                "repair_scope": strategy if strategy == WHOLE_SCENE_REPAIR_STRATEGY else "target_scene",
                "rebuild_scope": strategy if strategy == WHOLE_SCENE_REPAIR_STRATEGY else "",
            },
        }
    )
    return annotated
def math_logic_issue_signature(
    quality_issues: list[dict[str, Any]] | None,
) -> str:
    parts: list[str] = []
    for issue in quality_issues or []:
        if not isinstance(issue, dict):
            continue
        code = str(issue.get("code") or issue.get("issue_code") or "")
        scene_name = str(issue.get("scene_name") or "")
        evidence = _compact_text(issue.get("evidence") or issue.get("message") or "")
        suggested = _compact_text(issue.get("suggested_fix") or "")
        parts.append("|".join([scene_name, code, evidence[:180], suggested[:120]]))
    digest_source = "\n".join(sorted(parts))
    if not digest_source:
        return ""
    return hashlib.sha256(digest_source.encode("utf-8", "replace")).hexdigest()[:16]
def record_math_logic_no_progress(
    task_data: dict[str, Any] | None,
    *,
    scene_name: str,
    quality_issues: list[dict[str, Any]] | None,
    threshold: int = 2,
) -> dict[str, Any]:
    signature = math_logic_issue_signature(quality_issues)
    if not signature:
        return {
            "no_progress": False,
            "signature": "",
            "hit_count": 0,
            "repeat_count": 0,
            "threshold": threshold,
        }
    if task_data is None:
        return {
            "no_progress": False,
            "signature": signature,
            "hit_count": 1,
            "repeat_count": 1,
            "threshold": threshold,
        }
    store = task_data.setdefault("_math_logic_repair_signature_hits", {})
    if not isinstance(store, dict):
        store = {}
        task_data["_math_logic_repair_signature_hits"] = store
    key = f"{scene_name}:{signature}"
    hit_count = int(store.get(key) or 0) + 1
    store[key] = hit_count
    result = {
        "no_progress": hit_count >= max(1, threshold),
        "signature": signature,
        "hit_count": hit_count,
        "repeat_count": hit_count,
        "threshold": max(1, threshold),
        "strategy_marker": "contract_rebuild_required",
    }
    if result["no_progress"]:
        task_data["_math_logic_repair_no_progress"] = {
            "scene_name": scene_name,
            **result,
        }
    return result
from . import repair_contract_part3 as _part3
from . import repair_contract_part4 as _part4
globals().update({k: v for _module in (_part3, _part4) for k, v in vars(_module).items() if not k.startswith("__")})
