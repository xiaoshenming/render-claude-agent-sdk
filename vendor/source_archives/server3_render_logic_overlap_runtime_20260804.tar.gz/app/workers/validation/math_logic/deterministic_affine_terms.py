from . import deterministic_guard as _guard
PARENTHESIZED_AFFINE_EQUATION_SIDE_RE = _guard.PARENTHESIZED_AFFINE_EQUATION_SIDE_RE
DIVISION_AFFINE_EQUATION_SIDE_RE = _guard.DIVISION_AFFINE_EQUATION_SIDE_RE
TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_RE = _guard.TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_RE
_parse_simple_number_value = _guard._parse_simple_number_value

from . import deterministic_guard as _guard

def parse_affine_side_terms(side):
    parenthesized = PARENTHESIZED_AFFINE_EQUATION_SIDE_RE.fullmatch(side or "")
    if parenthesized:
        coefficient_sign = -1.0 if parenthesized.group(1) == "-" else 1.0
        coefficient = 1.0
        if parenthesized.group(2):
            parsed_coefficient = _parse_simple_number_value(parenthesized.group(2))
            if parsed_coefficient is None:
                return None
            coefficient = parsed_coefficient
        coefficient *= coefficient_sign
        variable = parenthesized.group(3)
        offset = _parse_simple_number_value(parenthesized.group(5))
        if offset is None:
            return None
        inner_constant = offset if parenthesized.group(4) == "+" else -offset
        return variable, coefficient, coefficient * inner_constant

    division = DIVISION_AFFINE_EQUATION_SIDE_RE.fullmatch(side or "")
    if division:
        denominator = float(division.group(3))
        if abs(denominator) <= 1e-9:
            return None
        coefficient_sign = -1.0 if division.group(1) == "-" else 1.0
        coefficient = coefficient_sign / denominator
        variable = division.group(2)
        constant = 0.0
        if division.group(4) and division.group(5):
            parsed_constant = _parse_simple_number_value(division.group(5))
            if parsed_constant is None:
                return None
            constant = parsed_constant if division.group(4) == "+" else -parsed_constant
        return variable, coefficient, constant

    tex_fraction = TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_RE.fullmatch(side or "")
    if tex_fraction:
        denominator = float(tex_fraction.group(3))
        if abs(denominator) <= 1e-9:
            return None
        coefficient_sign = -1.0 if tex_fraction.group(1) == "-" else 1.0
        coefficient = coefficient_sign / denominator
        variable = tex_fraction.group(2)
        constant = 0.0
        if tex_fraction.group(4) and tex_fraction.group(5):
            parsed_constant = _parse_simple_number_value(tex_fraction.group(5))
            if parsed_constant is None:
                return None
            constant = parsed_constant if tex_fraction.group(4) == "+" else -parsed_constant
        return variable, coefficient, constant

        return None
