import re

SUBQUESTION_MARKER_RE = re.compile(
    r"\(([1-9一二三四五六七八九])\)|（([1-9一二三四五六七八九])）|([①②③④⑤⑥⑦⑧⑨])|"
    r"(?<!\d)([1-9])\s*[、\.．\)）](?!\d)|第\s*([1-9一二三四五六七八九])\s*(?:问|小题)"
)

SUBQUESTION_FINAL_CONTEXT_RE = re.compile(
    r"(最终答案|答案汇总|最终结论|总结|小结|结论|全部小问|完整解答|总答)"
)

SUBQUESTION_LABELS = {
    "①": 1,
    "②": 2,
    "③": 3,
    "④": 4,
    "⑤": 5,
    "⑥": 6,
    "⑦": 7,
    "⑧": 8,
    "⑨": 9,
    "一": 1,
    "二": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
}

OPTION_ORDER_CONTEXT_RE = re.compile(
    r"(选项解析|逐项解析|逐项分析|选项顺序|选项题|选择题|按选项)"
)

OPTION_MARKER_RE = re.compile(r"(?<![A-Za-z])([A-D])\s*(?:项|[\.．、\)])")

FINAL_OPTION_ANSWER_RE = re.compile(r"最终答案\s*[：:\s]*([A-F])(?:\b|[^A-Za-z])")

CORRECT_OPTION_CLAIM_RE = re.compile(r"(?<![A-Za-z])([A-D])\s*项\s*(?:正确|对|成立)")

LINEAR_EQUATION_CONTEXT_RE = re.compile(r"(解方程|方程|求\s*[a-zA-Z])")

SIMPLE_NUMBER_VALUE_PATTERN = (
    r"(?:[+-]?\s*\\frac\s*\{\s*[+-]?\d+(?:\.\d+)?\s*\}\s*\{\s*[+-]?\d+(?:\.\d+)?\s*\}"
    r"|[+-]?\d+(?:\.\d+)?(?:\s*/\s*[+-]?\d+(?:\.\d+)?)?)"
)

EQUATION_EQUALS_PATTERN = r"=|＝"

EXPLICIT_MULTIPLY_PATTERN = r"(?:[×*·]\s*|\\(?:cdot|times)\s*)"

COEFFICIENT_VARIABLE_MULTIPLY_PATTERN = rf"(?:{EXPLICIT_MULTIPLY_PATTERN})?"

SIMPLE_LINEAR_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

LINEAR_AFFINE_EQUATION_SIDE_PATTERN = (
    rf"[+-]?\s*(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?[a-zA-Z]\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

PARENTHESIZED_AFFINE_EQUATION_SIDE_PATTERN = (
    rf"[+-]?\s*(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*)?[(（]\s*"
    rf"[a-zA-Z]\s*[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN}\s*[)）]"
)

DIVISION_AFFINE_EQUATION_SIDE_PATTERN = (
    rf"[+-]?\s*[a-zA-Z]\s*[/÷]\s*[+-]?\d+(?:\.\d+)?\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

TEX_VARIABLE_FRACTION_AFFINE_EQUATION_SIDE_PATTERN = (
    rf"[+-]?\s*\\frac\s*\{{\s*[a-zA-Z]\s*\}}\s*"
    rf"\{{\s*[+-]?\d+(?:\.\d+)?\s*\}}\s*"
    rf"(?:[+-]\s*{SIMPLE_NUMBER_VALUE_PATTERN})?"
)

CONSTANT_FIRST_AFFINE_EQUATION_SIDE_PATTERN = (
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*"
    rf"(?:(?:{SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN})?[a-zA-Z]"
)

CONSTANT_FIRST_DIVISION_AFFINE_EQUATION_SIDE_PATTERN = (
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*"
    rf"[a-zA-Z]\s*[/÷]\s*[+-]?\d+(?:\.\d+)?"
)

CONSTANT_FIRST_TEX_VARIABLE_FRACTION_EQUATION_SIDE_PATTERN = (
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}\s*[+-]\s*"
    rf"\\frac\s*\{{\s*[a-zA-Z]\s*\}}\s*"
    rf"\{{\s*[+-]?\d+(?:\.\d+)?\s*\}}"
)
