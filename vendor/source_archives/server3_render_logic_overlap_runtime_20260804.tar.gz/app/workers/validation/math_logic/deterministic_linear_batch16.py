from . import deterministic_guard as _guard

def parse_linear_grammar_batch16(prompt):
    parsed_batch15 = parse_linear_grammar_batch15(prompt)
    if parsed_batch15 is not None:
            return parsed_batch15
    match = SIMPLE_TEX_COEFFICIENT_FRACTION_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(3))
            if abs(denominator) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(4))
            if right_value is None:
                return None
            return match.group(2), right_value * denominator / coefficient
    match = REVERSED_TEX_COEFFICIENT_FRACTION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(4))
            if abs(denominator) <= 1e-9:
                return None
            return match.group(3), left_value * denominator / coefficient
    match = SIMPLE_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(6))
            if right_value is None:
                return None
            inner_value = right_value * denominator / coefficient
            expected = inner_value - offset if match.group(3) == "+" else inner_value + offset
            return match.group(2), expected
    return None
