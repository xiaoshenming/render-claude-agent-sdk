from __future__ import annotations

import ast
import asyncio
import os
import random
import re
from app.workers.validation.math_logic_ast_helpers import (
    _integer_assignments, _for_loop_builds_target_sector_strip, _range_count,
    _eval_int_expr, _loop_has_mod2_branch, _loop_adds_to_target_group,
    _has_call_named, _call_name, _name_of,
)
import time
from dataclasses import replace
from typing import Any

from app.core.config import settings

from .artifacts import write_math_logic_artifact
from .claim_extractor import extract_math_logic_targets
from .deterministic_guard import run_deterministic_math_guard
from .evidence import build_evidence_mismatch_issue
from .policy import HARD_ERROR_TYPES, apply_math_logic_policy
from .reviewer_client import run_math_logic_review
from .schemas import MathLogicDecision, MathLogicIssue, MathLogicReviewResult
from .runtime_config import (
    block_confidence as _block_confidence,
    effective_review_scope as _effective_review_scope,
    enabled as _enabled,
    env_bool as _env_bool,
    env_float as _env_float,
    env_int as _env_int,
    fast_timeout as _fast_timeout,
    has_p1_non_geometry_signal as _has_p1_non_geometry_signal,
    high_risk_only_enabled as _high_risk_only_enabled,
    mode as _mode,
    review_concurrency as _review_concurrency,
    review_scope as _review_scope,
    runtime_value as _runtime_value,
    sample_rate as _sample_rate,
    write_artifacts as _write_artifacts,
)


_REVIEW_SEMAPHORE: asyncio.Semaphore | None = None
_REVIEW_SEMAPHORE_LIMIT = 0


from .runtime_patterns import (
    _CIRCLE_SECTOR_REARRANGEMENT_RE, _CIRCLE_SECTOR_COUNT_FALSE_POSITIVE_RE,
    _CIRCLE_SECTOR_FALSE_POSITIVE_CODES, _OPTION_SCENE_SCOPE_FALSE_POSITIVE_CODES,
    _OPTION_LABEL_RE, _OPTION_SCENE_LABEL_RE, _OPTION_COVERAGE_GAP_RE,
)
from .runtime_false_positive import (_downgrade_circle_sector_loop_false_positives, _is_circle_sector_count_false_positive, _downgrade_option_scene_scope_false_positives, _is_option_scene_scope_false_positive, _current_option_scene_label, _planned_option_scene_labels, _extract_option_scene_label, _extract_option_labels, _has_valid_circle_sector_loop_rearrangement, _has_valid_circle_sector_loop_rearrangement_text)
from .runtime_records import (_dedupe_issues, _maybe_write_artifact, assess_scene_math_logic_risk, _record_task_data, _record_render_log, _review_semaphore)

async def review_scene_math_logic(
    *,
    job_id: str,
    scene_name: str,
    scene_code: str,
    narration: str = "",
    user_prompt: str = "",
    planning_scene: dict | None = None,
    task_data: dict | None = None,
    force: bool = False,
) -> MathLogicDecision:
    if not _enabled() or _mode() == "off":
        decision = MathLogicDecision(
            mode="off",
            scene_name=scene_name,
            final_action="record_only",
            issues=[],
        )
        _record_task_data(task_data, decision, status="skipped")
        return decision

    mode = _mode()
    started_at = time.monotonic()
    try:
        risk = assess_scene_math_logic_risk(
            scene_name=scene_name,
            scene_code=scene_code,
            narration=narration,
            planning_scene=planning_scene,
        )
        if _high_risk_only_enabled() and not force and not risk["should_review"]:
            decision = MathLogicDecision(
                mode=mode,
                scene_name=scene_name,
                final_action="record_only",
                issues=[],
                latency_ms=int((time.monotonic() - started_at) * 1000),
                risk_assessment=risk,
            )
            _record_task_data(task_data, decision, status="skipped_low_risk")
            return decision

        if not force and random.random() > _sample_rate():
            decision = MathLogicDecision(
                mode=mode,
                scene_name=scene_name,
                final_action="record_only",
                issues=[],
                risk_assessment=risk,
            )
            _record_task_data(task_data, decision, status="skipped")
            return decision

        review_scope = _effective_review_scope(
            configured_scope=_review_scope(),
            user_prompt=user_prompt,
            narration=narration,
            planning_scene=planning_scene,
            scene_code=scene_code,
        )
        targets = extract_math_logic_targets(
            scene_name=scene_name,
            scene_code=scene_code,
            narration=narration,
            planning_scene=planning_scene,
            scope=review_scope,
        )
        evidence_mismatch_issue = build_evidence_mismatch_issue(
            scene_name=scene_name,
            scene_code=scene_code,
            targets=targets,
            narration=narration,
            user_prompt=user_prompt,
            planning_scene=planning_scene,
        )
        if evidence_mismatch_issue is not None:
            decision = apply_math_logic_policy(
                mode=mode,
                scene_name=scene_name,
                issues=[evidence_mismatch_issue],
                block_confidence=_block_confidence(),
                latency_ms=int((time.monotonic() - started_at) * 1000),
                risk_assessment=risk,
            )
            decision = _maybe_write_artifact(
                decision=decision,
                job_id=job_id,
                task_data=task_data,
            )
            _record_task_data(task_data, decision, status="evidence_mismatch")
            return decision
        if not targets:
            decision = MathLogicDecision(
                mode=mode,
                scene_name=scene_name,
                final_action="record_only",
                issues=[],
                risk_assessment=risk,
            )
            _record_task_data(task_data, decision, status="skipped")
            return decision
        deterministic_issues = run_deterministic_math_guard(
            targets,
            user_prompt=user_prompt,
            scope=review_scope,
        )
        review_result = await _run_reviewer(
            job_id=job_id,
            scene_name=scene_name,
            targets=targets,
            user_prompt=user_prompt,
            scope=review_scope,
            task_data=task_data,
        )
        reviewer_issues = _downgrade_circle_sector_loop_false_positives(
            review_result.issues,
            scene_code=scene_code,
            targets=targets,
            user_prompt=user_prompt,
        )
        reviewer_issues = _downgrade_option_scene_scope_false_positives(
            reviewer_issues,
            scene_name=scene_name,
            scene_code=scene_code,
            user_prompt=user_prompt,
            planning_scene=planning_scene,
            task_data=task_data,
        )
        issues = _dedupe_issues(deterministic_issues + reviewer_issues)
        latency_ms = int((time.monotonic() - started_at) * 1000)
        decision = apply_math_logic_policy(
            mode=mode,
            scene_name=scene_name,
            issues=issues,
            block_confidence=_block_confidence(),
            latency_ms=latency_ms,
            review_models={
                "fast": review_result.model_name,
                "backend": review_result.backend_name,
            },
            risk_assessment=risk,
        )
        decision = _maybe_write_artifact(
            decision=decision,
            job_id=job_id,
            task_data=task_data,
        )
        status = "review_error" if review_result.status == "review_error" else "recorded"
        _record_task_data(task_data, decision, status=status)
        return decision
    except Exception as exc:
        decision = MathLogicDecision(
            mode=mode,
            scene_name=scene_name,
            final_action="record_only",
            issues=[
                MathLogicIssue(
                    code="review_error",
                    severity="low",
                    confidence=1.0,
                    hard_error=False,
                    scene_name=scene_name,
                    evidence=f"{type(exc).__name__}: {exc}",
                    policy_bucket="record_only",
                    metadata={"source": "runtime"},
                )
            ],
            latency_ms=int((time.monotonic() - started_at) * 1000),
        )
        _record_task_data(task_data, decision, status="review_error")
        return decision

async def _run_reviewer(
    *,
    job_id: str,
    scene_name: str,
    targets: list[dict[str, Any]],
    user_prompt: str,
    scope: str,
    task_data: dict | None = None,
) -> MathLogicReviewResult:
    if not targets:
        return MathLogicReviewResult(status="skipped")
    async with _review_semaphore():
        return await run_math_logic_review(
            job_id=job_id,
            scene_name=scene_name,
            targets=targets,
            user_prompt=user_prompt,
            scope=scope,
            reviewer_role="fast",
            timeout_sec=_fast_timeout(),
            task_data=task_data,
        )
