from __future__ import annotations

import hashlib
import json
import re
from typing import Any


WHOLE_SCENE_REPAIR_STRATEGY = "whole_scene_rebuild"

_CODE_OBLIGATIONS: dict[str, dict[str, list[str]]] = {
    "missing_condition": {
        "required_objects": ["题目条件中的关键点、线、圆、角或函数关系必须在画面中出现"],
        "required_relations": ["画面对象必须满足原题条件，不能只展示结论"],
        "required_proof_steps": ["补齐缺失条件如何参与后续推导"],
    },
    "missing_subquestion": {
        "required_proof_steps": ["逐条覆盖原题每个小问，不得只回答其中一部分"],
        "required_final_display": ["总结页必须列出每个小问对应结论"],
    },
    "teaching_structure_gap": {
        "required_proof_steps": ["补齐从题设到结论的中间推导过程"],
        "required_final_display": ["结论必须带依据，不得只有口号式总结"],
    },
    "geometry_relation_error": {
        "required_objects": ["重建相关点、线、角、圆，使坐标和几何关系一致"],
        "required_relations": ["长度、角度、平行、垂直、相切、共圆等关系必须可由坐标验证"],
        "required_proof_steps": ["证明文字必须和重建后的几何事实一致"],
    },
    "condition_error": {
        "required_relations": ["代码中的数值、坐标、比例、时间或单位必须匹配题目条件"],
        "required_proof_steps": ["所有计算步骤必须使用修正后的条件"],
    },
    "formula_error": {
        "required_formula_display": ["关键公式必须用 MathTex 展示，且公式左右两边数学含义正确"],
        "required_proof_steps": ["公式推导不能跳步到错误结论"],
    },
    "final_answer_error": {
        "required_formula_display": ["最终答案必须以题目要求的形式展示"],
        "required_proof_steps": ["最终答案前必须有可检查的推导依据"],
    },
    "symbol_binding_error": {
        "required_objects": ["所有文字中提到的点、线、角、变量必须在代码中定义并显示"],
        "required_relations": ["符号引用必须和实际图形对象绑定一致"],
    },
    "reasoning_step_error": {
        "required_proof_steps": ["重写错误推理步骤，保证每一步由前一步推出"],
    },
    "cut_fill_shape_deformation": {
        "required_objects": ["割补前后图形必须保留面积/边长/角度关系"],
        "required_relations": ["拼接、旋转、平移后的图形关系必须数值一致"],
    },
}



def _issue_repair_checklist(text: str) -> list[str]:
    checklist: list[str] = []
    if "中点" in text:
        checklist.append("中点关系必须由坐标或线段比例验证")
    if "外角" in text and "平分线" in text:
        checklist.append("外角平分线方向必须由等角或45度方向验证")
    if "相切" in text:
        checklist.append("切线必须垂直于切点半径")
    if "垂直" in text:
        checklist.append("垂直关系必须由点积、斜率或直角标记验证")
    if "共圆" in text or "圆" in text:
        checklist.append("圆上点必须满足同一圆心半径关系")
    if "只改公式" in text or "只改文字" in text:
        checklist.append("诊断为构造错误时不得只改显示文字或公式")
    return checklist
def _formula_like_terms(text: str) -> list[str]:
    terms: list[str] = []
    for match in re.finditer(r"[A-Za-z][A-Za-z0-9_{}\\^+-]*\s*=\s*[^，。；,\s]+", text):
        terms.append(match.group(0).strip(" 。；,，"))
    return _dedupe_compact(terms)
def _coerce_text_list(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [_compact_text(value)] if _compact_text(value) else []
    if isinstance(value, dict):
        return [
            _compact_text(item)
            for item in value.values()
            if _compact_text(item)
        ]
    if isinstance(value, (list, tuple, set)):
        result: list[str] = []
        for item in value:
            if isinstance(item, dict):
                result.extend(_coerce_text_list(item))
            elif _compact_text(item):
                result.append(_compact_text(item))
        return result
    return [_compact_text(value)] if _compact_text(value) else []
def _subquestion_obligations(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, dict):
            text = _compact_text(
                item.get("question")
                or item.get("description")
                or item.get("goal")
                or item.get("answer")
            )
        else:
            text = _compact_text(item)
        if text:
            result.append(f"覆盖小问: {text}")
    return result
def _symbol_binding_obligations(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return []
    result: list[str] = []
    for key, item in value.items():
        text = _compact_text(item)
        if key and text:
            result.append(f"{key}: {text}")
    return result
def _claim_obligations(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    result: list[str] = []
    for item in value:
        if isinstance(item, dict):
            text = _compact_text(
                item.get("formula")
                or item.get("claim")
                or item.get("answer")
                or item.get("text")
            )
        else:
            text = _compact_text(item)
        if text:
            result.append(text)
    return result
def _dedupe_compact(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        item = _compact_text(value)
        if not item or item in seen:
            continue
        seen.add(item)
        result.append(item[:260])
    return result
def _compact_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()
def _format_contract_evidence(contract: dict[str, Any]) -> str:
    obligations = contract.get("obligations") or {}
    try:
        payload = json.dumps(obligations, ensure_ascii=False, sort_keys=True)
    except TypeError:
        payload = str(obligations)
    return f"MATH_LOGIC_SCENE_CONTRACT {contract.get('repair_strategy')}: {payload[:900]}"

