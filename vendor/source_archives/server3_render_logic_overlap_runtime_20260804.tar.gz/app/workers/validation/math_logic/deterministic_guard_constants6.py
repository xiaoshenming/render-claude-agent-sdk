import re

from .deterministic_guard_constants5 import SIMPLE_NUMBER_VALUE_PATTERN
from .deterministic_guard_constants5 import *  # noqa: F401,F403 - split constants share prior patterns
from .deterministic_guard_constants import (
    COEFFICIENT_VARIABLE_MULTIPLY_PATTERN,
    EQUATION_EQUALS_PATTERN,
)

REVERSED_TEX_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_TEX_VARIABLE_TIMES_FRACTION_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*([a-zA-Z])\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_VARIABLE_TIMES_FRACTION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*([a-zA-Z])\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*(?![+\-*/÷×])"
)

SIMPLE_TEX_VARIABLE_TIMES_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"\\frac\s*\{{\s*([a-zA-Z])\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_VARIABLE_TIMES_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"\\frac\s*\{{\s*([a-zA-Z])\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*\}}\s*"
    rf"\{{\s*([+-]?\d+(?:\.\d+)?)\s*\}}\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_TEX_FRACTION_EQUATION_RE = re.compile(
    r"\\frac\s*\{\s*([a-zA-Z])\s*\}\s*\{\s*([+-]?\d+(?:\.\d+)?)\s*\}"
    rf"\s*(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_TEX_FRACTION_AFFINE_EQUATION_RE = re.compile(
    r"\\frac\s*\{\s*([a-zA-Z])\s*\}\s*\{\s*([+-]?\d+(?:\.\d+)?)\s*\}"
    rf"\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_TEX_FRACTION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    r"\\frac\s*\{\s*([a-zA-Z])\s*\}\s*\{\s*([+-]?\d+(?:\.\d+)?)\s*\}"
)

REVERSED_TEX_FRACTION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*"
    r"\\frac\s*\{\s*([a-zA-Z])\s*\}\s*\{\s*([+-]?\d+(?:\.\d+)?)\s*\}"
    rf"\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SQUARE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([a-zA-Z])\s*(?:\^2|²)\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([+-]?\d+(?:\.\d+)?)"
)

REVERSED_SQUARE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([+-]?\d+(?:\.\d+)?)\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([a-zA-Z])\s*(?:\^2|²)"
)

REQUESTED_VARIABLE_LIST_RE = re.compile(
    r"(?:求|计算|解出)\s*"
    r"([a-zA-Z](?:\s*(?:和|与|及|、|,|，)\s*[a-zA-Z])+)"
)

REQUESTED_VARIABLE_RE = re.compile(
    r"(?:求|计算|解出)\s*([a-zA-Z])\s*(?:的值)?"
    r"|([a-zA-Z])\s*(?:的值)?\s*(?:是多少|等于多少)"
)

FINAL_ASSIGNMENT_SUBJECT_SUFFIX_PATTERN = r"(?:的值|的取值|的解)?"

FINAL_ASSIGNMENT_OPERATOR_PATTERN = r"=|＝|取值为|取值是|为|是|等于"

FINAL_ASSIGNMENT_VARIABLE_RE = re.compile(
    rf"(?<![A-Za-z0-9])([a-zA-Z])\s*{FINAL_ASSIGNMENT_SUBJECT_SUFFIX_PATTERN}\s*"
    rf"(?:{FINAL_ASSIGNMENT_OPERATOR_PATTERN})\s*"
    rf"{SIMPLE_NUMBER_VALUE_PATTERN}"
)

FINAL_NUMERIC_ANSWER_RE = re.compile(
    rf"最终答案\s*[：:\s]*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

DOMAIN_EXCLUSION_RE = re.compile(
    r"([a-zA-Z])\s*(?:≠|!=|不等于|不能为|不可为)\s*(-?\d+(?:\.\d+)?)"
)

DOMAIN_BOUND_OPERATOR_PATTERN = (
    r">=|<=|>|<|≥|≤|大于或等于|大于等于|小于或等于|小于等于|"
    r"至少|不少于|不小于|至多|不超过|不大于|大于|超过|小于|低于"
)

DOMAIN_BOUND_RE = re.compile(
    rf"([a-zA-Z])\s*({DOMAIN_BOUND_OPERATOR_PATTERN})\s*"
    r"(?:为|是)?\s*"
    r"(-?\d+(?:\.\d+)?)"
)
