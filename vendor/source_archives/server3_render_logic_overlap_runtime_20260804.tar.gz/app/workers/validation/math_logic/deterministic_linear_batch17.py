from . import deterministic_guard as _guard

def parse_linear_grammar_batch17(prompt):
    parsed_batch16 = parse_linear_grammar_batch16(prompt)
    if parsed_batch16 is not None:
            return parsed_batch16
    match = REVERSED_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            inner_value = left_value * denominator / coefficient
            expected = inner_value - offset if match.group(4) == "+" else inner_value + offset
            return match.group(3), expected
    match = SIMPLE_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_EQUATION_RE.search(
            prompt
        )
    if match:
            offset = _parse_simple_number_value(match.group(3))
            if offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(4))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(6))
            if right_value is None:
                return None
            inner_value = right_value * denominator / coefficient
            expected = inner_value - offset if match.group(2) == "+" else inner_value + offset
            return match.group(1), expected
    match = (
            REVERSED_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_EQUATION_RE.search(
                prompt
            )
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(5))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            inner_value = left_value * denominator / coefficient
            expected = inner_value - offset if match.group(3) == "+" else inner_value + offset
            return match.group(2), expected
    return None
