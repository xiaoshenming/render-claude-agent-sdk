from typing import Any

def _explicit_number_condition_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    conditions = _extract_number_conditions(user_prompt)
    if not conditions:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    for variable, condition in conditions:
        for actual in _extract_final_variable_values(text, variable):
            if _satisfies_number_condition(actual, condition):
                continue
            condition_label = f"{variable} 为 {condition}"
            return {
                "evidence": (
                    f"题干明确要求 {condition_label}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": (
                    f"剔除不满足 {condition_label} 的答案，并重新核对定义域/条件。"
                ),
                "metadata": {
                    "guard": "explicit_number_condition",
                    "variable": variable,
                    "condition": condition,
                    "actual": actual,
                },
            }
    return None

def _extract_number_conditions(user_prompt: str) -> list[tuple[str, str]]:
    conditions: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for match in NUMBER_CONDITION_RE.finditer(user_prompt or ""):
        variable = match.group(1)
        condition = match.group(2)
        _append_number_condition(conditions, seen, variable, condition)
        tail = (user_prompt or "")[match.end():]
        offset = 0
        while True:
            followup = FOLLOWUP_NUMBER_CONDITION_RE.match(tail[offset:])
            if not followup:
                break
            _append_number_condition(conditions, seen, variable, followup.group(1))
            offset += followup.end()
    return conditions

def _append_number_condition(
    conditions: list[tuple[str, str]],
    seen: set[tuple[str, str]],
    variable: str,
    condition: str,
) -> None:
    key = (variable, condition)
    if variable and key not in seen:
        conditions.append(key)
        seen.add(key)

def _satisfies_number_condition(actual: float, condition: str) -> bool:
    if condition == "非负数":
        return actual > 0 or _same_number(actual, 0)
    if condition == "非正数":
        return actual < 0 or _same_number(actual, 0)
    if condition == "正数":
        return actual > 0 and not _same_number(actual, 0)
    if condition == "负数":
        return actual < 0 and not _same_number(actual, 0)
    if not _is_integer_value(actual):
        return False
    if condition in {"质数", "素数"}:
        return _is_prime_integer(int(round(actual)))
    if condition == "合数":
        value = int(round(actual))
        return value > 1 and not _is_prime_integer(value)
    if condition in {"平方数", "完全平方数"}:
        value = int(round(actual))
        return value >= 0 and _is_square_integer(value)
    if condition == "非零自然数":
        return actual > 0 and not _same_number(actual, 0)
    if condition == "自然数":
        return actual > 0 or _same_number(actual, 0)
    if condition == "正整数":
        return actual > 0 and not _same_number(actual, 0)
    if condition == "非负整数":
        return actual > 0 or _same_number(actual, 0)
    if condition == "偶数":
        return int(round(actual)) % 2 == 0
    if condition == "奇数":
        return int(round(actual)) % 2 != 0
    return True

def _explicit_divisibility_condition_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    conditions = _extract_divisibility_conditions(user_prompt)
    if not conditions:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    for variable, divisor, condition_label in conditions:
        for actual in _extract_final_variable_values(text, variable):
            if _satisfies_divisibility_condition(actual, divisor):
                continue
            return {
                "evidence": (
                    f"题干明确要求 {condition_label}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": (
                    f"剔除不满足 {condition_label} 的答案，并重新核对定义域/条件。"
                ),
                "metadata": {
                    "guard": "explicit_divisibility_condition",
                    "variable": variable,
                    "divisor": divisor,
                    "actual": actual,
                },
            }
    return None

def _extract_divisibility_conditions(user_prompt: str) -> list[tuple[str, int, str]]:
    conditions: list[tuple[str, int, str]] = []
    seen: set[tuple[str, int, str]] = set()
    for match in MULTIPLE_CONDITION_RE.finditer(user_prompt or ""):
        variable = match.group(1)
        divisor = int(match.group(2))
        label = f"{variable} 为 {_fmt_number(divisor)} 的倍数"
        key = (variable, divisor, label)
        if divisor and key not in seen:
            conditions.append(key)
            seen.add(key)
    for match in DIVISIBLE_BY_CONDITION_RE.finditer(user_prompt or ""):
        variable = match.group(1)
        divisor = int(match.group(2))
        label = f"{variable} 被 {_fmt_number(divisor)} 整除"
        key = (variable, divisor, label)
        if divisor and key not in seen:
            conditions.append(key)
            seen.add(key)
    return conditions

def _satisfies_divisibility_condition(actual: float, divisor: int) -> bool:
    if divisor == 0 or not _is_integer_value(actual):
        return False
    return int(round(actual)) % abs(divisor) == 0

def _explicit_factor_condition_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    conditions = _extract_factor_conditions(user_prompt)
    if not conditions:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    for variable, target_value, condition_label in conditions:
        for actual in _extract_final_variable_values(text, variable):
            if _satisfies_factor_condition(actual, target_value):
                continue
            return {
                "evidence": (
                    f"题干明确要求 {condition_label}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": (
                    f"剔除不满足 {condition_label} 的答案，并重新核对定义域/条件。"
                ),
                "metadata": {
                    "guard": "explicit_factor_condition",
                    "variable": variable,
                    "target_value": target_value,
                    "actual": actual,
                },
            }
    return None

def _extract_factor_conditions(user_prompt: str) -> list[tuple[str, int, str]]:
    conditions: list[tuple[str, int, str]] = []
    seen: set[tuple[str, int, str]] = set()
    for match in FACTOR_CONDITION_RE.finditer(user_prompt or ""):
        variable = match.group(1)
        target_value = int(match.group(2))
        term = match.group(3)
        label = f"{variable} 为 {_fmt_number(target_value)} 的{term}"
        key = (variable, target_value, label)
        if target_value and key not in seen:
            conditions.append(key)
            seen.add(key)
    return conditions

def _satisfies_factor_condition(actual: float, target_value: int) -> bool:
    if target_value == 0 or not _is_integer_value(actual):
        return False
    actual_int = int(round(actual))
    if actual_int == 0:
        return False
    return target_value % abs(actual_int) == 0

def _explicit_digit_count_condition_issue(
    text: str,
    user_prompt: str,
) -> dict[str, Any] | None:
    conditions = _extract_digit_count_conditions(user_prompt)
    if not conditions:
        return None
    if not SUBQUESTION_FINAL_CONTEXT_RE.search(text or ""):
        return None
    for variable, digit_count, condition_label in conditions:
        for actual in _extract_final_variable_values(text, variable):
            if _satisfies_digit_count_condition(actual, digit_count):
                continue
            return {
                "evidence": (
                    f"题干明确要求 {condition_label}，但当前最终答案为 "
                    f"{variable}={_fmt_number(actual)}。"
                ),
                "suggested_fix": (
                    f"剔除不满足 {condition_label} 的答案，并重新核对定义域/条件。"
                ),
                "metadata": {
                    "guard": "explicit_digit_count_condition",
                    "variable": variable,
                    "digit_count": digit_count,
                    "actual": actual,
                },
            }
    return None

def _extract_digit_count_conditions(user_prompt: str) -> list[tuple[str, int, str]]:
    conditions: list[tuple[str, int, str]] = []
    seen: set[tuple[str, int, str]] = set()
    for match in DIGIT_COUNT_CONDITION_RE.finditer(user_prompt or ""):
        variable = match.group(1)
        digit_count = DIGIT_COUNT_LABELS.get(match.group(2), 0)
        label = f"{variable} 为 {match.group(2)}位数"
        key = (variable, digit_count, label)
        if digit_count and key not in seen:
            conditions.append(key)
            seen.add(key)
    return conditions

def _satisfies_digit_count_condition(actual: float, digit_count: int) -> bool:
    if digit_count <= 0 or not _is_integer_value(actual):
        return False
    actual_int = int(round(actual))
    if actual_int <= 0:
        return False
    return len(str(actual_int)) == digit_count
