from __future__ import annotations

import ast
import math
import re
from dataclasses import dataclass
from typing import Any


Point = tuple[float, float]
EPSILON = 1e-6


@dataclass(frozen=True)
class ParsedGeometry:
    values: dict[str, float]
    point_vars: dict[str, Point]
    point_lists: dict[str, list[Point]]
    polygons: dict[str, list[Point]]



def _parse_geometry(code: str) -> ParsedGeometry:
    values = _numeric_assignments(code)
    point_vars = _point_variable_assignments(code, values)
    point_lists = _point_list_assignments(code, values)
    polygons = _polygon_assignments(code, values, point_vars, point_lists)
    return ParsedGeometry(
        values=values,
        point_vars=point_vars,
        point_lists=point_lists,
        polygons=polygons,
    )
def _numeric_assignments(code: str) -> dict[str, float]:
    pending: dict[str, str] = {}
    for line in code.splitlines():
        match = re.match(r"\s*([A-Za-z_]\w*)\s*=\s*([^#\n]+?)\s*$", line)
        if not match:
            continue
        name = match.group(1)
        expression = match.group(2).strip()
        if any(marker in expression for marker in ("[", "]", "{", "}", '"', "'")):
            continue
        pending[name] = expression

    values: dict[str, float] = {}
    for _ in range(6):
        changed = False
        for name, expression in pending.items():
            if name in values:
                continue
            value = _safe_eval_number(expression, values)
            if value is None:
                continue
            values[name] = value
            changed = True
        if not changed:
            break
    return values
def _point_variable_assignments(code: str, values: dict[str, float]) -> dict[str, Point]:
    points: dict[str, Point] = {}
    for line in code.splitlines():
        match = re.match(r"\s*([A-Za-z_]\w*)\s*=\s*(np\.array\([^\n]+\))\s*$", line)
        if not match:
            continue
        point = _parse_np_array_point(match.group(2), values)
        if point is not None:
            points[match.group(1)] = point
    return points
def _point_list_assignments(code: str, values: dict[str, float]) -> dict[str, list[Point]]:
    lists: dict[str, list[Point]] = {}
    for name, body in _named_bracket_blocks(code):
        points = _np_array_points_in_text(body, values)
        if points:
            lists[name] = points
    return lists
def _polygon_assignments(
    code: str,
    values: dict[str, float],
    point_vars: dict[str, Point],
    point_lists: dict[str, list[Point]],
) -> dict[str, list[Point]]:
    polygons: dict[str, list[Point]] = {}
    for name, args_text in _named_call_blocks(code, "Polygon"):
        points = _polygon_points(args_text, values, point_vars, point_lists)
        if len(points) >= 3:
            polygons[name] = points
    return polygons
def _polygon_points(
    args_text: str,
    values: dict[str, float],
    point_vars: dict[str, Point],
    point_lists: dict[str, list[Point]],
) -> list[Point]:
    points: list[Point] = []
    for raw_arg in _split_top_level(args_text):
        arg = raw_arg.strip()
        if not arg or _looks_like_keyword_arg(arg):
            continue
        point = _parse_np_array_point(arg, values)
        if point is None:
            point = _resolve_point_reference(arg, point_vars, point_lists)
        if point is not None:
            points.append(point)
    return points
def _resolve_point_reference(
    expression: str,
    point_vars: dict[str, Point],
    point_lists: dict[str, list[Point]],
) -> Point | None:
    variable_match = re.fullmatch(r"([A-Za-z_]\w*)", expression)
    if variable_match:
        return point_vars.get(variable_match.group(1))

    list_match = re.fullmatch(r"([A-Za-z_]\w*)\s*\[\s*(\d+)\s*\]", expression)
    if not list_match:
        return None
    points = point_lists.get(list_match.group(1))
    if not points:
        return None
    index = int(list_match.group(2))
    if index >= len(points):
        return None
    return points[index]
def _named_bracket_blocks(code: str) -> list[tuple[str, str]]:
    blocks: list[tuple[str, str]] = []
    pattern = re.compile(r"(?m)^\s*([A-Za-z_]\w*)\s*=\s*\[")
    for match in pattern.finditer(code):
        close_index = _find_matching(code, match.end() - 1, "[", "]")
        if close_index is None:
            continue
        blocks.append((match.group(1), code[match.end() - 1 : close_index + 1]))
    return blocks
def _named_call_blocks(code: str, call_name: str) -> list[tuple[str, str]]:
    blocks: list[tuple[str, str]] = []
    pattern = re.compile(rf"(?m)^\s*([A-Za-z_]\w*)\s*=\s*{re.escape(call_name)}\s*\(")
    for match in pattern.finditer(code):
        open_index = match.end() - 1
        close_index = _find_matching(code, open_index, "(", ")")
        if close_index is None:
            continue
        blocks.append((match.group(1), code[open_index + 1 : close_index]))
    return blocks
def _find_matching(text: str, open_index: int, opener: str, closer: str) -> int | None:
    depth = 0
    in_string: str | None = None
    escaped = False
    for index in range(open_index, len(text)):
        char = text[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == in_string:
                in_string = None
            continue
        if char in ("'", '"'):
            in_string = char
            continue
        if char == opener:
            depth += 1
        elif char == closer:
            depth -= 1
            if depth == 0:
                return index
    return None
def _parse_np_array_point(expression: str, values: dict[str, float]) -> Point | None:
    match = re.search(r"np\.array\(\s*\[([^\]]+)\]\s*\)", expression)
    if not match:
        return None
    parts = _split_top_level(match.group(1))
    if len(parts) < 2:
        return None
    x_value = _safe_eval_number(parts[0], values)
    y_value = _safe_eval_number(parts[1], values)
    if x_value is None or y_value is None:
        return None
    return (_clean_zero(x_value), _clean_zero(y_value))
def _np_array_points_in_text(text: str, values: dict[str, float]) -> list[Point]:
    points: list[Point] = []
    for match in re.finditer(r"np\.array\(\s*\[[^\]]+\]\s*\)", text):
        point = _parse_np_array_point(match.group(0), values)
        if point is not None:
            points.append(point)
    return points

from . import geometry_static_guard_part3 as _part3
globals().update({k:v for _module in (_part3,) for k,v in vars(_module).items() if not k.startswith("__")})

