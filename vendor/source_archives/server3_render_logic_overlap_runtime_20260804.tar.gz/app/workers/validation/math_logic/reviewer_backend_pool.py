"""数学逻辑 reviewer 的 dedicated backend pool 配置解析。"""

from __future__ import annotations

import json
from typing import Any


def parse_backend_pool(raw: str) -> list[dict[str, Any]]:
    text = (raw or "").strip()
    if not text:
        return []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    parsed: list[dict[str, Any]] = []
    for index, item in enumerate(data):
        if not isinstance(item, dict):
            continue
        model_name = str(item.get("model") or "").strip()
        keys = item.get("keys")
        keys = [keys] if isinstance(keys, str) else keys
        if not isinstance(keys, list):
            keys = []
        clean_keys = [str(key).strip() for key in keys if str(key or "").strip()]
        if not model_name or not clean_keys:
            continue
        try:
            priority = int(item.get("priority") or index + 1)
        except (TypeError, ValueError):
            priority = index + 1
        base_name = str(item.get("name") or f"dedicated-{model_name}").strip()
        api_base = str(item.get("api_base") or "").strip()
        for key_index, api_key in enumerate(clean_keys):
            parsed.append({
                "priority": priority,
                "backend_name": base_name if len(clean_keys) == 1 else f"{base_name}-{key_index + 1}",
                "api_key": api_key,
                "api_base": api_base,
                "model_name": model_name,
            })
    parsed.sort(key=lambda item: item["priority"])
    return parsed


def first_pool_model(raw: str) -> str:
    pool = parse_backend_pool(raw)
    return str(pool[0]["model_name"]) if pool else ""
