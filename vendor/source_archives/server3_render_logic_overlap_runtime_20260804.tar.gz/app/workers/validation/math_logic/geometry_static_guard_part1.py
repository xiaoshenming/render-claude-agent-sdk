from __future__ import annotations

import ast
import math
import re
from dataclasses import dataclass
from typing import Any


Point = tuple[float, float]
EPSILON = 1e-6


@dataclass(frozen=True)
class ParsedGeometry:
    values: dict[str, float]
    point_vars: dict[str, Point]
    point_lists: dict[str, list[Point]]
    polygons: dict[str, list[Point]]



def static_geometry_issues(
    text: str,
    *,
    user_prompt: str = "",
) -> list[dict[str, Any]]:
    code = _strip_line_prefixes(text)
    parsed = _parse_geometry(code)
    issues: list[dict[str, Any]] = []

    collinear_issue = _claimed_collinear_coordinates_issue(text, parsed)
    if collinear_issue:
        issues.append(collinear_issue)

    shared_vertices_issue = _cut_fill_triangle_shared_vertices_issue(text, parsed)
    if shared_vertices_issue:
        issues.append(shared_vertices_issue)

    inner_polygon_issue = _pythagorean_numeric_inner_polygon_issue(
        text,
        user_prompt,
        parsed,
    )
    if inner_polygon_issue:
        issues.append(inner_polygon_issue)

    zhaoshuang_formula_issue = _zhaoshuang_outer_square_formula_issue(
        text,
        user_prompt,
        parsed,
    )
    if zhaoshuang_formula_issue:
        issues.append(zhaoshuang_formula_issue)

    return issues
def _claimed_collinear_coordinates_issue(
    text: str,
    parsed: ParsedGeometry,
) -> dict[str, Any] | None:
    if not re.search(r"共线|同一直线|collinear", text, flags=re.I):
        return None
    point_names = _claimed_collinear_point_names(text)
    if len(point_names) < 3:
        point_names = sorted(parsed.point_vars)[:3]
    if len(point_names) < 3:
        return None
    points: list[Point] = []
    missing: list[str] = []
    for name in point_names[:3]:
        point = parsed.point_vars.get(name)
        if point is None:
            missing.append(name)
        else:
            points.append(point)
    if missing or len(points) < 3:
        return None
    cross = _cross(points[0], points[1], points[2])
    if abs(cross) <= EPSILON:
        return None
    labels = "、".join(point_names[:3])
    return {
        "code": "geometry_relation_error",
        "evidence": (
            f"文本声称 {labels} 共线，但坐标叉积为 {_fmt_number(cross)}，"
            "三点不在同一直线上。"
        ),
        "suggested_fix": "同步修正点坐标或删除共线/对齐表述，确保文字关系和图形坐标一致。",
        "metadata": {
            "guard": "claimed_collinear_coordinates",
            "points": {name: list(parsed.point_vars[name]) for name in point_names[:3]},
            "cross_product": cross,
        },
    }
def _cut_fill_triangle_shared_vertices_issue(
    text: str,
    parsed: ParsedGeometry,
) -> dict[str, Any] | None:
    if not re.search(r"公共边|共享边|沿[^，。；;]*边[^，。；;]*(?:拼合|拼接|合成)", text):
        return None
    triangles = {
        name: points for name, points in parsed.polygons.items() if len(points) == 3
    }
    if len(triangles) < 2:
        return None
    for first_name, first_points in triangles.items():
        for second_name, second_points in triangles.items():
            if first_name >= second_name:
                continue
            if _shared_point_count(first_points, second_points) >= 2:
                return None
    names = "、".join(sorted(triangles)[:4])
    return {
        "code": "cut_fill_shape_deformation",
        "evidence": (
            f"文本声称三角形沿公共边拼合，但 {names} 的顶点坐标没有任意两点重合，"
            "不存在可见公共边。"
        ),
        "suggested_fix": "让相邻三角形复用同一条边的两个端点，或把文字改为平移/分离展示。",
        "metadata": {
            "guard": "cut_fill_triangle_shared_vertices",
            "triangles": {
                name: [list(point) for point in points]
                for name, points in triangles.items()
            },
        },
    }
def _pythagorean_numeric_inner_polygon_issue(
    text: str,
    user_prompt: str,
    parsed: ParsedGeometry,
) -> dict[str, Any] | None:
    if not _mentions_pythagorean_cut_fill(text, user_prompt):
        return None
    for name, points in parsed.polygons.items():
        if len(points) != 4 or not re.search(r"inner|small|center|square|sq", name, re.I):
            continue
        if _is_square(points):
            continue
        side_lengths = _polygon_side_lengths(points)
        angle_dots = _adjacent_dot_products(points)
        return {
            "code": "cut_fill_shape_deformation",
            "evidence": (
                f"勾股割补图声称 {name} 是内部正方形，但按坐标计算边长为 "
                f"{_fmt_numbers(side_lengths)}，相邻边点积为 {_fmt_numbers(angle_dots)}，"
                "不是正方形。"
            ),
            "suggested_fix": (
                "用四个直角三角形的斜边端点构造旋转正方形，或重新计算四个顶点，"
                "保证四边等长且相邻边垂直。"
            ),
            "metadata": {
                "guard": "pythagorean_numeric_inner_polygon",
                "polygon": name,
                "points": [list(point) for point in points],
                "side_lengths": side_lengths,
                "adjacent_dot_products": angle_dots,
            },
        }
    return None
def _zhaoshuang_outer_square_formula_issue(
    text: str,
    user_prompt: str,
    parsed: ParsedGeometry,
) -> dict[str, Any] | None:
    if not _mentions_pythagorean_cut_fill(text, user_prompt):
        return None
    if not re.search(r"S[\s\S]{0,120}大[\s\S]{0,120}=[\s\S]{0,120}c\s*(?:\^|\*\*)\s*2", text):
        return None
    if not re.search(r"\(\s*[ab]\s*-\s*[ab]\s*\)\s*(?:\^|\*\*)\s*2", text):
        return None

    outer = _outer_square_polygon(parsed.polygons)
    if not outer:
        return None
    outer_name, outer_points = outer
    if not _is_square(outer_points):
        return None
    outer_side = _polygon_side_lengths(outer_points)[0]

    for triangle_name, triangle_points in parsed.polygons.items():
        if len(triangle_points) != 3:
            continue
        sides = sorted(_triangle_side_lengths(triangle_points))
        if len(sides) != 3 or not _close(sides[0] ** 2 + sides[1] ** 2, sides[2] ** 2):
            continue
        leg_sum = sides[0] + sides[1]
        hypotenuse = sides[2]
        if _close(outer_side, leg_sum) and not _close(outer_side, hypotenuse):
            return {
                "code": "cut_fill_shape_deformation",
                "evidence": (
                    f"外框边长 {_fmt_number(outer_side)} 等于三角形两直角边和 "
                    f"{_fmt_number(leg_sum)}，不是斜边 c={_fmt_number(hypotenuse)}；"
                    "画面却把大正方形面积写成 c^2。"
                ),
                "suggested_fix": (
                    "若公式使用 S大=c^2，外框必须由四个三角形斜边围成；"
                    "若外框边长是 a+b，应把面积公式改为 (a+b)^2 并同步说明。"
                ),
                "metadata": {
                    "guard": "zhaoshuang_outer_square_formula",
                    "outer_square": outer_name,
                    "triangle": triangle_name,
                    "outer_side": outer_side,
                    "leg_sum": leg_sum,
                    "hypotenuse": hypotenuse,
                },
            }
    return None

from . import geometry_static_guard_part2 as _part2
from . import geometry_static_guard_part3 as _part3
globals().update({k:v for _module in (_part2,_part3,) for k,v in vars(_module).items() if not k.startswith("__")})

