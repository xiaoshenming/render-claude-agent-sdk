from __future__ import annotations

import asyncio
import json
import os
import re
import time
from typing import Any

from app.services.llm_service import get_llm_manager
from app.services.dedicated_llm_client import call_dedicated_chat_completion
from app.services.llm_call_tracer import LLMCallTracer
from app.prompts.prompt_compiler import compile_cacheable_segmented_prompt
try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover - dependency exists in runtime image
    AsyncOpenAI = None

from app.core.config import settings
from app.core.runtime_config.client import (
    is_runtime_settings_override,
    refresh_runtime_config_if_stale,
)
from app.workers.repair.repair_state import (
    BackhalfRepairBudget,
    record_backhalf_repair_call,
)

from .policy import HARD_ERROR_TYPES
from .schemas import MathLogicIssue, MathLogicReviewResult
from .reviewer_backend_pool import first_pool_model as _first_pool_model, parse_backend_pool as _parse_backend_pool
from .reviewer_config_helpers import (
    metadata_value as _metadata_value,
    confidence as _confidence,
    severity as _severity,
    review_model_name as _review_model_name,
    review_max_tokens as _review_max_tokens,
    dedicated_backend_configs as _dedicated_backend_configs,
    dedicated_backend_config as _dedicated_backend_config,
)

MATH_LOGIC_FAST_DEFAULT_MAX_TOKENS = 4096
MATH_LOGIC_FINAL_DEFAULT_MAX_TOKENS = 8192



from .reviewer_prompts import *
from .reviewer_issue_filters import *
def _trace_usage_context(compile_result) -> dict[str, Any]:
    return {
        "prompt_segments": compile_result.prompt_segments,
        "cache_metrics": compile_result.cache_metrics,
        "prompt_firewall": compile_result.firewall_report,
    }
def _runtime_value(name: str, default: str = "") -> str:
    if is_runtime_settings_override(name):
        value = getattr(settings, name, None)
        if value not in (None, ""):
            return str(value)
    env_value = os.getenv(name)
    if env_value is not None:
        return env_value
    value = getattr(settings, name, None)
    if value not in (None, ""):
        return str(value)
    return default
async def _refresh_runtime_config_before_dedicated_checks() -> None:
    try:
        await asyncio.wait_for(
            refresh_runtime_config_if_stale(min_interval_sec=2.0),
            timeout=0.5,
        )
    except Exception:
        return
def parse_review_json(output_text: str) -> dict[str, Any]:
    text = (output_text or "").strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.S | re.I)
    if fenced:
        text = fenced.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end + 1])
        raise
async def run_math_logic_review(
    *,
    job_id: str,
    scene_name: str,
    targets: list[dict[str, Any]],
    user_prompt: str = "",
    scope: str = "all",
    reviewer_role: str = "fast",
    timeout_sec: float | None = None,
    task_data: dict[str, Any] | None = None,
) -> MathLogicReviewResult:
    started_at = time.monotonic()
    await _refresh_runtime_config_before_dedicated_checks()
    timeout = timeout_sec if timeout_sec is not None else _env_float(
        "MATH_LOGIC_FAST_TIMEOUT_SEC",
        60.0,
    )
    model_name = _review_model_name(reviewer_role)
    prompt = _build_review_prompt(
        scene_name=scene_name,
        targets=targets,
        user_prompt=user_prompt,
        scope=scope,
        reviewer_role=reviewer_role,
        model_name=model_name,
    )
    stable_prefix, dynamic_payload = _build_review_prompt_parts(
        scene_name=scene_name,
        targets=targets,
        user_prompt=user_prompt,
        scope=scope,
        reviewer_role=reviewer_role,
        model_name=model_name,
    )
    compile_result = compile_cacheable_segmented_prompt(
        prompt_id=f"math_logic_review:{_normalize_scope(scope)}:{reviewer_role}",
        stable_prefix=stable_prefix,
        dynamic_payload=dynamic_payload,
        selected_skills=["quality.math_logic_check"],
        expected_skill_role="quality",
        dynamic_payload_type="math_logic_review_targets",
    )
    trace_usage_context = _trace_usage_context(compile_result)
    budget_decision = record_backhalf_repair_call(
        task_data,
        scene_name=scene_name,
        call_type=f"math_logic_{reviewer_role}",
        signature=compile_result.prompt_content,
        budget=BackhalfRepairBudget(),
    )
    if not budget_decision.allowed:
        return MathLogicReviewResult(
            status="budget_skipped",
            issues=[],
            model_name=model_name,
            latency_ms=int((time.monotonic() - started_at) * 1000),
            summary=f"backhalf_budget:{budget_decision.reason}",
        )
    try:
        dedicated_backends = _dedicated_backend_configs(reviewer_role)
        if dedicated_backends:
            last_exc: Exception | None = None
            for dedicated in dedicated_backends:
                try:
                    dedicated_kwargs = {
                        key: value
                        for key, value in dedicated.items()
                        if key != "priority"
                    }
                    return await _run_dedicated_openai_compatible_review(
                        job_id=job_id,
                        prompt=compile_result.prompt_content,
                        messages=compile_result.cacheable_messages,
                        trace_usage_context=trace_usage_context,
                        scene_name=scene_name,
                        targets=targets,
                        scope=scope,
                        reviewer_role=reviewer_role,
                        timeout=timeout,
                        started_at=started_at,
                        **dedicated_kwargs,
                    )
                except Exception as exc:
                    last_exc = exc
                    continue
            if last_exc is not None:
                raise last_exc
        response, backend_name = await asyncio.wait_for(
            get_llm_manager().call(
                messages=compile_result.cacheable_messages,
                max_tokens=_review_max_tokens(reviewer_role),
                retry_budget=1,
                trace_job_id=job_id,
                trace_call_type=f"math_logic_{reviewer_role}",
                trace_prompt_version="math_logic_review_v1",
                trace_prompt_content=compile_result.prompt_content,
                trace_response_format="json_object",
                trace_usage_context=trace_usage_context,
            ),
            timeout=timeout,
        )
        raw_output = response.choices[0].message.content or ""
        payload = parse_review_json(raw_output)
        issues = [
            _issue_from_payload(raw, scene_name=scene_name)
            for raw in payload.get("issues", []) or []
            if isinstance(raw, dict)
        ]
        issues = _filter_issues_for_scope(issues, targets=targets, scope=scope)
        return MathLogicReviewResult(
            status="ok",
            issues=issues,
            backend_name=backend_name,
            model_name=model_name,
            latency_ms=int((time.monotonic() - started_at) * 1000),
            raw_output=raw_output,
            summary=str(payload.get("summary") or ""),
        )
    except Exception as exc:
        elapsed_ms = int((time.monotonic() - started_at) * 1000)
        return MathLogicReviewResult(
            status="review_error",
            issues=[
                MathLogicIssue(
                    code="review_error",
                    severity="low",
                    confidence=1.0,
                    hard_error=False,
                    scene_name=scene_name,
                    evidence=f"{type(exc).__name__}: {exc}",
                    policy_bucket="record_only",
                    metadata={"source": "reviewer_client"},
                )
            ],
            model_name=model_name,
            latency_ms=elapsed_ms,
            error=f"{type(exc).__name__}: {exc}",
        )
async def _run_dedicated_openai_compatible_review(
    *,
    job_id: str,
    prompt: str,
    messages: list[dict[str, Any]],
    trace_usage_context: dict[str, Any],
    scene_name: str,
    targets: list[dict[str, Any]],
    scope: str,
    reviewer_role: str,
    backend_name: str,
    model_name: str,
    api_key: str,
    api_base: str,
    timeout: float,
    started_at: float,
) -> MathLogicReviewResult:
    env_prefix = "MATH_LOGIC_FINAL" if reviewer_role == "final" else "MATH_LOGIC_FAST"
    response = await call_dedicated_chat_completion(
        job_id=job_id,
        call_type=f"math_logic_{reviewer_role}",
        prompt_version="math_logic_review_v1",
        prompt_content=prompt,
        backend_name=backend_name,
        limiter_key=f"math_logic_{reviewer_role}",
        env_prefix=env_prefix,
        client_cls=AsyncOpenAI,
        tracer_cls=LLMCallTracer,
        api_key=api_key,
        api_base=api_base,
        model_name=model_name,
        timeout=timeout,
        request_kwargs={
            "model": model_name,
            "messages": messages,
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "max_tokens": _review_max_tokens(reviewer_role),
        },
        trace_usage_context=trace_usage_context,
    )
    raw_output = response.choices[0].message.content or ""
    payload = parse_review_json(raw_output)
    issues = [
        _issue_from_payload(raw, scene_name=scene_name)
        for raw in payload.get("issues", []) or []
        if isinstance(raw, dict)
    ]
    issues = _filter_issues_for_scope(issues, targets=targets, scope=scope)
    return MathLogicReviewResult(
        status="ok",
        issues=issues,
        backend_name=backend_name,
        model_name=model_name,
        latency_ms=int((time.monotonic() - started_at) * 1000),
        raw_output=raw_output,
        summary=str(payload.get("summary") or ""),
    )

