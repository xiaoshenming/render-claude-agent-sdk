from __future__ import annotations

def _parse_affine_equation_side(side: str) -> tuple[str, float, float] | None:
    parsed_terms = parse_affine_side_terms(side)
    if parsed_terms is not None:
        return parsed_terms

    constant_first = CONSTANT_FIRST_AFFINE_EQUATION_SIDE_RE.fullmatch(side or "")
    if constant_first:
        constant = _parse_simple_number_value(constant_first.group(1))
        if constant is None:
            return None
        coefficient = 1.0
        if constant_first.group(3):
            parsed_coefficient = _parse_simple_number_value(constant_first.group(3))
            if parsed_coefficient is None:
                return None
            coefficient = parsed_coefficient
        if constant_first.group(2) == "-":
            coefficient *= -1
        return constant_first.group(4), coefficient, constant

    constant_first_division = CONSTANT_FIRST_DIVISION_AFFINE_EQUATION_SIDE_RE.fullmatch(
        side or ""
    )
    if constant_first_division:
        constant = _parse_simple_number_value(constant_first_division.group(1))
        if constant is None:
            return None
        denominator = float(constant_first_division.group(4))
        if abs(denominator) <= 1e-9:
            return None
        coefficient = 1.0 / denominator
        if constant_first_division.group(2) == "-":
            coefficient *= -1
        return constant_first_division.group(3), coefficient, constant

    constant_first_tex_fraction = (
        CONSTANT_FIRST_TEX_VARIABLE_FRACTION_EQUATION_SIDE_RE.fullmatch(side or "")
    )
    if constant_first_tex_fraction:
        constant = _parse_simple_number_value(constant_first_tex_fraction.group(1))
        if constant is None:
            return None
        denominator = float(constant_first_tex_fraction.group(4))
        if abs(denominator) <= 1e-9:
            return None
        coefficient = 1.0 / denominator
        if constant_first_tex_fraction.group(2) == "-":
            coefficient *= -1
        return constant_first_tex_fraction.group(3), coefficient, constant

    parsed_numeric = parse_affine_side_numeric_terms(side)
    if parsed_numeric is not None:
        return parsed_numeric

    tex_constant_first_variable_times_numerator = (
        TEX_CONSTANT_FIRST_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_RE.fullmatch(
            side or ""
        )
    )
    if tex_constant_first_variable_times_numerator:
        denominator = float(tex_constant_first_variable_times_numerator.group(5))
        if abs(denominator) <= 1e-9:
            return None
        numerator_constant = _parse_simple_number_value(
            tex_constant_first_variable_times_numerator.group(1)
        )
        if numerator_constant is None:
            return None
        coefficient = _parse_simple_number_value(
            tex_constant_first_variable_times_numerator.group(4)
        )
        if coefficient is None:
            return None
        if tex_constant_first_variable_times_numerator.group(2) == "-":
            coefficient *= -1
        constant = numerator_constant / denominator
        if (
            tex_constant_first_variable_times_numerator.group(6)
            and tex_constant_first_variable_times_numerator.group(7)
        ):
            tail_constant = _parse_simple_number_value(
                tex_constant_first_variable_times_numerator.group(7)
            )
            if tail_constant is None:
                return None
            constant += (
                tail_constant
                if tex_constant_first_variable_times_numerator.group(6) == "+"
                else -tail_constant
            )
        return (
            tex_constant_first_variable_times_numerator.group(3),
            coefficient / denominator,
            constant,
        )

    tex_variable_times_numerator = (
        TEX_VARIABLE_TIMES_COEFFICIENT_NUMERATOR_FRACTION_EQUATION_SIDE_RE.fullmatch(
            side or ""
        )
    )
    if tex_variable_times_numerator:
        denominator = float(tex_variable_times_numerator.group(6))
        if abs(denominator) <= 1e-9:
            return None
        coefficient = _parse_simple_number_value(tex_variable_times_numerator.group(3))
        if coefficient is None:
            return None
        if tex_variable_times_numerator.group(1) == "-":
            coefficient *= -1
        numerator_constant = _parse_simple_number_value(
            tex_variable_times_numerator.group(5)
        )
        if numerator_constant is None:
            return None
        if tex_variable_times_numerator.group(4) == "-":
            numerator_constant *= -1
        constant = numerator_constant / denominator
        if (
            tex_variable_times_numerator.group(7)
            and tex_variable_times_numerator.group(8)
        ):
            tail_constant = _parse_simple_number_value(
                tex_variable_times_numerator.group(8)
            )
            if tail_constant is None:
                return None
            constant += (
                tail_constant
                if tex_variable_times_numerator.group(7) == "+"
                else -tail_constant
            )
        return (
            tex_variable_times_numerator.group(2),
            coefficient / denominator,
            constant,
        )

    variable_first_tex_numerator = (
        VARIABLE_FIRST_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_RE.fullmatch(
            side or ""
        )
    )
    if variable_first_tex_numerator:
        denominator = float(variable_first_tex_numerator.group(6))
        if abs(denominator) <= 1e-9:
            return None
        numerator_coefficient = 1.0
        if variable_first_tex_numerator.group(2):
            parsed_coefficient = _parse_simple_number_value(
                variable_first_tex_numerator.group(2)
            )
            if parsed_coefficient is None:
                return None
            numerator_coefficient = parsed_coefficient
        if variable_first_tex_numerator.group(1) == "-":
            numerator_coefficient *= -1
        numerator_constant = _parse_simple_number_value(
            variable_first_tex_numerator.group(5)
        )
        if numerator_constant is None:
            return None
        if variable_first_tex_numerator.group(4) == "-":
            numerator_constant *= -1
        constant = numerator_constant / denominator
        if variable_first_tex_numerator.group(7) and variable_first_tex_numerator.group(8):
            tail_constant = _parse_simple_number_value(
                variable_first_tex_numerator.group(8)
            )
            if tail_constant is None:
                return None
            constant += (
                tail_constant
                if variable_first_tex_numerator.group(7) == "+"
                else -tail_constant
            )
        return (
            variable_first_tex_numerator.group(3),
            numerator_coefficient / denominator,
            constant,
        )

    tex_affine_numerator = TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_SIDE_RE.fullmatch(
        side or ""
    )
    if tex_affine_numerator:
        numerator_constant = _parse_simple_number_value(tex_affine_numerator.group(1))
        if numerator_constant is None:
            return None
        denominator = float(tex_affine_numerator.group(5))
        if abs(denominator) <= 1e-9:
            return None
        numerator_coefficient = 1.0
        if tex_affine_numerator.group(3):
            parsed_coefficient = _parse_simple_number_value(
                tex_affine_numerator.group(3)
            )
            if parsed_coefficient is None:
                return None
            numerator_coefficient = parsed_coefficient
        if tex_affine_numerator.group(2) == "-":
            numerator_coefficient *= -1
        constant = numerator_constant / denominator
        if tex_affine_numerator.group(6) and tex_affine_numerator.group(7):
            tail_constant = _parse_simple_number_value(tex_affine_numerator.group(7))
            if tail_constant is None:
                return None
            constant += (
                tail_constant if tex_affine_numerator.group(6) == "+" else -tail_constant
            )
        return (
            tex_affine_numerator.group(4),
            numerator_coefficient / denominator,
            constant,
        )

    match = AFFINE_EQUATION_SIDE_RE.fullmatch(side or "")
    if not match:
        return None
    coefficient_sign = -1.0 if match.group(1) == "-" else 1.0
    coefficient = 1.0
    if match.group(2):
        parsed_coefficient = _parse_simple_number_value(match.group(2))
        if parsed_coefficient is None:
            return None
        coefficient = parsed_coefficient
    coefficient *= coefficient_sign
    variable = match.group(3)
    constant = 0.0
    if match.group(4) and match.group(5):
        parsed_constant = _parse_simple_number_value(match.group(5))
        if parsed_constant is None:
            return None
        constant = parsed_constant if match.group(4) == "+" else -parsed_constant
    return variable, coefficient, constant
