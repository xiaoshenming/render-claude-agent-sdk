from __future__ import annotations

import os
import re
import asyncio
from typing import Any
from app.workers.validation.math_logic_ast_helpers import _range_count, _eval_int_expr, _loop_has_mod2_branch, _loop_adds_to_target_group, _call_name, _name_of
from app.core.config import settings
from .artifacts import write_math_logic_artifact
from .policy import HARD_ERROR_TYPES
from .runtime_config import write_artifacts as _write_artifacts, review_concurrency as _review_concurrency
from .schemas import MathLogicDecision, MathLogicIssue

def _dedupe_issues(issues: list[MathLogicIssue]) -> list[MathLogicIssue]:
    deduped: list[MathLogicIssue] = []
    seen: set[tuple] = set()
    seen_hard_scene_codes: set[tuple[str, str]] = set()
    for issue in issues:
        hard_scene_code = (issue.scene_name, issue.code)
        if issue.hard_error and issue.code in HARD_ERROR_TYPES:
            if hard_scene_code in seen_hard_scene_codes:
                continue
            seen_hard_scene_codes.add(hard_scene_code)
        span = issue.code_span or {}
        if span.get("start_line") is not None or span.get("end_line") is not None:
            key = (
                issue.scene_name,
                issue.code,
                span.get("start_line"),
                span.get("end_line"),
            )
        else:
            key = (
                issue.scene_name,
                issue.code,
                (issue.claim_id or issue.statement or issue.evidence or "")[:120],
            )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(issue)
    return deduped

def _maybe_write_artifact(
    *,
    decision: MathLogicDecision,
    job_id: str,
    task_data: dict | None,
) -> MathLogicDecision:
    if not _write_artifacts() or not task_data:
        return decision
    artifact_dir = task_data.get("_math_logic_artifact_dir")
    if not artifact_dir:
        return decision
    try:
        artifact_path = write_math_logic_artifact(
            artifact_dir=str(artifact_dir),
            job_id=job_id,
            decision=decision,
        )
        return MathLogicDecision(
            mode=decision.mode,
            scene_name=decision.scene_name,
            final_action=decision.final_action,
            issues=decision.issues,
            latency_ms=decision.latency_ms,
            block_reason=decision.block_reason,
            needs_repair=decision.needs_repair,
            needs_visual_check=decision.needs_visual_check,
            hard_error_count=decision.hard_error_count,
            needs_visual_check_count=decision.needs_visual_check_count,
            review_models=decision.review_models,
            artifact_path=artifact_path,
            risk_assessment=decision.risk_assessment,
        )
    except Exception:
        return decision

def assess_scene_math_logic_risk(
    *,
    scene_name: str,
    scene_code: str,
    narration: str = "",
    planning_scene: dict | None = None,
) -> dict[str, Any]:
    local_parts = [scene_name or "", scene_code or "", narration or ""]
    if isinstance(planning_scene, dict):
        for key in (
            "name",
            "title",
            "description",
            "narration",
            "voiceover",
            "math_content",
            "goal",
            "type",
            "stage",
        ):
            value = planning_scene.get(key)
            if value:
                local_parts.append(str(value))
    text = "\n".join(local_parts)
    signals: list[str] = []

    high_patterns = [
        ("geometry_proof", r"证明|垂直平分|垂直|平行|全等|相似|勾股|圆|三角形|中点|角平分|位似"),
        ("coordinate_transform", r"坐标|坐标变换|平移|旋转|轴对称|关于.*对称|原点|x['’]|y['’]"),
        ("application_calculation", r"应用题|实际问题|列方程|计算|求解|求和|数列|利润|行程|工程|浓度|增长率|总价|速度"),
        ("derivative", r"导数|单调性|极值|切线|函数.*最值|f['’]\("),
        ("probability", r"概率|随机|事件|样本空间|期望|方差|恰好|至少"),
    ]
    for signal, pattern in high_patterns:
        if re.search(pattern, text, flags=re.I):
            signals.append(signal)
    if re.search(r"关键结论|最终答案|答案|结论|综上|可得", text, flags=re.I) and (
        signals
        or re.search(r"证明|坐标|函数|方程|概率|导数|求和|数列|三角形", text, flags=re.I)
    ):
        signals.append("conclusion")

    extra_keywords = [
        item.strip()
        for item in os.getenv("MATH_LOGIC_HIGH_RISK_EXTRA_KEYWORDS", "").split(",")
        if item.strip()
    ]
    if any(keyword in text for keyword in extra_keywords):
        signals.append("configured_keyword")

    low_risk_hint = bool(
        re.search(
            r"Title|Intro|Transition|Cover|Warmup|标题|封面|过渡|导入|引入|回顾|"
            r"简单解释|概念介绍|本节|下一步|我们来看",
            text,
            flags=re.I,
        )
    )
    should_review = bool(signals)
    skip_reason = ""
    if not should_review:
        skip_reason = (
            "low_risk_title_or_transition"
            if low_risk_hint
            else "no_high_risk_math_signal"
        )
    return {
        "should_review": should_review,
        "risk_level": "high" if should_review else "low",
        "signals": sorted(set(signals)),
        "skip_reason": skip_reason,
    }

def _record_task_data(
    task_data: dict | None,
    decision: MathLogicDecision,
    *,
    status: str,
) -> None:
    if task_data is None:
        return
    scenes = task_data.setdefault("_math_logic_review_scenes", {})
    scenes[decision.scene_name] = {
        "status": status,
        "decision": decision.to_dict(),
    }
    task_data["_math_logic_review"] = {
        "status": status,
        "scene_count": len(scenes),
        "hard_error_count": sum(
            item["decision"].get("hard_error_count", 0)
            for item in scenes.values()
        ),
        "needs_visual_check_count": sum(
            item["decision"].get("needs_visual_check_count", 0)
            for item in scenes.values()
        ),
        "latest_scene": decision.scene_name,
        "latest_action": decision.final_action,
        "scenes": scenes,
    }
    _record_render_log(task_data, decision, status=status)

def _record_render_log(
    task_data: dict,
    decision: MathLogicDecision,
    *,
    status: str,
) -> None:
    if status == "skipped":
        return
    collector = task_data.get("_error_collector")
    if collector is None:
        return
    issues = [
        issue.to_dict() if hasattr(issue, "to_dict") else issue
        for issue in decision.issues
    ]
    context = {
        "type": "math_logic_review",
        "status": status,
        "scene_name": decision.scene_name,
        "mode": decision.mode,
        "final_action": decision.final_action,
        "hard_error_count": decision.hard_error_count,
        "needs_visual_check_count": decision.needs_visual_check_count,
        "needs_repair": decision.needs_repair,
        "needs_visual_check": decision.needs_visual_check,
        "review_models": decision.review_models,
        "artifact_path": decision.artifact_path,
        "issues": issues,
    }
    message = (
        f"数学逻辑审查 {decision.scene_name}: "
        f"{status}/{decision.final_action}, hard={decision.hard_error_count}"
    )
    try:
        method = collector.warning if status == "review_error" else collector.info
        method(
            "MATH_LOGIC_REVIEW",
            "CODE_VALIDATION",
            message,
            context=context,
            duration_ms=decision.latency_ms,
        )
    except Exception:
        return

def _review_semaphore() -> asyncio.Semaphore:
    global _REVIEW_SEMAPHORE, _REVIEW_SEMAPHORE_LIMIT
    limit = _review_concurrency()
    if _REVIEW_SEMAPHORE is None or _REVIEW_SEMAPHORE_LIMIT != limit:
        _REVIEW_SEMAPHORE = asyncio.Semaphore(limit)
        _REVIEW_SEMAPHORE_LIMIT = limit
    return _REVIEW_SEMAPHORE
