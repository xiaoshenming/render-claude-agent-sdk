from . import deterministic_guard as _guard

def parse_linear_grammar_batch18(prompt):
    parsed_batch17 = parse_linear_grammar_batch17(prompt)
    if parsed_batch17 is not None:
            return parsed_batch17
    match = (
            SIMPLE_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE.search(
                prompt
            )
        )
    if match:
            inner_offset = _parse_simple_number_value(match.group(3))
            if inner_offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(4))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            tail_offset = _parse_simple_number_value(match.group(7))
            if tail_offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(8))
            if right_value is None:
                return None
            adjusted = right_value - tail_offset if match.group(6) == "+" else right_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(2) == "+"
                else inner_value + inner_offset
            )
            return match.group(1), expected
    match = (
            REVERSED_TEX_PARENTHESIZED_TIMES_COEFFICIENT_FRACTION_AFFINE_EQUATION_RE.search(
                prompt
            )
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            inner_offset = _parse_simple_number_value(match.group(4))
            if inner_offset is None:
                return None
            coefficient = _parse_simple_number_value(match.group(5))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(6))
            if abs(denominator) <= 1e-9:
                return None
            tail_offset = _parse_simple_number_value(match.group(8))
            if tail_offset is None:
                return None
            adjusted = left_value - tail_offset if match.group(7) == "+" else left_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(3) == "+"
                else inner_value + inner_offset
            )
            return match.group(2), expected
    match = SIMPLE_TEX_COEFFICIENT_PARENTHESIZED_FRACTION_AFFINE_EQUATION_RE.search(
            prompt
        )
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            denominator = float(match.group(5))
            if abs(denominator) <= 1e-9:
                return None
            inner_offset = _parse_simple_number_value(match.group(4))
            if inner_offset is None:
                return None
            tail_offset = _parse_simple_number_value(match.group(7))
            if tail_offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(8))
            if right_value is None:
                return None
            adjusted = right_value - tail_offset if match.group(6) == "+" else right_value + tail_offset
            inner_value = adjusted * denominator / coefficient
            expected = (
                inner_value - inner_offset
                if match.group(3) == "+"
                else inner_value + inner_offset
            )
            return match.group(2), expected
    return None
