from . import deterministic_guard as _guard

def parse_linear_grammar_batch5(prompt):
    parsed_batch4 = parse_linear_grammar_batch4(prompt)
    if parsed_batch4 is not None:
            return parsed_batch4
    match = REVERSED_CONSTANT_FIRST_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE.search(
            prompt
        )
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            constant = _parse_simple_number_value(match.group(2))
            if constant is None:
                return None
            coefficient = _parse_simple_number_value(match.group(5))
            if coefficient is None:
                return None
            if match.group(3) == "-":
                coefficient *= -1
            if abs(coefficient) <= 1e-9:
                return None
            return match.group(4), (left_value - constant) / coefficient
    match = SIMPLE_VARIABLE_MULTIPLICATION_EQUATION_RE.search(prompt)
    if match:
            variable = match.group(1)
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(3))
            if right_value is None:
                return None
            return variable, right_value / coefficient
    match = SIMPLE_VARIABLE_MULTIPLICATION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            variable = match.group(1)
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            adjusted = right_value - offset if operator == "+" else right_value + offset
            return variable, adjusted / coefficient
    return None
