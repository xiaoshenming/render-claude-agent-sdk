from __future__ import annotations

import hashlib
import json
import re
from typing import Any


WHOLE_SCENE_REPAIR_STRATEGY = "whole_scene_rebuild"

_CODE_OBLIGATIONS: dict[str, dict[str, list[str]]] = {
    "missing_condition": {
        "required_objects": ["题目条件中的关键点、线、圆、角或函数关系必须在画面中出现"],
        "required_relations": ["画面对象必须满足原题条件，不能只展示结论"],
        "required_proof_steps": ["补齐缺失条件如何参与后续推导"],
    },
    "missing_subquestion": {
        "required_proof_steps": ["逐条覆盖原题每个小问，不得只回答其中一部分"],
        "required_final_display": ["总结页必须列出每个小问对应结论"],
    },
    "teaching_structure_gap": {
        "required_proof_steps": ["补齐从题设到结论的中间推导过程"],
        "required_final_display": ["结论必须带依据，不得只有口号式总结"],
    },
    "geometry_relation_error": {
        "required_objects": ["重建相关点、线、角、圆，使坐标和几何关系一致"],
        "required_relations": ["长度、角度、平行、垂直、相切、共圆等关系必须可由坐标验证"],
        "required_proof_steps": ["证明文字必须和重建后的几何事实一致"],
    },
    "condition_error": {
        "required_relations": ["代码中的数值、坐标、比例、时间或单位必须匹配题目条件"],
        "required_proof_steps": ["所有计算步骤必须使用修正后的条件"],
    },
    "formula_error": {
        "required_formula_display": ["关键公式必须用 MathTex 展示，且公式左右两边数学含义正确"],
        "required_proof_steps": ["公式推导不能跳步到错误结论"],
    },
    "final_answer_error": {
        "required_formula_display": ["最终答案必须以题目要求的形式展示"],
        "required_proof_steps": ["最终答案前必须有可检查的推导依据"],
    },
    "symbol_binding_error": {
        "required_objects": ["所有文字中提到的点、线、角、变量必须在代码中定义并显示"],
        "required_relations": ["符号引用必须和实际图形对象绑定一致"],
    },
    "reasoning_step_error": {
        "required_proof_steps": ["重写错误推理步骤，保证每一步由前一步推出"],
    },
    "cut_fill_shape_deformation": {
        "required_objects": ["割补前后图形必须保留面积/边长/角度关系"],
        "required_relations": ["拼接、旋转、平移后的图形关系必须数值一致"],
    },
}



def build_math_logic_scene_contract(
    *,
    scene_name: str,
    user_prompt: str = "",
    planning_scene: dict[str, Any] | None = None,
    quality_issues: list[dict[str, Any]] | None = None,
    no_progress: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a compact positive repair contract for a math-logic scene."""
    issue_codes = _issue_codes(quality_issues)
    obligations: dict[str, list[str]] = {
        "required_objects": [],
        "required_relations": [],
        "required_proof_steps": [],
        "required_formula_display": [],
        "required_final_display": [],
    }
    for code in issue_codes:
        for key, values in _CODE_OBLIGATIONS.get(code, {}).items():
            obligations.setdefault(key, []).extend(values)

    prompt_obligations = _obligations_from_prompt(user_prompt)
    for key, values in prompt_obligations.items():
        obligations.setdefault(key, []).extend(values)

    if planning_scene:
        title = str(planning_scene.get("title") or "").strip()
        purpose = str(planning_scene.get("purpose") or "").strip()
        math_content = str(planning_scene.get("math_content") or "").strip()
        if title or purpose or math_content:
            obligations.setdefault("required_proof_steps", []).append(
                "保持本场景规划目标: "
                + "；".join(part for part in (title, purpose, math_content) if part)
            )
        for key in (
            "required_objects",
            "required_relations",
            "required_proof_steps",
            "required_formula_display",
            "required_final_display",
        ):
            obligations.setdefault(key, []).extend(
                _coerce_text_list(planning_scene.get(key))
            )
        obligations.setdefault("required_proof_steps", []).extend(
            _subquestion_obligations(planning_scene.get("subquestions"))
        )
        obligations.setdefault("required_relations", []).extend(
            _symbol_binding_obligations(planning_scene.get("symbol_bindings"))
        )
        obligations.setdefault("required_formula_display", []).extend(
            _claim_obligations(planning_scene.get("formula_claims"))
        )
        obligations.setdefault("required_final_display", []).extend(
            _claim_obligations(planning_scene.get("final_answer_claims"))
        )

    issue_obligations = _obligations_from_issues(quality_issues)
    for key, values in issue_obligations.items():
        obligations.setdefault(key, []).extend(values)

    obligations = {
        key: _dedupe_compact(values)
        for key, values in obligations.items()
        if _dedupe_compact(values)
    }
    if not obligations:
        obligations = {
            "required_proof_steps": ["按原题逐步重建条件、推导和结论，避免只局部改一句话"]
        }
    contract_fields = _contract_fields_from_obligations(
        issue_codes=issue_codes,
        obligations=obligations,
        quality_issues=quality_issues,
    )

    repair_strategy = "targeted_patch"
    escalation: dict[str, Any] = {}
    if no_progress and no_progress.get("no_progress"):
        repair_strategy = WHOLE_SCENE_REPAIR_STRATEGY
        escalation = {
            "reason": "same_math_logic_signature_no_progress",
            "signature": no_progress.get("signature"),
            "hit_count": no_progress.get("hit_count"),
            "threshold": no_progress.get("threshold"),
        }

    return {
        "schema_version": "math_logic_scene_contract.v1",
        "scene_name": scene_name,
        "issue_codes": issue_codes,
        "repair_strategy": repair_strategy,
        "obligations": obligations,
        **contract_fields,
        "acceptance_criteria": [
            "复查不再返回 hard_error",
            "题设、图形、公式、推导、最终答案五者一致",
            "如果坐标/几何关系被改动，必须同步修改文字证明",
        ],
        "escalation": escalation,
    }
def build_math_logic_repair_obligations(
    *,
    scene_name: str,
    user_prompt: str = "",
    planning_scene: dict[str, Any] | None = None,
    decision: Any | None = None,
    quality_issues: list[dict[str, Any]] | None = None,
    no_progress: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    issue_payloads = _decision_issue_payloads(decision) or [
        dict(issue)
        for issue in quality_issues or []
        if isinstance(issue, dict)
    ]
    contract = build_math_logic_scene_contract(
        scene_name=scene_name,
        user_prompt=user_prompt,
        planning_scene=planning_scene,
        quality_issues=issue_payloads,
        no_progress=no_progress,
    )
    obligations = contract.get("obligations") or {}
    issue_codes = contract.get("issue_codes") or []
    primary_code = str(issue_codes[0] if issue_codes else "math_logic_scene_contract")
    required_visual_objects = _dedupe_compact(
        [
            *contract.get("required_visual_objects", []),
            *obligations.get("required_objects", []),
        ]
    )
    required_relations = _dedupe_compact(
        [
            *contract.get("required_relations", []),
            *obligations.get("required_relations", []),
        ]
    )
    verification_checklist = _dedupe_compact(
        [
            *contract.get("verification_checklist", []),
            *obligations.get("repair_checklist", []),
        ]
    )
    forbidden_scope = _dedupe_compact(list(contract.get("forbidden_scope") or []))
    required_terms = _dedupe_compact(
        [
            *obligations.get("required_objects", []),
            *required_visual_objects,
            *required_relations,
            *obligations.get("required_proof_steps", []),
            *obligations.get("required_formula_display", []),
            *obligations.get("required_final_display", []),
            *obligations.get("required_fix", []),
            *obligations.get("expected_math_statement", []),
            *verification_checklist,
        ]
    )
    forbidden_change_scope = (
        "；".join(forbidden_scope)
        or "不要只改文字或公式；如果诊断指向几何/条件错误，必须同步重建坐标、图形对象、标签和证明链。"
    )
    return [
        {
            "schema_version": "math_logic_repair_obligation.v1",
            "obligation_id": f"{primary_code}.scene_contract",
            "scene_name": scene_name,
            "issue_code": primary_code,
            "required_scene_scope": "target_scene",
            "required_terms": required_terms,
            "required_objects": list(obligations.get("required_objects") or []),
            "required_visual_objects": required_visual_objects,
            "required_relations": required_relations,
            "required_proof_steps": list(obligations.get("required_proof_steps") or []),
            "required_formula_display": list(
                obligations.get("required_formula_display") or []
            ),
            "required_final_display": list(
                obligations.get("required_final_display") or []
            ),
            "required_fix": list(obligations.get("required_fix") or []),
            "expected_math_statement": list(
                obligations.get("expected_math_statement") or []
            ),
            "repair_checklist": list(obligations.get("repair_checklist") or []),
            "forbidden_scope": forbidden_scope,
            "verification_checklist": verification_checklist,
            "forbidden_change_scope": forbidden_change_scope,
            "acceptance_criteria": list(contract.get("acceptance_criteria") or []),
            "repair_strategy": contract.get("repair_strategy"),
            "must_generate_if_missing": True,
        }
    ]
from . import repair_contract_part2 as _part2
from . import repair_contract_part3 as _part3
from . import repair_contract_part4 as _part4
globals().update({k: v for _module in (_part2, _part3, _part4) for k, v in vars(_module).items() if not k.startswith("__")})
