from __future__ import annotations

from dataclasses import replace

from .schemas import MathLogicDecision, MathLogicIssue


HARD_ERROR_TYPES = {
    "formula_error",
    "condition_error",
    "geometry_relation_error",
    "symbol_binding_error",
    "cut_fill_shape_deformation",
}

REPAIRABLE_CONTENT_ERROR_TYPES = {
    "missing_condition",
    "missing_subquestion",
    "final_answer_error",
    "reasoning_step_error",
    "teaching_structure_gap",
}

NON_BLOCKING_BUCKETS = {
    "teaching_approximation",
    "acceptable_simplification",
    "needs_visual_check",
    "record_only",
}


def is_block_eligible(issue: MathLogicIssue, block_confidence: float = 0.9) -> bool:
    return (
        is_hard_error(issue, block_confidence=block_confidence)
        and issue.severity == "high"
    )


def is_hard_error(issue: MathLogicIssue, block_confidence: float = 0.9) -> bool:
    return (
        issue.code in HARD_ERROR_TYPES
        and issue.hard_error
        and issue.confidence >= block_confidence
        and issue.policy_bucket == "hard_error"
        and not issue.needs_visual_check
    )


def repairable_hard_errors(
    issues: list[MathLogicIssue],
    *,
    block_confidence: float = 0.9,
) -> list[MathLogicIssue]:
    return [
        issue
        for issue in issues
        if is_repair_eligible_hard_error(
            issue, block_confidence=block_confidence)
        and issue.repairable
    ]


def is_repair_eligible_hard_error(
    issue: MathLogicIssue,
    *,
    block_confidence: float = 0.9,
) -> bool:
    if (
        not issue.hard_error
        or issue.confidence < block_confidence
        or issue.policy_bucket != "hard_error"
        or issue.needs_visual_check
    ):
        return False
    if issue.code in HARD_ERROR_TYPES:
        return issue.severity == "high"
    if issue.code in REPAIRABLE_CONTENT_ERROR_TYPES:
        return issue.severity in {"high", "medium"}
    return False


def ensure_repair_candidate_for_hard_errors(
    decision: MathLogicDecision,
    *,
    effective_mode: str | None = None,
    block_confidence: float = 0.9,
) -> MathLogicDecision:
    """Keep the repair gate deterministic when reviewer output is clearly fixable.

    The LLM reviewer supplies issue semantics.  This function only enforces the
    local policy contract: in repair mode, high-confidence hard errors marked
    repairable must enter the repair toolchain.
    """
    mode = (effective_mode or decision.mode or "shadow").strip().lower()
    if mode != "repair" or decision.needs_repair:
        return decision
    candidates = repairable_hard_errors(
        list(decision.issues or []),
        block_confidence=block_confidence,
    )
    if not candidates:
        return decision
    hard_error_count = max(
        int(decision.hard_error_count or 0),
        len([
            issue
            for issue in decision.issues
            if is_hard_error(issue, block_confidence=block_confidence)
            or is_repair_eligible_hard_error(
                issue, block_confidence=block_confidence)
        ]),
    )
    return replace(
        decision,
        mode=mode,
        final_action="repair_candidate",
        needs_repair=True,
        hard_error_count=hard_error_count,
    )


def apply_math_logic_policy(
    *,
    mode: str,
    scene_name: str,
    issues: list[MathLogicIssue],
    block_confidence: float = 0.9,
    latency_ms: int = 0,
    review_models: dict[str, str] | None = None,
    artifact_path: str | None = None,
    risk_assessment: dict | None = None,
) -> MathLogicDecision:
    normalized_mode = (mode or "shadow").strip().lower()
    hard_errors = [
        issue
        for issue in issues
        if is_hard_error(issue, block_confidence=block_confidence)
        or is_repair_eligible_hard_error(
            issue, block_confidence=block_confidence)
    ]
    block_eligible = [
        issue
        for issue in issues
        if is_block_eligible(issue, block_confidence=block_confidence)
    ]
    repairable = repairable_hard_errors(
        issues,
        block_confidence=block_confidence,
    )

    final_action = "record_only"
    if normalized_mode == "repair" and repairable:
        final_action = "repair_candidate"
    elif normalized_mode == "block" and block_eligible:
        final_action = "block_candidate"

    block_reason = None
    if final_action == "block_candidate":
        first = block_eligible[0]
        block_reason = f"{first.code}: {first.evidence[:180]}"

    needs_visual_check_count = sum(1 for issue in issues if issue.needs_visual_check)
    return MathLogicDecision(
        mode=normalized_mode,
        scene_name=scene_name,
        final_action=final_action,
        issues=issues,
        latency_ms=latency_ms,
        block_reason=block_reason,
        needs_repair=final_action == "repair_candidate",
        needs_visual_check=needs_visual_check_count > 0,
        hard_error_count=len(hard_errors),
        needs_visual_check_count=needs_visual_check_count,
        review_models=review_models or {},
        artifact_path=artifact_path,
        risk_assessment=risk_assessment or {},
    )
