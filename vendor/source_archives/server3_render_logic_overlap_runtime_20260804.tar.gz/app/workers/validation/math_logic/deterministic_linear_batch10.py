from . import deterministic_guard as _guard

def parse_linear_grammar_batch10(prompt):
    parsed_batch9 = parse_linear_grammar_batch9(prompt)
    if parsed_batch9 is not None:
            return parsed_batch9
    match = SIMPLE_IMPLICIT_PARENTHESIZED_AFFINE_EQUATION_RE.search(prompt)
    if match:
            coefficient = -1.0 if match.group(1) == "-" else 1.0
            variable = match.group(2)
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            inner_value = right_value / coefficient
            expected = inner_value - offset if operator == "+" else inner_value + offset
            return variable, expected
    match = REVERSED_IMPLICIT_PARENTHESIZED_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = -1.0 if match.group(2) == "-" else 1.0
            variable = match.group(3)
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            inner_value = left_value / coefficient
            expected = inner_value - offset if operator == "+" else inner_value + offset
            return variable, expected
    match = REVERSED_PARENTHESIZED_AFFINE_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            coefficient = _parse_simple_number_value(match.group(2))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            variable = match.group(3)
            operator = match.group(4)
            offset = _parse_simple_number_value(match.group(5))
            if offset is None:
                return None
            inner_value = left_value / coefficient
            expected = inner_value - offset if operator == "+" else inner_value + offset
            return variable, expected
    return None
