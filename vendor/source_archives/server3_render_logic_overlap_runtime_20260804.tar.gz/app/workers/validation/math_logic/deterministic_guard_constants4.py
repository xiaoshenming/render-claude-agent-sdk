import re

from .deterministic_guard_constants3 import SIMPLE_NUMBER_VALUE_PATTERN
from .deterministic_guard_constants3 import *  # noqa: F401,F403 - split constants share prior patterns
from .deterministic_guard_constants import (
    COEFFICIENT_VARIABLE_MULTIPLY_PATTERN,
    EQUATION_EQUALS_PATTERN,
)

SIMPLE_COEFFICIENT_VARIABLE_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

REVERSED_COEFFICIENT_VARIABLE_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}([a-zA-Z])\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

SIMPLE_COEFFICIENT_CONSTANT_FIRST_PARENTHESIZED_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*([a-zA-Z])\s*[)）]\s*"
    rf"[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

REVERSED_COEFFICIENT_CONSTANT_FIRST_PARENTHESIZED_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*([+-])\s*([a-zA-Z])\s*[)）]\s*"
    rf"[/÷]\s*([+-]?\d+(?:\.\d+)?)(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

SIMPLE_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

REVERSED_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

SIMPLE_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

REVERSED_PARENTHESIZED_TIMES_COEFFICIENT_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*{EXPLICIT_MULTIPLY_PATTERN}"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[/÷]\s*([+-]?\d+(?:\.\d+)?)"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

SIMPLE_COEFFICIENT_PARENTHESIZED_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

REVERSED_COEFFICIENT_PARENTHESIZED_DIVISION_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
    rf"(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

SIMPLE_COEFFICIENT_PARENTHESIZED_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)\s*(?:{EQUATION_EQUALS_PATTERN})\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

REVERSED_COEFFICIENT_PARENTHESIZED_DIVISION_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"{COEFFICIENT_VARIABLE_MULTIPLY_PATTERN}[(（]\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*[/÷]\s*"
    rf"([+-]?\d+(?:\.\d+)?)(?!\s*(?:[A-Za-z0-9]|[+\-*/÷×]))"
)

SIMPLE_PARENTHESIZED_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*[(（]\s*"
    rf"([a-zA-Z])\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_IMPLICIT_PARENTHESIZED_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([+-]?)\s*[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_IMPLICIT_PARENTHESIZED_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([+-]?)\s*"
    rf"[(（]\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]"
)

REVERSED_PARENTHESIZED_AFFINE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"[(（]\s*([a-zA-Z])\s*([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})\s*[)）]"
)

SIMPLE_SIGNED_VARIABLE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([+-])\s*([a-zA-Z])\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

SIMPLE_SIGNED_ADDITIVE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])([+-])\s*([a-zA-Z])\s*([+-])\s*"
    rf"({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)

REVERSED_SIGNED_VARIABLE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([+-])\s*([a-zA-Z])"
)

REVERSED_SIGNED_ADDITIVE_EQUATION_RE = re.compile(
    rf"(?<![A-Za-z0-9])({SIMPLE_NUMBER_VALUE_PATTERN})\s*"
    rf"(?:{EQUATION_EQUALS_PATTERN})\s*([+-])\s*([a-zA-Z])\s*"
    rf"([+-])\s*({SIMPLE_NUMBER_VALUE_PATTERN})"
)
