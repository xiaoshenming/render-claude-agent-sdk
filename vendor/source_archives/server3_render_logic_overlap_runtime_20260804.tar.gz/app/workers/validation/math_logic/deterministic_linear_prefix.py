from . import deterministic_guard as _guard
LINEAR_EQUATION_CONTEXT_RE = _guard.LINEAR_EQUATION_CONTEXT_RE
REVERSED_AFFINE_NUMERATOR_DIVISION_EQUATION_RE = _guard.REVERSED_AFFINE_NUMERATOR_DIVISION_EQUATION_RE
SIMPLE_AFFINE_NUMERATOR_DIVISION_EQUATION_RE = _guard.SIMPLE_AFFINE_NUMERATOR_DIVISION_EQUATION_RE
SIMPLE_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_RE = _guard.SIMPLE_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_RE
_parse_affine_equation_side = _guard._parse_affine_equation_side
_parse_simple_number_value = _guard._parse_simple_number_value

from . import deterministic_guard as _guard

def parse_linear_grammar_prefix(prompt):
    prompt = user_prompt or ""
    if not LINEAR_EQUATION_CONTEXT_RE.search(prompt):
            return None
    match = SIMPLE_AFFINE_NUMERATOR_DIVISION_EQUATION_RE.search(prompt)
    if match:
            side = _parse_affine_equation_side(match.group(1))
            if side is None:
                return None
            variable, coefficient, constant = side
            if abs(coefficient) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(2))
            if right_value is None:
                return None
            return variable, (right_value - constant) / coefficient
    match = REVERSED_AFFINE_NUMERATOR_DIVISION_EQUATION_RE.search(prompt)
    if match:
            left_value = _parse_simple_number_value(match.group(1))
            if left_value is None:
                return None
            side = _parse_affine_equation_side(match.group(2))
            if side is None:
                return None
            variable, coefficient, constant = side
            if abs(coefficient) <= 1e-9:
                return None
            return variable, (left_value - constant) / coefficient
    match = SIMPLE_TEX_AFFINE_NUMERATOR_FRACTION_EQUATION_RE.search(prompt)
    if match:
            side = _parse_affine_equation_side(match.group(1))
            if side is None:
                return None
            variable, coefficient, constant = side
            if abs(coefficient) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(2))
            if right_value is None:
                return None
            return variable, (right_value - constant) / coefficient
    return None
