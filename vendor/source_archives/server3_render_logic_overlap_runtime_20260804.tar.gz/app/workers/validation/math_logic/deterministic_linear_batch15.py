from . import deterministic_guard as _guard

def parse_linear_grammar_batch15(prompt):
    parsed_batch14 = parse_linear_grammar_batch14(prompt)
    if parsed_batch14 is not None:
            return parsed_batch14
    match = SIMPLE_AFFINE_EQUATION_RE.search(prompt)
    if match:
            coefficient = _parse_simple_number_value(match.group(1))
            if coefficient is None:
                return None
            if abs(coefficient) <= 1e-9:
                return None
            variable = match.group(2)
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            adjusted = right_value - offset if operator == "+" else right_value + offset
            return variable, adjusted / coefficient
    match = SIMPLE_DIVISION_EQUATION_RE.search(prompt)
    if match:
            variable = match.group(1)
            denominator = float(match.group(2))
            if abs(denominator) <= 1e-9:
                return None
            right_value = _parse_simple_number_value(match.group(3))
            if right_value is None:
                return None
            return variable, right_value * denominator
    match = SIMPLE_DIVISION_AFFINE_EQUATION_RE.search(prompt)
    if match:
            variable = match.group(1)
            denominator = float(match.group(2))
            if abs(denominator) <= 1e-9:
                return None
            operator = match.group(3)
            offset = _parse_simple_number_value(match.group(4))
            if offset is None:
                return None
            right_value = _parse_simple_number_value(match.group(5))
            if right_value is None:
                return None
            adjusted = right_value - offset if operator == "+" else right_value + offset
            return variable, adjusted * denominator
    return None
