"""公式操作数类型识别。"""

def is_ascii_operand(text: str, start: int, end: int) -> bool:
    return any(("A" <= ch <= "Z") or ("a" <= ch <= "z") or ("0" <= ch <= "9") for ch in text[start:end])

def is_symbolic_operand(text: str, start: int, end: int) -> bool:
    return any(("A" <= ch <= "Z") or ("a" <= ch <= "z") or ("0" <= ch <= "9") or ("\u0370" <= ch <= "\u03ff") or ch in "₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹²³¹√∞∑∠△" for ch in text[start:end])

def is_cjk_operand(text: str, start: int, end: int) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in text[start:end])

def is_operand_atom(ch: str, inner_chars: set[str]) -> bool:
    return bool(ch) and (ch in inner_chars or "\u4e00" <= ch <= "\u9fff")
