from __future__ import annotations

import ast

def compile_formula_text_boundaries(code: str) -> tuple[str, list[str]]:
    """Split high-confidence mixed prose/formula payloads into inline math calls.

    This compiler is deliberately narrow. Pure formula payloads remain owned by
    ``rewrite_formula_text_payloads_to_mathtex``; ambiguous mixed prose stays
    untouched so the static judge can still surface a violation.
    """
    from .formula_text_contract import (
        TEXT_PAYLOAD_HELPERS, _parent_map, _module_defines_inline_math_text,
        _call_can_use_self_inline_helper, _call_name, _first_text_payload,
        looks_like_formula_text, _is_pure_formula_payload, _inline_math_text_call_source,
        _node_span,
    )
    try:
        tree = ast.parse(code or "")
    except SyntaxError:
        return code, []

    parent_map = _parent_map(tree)
    has_inline_helper = _module_defines_inline_math_text(tree)
    lines = (code or "").splitlines(keepends=True)
    replacements: list[tuple[int, int, str, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node.func)
        if call_name.split(".")[-1] not in TEXT_PAYLOAD_HELPERS:
            continue
        if not _call_can_use_self_inline_helper(node, parent_map):
            continue
        payload = _first_text_payload(node)
        if payload is None or not looks_like_formula_text(payload):
            continue
        if _is_pure_formula_payload(payload):
            continue
        if len(node.args) > 1:
            continue
        replacement = _inline_math_text_call_source(
            code or "",
            node,
            payload,
            use_inline_helper=has_inline_helper,
        )
        if not replacement:
            continue
        start, end = _node_span(node, lines)
        if start is None or end is None:
            continue
        replacements.append(
            (
                start,
                end,
                replacement,
                f"formula_boundary_inline_math_text:L{getattr(node, 'lineno', 0) or 1}",
            )
        )

    if not replacements:
        return code, []

    fixed = code or ""
    fixes: list[str] = []
    for start, end, replacement, desc in sorted(replacements, reverse=True):
        fixed = fixed[:start] + replacement + fixed[end:]
        fixes.append(desc)
    fixes.reverse()
    return fixed, fixes

