"""Visible-string extraction from generated Python code."""
import ast
import logging

from .content_security_contracts import _StringFragment
from .content_security_normalization import (
 _dedupe_preserve_order, _docstring_value_node_ids, _extract_strings_with_regex,
 _is_reviewable_text, _merge_adjacent_cjk_fragments, _normalize_candidate,
)

logger=logging.getLogger(__name__)

def extract_visible_strings_from_code(code: str) -> str:
    """提取代码中用户可见或会朗读的字符串内容，用于输出内容安全检查。"""
    fragments = _extract_python_string_fragments(code)
    strings = _dedupe_preserve_order(
        [fragment.text for fragment in fragments if len(fragment.text) >= 2]
        + _merge_adjacent_cjk_fragments(fragments)
    )
    combined = "\n".join(strings)
    logger.info(
        f"[SECURITY] 提取到 {len(strings)} 个字符串，总长度={len(combined)}")
    return combined


def extract_strings_from_code(code: str) -> str:
    """兼容旧入口；输出端内容安全只审核用户可见/旁白文本。"""
    return extract_visible_strings_from_code(code)


def _extract_python_string_fragments(code: str) -> list[_StringFragment]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return _extract_strings_with_regex(code)

    ignored = _docstring_value_node_ids(tree)
    env = _collect_string_assignments(tree, ignored)
    fragments: list[_StringFragment] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        for text, source_node in _visible_texts_from_call(node, env, ignored):
            normalized = _normalize_candidate(text)
            if not _is_reviewable_text(normalized):
                continue
            fragments.append(_StringFragment(
                text=normalized,
                lineno=getattr(source_node, "lineno", getattr(node, "lineno", 0)) or 0,
                col_offset=getattr(source_node, "col_offset", getattr(node, "col_offset", 0)) or 0,
                end_lineno=(
                    getattr(
                        source_node,
                        "end_lineno",
                        getattr(source_node, "lineno", getattr(node, "lineno", 0)),
                    )
                    or 0
                ),
            ))
    return sorted(fragments, key=lambda item: (item.lineno, item.col_offset))


_VISIBLE_TEXT_CALLS = {
    "Text",
    "MarkupText",
    "Paragraph",
    "Tex",
    "MathTex",
    "safe_text_box",
    "safe_text",
    "create_text",
    "make_text",
    "get_title",
    "show_title",
    "add_title",
    "get_stem",
    "get_analysis_card",
    "add_voiceover_text",
    "create_subcaption",
}
_VOICEOVER_CALLS = {"voiceover"}


def _call_name(node: ast.Call) -> str:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _collect_string_assignments(
    tree: ast.AST,
    ignored: set[int],
) -> dict[str, str | list[str]]:
    env: dict[str, str | list[str]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            value = _resolve_text_expr(node.value, env, ignored)
            if value is None:
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    env[target.id] = value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            value = _resolve_text_expr(node.value, env, ignored)
            if value is not None:
                env[node.target.id] = value
    return env


def _resolve_text_expr(
    expr: ast.AST | None,
    env: dict[str, str | list[str]],
    ignored: set[int],
) -> str | list[str] | None:
    if expr is None or id(expr) in ignored:
        return None
    if isinstance(expr, ast.Constant) and isinstance(expr.value, str):
        return expr.value
    if isinstance(expr, ast.Name):
        return env.get(expr.id)
    if isinstance(expr, (ast.List, ast.Tuple)):
        items: list[str] = []
        for item in expr.elts:
            value = _resolve_text_expr(item, env, ignored)
            if isinstance(value, str):
                items.append(value)
        return items or None
    if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.Add):
        left = _resolve_text_expr(expr.left, env, ignored)
        right = _resolve_text_expr(expr.right, env, ignored)
        if isinstance(left, str) and isinstance(right, str):
            return left + right
    if isinstance(expr, ast.JoinedStr):
        parts: list[str] = []
        for value in expr.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
        return "".join(parts) if parts else None
    if isinstance(expr, ast.Call):
        func = expr.func
        if (
            isinstance(func, ast.Attribute)
            and func.attr == "join"
            and isinstance(func.value, ast.Constant)
            and isinstance(func.value.value, str)
            and expr.args
        ):
            value = _resolve_text_expr(expr.args[0], env, ignored)
            if isinstance(value, list):
                return func.value.value.join(value)
    return None


def _as_text_list(value: str | list[str] | None) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return value
    return []


def _visible_texts_from_call(
    node: ast.Call,
    env: dict[str, str | list[str]],
    ignored: set[int],
) -> list[tuple[str, ast.AST]]:
    name = _call_name(node)
    candidates: list[tuple[ast.AST, str | list[str] | None]] = []

    if name in _VOICEOVER_CALLS:
        for keyword in node.keywords:
            if keyword.arg == "text":
                candidates.append((keyword.value, _resolve_text_expr(keyword.value, env, ignored)))
        if not candidates and node.args:
            candidates.append((node.args[0], _resolve_text_expr(node.args[0], env, ignored)))
    elif name in _VISIBLE_TEXT_CALLS:
        if node.args:
            candidates.append((node.args[0], _resolve_text_expr(node.args[0], env, ignored)))
        for keyword in node.keywords:
            if keyword.arg in {"text", "content", "title", "key_point"}:
                candidates.append((keyword.value, _resolve_text_expr(keyword.value, env, ignored)))
    elif name == "create_options":
        for keyword in node.keywords:
            if keyword.arg == "options":
                candidates.append((keyword.value, _resolve_text_expr(keyword.value, env, ignored)))

    result: list[tuple[str, ast.AST]] = []
    for source_node, value in candidates:
        for item in _as_text_list(value):
            result.append((item, source_node))
    return result
