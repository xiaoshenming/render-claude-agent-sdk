import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _python_tuple_text_artifact_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Find Python tuple payloads that would be rendered as ordinary Text."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node.func)
        if call_name in {"Text", "MarkupText"} and _first_arg_is_tuple_text_literal(node):
            issues.append(
                GeneratedCodeQualityIssue(
                    code="tuple_text_literal_artifact",
                    severity="risk",
                    message=(
                        "Text/MarkupText 收到了 Python tuple literal 字符串，可能把 "
                        "('text', ...) 直接上屏；应交给 pre-render repair 归一化 "
                        "tuple payload。"
                    ),
                    line=getattr(node, "lineno", 1),
                    evidence=_call_evidence(source, node),
                    failure_code="tuple_text_literal_artifact",
                    risk_flags=("tuple_text_literal_artifact",),
                )
            )
            continue
        if call_name not in {"Text", "_build_text_mobject"}:
            continue
        line = getattr(node, "lineno", 1)
        if _first_arg_is_str_part(node) and _has_tuple_parts_contract_before(source, line):
            issues.append(
                GeneratedCodeQualityIssue(
                    code="python_tuple_text_artifact",
                    severity="risk",
                    message=(
                        "tuple part 通过 str(part) 进入 Text 文本路径，可能把 Python tuple "
                        "文本显示到画面；应交给 pre-render repair 拆成普通文本/MathTex，"
                        "而不是重新生成整段代码。"
                    ),
                    line=line,
                    evidence=_call_evidence(source, node),
                    failure_code="python_tuple_text_artifact",
                    risk_flags=("python_tuple_text_artifact",),
                )
            )
    return issues


def _first_arg_is_tuple_text_literal(node: ast.Call) -> bool:
    if not node.args:
        return False
    arg = node.args[0]
    return (
        isinstance(arg, ast.Constant)
        and isinstance(arg.value, str)
        and bool(_TUPLE_TEXT_LITERAL_RE.match(arg.value.strip()))
    )


def _first_arg_is_str_part(node: ast.Call) -> bool:
    if not node.args:
        return False
    arg = node.args[0]
    return (
        isinstance(arg, ast.Call)
        and _call_name(arg.func) == "str"
        and len(arg.args) == 1
        and isinstance(arg.args[0], ast.Name)
        and arg.args[0].id == "part"
    )


def _has_tuple_parts_contract_before(source: str, line: int) -> bool:
    prefix = "\n".join(source.splitlines()[: max(line - 1, 0)])
    if re.search(r"\bdef\s+\w*inline_math_text\s*\([^)]*\*parts\b", prefix):
        return True
    has_part_loop = re.search(r"\bfor\s+part\s+in\s+parts\s*:", prefix)
    has_tuple_guard = re.search(
        r"\bisinstance\s*\(\s*part\s*,\s*(?:tuple|\(\s*tuple\s*,\s*list\s*\))",
        prefix,
    )
    if has_part_loop and has_tuple_guard:
        return True
    return bool(re.search(r"\(\s*['\"](?:text|math)['\"]\s*,", prefix))


def _call_evidence(source: str, node: ast.AST, *, limit: int = 180) -> str:
    segment = ast.get_source_segment(source, node) or ""
    return " ".join(segment.strip().split())[:limit]


def _missing_voiceover_scene_import_line(
    source: str,
    *,
    enable_tts: bool | None,
) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    voiceover_defined = False
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ImportFrom) and node.module == "manim_voiceover":
            for alias in node.names:
                if alias.name == "*" or (
                    alias.name == "VoiceoverScene"
                    and alias.asname in {None, "VoiceoverScene"}
                ):
                    voiceover_defined = True
                    break
        elif isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == "VoiceoverScene":
                voiceover_defined = True
            if isinstance(node, ast.ClassDef) and _class_inherits_voiceover_scene(node):
                if not voiceover_defined:
                    return getattr(node, "lineno", 0)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(target, ast.Name) and target.id == "VoiceoverScene" for target in targets):
                voiceover_defined = True
    if (
        not voiceover_defined
        and (enable_tts or "self.voiceover(" in source)
        and _is_portrait_source(source)
    ):
        return _line_matching(source, r"\bself\.voiceover\s*\(") or 1
    return 0


def _missing_required_voiceover_block_line(
    source: str,
    *,
    enable_tts: bool | None,
) -> int:
    if not enable_tts:
        return 0
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    for node in ast.walk(tree):
        if isinstance(node, ast.With):
            for item in node.items:
                context_expr = item.context_expr
                if (
                    _is_self_voiceover_call(context_expr)
                    or _is_self_short_voiceover_call(context_expr)
                ):
                    return 0
    return _first_scene_construct_line(source) or 1


def _is_self_short_voiceover_call(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "short_voiceover"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _first_scene_construct_line(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "construct":
            return getattr(node, "lineno", 0) or 0
    return 0


def _class_inherits_voiceover_scene(node: ast.ClassDef) -> bool:
    return any(_base_name(base) == "VoiceoverScene" for base in node.bases)


def _is_portrait_source(source: str) -> bool:
    return bool(
        "portrait_" in source
        or re.search(r"\bconfig\.frame_height\s*=\s*1[34](?:\.\d+)?\b", source)
        or re.search(r"\bconfig\.pixel_height\s*=\s*1920\b", source)
        or re.search(r"\baspect_ratio\s*=\s*[\"']9:16[\"']", source)
    )


def _portrait_header_overlap_line(source: str) -> int:
    if not _is_portrait_source(source):
        return 0
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    for block, line_offset in blocks:
        line = _portrait_header_overlap_line_in_block(block, line_offset)
        if line:
            return line
    return 0


def _portrait_header_overlap_line_in_block(source: str, line_offset: int) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    header_vars = {
        var
        for var in _assigned_text_vars(source)
        if _PORTRAIT_HEADER_VAR_RE.search(var)
    }
    if len(header_vars) < 2:
        return 0

    top_edge_lines: list[int] = []
    y_band_lines: dict[str, list[int]] = {}
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id in header_vars
        ):
            continue
        method = node.func.attr
        line_no = line_offset + getattr(node, "lineno", 0)
        if method == "to_edge" and _call_uses_up_direction(node):
            buff = _call_keyword_number(node, "buff")
            if buff is None or buff <= 0.35:
                top_edge_lines.append(line_no)
        elif method == "move_to" and node.args:
            y_key = _portrait_header_y_key(node.args[0])
            if y_key:
                y_band_lines.setdefault(y_key, []).append(line_no)

    top_edge_lines.sort()
    if len(top_edge_lines) >= 2:
        return top_edge_lines[1]
    for lines in y_band_lines.values():
        if len(lines) >= 2:
            return sorted(lines)[1]
    return 0


