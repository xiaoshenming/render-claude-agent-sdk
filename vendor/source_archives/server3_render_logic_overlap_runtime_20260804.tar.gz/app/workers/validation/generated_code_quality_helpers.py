"""Static quality checks for generated Manim code.

These checks catch prompt-contract violations that are visible in code before
rendering. They are deliberately conservative and complement, not replace, the
frame-based layout validator.
"""
from dataclasses import dataclass
import ast
from collections.abc import Iterable
import math
import re
import textwrap

from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue
from app.workers.validation.generated_code_quality_entry import blocking_static_contract_codes
from app.workers.validation.generated_code_quality_misc import *
from app.workers.validation.generated_code_quality_pythagorean_semantic import (_pythagorean_three_square_semantic_issues, _pythagorean_three_square_semantic_issues_in_block)

def _prepare_generated_code_quality(source: str, *, allowed_runtime_helpers=None):
    """Run input-contract checks and return issues plus parsed text metadata."""
    issues = []
    if not source.strip():
        return [GeneratedCodeQualityIssue(code="empty_generated_code", severity="error", message="生成代码为空，无法渲染或进行视觉质量检查。", line=1, evidence="<empty>")], {}, set()
    try:
        from app.workers.repair.runtime_contract import scan_runtime_contract_violations
        for violation in scan_runtime_contract_violations(source, allowed_runtime_helpers=allowed_runtime_helpers):
            if str(violation.get("kind") or "") == "syntax_error":
                continue
            helper = str(violation.get("helper") or "").strip()
            receiver = str(violation.get("receiver") or "").strip()
            issues.append(GeneratedCodeQualityIssue(code="invented_helper_call", severity="error", message=str(violation.get("message") or "生成代码调用了未在运行时合同中定义的 helper"), line=int(violation.get("line") or 1), evidence=f"{receiver}.{helper}" if receiver and helper else helper, failure_code="invented_helper_call"))
    except Exception:
        pass
    text_assignments = _assigned_text_assignments(source)
    text_vars = {var: line for var, (line, _pos) in text_assignments.items()}
    registered = _registered_3d_text_var_positions(source)
    if re.match(r"\s*```(?:python)?\b", source):
        issues.append(GeneratedCodeQualityIssue(code="markdown_code_fence", severity="error", message="生成代码包含 Markdown 代码围栏，无法直接作为 Python 执行。", line=1, evidence="```python"))
    raw_asset_match = _RAW_SVG_OR_IMAGE_RE.search(source)
    if raw_asset_match:
        issues.append(GeneratedCodeQualityIssue(code="raw_svgmobject_path", severity="error", message="Generated code must use self.asset_icon/icon_card/icon_row instead of raw SVGMobject/ImageMobject paths.", line=_line_no(source, raw_asset_match.start()), evidence=raw_asset_match.group(0)))
    helper_definition_match = _ICON_HELPER_DEFINITION_RE.search(source)
    if helper_definition_match and not all(marker in source for marker in _OFFICIAL_ICON_HELPER_MARKERS):
        issues.append(GeneratedCodeQualityIssue(code="icon_asset_helper_redefined", severity="error", message="Generated code must call project BaseConfigScene asset_icon/icon_card/icon_row helpers instead of redefining icon helpers.", line=_line_no(source, helper_definition_match.start()), evidence=helper_definition_match.group(0).strip()))
    return issues, text_vars, registered
from app.workers.validation.generated_code_quality_right_triangle import (
    _right_triangle_side_label_anchor_line, _right_triangle_side_label_anchor_line_in_block,
    _right_triangle_side_label_anchor_line_regex, _ambiguous_right_angle_helper_line,
    _right_triangle_numeric_side_label_mismatch_issues, _right_triangle_numeric_side_label_mismatch_issues_in_block,
)
from app.workers.validation.generated_code_quality_reveal import (
    _bulk_pre_reveal_add_line, _bulk_pre_reveal_add_line_in_block,
    _pre_reveal_visible_object_line, _pre_reveal_visible_object_line_in_block,
    _is_self_visible_registration_call, _direct_name_args, _reveal_targets_in_play_call,
)
from app.workers.validation.generated_code_quality_layout import (
    _next_to_alignment_misuse_line, _parametric_surface_misuse_line,
    _text_formula_tiny_scale_line, _first_numeric_arg, _is_pure_text_split_layout,
)
from app.workers.validation.generated_code_quality_3d_camera import (
    _fix_in_frame_method_misuse_line, _mathpi_3d_camera_animate_misuse_line,
    _mathpi_3d_camera_frame_misuse_line, _mathpi_3d_camera_set_euler_misuse_line,
    _prism_polygon_extrusion_misuse_line,
)
from app.workers.validation.generated_code_quality_ranges import _class_range, _method_range, _is_front_facing_3d_camera_line
from app.workers.validation.generated_code_quality_3d_contract import (
    _should_check_3d_text, _mathpi_3d_scene_contract_missing_line,
    _mathpi_3d_camera_contract_missing_line, _mathpi_3d_default_camera_oblique_line,
)
from app.workers.validation.generated_code_quality_registry import (
    _assigned_text_assignments, _registered_3d_text_var_positions, _record_earliest_pos,
    _expand_group_members, _vgroup_members,
)
from app.workers.validation.generated_code_quality_config import (
    _undefined_global_config_attribute, _undersized_2d_axes_line, _call_name,
    _literal_number, _global_config_defined_attrs, _global_config_body,
)
from app.workers.validation.generated_code_quality_clear_screen import (
    _clear_screen_flicker_issue, _clear_screen_issue_at, _is_self_method_call,
    _fadeout_target_names, _fadein_target_names, _animation_target_names,
    _is_clear_screen_target, _is_definitely_whole_scene_target, _full_screen_overlay_vars,
)
from app.workers.validation.generated_code_quality_tracker import (
    _is_tracker_method_call, _is_full_timeline_helper_call, _is_empty_full_timeline_helper_call,
    _is_empty_sequence_literal, _call_uses_tracker_duration_as_run_time, _is_self_wait_like_call,
    _is_self_raw_play_call, _numeric_self_wait_seconds, _call_waits_for_tracker_remainder,
    _call_waits_for_full_tracker_duration, _is_full_tracker_duration_wait_arg,
    _contains_tracker_duration_subtraction, _contains_tracker_duration, _is_tracker_duration_attr,
)
from app.workers.validation.generated_code_quality_portrait_helpers import (
    _call_keyword_number, _portrait_header_y_key, _portrait_multi_concept_crowding_line,
    _portrait_concept_tokens, _portrait_multi_concept_terminal_line,
)
from app.workers.validation.generated_code_quality_voice_extract import _voiceover_call_text
from app.workers.validation.generated_code_quality_timing import (
    _formula_passed_to_show_text_line, _legacy_text_slot_api_line,
    _voiceover_timing_contract_issues,
)
from app.workers.validation.generated_code_quality_visibility import (
    _place_non_overlapping_without_others_line, _is_none_or_empty_sequence,
    _text_added_without_visible_registry_line, _dense_direct_positioning_without_registry_line,
    _dense_direct_positioning_without_registry_line_in_block, _has_visible_object_registry_lifecycle,
    _text_added_without_visible_registry_line_in_block, _text_visibility_delta_for_scene_call,
    _text_targets_in_nodes, _text_targets_in_node, _is_text_constructor_or_safe_text_call,
)
from app.workers.validation.generated_code_quality_geometry_state import (
    _stale_geometry_points_after_transform_line_in_block, _record_transformed_sources,
    _visual_geometry_source_names, _expr_has_geometry_transform_call, _geometry_transform_target_var,
    _raw_geometry_point_source_names, _subscript_base_name, _is_raw_geometry_points_name,
    _is_label_or_angle_position_call,
)
from app.workers.validation.generated_code_quality_voice import (
    _python_tuple_text_artifact_issues, _first_arg_is_tuple_text_literal,
    _first_arg_is_str_part, _has_tuple_parts_contract_before, _call_evidence,
    _missing_voiceover_scene_import_line, _missing_required_voiceover_block_line,
    _is_self_short_voiceover_call, _first_scene_construct_line, _class_inherits_voiceover_scene,
    _is_portrait_source, _portrait_header_overlap_line, _portrait_header_overlap_line_in_block,
)
from app.workers.validation.generated_code_quality_actions import (
    raise_for_tts_timing_blockers, try_auto_fix_formula_violations,
    try_auto_fix_icon_text_box_fallbacks, raise_for_blocking_static_contracts,
    raise_for_blocking_static_contracts_with_auto_fix,
)
from app.workers.validation.generated_code_quality_triangle import _literal_triangle_vertices, _eval_vector_expr, _literal_vertices_form_right_triangle, _numeric_midpoint_side_labels
from app.workers.validation.generated_code_quality_pythagorean import (
    _has_pythagorean_three_square_context, _uses_trusted_pythagorean_square_helper,
    _pythagorean_block_mentions_square_visual, _pythagorean_block_has_valid_three_square_visual,
    _pythagorean_area_symbols, _pythagorean_square_records, _pythagorean_square_assignment_kind,
    _pythagorean_square_label_from_name, _detached_pythagorean_square_evidence,
    _pythagorean_square_anchor_mentions_edge, _pythagorean_square_label_center_issues,
    _pythagorean_area_label_from_assignment, _pythagorean_single_area_label,
    _assignment_moves_label_to_square_center,
)
from app.workers.validation.generated_code_quality_circle import (
    _circle_area_base_width_mismatch_line, _circle_area_annularsector_misuse_line,
    _format_float, _is_side_label_var, _is_single_vertex_direction_offset,
)
from app.workers.validation.generated_code_quality_geometry_math import (
    _single_target_assignment_for_value, _numeric_text_value_from_expr,
    _parse_numeric_side_label, _midpoint_vertex_pair, _vertex_sum_pair, _vertex_name,
    _side_label_scale_mismatch, _side_key, _distance, _vector_sub, _vector_dot,
    _vector_length,
)
from app.workers.validation.generated_code_quality_formula_utils import (
    _formula_move_to_assignments, _formula_move_to_assignments_regex,
    _call_chain_root_name, _normalize_expr, _formula_transition_segment,
    _formula_replaced_or_removed, _scene_blocks, _is_reassigned_before_direct_show,
    _direct_show_pos, _first_line, _line_matching, _line_no, _line_text,
)
from app.workers.validation.generated_code_quality_state_utils import (
    _prehidden_text_vars, _assigned_visual_vars, _prehidden_opacity_line,
    _prehidden_opacity_line_in_block, _is_rehydration_add, _construct_blocks,
    _same_center_formula_stack_line, _same_center_formula_stack_line_in_block,
)
from app.workers.validation.generated_code_quality_portrait import (
    _portrait_tiny_font_size_issues, _plain_text_prime_label_issues,
)
from app.workers.validation.generated_code_quality_icons import (
    _core_visual_semantic_icon_fallback_issues, _text_box_icon_fallback_issues,
    _core_text_helper_fallback_icon_issues, _forbidden_visible_fallback_icon_issues,
)
from app.workers.validation.generated_code_quality_theme import (
    _durable_panel_manual_coordinate_issues, _theme_semantic_token_override_issues,
)
from app.workers.validation.generated_code_quality_geometry import _geometry_dict_key_not_local_issues
from app.workers.validation.generated_code_quality_static import (
    _invented_helper_call_issues,
    _module_defined_or_imported_names,
    _helper_abi_mismatch_issues,
)
from app.workers.validation.generated_code_quality_manim_api import _manim_019_api_blacklist_issues, _append_manim_019_issue

from app.workers.validation.formula_text_contract import (
    inspect_formula_text_violations,
)


def _append_icon_quality_issues(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    for checker in (
        _core_visual_semantic_icon_fallback_issues,
        _text_box_icon_fallback_issues,
        _core_text_helper_fallback_icon_issues,
        _forbidden_visible_fallback_icon_issues,
    ):
        issues.extend(checker(source))
def _append_formula_show_issue(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    line = _formula_passed_to_show_text_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(
            code="formula_passed_to_show_text", severity="error",
            message="纯公式被传给 show_text/restore_text，容易按普通文本显示或触发 LaTeX 文本路径问题。",
            line=line, evidence='show_text(r"$$...$$")',
        ))
def _append_default_color_issue(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    line = _default_manim_color_constant_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(
            code="default_manim_color_constant", severity="risk",
            message="颜色 keyword 使用 Manim 默认色常量，可能绕过 GlobalConfig 配色与背景对比合同。",
            line=line, evidence="color=BLUE/GOLD/RED_C...",
        ))
def _append_gtts_voice_issue(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    line = _gtts_voiceover_provider_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(
            code="unsupported_gtts_voiceover_provider", severity="error",
            message="生成代码导入或实例化了 gTTS demo provider，应使用项目内置 TTS 服务合同。",
            line=line, evidence="manim_voiceover.services.gtts.GTTSService",
        ))
def _append_stale_geometry_issue(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    line = _stale_geometry_points_after_transform_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(
            code="stale_geometry_points_after_transform", severity="risk",
            message="图形或 VGroup 已整体变换后，标签/角标仍使用原始 points/vertices 坐标，容易跟主体图形漂移。",
            line=line, evidence="points[...] or vertices[...] after shift/scale/move_to",
        ))
def _append_registry_quality_issues(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    checks = (
        (_place_non_overlapping_without_others_line, "place_non_overlapping_without_others", "risk"),
        (_text_added_without_visible_registry_line, "text_added_without_visible_registry", "risk"),
    )
    for checker, code, severity in checks:
        line = checker(source)
        if line:
            issues.append(GeneratedCodeQualityIssue(code=code, severity=severity, message="可见对象 registry 缺失或未传入，后续避让和修复缺少上下文。", line=line, evidence="visible_objects registry"))
def _append_dense_and_3d_issues(source: str, issues: list[GeneratedCodeQualityIssue], *, is_3d: bool | None, text_vars: dict[str, int], registered_3d_text_var_positions: dict[str, int], text_assignments: dict[str, tuple[int, int]]) -> None:
    line = _dense_direct_positioning_without_registry_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(code="dense_direct_positioning_without_registry", severity="risk", message="同一 Scene 密集使用 move_to/next_to/arrange 等直接定位，但未维护 visible_objects 或等价 registry，点标/公式/说明容易互相遮挡。", line=line, evidence="many move_to/next_to calls without visible_objects registry"))
    if _should_check_3d_text(source, is_3d):
        for var, line_no in text_vars.items():
            show_pos = _direct_show_pos(source, var)
            if show_pos < 0 or (registered_3d_text_var_positions.get(var) is not None and registered_3d_text_var_positions[var] < show_pos) or _is_reassigned_before_direct_show(source, var, text_assignments[var][1]):
                continue
            issues.append(GeneratedCodeQualityIssue(code="unregistered_3d_text", severity="error", message="3D Text/MathTex 展示前未注册 fixed frame/orientation，可能侧面不可见。", line=line_no, evidence=var))
def _append_portrait_layout_issues(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    for checker, code, message in (
        (_portrait_header_overlap_line, "portrait_header_overlap", "竖屏标题/副标题没有分层 clearance，容易在顶部安全区互相压住。"),
        (_portrait_multi_concept_crowding_line, "portrait_multi_concept_crowding", "竖屏单个终态同时展示多个完整判定/证明板，密度过高。"),
    ):
        line = checker(source)
        if line:
            issues.append(GeneratedCodeQualityIssue(code=code, severity="error", message=message, line=line, evidence="portrait layout contract"))
def _append_geometry_sequence_issues(source: str, issues: list[GeneratedCodeQualityIssue]) -> None:
    for checker, code, severity, message in (
        (_prehidden_opacity_line, "prehidden_opacity_reveal", "error", "首个动画前用 set_opacity(0) 预藏文字/标签，违反逐步揭示合同。"),
        (_same_center_formula_stack_line, "same_center_formula_stack", "risk", "多条公式使用同一 center 依次出现，且缺少 FadeOut/ReplacementTransform。"),
    ):
        line = checker(source)
        if line:
            issues.append(GeneratedCodeQualityIssue(code=code, severity=severity, message=message, line=line, evidence="geometry sequence contract"))
def _append_circle_prism_issues(source, issues):
        if circle_base_line:
            issues.append(
                GeneratedCodeQualityIssue(
                    code="circle_area_base_width_mismatch",
                    severity="error",
                    message=(
                        "圆面积扇形交错拼接把 half_chord 当成完整扇形宽度，"
                        "底边长度与 πr 标注不一致。"
                    ),
                    line=circle_base_line,
                    evidence=(
                        "if w = r*sin(angle/2), use sector_width=2*w and "
                        "base≈(num_sectors/2)*sector_width, not 15*w/7.5*w"
                    ),
                )
            )
    
        circle_annular_line = _circle_area_annularsector_misuse_line(source)
        if circle_annular_line:
            issues.append(
                GeneratedCodeQualityIssue(
                    code="circle_area_annularsector_misuse",
                    severity="error",
                    message=(
                        "圆面积分割重排必须保留原圆扇形；AnnularSector 会变成环形带，"
                        "不等价于圆盘等分扇形。"
                    ),
                    line=circle_annular_line,
                    evidence="use Sector or an equivalent 3D sector prism, not AnnularSector",
                )
            )
    
        prism_misuse_line = _prism_polygon_extrusion_misuse_line(source)
        if prism_misuse_line:
            issues.append(
                GeneratedCodeQualityIssue(
                    code="manim_prism_polygon_extrusion_misuse",
                    severity="error",
                    message=(
                        "Manim Prism 不能用 Prism(poly, depth=...) 挤出 Polygon；"
                        "会在渲染时报 Mobject/Prism 参数错误。"
                    ),
                    line=prism_misuse_line,
                    evidence="build top/bottom Polygon faces + side faces as VGroup, or use Prism(dimensions=[...])",
                )
            )
