"""Shared AST checks for formula-like payloads in plain text helpers."""

from __future__ import annotations

import ast

from app.workers.validation.formula_text_constants import *
from app.workers.validation.formula_text_ast_utils import (
    _parent_map, _call_can_use_self_inline_helper, _module_defines_inline_math_text,
    _node_span, _byte_col_to_char_col, _stringish_constant, _call_name,
)
from app.workers.validation.formula_text_boundary_checks import (
    dollar_formula_boundary_segments,
    split_leading_cjk_prose_from_latex_math, trim_inline_math_span, strip_unanchored_cjk,
)
from app.workers.validation.formula_text_normalization import normalize_formula_text_payload
from app.workers.validation.formula_text_operand_checks import (
    is_ascii_operand, is_symbolic_operand, is_cjk_operand, is_operand_atom,
)
from app.workers.validation.formula_text_operand_constants import (
    _FORMULA_OPERAND_CHARS, _FORMULA_COMPARATOR, _COMPARATOR_RE,
    _OPERAND_INNER_CHARS, _LATEX_COMMAND_RE,
)
from app.workers.validation.formula_text_operand_expansion import (
    expand_left,
    expand_right,
)
from app.workers.validation.formula_text_ast_helpers import safe_unparse, is_str_call, expr_names, payload_is_indexed_value, call_uses_formula_color, dynamic_expression_source, first_text_payload, first_text_payload_node, looks_like_dynamic_formula_payload, first_dynamic_formula_payload
from app.workers.validation.formula_text_cjk_checks import is_cjk_symbolic_formula, is_pure_formula_payload
from app.workers.validation.formula_text_mathtex_helpers import mathtex_call_source, dynamic_mathtex_call_source, inline_vgroup_call_source, inline_math_text_call_source
from app.workers.validation.formula_text_payload_helpers import (
    expression_names as _expr_names,
    first_payload as _first_text_payload,
    first_payload_node as _first_text_payload_node,
    is_indexed_payload as _payload_is_indexed_value,
)
from app.workers.validation.formula_text_latex_spans import collect_latex_command_spans
from app.workers.validation.formula_text_patterns import formula_match_patterns
from dataclasses import dataclass
import re





def _high_confidence_formula_boundary_segments(text: str) -> list[tuple[str, str]]:
    compact = _normalize_formula_text_payload(str(text or ""))
    dollar_segments = _dollar_formula_boundary_segments(compact)
    if dollar_segments:
        return dollar_segments
    matches = _collect_high_confidence_formula_matches(compact)
    if not matches:
        return []

    segments: list[tuple[str, str]] = []
    cursor = 0
    for start, end in matches:
        prose = compact[cursor:start].strip()
        if prose:
            segments.append(("text", prose))
        raw_match = compact[start:end].strip()
        split_match = _split_leading_cjk_prose_from_latex_math(raw_match)
        if split_match:
            segments.extend(split_match)
        else:
            math = _normalize_inline_math_segment(raw_match)
            if not math:
                return []
            segments.append(("math", math))
        cursor = end
    tail = compact[cursor:].strip()
    if tail:
        segments.append(("text", tail))
    if not segments:
        return []
    return segments

def _dollar_formula_boundary_segments(text: str) -> list[tuple[str, str]]:
    return dollar_formula_boundary_segments(text, _normalize_inline_math_segment)

def _split_leading_cjk_prose_from_latex_math(
    value: str,
) -> list[tuple[str, str]]:
    """Keep Chinese narration outside MathTex when a match swallowed a whole sentence."""
    return split_leading_cjk_prose_from_latex_math(
        value, _normalize_inline_math_segment, FORMULA_TEXT_LATEX_TOKENS
    )

def _normalize_formula_text_payload(text: str) -> str:
    return normalize_formula_text_payload(text)

def _expand_left(text: str, index: int) -> int:
    return expand_left(text, index, _OPERAND_INNER_CHARS)

def _expand_right(text: str, index: int) -> int:
    return expand_right(text, index, _OPERAND_INNER_CHARS, _LATEX_COMMAND_RE)

def _is_ascii_operand(text: str, start: int, end: int) -> bool:
    return is_ascii_operand(text, start, end)

def _is_symbolic_operand(text: str, start: int, end: int) -> bool:
    return is_symbolic_operand(text, start, end)

def _is_cjk_operand(text: str, start: int, end: int) -> bool:
    return is_cjk_operand(text, start, end)

def _collect_chain_spans(text: str) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    used_intervals: list[tuple[int, int]] = []
    for match in _COMPARATOR_RE.finditer(text):
        comp_start, comp_end = match.span()
        if any(start <= comp_start < end for start, end in used_intervals):
            continue
        left_end = comp_start
        while left_end > 0 and text[left_end - 1] == " ":
            left_end -= 1
        left_start = _expand_left(text, left_end)
        right_start = comp_end
        while right_start < len(text) and text[right_start] == " ":
            right_start += 1
        right_end = _expand_right(text, right_start)
        if right_end <= right_start:
            continue
        comparator_count = 1
        has_left_operand = left_start < left_end
        if not has_left_operand:
            if comp_start > 0:
                prev = text[comp_start - 1]
                if prev not in {" ", "\t", "\u3000"}:
                    continue
            if not (
                _is_symbolic_operand(text, right_start, right_end)
                or text[right_start:right_end].lstrip().startswith("\\")
            ):
                continue
            left_start = comp_start
        elif not (
            _is_symbolic_operand(text, left_start, left_end)
            or _is_symbolic_operand(text, right_start, right_end)
        ):
            # Pure CJK pair on first comparator: defer the chain-length check
            # until we know how many comparators tie it together.
            pass
        end = right_end
        while True:
            cursor = end
            while cursor < len(text) and text[cursor] == " ":
                cursor += 1
            chain_match = _COMPARATOR_RE.match(text, cursor)
            if not chain_match:
                break
            chain_end_pos = chain_match.end()
            ahead = chain_end_pos
            while ahead < len(text) and text[ahead] == " ":
                ahead += 1
            extended = _expand_right(text, ahead)
            if extended <= ahead:
                break
            comparator_count += 1
            end = extended
        # Reject a stray inequality between two CJK fragments unless the
        # chain links 3 or more operands or carries an explicit LaTeX
        # comparator.
        if (
            has_left_operand
            and not _is_symbolic_operand(text, left_start, end)
            and not text[comp_start:comp_end].startswith("\\")
            and comparator_count < 2
        ):
            continue
        if has_left_operand:
            left_start, end = _strip_unanchored_cjk(
                text, left_start, end, comp_start, comp_end
            )
        if left_start >= end:
            continue
        spans.append((left_start, end))
        used_intervals.append((left_start, end))
    spans.sort()
    deduped: list[tuple[int, int]] = []
    for start, end in spans:
        if deduped and start < deduped[-1][1]:
            continue
        deduped.append((start, end))
    return deduped

def _strip_unanchored_cjk(
    text: str,
    start: int,
    end: int,
    comp_start: int,
    comp_end: int,
) -> tuple[int, int]:
    """Remove CJK prefixes/suffixes when an ASCII anchor exists in the chain."""

    return strip_unanchored_cjk(text, start, end, comp_start, comp_end, _is_symbolic_operand)

def _collect_high_confidence_formula_matches(text: str) -> list[tuple[int, int]]:
    """Return non-overlapping (start, end) spans for inline math segments."""

    raw_spans: list[tuple[int, int]] = list(_collect_chain_spans(text))
    raw_spans.extend(_collect_latex_command_spans(text))
    for pattern in _formula_match_patterns():
        for match in pattern.finditer(text):
            start, end = match.span()
            if start == end:
                continue
            raw_spans.append((start, end))
    if not raw_spans:
        return []
    trimmed: list[tuple[int, int]] = []
    for start, end in raw_spans:
        adjusted = _trim_inline_math_span(text, start, end)
        if adjusted is None:
            continue
        trimmed.append(adjusted)
    if not trimmed:
        return []
    trimmed.sort(key=lambda span: (span[0], -(span[1] - span[0])))
    selected: list[tuple[int, int]] = []
    for start, end in trimmed:
        if selected and start < selected[-1][1]:
            continue
        selected.append((start, end))
    return selected

def _collect_latex_command_spans(text: str) -> list[tuple[int, int]]:
    return collect_latex_command_spans(text)

def _formula_match_patterns() -> tuple[re.Pattern[str], ...]:
    return formula_match_patterns()

def _trim_inline_math_span(
    text: str, start: int, end: int
) -> tuple[int, int] | None:
    """Drop punctuation that should not enter MathTex."""

    return trim_inline_math_span(text, start, end, _FORMULA_TRAILING_BAD_RE)

def _iter_high_confidence_formula_matches(text: str):
    """Backward compatible iterator over normalized inline math spans."""

    compact = _normalize_formula_text_payload(text)
    for start, end in _collect_high_confidence_formula_matches(compact):

        class _Match:
            __slots__ = ("_text", "_start", "_end")

            def __init__(self, text: str, start: int, end: int) -> None:
                self._text = text
                self._start = start
                self._end = end

            def span(self) -> tuple[int, int]:
                return (self._start, self._end)

            def group(self, _index: int = 0) -> str:
                return self._text[self._start:self._end]

        yield _Match(compact, start, end)

