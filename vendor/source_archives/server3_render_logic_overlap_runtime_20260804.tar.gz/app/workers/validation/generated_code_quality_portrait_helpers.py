import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _call_keyword_number(node: ast.Call, name: str) -> float | None:
    for keyword in node.keywords:
        if keyword.arg == name:
            return _literal_number(keyword.value)
    return None


def _portrait_header_y_key(node: ast.AST) -> str:
    expr = _normalize_expr(ast.unparse(node))
    match = re.fullmatch(r"UP\s*\*\s*(-?\d+(?:\.\d+)?)", expr)
    if not match:
        match = re.fullmatch(r"(-?\d+(?:\.\d+)?)\s*\*\s*UP", expr)
    if not match:
        return ""
    return f"UP*{float(match.group(1)):.2f}"


def _portrait_multi_concept_crowding_line(source: str) -> int:
    if not _is_portrait_source(source):
        return 0
    scene_blocks = _scene_blocks(source)
    if len(scene_blocks) != 1:
        return 0
    block, line_offset = scene_blocks[0]
    tokens = _portrait_concept_tokens(block)
    if len(tokens) < 2:
        return 0
    if re.search(r"\b(?:comparison|compare|compact|summary)_?(?:row|strip|line)\b", block, re.I):
        return 0
    return _portrait_multi_concept_terminal_line(block, line_offset, tokens)


def _portrait_concept_tokens(source: str) -> set[str]:
    return {
        token
        for token in _PORTRAIT_CONCEPT_TOKENS
        if re.search(rf"\b{re.escape(token)}\b", source)
    }


def _portrait_multi_concept_terminal_line(
    source: str,
    line_offset: int,
    tokens: set[str],
) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    token_vars: dict[str, set[str]] = {}
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            segment = ast.get_source_segment(source, node) or ""
            var_tokens = {
                token
                for token in tokens
                if re.search(rf"\b{re.escape(token)}\b", segment, re.I)
            }
            if var_tokens:
                token_vars[node.targets[0].id] = var_tokens

    if len({token for values in token_vars.values() for token in values}) < 2:
        return 0

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_self_method_call(node, "play"):
            continue
        shown_tokens: set[str] = set()
        visual_board_reveals = 0
        for arg in node.args:
            if not isinstance(arg, ast.Call):
                continue
            if _call_name(arg.func) not in _REVEAL_TEXT_ANIMATION_NAMES:
                continue
            names = {
                child.id
                for child in ast.walk(arg)
                if isinstance(child, ast.Name) and child.id in token_vars
            }
            for name in names:
                shown_tokens.update(token_vars[name])
                if re.search(r"(?:board|proof|panel|card|group)$", name, re.I):
                    visual_board_reveals += 1
        if len(shown_tokens) >= 2 and visual_board_reveals >= 2:
            return line_offset + getattr(node, "lineno", 0)
    return 0


