import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _next_to_alignment_misuse_line(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _line_matching(source, r"\.next_to\s*\([^)]*\balignment\s*=")

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or _call_name(node.func) != "next_to":
            continue
        if any(keyword.arg == "alignment" for keyword in node.keywords):
            return getattr(node, "lineno", 0) or 1
    return 0


def _parametric_surface_misuse_line(source: str) -> int:
    match = _PARAMETRIC_SURFACE_RE.search(source)
    return _line_no(source, match.start()) if match else 0


def _text_formula_tiny_scale_line(source: str, text_vars: dict[str, int]) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _line_matching(
            source,
            r"\b(?:Text|Tex|MathTex|MarkupText)\s*\([^\\n]*\)\.scale\s*\(\s*0\.[0-6]",
        )

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if _call_name(node.func) != "scale":
            continue
        scale_value = _first_numeric_arg(node)
        if scale_value is None or scale_value >= _TEXT_FORMULA_TINY_SCALE_THRESHOLD:
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        target = node.func.value
        if isinstance(target, ast.Call) and _call_name(target.func) in _TEXT_CONSTRUCTOR_NAMES:
            return getattr(node, "lineno", 0) or 1
        if isinstance(target, ast.Name) and target.id in text_vars:
            return getattr(node, "lineno", 0) or text_vars[target.id]
    return 0


def _first_numeric_arg(call: ast.Call) -> float | None:
    if not call.args:
        return None
    return _literal_number(call.args[0])


def _is_pure_text_split_layout(source: str) -> bool:
    if _VISUAL_PRIMITIVE_RE.search(source) or _CUSTOM_VISUAL_GRAPH_RE.search(source):
        return False
    show_text_slots = re.findall(r"self\.show_text\s*\([^)]*,\s*[\"'](?:title|[1-4]|sub)[\"']", source)
    return len(show_text_slots) >= 2 or "self.graph_center" in source


