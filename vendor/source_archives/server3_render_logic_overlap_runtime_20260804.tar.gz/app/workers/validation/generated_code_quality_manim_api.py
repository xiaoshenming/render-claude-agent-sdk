import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _manim_019_api_blacklist_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _call_name(node.func)
        bad_keyword_names = {
            keyword.arg
            for keyword in node.keywords
            if keyword.arg in {"stroke_dash_array", "max_width_to_size_ratio"}
        }
        if call_name == "set_style" and any(
            keyword.arg == "dashed" for keyword in node.keywords
        ):
            _append_manim_019_issue(
                issues,
                seen,
                code="manim_set_style_dashed_misuse",
                line=getattr(node, "lineno", 1),
                evidence=_call_evidence(source, node),
                message=(
                    "Manim 0.19 的 set_style(...) 不支持 dashed=True；"
                    "虚线请使用 DashedLine/DashedVMobject 或显式 dash helper。"
                ),
            )
        if "stroke_dash_array" in bad_keyword_names:
            _append_manim_019_issue(
                issues,
                seen,
                code="manim_stroke_dash_array_misuse",
                line=getattr(node, "lineno", 1),
                evidence=_call_evidence(source, node),
                message=(
                    "Manim 0.19 不支持 stroke_dash_array 关键字；"
                    "虚线对象应重写为 DashedLine/DashedVMobject。"
                ),
            )
        if "max_width_to_size_ratio" in bad_keyword_names:
            _append_manim_019_issue(
                issues,
                seen,
                code="manim_max_width_to_size_ratio_misuse",
                line=getattr(node, "lineno", 1),
                evidence=_call_evidence(source, node),
                message=(
                    "Manim 0.19 不支持 max_width_to_size_ratio；"
                    "应使用 font_size、scale_to_fit_width 或项目 safe_text_box 合同。"
                ),
            )
    return issues


def _append_manim_019_issue(
    issues: list[GeneratedCodeQualityIssue],
    seen: set[tuple[str, int]],
    *,
    code: str,
    line: int,
    evidence: str,
    message: str,
) -> None:
    key = (code, line)
    if key in seen:
        return
    seen.add(key)
    issues.append(
        GeneratedCodeQualityIssue(
            code=code,
            severity="error",
            message=message,
            line=line,
            evidence=evidence,
            failure_code=code,
        )
    )


