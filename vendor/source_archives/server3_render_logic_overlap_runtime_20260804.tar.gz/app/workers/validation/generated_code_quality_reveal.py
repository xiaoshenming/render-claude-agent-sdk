import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _bulk_pre_reveal_add_line(source: str) -> int:
    construct_blocks = _construct_blocks(source)
    if construct_blocks:
        for block, line_offset in construct_blocks:
            line = _bulk_pre_reveal_add_line_in_block(
                block, _assigned_text_vars(block), line_offset
            )
            if line:
                return line
        return 0
    return _bulk_pre_reveal_add_line_in_block(source, _assigned_text_vars(source), 0)


def _bulk_pre_reveal_add_line_in_block(
    source: str, text_vars: dict[str, int], line_offset: int
) -> int:
    first_play_pos = source.find("self.play(")
    prefix = source if first_play_pos == -1 else source[:first_play_pos]
    visual_vars = _assigned_visual_vars(prefix)
    prehidden_vars = _prehidden_text_vars(prefix, text_vars)
    add_call_re = r"self\.(add|add_fixed_in_frame_mobjects)\s*\(([^)\n]*)\)"
    for match in re.finditer(add_call_re, prefix):
        method = match.group(1)
        args = match.group(2)
        inline_text_count = len(re.findall(r"\b(?:Text|Tex|MathTex)\s*\(", args))
        var_count = sum(
            1
            for var in text_vars
            if var not in prehidden_vars and re.search(rf"\b{re.escape(var)}\b", args)
        )
        text_count = inline_text_count + var_count
        threshold = 2 if method == "add" else 3
        has_visual_arg = any(
            re.search(rf"\b{re.escape(var)}\b", args) for var in visual_vars
        )
        if method == "add" and (
            has_visual_arg or _is_rehydration_add(source, match.start())
        ):
            continue
        if text_count >= threshold:
            return line_offset + _line_no(source, match.start())
    return 0


def _pre_reveal_visible_object_line(source: str) -> int:
    construct_blocks = _construct_blocks(source)
    if construct_blocks:
        for block, line_offset in construct_blocks:
            line = _pre_reveal_visible_object_line_in_block(block, line_offset)
            if line:
                return line
        return 0
    return _pre_reveal_visible_object_line_in_block(source, 0)


def _pre_reveal_visible_object_line_in_block(source: str, line_offset: int) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    calls = sorted(
        (node for node in ast.walk(tree) if isinstance(node, ast.Call)),
        key=lambda node: (getattr(node, "lineno", 10**9), getattr(node, "col_offset", 0)),
    )
    first_play_line = next(
        (
            getattr(node, "lineno", 0)
            for node in calls
            if _is_self_method_call(node, "play")
        ),
        0,
    )
    if not first_play_line:
        return 0

    pre_visible: dict[str, int] = {}
    for node in calls:
        line_no = getattr(node, "lineno", 0)
        if line_no >= first_play_line:
            continue
        if not _is_self_visible_registration_call(node):
            continue
        for name in _direct_name_args(node):
            pre_visible.setdefault(name, line_offset + line_no)

    if not pre_visible:
        return 0

    for node in calls:
        line_no = getattr(node, "lineno", 0)
        if line_no < first_play_line or not _is_self_method_call(node, "play"):
            continue
        revealed = _reveal_targets_in_play_call(node)
        for name, registered_line in pre_visible.items():
            if name in revealed:
                return registered_line
    return 0


def _is_self_visible_registration_call(node: ast.Call) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and node.func.attr in {
            "add",
            "add_visible",
            "add_visible_object",
            "add_visible_mobject",
        }
    )


def _direct_name_args(node: ast.Call) -> set[str]:
    return {arg.id for arg in node.args if isinstance(arg, ast.Name)}


def _reveal_targets_in_play_call(node: ast.Call) -> set[str]:
    targets: set[str] = set()
    if not _is_self_method_call(node, "play"):
        return targets
    for arg in node.args:
        for child in ast.walk(arg):
            if not isinstance(child, ast.Call):
                continue
            if _call_name(child.func) not in _REVEAL_TEXT_ANIMATION_NAMES:
                continue
            for target in child.args:
                targets.update(
                    name_node.id
                    for name_node in ast.walk(target)
                    if isinstance(name_node, ast.Name)
                )
    return targets


