"""Scene-name and standalone-code diagnostic extraction helpers."""

import re
from typing import List, Optional

_NUMBERED_SCENE_CLASS_RE = r"Scene_\d+(?:_\w+)?"

def extract_all_scene_names(code: str) -> List[str]:
    """提取所有 Scene_XX_Name 格式的类名，按序号排序。"""
    matches = re.findall(
        r"class\s+(Scene_\d+_\w+)\s*\([^)]*\)\s*:", code)
    if not matches:
        return []
    return sorted(
        matches,
        key=lambda x: int(re.search(r"Scene_(\d+)", x).group(1)))


def is_slice_mode(code: str) -> bool:
    """检测代码是否包含切片架构（2+ 个 Scene_XX 类）。"""
    return len(extract_all_scene_names(code)) >= 2


def extract_class_name(code: str) -> Optional[str]:
    """提取场景类名，支持所有继承自 *Scene 的类。"""
    match = re.search(
        r"class\s+([A-Za-z0-9_]+)\s*\([^)]*Scene[^)]*\)\s*:", code)
    return match.group(1) if match else None


def extract_title_from_code(code: str) -> str:
    """从 Manim 代码中提取标题（比调用大模型更快）。

    4 级回退策略:
    1. safe_text_box("标题") 格式
    2. Tex(r"$$\\text{标题}$$") 格式
    3. Text("标题") 格式
    4. Scene_XX_Name 类名 / 其他 Scene 子类名
    """
    # 优先: safe_text_box 标题文本
    match = re.search(
        r'safe_text_box\s*\(\s*["\']([^"\']+)["\']',
        code,
    )
    if match:
        title = match.group(1).strip()
        return title[:15] if len(title) > 15 else title

    # 备选: Tex 格式
    match = re.search(r'title\s*=\s*Tex\s*\(\s*r"\$\$\\text\{([^}]+)\}', code)
    if match:
        title = match.group(1).strip()
        return title[:15] if len(title) > 15 else title

    # 备选: Text 格式
    match = re.search(r'title\s*=\s*Text\s*\(\s*["\']([^"\']+)["\']', code)
    if match:
        title = match.group(1).strip()
        return title[:15] if len(title) > 15 else title

    # 备选: Scene_XX_Name 类名
    match = re.search(rf'class\s+({_NUMBERED_SCENE_CLASS_RE})\s*\(', code)
    if match:
        parts = match.group(1).split('_', 2)
        title = parts[2] if len(parts) >= 3 else match.group(1)
        title = re.sub(r'([a-z])([A-Z])', r'\1 \2', title)
        return title[:15] if len(title) > 15 else title

    # 最后备选: 任意非基类 Scene 子类
    for m in re.finditer(r'class\s+([A-Za-z0-9_]+)\s*\([^)]*Scene', code):
        name = m.group(1)
        if name not in ('BaseConfigScene', 'VoiceoverScene'):
            title = re.sub(r'([a-z])([A-Z])', r'\1 \2', name)
            return title[:15] if len(title) > 15 else title

    return "Shuxuepai动画视频"


def extract_scene_standalone_code(full_code: str, scene_name: str) -> str:
    """提取 header + 指定 Scene 类的完整可独立执行代码。"""
    first_scene_match = re.search(
        rf"(?m)^class\s+{_NUMBERED_SCENE_CLASS_RE}\s*\([^)]*\)\s*:",
        full_code,
    )
    header = full_code[:first_scene_match.start()] if first_scene_match else full_code

    scene_match = re.search(
        rf"(?ms)^class\s+{re.escape(scene_name)}\s*\([^)]*\)\s*:.*?(?=^class\s+{_NUMBERED_SCENE_CLASS_RE}\s*\(|\Z)",
        full_code,
    )
    if not scene_match:
        return header.rstrip()

    scene_code = scene_match.group(0).strip()
    header = header.rstrip()
    return f"{header}\n\n{scene_code}" if header else scene_code


def extract_scene_class_code(full_code: str, scene_name: str) -> str:
    """仅提取目标 Scene 类定义，不包含 header。"""
    scene_match = re.search(
        rf"(?ms)^class\s+{re.escape(scene_name)}\s*\([^)]*\)\s*:.*?(?=^class\s+{_NUMBERED_SCENE_CLASS_RE}\s*\(|\Z)",
        full_code,
    )
    return scene_match.group(0).strip() if scene_match else ""


def extract_slice_header(full_code: str) -> str:
    """提取切片独立代码中的公共 header。"""
    first_scene_match = re.search(
        rf"(?m)^class\s+{_NUMBERED_SCENE_CLASS_RE}\s*\([^)]*\)\s*:",
        full_code,
    )
    if not first_scene_match:
        return (full_code or "").strip()
    return full_code[:first_scene_match.start()].rstrip()
