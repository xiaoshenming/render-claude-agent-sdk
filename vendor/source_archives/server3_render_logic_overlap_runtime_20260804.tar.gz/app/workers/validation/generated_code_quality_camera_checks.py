"""3D 镜头与固定文字合同检查。"""
from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue
from app.workers.validation.generated_code_quality_3d_camera import *

def _append_camera_quality_issues(source: str, issues: list[GeneratedCodeQualityIssue], *, is_3d: bool | None) -> None:
    checks = (
        (_mathpi_3d_camera_contract_missing_line, "mathpi_3d_camera_contract_missing", "MathPi-3D 任务缺少镜头合同。"),
        (_mathpi_3d_default_camera_oblique_line, "mathpi_3d_default_camera_oblique", "MathPi-3D 默认镜头不能斜置。"),
        (_mathpi_3d_camera_animate_misuse_line, "mathpi_3d_camera_animate_misuse", "ThreeDCamera 不能直接 play 镜头动画。"),
        (_mathpi_3d_camera_frame_misuse_line, "mathpi_3d_camera_frame_misuse", "ThreeDCamera 没有 frame 属性。"),
        (_mathpi_3d_camera_set_euler_misuse_line, "mathpi_3d_camera_set_euler_misuse", "ThreeDCamera 没有 set_euler_angles 方法。"),
    )
    for checker, code, message in checks:
        line = checker(source, is_3d=is_3d)
        if line:
            issues.append(GeneratedCodeQualityIssue(code=code, severity="error", message=message, line=line, evidence=code))
    line = _fix_in_frame_method_misuse_line(source)
    if line:
        issues.append(GeneratedCodeQualityIssue(code="manim_fix_in_frame_method_misuse", severity="error", message="固定文字应使用 add_fixed_in_frame_mobjects。", line=line, evidence="add_fixed_in_frame_mobjects"))
