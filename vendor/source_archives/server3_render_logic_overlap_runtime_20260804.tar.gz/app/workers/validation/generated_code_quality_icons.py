import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _core_visual_semantic_icon_fallback_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Core teaching objects must be real geometry, not tiny labeled placeholders."""
    issues: list[GeneratedCodeQualityIssue] = []
    for match in _CORE_VISUAL_SEMANTIC_ICON_RE.finditer(source):
        helper = match.group("helper")
        label = match.group("label").strip("'\"")
        issues.append(
            GeneratedCodeQualityIssue(
                code="core_visual_semantic_icon_fallback",
                severity="error",
                message=(
                    "核心教学视觉对象退化为语义小图标；应使用真实几何 helper，"
                    "例如分段绳子、格点线和可取坐标点。"
                ),
                line=_line_no(source, match.start()),
                evidence=f"{helper}->{label}",
                failure_code="core_visual_semantic_icon_fallback",
            )
        )
    return issues


def _text_box_icon_fallback_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Generated icons must resolve to real assets, not labeled white boxes."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        method = node.func.attr
        if method not in {"_semantic_visual_icon", "generated_icon"}:
            continue
        if not isinstance(node.func.value, ast.Name) or node.func.value.id != "self":
            continue

        label = _first_string_arg(node) or method
        if method == "_semantic_visual_icon":
            code = "semantic_visual_icon_text_box_fallback"
            message = (
                "_semantic_visual_icon 会退化成文字白框；应使用真实 SVG/asset_icon "
                "资源或对应的几何 helper。"
            )
            evidence = f"_semantic_visual_icon({label!r})"
        else:
            code = "generated_icon_text_box_fallback"
            message = (
                "generated_icon 是 pre-render 文本框兜底，不能作为最终图标资源；"
                "应保留 self.asset_icon(\"generated:...\") 或使用真实 SVG 资产。"
            )
            evidence = f"generated_icon({label!r})"

        line = getattr(node, "lineno", 1)
        key = (code, line)
        if key in seen:
            continue
        seen.add(key)
        issues.append(
            GeneratedCodeQualityIssue(
                code=code,
                severity="error",
                message=message,
                line=line,
                evidence=evidence,
                failure_code=code,
            )
        )
    return issues


def _core_text_helper_fallback_icon_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Text/content helpers must render actual text, not icon placeholders."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        if not _TEXT_HELPER_NAME_RE.search(node.name):
            continue
        fallback = _text_helper_returned_fallback_icon(node)
        if fallback is None:
            continue
        label, line = fallback
        if label and not _TEXT_FALLBACK_LABEL_RE.search(label):
            continue
        key = (node.name, line)
        if key in seen:
            continue
        seen.add(key)
        issues.append(
            GeneratedCodeQualityIssue(
                code="core_text_helper_fallback_icon",
                severity="error",
                message=(
                    "文本/标题/说明 helper 退化为 fallback icon；"
                    "应返回真实 Text/MarkupText，而不是圆点图标占位。"
                ),
                line=line,
                evidence=f"{node.name}->{label or '_mathpi_fallback_icon'}",
                failure_code="core_text_helper_fallback_icon",
            )
        )
    return issues


def _forbidden_visible_fallback_icon_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Visible fallback helpers are content loss, not acceptable final visuals."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        for call in _visible_fallback_calls(node):
            label, line = call
            _append_visible_fallback_issue(
                issues,
                seen,
                line=line,
                evidence=f"{node.name}->{label or '_mathpi_fallback_icon'}",
            )
    return issues


def _visible_fallback_calls(function_node: ast.FunctionDef) -> list[tuple[str, int]]:
    calls: list[tuple[str, int]] = []
    for node in ast.walk(function_node):
        if not isinstance(node, ast.Call):
            continue
        call_name = ""
        if isinstance(node.func, ast.Attribute):
            call_name = node.func.attr
        elif isinstance(node.func, ast.Name):
            call_name = node.func.id
        if call_name not in _VISIBLE_FALLBACK_CALL_NAMES:
            continue
        calls.append((
            _first_string_arg(node) or call_name,
            int(getattr(node, "lineno", getattr(function_node, "lineno", 1))),
        ))
    return calls


def _append_visible_fallback_issue(
    issues: list[GeneratedCodeQualityIssue],
    seen: set[tuple[str, int]],
    *,
    line: int,
    evidence: str,
) -> None:
    key = (evidence, line)
    if key in seen:
        return
    seen.add(key)
    issues.append(
        GeneratedCodeQualityIssue(
            code="forbidden_visible_fallback_icon",
            severity="error",
            message=(
                "核心教学对象退化为可见 fallback icon/占位框；"
                "应实现真实几何、文字或资产，不能输出圆点兜底。"
            ),
            line=line,
            evidence=evidence,
            failure_code="forbidden_visible_fallback_icon",
        )
    )


def _text_helper_returned_fallback_icon(
    function_node: ast.FunctionDef,
) -> tuple[str, int] | None:
    for node in ast.walk(function_node):
        if not isinstance(node, ast.Return) or node.value is None:
            continue
        for child in ast.walk(node.value):
            if not isinstance(child, ast.Call):
                continue
            call_name = ""
            if isinstance(child.func, ast.Attribute):
                call_name = child.func.attr
            elif isinstance(child.func, ast.Name):
                call_name = child.func.id
            if call_name != "_mathpi_fallback_icon":
                continue
            return (
                _first_string_arg(child) or "",
                int(getattr(child, "lineno", node.lineno)),
            )
    return None


def _first_string_arg(call: ast.Call) -> str | None:
    if not call.args:
        return None
    first = call.args[0]
    if isinstance(first, ast.Constant) and isinstance(first.value, str):
        return first.value
    return None


