import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _right_triangle_side_label_anchor_line(source: str) -> int:
    if not _RIGHT_TRIANGLE_CONTEXT_RE.search(source):
        return 0
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    for block, line_offset in blocks:
        line = _right_triangle_side_label_anchor_line_in_block(block, line_offset)
        if line:
            return line
    return 0


def _right_triangle_side_label_anchor_line_in_block(
    source: str,
    line_offset: int,
) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _right_triangle_side_label_anchor_line_regex(source, line_offset)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        target_names = [
            target.id for target in node.targets if isinstance(target, ast.Name)
        ]
        if not any(_is_side_label_var(name) for name in target_names):
            continue
        for call in ast.walk(node.value):
            if not (
                isinstance(call, ast.Call)
                and isinstance(call.func, ast.Attribute)
                and call.func.attr == "next_to"
                and call.args
            ):
                continue
            anchor_expr = _normalize_expr(ast.unparse(call.args[0]))
            if _is_single_vertex_direction_offset(anchor_expr):
                return line_offset + getattr(call, "lineno", getattr(node, "lineno", 0))
    return 0


def _right_triangle_side_label_anchor_line_regex(source: str, line_offset: int) -> int:
    pattern = re.compile(
        rf"(?m)^\s*(?:label_[abc]|[abc]_label|side_[abc]_label)\s*=.*?"
        rf"\.next_to\s*\(\s*[A-Z][A-Za-z0-9_]*\s*[-+]\s*{_DIRECTION_NAME_RE}",
        re.I,
    )
    match = pattern.search(source)
    return line_offset + _line_no(source, match.start()) if match else 0


def _ambiguous_right_angle_helper_line(source: str) -> int:
    if "get_right_angle_mark" not in source:
        return 0
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _line_matching(source, r"\b(?:self\.)?get_right_angle_mark\s*\(")
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr == "get_right_angle_mark":
            return getattr(node, "lineno", 0) or 1
        if isinstance(func, ast.Name) and func.id == "get_right_angle_mark":
            return getattr(node, "lineno", 0) or 1
    return 0


def _right_triangle_numeric_side_label_mismatch_issues(
    source: str,
) -> list[GeneratedCodeQualityIssue]:
    if not _RIGHT_TRIANGLE_CONTEXT_RE.search(source):
        return []
    issues: list[GeneratedCodeQualityIssue] = []
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    for block, line_offset in blocks:
        issues.extend(
            _right_triangle_numeric_side_label_mismatch_issues_in_block(
                block,
                line_offset,
            )
        )
    return issues


def _right_triangle_numeric_side_label_mismatch_issues_in_block(
    source: str,
    line_offset: int,
) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    vertices = _literal_triangle_vertices(tree)
    if vertices is None or not _literal_vertices_form_right_triangle(vertices):
        return []

    side_labels = _numeric_midpoint_side_labels(tree, vertices)
    if len(side_labels) < 2:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    for left_index, left in enumerate(side_labels):
        left_side, left_label, left_length, left_line, left_name = left
        for right in side_labels[left_index + 1:]:
            right_side, right_label, right_length, _right_line, right_name = right
            if not _side_label_scale_mismatch(
                left_length,
                left_label,
                right_length,
                right_label,
            ):
                continue
            evidence = (
                f"{left_name} on {left_side}: length={left_length:.3g}, label={left_label:g}; "
                f"{right_name} on {right_side}: length={right_length:.3g}, label={right_label:g}"
            )
            issues.append(
                GeneratedCodeQualityIssue(
                    code="right_triangle_numeric_side_label_mismatch",
                    severity="error",
                    message=(
                        "直角三角形数值边标签与 A/B/C 坐标长度比例不一致，"
                        "会把 3、4、5 等边长标到错误边或错误尺度；请按实际边长重算标签。"
                    ),
                    line=line_offset + left_line,
                    evidence=evidence,
                    failure_code="right_triangle_numeric_side_label_mismatch",
                )
            )
            return issues
    return issues


