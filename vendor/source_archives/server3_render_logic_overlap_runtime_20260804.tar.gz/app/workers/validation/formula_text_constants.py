"""Formula text token and helper constants."""
FORMULA_TEXT_LATEX_TOKENS = (
    "\\frac", "\\sqrt", "\\times", "\\left", "\\right", "\\sum", "\\int", "\\theta", "\\alpha", "\\beta", "\\gamma", "\\pi", "\\Delta", "\\delta", "\\lambda", "\\mu", "\\sigma", "\\phi", "\\Omega", "\\sin", "\\cos", "\\tan", "\\log", "\\ln", "\\lim", "\\infty", "\\neq", "\\approx", "\\subset", "\\subseteq", "\\supset", "\\supseteq", "\\in", "\\notin", "\\cup", "\\cap", "\\emptyset", "\\angle", "\\triangle", "\\cong", "\\sim", "\\because", "\\therefore", "\\implies", "\\cdot", "\\vec", "\\over", "\\perp", "\\parallel", "\\le", "\\ge", "\\leq", "\\geq", "\\ne", "\\pm", "\\to", "$", "\\(", "\\[",
)
TEXT_PAYLOAD_HELPERS = {"MarkupText", "Paragraph", "Text", "safe_text_box"}
MATHTEX_SAFE_KEYWORDS = {"color", "font_size", "tex_template", "substrings_to_isolate"}
INLINE_TEXT_SAFE_KEYWORDS = {"color", "font_size"}
