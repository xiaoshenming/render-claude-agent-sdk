from __future__ import annotations

__all__ = ["_layout_repair_degraded_allowed", "_pre_render_scan_layout_repair_script", "_mark_shared_layout_repair_event_scope", "_layout_issue_object_summary", "_layout_repair_last_error", "_record_layout_repair_plan", "_mark_layout_issue_signatures", "_check_layout_helper_contract", "_shared_layout_helper_touched_scenes", "_parse_frame_overflow_evidence", "_layout_issue_repair_action_hints", "_layout_repair_action_hints_for_quality_issues", "_record_layout_seconds", "_backhalf_repair_budget", "_should_cross_scene_dedup", "_extract_render_canvas_profile_metadata", "_attach_render_canvas_profile_metadata", "_record_layout_render_fix_count", "_parse_overlap_evidence", "_record_soft_layout_note", "_should_sync_llm_layout_judge", "_layout_repair_budget", "_layout_pre_render_color_scheme", "_layout_repair_no_progress_threshold", "_ast_base_name", "_layout_issue_metadata_summary", "_layout_repair_max_llm_calls", "_legacy_layout_judge_disabled", "_env_int", "_env_bool", "_visual_edge_color_distance", "_visual_edge_density_threshold", "_visual_edge_margin_ratio", "_probe_timeout", "_task_data_int", "_compact_layout_number", "_compact_layout_text", "_env_float", "_repair_loop_limit"]

def _layout_repair_degraded_allowed(*args, **kwargs):
    from app.workers.validation.layout.runtime_quality_contract import _layout_repair_degraded_allowed as _impl
    return _impl(*args, **kwargs)


def _pre_render_scan_layout_repair_script(*args, **kwargs):
    from app.workers.validation.layout.runtime_quality_contract import _pre_render_scan_layout_repair_script as _impl
    return _impl(*args, **kwargs)


def _mark_shared_layout_repair_event_scope(*args, **kwargs):
    from app.workers.validation.layout.runtime_reporting import _mark_shared_layout_repair_event_scope as _impl
    return _impl(*args, **kwargs)


def _layout_issue_object_summary(*args, **kwargs):
    from app.workers.validation.layout.runtime_reporting import _layout_issue_object_summary as _impl
    return _impl(*args, **kwargs)


def _layout_repair_last_error(*args, **kwargs):
    from app.workers.validation.layout.runtime_reporting import _layout_repair_last_error as _impl
    return _impl(*args, **kwargs)


def _record_layout_repair_plan(*args, **kwargs):
    from app.workers.validation.layout.runtime_reporting import _record_layout_repair_plan as _impl
    return _impl(*args, **kwargs)


def _mark_layout_issue_signatures(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _mark_layout_issue_signatures as _impl
    return _impl(*args, **kwargs)


def _check_layout_helper_contract(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _check_layout_helper_contract as _impl
    return _impl(*args, **kwargs)


def _shared_layout_helper_touched_scenes(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _shared_layout_helper_touched_scenes as _impl
    return _impl(*args, **kwargs)


def _parse_frame_overflow_evidence(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _parse_frame_overflow_evidence as _impl
    return _impl(*args, **kwargs)


def _layout_issue_repair_action_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _layout_issue_repair_action_hints as _impl
    return _impl(*args, **kwargs)


def _layout_repair_action_hints_for_quality_issues(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _layout_repair_action_hints_for_quality_issues as _impl
    return _impl(*args, **kwargs)


def _record_layout_seconds(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _record_layout_seconds as _impl
    return _impl(*args, **kwargs)


def _backhalf_repair_budget(*args, **kwargs):
    from app.workers.validation.layout.runtime_helpers import _backhalf_repair_budget as _impl
    return _impl(*args, **kwargs)


def _should_cross_scene_dedup(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _should_cross_scene_dedup as _impl
    return _impl(*args, **kwargs)


def _extract_render_canvas_profile_metadata(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _extract_render_canvas_profile_metadata as _impl
    return _impl(*args, **kwargs)


def _attach_render_canvas_profile_metadata(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _attach_render_canvas_profile_metadata as _impl
    return _impl(*args, **kwargs)



def _record_layout_render_fix_count(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _record_layout_render_fix_count as _impl
    return _impl(*args, **kwargs)


def _parse_overlap_evidence(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _parse_overlap_evidence as _impl
    return _impl(*args, **kwargs)


def _record_soft_layout_note(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _record_soft_layout_note as _impl
    return _impl(*args, **kwargs)


def _should_sync_llm_layout_judge(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _should_sync_llm_layout_judge as _impl
    return _impl(*args, **kwargs)


def _layout_repair_budget(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _layout_repair_budget as _impl
    return _impl(*args, **kwargs)


def _layout_pre_render_color_scheme(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _layout_pre_render_color_scheme as _impl
    return _impl(*args, **kwargs)


def _layout_repair_no_progress_threshold(*args, **kwargs):
    from app.workers.validation.layout.runtime_thresholds import _layout_repair_no_progress_threshold as _impl
    return _impl(*args, **kwargs)


def _ast_base_name(*args, **kwargs):
    from app.workers.validation.layout.runtime_misc import _ast_base_name as _impl
    return _impl(*args, **kwargs)


def _layout_issue_metadata_summary(*args, **kwargs):
    from app.workers.validation.layout.runtime_misc import _layout_issue_metadata_summary as _impl
    return _impl(*args, **kwargs)


def _layout_repair_max_llm_calls(*args, **kwargs):
    from app.workers.validation.layout.runtime_misc import _layout_repair_max_llm_calls as _impl
    return _impl(*args, **kwargs)


def _legacy_layout_judge_disabled(*args, **kwargs):
    from app.workers.validation.layout.runtime_misc import _legacy_layout_judge_disabled as _impl
    return _impl(*args, **kwargs)


def _env_int(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _env_int as _impl
    return _impl(*args, **kwargs)


def _env_bool(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _env_bool as _impl
    return _impl(*args, **kwargs)


def _visual_edge_color_distance(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _visual_edge_color_distance as _impl
    return _impl(*args, **kwargs)


def _visual_edge_density_threshold(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _visual_edge_density_threshold as _impl
    return _impl(*args, **kwargs)


def _visual_edge_margin_ratio(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _visual_edge_margin_ratio as _impl
    return _impl(*args, **kwargs)


def _probe_timeout(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _probe_timeout as _impl
    return _impl(*args, **kwargs)


def _task_data_int(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _task_data_int as _impl
    return _impl(*args, **kwargs)


def _compact_layout_number(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _compact_layout_number as _impl
    return _impl(*args, **kwargs)


def _compact_layout_text(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _compact_layout_text as _impl
    return _impl(*args, **kwargs)


def _env_float(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _env_float as _impl
    return _impl(*args, **kwargs)


def _repair_loop_limit(*args, **kwargs):
    from app.workers.validation.layout.runtime_primitives import _repair_loop_limit as _impl
    return _impl(*args, **kwargs)


