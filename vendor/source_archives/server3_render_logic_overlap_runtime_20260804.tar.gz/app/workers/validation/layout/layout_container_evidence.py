"""Container-boundary evidence predicates for layout policy."""

from __future__ import annotations

from typing import Any

TEXTUAL_KINDS = {"text", "formula"}


def _float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def text_bbox_inside_container(
    a: dict[str, Any], b: dict[str, Any], *, tolerance: float = 0.02
) -> bool:
    if str(a.get("kind") or "") == "container":
        container, text_obj = a, b
    elif str(b.get("kind") or "") == "container":
        container, text_obj = b, a
    else:
        return False
    if str(text_obj.get("kind") or "") not in TEXTUAL_KINDS:
        return False
    text_box = text_obj.get("bbox") if isinstance(text_obj.get("bbox"), dict) else None
    container_box = container.get("bbox") if isinstance(container.get("bbox"), dict) else None
    if not text_box or not container_box:
        return False
    margins = (
        _float(text_box.get("left")) - _float(container_box.get("left")) + tolerance,
        _float(container_box.get("right")) - _float(text_box.get("right")) + tolerance,
        _float(container_box.get("top")) - _float(text_box.get("top")) + tolerance,
        _float(text_box.get("bottom")) - _float(container_box.get("bottom")) + tolerance,
    )
    return all(margin >= 0.0 for margin in margins)
