"""Compatibility facade for layout judge client."""
from . import judge_helpers as _helpers
from . import judge_issue_helpers as _issues
from . import judge_core as _core
globals().update({k: v for _module in (_helpers, _issues, _core) for k, v in vars(_module).items() if not k.startswith("__")})
