"""布局重叠证据 metadata 规整。"""
from __future__ import annotations
from typing import Any


def overlap_metadata(overlap: dict[str, Any]) -> dict[str, Any]:
    metadata = dict(overlap.get("metadata")) if isinstance(overlap.get("metadata"), dict) else {}
    metadata["category"] = str(overlap.get("category") or "")
    for key in ("event", "step"):
        if key in overlap and key not in metadata:
            metadata[key] = overlap[key]
    return metadata
