from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any

def _layout_mvp_probe_object(obj: dict[str, Any]) -> dict[str, Any]:
    payload = dict(obj)
    text = payload.get("text")
    if text in (None, "") and payload.get("label") not in (None, ""):
        payload["text"] = str(payload.get("label"))
    if payload.get("kind") in (None, ""):
        cls = str(payload.get("class") or "")
        if cls in {"Text", "MarkupText", "Paragraph"}:
            payload["kind"] = "text"
        elif cls in {"MathTex", "Tex", "SingleStringMathTex"}:
            payload["kind"] = "formula"
        elif cls:
            payload["kind"] = "shape"
    return payload


def _layout_mvp_overlap_category(objects: list[dict[str, Any]]) -> str:
    has_shape = any(_layout_mvp_object_is_shape(obj) for obj in objects)
    has_textual = any(_layout_mvp_object_is_textual(obj) for obj in objects)
    if has_shape and has_textual:
        return "label_shape_overlap_risk"
    return "text_formula_overlap"


def _layout_mvp_object_is_shape(obj: dict[str, Any]) -> bool:
    if obj.get("kind") == "shape":
        return True
    return str(obj.get("class") or "") in {
        "Arrow",
        "Line",
        "Arc",
        "Circle",
        "Rectangle",
        "Square",
        "Polygon",
        "Triangle",
        "Axes",
        "NumberPlane",
    }


def _layout_mvp_object_is_textual(obj: dict[str, Any]) -> bool:
    if obj.get("kind") in {"text", "formula", "tex"}:
        return True
    return str(obj.get("class") or "") in {
        "Text",
        "MarkupText",
        "Paragraph",
        "MathTex",
        "Tex",
        "SingleStringMathTex",
    }


def _layout_mvp_actions_from_metadata(
    metadata: dict[str, Any] | None,
    *,
    outer_round: int,
) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    if not isinstance(metadata, dict):
        return actions
    for item in metadata.get("rounds") or []:
        if not isinstance(item, dict):
            continue
        if _layout_mvp_round_has_no_patch(item):
            continue
        action: dict[str, Any] = {
            "type": "small_patch",
            "method": "layout_mvp_0llm_small_patch",
            "repair_source": "deterministic",
            "outer_round": outer_round,
            "round_index": item.get("round_index"),
            "status": item.get("status"),
            "patch_count": item.get("patch_count"),
            "patch_reasons": item.get("patch_reasons") or [],
            "changed_lines": item.get("changed_lines") or [],
        }
        diff = item.get("diff")
        if isinstance(diff, str) and diff:
            action["diff_preview"] = diff[:12000]
        actions.append(action)
    return actions


