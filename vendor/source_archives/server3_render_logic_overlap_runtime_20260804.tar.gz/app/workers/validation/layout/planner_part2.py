from __future__ import annotations

import copy
import json
import re
from typing import Any
from . import planner_part3 as _part3
from . import planner_part4 as _part4
globals().update({k: v for _module in (_part3, _part4) for k, v in vars(_module).items() if not k.startswith("__")})

from .schemas import LayoutIssue


LAYOUT_REPAIR_PLAN_SCHEMA_VERSION = "layout_repair_plan.v1"
LAYOUT_PLAN_TARGET_CODES = {
    "layout_overlap_error",
    "layout_frame_overflow",
    "layout_container_overflow",
    "layout_container_border_overlap",
}

_OVERLAP_EVIDENCE_RE = re.compile(
    r"(?P<a>.+?)\s+overlaps\s+(?P<b>.+?);\s*"
    r"overlap_ratio=(?P<overlap_ratio>-?\d+(?:\.\d+)?),\s*"
    r"x_overlap=(?P<x_overlap>-?\d+(?:\.\d+)?),\s*"
    r"y_overlap=(?P<y_overlap>-?\d+(?:\.\d+)?)"
)
_FRAME_OVERFLOW_EVIDENCE_RE = re.compile(
    r"(?P<object>.+?)\s+exceeds\s+frame\s+bounds;\s*"
    r"overflow_x=(?P<overflow_x>-?\d+(?:\.\d+)?),\s*"
    r"overflow_y=(?P<overflow_y>-?\d+(?:\.\d+)?)"
    r"(?:,\s*frame=\[(?P<frame>[^\]]+)\])?"
)



def _constraint_from_issue(issue: LayoutIssue | dict[str, Any]) -> dict[str, Any]:
    code = str(_issue_get(issue, "code") or "")
    evidence = str(
        _issue_get(issue, "evidence")
        or _issue_get(issue, "message")
        or ""
    )
    if code not in LAYOUT_PLAN_TARGET_CODES and not _evidence_is_layout_target(evidence):
        return {}

    parsed = _parse_evidence(evidence)
    objects = [_object_constraint(obj) for obj in _issue_objects(issue)[:3]]
    objects = [obj for obj in objects if obj]
    scene = str(_issue_get(issue, "scene_name") or parsed.get("scene") or "")
    metrics = _issue_metrics(issue, parsed)
    action, fallback_actions = _choose_action(code, objects, metrics)
    action_contract = _executable_action_contract(
        action=action,
        code=code or _code_from_evidence(evidence),
        scene=scene,
        objects=objects,
        metrics=metrics,
    )
    constraint = {
        "scene": scene,
        "code": code or _code_from_evidence(evidence),
        "severity": _issue_get(issue, "severity"),
        "confidence": _round_float(_issue_get(issue, "confidence")),
        "objects": objects,
        "overlap_ratio": metrics.get("overlap_ratio"),
        "x_overlap": metrics.get("x_overlap"),
        "y_overlap": metrics.get("y_overlap"),
        "overflow_x": metrics.get("overflow_x"),
        "overflow_y": metrics.get("overflow_y"),
        "safe_zone": _safe_zone(issue, parsed),
        "bbox_signature": _bbox_signature(scene, code, objects, metrics),
        "action": action,
        "fallback_actions": fallback_actions,
        "action_contract": action_contract,
        "axis": _separation_axis(metrics),
        "direction": _direction_hint(objects, metrics),
        "min_clearance": _min_clearance(metrics),
        "scale_hint": _scale_hint(action, metrics),
        "evidence": _compact_text(evidence, 500),
    }
    constraint.update(_action_contract(action, objects))
    return {
        key: value
        for key, value in constraint.items()
        if value not in (None, "", [], {})
    }
def _evidence_is_layout_target(evidence: str) -> bool:
    return " overlaps " in evidence or "exceeds frame bounds" in evidence
def _code_from_evidence(evidence: str) -> str:
    if "exceeds frame bounds" in evidence:
        return "layout_frame_overflow"
    if " overlaps " in evidence:
        return "layout_overlap_error"
    return "layout_issue"
def _parse_evidence(evidence: str) -> dict[str, Any]:
    overlap_match = _OVERLAP_EVIDENCE_RE.search(evidence or "")
    if overlap_match:
        return {
            "a": overlap_match.group("a").strip(),
            "b": overlap_match.group("b").strip(),
            "overlap_ratio": _round_float(overlap_match.group("overlap_ratio")),
            "x_overlap": _round_float(overlap_match.group("x_overlap")),
            "y_overlap": _round_float(overlap_match.group("y_overlap")),
        }
    overflow_match = _FRAME_OVERFLOW_EVIDENCE_RE.search(evidence or "")
    if not overflow_match:
        return {}
    frame = None
    if overflow_match.group("frame"):
        frame_values = [
            _round_float(item)
            for item in str(overflow_match.group("frame")).split(",")
        ]
        if len(frame_values) == 4:
            frame = {
                "left": frame_values[0],
                "right": frame_values[1],
                "bottom": frame_values[2],
                "top": frame_values[3],
            }
    return {
        "object": overflow_match.group("object").strip(),
        "overflow_x": _round_float(overflow_match.group("overflow_x")),
        "overflow_y": _round_float(overflow_match.group("overflow_y")),
        "frame": frame,
    }
def _issue_metrics(
    issue: LayoutIssue | dict[str, Any],
    parsed: dict[str, Any],
) -> dict[str, float]:
    code = str(_issue_get(issue, "code") or "")
    overlap_ratio = _first_number(
        _issue_get(issue, "overlap_ratio"),
        parsed.get("overlap_ratio"),
    )
    x_value = _first_number(_issue_get(issue, "x_overlap"), parsed.get("x_overlap"))
    y_value = _first_number(_issue_get(issue, "y_overlap"), parsed.get("y_overlap"))
    metadata = _issue_metadata(issue)
    if code == "layout_frame_overflow" or parsed.get("overflow_x") is not None:
        return {
            "overflow_x": _first_number(
                metadata.get("overflow_x"),
                parsed.get("overflow_x"),
                x_value,
            ),
            "overflow_y": _first_number(
                metadata.get("overflow_y"),
                parsed.get("overflow_y"),
                y_value,
            ),
        }
    return {
        "overlap_ratio": overlap_ratio,
        "x_overlap": x_value,
        "y_overlap": y_value,
    }
def _safe_zone(issue: LayoutIssue | dict[str, Any], parsed: dict[str, Any]) -> dict[str, Any]:
    metadata = _issue_metadata(issue)
    frame = metadata.get("frame")
    if isinstance(frame, dict):
        return {
            "frame": {
                "left": _round_float(frame.get("left")),
                "right": _round_float(frame.get("right")),
                "bottom": _round_float(frame.get("bottom")),
                "top": _round_float(frame.get("top")),
            }
        }
    if isinstance(parsed.get("frame"), dict):
        return {"frame": parsed["frame"]}
    return {}
