"""Layout LLM judge：对 needs_llm_judge=True 的模糊重叠做二次判定。

对应 Admin 后台 `ai.routes.layout_judge` 配置（默认 deepseek-v4-flash）。
判定为真重叠的 issue 会被升级为 layout_overlap_error 并交给修复管线，
不再有"等人工查看"的中间态。
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
from dataclasses import replace
from typing import Any

try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover
    AsyncOpenAI = None

from app.core.config import settings
from app.core.runtime_config.client import (
    is_runtime_settings_override,
    refresh_runtime_config_if_stale,
)
from app.prompts.prompt_compiler import compile_cacheable_segmented_prompt
from app.services.dedicated_llm_client import call_dedicated_chat_completion
from app.services.llm_call_tracer import LLMCallTracer
from app.services.llm_service import get_llm_manager
from app.workers.repair.repair_state import (
    BackhalfRepairBudget,
    record_backhalf_repair_call,
)

from .schemas import LayoutIssue


TEXTUAL_KINDS = {"text", "formula"}
TEXT_SHAPE_ERROR_THRESHOLD = 0.35
TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD = 0.55
EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow"}



def _normalize_label_text(text: str) -> str:
    compact = (text or "").strip()
    compact = re.sub(r"^\$+|\$+$", "", compact)
    compact = re.sub(r"\\[a-zA-Z]+\{([^{}]*)\}", r"\1", compact)
    compact = compact.replace("^{2}", "^2")
    compact = compact.replace("{", "").replace("}", "")
    compact = compact.replace("′", "'")
    compact = re.sub(r"\s+", "", compact)
    return compact
def _is_protected_geometry_label(obj: dict[str, Any]) -> bool:
    if str(obj.get("kind") or "") not in {"text", "formula"}:
        return False
    compact = _normalize_label_text(str(obj.get("text") or ""))
    if not compact or len(compact) > 8:
        return False
    return bool(_PROTECTED_GEOMETRY_LABEL_RE.match(compact))
def _should_suppress_auto_repair(issue: LayoutIssue) -> bool:
    category = str((issue.metadata or {}).get("category") or "")
    if category not in {"label_shape_overlap_risk", "text_formula_overlap"}:
        return bool((issue.metadata or {}).get("protected_geometry_label"))
    return any(
        isinstance(obj, dict) and _is_protected_geometry_label(obj)
        for obj in issue.objects or []
    )
def _strong_bbox_occlusion_metadata(issue: LayoutIssue) -> dict[str, Any] | None:
    text_obj, shape_obj = _text_shape_pair(issue)
    if text_obj is None or shape_obj is None:
        return None
    if _is_protected_geometry_label(text_obj):
        return None
    shape_class = str(shape_obj.get("class") or "")
    if shape_class in {"Axes", "NumberPlane"}:
        return None
    metadata = issue.metadata or {}
    if metadata.get("near_collision"):
        return None
    text_box = text_obj.get("bbox") if isinstance(text_obj.get("bbox"), dict) else {}
    if not text_box:
        return None
    text_width = max(_round(text_box.get("width")), 0.01)
    text_height = max(_round(text_box.get("height")), 0.01)
    x_coverage = max(0.0, min(1.0, _round(issue.x_overlap) / text_width))
    y_coverage = max(0.0, min(1.0, _round(issue.y_overlap) / text_height))
    area_coverage = x_coverage * y_coverage
    line_like = shape_class in EXTENDED_LINE_CLASSES
    is_obvious = bool(metadata.get("strong_text_shape_occlusion")) or (
        _round(issue.overlap_ratio) >= TEXT_SHAPE_ERROR_THRESHOLD
        or area_coverage >= TEXT_SHAPE_ERROR_THRESHOLD
        or (
            x_coverage >= TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD
            and y_coverage >= TEXT_SHAPE_ERROR_THRESHOLD
        )
        or (
            line_like
            and x_coverage >= 0.45
            and y_coverage >= 0.22
        )
    )
    if not is_obvious:
        return None
    visual_evidence = metadata.get("visual_review_evidence")
    if not isinstance(visual_evidence, dict):
        visual_evidence = _visual_review_evidence(
            text_obj=text_obj,
            shape_obj=shape_obj,
            issue=issue,
        )
    return {
        "strong_text_shape_occlusion": True,
        "bbox_occlusion_metrics": {
            "text_coverage_x": round(x_coverage, 4),
            "text_coverage_y": round(y_coverage, 4),
            "text_coverage_area": round(area_coverage, 4),
            "shape_class": shape_class,
        },
        "visual_review_evidence": visual_evidence,
    }
def _text_shape_pair(
    issue: LayoutIssue,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    text_obj = None
    shape_obj = None
    for obj in issue.objects or []:
        if not isinstance(obj, dict):
            continue
        kind = str(obj.get("kind") or "")
        if kind in TEXTUAL_KINDS and text_obj is None:
            text_obj = obj
        elif kind == "shape" and shape_obj is None:
            shape_obj = obj
    return text_obj, shape_obj
def _visual_review_evidence(
    *,
    text_obj: dict[str, Any],
    shape_obj: dict[str, Any],
    issue: LayoutIssue,
) -> dict[str, Any]:
    return {
        "evidence_type": "text_shape_occlusion",
        "textual_object": _label(text_obj),
        "occluding_object": _label(shape_obj),
        "overlap_ratio": _round(issue.overlap_ratio),
        "x_overlap": _round(issue.x_overlap),
        "y_overlap": _round(issue.y_overlap),
        "crop_hint": {
            "source": "bbox_union",
            "padding": 0.16,
            "bbox": _union_bbox(text_obj, shape_obj),
        },
    }
def _union_bbox(*objects: dict[str, Any]) -> dict[str, float]:
    boxes = [
        obj.get("bbox")
        for obj in objects
        if isinstance(obj.get("bbox"), dict)
    ]
    if not boxes:
        return {}
    left = min(_round(box.get("left")) for box in boxes)
    right = max(_round(box.get("right")) for box in boxes)
    top = max(_round(box.get("top")) for box in boxes)
    bottom = min(_round(box.get("bottom")) for box in boxes)
    return {
        "left": round(left, 4),
        "right": round(right, 4),
        "top": round(top, 4),
        "bottom": round(bottom, 4),
        "width": round(max(0.0, right - left), 4),
        "height": round(max(0.0, top - bottom), 4),
    }
def _label(obj: dict[str, Any]) -> str:
    text = str(obj.get("text") or "").strip()
    cls = str(obj.get("class") or obj.get("kind") or "object")
    return f"{cls}({text})" if text else cls
def _is_protected_record_only_layout_issue(issue: LayoutIssue) -> bool:
    if issue.code != "layout_overlap_risk":
        return False
    if issue.severity != "low":
        return False
    if issue.repairable or issue.deterministic_repairable:
        return False
    if not bool((issue.metadata or {}).get("protected_geometry_label")):
        return False
    suggested_fix = str(issue.suggested_fix or "")
    return "只记录" in suggested_fix and "正常标注" in suggested_fix
def _clear_protected_record_only_judge_flags(
    issues: list[LayoutIssue],
) -> list[LayoutIssue]:
    return [
        replace(issue, needs_llm_judge=False)
        if _is_protected_record_only_layout_issue(issue) and issue.needs_llm_judge
        else issue
        for issue in issues
    ]
def _build_prompt(*, scene_name: str, items: list[dict[str, Any]]) -> str:
    stable_prefix, dynamic_payload = _build_prompt_parts(
        scene_name=scene_name,
        items=items,
    )
    return f"{stable_prefix}\n\n{dynamic_payload}"
def _build_prompt_parts(
    *,
    scene_name: str,
    items: list[dict[str, Any]],
) -> tuple[str, str]:
    stable_prefix = """你是 Manim 视频的版面裁判。下面是探针检测到的"疑似重叠"，
我已经确定它们多数属于 ratio 不算高或几何边界模糊的案例，需要你做最终判断。
**这些 overlap 在最终视频画面上是否真的会让人眼看到文字/图形挤在一起、影响阅读？**

判定原则：
- 文本和文本/公式互相覆盖 ≥ 30% 高度，必为真重叠 (is_real_overlap=true)。
- 公式被图形压住、线穿过文字/公式、Polygon/Circle/Arrow 等图形覆盖可读公式，默认是真重叠；只有明确不影响阅读时才可 false_positive。
- 顶点字母 (M, A, B, ...) 落在大几何图形 bbox 内是合法标注，不算重叠 (is_real_overlap=false)。
- 短几何锚定标签/边长标签 (a, b, c, a^2, c=?, a=3 等) 与边或图形贴近通常是正常标注；但只能在不遮挡阅读、不穿字、不压住公式时 false_positive。
- 内部标注/贴线不是免死牌；若 bbox 指标和证据显示文字/公式主体被遮挡，必须 true。
- 公式与公式相邻、bbox 仅边界擦边 (overlap_ratio < 0.2) 但视觉上彼此分隔，false_positive。
- 与坐标轴/边框 1-2 像素相交，false_positive。
- 任何让用户读不清文字的实际遮挡，true。

只输出 JSON，schema 为：
{{
  "verdicts": [
    {{
      "id": <int, 与输入 id 对应>,
      "is_real_overlap": true|false,
      "reason": "≤80字判断依据"
    }}
  ]
}}
"""
    dynamic_payload = f"""Scene：{scene_name}

待判定列表：
{json.dumps(items, ensure_ascii=False, indent=2)}
"""
    return stable_prefix, dynamic_payload
def _parse_verdicts(raw_output: str) -> dict[int, dict[str, Any]]:
    text = (raw_output or "").strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.S | re.I)
    if fenced:
        text = fenced.group(1).strip()
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            return {}
        payload = json.loads(text[start:end + 1])
    out: dict[int, dict[str, Any]] = {}
    for item in payload.get("verdicts", []) or []:
        if not isinstance(item, dict):
            continue
        try:
            out[int(item.get("id"))] = item
        except (TypeError, ValueError):
            continue
    return out

