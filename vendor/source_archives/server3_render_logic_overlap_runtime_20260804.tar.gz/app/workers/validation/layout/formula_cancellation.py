"""公式消去线与公式框重叠的证据判定。"""
from __future__ import annotations
from typing import Any, Collection, Callable

def looks_like_formula_cancellation_line_overlap(a: dict[str, Any], b: dict[str, Any], *, ratio: float, float_value: Callable[[Any], float], line_classes: Collection[str]) -> bool:
    if ratio < 0.45: return False
    formula = a if str(a.get("kind") or "") == "formula" else b
    line = b if formula is a else a
    if str(formula.get("kind") or "") != "formula" or str(line.get("kind") or "") != "shape": return False
    if str(line.get("class") or "") not in line_classes or not str(formula.get("text") or "").strip(): return False
    formula_box = formula.get("bbox") if isinstance(formula.get("bbox"), dict) else {}
    line_box = line.get("bbox") if isinstance(line.get("bbox"), dict) else {}
    if not formula_box or not line_box: return False
    fw, fh = max(float_value(formula_box.get("width")), 0.01), max(float_value(formula_box.get("height")), 0.01)
    lw, lh = float_value(line_box.get("width")), float_value(line_box.get("height"))
    if lw <= 0 or lh <= 0 or lw > max(0.85, min(1.35, fw * 0.65)) or lh > max(0.55, fh * 2.4): return False
    cx, cy = float_value(line_box.get("center_x")), float_value(line_box.get("center_y"))
    px, py = max(0.12, lw * 0.25), max(0.12, lh * 0.25)
    return float_value(formula_box.get("left")) - px <= cx <= float_value(formula_box.get("right")) + px and float_value(formula_box.get("bottom")) - py <= cy <= float_value(formula_box.get("top")) + py
