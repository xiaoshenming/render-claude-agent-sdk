"""Geometry-label normalization and protection predicates for layout policy."""

from __future__ import annotations

import re
from typing import Any

TEXTUAL_KINDS = {"text", "formula"}
_SHORT_ANCHOR_LABEL_RE = re.compile(r"^[A-Za-z][A-Za-z0-9'_]{0,2}$")
_PROTECTED_GEOMETRY_LABEL_RE = re.compile(
    r"^(?:[abcABC][A-Za-z0-9'_]{0,2}|[abcABC]\^2|[abcABC]=\?|"
    r"[abcABC]=-?\d+(?:\.\d+)?|(?:斜边|直角边|边长|边|高|底边|底|腰|长|宽)[abcABChH]|"
    r"-?\d+(?:\.\d+)?)$"
)
_COORDINATE_POINT_LABEL_RE = re.compile(
    r"^[A-Za-z][A-Za-z0-9'_]{0,2}\(-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?\)$"
)


def _float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def is_short_anchor_label(text: str) -> bool:
    compact = re.sub(r"^\$+|\$+$", "", (text or "").strip())
    compact = re.sub(r"\\[a-zA-Z]+\{([^{}]*)\}", r"\1", compact)
    compact = compact.replace("{", "").replace("}", "").strip()
    return bool(_SHORT_ANCHOR_LABEL_RE.match(compact))


def normalize_label_text(text: str) -> str:
    compact = re.sub(r"^\$+|\$+$", "", (text or "").strip())
    compact = re.sub(r"\\[a-zA-Z]+\{([^{}]*)\}", r"\1", compact)
    compact = compact.replace("^{2}", "^2").replace("{", "").replace("}", "")
    return re.sub(r"\s+", "", compact.replace("′", "'"))


def looks_like_probe_duplicate_textual_pair(a: dict[str, Any], b: dict[str, Any], *, tolerance: float = 0.015) -> bool:
    if str(a.get("kind") or "") not in TEXTUAL_KINDS or str(b.get("kind") or "") not in TEXTUAL_KINDS:
        return False
    if normalize_label_text(str(a.get("text") or "")) != normalize_label_text(str(b.get("text") or "")):
        return False
    box_a = a.get("bbox") if isinstance(a.get("bbox"), dict) else {}
    box_b = b.get("bbox") if isinstance(b.get("bbox"), dict) else {}
    return bool(box_a and box_b) and all(abs(_float(box_a.get(k)) - _float(box_b.get(k))) <= tolerance for k in ("left", "right", "top", "bottom"))


def is_protected_geometry_label(obj: dict[str, Any]) -> bool:
    if str(obj.get("kind") or "") not in TEXTUAL_KINDS:
        return False
    compact = normalize_label_text(str(obj.get("text") or ""))
    if _COORDINATE_POINT_LABEL_RE.match(compact):
        return True
    return bool(compact and len(compact) <= 8 and _PROTECTED_GEOMETRY_LABEL_RE.match(compact))


def looks_like_protected_geometry_label_pair(a: dict[str, Any], b: dict[str, Any]) -> bool:
    return is_protected_geometry_label(a) or is_protected_geometry_label(b)


def contains_protected_geometry_label(a: dict[str, Any], b: dict[str, Any]) -> bool:
    return is_protected_geometry_label(a) or is_protected_geometry_label(b)


def looks_like_anchored_short_label_pair(a: dict[str, Any], b: dict[str, Any], ratio: float) -> bool:
    if str(a.get("kind") or "") not in TEXTUAL_KINDS or str(b.get("kind") or "") not in TEXTUAL_KINDS:
        return False
    return ratio <= 0.6 and is_short_anchor_label(str(a.get("text") or "")) and is_short_anchor_label(str(b.get("text") or ""))
