from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any

def _repair_loop_limit(env_name: str, default: int) -> int:
    try:
        value = int(_runtime_value(env_name, str(default)))
    except (TypeError, ValueError):
        return default
    return max(1, min(value, 12))

def _env_float(env_name: str, default: float, *, minimum: float = 0.0) -> float:
    try:
        value = float(_runtime_value(env_name, str(default)))
    except (TypeError, ValueError):
        return default
    return max(minimum, value)

def _compact_layout_text(value: Any, limit: int) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    head = limit // 2
    tail = limit - head - 5
    return f"{text[:head]}...{text[-tail:]}"

def _compact_layout_number(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    return f"{number:.3f}".rstrip("0").rstrip(".")

def _task_data_int(task_data: dict | None, key: str) -> int:
    if not isinstance(task_data, dict):
        return 0
    try:
        return int(task_data.get(key, 0) or 0)
    except (TypeError, ValueError):
        return 0

def _probe_timeout() -> int:
    try:
        return int(_runtime_value("LAYOUT_PROBE_TIMEOUT_SEC", "120"))
    except (TypeError, ValueError):
        return 120

def _visual_edge_margin_ratio() -> float:
    try:
        value = float(_runtime_value("LAYOUT_PROBE_VISUAL_EDGE_MARGIN_RATIO", "0.035"))
    except (TypeError, ValueError):
        return 0.035
    return max(0.01, min(value, 0.12))

def _visual_edge_density_threshold() -> float:
    try:
        value = float(_runtime_value("LAYOUT_PROBE_VISUAL_EDGE_DENSITY_THRESHOLD", "0.01"))
    except (TypeError, ValueError):
        return 0.01
    return max(0.001, min(value, 0.25))

def _visual_edge_color_distance() -> float:
    try:
        value = float(_runtime_value("LAYOUT_PROBE_VISUAL_EDGE_COLOR_DISTANCE", "28"))
    except (TypeError, ValueError):
        return 28.0
    return max(5.0, min(value, 120.0))

def _env_bool(name: str, default: bool) -> bool:
    raw = _runtime_value(name, "")
    if not raw:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}

def _env_int(*args, **kwargs):
    from app.workers.validation.layout.runtime_small_helpers import _env_int as _impl
    return _impl(*args, **kwargs)
