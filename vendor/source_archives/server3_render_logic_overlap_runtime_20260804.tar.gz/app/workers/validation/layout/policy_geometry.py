"""几何/坐标轴判定辅助，供布局策略保持轻量。"""

from __future__ import annotations

import re
from typing import Any


TEXTUAL_KINDS = {"text", "formula"}
EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow"}
SHORT_AXIS_TICK_RE = re.compile(r"^-?\d+(?:\.\d+)?$")


def normalize_chemical_fragment(value: Any) -> str:
    text = str(value or "").strip().upper().replace(" ", "")
    text = re.sub(r"\\TEXT\{([^{}]*)\}", r"\1", text)
    text = text.replace("{", "").replace("}", "")
    text = text.replace("\\", "").replace("-", "")
    return re.sub(r"[^A-Z0-9]", "", text)


def bbox_center_gap(a: dict[str, Any], b: dict[str, Any]) -> float:
    box_a = a.get("bbox") if isinstance(a.get("bbox"), dict) else {}
    box_b = b.get("bbox") if isinstance(b.get("bbox"), dict) else {}
    if not box_a or not box_b:
        return 0.0
    dx = _float(box_a.get("center_x")) - _float(box_b.get("center_x"))
    dy = _float(box_a.get("center_y")) - _float(box_b.get("center_y"))
    return (dx * dx + dy * dy) ** 0.5


def looks_like_extended_graph_line(
    obj: dict[str, Any], *, frame: dict[str, Any] | None = None
) -> bool:
    if str(obj.get("kind") or "") != "shape":
        return False
    if str(obj.get("class") or "") not in EXTENDED_LINE_CLASSES:
        return False
    if str(obj.get("text") or "").strip():
        return False
    bbox = obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {}
    if not bbox:
        return False
    width, height = _float(bbox.get("width")), _float(bbox.get("height"))
    if frame:
        frame_width = _float(frame.get("right")) - _float(frame.get("left"))
        frame_height = _float(frame.get("top")) - _float(frame.get("bottom"))
        return (frame_width > 0 and width >= frame_width * 0.85) or (
            frame_height > 0 and height >= frame_height * 1.15
        )
    return max(width, height) >= 7.5 and height >= 4.0


def axes_obj(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any] | None:
    for candidate in (a, b):
        if str(candidate.get("kind") or "") == "shape" and str(
            candidate.get("class") or ""
        ) in {"Axes", "NumberPlane"}:
            return candidate
    return None


def is_common_axes_annotation(text: str) -> bool:
    compact = text.replace(" ", "")
    return bool(
        re.fullmatch(r"[xyXO]", compact)
        or re.fullmatch(r"-?\d+(?:\.\d+)?", compact)
        or re.fullmatch(r"[A-Z][′']{0,2}\(-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?\)", compact)
        or re.fullmatch(r"[A-Z][′']{0,2}\([^()]{1,14}\)", compact)
        or re.fullmatch(r"P[′']{0,2}\([^()]{1,14}\)", compact)
        or re.fullmatch(r"y=x|x=y|y=-x|x=-y|[lmno]", compact, flags=re.I)
    )


def box_mostly_inside(
    inner: dict[str, Any], outer: dict[str, Any], *, margin: float
) -> bool:
    return (
        _float(inner.get("left")) >= _float(outer.get("left")) - margin
        and _float(inner.get("right")) <= _float(outer.get("right")) + margin
        and _float(inner.get("top")) <= _float(outer.get("top")) + margin
        and _float(inner.get("bottom")) >= _float(outer.get("bottom")) - margin
    )


def looks_like_external_axis_tick_container_overlap(
    a: dict[str, Any], b: dict[str, Any]
) -> bool:
    text_obj = a if str(a.get("kind") or "") in TEXTUAL_KINDS else b
    container = b if str(b.get("kind") or "") == "container" else a
    if str(container.get("kind") or "") != "container":
        return False
    text = str(text_obj.get("text") or "").strip().replace(" ", "")
    if not SHORT_AXIS_TICK_RE.match(text):
        return False
    text_box = text_obj.get("bbox") if isinstance(text_obj.get("bbox"), dict) else {}
    container_box = container.get("bbox") if isinstance(container.get("bbox"), dict) else {}
    if not text_box or not container_box:
        return False
    text_width = max(_float(text_box.get("width")), 0.01)
    text_height = max(_float(text_box.get("height")), 0.01)
    return _float(container_box.get("width")) >= max(2.0, text_width * 6.0) and _float(
        container_box.get("height")
    ) >= text_height * 2.0


def _float(value: Any) -> float:
    try:
        return float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0
