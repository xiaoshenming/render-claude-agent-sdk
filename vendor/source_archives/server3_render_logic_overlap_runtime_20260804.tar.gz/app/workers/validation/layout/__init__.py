"""Layout validation and repair helpers for rendered Manim scenes."""
