from __future__ import annotations

import copy
import json
import re
from typing import Any
from . import planner_part2 as _part2
from . import planner_part3 as _part3
from . import planner_part4 as _part4
globals().update({k: v for _module in (_part2, _part3, _part4) for k, v in vars(_module).items() if not k.startswith("__")})

from .schemas import LayoutIssue


LAYOUT_REPAIR_PLAN_SCHEMA_VERSION = "layout_repair_plan.v1"
LAYOUT_PLAN_TARGET_CODES = {
    "layout_overlap_error",
    "layout_frame_overflow",
    "layout_container_overflow",
    "layout_container_border_overlap",
}

_OVERLAP_EVIDENCE_RE = re.compile(
    r"(?P<a>.+?)\s+overlaps\s+(?P<b>.+?);\s*"
    r"overlap_ratio=(?P<overlap_ratio>-?\d+(?:\.\d+)?),\s*"
    r"x_overlap=(?P<x_overlap>-?\d+(?:\.\d+)?),\s*"
    r"y_overlap=(?P<y_overlap>-?\d+(?:\.\d+)?)"
)
_FRAME_OVERFLOW_EVIDENCE_RE = re.compile(
    r"(?P<object>.+?)\s+exceeds\s+frame\s+bounds;\s*"
    r"overflow_x=(?P<overflow_x>-?\d+(?:\.\d+)?),\s*"
    r"overflow_y=(?P<overflow_y>-?\d+(?:\.\d+)?)"
    r"(?:,\s*frame=\[(?P<frame>[^\]]+)\])?"
)



def build_layout_repair_plan(
    issues: list[LayoutIssue | dict[str, Any]],
) -> dict[str, Any]:
    constraints = [
        constraint
        for issue in issues or []
        if (constraint := _constraint_from_issue(issue))
    ]
    scenes = sorted(
        {
            str(constraint.get("scene") or "")
            for constraint in constraints
            if constraint.get("scene")
        }
    )
    primary_actions = _dedupe(
        str(constraint.get("action") or "")
        for constraint in constraints
        if constraint.get("action")
    )
    action_contracts = _dedupe_action_contracts(
        constraint.get("action_contract")
        for constraint in constraints
        if isinstance(constraint.get("action_contract"), dict)
    )
    plan = {
        "schema_version": LAYOUT_REPAIR_PLAN_SCHEMA_VERSION,
        "scene_name": scenes[0] if len(scenes) == 1 else "MULTI_SCENE",
        "scene_names": scenes,
        "issue_count": len(constraints),
        "primary_actions": primary_actions,
        "actions": action_contracts,
        "constraints": constraints,
        "prompt_rules": [
            "Preserve protected geometry labels and mathematical meaning.",
            "Prefer the listed deterministic action before free-form repositioning.",
            "Do not move both objects blindly; keep one anchor stable and move/scale the target.",
        ],
    }
    return {key: value for key, value in plan.items() if value not in (None, [], {})}
def mark_layout_repair_plan_progress(
    plan: dict[str, Any],
    *,
    signature_counts: dict[str, int],
) -> dict[str, Any]:
    marked = copy.deepcopy(plan)
    repeated: list[str] = []
    constraints = marked.get("constraints")
    if not isinstance(constraints, list):
        return marked

    for constraint in constraints:
        if not isinstance(constraint, dict):
            continue
        signature = str(constraint.get("bbox_signature") or "")
        if not signature:
            continue
        count_key = f"{constraint.get('scene') or ''}:{signature}"
        repeat_count = int(signature_counts.get(count_key, 0) or 0) + 1
        signature_counts[count_key] = repeat_count
        constraint["repeat_count"] = repeat_count
        if repeat_count >= 2:
            constraint["repeated_bbox_signature"] = True
            repeated.append(signature)

    if repeated:
        marked["escalation"] = "scene_regenerate_required"
        marked["escalation_reason"] = "same_scene_same_bbox_signature_repeated"
        marked["repeated_bbox_signatures"] = repeated[:8]
    return marked
def layout_repair_plan_to_prompt_context(plan: dict[str, Any] | None) -> str:
    if not isinstance(plan, dict) or not plan.get("constraints"):
        return ""
    lines = [
        "LAYOUT_REPAIR_PLAN",
        f"schema_version={plan.get('schema_version')}",
        f"scene_name={plan.get('scene_name')}",
    ]
    if plan.get("escalation"):
        lines.append(
            f"escalation={plan.get('escalation')} "
            f"reason={plan.get('escalation_reason') or ''}".strip()
        )
    constraints = [
        item for item in plan.get("constraints", []) if isinstance(item, dict)
    ]
    for index, constraint in enumerate(constraints[:6], start=1):
        objects = [
            str(obj.get("label") or "")
            for obj in constraint.get("objects", [])
            if isinstance(obj, dict) and obj.get("label")
        ]
        details = [
            f"{index}. action={constraint.get('action')}",
            f"scene={constraint.get('scene')}",
            f"code={constraint.get('code')}",
        ]
        if objects:
            details.append("objects=" + " vs ".join(objects[:3]))
        for key in (
            "overlap_ratio",
            "x_overlap",
            "y_overlap",
            "overflow_x",
            "overflow_y",
            "axis",
            "direction",
            "min_clearance",
            "scale_hint",
        ):
            if constraint.get(key) is not None:
                details.append(f"{key}={constraint.get(key)}")
        if constraint.get("fallback_actions"):
            details.append(
                "fallback_actions="
                + ",".join(str(item) for item in constraint["fallback_actions"][:4])
            )
        action_contract = constraint.get("action_contract")
        if isinstance(action_contract, dict):
            details.append(f"executable_action={action_contract.get('action')}")
            if action_contract.get("target"):
                details.append(f"target={action_contract.get('target')}")
            if action_contract.get("avoid"):
                details.append(f"avoid={action_contract.get('avoid')}")
            if action_contract.get("expected_gap") is not None:
                details.append(f"expected_gap={action_contract.get('expected_gap')}")
            verification = action_contract.get("verification")
            if isinstance(verification, dict):
                details.append(
                    "verification="
                    + ",".join(
                        f"{key}:{value}"
                        for key, value in verification.items()
                        if value not in (None, "", [], {})
                    )
                )
        if constraint.get("repeated_bbox_signature"):
            details.append(
                f"repeated_bbox_signature=true repeat_count={constraint.get('repeat_count')}"
            )
        lines.append(" | ".join(details))
    return "\n".join(lines)
