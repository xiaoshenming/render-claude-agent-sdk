"""Noise filters and evidence text for layout overlap policy."""

from __future__ import annotations

from typing import Any

from .formula_cancellation import looks_like_formula_cancellation_line_overlap as _formula_cancellation_overlap
from .layout_evidence_text import label
from .layout_label_geometry import TEXTUAL_KINDS
from .policy_geometry import (
    axes_obj, bbox_center_gap, box_mostly_inside, is_common_axes_annotation, normalize_chemical_fragment,
)

EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow", "Brace", "BraceBetweenPoints"}

def _float(value: Any) -> float:
    try: return float(value)
    except (TypeError, ValueError): return 0.0

def bounds_evidence(obj: dict[str, Any], overflow_x: float, overflow_y: float, frame: dict[str, Any]) -> str:
    frame_text = f", frame=[{_float(frame.get('left')):.4f},{_float(frame.get('right')):.4f},{_float(frame.get('bottom')):.4f},{_float(frame.get('top')):.4f}]" if frame else ""
    return f"{label(obj)} exceeds frame bounds; overflow_x={overflow_x:.4f}, overflow_y={overflow_y:.4f}{frame_text}"

def near_collision_evidence(a: dict[str, Any], b: dict[str, Any], metadata: dict[str, Any]) -> str:
    return f"{label(a)} is very close to {label(b)}; gap={_float(metadata.get('gap')):.4f}"

def looks_like_partial_formula_highlight(a: dict[str, Any], b: dict[str, Any]) -> bool:
    text_obj=a if str(a.get('kind') or '') in TEXTUAL_KINDS else b; container=b if str(b.get('kind') or '') == 'container' else a
    if str(container.get('class') or '') != 'SurroundingRectangle' or str(text_obj.get('kind') or '') != 'formula': return False
    text=str(text_obj.get('text') or ''); tb=text_obj.get('bbox') if isinstance(text_obj.get('bbox'),dict) else {}; cb=container.get('bbox') if isinstance(container.get('bbox'),dict) else {}
    if not text or not tb or not cb: return False
    tw=max(_float(tb.get('width')),0.01); th=max(_float(tb.get('height')),0.01)
    return _float(cb.get('width')) < tw*0.9 and _float(cb.get('height')) <= max(0.75,th*1.8)

def looks_like_formula_cancellation_line_overlap(a: dict[str, Any], b: dict[str, Any], *, ratio: float) -> bool:
    return _formula_cancellation_overlap(a,b,ratio=ratio,float_value=_float,line_classes=EXTENDED_LINE_CLASSES)

def looks_like_vertex_label_inside_shape(a: dict[str, Any], b: dict[str, Any]) -> bool:
    text_obj=a if str(a.get('kind') or '') in TEXTUAL_KINDS else b; shape=b if text_obj is a else a
    if str(shape.get('kind') or '') != 'shape': return False
    tv=str(text_obj.get('text') or '').strip(); tb=text_obj.get('bbox') if isinstance(text_obj.get('bbox'),dict) else {}; sb=shape.get('bbox') if isinstance(shape.get('bbox'),dict) else {}
    if not tv or len(tv)>3 or not tb or not sb: return False
    margins=[_float(tb.get('left'))-_float(sb.get('left')),_float(sb.get('right'))-_float(tb.get('right')),_float(sb.get('top'))-_float(tb.get('top')),_float(tb.get('bottom'))-_float(sb.get('bottom'))]
    if min(margins)<0: return False
    return _float(sb.get('width'))*_float(sb.get('height')) >= max(_float(tb.get('width'))*_float(tb.get('height')),1e-6)*10.0

def looks_like_axes_annotation_overlap(a: dict[str, Any], b: dict[str, Any]) -> bool:
    axes=axes_obj(a,b)
    if axes is None: return False
    label_obj=b if axes is a else a; text=str(label_obj.get('text') or '').strip()
    if str(label_obj.get('kind') or '') not in TEXTUAL_KINDS or not text or len(text)>18 or not is_common_axes_annotation(text): return False
    lb=label_obj.get('bbox') if isinstance(label_obj.get('bbox'),dict) else {}; ab=axes.get('bbox') if isinstance(axes.get('bbox'),dict) else {}
    return True if not lb or not ab else box_mostly_inside(lb,ab,margin=0.35)

def looks_like_intentional_water_assembly_overlap(a: dict[str, Any], b: dict[str, Any], *, category: str, ratio: float, metadata: dict[str, Any]) -> bool:
    if category!='text_formula_overlap' or str(metadata.get('event') or '')!='after_play' or ratio<0.3: return False
    if str(a.get('kind') or '') not in TEXTUAL_KINDS or str(b.get('kind') or '') not in TEXTUAL_KINDS: return False
    texts={normalize_chemical_fragment(a.get('text')),normalize_chemical_fragment(b.get('text'))}
    if texts in ({'H','OH'},{'H','OOH'}): return bbox_center_gap(a,b)<=0.8
    if 'H2O' in texts and texts.intersection({'H','OH','OOH','HO'}): return bbox_center_gap(a,b)<=1.0
    return False
