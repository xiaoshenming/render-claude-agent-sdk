from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any

def _legacy_layout_judge_disabled(task_data: dict[str, Any] | None) -> bool:
    return _task_flag_true(
        task_data,
        "_agent_disable_legacy_layout_judge",
        "_disable_legacy_layout_judge",
        "_agent_fast_pre_direct_output",
        "_fast_pre_direct_output",
    )

def _layout_repair_max_llm_calls(max_passes: int) -> int:
    return min(
        max_passes,
        _repair_loop_limit(
            "LAYOUT_REPAIR_MAX_LLM_CALLS_PER_SCENE",
            DEFAULT_REPAIR_MAX_LLM_CALLS_PER_SCENE,
        ),
    )

def _layout_issue_metadata_summary(metadata: dict[str, Any]) -> str:
    if not isinstance(metadata, dict):
        return ""
    parts: list[str] = []
    for key in ("source", "helper", "frame_index", "method", "repair_hint"):
        if metadata.get(key) is not None:
            parts.append(f"{key}={_compact_layout_text(metadata[key], 120)}")
    return ",".join(parts)

def _ast_base_name(node: ast.expr) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Subscript):
        return _ast_base_name(node.value)
    return ""
