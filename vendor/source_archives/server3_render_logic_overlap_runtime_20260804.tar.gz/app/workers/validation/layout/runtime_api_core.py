from __future__ import annotations

__all__ = ["_runtime_value", "_task_flag_true", "_legacy_slice_fixer_repair_disabled", "_layout_mvp_0llm_route_enabled", "_layout_mvp_repair_rounds", "_layout_mvp_probe_from_decision", "_layout_mvp_probe_object", "_layout_mvp_overlap_category", "_layout_mvp_object_is_shape", "_layout_mvp_object_is_textual", "_layout_mvp_actions_from_metadata", "_layout_mvp_round_has_no_patch", "_layout_mvp_is_no_patch_record_only", "_layout_mvp_manifest_metadata", "_layout_overlap_summary", "_layout_blocking_overlap_summary", "_layout_repair_has_blocking_residual", "_layout_repair_quantified_closure", "_layout_repair_has_quantified_improvement", "_layout_repair_requires_quantified_improvement", "_layout_repair_should_fail_fast", "_layout_repair_fail_fast_reason", "_layout_repair_no_improvement_error", "_layout_repair_stubborn_semantic_residual_reason", "_layout_blocking_signature_issues", "_is_protected_record_only_layout_issue", "_clear_protected_record_only_judge_flags", "_layout_recheck_clean_enough", "_layout_issue_error_summary", "_annotate_layout_decision_repair_action_hints", "_layout_issue_with_repair_action_hints", "_layout_issue_payload_with_repair_hints", "_layout_issue_payloads_with_repair_hints", "_layout_quality_issue_payloads_with_repair_hints", "_layout_issue_payloads_for_repair_context", "_attach_layout_repair_plan", "_attach_layout_repair_action_hints", "_layout_issue_get", "_layout_issue_objects"]

def _runtime_value(*args, **kwargs):
    from app.workers.validation.layout.runtime_policy import _runtime_value as _impl
    return _impl(*args, **kwargs)


def _task_flag_true(*args, **kwargs):
    from app.workers.validation.layout.runtime_policy import _task_flag_true as _impl
    return _impl(*args, **kwargs)


def _legacy_slice_fixer_repair_disabled(*args, **kwargs):
    from app.workers.validation.layout.runtime_policy import _legacy_slice_fixer_repair_disabled as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_0llm_route_enabled(*args, **kwargs):
    from app.workers.validation.layout.runtime_policy import _layout_mvp_0llm_route_enabled as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_repair_rounds(*args, **kwargs):
    from app.workers.validation.layout.runtime_policy import _layout_mvp_repair_rounds as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_probe_from_decision(*args, **kwargs):
    from app.workers.validation.layout.runtime_policy import _layout_mvp_probe_from_decision as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_probe_object(*args, **kwargs):
    from app.workers.validation.layout.runtime_probe import _layout_mvp_probe_object as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_overlap_category(*args, **kwargs):
    from app.workers.validation.layout.runtime_probe import _layout_mvp_overlap_category as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_object_is_shape(*args, **kwargs):
    from app.workers.validation.layout.runtime_probe import _layout_mvp_object_is_shape as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_object_is_textual(*args, **kwargs):
    from app.workers.validation.layout.runtime_probe import _layout_mvp_object_is_textual as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_actions_from_metadata(*args, **kwargs):
    from app.workers.validation.layout.runtime_probe import _layout_mvp_actions_from_metadata as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_round_has_no_patch(*args, **kwargs):
    from app.workers.validation.layout.runtime_manifest import _layout_mvp_round_has_no_patch as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_is_no_patch_record_only(*args, **kwargs):
    from app.workers.validation.layout.runtime_manifest import _layout_mvp_is_no_patch_record_only as _impl
    return _impl(*args, **kwargs)


def _layout_mvp_manifest_metadata(*args, **kwargs):
    from app.workers.validation.layout.runtime_manifest import _layout_mvp_manifest_metadata as _impl
    return _impl(*args, **kwargs)




















def _layout_overlap_summary(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_overlap_summary as _impl
    return _impl(*args, **kwargs)


def _layout_blocking_overlap_summary(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_blocking_overlap_summary as _impl
    return _impl(*args, **kwargs)


def _layout_repair_has_blocking_residual(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_has_blocking_residual as _impl
    return _impl(*args, **kwargs)


def _layout_repair_quantified_closure(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_quantified_closure as _impl
    return _impl(*args, **kwargs)


def _layout_repair_has_quantified_improvement(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_has_quantified_improvement as _impl
    return _impl(*args, **kwargs)


def _layout_repair_requires_quantified_improvement(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_requires_quantified_improvement as _impl
    return _impl(*args, **kwargs)


def _layout_repair_should_fail_fast(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_should_fail_fast as _impl
    return _impl(*args, **kwargs)


def _layout_repair_fail_fast_reason(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_fail_fast_reason as _impl
    return _impl(*args, **kwargs)


def _layout_repair_no_improvement_error(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_no_improvement_error as _impl
    return _impl(*args, **kwargs)


def _layout_repair_stubborn_semantic_residual_reason(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_repair_stubborn_semantic_residual_reason as _impl
    return _impl(*args, **kwargs)


def _layout_blocking_signature_issues(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_blocking_signature_issues as _impl
    return _impl(*args, **kwargs)


def _is_protected_record_only_layout_issue(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _is_protected_record_only_layout_issue as _impl
    return _impl(*args, **kwargs)


def _clear_protected_record_only_judge_flags(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _clear_protected_record_only_judge_flags as _impl
    return _impl(*args, **kwargs)


def _layout_recheck_clean_enough(*args, **kwargs):
    from app.workers.validation.layout.runtime_audit import _layout_recheck_clean_enough as _impl
    return _impl(*args, **kwargs)




def _layout_issue_error_summary(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _layout_issue_error_summary as _impl
    return _impl(*args, **kwargs)


def _annotate_layout_decision_repair_action_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _annotate_layout_decision_repair_action_hints as _impl
    return _impl(*args, **kwargs)


def _layout_issue_with_repair_action_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _layout_issue_with_repair_action_hints as _impl
    return _impl(*args, **kwargs)


def _layout_issue_payload_with_repair_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _layout_issue_payload_with_repair_hints as _impl
    return _impl(*args, **kwargs)


def _layout_issue_payloads_with_repair_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _layout_issue_payloads_with_repair_hints as _impl
    return _impl(*args, **kwargs)


def _layout_quality_issue_payloads_with_repair_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _layout_quality_issue_payloads_with_repair_hints as _impl
    return _impl(*args, **kwargs)


def _layout_issue_payloads_for_repair_context(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _layout_issue_payloads_for_repair_context as _impl
    return _impl(*args, **kwargs)


def _attach_layout_repair_plan(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _attach_layout_repair_plan as _impl
    return _impl(*args, **kwargs)


def _attach_layout_repair_action_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_evidence import _attach_layout_repair_action_hints as _impl
    return _impl(*args, **kwargs)














def _layout_issue_get(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _layout_issue_get as _impl
    return _impl(*args, **kwargs)


def _layout_issue_objects(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _layout_issue_objects as _impl
    return _impl(*args, **kwargs)

