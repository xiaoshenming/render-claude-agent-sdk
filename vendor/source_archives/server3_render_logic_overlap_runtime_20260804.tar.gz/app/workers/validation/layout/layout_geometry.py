from __future__ import annotations

from typing import Any


def _round(value: float) -> float:
    return round(float(value), 4)


def _intersection(a: dict[str, float], b: dict[str, float]) -> tuple[float, float, float]:
    x_overlap = min(a["right"], b["right"]) - max(a["left"], b["left"])
    y_overlap = min(a["top"], b["top"]) - max(a["bottom"], b["bottom"])
    if x_overlap <= 0 or y_overlap <= 0:
        return 0.0, 0.0, 0.0
    area = x_overlap * y_overlap
    min_area = min(a["width"] * a["height"], b["width"] * b["height"])
    ratio = area / min_area if min_area > 0 else 0.0
    return _round(x_overlap), _round(y_overlap), _round(ratio)


def _rect_points(box: dict[str, float]) -> list[tuple[float, float]]:
    return [(float(box["left"]), float(box["bottom"])), (float(box["right"]), float(box["bottom"])),
            (float(box["right"]), float(box["top"])), (float(box["left"]), float(box["top"]))]


def _point_in_rect(point: tuple[float, float], box: dict[str, float], *, tolerance: float = 0.0) -> bool:
    x, y = point
    return float(box["left"]) - tolerance <= x <= float(box["right"]) + tolerance and float(box["bottom"]) - tolerance <= y <= float(box["top"]) + tolerance


def _orientation(a, b, c) -> float:
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def _on_segment(a, b, c, *, tolerance: float = 1e-7) -> bool:
    return min(a[0], c[0]) - tolerance <= b[0] <= max(a[0], c[0]) + tolerance and min(a[1], c[1]) - tolerance <= b[1] <= max(a[1], c[1]) + tolerance and abs(_orientation(a, b, c)) <= tolerance


def _segments_intersect(a1, a2, b1, b2) -> bool:
    o1, o2 = _orientation(a1, a2, b1), _orientation(a1, a2, b2)
    o3, o4 = _orientation(b1, b2, a1), _orientation(b1, b2, a2)
    return (o1 * o2 < 0 and o3 * o4 < 0) or _on_segment(a1, b1, a2) or _on_segment(a1, b2, a2) or _on_segment(b1, a1, b2) or _on_segment(b1, a2, b2)


def _rect_edges(box):
    p = _rect_points(box)
    return list(zip(p, p[1:] + p[:1]))


def _point_in_polygon(point, polygon) -> bool:
    inside = False
    x, y = point
    for i, (x1, y1) in enumerate(polygon):
        x2, y2 = polygon[(i + 1) % len(polygon)]
        if _on_segment((x1, y1), point, (x2, y2)):
            return True
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-12) + x1:
            inside = not inside
    return inside


def _line_intersects_rect(points, box) -> bool:
    tuples = [(float(p[0]), float(p[1])) for p in points]
    return len(tuples) >= 2 and any(_point_in_rect(a, box) or _point_in_rect(b, box) or any(_segments_intersect(a, b, x, y) for x, y in _rect_edges(box)) for a, b in zip(tuples, tuples[1:]))


def _polygon_intersects_rect(geometry: dict[str, Any], box: dict[str, float]) -> bool:
    points = [(float(p[0]), float(p[1])) for p in geometry.get("points", [])]
    if len(points) < 3:
        return False
    edges = _rect_edges(box)
    if any(_point_in_rect(a, box) or any(_segments_intersect(a, b, x, y) for x, y in edges) for a, b in zip(points, points[1:] + points[:1])):
        return True
    return bool(geometry.get("filled")) and (any(_point_in_polygon(p, points) for p in _rect_points(box)) or any(_point_in_rect(p, box) for p in points))
