"""Frame-bound overflow issue construction."""

from __future__ import annotations

from typing import Any

from .layout_overlap_noise import bounds_evidence
from .policy_geometry import looks_like_extended_graph_line
from .schemas import LayoutIssue

TEXTUAL_KINDS={"text","formula"}
FRAME_BOUNDS_KINDS=TEXTUAL_KINDS|{"container","shape","group"}
LINE_LIKE_FRAME_REPAIR_CLASSES={"Line","DashedLine","Arrow","DoubleArrow","Brace","BraceBetweenPoints"}

def _float(value: Any) -> float:
    try: return float(value)
    except (TypeError, ValueError): return 0.0

def issue_from_bounds_violation(scene_name: str, violation: dict[str, Any]) -> LayoutIssue | None:
    if str(violation.get("category") or "") != "frame_bounds_overflow": return None
    obj=violation.get("object") if isinstance(violation.get("object"),dict) else {}; kind=str(obj.get("kind") or '')
    if kind not in FRAME_BOUNDS_KINDS: return None
    ox=_float(violation.get("overflow_x")); oy=_float(violation.get("overflow_y")); overflow=max(ox,oy)
    if overflow<=0: return None
    frame=violation.get("frame") if isinstance(violation.get("frame"),dict) else {}
    if looks_like_extended_graph_line(obj, frame=frame): return None
    metadata={"category":"frame_bounds_overflow","frame":frame,"sides":violation.get("sides") or [],"event":violation.get("event"),"step":violation.get("step")}
    if str(metadata.get("event") or '')=='after_play' and kind in TEXTUAL_KINDS:
        return LayoutIssue(code="layout_overlap_risk",severity="low" if overflow<0.5 else "medium",confidence=min(0.85,0.45+overflow),scene_name=scene_name,evidence=bounds_evidence(obj,ox,oy,frame),overlap_ratio=0.0,x_overlap=ox,y_overlap=oy,objects=[obj],repairable=False,deterministic_repairable=False,needs_llm_judge=False,suggested_fix="中间动画帧的文字/公式短暂越界只记录风险；最终停留态仍越界时再修复。",metadata={**metadata,"transient_after_play":True})
    obj_class=str(obj.get("class") or ''); visual=kind in {"shape","group"}; line_like=visual and obj_class in LINE_LIKE_FRAME_REPAIR_CLASSES
    return LayoutIssue(code="layout_frame_overflow",severity="high" if overflow>=0.12 else "medium",confidence=min(0.99,0.76+overflow),scene_name=scene_name,evidence=bounds_evidence(obj,ox,oy,frame),overlap_ratio=0.0,x_overlap=ox,y_overlap=oy,objects=[obj],repairable=True,deterministic_repairable=not visual or line_like,suggested_fix=("将超出画幅的图形/组合整体缩放或平移回安全画幅，保持数学结构和相对位置不变。" if visual else "将超出画幅的文字/公式/信息框移回安全画幅，优先做小幅反向 shift。"),metadata=metadata)
