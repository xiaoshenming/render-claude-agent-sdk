from __future__ import annotations

__all__ = ["_issue_number_from_fields_or_parsed", "_overlap_labels", "_choose_layout_action_target", "_frame_overflow_target", "_layout_object_label", "_layout_label_is_textual", "_layout_label_is_diagram_anchor", "_needs_clear_zone_overlap_repair", "_clear_zone_for_overlap_target", "_object_has_bbox", "_frame_from_issue_or_parsed", "_shift_inside_frame_direction", "_clean_layout_geometry", "_font_scale_hint", "_frame_scale_hint", "_round_layout_float", "_layout_issue_list_signature", "_layout_issue_semantic_signature", "_slice_repair_method_info", "_parse_probe_stdout", "_probe_runtime_error_is_repairable", "_probe_runtime_error_is_internal", "_decision_from_probe_result", "_needs_visual_probe_fallback", "_annotate_internal_probe_fallback", "_detect_edge_overflow_in_image", "_record_task_data", "_record_render_log", "_compact_layout_bbox", "_compact_layout_object", "_layout_issue_signature", "_layout_repair_residual_issue_top3", "_apply_cross_scene_dedup", "_record_layout_repair_event", "_merge_shared_layout_repair_changes", "_layout_action_hints_summary", "_frame_overflow_action_hints", "_overlap_action_hints", "_render_canvas_profile_metadata"]

def _issue_number_from_fields_or_parsed(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _issue_number_from_fields_or_parsed as _impl
    return _impl(*args, **kwargs)


def _overlap_labels(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _overlap_labels as _impl
    return _impl(*args, **kwargs)


def _choose_layout_action_target(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _choose_layout_action_target as _impl
    return _impl(*args, **kwargs)


def _frame_overflow_target(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _frame_overflow_target as _impl
    return _impl(*args, **kwargs)


def _layout_object_label(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _layout_object_label as _impl
    return _impl(*args, **kwargs)


def _layout_label_is_textual(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _layout_label_is_textual as _impl
    return _impl(*args, **kwargs)


def _layout_label_is_diagram_anchor(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _layout_label_is_diagram_anchor as _impl
    return _impl(*args, **kwargs)


def _needs_clear_zone_overlap_repair(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _needs_clear_zone_overlap_repair as _impl
    return _impl(*args, **kwargs)


def _clear_zone_for_overlap_target(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _clear_zone_for_overlap_target as _impl
    return _impl(*args, **kwargs)


def _object_has_bbox(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _object_has_bbox as _impl
    return _impl(*args, **kwargs)


def _frame_from_issue_or_parsed(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _frame_from_issue_or_parsed as _impl
    return _impl(*args, **kwargs)


def _shift_inside_frame_direction(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _shift_inside_frame_direction as _impl
    return _impl(*args, **kwargs)


def _clean_layout_geometry(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _clean_layout_geometry as _impl
    return _impl(*args, **kwargs)


def _font_scale_hint(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _font_scale_hint as _impl
    return _impl(*args, **kwargs)


def _frame_scale_hint(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _frame_scale_hint as _impl
    return _impl(*args, **kwargs)


def _round_layout_float(*args, **kwargs):
    from app.workers.validation.layout.runtime_issue_metadata import _round_layout_float as _impl
    return _impl(*args, **kwargs)












def _layout_issue_list_signature(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _layout_issue_list_signature as _impl
    return _impl(*args, **kwargs)


def _layout_issue_semantic_signature(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _layout_issue_semantic_signature as _impl
    return _impl(*args, **kwargs)


def _slice_repair_method_info(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _slice_repair_method_info as _impl
    return _impl(*args, **kwargs)


def _parse_probe_stdout(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _parse_probe_stdout as _impl
    return _impl(*args, **kwargs)


def _probe_runtime_error_is_repairable(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _probe_runtime_error_is_repairable as _impl
    return _impl(*args, **kwargs)


def _probe_runtime_error_is_internal(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _probe_runtime_error_is_internal as _impl
    return _impl(*args, **kwargs)


def _decision_from_probe_result(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _decision_from_probe_result as _impl
    return _impl(*args, **kwargs)


def _needs_visual_probe_fallback(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _needs_visual_probe_fallback as _impl
    return _impl(*args, **kwargs)


def _annotate_internal_probe_fallback(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _annotate_internal_probe_fallback as _impl
    return _impl(*args, **kwargs)


def _detect_edge_overflow_in_image(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _detect_edge_overflow_in_image as _impl
    return _impl(*args, **kwargs)


def _record_task_data(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _record_task_data as _impl
    return _impl(*args, **kwargs)


def _record_render_log(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _record_render_log as _impl
    return _impl(*args, **kwargs)


def _compact_layout_bbox(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _compact_layout_bbox as _impl
    return _impl(*args, **kwargs)


def _compact_layout_object(*args, **kwargs):
    from app.workers.validation.layout.runtime_signatures import _compact_layout_object as _impl
    return _impl(*args, **kwargs)


















def _layout_issue_signature(*args, **kwargs):
    from app.workers.validation.layout.runtime_contract import _layout_issue_signature as _impl
    return _impl(*args, **kwargs)


def _layout_repair_residual_issue_top3(*args, **kwargs):
    from app.workers.validation.layout.runtime_contract import _layout_repair_residual_issue_top3 as _impl
    return _impl(*args, **kwargs)


def _apply_cross_scene_dedup(*args, **kwargs):
    from app.workers.validation.layout.runtime_repair_events import _apply_cross_scene_dedup as _impl
    return _impl(*args, **kwargs)


def _record_layout_repair_event(*args, **kwargs):
    from app.workers.validation.layout.runtime_repair_events import _record_layout_repair_event as _impl
    return _impl(*args, **kwargs)


def _merge_shared_layout_repair_changes(*args, **kwargs):
    from app.workers.validation.layout.runtime_repair_events import _merge_shared_layout_repair_changes as _impl
    return _impl(*args, **kwargs)


def _layout_action_hints_summary(*args, **kwargs):
    from app.workers.validation.layout.runtime_action_hints import _layout_action_hints_summary as _impl
    return _impl(*args, **kwargs)


def _frame_overflow_action_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_action_hints import _frame_overflow_action_hints as _impl
    return _impl(*args, **kwargs)


def _overlap_action_hints(*args, **kwargs):
    from app.workers.validation.layout.runtime_action_hints import _overlap_action_hints as _impl
    return _impl(*args, **kwargs)


def _render_canvas_profile_metadata(*args, **kwargs):
    from app.workers.validation.layout.runtime_quality_contract import _render_canvas_profile_metadata as _impl
    return _impl(*args, **kwargs)

