from __future__ import annotations

import ast
from dataclasses import dataclass


COMMON_HELPER_RISK_NAMES = frozenset(
    {
        "asset_icon",
        "build_card",
        "build_cjk_math_line",
        "clamp_to_canvas",
        "create_3d_label",
        "create_card",
        "create_formula",
        "create_right_angle_mark",
        "create_text",
        "draw_right_angle_mark",
        "fit_to_canvas",
        "fit_to_width",
        "fw",
        "get_color",
        "get_rearranged_sectors",
        "get_sectors",
        "icon_card",
        "icon_row",
        "init_tts",
        "inline_math_text",
        "layout_canvas",
        "make_formula",
        "make_fraction_rectangle",
        "make_labeled_triangle",
        "make_point_with_label",
        "make_title",
        "narrate",
        "place_non_overlapping",
        "play_steps_evenly",
        "play_synced_steps",
        "play_voiceover",
        "portrait_formula",
        "portrait_title",
        "safe_formula",
        "safe_group",
        "safe_math_box",
        "safe_tex",
        "safe_text",
        "safe_text_box",
        "show_text",
        "wait_for_voiceover_remaining",
        "wait_until_bookmark",
    }
)


@dataclass(frozen=True)
class HelperContractResult:
    ok: bool
    missing_helpers: tuple[str, ...]
    defined_helpers: tuple[str, ...]


def check_helper_contract(code: str) -> HelperContractResult:
    tree = ast.parse(code)
    defined_helpers = _collect_defined_names(tree)
    called_helpers = _collect_called_helper_names(tree)
    missing_helpers = tuple(
        sorted(
            name
            for name in called_helpers
            if name in COMMON_HELPER_RISK_NAMES and name not in defined_helpers
        )
    )
    return HelperContractResult(
        ok=not missing_helpers,
        missing_helpers=missing_helpers,
        defined_helpers=tuple(sorted(defined_helpers & COMMON_HELPER_RISK_NAMES)),
    )


def _collect_defined_names(tree: ast.AST) -> set[str]:
    defined: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            defined.add(node.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                defined.add(alias.asname or alias.name.split(".", 1)[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name != "*":
                    defined.add(alias.asname or alias.name)
    return defined


def _collect_called_helper_names(tree: ast.AST) -> set[str]:
    called: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            called.add(node.func.id)
    return called
