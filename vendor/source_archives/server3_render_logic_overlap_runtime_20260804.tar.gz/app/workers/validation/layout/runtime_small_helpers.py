from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _layout_pre_render_color_scheme(ctx) -> int:
    task_data = getattr(ctx, "task_data", None)
    candidates = [
        getattr(ctx, "color_scheme", None),
        task_data.get("color_scheme") if isinstance(task_data, dict) else None,
    ]
    for value in candidates:
        try:
            return int(value)
        except (TypeError, ValueError):
            continue
    return 1

def _layout_repair_budget() -> _RepairBudget:
    max_passes = _repair_loop_limit(
        "LAYOUT_REPAIR_LLM_MAX_PASSES",
        DEFAULT_REPAIR_MAX_PASSES,
    )
    inner_retries = _repair_loop_limit(
        "LAYOUT_REPAIR_LLM_INNER_RETRIES",
        DEFAULT_REPAIR_INNER_RETRIES,
    )
    return _RepairBudget(
        max_passes=max_passes,
        inner_retries=inner_retries,
        max_llm_calls_per_scene=_layout_repair_max_llm_calls(max_passes),
    )

def _should_sync_llm_layout_judge(decision: LayoutDecision) -> bool:
    """Only block on LLM layout judge for deterministic hard layout findings."""
    for issue in decision.issues:
        if _is_protected_record_only_layout_issue(issue):
            continue
        if not issue.needs_llm_judge:
            continue
        if issue.code in _LAYOUT_HARD_ERROR_CODES:
            return True
        if issue.repairable and issue.severity == "high":
            return True
        if issue.overlap_ratio >= _sync_llm_overlap_threshold():
            return True
    return False

def _record_soft_layout_note(
    task_data: dict | None,
    decision: LayoutDecision,
) -> None:
    if not isinstance(task_data, dict):
        return
    pending = [issue for issue in decision.issues if issue.needs_llm_judge]
    notes = task_data.setdefault("_layout_async_notes", [])
    notes.append({
        "scene_name": decision.scene_name,
        "reason": "soft_layout_risk",
        "issue_count": len(pending),
        "issues": [issue.to_dict() for issue in pending[:10]],
    })

def _parse_overlap_evidence(evidence: str) -> dict[str, Any]:
    match = _OVERLAP_EVIDENCE_RE.search(evidence or "")
    if not match:
        return {}
    return {
        "a": match.group("a").strip(),
        "b": match.group("b").strip(),
        "overlap_ratio": _round_layout_float(match.group("overlap_ratio")),
        "x_overlap": _round_layout_float(match.group("x_overlap")),
        "y_overlap": _round_layout_float(match.group("y_overlap")),
    }

def _record_layout_render_fix_count(
    task_data: dict | None,
    *,
    render_fix_baseline: int | None = None,
) -> None:
    if not isinstance(task_data, dict):
        return
    task_data["_layout_render_fix_count"] = (
        _task_data_int(task_data, "_layout_render_fix_count") + 1
    )
    if render_fix_baseline is None:
        return
    current = _task_data_int(task_data, "_render_fix_count")
    if current <= render_fix_baseline:
        task_data["_render_fix_count"] = render_fix_baseline + 1

def _env_int(
    name: str,
    default: int,
    *,
    minimum: int,
    maximum: int | None = None,
) -> int:
    try:
        value = int(_runtime_value(name, str(default)))
    except (TypeError, ValueError):
        return default
    value = max(minimum, value)
    return min(value, maximum) if maximum is not None else value

def _attach_render_canvas_profile_metadata(
    raw: dict,
    *,
    aspect_ratio: str,
) -> dict:
    payload = dict(raw or {})
    profile_metadata = _render_canvas_profile_metadata(aspect_ratio)
    metadata_value = payload.get("metadata")
    metadata = dict(metadata_value) if isinstance(metadata_value, dict) else {}
    metadata["render_canvas_profile"] = profile_metadata
    payload["metadata"] = metadata
    payload["render_canvas_profile"] = profile_metadata
    return payload

def _extract_render_canvas_profile_metadata(raw: dict) -> dict[str, Any]:
    profile = raw.get("render_canvas_profile") if isinstance(raw, dict) else None
    if isinstance(profile, dict):
        return dict(profile)
    metadata = raw.get("metadata") if isinstance(raw, dict) else None
    if isinstance(metadata, dict) and isinstance(
        metadata.get("render_canvas_profile"),
        dict,
    ):
        return dict(metadata["render_canvas_profile"])
    return {}

def _should_cross_scene_dedup(issue: LayoutIssue) -> bool:
    if issue.code != "layout_frame_overflow":
        return True
    for obj in issue.objects or []:
        if not isinstance(obj, dict):
            continue
        if str(obj.get("kind") or "") in {"shape", "group"}:
            return False
    return True
