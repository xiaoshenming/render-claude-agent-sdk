from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _layout_issue_get(issue: LayoutIssue | dict[str, Any], key: str) -> Any:
    if isinstance(issue, LayoutIssue):
        return getattr(issue, key, None)
    if isinstance(issue, dict):
        return issue.get(key)
    return None


def _layout_issue_objects(issue: LayoutIssue | dict[str, Any]) -> list[dict[str, Any]]:
    objects = _layout_issue_get(issue, "objects")
    if not isinstance(objects, list):
        return []
    return [obj for obj in objects if isinstance(obj, dict)]


def _issue_number_from_fields_or_parsed(
    issue: LayoutIssue | dict[str, Any],
    field: str,
    parsed: dict[str, Any],
    *,
    parsed_key: str | None = None,
) -> float:
    value = _round_layout_float(_layout_issue_get(issue, field))
    if value:
        return value
    return _round_layout_float(parsed.get(parsed_key or field))


def _overlap_labels(
    objects: list[dict[str, Any]],
    parsed: dict[str, Any],
) -> list[str]:
    labels = [_layout_object_label(obj) for obj in objects[:2]]
    labels = [label for label in labels if label]
    if len(labels) >= 2:
        return labels
    parsed_labels = [
        str(parsed.get("a") or "").strip(),
        str(parsed.get("b") or "").strip(),
    ]
    return [label for label in parsed_labels if label]


def _choose_layout_action_target(
    objects: list[dict[str, Any]],
    labels: list[str],
) -> tuple[str, str]:
    if len(objects) >= 2:
        for index, obj in enumerate(objects[:2]):
            if str(obj.get("kind") or "") in {"text", "formula"}:
                other_index = 1 - index
                return labels[index], labels[other_index]
        for index, obj in enumerate(objects[:2]):
            if _layout_label_is_textual(_layout_object_label(obj)):
                other_index = 1 - index
                return labels[index], labels[other_index]
    for index, label in enumerate(labels[:2]):
        if _layout_label_is_textual(label):
            other_index = 1 - index
            return label, labels[other_index]
    if len(labels) >= 2:
        return labels[1], labels[0]
    return labels[0], "overlapping_object"


def _frame_overflow_target(
    objects: list[dict[str, Any]],
    parsed: dict[str, Any],
) -> str:
    if objects:
        return _layout_object_label(objects[0])
    return str(parsed.get("object") or "object")


def _layout_object_label(obj: dict[str, Any]) -> str:
    text = str(obj.get("text") or "").strip()
    cls = str(obj.get("class") or obj.get("kind") or obj.get("name") or "object")
    return f"{cls}({text[:80]})" if text else cls


def _layout_label_is_textual(label: str) -> bool:
    text = str(label or "")
    return any(name in text for name in ("Text", "Tex", "MathTex", "MarkupText"))


def _layout_label_is_diagram_anchor(label: str) -> bool:
    text = str(label or "")
    return any(
        name in text
        for name in (
            "Line",
            "Polygon",
            "Square",
            "Circle",
            "Arrow",
            "Axes",
            "NumberPlane",
            "Angle",
        )
    )


def _needs_clear_zone_overlap_repair(labels: list[str], overlap_ratio: float) -> bool:
    if overlap_ratio < 0.45:
        return False
    return any(_layout_label_is_textual(label) for label in labels) and any(
        _layout_label_is_diagram_anchor(label) for label in labels
    )


def _clear_zone_for_overlap_target(target: str) -> str:
    if "MathTex" in str(target or "") or "Tex" in str(target or ""):
        return "formula_zone"
    if "Text" in str(target or "") or "MarkupText" in str(target or ""):
        return "caption_zone"
    return "diagram_outer_label_zone"


def _object_has_bbox(objects: list[dict[str, Any]]) -> bool:
    return any(isinstance(obj.get("bbox"), dict) and obj.get("bbox") for obj in objects)


def _frame_from_issue_or_parsed(
    issue: LayoutIssue | dict[str, Any],
    parsed: dict[str, Any],
) -> list[float] | None:
    metadata = _layout_issue_get(issue, "metadata")
    frame = metadata.get("frame") if isinstance(metadata, dict) else None
    if isinstance(frame, dict):
        values = [
            _round_layout_float(frame.get("left")),
            _round_layout_float(frame.get("right")),
            _round_layout_float(frame.get("bottom")),
            _round_layout_float(frame.get("top")),
        ]
        if any(values):
            return values
    parsed_frame = parsed.get("frame")
    if isinstance(parsed_frame, list) and len(parsed_frame) == 4:
        return parsed_frame
    return None


def _shift_inside_frame_direction(
    objects: list[dict[str, Any]],
    frame: list[float] | None,
) -> str:
    if not objects or not frame:
        return "inside_frame"
    bbox = objects[0].get("bbox") if isinstance(objects[0].get("bbox"), dict) else {}
    if not bbox:
        return "inside_frame"
    frame_left, frame_right, frame_bottom, frame_top = frame
    directions: list[str] = []
    if _round_layout_float(bbox.get("right")) > frame_right:
        directions.append("LEFT")
    if _round_layout_float(bbox.get("left")) < frame_left:
        directions.append("RIGHT")
    if _round_layout_float(bbox.get("top")) > frame_top:
        directions.append("DOWN")
    if _round_layout_float(bbox.get("bottom")) < frame_bottom:
        directions.append("UP")
    return "+".join(directions) if directions else "inside_frame"


def _clean_layout_geometry(value: dict[str, Any]) -> dict[str, Any]:
    return {key: item for key, item in value.items() if item is not None}


def _font_scale_hint(overlap_ratio: float) -> float:
    if overlap_ratio >= 0.45:
        return 0.84
    if overlap_ratio >= 0.3:
        return 0.88
    return 0.92


def _frame_scale_hint(overflow_x: float, overflow_y: float) -> float:
    overflow = max(abs(overflow_x), abs(overflow_y))
    if overflow >= 0.35:
        return 0.86
    if overflow >= 0.18:
        return 0.9
    return 0.94


def _round_layout_float(value: Any, digits: int = 4) -> float:
    try:
        return round(float(value), digits)
    except (TypeError, ValueError):
        return 0.0


