from __future__ import annotations

import re
from typing import Any

from .schemas import LayoutDecision, LayoutIssue
from .formula_cancellation import looks_like_formula_cancellation_line_overlap
from .overlap_metadata import overlap_metadata
from .policy_geometry import (
    axes_obj as _axes_obj,
    bbox_center_gap as _bbox_center_gap,
    box_mostly_inside as _box_mostly_inside,
    is_common_axes_annotation as _is_common_axes_annotation,
    looks_like_extended_graph_line as _looks_like_extended_graph_line,
    looks_like_external_axis_tick_container_overlap as _looks_like_external_axis_tick_container_overlap,
    normalize_chemical_fragment as _normalize_chemical_fragment,
)
from .layout_label_geometry import (
    contains_protected_geometry_label as _contains_protected_geometry_label,
    is_protected_geometry_label as _is_protected_geometry_label,
    is_short_anchor_label as _is_short_anchor_label,
    looks_like_anchored_short_label_pair as _looks_like_anchored_short_label_pair,
    looks_like_probe_duplicate_textual_pair as _looks_like_probe_duplicate_textual_pair,
    looks_like_protected_geometry_label_pair as _looks_like_protected_geometry_label_pair,
    normalize_label_text as _normalize_label_text,
)
from .layout_evidence_text import (
    evidence as _evidence,
    label as _label,
    suggest_container_fix as _suggest_container_fix,
    suggest_fix as _suggest_fix,
)
from .layout_container_evidence import text_bbox_inside_container as _text_bbox_inside_container


TEXTUAL_KINDS = {"text", "formula"}
FRAME_BOUNDS_KINDS = TEXTUAL_KINDS | {"container", "shape", "group"}
DIRECT_ERROR_THRESHOLD = 0.30
# 文字/公式互相之间的重叠：阈值更严格，>=0.15 直接升级为 error 触发自动修复。
# 0.30 这个阈值漏掉了诸如 "Text(slot3) ↔ MathTex(slot4)" 比例 0.20~0.25 的真重叠。
TEXTUAL_PAIR_ERROR_THRESHOLD = 0.15
TEXTUAL_RISK_THRESHOLD = 0.10
TEXT_SHAPE_ERROR_THRESHOLD = 0.35
TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD = 0.55
LAYOUT_ERROR_CODES = {
    "layout_overlap_error",
    "layout_container_overflow",
    "layout_frame_overflow",
}
LAYOUT_RISK_CODES = {"layout_overlap_risk", "layout_container_border_overlap"}
SHORT_AXIS_TICK_RE = re.compile(r"^-?\d+(?:\.\d+)?$")
EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow"}
LINE_LIKE_FRAME_REPAIR_CLASSES = EXTENDED_LINE_CLASSES | {
    "Brace",
    "BraceBetweenPoints",
}


def apply_layout_policy(
    *,
    mode: str,
    scene_name: str,
    overlaps: list[dict[str, Any]],
    bounds_violations: list[dict[str, Any]] | None = None,
    latency_ms: int = 0,
    artifact_path: str | None = None,
) -> LayoutDecision:
    normalized_mode = (mode or "shadow").strip().lower()
    if normalized_mode not in {"off", "shadow", "repair", "block"}:
        normalized_mode = "shadow"

    issues: list[LayoutIssue] = []
    for overlap in overlaps:
        issue = _issue_from_overlap(scene_name, overlap)
        if issue:
            issues.append(issue)
    for violation in bounds_violations or []:
        issue = _issue_from_bounds_violation(scene_name, violation)
        if issue:
            issues.append(issue)

    errors = [issue for issue in issues if issue.code in LAYOUT_ERROR_CODES]
    risks = [issue for issue in issues if issue.code in LAYOUT_RISK_CODES]
    repairable = [issue for issue in issues if issue.repairable]

    final_action = "record_only"
    if normalized_mode == "repair" and repairable:
        final_action = "repair_candidate"
    elif normalized_mode == "block" and errors:
        final_action = "block_candidate"

    return LayoutDecision(
        mode=normalized_mode,
        scene_name=scene_name,
        final_action=final_action,
        issues=issues,
        latency_ms=latency_ms,
        needs_repair=final_action == "repair_candidate",
        layout_error_count=len(errors),
        layout_risk_count=len(risks),
        artifact_path=artifact_path,
    )


from .policy_overlap_issue import _issue_from_overlap



def _overlap_metadata(overlap: dict[str, Any]) -> dict[str, Any]:
    return overlap_metadata(overlap)

from .layout_bounds_issue import issue_from_bounds_violation as _issue_from_bounds_violation


from .layout_overlap_noise import (
    bounds_evidence as _bounds_evidence,
    near_collision_evidence as _near_collision_evidence,
    looks_like_partial_formula_highlight as _looks_like_partial_formula_highlight,
    looks_like_formula_cancellation_line_overlap as _looks_like_formula_cancellation_line_overlap,
    looks_like_vertex_label_inside_shape as _looks_like_vertex_label_inside_shape,
    looks_like_axes_annotation_overlap as _looks_like_axes_annotation_overlap,
    looks_like_intentional_water_assembly_overlap as _looks_like_intentional_water_assembly_overlap,
)

def _is_after_play_event(metadata: dict[str, Any]) -> bool:
    return str(metadata.get("event") or "") == "after_play"


def _transient_after_play_risk_issue(
    *,
    scene_name: str,
    a: dict[str, Any],
    b: dict[str, Any],
    ratio: float,
    x_overlap: float,
    y_overlap: float,
    metadata: dict[str, Any],
    suggested_fix: str | None = None,
) -> LayoutIssue:
    severity = "medium" if ratio >= DIRECT_ERROR_THRESHOLD else "low"
    return LayoutIssue(
        code="layout_overlap_risk",
        severity=severity,
        confidence=min(0.9, 0.5 + ratio / 2.0),
        scene_name=scene_name,
        evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
        overlap_ratio=ratio,
        x_overlap=x_overlap,
        y_overlap=y_overlap,
        objects=[a, b],
        repairable=False,
        deterministic_repairable=False,
        needs_llm_judge=False,
        suggested_fix=(
            suggested_fix
            or "中间动画帧的文字/公式重叠只记录风险；最终停留态仍重叠时再触发布局修复。"
        ),
        metadata={**metadata, "transient_after_play": True},
    )


from .layout_visual_occlusion import (
    strong_text_shape_occlusion_metadata as _strong_text_shape_occlusion_metadata,
    union_bbox as _union_bbox,
)
from .layout_visual_occlusion import _float as _float
