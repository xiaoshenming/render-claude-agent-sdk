"""Layout issue signatures and no-progress state tracking."""

import hashlib
from typing import Any, Callable


def issue_signature(
    issues: list[dict[str, Any]] | None,
    constraint_parser: Callable[[dict[str, Any]], dict[str, Any] | None],
) -> str:
    parts: list[str] = []
    for issue in issues or []:
        if not isinstance(issue, dict):
            continue
        objects = issue.get("objects") or []
        names = [
            str(obj.get("text") or obj.get("class") or obj.get("name") or "")
            for obj in objects if isinstance(obj, dict)
        ]
        parsed = constraint_parser(issue) or {}
        parts.append("|".join([
            str(issue.get("code") or ""),
            " ".join(str(issue.get("evidence") or "").split())[:180],
            ",".join(names[:2]),
            str(parsed.get("overlap_ratio") or parsed.get("overflow_x") or ""),
            str(parsed.get("x_overlap") or parsed.get("overflow_y") or ""),
        ]))
    source = "\n".join(sorted(part for part in parts if part.strip("|,")))
    return hashlib.sha256(source.encode("utf-8", "replace")).hexdigest()[:16] if source else ""


def record_no_progress(
    task_data: dict[str, Any] | None, *, scene_name: str,
    signature: str, threshold: int = 2,
) -> dict[str, Any]:
    if not signature:
        return {"no_progress": False, "signature": "", "hit_count": 0, "threshold": threshold}
    if task_data is None:
        return {"no_progress": False, "signature": signature, "hit_count": 1, "threshold": threshold}
    store = task_data.setdefault("_layout_repair_signature_hits", {})
    if not isinstance(store, dict):
        store = {}
        task_data["_layout_repair_signature_hits"] = store
    key = f"{scene_name}:{signature}"
    hit_count = int(store.get(key) or 0) + 1
    store[key] = hit_count
    result = {
        "no_progress": hit_count >= max(1, threshold), "signature": signature,
        "hit_count": hit_count, "threshold": max(1, threshold),
    }
    if result["no_progress"]:
        task_data["_layout_repair_no_progress"] = {"scene_name": scene_name, **result}
    return result
