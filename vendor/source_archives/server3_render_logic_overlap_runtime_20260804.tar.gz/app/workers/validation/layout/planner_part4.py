from __future__ import annotations

import copy
import json
import re
from typing import Any

from .schemas import LayoutIssue


LAYOUT_REPAIR_PLAN_SCHEMA_VERSION = "layout_repair_plan.v1"
LAYOUT_PLAN_TARGET_CODES = {
    "layout_overlap_error",
    "layout_frame_overflow",
    "layout_container_overflow",
    "layout_container_border_overlap",
}

_OVERLAP_EVIDENCE_RE = re.compile(
    r"(?P<a>.+?)\s+overlaps\s+(?P<b>.+?);\s*"
    r"overlap_ratio=(?P<overlap_ratio>-?\d+(?:\.\d+)?),\s*"
    r"x_overlap=(?P<x_overlap>-?\d+(?:\.\d+)?),\s*"
    r"y_overlap=(?P<y_overlap>-?\d+(?:\.\d+)?)"
)
_FRAME_OVERFLOW_EVIDENCE_RE = re.compile(
    r"(?P<object>.+?)\s+exceeds\s+frame\s+bounds;\s*"
    r"overflow_x=(?P<overflow_x>-?\d+(?:\.\d+)?),\s*"
    r"overflow_y=(?P<overflow_y>-?\d+(?:\.\d+)?)"
    r"(?:,\s*frame=\[(?P<frame>[^\]]+)\])?"
)



def _clear_zone_for_objects(objects: list[dict[str, Any]]) -> str:
    kinds = {str(obj.get("kind") or "") for obj in objects}
    roles = {str(obj.get("role") or "") for obj in objects}
    if "formula" in kinds or "formula" in roles:
        return "formula_zone"
    if "label" in roles:
        return "diagram_outer_label_zone"
    return "caption_zone"
def _object_constraint(obj: dict[str, Any]) -> dict[str, Any]:
    label = _object_label(obj)
    bbox = _bbox(obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {})
    return {
        "label": label,
        "role": _object_role(obj),
        "kind": str(obj.get("kind") or ""),
        "class": str(obj.get("class") or ""),
        "text": _compact_text(obj.get("text"), 120),
        "bbox": bbox,
    }
def _object_label(obj: dict[str, Any]) -> str:
    text = str(obj.get("text") or "").strip()
    cls = str(obj.get("class") or obj.get("kind") or obj.get("name") or "object")
    return f"{cls}({text[:80]})" if text else cls
def _object_role(obj: dict[str, Any]) -> str:
    kind = str(obj.get("kind") or "")
    cls = str(obj.get("class") or "")
    text = str(obj.get("text") or "").strip()
    if kind in {"text", "formula"}:
        if len(text) <= 8:
            return "label"
        if kind == "formula" or cls in {"MathTex", "Tex"}:
            return "formula"
        return "explanation_text"
    if kind == "container":
        return "container"
    if kind == "group" or cls in {"VGroup", "Group"}:
        return "group"
    if kind == "shape":
        return "main_diagram"
    return kind or "object"
def _bbox(bbox: dict[str, Any]) -> dict[str, float]:
    result = {
        key: _round_float(bbox.get(key))
        for key in (
            "left",
            "right",
            "top",
            "bottom",
            "width",
            "height",
            "center_x",
            "center_y",
        )
        if bbox.get(key) is not None
    }
    return {key: value for key, value in result.items() if value is not None}
def _bbox_signature(
    scene: str,
    code: str,
    objects: list[dict[str, Any]],
    metrics: dict[str, float],
) -> str:
    object_rows = []
    for obj in objects[:3]:
        bbox = obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {}
        object_rows.append(
            (
                obj.get("kind"),
                obj.get("class"),
                obj.get("text"),
                tuple(
                    _round_float(bbox.get(key), digits=3)
                    for key in ("left", "right", "top", "bottom")
                ),
            )
        )
    metric_row = tuple(
        (key, _round_float(value, digits=3))
        for key, value in sorted(metrics.items())
        if value is not None
    )
    return json.dumps(
        (scene, code, tuple(object_rows), metric_row),
        ensure_ascii=False,
        sort_keys=True,
    )
def _separation_axis(metrics: dict[str, float]) -> str:
    x_value = abs(float(metrics.get("x_overlap") or metrics.get("overflow_x") or 0.0))
    y_value = abs(float(metrics.get("y_overlap") or metrics.get("overflow_y") or 0.0))
    return "x" if x_value >= y_value else "y"
def _direction_hint(
    objects: list[dict[str, Any]],
    metrics: dict[str, float],
) -> str:
    if metrics.get("overflow_x") or metrics.get("overflow_y"):
        return "inside_safe_zone"
    if len(objects) < 2:
        return "away_from_overlap"
    first = objects[0].get("bbox") if isinstance(objects[0].get("bbox"), dict) else {}
    second = objects[1].get("bbox") if isinstance(objects[1].get("bbox"), dict) else {}
    if not first or not second:
        return "away_from_overlap"
    if _separation_axis(metrics) == "x":
        return (
            "left"
            if float(first.get("center_x") or 0.0) <= float(second.get("center_x") or 0.0)
            else "right"
        )
    return (
        "down"
        if float(first.get("center_y") or 0.0) <= float(second.get("center_y") or 0.0)
        else "up"
    )
def _min_clearance(metrics: dict[str, float]) -> float:
    values = [
        abs(float(metrics.get(key) or 0.0))
        for key in ("x_overlap", "y_overlap", "overflow_x", "overflow_y")
    ]
    return _round_float(max(values + [0.12]) + 0.08)
def _scale_hint(action: str, metrics: dict[str, float]) -> float | None:
    if action not in {"scale_group_to_fit", "wrap_or_shrink_text"}:
        return None
    pressure = max(
        abs(float(metrics.get("overlap_ratio") or 0.0)),
        abs(float(metrics.get("overflow_x") or 0.0)),
        abs(float(metrics.get("overflow_y") or 0.0)),
    )
    if pressure >= 0.45:
        return 0.84
    if pressure >= 0.25:
        return 0.88
    return 0.92
def _issue_get(issue: LayoutIssue | dict[str, Any], key: str) -> Any:
    if isinstance(issue, LayoutIssue):
        return getattr(issue, key, None)
    if isinstance(issue, dict):
        return issue.get(key)
    return None
def _issue_objects(issue: LayoutIssue | dict[str, Any]) -> list[dict[str, Any]]:
    objects = _issue_get(issue, "objects")
    if not isinstance(objects, list):
        return []
    return [obj for obj in objects if isinstance(obj, dict)]
def _issue_metadata(issue: LayoutIssue | dict[str, Any]) -> dict[str, Any]:
    metadata = _issue_get(issue, "metadata")
    return metadata if isinstance(metadata, dict) else {}
def _first_number(*values: Any) -> float | None:
    for value in values:
        number = _round_float(value)
        if number is not None:
            return number
    return None
def _round_float(value: Any, digits: int = 4) -> float | None:
    try:
        return round(float(value), digits)
    except (TypeError, ValueError):
        return None
def _compact_text(value: Any, limit: int) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    head = max(1, limit // 2)
    tail = max(1, limit - head - 5)
    return f"{text[:head]}...{text[-tail:]}"
def _dedupe(values: Any) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result
def _dedupe_action_contracts(values: Any) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for value in values:
        if not isinstance(value, dict) or not value.get("action"):
            continue
        key = json.dumps(value, ensure_ascii=False, sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result

