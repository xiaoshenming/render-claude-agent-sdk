"""Evidence calculations for text occlusion by geometric shapes."""

from __future__ import annotations

from typing import Any

from .layout_evidence_text import label
from .layout_label_geometry import is_protected_geometry_label

EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow", "Brace", "BraceBetweenPoints"}
TEXT_SHAPE_ERROR_THRESHOLD = 0.35
TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD = 0.55
TEXTUAL_KINDS = {"text", "formula"}

def _float(value: Any) -> float:
    try: return float(value)
    except (TypeError, ValueError): return 0.0

def union_bbox(*objects: dict[str, Any]) -> dict[str, float]:
    boxes=[obj.get("bbox") for obj in objects if isinstance(obj.get("bbox"),dict)]
    if not boxes: return {}
    left=min(_float(b.get("left")) for b in boxes); right=max(_float(b.get("right")) for b in boxes)
    top=max(_float(b.get("top")) for b in boxes); bottom=min(_float(b.get("bottom")) for b in boxes)
    return {"left":round(left,4),"right":round(right,4),"top":round(top,4),"bottom":round(bottom,4),"width":round(max(0.0,right-left),4),"height":round(max(0.0,top-bottom),4)}

def visual_review_evidence(*, text_obj: dict[str, Any], shape_obj: dict[str, Any], ratio: float, x_overlap: float, y_overlap: float) -> dict[str, Any]:
    return {"evidence_type":"text_shape_occlusion","textual_object":label(text_obj),"occluding_object":label(shape_obj),"overlap_ratio":round(ratio,4),"x_overlap":round(x_overlap,4),"y_overlap":round(y_overlap,4),"crop_hint":{"source":"bbox_union","padding":0.16,"bbox":union_bbox(text_obj,shape_obj)}}

def strong_text_shape_occlusion_metadata(a: dict[str, Any], b: dict[str, Any], *, ratio: float, x_overlap: float, y_overlap: float, metadata: dict[str, Any]) -> dict[str, Any] | None:
    if metadata.get("near_collision"): return None
    text_obj=a if str(a.get("kind") or "") in TEXTUAL_KINDS else b; shape_obj=b if text_obj is a else a
    if str(text_obj.get("kind") or "") not in TEXTUAL_KINDS or str(shape_obj.get("kind") or "") != "shape" or is_protected_geometry_label(text_obj): return None
    shape_class=str(shape_obj.get("class") or "")
    if shape_class in {"Axes","NumberPlane"}: return None
    text_box=text_obj.get("bbox") if isinstance(text_obj.get("bbox"),dict) else {}
    if not text_box: return None
    text_width=max(_float(text_box.get("width")),0.01); text_height=max(_float(text_box.get("height")),0.01)
    x_coverage=max(0.0,min(1.0,x_overlap/text_width)); y_coverage=max(0.0,min(1.0,y_overlap/text_height)); area=x_coverage*y_coverage
    line_like=shape_class in EXTENDED_LINE_CLASSES
    obvious=(ratio>=TEXT_SHAPE_ERROR_THRESHOLD or area>=TEXT_SHAPE_ERROR_THRESHOLD or (x_coverage>=TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD and y_coverage>=TEXT_SHAPE_ERROR_THRESHOLD) or (line_like and x_coverage>=0.45 and y_coverage>=0.22))
    if not obvious: return None
    return {"strong_text_shape_occlusion":True,"bbox_occlusion_metrics":{"text_coverage_x":round(x_coverage,4),"text_coverage_y":round(y_coverage,4),"text_coverage_area":round(area,4),"shape_class":shape_class},"visual_review_evidence":visual_review_evidence(text_obj=text_obj,shape_obj=shape_obj,ratio=ratio,x_overlap=x_overlap,y_overlap=y_overlap)}
