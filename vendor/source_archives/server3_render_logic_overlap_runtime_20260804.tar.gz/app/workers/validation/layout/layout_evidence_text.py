"""Small evidence and repair-message helpers for layout overlaps."""

from __future__ import annotations

from typing import Any


def label(obj: dict[str, Any]) -> str:
    text = str(obj.get("text") or "").strip()
    cls = str(obj.get("class") or obj.get("kind") or "object")
    return f"{cls}({text})" if text else cls


def evidence(a: dict[str, Any], b: dict[str, Any], ratio: float, x_overlap: float, y_overlap: float) -> str:
    return f"{label(a)} overlaps {label(b)}; overlap_ratio={ratio:.4f}, x_overlap={x_overlap:.4f}, y_overlap={y_overlap:.4f}"


def suggest_fix(a: dict[str, Any], b: dict[str, Any]) -> str:
    labels = [label(a), label(b)]
    return f"分离 {labels[0]} 与 {labels[1]} 的 bbox；优先移动公式或后出现标签，使用小幅 shift/scale 或先 FadeOut 旧尺寸标注后再展示新公式。"


def suggest_container_fix(a: dict[str, Any], b: dict[str, Any]) -> str:
    labels = [label(a), label(b)]
    return f"让 {labels[0]} 与 {labels[1]} 保持容器内边距；优先缩小文字/公式，必要时向容器中心小幅移动，避免压住边框或溢出卡片。"
