from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _pre_render_scan_layout_repair_script(
    *,
    ctx,
    script_path: str,
    scene_name: str,
    method: str,
) -> list[str]:
    """Normalize layout-repair scripts before probe/render reads them."""
    task_data = getattr(ctx, "task_data", None)
    if isinstance(task_data, dict):
        raw = task_data.get("_agent_disable_legacy_pre_render_scan")
        if raw is None:
            raw = task_data.get("_agent_disable_pre_render_scan")
        if isinstance(raw, bool):
            disabled = raw
        elif isinstance(raw, (int, float)):
            disabled = bool(raw)
        elif isinstance(raw, str):
            disabled = raw.strip().lower() in {
                "1",
                "true",
                "yes",
                "y",
                "on",
                "enabled",
            }
        else:
            disabled = bool(raw)
        if disabled:
            records = task_data.setdefault("_layout_pre_render_fixes", [])
            if isinstance(records, list):
                records.append({
                    "scene_name": scene_name,
                    "method": method,
                    "fixes": [],
                    "skipped": True,
                    "reason": "task_flag_disable_legacy_pre_render_scan",
                })
            return []
    from app.workers.repair.pre_render_fixes import pre_render_scan

    path = Path(script_path)
    source = path.read_text(encoding="utf-8", errors="replace")
    fixed, fixes = pre_render_scan(
        source,
        color_scheme=_layout_pre_render_color_scheme(ctx),
    )
    if not fixes or fixed == source:
        return []

    compile(fixed, script_path, "exec")
    path.write_text(fixed, encoding="utf-8")

    if isinstance(task_data, dict):
        task_data["_layout_pre_render_fix_count"] = (
            int(task_data.get("_layout_pre_render_fix_count") or 0) + len(fixes)
        )
        records = task_data.setdefault("_layout_pre_render_fixes", [])
        if isinstance(records, list):
            records.append({
                "scene_name": scene_name,
                "method": method,
                "fixes": fixes[:20],
            })
    return fixes

def _layout_repair_degraded_allowed(issues: list[LayoutIssue]) -> tuple[bool, str]:
    """Allow success only for small residual visual overlaps after a rendered fix.

    This is intentionally narrower than "ignore layout". Runtime errors,
    frame overflows, and container overflows still fail closed; the downgrade is
    only for stubborn low-ratio overlaps where the latest candidate rendered.
    """
    if not _env_bool("LAYOUT_REPAIR_ALLOW_DEGRADED_SUCCESS", True):
        return False, "degraded_success_disabled"
    if not issues:
        return False, "no_residual_issues"

    max_count = _env_int(
        "LAYOUT_REPAIR_DEGRADED_MAX_ISSUES",
        8,
        minimum=1,
        maximum=12,
    )
    if len(issues) > max_count:
        return False, f"too_many_residual_issues={len(issues)}>{max_count}"

    max_overlap = _env_float(
        "LAYOUT_REPAIR_DEGRADED_MAX_OVERLAP_RATIO",
        0.18,
        minimum=0.0,
    )
    max_high_overlap = _env_float(
        "LAYOUT_REPAIR_DEGRADED_MAX_HIGH_OVERLAP_RATIO",
        0.12,
        minimum=0.0,
    )
    allowed_soft_codes = {
        "layout_overlap_error",
        "layout_overlap_risk",
        "layout_container_border_overlap",
    }
    for issue in issues:
        if issue.code in {"layout_frame_overflow", "layout_container_overflow"}:
            return False, f"hard_residual_issue={issue.code}"
        if issue.code == "layout_probe_runtime_error":
            return False, "residual_probe_runtime_error"
        if issue.code not in allowed_soft_codes:
            return False, f"unsupported_residual_issue={issue.code}"
        ratio = float(issue.overlap_ratio or 0.0)
        if ratio > max_overlap:
            return False, f"residual_overlap_ratio={ratio:.3f}>{max_overlap:.3f}"
        if issue.severity == "high":
            if ratio <= 0:
                return False, "high_residual_overlap_missing_ratio"
            if ratio > max_high_overlap:
                return False, (
                    f"high_residual_overlap_ratio={ratio:.3f}>{max_high_overlap:.3f}"
                )

    return True, "minor_residual_overlap"

def _render_canvas_profile_metadata(aspect_ratio: str) -> dict[str, Any]:
    profile = get_render_canvas_profile(aspect_ratio)
    contract = dict(profile.to_prompt_contract())
    pixel_size = contract.get("pixel_size") or [
        profile.pixel_width,
        profile.pixel_height,
    ]
    frame_contract = contract.get("manim_frame")
    frame = dict(frame_contract) if isinstance(frame_contract, dict) else {}
    safe_box_contract = contract.get("safe_box")
    safe_box = dict(safe_box_contract) if isinstance(safe_box_contract, dict) else {}
    return {
        "profile_name": profile.profile_name,
        "version": profile.version,
        "aspect_ratio": profile.aspect_ratio,
        "pixel": {
            "width": int(pixel_size[0]),
            "height": int(pixel_size[1]),
        },
        "frame": {
            "width": float(frame.get("frame_width", profile.frame_width)),
            "height": float(frame.get("frame_height", profile.frame_height)),
            "x_range": list(frame.get("x_range") or [profile.x_min, profile.x_max]),
            "y_range": list(frame.get("y_range") or [profile.y_min, profile.y_max]),
        },
        "safe_box": {
            "x_range": list(
                safe_box.get("x_range") or [profile.safe_x_min, profile.safe_x_max]
            ),
            "y_range": list(
                safe_box.get("y_range") or [profile.safe_y_min, profile.safe_y_max]
            ),
        },
    }
