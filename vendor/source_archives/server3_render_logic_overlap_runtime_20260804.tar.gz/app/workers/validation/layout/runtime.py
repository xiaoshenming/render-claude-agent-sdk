from __future__ import annotations

import asyncio
import ast
import json
import logging
import os
import re
import tempfile
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Awaitable, Callable

from .runtime_api_core import *
from .runtime_api_helpers import *
from .runtime_api_reporting import *

from app.core.config import (
    DEFAULT_REPAIR_CONCURRENCY,
    DEFAULT_REPAIR_INNER_RETRIES,
    DEFAULT_REPAIR_MAX_LLM_CALLS_PER_SCENE,
    DEFAULT_REPAIR_MAX_PASSES,
    settings,
)
from app.core.render_canvas_profile import get_render_canvas_profile
from app.services import ffmpeg_service
from app.workers.rendering import executor as render_executor
from app.workers.validation.quality_repair_policy import (
    RepairLane,
    classify_quality_issue,
)
from app.workers.repair.repair_state import BackhalfRepairBudget

from .helper_contract import check_helper_contract
from .judge_client import judge_layout_issues
from .planner import (
    build_layout_repair_plan,
    layout_repair_plan_to_prompt_context,
    mark_layout_repair_plan_progress,
)
from .policy import apply_layout_policy
from .probe_runner import PROBE_RUNNER_SOURCE
from .repair_plan import (
    annotate_layout_issues_with_plan,
    record_layout_no_progress,
)
from .schemas import LayoutDecision, LayoutIssue


RenderSceneFn = Callable[[object, str, str, str], Awaitable[str]]
logger = logging.getLogger("render")


_LAYOUT_HARD_ERROR_CODES = {
    "layout_overlap_error",
    "layout_container_overflow",
    "layout_frame_overflow",
}


@dataclass(frozen=True)
class _RepairBudget:
    max_passes: int
    inner_retries: int
    max_llm_calls_per_scene: int


async def inspect_and_repair_layout(
    *,
    ctx,
    script_path: str,
    mp4_paths: list[tuple[str, str]],
    slices_dir: str,
    render_scene_fn: RenderSceneFn | None = None,
) -> list[tuple[str, str]]:
    """Inspect scene layout and record evidence without mutating render output.

    The historical layout repair routes (quality-repair adapter, deterministic
    auto-nudge and slice repair) are retired.  Keep the public function name as
    a compatibility boundary for callers while making its runtime behavior
    explicitly evidence-only and fail-open.
    """
    if not _enabled() or _mode() == "off":
        return mp4_paths

    next_paths = list(mp4_paths)
    decisions = await _probe_and_judge_scenes(
        ctx=ctx,
        script_path=script_path,
        scene_names=[scene_name for scene_name, _ in next_paths],
    )
    for (scene_name, current_path), decision in zip(
        list(next_paths), decisions, strict=False
    ):
        decision = await _apply_visual_fallback_if_needed(
            ctx=ctx,
            scene_name=scene_name,
            video_path=current_path,
            decision=decision,
        )
        decision = _apply_cross_scene_dedup(
            ctx=ctx,
            scene_name=scene_name,
            decision=decision,
            demote_observed=False,
        )
        _record_task_data(
            ctx.task_data,
            decision,
            status=_status_for(decision),
            aspect_ratio=getattr(ctx, "aspect_ratio", "16:9") or "16:9",
        )

    return next_paths


async def probe_scene_layout(
    *,
    ctx,
    scene_name: str,
    script_path: str,
    apply_cross_scene_dedup: bool = True,
) -> LayoutDecision:
    mode = _mode()
    started_at = time.monotonic()
    try:
        raw = await _run_probe_in_container(
            ctx=ctx,
            scene_name=scene_name,
            script_path=script_path,
        )
        decision = _decision_from_probe_result(
            mode=mode,
            scene_name=scene_name,
            raw=raw,
            latency_ms=int((time.monotonic() - started_at) * 1000),
        )
        if apply_cross_scene_dedup:
            decision = _apply_cross_scene_dedup(
                ctx=ctx,
                scene_name=scene_name,
                decision=decision,
            )
        return decision
    except Exception as exc:
        issue = LayoutIssue(
            code="layout_review_error",
            severity="low",
            confidence=1.0,
            scene_name=scene_name,
            evidence=f"{type(exc).__name__}: {exc}",
            metadata={"source": "layout_runtime"},
        )
        return LayoutDecision(
            mode=mode,
            scene_name=scene_name,
            final_action="record_only",
            issues=[issue],
            latency_ms=int((time.monotonic() - started_at) * 1000),
        )


async def _probe_and_judge_scenes(
    *,
    ctx,
    script_path: str,
    scene_names: list[str],
) -> list[LayoutDecision]:
    probe_limit = _env_int("LAYOUT_PROBE_CONCURRENCY", 32, minimum=1)
    judge_limit = _env_int("LAYOUT_JUDGE_CONCURRENCY", 32, minimum=1)
    probe_sem = asyncio.Semaphore(probe_limit)
    judge_sem = asyncio.Semaphore(judge_limit)
    deterministic_started = time.monotonic()

    async def probe_one(scene_name: str) -> LayoutDecision:
        async with probe_sem:
            return await probe_scene_layout(
                ctx=ctx,
                scene_name=scene_name,
                script_path=script_path,
                apply_cross_scene_dedup=False,
            )

    decisions = await asyncio.gather(
        *(probe_one(scene_name) for scene_name in scene_names)
    )
    deterministic_sec = time.monotonic() - deterministic_started
    _record_layout_seconds(
        getattr(ctx, "task_data", None),
        deterministic_sec=deterministic_sec,
        llm_sec=0.0,
    )

    async def judge_one(decision: LayoutDecision) -> LayoutDecision:
        if not any(issue.needs_llm_judge for issue in decision.issues):
            return decision
        if _legacy_layout_judge_disabled(getattr(ctx, "task_data", None)):
            _record_soft_layout_note(getattr(ctx, "task_data", None), decision)
            return decision
        if not _should_sync_llm_layout_judge(decision):
            _record_soft_layout_note(getattr(ctx, "task_data", None), decision)
            return decision
        async with judge_sem:
            started = time.monotonic()
            judged = await _apply_llm_judge_if_needed(
                ctx=ctx,
                scene_name=decision.scene_name,
                decision=decision,
            )
            _record_layout_seconds(
                getattr(ctx, "task_data", None),
                deterministic_sec=0.0,
                llm_sec=time.monotonic() - started,
            )
            return judged

    return await asyncio.gather(*(judge_one(decision) for decision in decisions))




















def _status_for(decision: LayoutDecision) -> str:
    if decision.final_action in {"repair_candidate", "block_candidate"}:
        return decision.final_action
    return "recorded" if decision.issues else "clean"


def _enabled() -> bool:
    return _env_bool("LAYOUT_REVIEW_ENABLED", False)


def _mode() -> str:
    mode = _runtime_value("LAYOUT_REVIEW_MODE", "shadow").strip().lower()
    return mode if mode in {"off", "shadow", "repair", "block"} else "shadow"




def _deterministic_auto_nudge_enabled() -> bool:
    return _env_bool("LAYOUT_DETERMINISTIC_AUTO_NUDGE_ENABLED", True)


def _layout_patch_first_enabled() -> bool:
    return _env_bool("LAYOUT_REPAIR_PATCH_FIRST_ENABLED", True)


def _visual_edge_fallback_enabled() -> bool:
    return _env_bool("LAYOUT_PROBE_VISUAL_FALLBACK_ENABLED", True)








def _sync_llm_overlap_threshold() -> float:
    return _env_float("LAYOUT_SYNC_LLM_MIN_OVERLAP_RATIO", 0.25, minimum=0.0)






def _resolution_for(aspect_ratio: str) -> tuple[int, int]:
    profile = get_render_canvas_profile(aspect_ratio)
    return int(profile.pixel_width), int(profile.pixel_height)








# ==== P1-4: 跨 scene issue dedup ====
