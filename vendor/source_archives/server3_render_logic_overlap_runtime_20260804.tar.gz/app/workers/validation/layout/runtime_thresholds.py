from app.workers.validation.layout import runtime as _runtime

def _layout_repair_no_progress_threshold() -> int:
    return _repair_loop_limit("LAYOUT_REPAIR_NO_PROGRESS_REPEAT_THRESHOLD", 3)
