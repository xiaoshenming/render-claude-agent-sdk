from __future__ import annotations
import re
from typing import Any
from .schemas import LayoutDecision, LayoutIssue
from .overlap_metadata import overlap_metadata
from .policy_geometry import looks_like_external_axis_tick_container_overlap as _looks_like_external_axis_tick_container_overlap
from .layout_label_geometry import (
    contains_protected_geometry_label as _contains_protected_geometry_label,
    is_short_anchor_label as _is_short_anchor_label,
    looks_like_anchored_short_label_pair as _looks_like_anchored_short_label_pair,
    looks_like_probe_duplicate_textual_pair as _looks_like_probe_duplicate_textual_pair,
    looks_like_protected_geometry_label_pair as _looks_like_protected_geometry_label_pair,
)
from .layout_evidence_text import evidence as _evidence, suggest_container_fix as _suggest_container_fix, suggest_fix as _suggest_fix
from .layout_container_evidence import text_bbox_inside_container as _text_bbox_inside_container
from .policy_overlap_shape import issue_from_text_shape_overlap as _issue_from_text_shape_overlap
TEXTUAL_KINDS = {"text", "formula"}
FRAME_BOUNDS_KINDS = TEXTUAL_KINDS | {"container", "shape", "group"}
DIRECT_ERROR_THRESHOLD = 0.30
# 文字/公式互相之间的重叠：阈值更严格，>=0.15 直接升级为 error 触发自动修复。
# 0.30 这个阈值漏掉了诸如 "Text(slot3) ↔ MathTex(slot4)" 比例 0.20~0.25 的真重叠。
TEXTUAL_PAIR_ERROR_THRESHOLD = 0.15
TEXTUAL_RISK_THRESHOLD = 0.10
TEXT_SHAPE_ERROR_THRESHOLD = 0.35
TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD = 0.55
LAYOUT_ERROR_CODES = {
    "layout_overlap_error",
    "layout_container_overflow",
    "layout_frame_overflow",
}
LAYOUT_RISK_CODES = {"layout_overlap_risk", "layout_container_border_overlap"}
SHORT_AXIS_TICK_RE = re.compile(r"^-?\d+(?:\.\d+)?$")
EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow"}
LINE_LIKE_FRAME_REPAIR_CLASSES = EXTENDED_LINE_CLASSES | {
    "Brace",
    "BraceBetweenPoints",
}
def apply_layout_policy(
    *,
    mode: str,
    scene_name: str,
    overlaps: list[dict[str, Any]],
    bounds_violations: list[dict[str, Any]] | None = None,
    latency_ms: int = 0,
    artifact_path: str | None = None,
) -> LayoutDecision:
    normalized_mode = (mode or "shadow").strip().lower()
    if normalized_mode not in {"off", "shadow", "repair", "block"}:
        normalized_mode = "shadow"
    issues: list[LayoutIssue] = []
    for overlap in overlaps:
        issue = _issue_from_overlap(scene_name, overlap)
        if issue:
            issues.append(issue)
    for violation in bounds_violations or []:
        issue = _issue_from_bounds_violation(scene_name, violation)
        if issue:
            issues.append(issue)
    errors = [issue for issue in issues if issue.code in LAYOUT_ERROR_CODES]
    risks = [issue for issue in issues if issue.code in LAYOUT_RISK_CODES]
    repairable = [issue for issue in issues if issue.repairable]
    final_action = "record_only"
    if normalized_mode == "repair" and repairable:
        final_action = "repair_candidate"
    elif normalized_mode == "block" and errors:
        final_action = "block_candidate"
    return LayoutDecision(
        mode=normalized_mode,
        scene_name=scene_name,
        final_action=final_action,
        issues=issues,
        latency_ms=latency_ms,
        needs_repair=final_action == "repair_candidate",
        layout_error_count=len(errors),
        layout_risk_count=len(risks),
        artifact_path=artifact_path,
    )
from .layout_overlap_noise import (bounds_evidence as _bounds_evidence, near_collision_evidence as _near_collision_evidence, looks_like_partial_formula_highlight as _looks_like_partial_formula_highlight, looks_like_formula_cancellation_line_overlap as _looks_like_formula_cancellation_line_overlap, looks_like_vertex_label_inside_shape as _looks_like_vertex_label_inside_shape, looks_like_axes_annotation_overlap as _looks_like_axes_annotation_overlap, looks_like_intentional_water_assembly_overlap as _looks_like_intentional_water_assembly_overlap)
from .layout_visual_occlusion import strong_text_shape_occlusion_metadata as _strong_text_shape_occlusion_metadata, union_bbox as _union_bbox, _float as _float
from .layout_bounds_issue import issue_from_bounds_violation as _issue_from_bounds_violation
from .overlap_metadata import overlap_metadata as _overlap_metadata
def _issue_from_overlap(
    scene_name: str,
    overlap: dict[str, Any],
) -> LayoutIssue | None:
    a = overlap.get("a") if isinstance(overlap.get("a"), dict) else {}
    b = overlap.get("b") if isinstance(overlap.get("b"), dict) else {}
    ratio = _float(overlap.get("ratio_of_smaller"))
    x_overlap = _float(overlap.get("x_overlap"))
    y_overlap = _float(overlap.get("y_overlap"))
    category = str(overlap.get("category") or "")
    extra_metadata = _overlap_metadata(overlap)
    a_kind = str(a.get("kind") or "")
    b_kind = str(b.get("kind") or "")
    textual_pair = a_kind in TEXTUAL_KINDS and b_kind in TEXTUAL_KINDS
    if textual_pair and _looks_like_probe_duplicate_textual_pair(a, b):
        return None
    if textual_pair and _looks_like_intentional_water_assembly_overlap(
        a,
        b,
        category=category,
        ratio=ratio,
        metadata=extra_metadata,
    ):
        return None
    if textual_pair and _is_after_play_event(extra_metadata):
        if ratio < TEXTUAL_RISK_THRESHOLD:
            return None
        return _transient_after_play_risk_issue(
            scene_name=scene_name,
            a=a,
            b=b,
            ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            metadata=extra_metadata,
        )
    if textual_pair and _looks_like_protected_geometry_label_pair(a, b):
        has_short_anchor_label = _is_short_anchor_label(
            str(a.get("text") or "")
        ) or _is_short_anchor_label(str(b.get("text") or ""))
        if (
            has_short_anchor_label
            and ratio >= TEXTUAL_PAIR_ERROR_THRESHOLD
            and not _looks_like_anchored_short_label_pair(a, b, ratio)
        ):
            return LayoutIssue(
                code="layout_overlap_error",
                severity="high",
                confidence=min(0.95, 0.65 + ratio),
                scene_name=scene_name,
                evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
                overlap_ratio=ratio,
                x_overlap=x_overlap,
                y_overlap=y_overlap,
                objects=[a, b],
                repairable=True,
                deterministic_repairable=True,
                suggested_fix=_suggest_fix(a, b),
                metadata={
                    **extra_metadata,
                    "protected_geometry_label": True,
                    "promoted_from_protected_geometry_label": True,
                },
            )
        return LayoutIssue(
            code="layout_overlap_risk",
            severity="low",
            confidence=min(0.75, 0.45 + ratio / 2.0),
            scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
            overlap_ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            objects=[a, b],
            repairable=False,
            deterministic_repairable=False,
            needs_llm_judge=False,
            suggested_fix="短几何标签/边长标签贴近对应图形通常是正常标注；只记录风险，不自动移动锚定标签。",
            metadata={**extra_metadata, "protected_geometry_label": True},
        )
    if category == "text_container_overflow":
        if _looks_like_partial_formula_highlight(a, b):
            return None
        if _is_after_play_event(extra_metadata) and (
            a_kind in TEXTUAL_KINDS or b_kind in TEXTUAL_KINDS
        ):
            return _transient_after_play_risk_issue(
                scene_name=scene_name,
                a=a,
                b=b,
                ratio=ratio,
                x_overlap=x_overlap,
                y_overlap=y_overlap,
                metadata=extra_metadata,
                suggested_fix="中间动画帧的文字/容器边界接触只记录风险；若最终停留态仍越界，再触发布局修复。",
            )
        if _text_bbox_inside_container(a, b):
            # text bbox 完全位于 container 内：probe 只是按高 IoU 报了 overflow，
            # 文字其实安全（4 个 margin 都 ≥ 0），不应触发 scale 缩字。
            return None
        if _looks_like_external_axis_tick_container_overlap(a, b):
            return LayoutIssue(
                code="layout_container_border_overlap",
                severity="medium",
                confidence=min(0.9, 0.55 + ratio / 3.0),
                scene_name=scene_name,
                evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
                overlap_ratio=ratio,
                x_overlap=x_overlap,
                y_overlap=y_overlap,
                objects=[a, b],
                repairable=False,
                deterministic_repairable=False,
                needs_llm_judge=True,
                suggested_fix="短坐标刻度与大信息框边缘接触，记录为布局风险；不要把刻度强行移入容器。",
                metadata={**extra_metadata, "external_axis_tick": True},
            )
        return LayoutIssue(
            code="layout_container_overflow",
            severity="high",
            confidence=min(0.99, 0.78 + ratio / 2.0),
            scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
            overlap_ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            objects=[a, b],
            repairable=True,
            deterministic_repairable=True,
            suggested_fix=_suggest_container_fix(a, b),
            metadata=extra_metadata,
        )
    if category == "text_container_border_overlap":
        return LayoutIssue(
            code="layout_container_border_overlap",
            severity="medium",
            confidence=min(0.9, 0.55 + ratio / 3.0),
            scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
            overlap_ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            objects=[a, b],
            repairable=True,
            deterministic_repairable=True,
            needs_llm_judge=True,
            suggested_fix=_suggest_container_fix(a, b),
            metadata={**extra_metadata, "non_blocking_border_contact": True},
        )
    if textual_pair and ratio >= DIRECT_ERROR_THRESHOLD:
        if _looks_like_anchored_short_label_pair(a, b, ratio):
            # 两个紧贴几何顶点的短标签 (A/A'/B1) 在 bbox 上彼此相交，但视觉上靠 dot 分隔；
            # 误判为高严重 layout_overlap_error 会驱动 LLM 远距离搬动 → 标签飞离锚点。
            return None
        return LayoutIssue(
            code="layout_overlap_error",
            severity="high",
            confidence=min(0.99, 0.78 + ratio / 2.0),
            scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
            overlap_ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            objects=[a, b],
            repairable=True,
            deterministic_repairable=True,
            suggested_fix=_suggest_fix(a, b),
            metadata=extra_metadata,
        )
    if textual_pair and ratio >= TEXTUAL_PAIR_ERROR_THRESHOLD:
        if _looks_like_anchored_short_label_pair(a, b, ratio):
            return None
        # 文本对文本/公式只要超过 0.15 就直接交给修复管线（确定性 nudge + LLM 兜底）。
        # 这类重叠人眼一定能看出来，不需要 LLM judge 二次判断。
        return LayoutIssue(
            code="layout_overlap_error",
            severity="high",
            confidence=min(0.95, 0.65 + ratio),
            scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
            overlap_ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            objects=[a, b],
            repairable=True,
            deterministic_repairable=True,
            suggested_fix=_suggest_fix(a, b),
            metadata={**extra_metadata, "promoted_from_risk": True},
        )
    if textual_pair and ratio >= TEXTUAL_RISK_THRESHOLD:
        return LayoutIssue(
            code="layout_overlap_risk",
            severity="medium",
            confidence=min(0.85, 0.55 + ratio),
            scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap),
            overlap_ratio=ratio,
            x_overlap=x_overlap,
            y_overlap=y_overlap,
            objects=[a, b],
            repairable=False,
            deterministic_repairable=False,
            needs_llm_judge=True,
            suggested_fix=_suggest_fix(a, b),
            metadata=extra_metadata,
        )
    return _issue_from_text_shape_overlap(
        scene_name=scene_name, overlap=overlap, a=a, b=b, ratio=ratio,
        x_overlap=x_overlap, y_overlap=y_overlap, category=category,
        metadata=extra_metadata, textual_kinds=TEXTUAL_KINDS,
        textual_risk_threshold=TEXTUAL_RISK_THRESHOLD,
    )
