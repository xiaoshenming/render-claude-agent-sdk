from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from typing import Any

from .schemas import LayoutIssue


TEXT_CONSTRUCTORS = {"Text", "MarkupText", "Tex", "MathTex"}
TEXT_FACTORY_METHODS = {
    "create_formula",
    "create_mathtex",
    "create_text",
    "build_vector_label",
    "label_at",
    "make_label",
    "make_formula",
    "make_info_box",
    "make_mathtex",
    "make_text",
    "portrait_formula",
    "safe_text_box",
}
MULTI_TEXT_FACTORY_METHODS = {"make_info_box"}
TEXTUAL_KINDS = {"text", "formula"}
CONTAINER_ISSUE_CODES = {
    "layout_container_overflow",
    "layout_container_border_overlap",
}
FRAME_ISSUE_CODES = {"layout_frame_overflow"}
POSITIONING_METHODS = {
    "move_to",
    "next_to",
    "to_edge",
    "to_corner",
    "shift",
    "scale",
    "scale_to_fit_width",
    "scale_to_fit_height",
    "stretch_to_fit_width",
    "stretch_to_fit_height",
    "arrange",
    "center",
}
POSITIONING_HELPER_METHODS = {
    "enforce_graph_bounds",
    "fit_3d_portrait",
    "fit_to_frame",
    "fit_to_safe_area",
    "place_non_overlapping",
}
LAYOUT_GROUP_CONSTRUCTORS = {"Group", "VGroup"}
LAYOUT_GROUP_FACTORY_METHODS = {"safe_group"}
LINE_LIKE_FRAME_CONSTRUCTORS = {
    "Line",
    "DashedLine",
    "Arrow",
    "DoubleArrow",
    "Brace",
    "BraceBetweenPoints",
}


@dataclass(frozen=True)
class _SourceObject:
    variable: str
    text: str
    constructor: str
    lineno: int
    end_lineno: int


@dataclass(frozen=True)
class _GroupSource:
    variable: str
    lineno: int
    end_lineno: int


@dataclass(frozen=True)
class _GroupShift:
    source: _SourceObject
    expression: str
    direction: str
    distance: float


def apply_deterministic_layout_nudges(
    code: str,
    *,
    scene_name: str,
    issues: list[LayoutIssue],
    aspect_ratio: str = "16:9",
) -> tuple[str, list[dict[str, Any]]]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return code, []

    group_context = _collect_scene_groups(tree, scene_name)
    objects = _collect_scene_objects(tree, scene_name, group_context=group_context)
    frame_objects = _collect_frame_object_sources(
        tree,
        scene_name,
        group_context=group_context,
    )
    by_text: dict[str, list[_SourceObject]] = {}
    for item in objects:
        by_text.setdefault(item.text, []).append(item)

    insertions: dict[int, list[str]] = {}
    deletions: set[int] = set()
    actions: list[dict[str, Any]] = []
    adjusted_variables: set[tuple[str, int]] = set()
    for issue in issues:
        force_text_line_repair = _should_force_text_line_overlap_repair(issue)
        if not issue.deterministic_repairable and not force_text_line_repair:
            continue
        if issue.code in FRAME_ISSUE_CODES:
            frame_lines, frame_action, frame_source = _frame_overflow_adjustment_lines(
                by_text=by_text,
                frame_objects=frame_objects,
                issue=issue,
                code=code,
            )
            if frame_lines and frame_action and frame_source is not None:
                source_key = (frame_source.variable, frame_source.lineno)
                if source_key in adjusted_variables:
                    continue
                insertions.setdefault(frame_source.end_lineno, []).extend(frame_lines)
                actions.append(frame_action)
                adjusted_variables.add(source_key)
            continue
        target, other = _choose_target(issue.objects)
        if not target or not other:
            continue
        if issue.code not in CONTAINER_ISSUE_CODES:
            (
                manual_scale_lines,
                manual_scale_action,
                manual_scale_source,
            ) = _safe_text_box_manual_layout_scale_lines(
                by_text=by_text,
                issue=issue,
                code=code,
                scene_name=scene_name,
                aspect_ratio=aspect_ratio,
            )
            if (
                manual_scale_lines
                and manual_scale_action
                and manual_scale_source is not None
            ):
                source_key = (manual_scale_source.variable, manual_scale_source.lineno)
                if source_key in adjusted_variables:
                    continue
                insertions.setdefault(manual_scale_source.end_lineno, []).extend(
                    manual_scale_lines
                )
                actions.append(manual_scale_action)
                adjusted_variables.add(source_key)
                continue
            label_shift = _source_shift_for_external_label_overlap(
                by_text=by_text,
                target=target,
                other=other,
                group_context=group_context,
            )
            if label_shift is not None:
                source_obj = label_shift.source
                source_key = (source_obj.variable, source_obj.lineno)
                if source_key in adjusted_variables:
                    continue
                if _variable_already_mutated(code, source_obj):
                    continue
                line = _line_at(code, source_obj.lineno)
                indent = line[: len(line) - len(line.lstrip())]
                clamped_expr, clamped_distance, anchor_protected = _clamp_shift_for_layout(
                    label_shift.expression,
                    label_shift.direction,
                    label_shift.distance,
                    target_text=source_obj.text,
                    source_obj=source_obj,
                    code=code,
                    aspect_ratio=aspect_ratio,
                )
                insertions.setdefault(source_obj.end_lineno, []).extend(
                    _shift_lines_for_source(
                        source_obj=source_obj,
                        expression=clamped_expr,
                        indent=indent,
                    )
                )
                actions.append(
                    {
                        "scene_name": scene_name,
                        "target_text": source_obj.text,
                        "target_variable": source_obj.variable,
                        "direction": label_shift.direction,
                        "distance": clamped_distance,
                        "issue_code": issue.code,
                        "aspect_ratio": aspect_ratio,
                        "anchor_protected": anchor_protected,
                    }
                )
                adjusted_variables.add(source_key)
                continue
            dimension_shift = _source_shift_for_dimension_label_shape_overlap(
                by_text=by_text,
                target=target,
                other=other,
            )
            if dimension_shift is not None:
                source_obj = dimension_shift.source
                source_key = (source_obj.variable, source_obj.lineno)
                if source_key in adjusted_variables:
                    continue
                if _variable_already_mutated(code, source_obj):
                    continue
                line = _line_at(code, source_obj.lineno)
                indent = line[: len(line) - len(line.lstrip())]
                clamped_expr, clamped_distance, anchor_protected = _clamp_shift_for_layout(
                    dimension_shift.expression,
                    dimension_shift.direction,
                    dimension_shift.distance,
                    target_text=source_obj.text,
                    source_obj=source_obj,
                    code=code,
                    aspect_ratio=aspect_ratio,
                )
                insertions.setdefault(source_obj.end_lineno, []).extend(
                    _shift_lines_for_source(
                        source_obj=source_obj,
                        expression=clamped_expr,
                        indent=indent,
                    )
                )
                actions.append(
                    {
                        "scene_name": scene_name,
                        "target_text": source_obj.text,
                        "target_variable": source_obj.variable,
                        "method": "dimension_label_outside_shape",
                        "direction": dimension_shift.direction,
                        "distance": clamped_distance,
                        "issue_code": issue.code,
                        "aspect_ratio": aspect_ratio,
                        "anchor_protected": anchor_protected,
                    }
                )
                adjusted_variables.add(source_key)
                continue
        target_text = str(target.get("text") or "")
        matches = _source_matches_for_text(by_text, target_text)
        if len(matches) != 1:
            alternate_text = str(other.get("text") or "")
            alternate_matches = _source_matches_for_text(by_text, alternate_text)
            if (
                len(alternate_matches) == 1
                and _is_external_label_text(_compact_tex(target_text))
                and _is_external_label_text(_compact_tex(alternate_text))
            ):
                target, other = other, target
                target_text = alternate_text
                source_obj = alternate_matches[0]
            else:
                continue
        else:
            source_obj = matches[0]
        label_pair_shift = _shift_for_short_label_pair_overlap(
            source_obj=source_obj,
            target=target,
            other=other,
        )
        group_shift = label_pair_shift or _group_shift_for_external_short_label_overlap(
            source_obj=source_obj,
            target=target,
            other=other,
            group_context=group_context,
        )
        if group_shift is not None:
            source_obj = group_shift.source
        source_key = (source_obj.variable, source_obj.lineno)
        if source_key in adjusted_variables:
            continue
        if issue.code in CONTAINER_ISSUE_CODES:
            (
                align_reset_line,
                align_reset_action,
            ) = _tape_diagram_label_align_reset(
                tree=tree,
                code=code,
                source_obj=source_obj,
                target=target,
                container=other,
                issue=issue,
                group_context=group_context,
            )
            if align_reset_line is not None and align_reset_action:
                deletions.add(align_reset_line)
                actions.append(align_reset_action)
                adjusted_variables.add(source_key)
                continue
        if _variable_already_mutated(code, source_obj):
            continue
        line = _line_at(code, source_obj.lineno)
        indent = line[: len(line) - len(line.lstrip())]
        if issue.code in CONTAINER_ISSUE_CODES:
            new_lines, action = _container_adjustment_lines(
                source_obj=source_obj,
                target=target,
                container=other,
                issue=issue,
                indent=indent,
            )
            if not new_lines:
                continue
            insertions.setdefault(source_obj.end_lineno, []).extend(new_lines)
            actions.append(action)
        else:
            if group_shift is not None:
                direction = group_shift.direction
                distance = group_shift.distance
                shift_expression = group_shift.expression
            else:
                direction = _direction_away_from(target, other)
                distance = _nudge_distance(issue)
                shift_expression = f"{direction} * {distance:.3f}"
            shift_expression, distance, anchor_protected = _clamp_shift_for_layout(
                shift_expression,
                direction,
                distance,
                target_text=source_obj.text,
                source_obj=source_obj,
                code=code,
                aspect_ratio=aspect_ratio,
            )
            insertions.setdefault(source_obj.end_lineno, []).extend(
                _shift_lines_for_source(
                    source_obj=source_obj,
                    expression=shift_expression,
                    indent=indent,
                )
            )
            actions.append(
                {
                    "scene_name": scene_name,
                    "target_text": target_text,
                    "target_variable": source_obj.variable,
                    "direction": direction,
                    "distance": distance,
                    "issue_code": issue.code,
                    "aspect_ratio": aspect_ratio,
                    "anchor_protected": anchor_protected,
                }
            )
        adjusted_variables.add(source_key)

    if not insertions and not deletions:
        return code, []

    lines = code.splitlines()
    output: list[str] = []
    for index, line in enumerate(lines, start=1):
        if index in deletions:
            output.extend(insertions.get(index, []))
            continue
        output.append(line)
        output.extend(insertions.get(index, []))
    suffix = "\n" if code.endswith("\n") else ""
    fixed = "\n".join(output) + suffix
    try:
        ast.parse(fixed)
    except SyntaxError:
        return code, []
    return fixed, actions


def _collect_scene_objects(
    tree: ast.AST,
    scene_name: str,
    *,
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]] | None = None,
) -> list[_SourceObject]:
    class_defs = {
        node.name: node
        for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef)
    }
    scene_cls = next(
        (
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.ClassDef) and node.name == scene_name
        ),
        None,
    )
    if scene_cls is None:
        return []
    results: list[_SourceObject] = []
    by_variable: dict[str, list[_SourceObject]] = {}
    searchable_classes = _related_scene_classes(scene_cls, class_defs)
    group_members = group_context[0] if group_context is not None else _collect_group_members(searchable_classes)
    for owner_cls in searchable_classes:
        string_constants = _collect_string_constants(owner_cls)
        for node in ast.walk(owner_cls):
            if not isinstance(node, ast.Assign) or not node.targets:
                continue
            target = node.targets[0]
            if not isinstance(target, ast.Name):
                continue
            collection_items = _collect_text_collection_items(
                node=node,
                target_name=target.id,
                string_constants=string_constants,
            )
            if collection_items:
                results.extend(collection_items)
                continue
            group_items = _collect_text_group_items(
                node=node,
                target_name=target.id,
                string_constants=string_constants,
            )
            if group_items:
                results.extend(group_items)
                continue
            constructor = _constructor_call(node.value)
            if constructor is None:
                continue
            constructor_name = _call_name(constructor)
            texts = _text_args_for_constructor(constructor, string_constants)
            for text in texts:
                source = _SourceObject(
                    variable=target.id,
                    text=text,
                    constructor=constructor_name,
                    lineno=node.lineno,
                    end_lineno=getattr(node, "end_lineno", node.lineno),
                )
                results.append(source)
                by_variable.setdefault(target.id, []).append(source)

    existing_by_text: dict[str, list[_SourceObject]] = {}
    for item in results:
        existing_by_text.setdefault(item.text, []).append(item)

    for source in _collect_helper_argument_text_sources(searchable_classes):
        if len(existing_by_text.get(source.text, [])) == 1:
            continue
        results.append(source)
        by_variable.setdefault(source.variable, []).append(source)
        existing_by_text.setdefault(source.text, []).append(source)

    if not results:
        return []

    latest_positioning_line = {
        _source_key(item): item.end_lineno
        for item in results
    }
    _apply_positioning_lines(
        searchable_classes=searchable_classes,
        group_members=group_members,
        by_variable=by_variable,
        latest_positioning_line=latest_positioning_line,
    )

    return [
        _SourceObject(
            variable=item.variable,
            text=item.text,
            constructor=item.constructor,
            lineno=item.lineno,
            end_lineno=latest_positioning_line.get(_source_key(item), item.end_lineno),
        )
        for item in results
    ]


def _collect_scene_groups(
    tree: ast.AST,
    scene_name: str,
) -> tuple[dict[str, list[str]], dict[str, _GroupSource]]:
    class_defs = {
        node.name: node
        for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef)
    }
    scene_cls = next(
        (
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.ClassDef) and node.name == scene_name
        ),
        None,
    )
    if scene_cls is None:
        return {}, {}
    searchable_classes = _related_scene_classes(scene_cls, class_defs)
    group_members = _collect_group_members(searchable_classes)
    group_sources = _collect_group_sources(searchable_classes)
    group_source_objects = {
        variable: _SourceObject(
            variable=source.variable,
            text="",
            constructor="Group",
            lineno=source.lineno,
            end_lineno=source.end_lineno,
        )
        for variable, source in group_sources.items()
    }
    by_variable = {
        variable: [source]
        for variable, source in group_source_objects.items()
    }
    latest_positioning_line = {
        _source_key(source): source.end_lineno
        for source in group_source_objects.values()
    }
    _apply_positioning_lines(
        searchable_classes=searchable_classes,
        group_members=group_members,
        by_variable=by_variable,
        latest_positioning_line=latest_positioning_line,
    )
    return group_members, {
        variable: _GroupSource(
            variable=source.variable,
            lineno=source.lineno,
            end_lineno=latest_positioning_line.get(
                _source_key(group_source_objects[variable]),
                source.end_lineno,
            ),
        )
        for variable, source in group_sources.items()
    }


def _collect_frame_object_sources(
    tree: ast.AST,
    scene_name: str,
    *,
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]] | None = None,
) -> list[_SourceObject]:
    class_defs = {
        node.name: node
        for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef)
    }
    scene_cls = next(
        (
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.ClassDef) and node.name == scene_name
        ),
        None,
    )
    if scene_cls is None:
        return []
    searchable_classes = _related_scene_classes(scene_cls, class_defs)
    group_members = (
        group_context[0]
        if group_context is not None
        else _collect_group_members(searchable_classes)
    )
    results: list[_SourceObject] = []
    by_variable: dict[str, list[_SourceObject]] = {}
    for owner_cls in searchable_classes:
        for node in ast.walk(owner_cls):
            if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                continue
            target = node.targets[0]
            if not isinstance(target, ast.Name):
                continue
            constructor = _frame_object_constructor_call(node.value)
            if constructor is None:
                continue
            source = _SourceObject(
                variable=target.id,
                text="",
                constructor=_call_name(constructor),
                lineno=node.lineno,
                end_lineno=getattr(node, "end_lineno", node.lineno),
            )
            results.append(source)
            by_variable.setdefault(target.id, []).append(source)
    latest_positioning_line = {
        _source_key(item): item.end_lineno
        for item in results
    }
    _apply_positioning_lines(
        searchable_classes=searchable_classes,
        group_members=group_members,
        by_variable=by_variable,
        latest_positioning_line=latest_positioning_line,
    )
    return [
        _SourceObject(
            variable=item.variable,
            text=item.text,
            constructor=item.constructor,
            lineno=item.lineno,
            end_lineno=latest_positioning_line.get(
                _source_key(item),
                item.end_lineno,
            ),
        )
        for item in results
    ]


def _related_scene_classes(
    scene_cls: ast.ClassDef,
    class_defs: dict[str, ast.ClassDef],
) -> list[ast.ClassDef]:
    result: list[ast.ClassDef] = []
    seen: set[str] = set()

    def visit(cls: ast.ClassDef) -> None:
        for base in cls.bases:
            if isinstance(base, ast.Name):
                base_cls = class_defs.get(base.id)
                if base_cls is not None:
                    visit(base_cls)
        if cls.name not in seen:
            seen.add(cls.name)
            result.append(cls)

    visit(scene_cls)
    return result


def _collect_helper_argument_text_sources(
    classes: list[ast.ClassDef],
) -> list[_SourceObject]:
    methods: dict[str, ast.FunctionDef] = {
        node.name: node
        for cls in classes
        for node in cls.body
        if isinstance(node, ast.FunctionDef)
    }
    if not methods:
        return []

    results: list[_SourceObject] = []
    seen: set[tuple[str, int, str]] = set()
    for owner_cls in classes:
        for call in ast.walk(owner_cls):
            if not isinstance(call, ast.Call):
                continue
            helper = methods.get(_helper_method_call_name(call))
            if helper is None:
                continue
            bindings = _helper_call_string_bindings(helper, call)
            if not bindings:
                continue
            for source in _helper_text_sources_from_bindings(helper, bindings):
                key = (source.variable, source.lineno, source.text)
                if key in seen:
                    continue
                seen.add(key)
                results.append(source)
    return results


def _helper_method_call_name(call: ast.Call) -> str:
    func = call.func
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _helper_call_string_bindings(
    helper: ast.FunctionDef,
    call: ast.Call,
) -> dict[str, str]:
    params = [arg.arg for arg in helper.args.args]
    if params and params[0] == "self":
        params = params[1:]
    bindings: dict[str, str] = {}
    for index, arg in enumerate(call.args):
        if index >= len(params):
            break
        value = _literal_string_arg(arg)
        if value:
            bindings[params[index]] = value
    for keyword in call.keywords:
        if not keyword.arg:
            continue
        value = _literal_string_arg(keyword.value)
        if value:
            bindings[keyword.arg] = value
    return bindings


def _literal_string_arg(node: ast.AST) -> str:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return ""


def _helper_text_sources_from_bindings(
    helper: ast.FunctionDef,
    bindings: dict[str, str],
) -> list[_SourceObject]:
    results: list[_SourceObject] = []
    for node in ast.walk(helper):
        if not isinstance(node, ast.Assign) or not node.targets:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        collection_items = _collect_text_collection_items(
            node=node,
            target_name=target.id,
            string_constants=bindings,
        )
        if collection_items:
            results.extend(collection_items)
            continue
        group_items = _collect_text_group_items(
            node=node,
            target_name=target.id,
            string_constants=bindings,
        )
        if group_items:
            results.extend(group_items)
            continue
        constructor = _constructor_call(node.value)
        if constructor is None:
            continue
        constructor_name = _call_name(constructor)
        texts = _text_args_for_constructor(constructor, bindings)
        for text in texts:
            results.append(
                _SourceObject(
                    variable=target.id,
                    text=text,
                    constructor=constructor_name,
                    lineno=node.lineno,
                    end_lineno=getattr(node, "end_lineno", node.lineno),
                )
            )
    return results


def _collect_group_sources(classes: list[ast.ClassDef]) -> dict[str, _GroupSource]:
    sources: dict[str, _GroupSource] = {}
    for owner_cls in classes:
        for node in ast.walk(owner_cls):
            if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                continue
            target = node.targets[0]
            if isinstance(target, ast.Tuple):
                for item in target.elts:
                    if not isinstance(item, ast.Name):
                        continue
                    if item.id not in {"axis_labels", "point_labels"}:
                        continue
                    sources[item.id] = _GroupSource(
                        variable=item.id,
                        lineno=node.lineno,
                        end_lineno=getattr(node, "end_lineno", node.lineno),
                    )
                continue
            if not isinstance(target, ast.Name):
                continue
            if target.id in {"axis_labels", "point_labels"} and _space_group_key(node.value) == target.id:
                sources[target.id] = _GroupSource(
                    variable=target.id,
                    lineno=node.lineno,
                    end_lineno=getattr(node, "end_lineno", node.lineno),
                )
                continue
            base_call = _layout_group_call(node.value)
            if base_call is None:
                continue
            sources[target.id] = _GroupSource(
                variable=target.id,
                lineno=node.lineno,
                end_lineno=getattr(node, "end_lineno", node.lineno),
            )
    return sources


def _collect_group_members(classes: list[ast.ClassDef]) -> dict[str, list[str]]:
    members: dict[str, list[str]] = {}
    for owner_cls in classes:
        for node in ast.walk(owner_cls):
            if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                continue
            target = node.targets[0]
            if not isinstance(target, ast.Name):
                continue
            base_call = _layout_group_call(node.value)
            if base_call is None:
                continue
            names = [arg.id for arg in base_call.args if isinstance(arg, ast.Name)]
            if names:
                members[target.id] = names
    return members


def _apply_positioning_lines(
    *,
    searchable_classes: list[ast.ClassDef],
    group_members: dict[str, list[str]],
    by_variable: dict[str, list[_SourceObject]],
    latest_positioning_line: dict[tuple[str, int], int],
) -> None:
    for owner_cls in searchable_classes:
        for node in ast.walk(owner_cls):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if not isinstance(func, ast.Attribute):
                continue
            receiver_names: list[str] = []
            if func.attr in POSITIONING_METHODS:
                receiver = func.value
                if isinstance(receiver, ast.Name):
                    receiver_names = [receiver.id, *_expand_group_members(receiver.id, group_members)]
            elif func.attr in POSITIONING_HELPER_METHODS:
                for arg in node.args:
                    if isinstance(arg, ast.Name):
                        receiver_names.extend([arg.id, *_expand_group_members(arg.id, group_members)])
            if not receiver_names:
                continue
            for receiver_name in receiver_names:
                source = _nearest_source_before(
                    by_variable.get(receiver_name, []),
                    getattr(node, "lineno", 0),
                )
                if source is None:
                    continue
                if getattr(node, "lineno", 0) < source.lineno:
                    continue
                key = _source_key(source)
                latest_positioning_line[key] = max(
                    latest_positioning_line[key],
                    getattr(node, "end_lineno", getattr(node, "lineno", source.end_lineno)),
                )


def _expand_group_members(group_name: str, group_members: dict[str, list[str]]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()

    def visit(name: str) -> None:
        for child in group_members.get(name, []):
            if child in seen:
                continue
            seen.add(child)
            out.append(child)
            visit(child)

    visit(group_name)
    return out


def _source_key(source: _SourceObject) -> tuple[str, int]:
    return source.variable, source.lineno


def _source_matches_for_text(
    by_text: dict[str, list[_SourceObject]],
    text: str,
) -> list[_SourceObject]:
    matches = by_text.get(text, [])
    if len(matches) == 1:
        return matches
    match_key = _text_match_key(text)
    if match_key:
        out: list[_SourceObject] = []
        seen: set[tuple[str, int, str]] = set()
        for source_text, sources in by_text.items():
            if _text_match_key(source_text) != match_key:
                continue
            for source in sources:
                key = (source.variable, source.lineno, source.text)
                if key in seen:
                    continue
                seen.add(key)
                out.append(source)
        if out:
            return out

    compact = _compact_tex(text)
    if not compact:
        return matches
    out: list[_SourceObject] = []
    seen: set[tuple[str, int, str]] = set()
    for source_text, sources in by_text.items():
        if _compact_tex(source_text) != compact:
            continue
        for source in sources:
            key = (source.variable, source.lineno, source.text)
            if key in seen:
                continue
            seen.add(key)
            out.append(source)
    return out


def _text_match_key(text: str) -> str:
    normalized = (
        text.replace("\\n", "\n")
        .replace("\\t", "\t")
        .replace("\\r", "\r")
    )
    return re.sub(r"\s+", "", _compact_tex(normalized))


def _source_belongs_to_layout_panel(
    source: _SourceObject,
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]] | None,
) -> bool:
    if group_context is None:
        return False
    group_members, _ = group_context
    for group_name in group_members:
        group_lower = group_name.lower()
        if not any(keyword in group_lower for keyword in ("panel", "fixed", "frame", "stack")):
            continue
        if source.variable in _expand_group_members(group_name, group_members):
            return True
    return False


def _nearest_source_before(sources: list[_SourceObject], lineno: int) -> _SourceObject | None:
    eligible = [source for source in sources if source.lineno <= lineno]
    if eligible:
        return max(eligible, key=lambda source: (source.lineno, source.end_lineno))
    return sources[0] if sources else None


def _shift_lines_for_source(
    *,
    source_obj: _SourceObject,
    expression: str,
    indent: str,
) -> list[str]:
    if source_obj.constructor == "Group" and "[" not in source_obj.variable:
        return [
            f"{indent}for _layout_obj in {source_obj.variable}:",
            f"{indent}    _layout_obj.shift({expression})",
        ]
    return [f"{indent}{source_obj.variable}.shift({expression})"]


def _constructor_call(node: ast.AST) -> ast.Call | None:
    if isinstance(node, ast.Call):
        name = _call_name(node)
        if name in TEXT_CONSTRUCTORS or name in TEXT_FACTORY_METHODS:
            return node
        if isinstance(node.func, ast.Attribute):
            return _constructor_call(node.func.value)
    return None


def _frame_object_constructor_call(node: ast.AST) -> ast.Call | None:
    if isinstance(node, ast.Call):
        name = _call_name(node)
        if name in LINE_LIKE_FRAME_CONSTRUCTORS:
            return node
        if name == "always_redraw":
            for arg in node.args:
                if isinstance(arg, ast.Lambda):
                    constructor = _frame_object_constructor_call(arg.body)
                    if constructor is not None:
                        return constructor
        if isinstance(node.func, ast.Attribute):
            return _frame_object_constructor_call(node.func.value)
    return None


def _source_line_snippet(code: str, source: _SourceObject) -> str:
    lines = code.splitlines()
    start = max(source.lineno - 1, 0)
    end = max(source.end_lineno, source.lineno)
    return " ".join(line.strip() for line in lines[start:end])


def _split_top_level_commas(text: str) -> list[str]:
    parts: list[str] = []
    current: list[str] = []
    depth = 0
    for char in text:
        if char in "([{":
            depth += 1
        elif char in ")]}" and depth > 0:
            depth -= 1
        if char == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(char)
    if current:
        parts.append("".join(current).strip())
    return parts


def _c2p_xy_pairs(snippet: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for match in re.finditer(r"\.c2p\(([^)]*)\)", snippet):
        parts = _split_top_level_commas(match.group(1))
        if len(parts) >= 2:
            pairs.append((parts[0], parts[1]))
    return pairs


def _frame_issue_orientation(target: dict[str, Any]) -> str:
    bbox = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    width = max(_box_float(bbox, "width"), 0.0)
    height = max(_box_float(bbox, "height"), 0.0)
    if height >= max(width * 1.35, 0.2):
        return "vertical"
    if width >= max(height * 1.35, 0.2):
        return "horizontal"
    return ""


def _frame_source_orientation(code: str, source: _SourceObject) -> str:
    snippet = _source_line_snippet(code, source)
    pairs = _c2p_xy_pairs(snippet)
    if len(pairs) >= 2:
        start_x, start_y = pairs[0]
        end_x, end_y = pairs[1]
        if start_x == end_x:
            return "vertical"
        if start_y == end_y:
            return "horizontal"
    name = source.variable.lower()
    if re.search(r"(^|_)v(ertical)?(_|$)|vertical", name):
        return "vertical"
    if re.search(r"(^|_)h(orizontal)?(_|$)|horizontal", name):
        return "horizontal"
    if "UP" in snippet and "DOWN" in snippet:
        return "vertical"
    if "LEFT" in snippet and "RIGHT" in snippet:
        return "horizontal"
    return ""


def _is_after_play_frame_issue(issue: LayoutIssue, target: dict[str, Any]) -> bool:
    metadata = issue.metadata if isinstance(issue.metadata, dict) else {}
    if str(metadata.get("event") or "") == "after_play":
        return True
    return bool(target.get("path"))


def _call_name(node: ast.Call) -> str:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def _collect_string_constants(scene_cls: ast.ClassDef) -> dict[str, str | list[str]]:
    constants: dict[str, str | list[str]] = {}
    tuple_collections: dict[str, list[tuple[str, ...]]] = {}
    for node in ast.walk(scene_cls):
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            continue
        value = node.value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            constants[target.id] = value.value
        elif isinstance(value, (ast.List, ast.Tuple)):
            strings = [
                item.value
                for item in value.elts
                if isinstance(item, ast.Constant) and isinstance(item.value, str)
            ]
            if strings and len(strings) == len(value.elts):
                constants[target.id] = strings
                continue
            rows = _string_tuple_rows(value)
            if rows:
                tuple_collections[target.id] = rows
    for node in ast.walk(scene_cls):
        if not isinstance(node, ast.For):
            continue
        rows = _loop_string_rows(node.iter, tuple_collections)
        if not rows:
            continue
        names = _loop_value_target_names(node.target, enumerated=_is_enumerate_call(node.iter))
        if not names:
            continue
        width = min(len(names), min(len(row) for row in rows))
        for index in range(width):
            values = [row[index] for row in rows if row[index]]
            if values:
                constants[names[index]] = values
    return constants


def _string_tuple_rows(node: ast.List | ast.Tuple) -> list[tuple[str, ...]]:
    rows: list[tuple[str, ...]] = []
    for element in node.elts:
        if not isinstance(element, (ast.List, ast.Tuple)):
            return []
        row = tuple(
            item.value
            for item in element.elts
            if isinstance(item, ast.Constant) and isinstance(item.value, str)
        )
        if not row or len(row) != len(element.elts):
            return []
        rows.append(row)
    return rows


def _loop_string_rows(
    node: ast.AST,
    tuple_collections: dict[str, list[tuple[str, ...]]],
) -> list[tuple[str, ...]]:
    if isinstance(node, ast.Name):
        return tuple_collections.get(node.id, [])
    if _is_enumerate_call(node) and node.args and isinstance(node.args[0], ast.Name):
        return tuple_collections.get(node.args[0].id, [])
    return []


def _is_enumerate_call(node: ast.AST) -> bool:
    return isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "enumerate"


def _loop_value_target_names(node: ast.AST, *, enumerated: bool) -> list[str]:
    target = node
    if enumerated and isinstance(node, ast.Tuple) and len(node.elts) >= 2:
        target = node.elts[1]
    if isinstance(target, ast.Name):
        return [target.id]
    if not isinstance(target, ast.Tuple):
        return []
    return [item.id for item in target.elts if isinstance(item, ast.Name)]


def _collect_text_collection_items(
    *,
    node: ast.Assign,
    target_name: str,
    string_constants: dict[str, str | list[str]],
) -> list[_SourceObject]:
    value = node.value
    if not isinstance(value, (ast.List, ast.Tuple)):
        return []
    results: list[_SourceObject] = []
    for index, element in enumerate(value.elts):
        constructor = _constructor_call(element)
        if constructor is None:
            continue
        constructor_name = _call_name(constructor)
        texts = _text_args_for_constructor(constructor, string_constants)
        if not constructor_name or not texts:
            continue
        results.extend(
            _SourceObject(
                variable=f"{target_name}[{index}]",
                text=text,
                constructor=constructor_name,
                lineno=node.lineno,
                end_lineno=getattr(node, "end_lineno", node.lineno),
            )
            for text in texts
        )
    return results


def _collect_text_group_items(
    *,
    node: ast.Assign,
    target_name: str,
    string_constants: dict[str, str | list[str]],
) -> list[_SourceObject]:
    base_call = _layout_group_call(node.value)
    if base_call is None:
        return []
    results: list[_SourceObject] = []
    for index, element in enumerate(base_call.args):
        constructor = _constructor_call(element)
        if constructor is None:
            continue
        constructor_name = _call_name(constructor)
        texts = _text_args_for_constructor(constructor, string_constants)
        if not constructor_name or not texts:
            continue
        results.extend(
            _SourceObject(
                variable=f"{target_name}[{index}]",
                text=text,
                constructor=constructor_name,
                lineno=node.lineno,
                end_lineno=getattr(node, "end_lineno", node.lineno),
            )
            for text in texts
        )
    return results


def _base_call(node: ast.AST) -> ast.Call | None:
    if not isinstance(node, ast.Call):
        return None
    if isinstance(node.func, ast.Attribute):
        return _base_call(node.func.value)
    return node


def _layout_group_call(node: ast.AST) -> ast.Call | None:
    if not isinstance(node, ast.Call):
        return None
    name = _call_name(node)
    if name in LAYOUT_GROUP_CONSTRUCTORS or name in LAYOUT_GROUP_FACTORY_METHODS:
        return node
    if isinstance(node.func, ast.Attribute):
        return _layout_group_call(node.func.value)
    return None


def _space_group_key(node: ast.AST) -> str:
    if not isinstance(node, ast.Subscript):
        return ""
    value = node.value
    if not isinstance(value, ast.Name):
        return ""
    key = node.slice
    if isinstance(key, ast.Constant) and isinstance(key.value, str):
        return key.value
    return ""


def _text_args_for_constructor(
    node: ast.Call,
    string_constants: dict[str, str | list[str]] | None = None,
) -> list[str]:
    strings: list[str] = []
    dynamic_subscript_values = False
    for arg in node.args:
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            strings.append(arg.value)
        elif isinstance(arg, ast.Name) and string_constants:
            value = string_constants.get(arg.id, "")
            if isinstance(value, str) and value:
                strings.append(value)
            elif isinstance(value, list) and value:
                dynamic_subscript_values = True
                strings.extend(value)
        elif isinstance(arg, ast.Subscript) and string_constants:
            values = _string_values_from_subscript(arg, string_constants)
            if values:
                dynamic_subscript_values = True
                strings.extend(values)
        elif isinstance(arg, ast.Call) and string_constants and _call_name(arg) == "str":
            if arg.args and isinstance(arg.args[0], ast.Name):
                value = string_constants.get(arg.args[0].id, "")
                if isinstance(value, str) and value:
                    strings.append(value)
    if _call_name(node) in MULTI_TEXT_FACTORY_METHODS:
        return strings
    if _call_name(node) in {"MathTex", "Tex", "SingleStringMathTex"} and len(strings) > 1:
        joined = "".join(strings)
        with_spaces = " ".join(strings)
        return [*strings, joined, with_spaces]
    if dynamic_subscript_values:
        return strings
    return strings[:1]


def _first_string_arg(
    node: ast.Call,
    string_constants: dict[str, str | list[str]] | None = None,
) -> str:
    return next(iter(_text_args_for_constructor(node, string_constants)), "")


def _string_values_from_subscript(
    node: ast.Subscript,
    string_constants: dict[str, str | list[str]],
) -> list[str]:
    value = node.value
    if not isinstance(value, ast.Name):
        return []
    source = string_constants.get(value.id)
    if not isinstance(source, list):
        return []
    key = node.slice
    if isinstance(key, ast.Constant) and isinstance(key.value, int):
        try:
            return [source[key.value]]
        except IndexError:
            return []
    return source


def _choose_target(
    objects: list[dict[str, Any]],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if len(objects) < 2:
        return None, None
    a, b = objects[0], objects[1]
    if a.get("kind") in TEXTUAL_KINDS and b.get("kind") == "container":
        return a, b
    if b.get("kind") in TEXTUAL_KINDS and a.get("kind") == "container":
        return b, a
    if _is_external_label_overlap(a, b):
        return b, a
    if _is_external_label_overlap(b, a):
        return a, b
    if b.get("kind") == "formula":
        return b, a
    if a.get("kind") == "formula":
        return a, b
    return b, a


def _group_shift_for_external_short_label_overlap(
    *,
    source_obj: _SourceObject,
    target: dict[str, Any],
    other: dict[str, Any],
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]],
) -> _GroupShift | None:
    if not _is_short_label_overlap(target, other):
        return None
    if _is_vector_geometry_label_text(source_obj.text) or "vector_label" in source_obj.variable:
        return None
    group_members, group_sources = group_context
    candidates = [
        group_name
        for group_name in group_sources
        if source_obj.variable in _expand_group_members(group_name, group_members)
    ]
    if candidates:
        preferred = _preferred_shift_group(candidates)
        source = group_sources.get(preferred)
        if source is not None and _prefer_content_group_for_external_label_overlap(
            source_obj=source_obj,
            group_name=preferred,
            target=target,
            other=other,
        ):
            shift_expression, direction, distance = _horizontal_group_shift(target, other)
            if not shift_expression:
                direction = _direction_away_from(target, other)
                distance = _nudge_distance_from_boxes(target, other)
                shift_expression = f"{direction} * {distance:.3f}"
            shift_expression, direction = _add_graph_group_vertical_escape(
                group_name=preferred,
                target=target,
                other=other,
                shift_expression=shift_expression,
                direction=direction,
                distance=distance,
            )
            return _GroupShift(
                source=_SourceObject(
                    variable=source.variable,
                    text=source_obj.text,
                    constructor="Group",
                    lineno=source.lineno,
                    end_lineno=source.end_lineno,
                ),
                expression=shift_expression,
                direction=direction,
                distance=distance,
            )

    label_shift = _label_group_shift_for_external_short_label_overlap(
        target=target,
        other=other,
        group_sources=group_sources,
    )
    if label_shift is not None:
        return label_shift
    if not candidates:
        return None
    preferred = _preferred_shift_group(candidates)
    source = group_sources.get(preferred)
    if source is None:
        return None
    shift_expression, direction, distance = _horizontal_group_shift(target, other)
    if not shift_expression:
        direction = _direction_away_from(target, other)
        distance = _nudge_distance_from_boxes(target, other)
        shift_expression = f"{direction} * {distance:.3f}"
    shift_expression, direction = _add_graph_group_vertical_escape(
        group_name=preferred,
        target=target,
        other=other,
        shift_expression=shift_expression,
        direction=direction,
        distance=distance,
    )
    return _GroupShift(
        source=_SourceObject(
            variable=source.variable,
            text=source_obj.text,
            constructor="Group",
            lineno=source.lineno,
            end_lineno=source.end_lineno,
        ),
        expression=shift_expression,
        direction=direction,
        distance=distance,
    )


def _add_graph_group_vertical_escape(
    *,
    group_name: str,
    target: dict[str, Any],
    other: dict[str, Any],
    shift_expression: str,
    direction: str,
    distance: float,
) -> tuple[str, str]:
    if "graph" not in group_name.lower():
        return shift_expression, direction
    target_text = _compact_tex(str(target.get("text") or ""))
    if len(target_text) < 24 or "=" not in target_text:
        return shift_expression, direction
    if distance < 1.4:
        return shift_expression, direction
    vertical_direction = _direction_away_from(target, other)
    vertical_distance = _graph_group_vertical_escape_distance(target, other)
    if vertical_distance <= 0:
        return shift_expression, direction
    return (
        f"{shift_expression} + {vertical_direction} * {vertical_distance:.3f}",
        f"{direction}+{vertical_direction}",
    )


def _graph_group_vertical_escape_distance(
    target: dict[str, Any],
    other: dict[str, Any],
) -> float:
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    if not target_box or not other_box:
        return 0.0
    overlap = min(_box_float(target_box, "top"), _box_float(other_box, "top")) - max(
        _box_float(target_box, "bottom"),
        _box_float(other_box, "bottom"),
    )
    if overlap <= 0:
        return 0.0
    return round(min(0.95, max(0.55, overlap + 0.45)), 3)


def _prefer_content_group_for_external_label_overlap(
    *,
    source_obj: _SourceObject,
    group_name: str,
    target: dict[str, Any],
    other: dict[str, Any],
) -> bool:
    if group_name in {"axis_labels", "point_labels"}:
        return False
    if _is_vector_geometry_label_text(source_obj.text):
        return False
    target_text = _compact_tex(str(target.get("text") or source_obj.text))
    other_text = _compact_tex(str(other.get("text") or ""))
    if not target_text or not _is_external_label_text(other_text):
        return False
    group_lower = group_name.lower()
    if any(keyword in group_lower for keyword in ("panel", "fixed", "frame", "stack")):
        return True
    return (
        len(target_text) >= 8
        and any(marker in target_text for marker in ("=", "\\overrightarrow", "\\vec", "\\cdot"))
    )


def _shift_for_short_label_pair_overlap(
    *,
    source_obj: _SourceObject,
    target: dict[str, Any],
    other: dict[str, Any],
) -> _GroupShift | None:
    target_text = _compact_tex(str(target.get("text") or ""))
    other_text = _compact_tex(str(other.get("text") or ""))
    if not target_text or not other_text:
        return None
    if not (_is_external_label_text(target_text) and _is_external_label_text(other_text)):
        return None
    direction, distance = _short_label_pair_horizontal_shift(target, other, target_text)
    return _GroupShift(
        source=source_obj,
        expression=f"{direction} * {distance:.3f}",
        direction=direction,
        distance=distance,
    )


def _short_label_pair_horizontal_shift(
    target: dict[str, Any],
    other: dict[str, Any],
    target_text: str,
) -> tuple[str, float]:
    preferred_direction = {
        "A": "LEFT",
        "B": "RIGHT",
        "C": "LEFT",
        "D": "RIGHT",
        "O": "LEFT",
        "S": "RIGHT",
        "R": "LEFT",
        "r": "LEFT",
    }.get(target_text)
    if preferred_direction:
        direction = preferred_direction
    elif _center_x(target) >= _center_x(other):
        direction = "RIGHT"
    else:
        direction = "LEFT"

    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    overlap = 0.0
    if target_box and other_box:
        overlap = min(_box_float(target_box, "right"), _box_float(other_box, "right")) - max(
            _box_float(target_box, "left"),
            _box_float(other_box, "left"),
        )
    other_text = _compact_tex(str(other.get("text") or ""))
    min_distance = 1.05 if (
        _is_numeric_label_text(target_text) or _is_numeric_label_text(other_text)
    ) else 0.7
    distance = round(min(1.35, max(min_distance, overlap + 0.5)), 3)
    return direction, distance


def _label_group_shift_for_external_short_label_overlap(
    *,
    target: dict[str, Any],
    other: dict[str, Any],
    group_sources: dict[str, _GroupSource],
) -> _GroupShift | None:
    text = _compact_tex(str(other.get("text") or ""))
    if not text:
        return None
    if text not in {"x", "y", "z"}:
        return None
    preferred = "axis_labels"
    source = group_sources.get(preferred)
    if source is None:
        return None
    if preferred == "axis_labels":
        shift_expression, direction, distance = _axis_label_shift(target, other, text)
    else:
        shift_expression, direction, distance = _horizontal_label_shift(target, other)
    if not shift_expression:
        return None
    if preferred == "point_labels":
        distance = max(distance, 1.3)
        shift_expression = f"{direction} * {distance:.3f}"
    return _GroupShift(
        source=_SourceObject(
            variable=source.variable,
            text=str(other.get("text") or ""),
            constructor="Group",
            lineno=source.lineno,
            end_lineno=source.end_lineno,
        ),
        expression=shift_expression,
        direction=direction,
        distance=distance,
    )


def _source_shift_for_external_label_overlap(
    *,
    by_text: dict[str, list[_SourceObject]],
    target: dict[str, Any],
    other: dict[str, Any],
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]] | None = None,
) -> _GroupShift | None:
    if _is_external_label_overlap(other, target):
        label = other
        content = target
    elif _is_external_label_overlap(target, other):
        label = target
        content = other
    else:
        return None

    label_text = str(label.get("text") or "")
    compact = _compact_tex(label_text)
    content_text = str(content.get("text") or "")
    content_compact = _compact_tex(content_text)
    if content.get("kind") == "formula" and _should_move_formula_for_label_overlap(
        label_text=compact,
        content_text=content_compact,
    ):
        matches = _source_matches_for_text(by_text, content_text)
        if len(matches) != 1:
            return None
        source = matches[0]
        shift_expression, direction, distance = _formula_content_shift_away_from_label(
            label=label,
            content=content,
            content_text=content_compact,
        )
        if not shift_expression:
            return None
        return _GroupShift(
            source=source,
            expression=shift_expression,
            direction=direction,
            distance=distance,
        )
    if (
        content.get("kind") == "formula"
        and label.get("kind") == "formula"
        and _is_external_label_text(compact)
        and compact not in {"x", "y", "z"}
        and not _is_external_label_text(content_compact)
        and not _is_vector_algebra_formula_text(content_compact)
    ):
        matches = _source_matches_for_text(by_text, content_text)
        if len(matches) == 1 and not _source_belongs_to_layout_panel(
            matches[0],
            group_context,
        ):
            source = matches[0]
            shift_expression, direction, distance = _formula_content_shift_away_from_label(
                label=label,
                content=content,
                content_text=content_compact,
            )
            if shift_expression:
                return _GroupShift(
                    source=source,
                    expression=shift_expression,
                    direction=direction,
                    distance=distance,
                )
    if content.get("kind") == "formula":
        return None

    matches = _source_matches_for_text(by_text, label_text)
    if len(matches) != 1:
        return None
    source = matches[0]
    if compact in {"x", "y", "z"}:
        shift_expression, direction, distance = _axis_label_shift(content, label, compact)
    else:
        shift_expression, direction, distance = _horizontal_label_shift(content, label)
        if not shift_expression:
            shift_expression, direction, distance = _vertical_label_shift(content, label)
    if not shift_expression:
        return None
    return _GroupShift(
        source=source,
        expression=shift_expression,
        direction=direction,
        distance=distance,
    )


def _source_shift_for_dimension_label_shape_overlap(
    *,
    by_text: dict[str, list[_SourceObject]],
    target: dict[str, Any],
    other: dict[str, Any],
) -> _GroupShift | None:
    label, shape = _dimension_label_and_shape(target, other)
    if label is None or shape is None:
        return None
    label_text = str(label.get("text") or "")
    matches = _source_matches_for_text(by_text, label_text)
    if len(matches) != 1:
        return None
    direction, distance = _dimension_label_escape(label=label, shape=shape)
    if not direction:
        return None
    return _GroupShift(
        source=matches[0],
        expression=f"{direction} * {distance:.3f}",
        direction=direction,
        distance=distance,
    )


def _should_force_text_line_overlap_repair(issue: LayoutIssue) -> bool:
    """Allow deterministic repair for visual-review text/line overlaps.

    The post-render visual judge may classify a full text-vs-Line collision as
    `label_shape_overlap_risk` and set deterministic_repairable=False because a
    generic label/shape overlap can be ambiguous.  A long safe_text_box fully
    covering a horizontal Line is not a geometry-label ambiguity: shrinking or
    moving the text is deterministic and avoids an expensive LLM repair loop.
    """
    if issue.code != "layout_overlap_error" or not issue.repairable:
        return False
    if float(issue.overlap_ratio or 0.0) < 0.45:
        return False
    if float(issue.y_overlap or 0.0) <= 0:
        return False
    objects = list(issue.objects or [])
    text_objects = [
        obj
        for obj in objects
        if obj.get("kind") in TEXTUAL_KINDS and str(obj.get("text") or "").strip()
    ]
    line_objects = [obj for obj in objects if _is_line_like_shape_object(obj)]
    if not text_objects or not line_objects:
        return False
    if any(_is_external_label_text(_compact_tex(str(obj.get("text") or ""))) for obj in text_objects):
        return False
    return True


def _is_line_like_shape_object(obj: dict[str, Any]) -> bool:
    if str(obj.get("text") or "").strip():
        return False
    klass = str(obj.get("class") or "")
    if klass in {"Line", "DashedLine", "Arrow", "DoubleArrow"}:
        return True
    kind = str(obj.get("kind") or "")
    return kind in {"line"} and bool(klass)


def _dimension_label_and_shape(
    first: dict[str, Any],
    second: dict[str, Any],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if _is_dimension_label_object(first) and _is_graphical_shape_object(second):
        return first, second
    if _is_dimension_label_object(second) and _is_graphical_shape_object(first):
        return second, first
    return None, None


def _is_dimension_label_object(obj: dict[str, Any]) -> bool:
    if obj.get("kind") not in TEXTUAL_KINDS:
        return False
    return _is_dimension_label_text(str(obj.get("text") or ""))


def _is_dimension_label_text(text: str) -> bool:
    normalized = re.sub(r"\s+", "", text.strip())
    if not normalized or not any(char.isdigit() for char in normalized):
        return False
    has_unit = any(
        unit in normalized
        for unit in ("厘米", "分米", "毫米", "千米", "cm", "dm", "mm", "km", "m")
    )
    has_dimension_word = any(
        keyword in normalized
        for keyword in ("高", "长", "宽", "底", "边", "边长", "半径", "直径", "斜边", "棱")
    )
    if has_unit and has_dimension_word:
        return True
    return bool(re.search(r"\d+(?:\.\d+)?(?:厘米|分米|毫米|千米|cm|dm|mm|km|m)$", normalized))


def _is_graphical_shape_object(obj: dict[str, Any]) -> bool:
    if obj.get("kind") in TEXTUAL_KINDS:
        return False
    if str(obj.get("text") or "").strip():
        return False
    klass = str(obj.get("class") or "")
    if klass in {
        "Polygon",
        "Rectangle",
        "RoundedRectangle",
        "Square",
        "Circle",
        "Ellipse",
        "Line",
        "Arrow",
        "DoubleArrow",
        "Brace",
        "Arc",
    }:
        return True
    return obj.get("kind") in {"shape", "polygon", "geometry", "line"}


def _dimension_label_escape(
    *,
    label: dict[str, Any],
    shape: dict[str, Any],
) -> tuple[str, float]:
    label_box = label.get("bbox") if isinstance(label.get("bbox"), dict) else {}
    shape_box = shape.get("bbox") if isinstance(shape.get("bbox"), dict) else {}
    if not label_box or not shape_box:
        return "", 0.0
    label_text = str(label.get("text") or "")
    prefer_horizontal = any(keyword in label_text for keyword in ("高", "宽", "直径", "半径"))
    if prefer_horizontal or abs(_center_x(label) - _center_x(shape)) >= abs(
        _center_y(label) - _center_y(shape)
    ):
        if _center_x(label) >= _center_x(shape):
            distance = _box_float(shape_box, "right") - _box_float(label_box, "left") + 0.25
            direction = "RIGHT"
        else:
            distance = _box_float(label_box, "right") - _box_float(shape_box, "left") + 0.25
            direction = "LEFT"
    elif _center_y(label) >= _center_y(shape):
        distance = _box_float(shape_box, "top") - _box_float(label_box, "bottom") + 0.22
        direction = "UP"
    else:
        distance = _box_float(label_box, "top") - _box_float(shape_box, "bottom") + 0.22
        direction = "DOWN"
    return direction, round(min(1.45, max(0.45, distance)), 3)


def _should_move_formula_for_label_overlap(
    *,
    label_text: str,
    content_text: str,
) -> bool:
    if not label_text or not content_text:
        return False
    if label_text == "y":
        return False
    if _is_vector_geometry_label_text(content_text):
        return True
    return label_text in {"x", "z"} and not _is_external_label_text(content_text)


def _is_vector_algebra_formula_text(text: str) -> bool:
    return any(marker in text for marker in ("\\vec", "\\overrightarrow", "\\Delta"))


def _formula_content_shift_away_from_label(
    *,
    label: dict[str, Any],
    content: dict[str, Any],
    content_text: str,
) -> tuple[str, str, float]:
    if _is_vector_geometry_label_text(content_text):
        direction, distance = _vector_label_horizontal_shift(content, label)
        return f"{direction} * {distance:.3f}", direction, distance
    shift_expression, direction, distance = _horizontal_label_shift(label, content)
    if shift_expression:
        distance = round(max(distance, 0.9), 3)
        return f"{direction} * {distance:.3f}", direction, distance
    shift_expression, direction, distance = _vertical_label_shift(label, content)
    if shift_expression:
        distance = round(max(distance, 0.75), 3)
        return f"{direction} * {distance:.3f}", direction, distance
    return "", "", 0.0


def _vector_label_horizontal_shift(
    target: dict[str, Any],
    other: dict[str, Any],
) -> tuple[str, float]:
    direction = "RIGHT" if _center_x(target) >= _center_x(other) else "LEFT"
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    overlap = 0.0
    if target_box and other_box:
        overlap = min(_box_float(target_box, "right"), _box_float(other_box, "right")) - max(
            _box_float(target_box, "left"),
            _box_float(other_box, "left"),
        )
    distance = round(min(1.35, max(0.9, overlap + 0.6)), 3)
    return direction, distance


def _axis_label_shift(
    target: dict[str, Any],
    other: dict[str, Any],
    label_text: str,
) -> tuple[str, str, float]:
    if label_text == "y":
        shift_expression, direction, distance = _vertical_label_shift(target, other)
        if direction == "DOWN" and _is_top_title_axis_overlap(target, other):
            distance = max(distance, 1.35)
            shift_expression = f"{direction} * {distance:.3f}"
        return shift_expression, direction, distance
    horizontal = _horizontal_label_shift(target, other)
    if horizontal[0]:
        return horizontal
    return _vertical_label_shift(target, other)


def _is_top_title_axis_overlap(target: dict[str, Any], other: dict[str, Any]) -> bool:
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    if not target_box or not other_box:
        return False
    return max(_box_float(target_box, "top"), _box_float(other_box, "top")) >= 3.0


def _vertical_label_shift(
    target: dict[str, Any],
    other: dict[str, Any],
) -> tuple[str, str, float]:
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    if not target_box or not other_box:
        return "", "", 0.0

    overlap = min(_box_float(target_box, "top"), _box_float(other_box, "top")) - max(
        _box_float(target_box, "bottom"),
        _box_float(other_box, "bottom"),
    )
    if overlap <= 0:
        overlap = abs(_center_y(target) - _center_y(other))
    direction = "UP" if _center_y(other) >= _center_y(target) else "DOWN"
    distance = round(min(1.2, max(0.35, overlap + 0.35)), 3)
    return f"{direction} * {distance:.3f}", direction, distance


def _horizontal_label_shift(
    target: dict[str, Any],
    other: dict[str, Any],
) -> tuple[str, str, float]:
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    if not target_box or not other_box:
        return "", "", 0.0

    target_left = _box_float(target_box, "left")
    target_right = _box_float(target_box, "right")
    other_left = _box_float(other_box, "left")
    other_right = _box_float(other_box, "right")
    if target_left == target_right or other_left == other_right:
        return "", "", 0.0

    if target_right >= other_right:
        direction = "LEFT"
        distance = other_right - target_left + 0.15
    else:
        direction = "RIGHT"
        distance = target_right - other_left + 0.15
    distance = round(min(1.45, max(0.35, distance)), 3)
    return f"{direction} * {distance:.3f}", direction, distance


def _horizontal_group_shift(
    target: dict[str, Any],
    other: dict[str, Any],
) -> tuple[str, str, float]:
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    other_box = other.get("bbox") if isinstance(other.get("bbox"), dict) else {}
    if not target_box or not other_box:
        return "", "", 0.0

    target_left = _box_float(target_box, "left")
    target_right = _box_float(target_box, "right")
    other_left = _box_float(other_box, "left")
    other_right = _box_float(other_box, "right")
    if target_left == target_right or other_left == other_right:
        return "", "", 0.0

    if target_right >= other_right:
        direction = "RIGHT"
        distance = other_right - target_left + 0.15
    else:
        direction = "LEFT"
        distance = target_right - other_left + 0.15
    distance = round(min(1.45, max(0.35, distance)), 3)
    return f"{direction} * {distance:.3f}", direction, distance


def _nudge_distance_from_boxes(target: dict[str, Any], other: dict[str, Any]) -> float:
    return round(
        min(
            1.2,
            max(0.2, abs(_center_y(target) - _center_y(other)) + 0.45),
        ),
        3,
    )


def _is_short_label_overlap(target: dict[str, Any], other: dict[str, Any]) -> bool:
    return _is_external_label_overlap(other, target)


def _is_external_label_overlap(label_obj: dict[str, Any], content_obj: dict[str, Any]) -> bool:
    label_text = _compact_tex(str(label_obj.get("text") or ""))
    content_text = _compact_tex(str(content_obj.get("text") or ""))
    if not label_text or not content_text:
        return False
    label_like = _is_external_label_text(label_text)
    content_label_like = _is_external_label_text(content_text)
    if label_like == content_label_like:
        return False
    return label_like and not content_label_like


def _is_external_label_text(text: str) -> bool:
    if text in {"x", "y", "z"}:
        return True
    if len(text) <= 3 and not any(operator in text for operator in {"+", "-", "=", "*", "/", "\\"}):
        return True
    return len(text) <= 18 and "(" in text and "," in text


def _is_numeric_label_text(text: str) -> bool:
    normalized = text.strip()
    if not normalized:
        return False
    if normalized.startswith("-"):
        normalized = normalized[1:]
    return normalized.replace(".", "", 1).isdigit()


def _is_vector_geometry_label_text(text: str) -> bool:
    compact = _compact_tex(text)
    if "\\frac12\\vec" in compact or compact.startswith("\\frac12vec"):
        return True
    if "=" in compact or "\\cdot" in compact:
        return False
    return any(
        marker in compact
        for marker in ("\\overrightarrow", "\\vec", "\\overline")
    )


def _compact_tex(text: str) -> str:
    return (
        text.replace("\\\\", "")
        .replace("{", "")
        .replace("}", "")
        .replace(" ", "")
        .replace("^", "")
        .replace("_", "")
    )


def _preferred_shift_group(candidates: list[str]) -> str:
    for keyword in ("panel", "fixed", "frame"):
        matching = [name for name in candidates if keyword in name.lower()]
        if matching:
            return max(matching, key=len)
    for keyword in ("stack", "group"):
        matching = [name for name in candidates if keyword in name.lower()]
        if matching:
            return max(matching, key=len)
    return max(candidates, key=len)


def _direction_away_from(target: dict[str, Any], other: dict[str, Any]) -> str:
    target_y = _center_y(target)
    other_y = _center_y(other)
    return "DOWN" if target_y <= other_y else "UP"


def _center_y(obj: dict[str, Any]) -> float:
    bbox = obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {}
    try:
        return float(bbox.get("center_y", 0.0))
    except (TypeError, ValueError):
        return 0.0


def _center_x(obj: dict[str, Any]) -> float:
    bbox = obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {}
    try:
        return float(bbox.get("center_x", 0.0))
    except (TypeError, ValueError):
        return 0.0


def _nudge_distance(issue: LayoutIssue) -> float:
    return round(min(1.2, max(0.2, float(issue.y_overlap or 0.0) + 0.25)), 3)


def _safe_shift_max(aspect_ratio: str, axis: str) -> float:
    """根据画幅返回单次 shift 在指定轴向 (x/y) 的安全最大距离。

    16:9 横屏 frame 14.22×8（safe ≈ ±7,±4）→ x 上限 1.45（保留旧行为）
    9:16 竖屏 frame  4.5×8 （safe ≈ ±2.25,±4）→ x 上限 0.7（避免越界）
    y 方向横竖屏画幅高度都是 8，沿用上游函数自身的 1.2 / 1.35 上限不再额外 cap。
    """
    portrait = (aspect_ratio or "").strip() == "9:16"
    if axis == "x":
        return 0.7 if portrait else 1.45
    # y 方向不做额外裁剪（用 inf 等价），保留上游函数本身的上限。
    return float("inf")


def _is_short_anchor_label_text(text: str) -> bool:
    """≤3 char 紧凑文本（A'/A1/x 等几何标注），不应被远距离 shift。"""
    compact = _compact_tex(text)
    if not compact:
        return False
    if len(compact) > 3:
        return False
    return not any(op in compact for op in {"+", "-", "=", "*", "/", "\\"})


def _is_geometry_anchor_label_text(text: str) -> bool:
    """点标签、边长标签、斜边标签等锚定几何标注都不能远距离漂移。"""
    if _is_short_anchor_label_text(text):
        return True
    compact = _compact_tex(text)
    if not compact or len(compact) > 24:
        return False
    if any("\u4e00" <= char <= "\u9fff" for char in compact):
        return False
    if "=" not in compact:
        return False
    left, _, right = compact.partition("=")
    if not left or not right:
        return False
    if len(left) > 4:
        return False
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9'′]*", left):
        return False
    return not any(marker in compact for marker in ("+", "\\sum", "\\int"))


_ANCHOR_FACTORY_NAMES = (
    "label_at",
    "tex_label",
    "make_label",
    "build_vector_label",
    "create_vertex_label",
    "portrait_formula",
)
_ANCHOR_FACTORY_PATTERNS = tuple(
    re.compile(rf"(?:self\.|\b){name}\s*\(")
    for name in _ANCHOR_FACTORY_NAMES
)
_GEOMETRY_MOVE_TO_ANCHOR_TOKENS = (
    "edge_",
    "pt_",
    "point_",
    "_dot",
    "line_",
    "diag_",
    "diagonal",
    "vertex",
    "side_",
    "hypotenuse",
)


def _variable_already_mutated(code: str, source_obj: "_SourceObject") -> bool:
    """检测变量是否已经被 ``.shift(`` 或 ``.scale(`` 链式 mutate 过。

    扫描 source_obj 定义起始行起 30 行内是否出现 ``<var>.shift(`` 或 ``<var>.scale(``，
    若是说明上一轮 pass 已经注入过位移/缩放。再叠加只会让对象不停放大缩小或飞远。

    起点用 ``source_obj.lineno`` 而非 ``end_lineno + 1``，因为 ``_collect_scene_objects``
    会把链式的 ``.shift()`` 一并算入 ``end_lineno``，end_lineno 之后通常已不含 mutate。
    """
    var = source_obj.variable
    if not var:
        return False
    lines = code.splitlines()
    start = max(1, source_obj.lineno + 1)
    end = min(len(lines), start + 30)
    needle_shift = f"{var}.shift("
    needle_scale = f"{var}.scale("
    for i in range(start, end + 1):
        snippet = lines[i - 1]
        if needle_shift in snippet or needle_scale in snippet:
            return True
    return False


def _variable_has_positioning_after_assignment(
    code: str,
    source_obj: "_SourceObject",
) -> bool:
    var = source_obj.variable
    if not var or "[" in var:
        return False
    lines = code.splitlines()
    start = max(1, source_obj.lineno + 1)
    end = min(len(lines), max(source_obj.end_lineno, source_obj.lineno + 8))
    methods = ("move_to", "next_to", "to_edge", "to_corner", "shift")
    for index in range(start, end + 1):
        snippet = lines[index - 1]
        if any(f"{var}.{method}(" in snippet for method in methods):
            return True
    return False


def _safe_text_box_manual_layout_scale_lines(
    *,
    by_text: dict[str, list[_SourceObject]],
    issue: LayoutIssue,
    code: str,
    scene_name: str,
    aspect_ratio: str,
) -> tuple[list[str], dict[str, Any] | None, _SourceObject | None]:
    """Shrink manually positioned safe_text_box content before asking the LLM.

    Generated scenes often place explanatory text with safe_text_box(), then
    move_to()/shift() it into a panel. Older deterministic logic skipped those
    variables because they were already mutated, which left repeated overlap
    issues for the expensive slice fixer. For these boxes, an additional scale
    after the final positioning call is deterministic and does not change the
    scene structure.
    """
    if issue.code in CONTAINER_ISSUE_CODES or issue.code in FRAME_ISSUE_CODES:
        return [], None, None
    candidates: list[tuple[int, dict[str, Any], _SourceObject]] = []
    for obj in issue.objects:
        if obj.get("kind") not in TEXTUAL_KINDS:
            continue
        text = str(obj.get("text") or "")
        if not text:
            continue
        if _is_external_label_text(_compact_tex(text)):
            continue
        matches = _source_matches_for_text(by_text, text)
        if len(matches) != 1:
            continue
        source = matches[0]
        if source.constructor != "safe_text_box":
            continue
        if not (
            _variable_already_mutated(code, source)
            or _variable_has_positioning_after_assignment(code, source)
        ):
            continue
        candidates.append((len(_compact_tex(text)), obj, source))
    if not candidates:
        return [], None, None

    _, target, source = max(candidates, key=lambda item: item[0])
    line = _line_at(code, source.lineno)
    indent = line[: len(line) - len(line.lstrip())]
    bbox = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    width = max(_box_float(bbox, "width"), 0.1)
    height = max(_box_float(bbox, "height"), 0.1)
    x_pressure = max(0.0, float(issue.x_overlap or 0.0)) / width
    y_pressure = max(0.0, float(issue.y_overlap or 0.0)) / height
    overlap_pressure = max(0.0, float(issue.overlap_ratio or 0.0)) * 0.35
    pressure = max(x_pressure * 0.75, y_pressure * 0.55, overlap_pressure)
    lower_bound = 0.70 if (aspect_ratio or "").strip() == "9:16" else 0.72
    scale = round(max(lower_bound, min(0.92, 1.0 - pressure)), 3)
    top_escape = _safe_text_box_top_title_escape_lines(
        source=source,
        target=target,
        issue=issue,
        code=code,
        indent=indent,
        scale=scale,
    )
    if top_escape is not None:
        lines, action = top_escape
        return lines, action, source
    action = {
        "scene_name": scene_name,
        "target_text": str(target.get("text") or ""),
        "target_variable": source.variable,
        "method": "safe_text_box_scale_after_manual_layout",
        "scale": scale,
        "issue_code": issue.code,
        "aspect_ratio": aspect_ratio,
    }
    return [f"{indent}{source.variable}.scale({scale:.3f})"], action, source


def _safe_text_box_top_title_escape_lines(
    *,
    source: _SourceObject,
    target: dict[str, Any],
    issue: LayoutIssue,
    code: str,
    indent: str,
    scale: float,
) -> tuple[list[str], dict[str, Any]] | None:
    """Move top titles out of the geometry label band before LLM repair.

    A common generated layout puts `safe_text_box(..., area="top")` at the
    center of the top canvas, while point labels such as D' sit just below the
    frame top. Scaling the title alone leaves both objects on the same baseline,
    so use a small upward escape as the deterministic first repair.
    """
    if not _source_is_top_title_safe_text_box(code, source):
        return None
    label = _external_label_counterpart(issue, target)
    if label is None:
        return None
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    if not target_box:
        return None
    if _center_y(target) < 2.0:
        return None

    top_limit = 3.72
    available = top_limit - _box_float(target_box, "top")
    if available < 0.18:
        return None
    raw_distance = max(0.42, min(0.68, float(issue.y_overlap or 0.0) + 0.40))
    distance = round(max(0.18, min(raw_distance, available)), 3)
    title_scale = round(max(0.80, min(0.90, scale)), 3)
    lines = [
        f"{indent}{source.variable}.scale({title_scale:.3f})",
        f"{indent}{source.variable}.shift(UP * {distance:.3f})",
    ]
    return lines, {
        "scene_name": issue.scene_name,
        "target_text": str(target.get("text") or ""),
        "target_variable": source.variable,
        "method": "safe_text_box_top_title_escape",
        "scale": title_scale,
        "shift_y": distance,
        "label_text": str(label.get("text") or ""),
        "issue_code": issue.code,
    }


def _source_is_top_title_safe_text_box(code: str, source: _SourceObject) -> bool:
    if source.constructor != "safe_text_box":
        return False
    lines = code.splitlines()
    start = max(0, source.lineno - 1)
    end = min(len(lines), source.end_lineno + 2)
    window = "\n".join(lines[start:end])
    return (
        'area="top"' in window
        or "area='top'" in window
        or 'layout_canvas("top")' in window
        or "layout_canvas('top')" in window
    )


def _external_label_counterpart(
    issue: LayoutIssue,
    target: dict[str, Any],
) -> dict[str, Any] | None:
    for obj in issue.objects:
        if obj is target:
            continue
        text = _compact_tex(str(obj.get("text") or ""))
        if not _is_external_label_text(text):
            continue
        if _center_y(obj) < 1.8:
            continue
        return obj
    return None


def _line_has_next_to_anchor(code: str, lineno: int) -> bool:
    """判断 source 定义所在行（及紧邻几行）是否锚定到几何对象。

    锚定形式：
    1. ``.next_to(dot, UP, ...)`` 的链式调用；LLM 常把 ``label = MathTex("A'").next_to(...)``
       拆成多行；
    2. ``self.label_at(...)`` / ``self.tex_label(...)`` / ``make_label(...)`` /
       ``build_vector_label(...)`` 等几何标注工厂方法（内部封装了 next_to）。
    3. ``.move_to(edge_*_center + ...)`` / ``.move_to(pt_* + ...)`` 等直接锚到边/点/线的形式。

    任一形式命中即视为锚定标签，禁止远距离 shift。
    """
    lines = code.splitlines()
    if lineno < 1 or lineno > len(lines):
        return False
    end = min(len(lines), lineno + 5)
    for i in range(lineno, end + 1):
        snippet = lines[i - 1]
        if ".next_to(" in snippet:
            return True
        if ".move_to(" in snippet and any(
            token in snippet for token in _GEOMETRY_MOVE_TO_ANCHOR_TOKENS
        ):
            return True
        for pattern in _ANCHOR_FACTORY_PATTERNS:
            if pattern.search(snippet):
                return True
    return False


def _clamp_shift_for_layout(
    expression: str,
    direction: str,
    distance: float,
    *,
    target_text: str,
    source_obj: _SourceObject,
    code: str,
    aspect_ratio: str,
) -> tuple[str, float, bool]:
    """对 shift 距离做画幅 + 锚点安全裁剪。

    1. 横/竖屏感知：竖屏 x 上限收紧到 0.7，防止越出 4.5 宽的 9:16 画幅。
    2. `.next_to(...)` 锚定的几何标注（点标签、边长标签、斜边标签）强制 ≤ 0.4，
       避免 rigid shift 让 label 飞离它的锚点 1.45 单位破坏几何关系。

    返回新 ``(expression, distance, anchor_protected)``。
    """
    # 复合方向（如 ``RIGHT+DOWN``）或多段 shift（``RIGHT * 1.5 + DOWN * 0.7``）
    # 已经是上游 group/escape 计算后的结果，不在本函数职责内重新拼装；
    # 直接放行，避免破坏既有 graph_group 等横向饱和后再追加纵向逃逸的复合 shift。
    simple_direction = direction in {"LEFT", "RIGHT", "UP", "DOWN"}
    if not simple_direction or "+" in expression:
        return expression, distance, False
    axis = "x" if direction in {"LEFT", "RIGHT"} else "y"
    max_distance = _safe_shift_max(aspect_ratio, axis)
    anchor_protected = False
    if _is_geometry_anchor_label_text(target_text) and _line_has_next_to_anchor(
        code, source_obj.lineno
    ):
        max_distance = min(max_distance, 0.4)
        anchor_protected = True
    if distance <= max_distance:
        return expression, distance, anchor_protected
    new_distance = round(max_distance, 3)
    new_expression = f"{direction} * {new_distance:.3f}"
    return new_expression, new_distance, anchor_protected


def _container_adjustment_lines(
    *,
    source_obj: _SourceObject,
    target: dict[str, Any],
    container: dict[str, Any],
    issue: LayoutIssue,
    indent: str,
) -> tuple[list[str], dict[str, Any]]:
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    container_box = container.get("bbox") if isinstance(container.get("bbox"), dict) else {}
    if not target_box or not container_box:
        return [], {}

    padding = _container_padding(target_box)
    scale = _container_fit_scale(target_box, container_box, padding)
    if issue.code == "layout_container_overflow" and _is_short_chinese_badge(target):
        scale = min(scale, 0.72)
    if issue.code == "layout_container_border_overlap":
        scale = 0.82 if scale > 0.9 else min(scale, 0.92)
    dx, dy = _shift_into_container(target_box, container_box, padding)
    if container.get("class") == "SurroundingRectangle" and (abs(dx) > 0.3 or abs(dy) > 0.3):
        scale = min(scale, 0.82)
        dx = 0.0
        dy = 0.0

    lines: list[str] = []
    if scale < 0.98:
        lines.append(f"{indent}{source_obj.variable}.scale({scale:.3f})")
    shift_expr = _shift_expression(dx, dy)
    if shift_expr:
        lines.extend(
            _shift_lines_for_source(
                source_obj=source_obj,
                expression=shift_expr,
                indent=indent,
            )
        )
    if not lines:
        return [], {}
    return lines, {
        "scene_name": issue.scene_name,
        "target_text": source_obj.text,
        "target_variable": source_obj.variable,
        "method": "container_text_fit",
        "issue_code": issue.code,
        "scale": scale,
        "shift_x": dx,
        "shift_y": dy,
    }


def _tape_diagram_label_align_reset(
    *,
    tree: ast.AST,
    code: str,
    source_obj: _SourceObject,
    target: dict[str, Any],
    container: dict[str, Any],
    issue: LayoutIssue,
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]],
) -> tuple[int | None, dict[str, Any] | None]:
    """Remove child label alignment that collapses an already-arranged tape row."""
    if issue.code != "layout_container_overflow":
        return None, None
    if not _is_short_chinese_badge(target):
        return None, None
    if str(container.get("class") or "") not in {"Rectangle", "Square"}:
        return None, None
    group_name = _tape_row_group_for_label(
        code=code,
        source_obj=source_obj,
        group_context=group_context,
    )
    if not group_name:
        return None, None
    align_line = _horizontal_align_to_line(
        tree,
        source_obj.variable,
        min_lineno=source_obj.lineno,
        max_lineno=max(source_obj.end_lineno, source_obj.lineno + 24),
    )
    if align_line is None:
        return None, None
    lines = code.splitlines()
    removed = lines[align_line - 1].strip() if 0 < align_line <= len(lines) else ""
    return align_line, {
        "scene_name": issue.scene_name,
        "target_text": source_obj.text,
        "target_variable": source_obj.variable,
        "row_variable": group_name,
        "method": "tape_diagram_label_align_reset",
        "issue_code": issue.code,
        "removed_line": removed,
    }


def _tape_row_group_for_label(
    *,
    code: str,
    source_obj: _SourceObject,
    group_context: tuple[dict[str, list[str]], dict[str, _GroupSource]],
) -> str:
    if "[" in source_obj.variable:
        return ""
    group_members, group_sources = group_context
    lines = code.splitlines()
    for group_name, members in group_members.items():
        if len(members) < 2 or members[0] != source_obj.variable:
            continue
        source = group_sources.get(group_name)
        if source is None or source.lineno < source_obj.lineno:
            continue
        source_text = "\n".join(lines[source.lineno - 1 : source.end_lineno])
        if ".arrange(" not in source_text or "RIGHT" not in source_text:
            continue
        if not _looks_like_tape_row_member(members[1]):
            continue
        return group_name
    return ""


def _looks_like_tape_row_member(variable: str) -> bool:
    normalized = variable.lower()
    return any(
        marker in normalized
        for marker in ("block", "bar", "cell", "rect", "segment", "unit")
    )


def _horizontal_align_to_line(
    tree: ast.AST,
    variable: str,
    *,
    min_lineno: int,
    max_lineno: int,
) -> int | None:
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if not isinstance(func, ast.Attribute) or func.attr != "align_to":
            continue
        if not isinstance(func.value, ast.Name) or func.value.id != variable:
            continue
        lineno = getattr(node, "lineno", None)
        if lineno is None or lineno < min_lineno or lineno > max_lineno:
            continue
        if _align_to_uses_horizontal_direction(node):
            return lineno
    return None


def _align_to_uses_horizontal_direction(node: ast.Call) -> bool:
    for arg in node.args[1:]:
        if _ast_direction_name(arg) in {"LEFT", "RIGHT"}:
            return True
    for keyword in node.keywords:
        if keyword.arg in {"direction", "aligned_edge"} and _ast_direction_name(
            keyword.value
        ) in {"LEFT", "RIGHT"}:
            return True
    return False


def _ast_direction_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""


def _frame_overflow_adjustment_lines(
    *,
    by_text: dict[str, list[_SourceObject]],
    frame_objects: list[_SourceObject],
    issue: LayoutIssue,
    code: str,
) -> tuple[list[str], dict[str, Any], _SourceObject | None]:
    if not issue.objects:
        return [], {}, None
    target = issue.objects[0]
    target_text = str(target.get("text") or "")
    matches = _source_matches_for_text(by_text, target_text)
    target_class = str(target.get("class") or "")
    if len(matches) == 1:
        source_obj = matches[0]
    else:
        if target_text or target_class not in LINE_LIKE_FRAME_CONSTRUCTORS:
            return [], {}, None
        visual_matches = [
            source
            for source in frame_objects
            if source.constructor == target_class
        ]
        if _is_after_play_frame_issue(issue, target) and len(visual_matches) > 1:
            moving_matches = [
                source
                for source in visual_matches
                if source.variable.lower().startswith("moving_")
            ]
            if moving_matches:
                visual_matches = [moving_matches[-1]]
        orientation = _frame_issue_orientation(target)
        if orientation and len(visual_matches) > 1:
            oriented_matches = [
                source
                for source in visual_matches
                if _frame_source_orientation(code, source) == orientation
            ]
            if len(oriented_matches) == 1:
                visual_matches = oriented_matches
        if len(visual_matches) != 1:
            return [], {}, None
        source_obj = visual_matches[0]
    target_box = target.get("bbox") if isinstance(target.get("bbox"), dict) else {}
    frame = issue.metadata.get("frame") if isinstance(issue.metadata, dict) else {}
    if not target_box or not isinstance(frame, dict) or not frame:
        return [], {}, None
    dx, dy = _shift_into_frame(target_box, frame, padding=0.12)
    shift_expr = _shift_expression(dx, dy)
    if not shift_expr:
        return [], {}, None
    line = _line_at(code, source_obj.lineno)
    indent = line[: len(line) - len(line.lstrip())]
    action = {
        "scene_name": issue.scene_name,
        "target_variable": source_obj.variable,
        "issue_code": issue.code,
        "shift_x": dx,
        "shift_y": dy,
        "frame": frame,
    }
    if source_obj.text:
        action["target_text"] = source_obj.text
    if target_class:
        action["target_class"] = target_class
    return (
        _frame_shift_lines_for_source(
            code=code,
            source_obj=source_obj,
            expression=shift_expr,
            indent=indent,
        ),
        action,
        source_obj,
    )


def _frame_shift_lines_for_source(
    *,
    code: str,
    source_obj: _SourceObject,
    expression: str,
    indent: str,
) -> list[str]:
    snippet = _source_line_snippet(code, source_obj)
    if (
        source_obj.constructor in LINE_LIKE_FRAME_CONSTRUCTORS
        and "always_redraw" in snippet
    ):
        return [
            f"{indent}{source_obj.variable}.add_updater("
            f"lambda _layout_obj: _layout_obj.shift({expression}))"
        ]
    return _shift_lines_for_source(
        source_obj=source_obj,
        expression=expression,
        indent=indent,
    )


def _shift_into_frame(
    target_box: dict[str, Any],
    frame: dict[str, Any],
    *,
    padding: float,
) -> tuple[float, float]:
    dx = 0.0
    dy = 0.0
    left_limit = _box_float(frame, "left") + padding
    right_limit = _box_float(frame, "right") - padding
    top_limit = _box_float(frame, "top") - padding
    bottom_limit = _box_float(frame, "bottom") + padding
    if _box_float(target_box, "left") < left_limit:
        dx += left_limit - _box_float(target_box, "left")
    if _box_float(target_box, "right") > right_limit:
        dx -= _box_float(target_box, "right") - right_limit
    if _box_float(target_box, "bottom") < bottom_limit:
        dy += bottom_limit - _box_float(target_box, "bottom")
    if _box_float(target_box, "top") > top_limit:
        dy -= _box_float(target_box, "top") - top_limit
    return round(max(-1.2, min(1.2, dx)), 3), round(max(-1.2, min(1.2, dy)), 3)


def _container_padding(target_box: dict[str, Any]) -> float:
    text_min_size = min(_box_float(target_box, "width"), _box_float(target_box, "height"))
    return round(min(0.10, max(0.035, text_min_size * 0.08)), 3)


def _is_short_chinese_badge(target: dict[str, Any]) -> bool:
    if str(target.get("class") or "") not in {"Text", "MarkupText"}:
        return False
    text = str(target.get("text") or "").strip()
    if not text or len(text) > 8:
        return False
    if any(marker in text for marker in ("=", "+", "-", "\\", "/", "^", "_")):
        return False
    return any("\u4e00" <= char <= "\u9fff" for char in text)


def _container_fit_scale(
    target_box: dict[str, Any],
    container_box: dict[str, Any],
    padding: float,
) -> float:
    target_width = max(_box_float(target_box, "width"), 0.01)
    target_height = max(_box_float(target_box, "height"), 0.01)
    usable_width = max(_box_float(container_box, "width") - padding * 2, 0.01)
    usable_height = max(_box_float(container_box, "height") - padding * 2, 0.01)
    scale = min(1.0, usable_width / target_width, usable_height / target_height)
    return round(max(0.52, min(0.95, scale)), 3)


def _shift_into_container(
    target_box: dict[str, Any],
    container_box: dict[str, Any],
    padding: float,
) -> tuple[float, float]:
    dx = 0.0
    dy = 0.0
    left_gap = _box_float(target_box, "left") - _box_float(container_box, "left")
    right_gap = _box_float(container_box, "right") - _box_float(target_box, "right")
    top_gap = _box_float(container_box, "top") - _box_float(target_box, "top")
    bottom_gap = _box_float(target_box, "bottom") - _box_float(container_box, "bottom")
    if left_gap < padding:
        dx += padding - left_gap
    if right_gap < padding:
        dx -= padding - right_gap
    if bottom_gap < padding:
        dy += padding - bottom_gap
    if top_gap < padding:
        dy -= padding - top_gap
    return round(max(-1.0, min(1.0, dx)), 3), round(max(-1.0, min(1.0, dy)), 3)


def _shift_expression(dx: float, dy: float) -> str:
    parts: list[str] = []
    if abs(dx) >= 0.05:
        direction = "RIGHT" if dx > 0 else "LEFT"
        parts.append(f"{direction} * {abs(dx):.3f}")
    if abs(dy) >= 0.05:
        direction = "UP" if dy > 0 else "DOWN"
        parts.append(f"{direction} * {abs(dy):.3f}")
    return " + ".join(parts)


def _box_float(box: dict[str, Any], key: str) -> float:
    try:
        return float(box.get(key) or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _line_at(code: str, lineno: int) -> str:
    lines = code.splitlines()
    if lineno <= 0 or lineno > len(lines):
        return ""
    return lines[lineno - 1]
