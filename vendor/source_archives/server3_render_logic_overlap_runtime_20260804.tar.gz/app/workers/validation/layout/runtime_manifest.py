from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any

def _layout_mvp_round_has_no_patch(item: dict[str, Any]) -> bool:
    if str(item.get("status") or "") != "record_only":
        return False
    try:
        patch_count = int(item.get("patch_count") or 0)
    except (TypeError, ValueError):
        patch_count = 0
    return patch_count <= 0


def _layout_mvp_is_no_patch_record_only(
    metadata: dict[str, Any] | None,
    *,
    reason: str,
) -> bool:
    if not isinstance(metadata, dict):
        return reason in {"layout_mvp_no_safe_patch", "layout_solver_no_patch"}
    try:
        blocking_count = int(metadata.get("before_blocking_issue_count") or 0)
    except (TypeError, ValueError):
        blocking_count = 0
    if blocking_count <= 0:
        return False
    if reason in {"layout_mvp_no_safe_patch", "layout_solver_no_patch"}:
        return True
    for item in metadata.get("rounds") or []:
        if not isinstance(item, dict):
            continue
        if str(item.get("reason") or "") == "layout_solver_no_patch":
            return True
        if _layout_mvp_round_has_no_patch(item):
            return True
    return False


def _layout_mvp_manifest_metadata(
    metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    """Keep layout_mvp manifest fields path-safe for quality case persistence."""
    if not isinstance(metadata, dict):
        return {}
    allowed_top = {
        "engine",
        "adapter_mode",
        "repair_source",
        "repair_method",
        "zero_llm",
        "target_scene",
        "max_rounds",
        "before_blocking_issue_count",
        "record_only_reason",
        "outer_round",
        "outer_max_rounds",
        "after_clean",
        "after_recheck_reason",
        "quantified_closure",
    }
    safe: dict[str, Any] = {
        key: metadata.get(key)
        for key in allowed_top
        if key in metadata
    }
    if isinstance(metadata.get("errors"), list):
        safe["errors"] = metadata.get("errors")
    rounds: list[dict[str, Any]] = []
    for item in metadata.get("rounds") or []:
        if not isinstance(item, dict):
            continue
        round_record: dict[str, Any] = {}
        for key in (
            "round_index",
            "status",
            "reason",
            "blocking_issue_count",
            "patch_count",
            "patch_reasons",
            "changed_lines",
            "before_video_ref",
            "after_video_ref",
        ):
            if key in item:
                round_record[key] = item.get(key)
        probe = item.get("before_probe")
        if isinstance(probe, dict):
            round_record["before_probe_summary"] = {
                "top_overlap_count": len(probe.get("top_overlaps") or []),
                "top_bounds_violation_count": len(
                    probe.get("top_bounds_violations") or []
                ),
            }
        diff = item.get("diff")
        if isinstance(diff, str) and diff:
            round_record["diff_preview"] = diff[:12000]
        render_result = item.get("render_result")
        if isinstance(render_result, dict):
            round_record["render_result"] = {
                key: render_result.get(key)
                for key in ("succeeded", "video_ref", "code_ref")
                if key in render_result
            }
        rounds.append(round_record)
    if rounds:
        safe["rounds"] = rounds
    return safe


