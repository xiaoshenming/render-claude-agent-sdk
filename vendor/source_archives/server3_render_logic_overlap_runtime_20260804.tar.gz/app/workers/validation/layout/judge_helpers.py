"""Layout LLM judge：对 needs_llm_judge=True 的模糊重叠做二次判定。

对应 Admin 后台 `ai.routes.layout_judge` 配置（默认 deepseek-v4-flash）。
判定为真重叠的 issue 会被升级为 layout_overlap_error 并交给修复管线，
不再有"等人工查看"的中间态。
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
from dataclasses import replace
from typing import Any

try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover
    AsyncOpenAI = None

from app.core.config import settings
from app.core.runtime_config.client import (
    is_runtime_settings_override,
    refresh_runtime_config_if_stale,
)
from app.prompts.prompt_compiler import compile_cacheable_segmented_prompt
from app.services.dedicated_llm_client import call_dedicated_chat_completion
from app.services.llm_call_tracer import LLMCallTracer
from app.services.llm_service import get_llm_manager
from app.workers.repair.repair_state import (
    BackhalfRepairBudget,
    record_backhalf_repair_call,
)

from .schemas import LayoutIssue


TEXTUAL_KINDS = {"text", "formula"}
TEXT_SHAPE_ERROR_THRESHOLD = 0.35
TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD = 0.55
EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow"}



def _trace_usage_context(compile_result) -> dict[str, Any]:
    return {
        "prompt_segments": compile_result.prompt_segments,
        "cache_metrics": compile_result.cache_metrics,
        "prompt_firewall": compile_result.firewall_report,
    }
def _runtime_value(name: str, default: str = "") -> str:
    if is_runtime_settings_override(name):
        value = getattr(settings, name, None)
        if value not in (None, ""):
            return str(value)
    env_value = os.getenv(name)
    if env_value is not None:
        return env_value
    value = getattr(settings, name, None)
    if value not in (None, ""):
        return str(value)
    return default
def _parse_backend_pool(raw: str) -> list[dict[str, Any]]:
    text = (raw or "").strip()
    if not text:
        return []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    parsed: list[dict[str, Any]] = []
    for index, item in enumerate(data):
        if not isinstance(item, dict):
            continue
        model_name = str(item.get("model") or "").strip()
        keys = item.get("keys")
        if isinstance(keys, str):
            keys = [keys]
        if not isinstance(keys, list):
            keys = []
        clean_keys = [str(key).strip() for key in keys if str(key or "").strip()]
        if not model_name or not clean_keys:
            continue
        try:
            priority = int(item.get("priority") or index + 1)
        except (TypeError, ValueError):
            priority = index + 1
        base_name = str(item.get("name") or f"dedicated-{model_name}").strip()
        api_base = str(item.get("api_base") or "").strip()
        for key_index, api_key in enumerate(clean_keys):
            backend_name = base_name if len(clean_keys) == 1 else f"{base_name}-{key_index + 1}"
            parsed.append({
                "priority": priority,
                "backend_name": backend_name,
                "api_key": api_key,
                "api_base": api_base,
                "model_name": model_name,
            })
    parsed.sort(key=lambda item: item["priority"])
    return parsed
def _first_pool_model(raw: str) -> str:
    for backend in _parse_backend_pool(raw):
        return backend["model_name"]
    return ""
async def _refresh_runtime_config_before_dedicated_checks() -> None:
    try:
        await asyncio.wait_for(
            refresh_runtime_config_if_stale(min_interval_sec=2.0),
            timeout=0.5,
        )
    except Exception:
        return
def _judge_enabled() -> bool:
    raw = _runtime_value("LAYOUT_JUDGE_ENABLED", "true").strip().lower()
    return raw in {"1", "true", "yes", "on"}
def _judge_model() -> str:
    pooled_model = _first_pool_model(_runtime_value("LAYOUT_JUDGE_BACKENDS_JSON"))
    if pooled_model:
        return pooled_model
    return _runtime_value("LAYOUT_JUDGE_MODEL", "deepseek-v4-flash").strip() or "deepseek-v4-flash"
def _judge_timeout() -> float:
    try:
        return float(_runtime_value("LAYOUT_JUDGE_TIMEOUT_SEC", "45"))
    except (TypeError, ValueError):
        return 45.0
def _judge_max_tokens() -> int:
    raw = _runtime_value(
        "LAYOUT_JUDGE_MAX_TOKENS",
        str(getattr(settings, "LLM_MAX_OUTPUT_TOKENS", 65536) or 65536),
    ).strip()
    try:
        value = int(raw or 0)
    except (TypeError, ValueError):
        value = 0
    return max(1024, value or int(getattr(settings, "LLM_MAX_OUTPUT_TOKENS", 65536) or 65536))
def _dedicated_backend_configs() -> list[dict[str, str]]:
    pooled = _parse_backend_pool(_runtime_value("LAYOUT_JUDGE_BACKENDS_JSON"))
    if pooled:
        return pooled
    api_key = _runtime_value("LAYOUT_JUDGE_API_KEY").strip()
    if not api_key:
        return []
    api_base = _runtime_value("LAYOUT_JUDGE_API_BASE").strip()
    return [{
        "backend_name": "dedicated-layout-judge",
        "api_key": api_key,
        "api_base": api_base or None,
        "model_name": _judge_model(),
    }]
def _dedicated_backend_config() -> dict[str, str] | None:
    configs = _dedicated_backend_configs()
    return configs[0] if configs else None
def _ensure_verdict_payload(raw_output: str) -> None:
    text = (raw_output or "").strip()
    if not text:
        raise ValueError("empty layout judge response")
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.S | re.I)
    if fenced:
        text = fenced.group(1).strip()
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("layout judge response is not JSON") from None
        payload = json.loads(text[start:end + 1])
    if not isinstance(payload, dict) or not isinstance(payload.get("verdicts"), list):
        raise ValueError("layout judge response missing verdicts list")

