"""Layout LLM judge：对 needs_llm_judge=True 的模糊重叠做二次判定。

对应 Admin 后台 `ai.routes.layout_judge` 配置（默认 deepseek-v4-flash）。
判定为真重叠的 issue 会被升级为 layout_overlap_error 并交给修复管线，
不再有"等人工查看"的中间态。
"""
from __future__ import annotations
import asyncio
import json
import os
import re
import time
from dataclasses import replace
from typing import Any
try:
    from openai import AsyncOpenAI
except Exception:  # pragma: no cover
    AsyncOpenAI = None

from app.core.config import settings
from app.core.runtime_config.client import (
    is_runtime_settings_override,
    refresh_runtime_config_if_stale,
)
from app.prompts.prompt_compiler import compile_cacheable_segmented_prompt
from app.services.dedicated_llm_client import call_dedicated_chat_completion
from app.services.llm_call_tracer import LLMCallTracer
from app.services.llm_service import get_llm_manager
from app.workers.repair.repair_state import (
    BackhalfRepairBudget,
    record_backhalf_repair_call,
)

from .schemas import LayoutIssue

TEXTUAL_KINDS = {"text", "formula"}
TEXT_SHAPE_ERROR_THRESHOLD = 0.35
TEXT_SHAPE_COVERAGE_ERROR_THRESHOLD = 0.55
EXTENDED_LINE_CLASSES = {"Line", "DashedLine", "Arrow", "DoubleArrow"}

from .judge_helpers import *
from .judge_issue_helpers import *
async def judge_layout_issues(
    *,
    job_id: str,
    scene_name: str,
    issues: list[LayoutIssue],
    task_data: dict[str, Any] | None = None,
) -> tuple[list[LayoutIssue], dict[str, Any]]:
    """对 needs_llm_judge=True 的 issue 做 LLM 二次判定。

    Returns:
        (new_issues_list, judge_meta)
        - new_issues_list: 与输入等长，verdict=real 的 issue 已被升级为 layout_overlap_error/repairable=True。
        - judge_meta: 含 model/latency/error 等执行信息，便于写入 task_data。
    """
    await _refresh_runtime_config_before_dedicated_checks()
    new_issues = _clear_protected_record_only_judge_flags(list(issues))
    pending_indices = [
        i for i, issue in enumerate(new_issues) if issue.needs_llm_judge
    ]
    if not pending_indices or not _judge_enabled():
        return new_issues, {"status": "skipped", "pending_count": len(pending_indices)}

    started_at = time.monotonic()
    model_name = _judge_model()
    timeout = _judge_timeout()
    pending_payload = [
        _issue_to_judge_payload(idx, new_issues[idx]) for idx in pending_indices
    ]
    prompt = _build_prompt(scene_name=scene_name, items=pending_payload)
    budget_decision = record_backhalf_repair_call(
        task_data,
        scene_name=scene_name,
        call_type="layout_judge",
        signature=prompt,
        budget=BackhalfRepairBudget(),
    )
    if not budget_decision.allowed:
        return new_issues, {
            "status": "budget_skipped",
            "reason": budget_decision.reason,
            "pending_count": len(pending_indices),
            "job_llm_calls": budget_decision.job_llm_calls,
            "scene_call_count": budget_decision.scene_call_count,
        }

    try:
        raw_output, backend_name = await _call_judge(
            prompt=prompt,
            job_id=job_id,
            model_name=model_name,
            timeout=timeout,
            scene_name=scene_name,
            items=pending_payload,
        )
        verdicts = _parse_verdicts(raw_output)
        latency_ms = int((time.monotonic() - started_at) * 1000)
    except Exception as exc:
        return list(issues), {
            "status": "error",
            "model": model_name,
            "error": f"{type(exc).__name__}: {exc}",
            "pending_count": len(pending_indices),
            "latency_ms": int((time.monotonic() - started_at) * 1000),
        }

    promoted_count = 0
    cleared_count = 0
    suppressed_count = 0
    for idx in pending_indices:
        verdict = verdicts.get(idx, {})
        llm_is_real = bool(verdict.get("is_real_overlap"))
        forced_real_metadata = _strong_bbox_occlusion_metadata(new_issues[idx])
        is_real = llm_is_real or bool(forced_real_metadata)
        reason = str(verdict.get("reason") or "")[:300]
        original = new_issues[idx]
        merged_meta = dict(original.metadata or {})
        if forced_real_metadata:
            merged_meta.update(forced_real_metadata)
        merged_meta["judge_model"] = model_name
        if forced_real_metadata and not llm_is_real:
            merged_meta["judge_verdict"] = "bbox_forced_real"
            merged_meta["llm_judge_verdict"] = "false_positive"
        else:
            merged_meta["judge_verdict"] = "real" if is_real else "false_positive"
        if reason:
            merged_meta["judge_reason"] = reason
        if is_real:
            if _should_suppress_auto_repair(original):
                suppressed_count += 1
                merged_meta["auto_repair_suppressed"] = "protected_geometry_label"
                new_issues[idx] = replace(
                    original,
                    severity="medium",
                    repairable=False,
                    deterministic_repairable=False,
                    needs_llm_judge=False,
                    metadata=merged_meta,
                )
                continue
            promoted_count += 1
            new_issues[idx] = replace(
                original,
                code="layout_overlap_error",
                severity="high",
                repairable=True,
                deterministic_repairable=False,  # LLM 判定的真重叠，优先走 slice_fixer
                needs_llm_judge=False,
                metadata=merged_meta,
            )
        else:
            cleared_count += 1
            new_issues[idx] = replace(
                original,
                needs_llm_judge=False,
                metadata=merged_meta,
            )
    return new_issues, {
        "status": "ok",
        "model": model_name,
        "backend": backend_name,
        "pending_count": len(pending_indices),
        "promoted_count": promoted_count,
        "cleared_count": cleared_count,
        "suppressed_count": suppressed_count,
        "latency_ms": latency_ms,
    }
async def _call_judge(
    *,
    prompt: str,
    job_id: str,
    model_name: str,
    timeout: float,
    scene_name: str | None = None,
    items: list[dict[str, Any]] | None = None,
) -> tuple[str, str]:
    if scene_name is not None and items is not None:
        stable_prefix, dynamic_payload = _build_prompt_parts(
            scene_name=scene_name,
            items=items,
        )
    elif prompt:
        parts = prompt.split("待判定列表：", 1)
        if len(parts) == 2:
            stable_prefix = parts[0].strip()
            dynamic_payload = f"待判定列表：{parts[1].strip()}"
        else:
            stable_prefix = "你是 Manim 视频的版面裁判。只输出 JSON 判定结果。"
            dynamic_payload = prompt
    else:
        stable_prefix, dynamic_payload = _build_prompt_parts(
            scene_name="unknown",
            items=[],
        )
    compile_result = compile_cacheable_segmented_prompt(
        prompt_id="layout_judge",
        stable_prefix=stable_prefix,
        dynamic_payload=dynamic_payload,
        selected_skills=["quality.geometry_label_check"],
        expected_skill_role="quality",
        dynamic_payload_type="layout_judge_items",
    )
    trace_usage_context = _trace_usage_context(compile_result)
    dedicated_backends = _dedicated_backend_configs()
    if dedicated_backends:
        last_exc: Exception | None = None
        for dedicated in dedicated_backends:
            try:
                response = await call_dedicated_chat_completion(
                    job_id=job_id,
                    call_type="layout_judge",
                    prompt_version="layout_judge_v1",
                    prompt_content=prompt,
                    backend_name=dedicated["backend_name"],
                    limiter_key="layout_judge",
                    env_prefix="LAYOUT_JUDGE",
                    client_cls=AsyncOpenAI,
                    tracer_cls=LLMCallTracer,
                    api_key=dedicated["api_key"],
                    api_base=dedicated.get("api_base") or None,
                    model_name=dedicated["model_name"],
                    timeout=timeout,
                    request_kwargs={
                        "model": dedicated["model_name"],
                        "messages": compile_result.cacheable_messages,
                        "temperature": 0,
                        "response_format": {"type": "json_object"},
                        "max_tokens": _judge_max_tokens(),
                    },
                    trace_usage_context=trace_usage_context,
                )
                raw_output = response.choices[0].message.content or ""
                _ensure_verdict_payload(raw_output)
                return (raw_output, dedicated["backend_name"])
            except Exception as exc:
                last_exc = exc
                continue
        if last_exc is not None:
            raise last_exc
    response, backend_name = await asyncio.wait_for(
        get_llm_manager().call(
            messages=compile_result.cacheable_messages,
            max_tokens=_judge_max_tokens(),
            retry_budget=1,
            trace_job_id=job_id,
            trace_call_type="layout_judge",
            trace_prompt_version="layout_judge_v1",
            trace_prompt_content=compile_result.prompt_content,
            trace_response_format="json_object",
            trace_usage_context=trace_usage_context,
        ),
        timeout=timeout,
    )
    return (response.choices[0].message.content or ""), backend_name
def _issue_to_judge_payload(idx: int, issue: LayoutIssue) -> dict[str, Any]:
    objects = []
    for obj in (issue.objects or [])[:2]:
        if not isinstance(obj, dict):
            continue
        bbox = obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {}
        objects.append({
            "class": str(obj.get("class") or ""),
            "kind": str(obj.get("kind") or ""),
            "text": str(obj.get("text") or "")[:200],
            "bbox": {
                "left": _round(bbox.get("left")),
                "right": _round(bbox.get("right")),
                "top": _round(bbox.get("top")),
                "bottom": _round(bbox.get("bottom")),
                "width": _round(bbox.get("width")),
                "height": _round(bbox.get("height")),
            },
        })
    metadata = issue.metadata or {}
    payload = {
        "id": idx,
        "category": metadata.get("category", ""),
        "code": issue.code,
        "evidence": issue.evidence,
        "overlap_ratio": _round(issue.overlap_ratio),
        "x_overlap": _round(issue.x_overlap),
        "y_overlap": _round(issue.y_overlap),
        "objects": objects,
    }
    visual_evidence = metadata.get("visual_review_evidence")
    if isinstance(visual_evidence, dict):
        payload["visual_review_evidence"] = visual_evidence
    bbox_metrics = metadata.get("bbox_occlusion_metrics")
    if isinstance(bbox_metrics, dict):
        payload["bbox_occlusion_metrics"] = bbox_metrics
    if metadata.get("near_collision"):
        payload["near_collision"] = True
        payload["gap"] = _round(metadata.get("gap"))
    return payload
def _round(value: Any) -> float:
    try:
        return round(float(value), 4)
    except (TypeError, ValueError):
        return 0.0
