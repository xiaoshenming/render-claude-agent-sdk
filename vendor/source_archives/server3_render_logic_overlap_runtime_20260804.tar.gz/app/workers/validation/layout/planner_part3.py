from __future__ import annotations

import copy
import json
import re
from typing import Any
from . import planner_part4 as _part4
globals().update({k: v for k, v in vars(_part4).items() if not k.startswith("__")})

from .schemas import LayoutIssue


LAYOUT_REPAIR_PLAN_SCHEMA_VERSION = "layout_repair_plan.v1"
LAYOUT_PLAN_TARGET_CODES = {
    "layout_overlap_error",
    "layout_frame_overflow",
    "layout_container_overflow",
    "layout_container_border_overlap",
}

_OVERLAP_EVIDENCE_RE = re.compile(
    r"(?P<a>.+?)\s+overlaps\s+(?P<b>.+?);\s*"
    r"overlap_ratio=(?P<overlap_ratio>-?\d+(?:\.\d+)?),\s*"
    r"x_overlap=(?P<x_overlap>-?\d+(?:\.\d+)?),\s*"
    r"y_overlap=(?P<y_overlap>-?\d+(?:\.\d+)?)"
)
_FRAME_OVERFLOW_EVIDENCE_RE = re.compile(
    r"(?P<object>.+?)\s+exceeds\s+frame\s+bounds;\s*"
    r"overflow_x=(?P<overflow_x>-?\d+(?:\.\d+)?),\s*"
    r"overflow_y=(?P<overflow_y>-?\d+(?:\.\d+)?)"
    r"(?:,\s*frame=\[(?P<frame>[^\]]+)\])?"
)



def _choose_action(
    code: str,
    objects: list[dict[str, Any]],
    metrics: dict[str, float],
) -> tuple[str, list[str]]:
    kinds = {str(obj.get("kind") or "") for obj in objects}
    roles = {str(obj.get("role") or "") for obj in objects}
    classes = {str(obj.get("class") or "") for obj in objects}
    overlap_ratio = float(metrics.get("overlap_ratio") or 0.0)
    has_textual = bool(kinds.intersection({"text", "formula"}))
    has_diagram_anchor = bool(
        kinds.intersection({"shape", "container", "group"})
        or classes.intersection(
            {
                "Line",
                "Polygon",
                "Square",
                "Circle",
                "Arrow",
                "Axes",
                "NumberPlane",
            }
        )
    )

    if code == "layout_frame_overflow":
        if roles.intersection({"main_diagram", "group"}) or kinds.intersection(
            {"shape", "group"}
        ):
            return "scale_group_to_fit", ["shift_to_safe_zone"]
        return "shift_to_safe_zone", ["wrap_or_shrink_text", "scale_group_to_fit"]
    if code == "layout_container_border_overlap":
        return "container_formula_padding", ["wrap_or_shrink_text", "shift_to_safe_zone"]
    if code == "layout_container_overflow":
        return "wrap_or_shrink_text", ["shift_to_safe_zone", "scale_group_to_fit"]
    if has_textual and has_diagram_anchor and overlap_ratio >= 0.45:
        return "move_label_or_formula_to_clear_zone", [
            "separate_formula_from_diagram",
            "move_label_away",
            "wrap_or_shrink_text",
            "shift_to_safe_zone",
        ]
    if "formula" in kinds and (
        kinds.intersection({"shape", "container", "group"})
        or classes.intersection({"Line", "Polygon", "Circle", "Axes", "NumberPlane"})
        or "text" in kinds
    ):
        return "separate_formula_from_diagram", [
            "move_label_away",
            "wrap_or_shrink_text",
            "shift_to_safe_zone",
        ]
    if "label" in roles:
        return "move_label_away", ["shift_to_safe_zone", "wrap_or_shrink_text"]
    if kinds.issubset({"text", "formula"}) and kinds:
        return "wrap_or_shrink_text", ["move_label_away", "shift_to_safe_zone"]
    return "shift_to_safe_zone", ["scale_group_to_fit", "move_label_away"]
def _action_contract(
    action: str,
    objects: list[dict[str, Any]],
) -> dict[str, Any]:
    if action == "move_label_or_formula_to_clear_zone":
        return {
            "preserve_anchor": "main_diagram",
            "target_zone": _clear_zone_for_objects(objects),
            "forbidden_actions": ["reduce_font_first", "move_both_objects_blindly"],
        }
    if action == "container_formula_padding":
        return {
            "preserve_anchor": "container_and_content_center",
            "target_zone": "container_inner_padding",
            "forbidden_actions": ["shift_container_only", "reduce_font_first"],
        }
    return {}
def _executable_action_contract(
    *,
    action: str,
    code: str,
    scene: str,
    objects: list[dict[str, Any]],
    metrics: dict[str, float],
) -> dict[str, Any]:
    executable = _executable_action_name(action)
    if not executable:
        return {}
    target = _object_action_target(objects, 0)
    avoid = _object_action_target(objects, 1)
    expected_gap = _min_clearance(metrics)
    contract = {
        "action": executable,
        "source_action": action,
        "target": target,
        "avoid": avoid,
        "axis": _separation_axis(metrics),
        "direction": _direction_hint(objects, metrics),
        "distance": expected_gap,
        "expected_gap": expected_gap,
        "verification": _verification_contract(
            code=code,
            scene=scene,
            action=executable,
            expected_gap=expected_gap,
        ),
    }
    if executable == "move_to_safe_zone":
        contract["target_zone"] = _clear_zone_for_objects(objects)
    if executable in {"scale_group_to_frame", "shrink_or_wrap_text"}:
        contract["scale_hint"] = _scale_hint(action, metrics)
    return {
        key: value
        for key, value in contract.items()
        if value not in (None, "", [], {})
    }
def _executable_action_name(action: str) -> str:
    mapping = {
        "move_label_or_formula_to_clear_zone": "move_to_safe_zone",
        "separate_formula_from_diagram": "move_label_along_normal",
        "move_label_away": "move_label_along_normal",
        "shift_to_safe_zone": "move_to_safe_zone",
        "wrap_or_shrink_text": "shrink_or_wrap_text",
        "scale_group_to_fit": "scale_group_to_frame",
        "container_formula_padding": "shrink_or_wrap_text",
    }
    return mapping.get(action, action if action else "")
def _object_action_target(objects: list[dict[str, Any]], index: int) -> str:
    if index >= len(objects):
        return ""
    item = objects[index]
    return str(item.get("label") or item.get("text") or item.get("class") or "")
def _verification_contract(
    *,
    code: str,
    scene: str,
    action: str,
    expected_gap: float,
) -> dict[str, Any]:
    assertion = "no_overlap"
    if code == "layout_frame_overflow" or action == "scale_group_to_frame":
        assertion = "inside_frame"
    elif code in {"layout_container_overflow", "layout_container_border_overlap"}:
        assertion = "no_container_overflow"
    return {
        "probe": "bbox",
        "assertion": assertion,
        "min_gap": expected_gap,
        "scene": scene,
    }
