from __future__ import annotations

from typing import Any

from .layout_evidence_text import evidence as _evidence, suggest_fix as _suggest_fix
from .layout_overlap_noise import (
    looks_like_axes_annotation_overlap as _looks_like_axes_annotation_overlap,
    looks_like_formula_cancellation_line_overlap as _looks_like_formula_cancellation_line_overlap,
    looks_like_vertex_label_inside_shape as _looks_like_vertex_label_inside_shape,
    near_collision_evidence as _near_collision_evidence,
)
from .policy_geometry import looks_like_extended_graph_line as _looks_like_extended_graph_line
from .layout_label_geometry import contains_protected_geometry_label as _contains_protected_geometry_label
from .layout_visual_occlusion import strong_text_shape_occlusion_metadata as _strong_text_shape_occlusion_metadata
from .schemas import LayoutIssue


def issue_from_text_shape_overlap(
    *,
    scene_name: str,
    overlap: dict[str, Any],
    a: dict[str, Any],
    b: dict[str, Any],
    ratio: float,
    x_overlap: float,
    y_overlap: float,
    category: str,
    metadata: dict[str, Any],
    textual_kinds: set[str],
    textual_risk_threshold: float,
) -> LayoutIssue | None:
    """Classify residual text/shape overlaps after textual-pair policy handling."""
    a_kind = str(a.get("kind") or "")
    b_kind = str(b.get("kind") or "")
    if ratio < textual_risk_threshold or not (
        a_kind in textual_kinds or b_kind in textual_kinds
    ):
        return None
    if _looks_like_formula_cancellation_line_overlap(a, b, ratio=ratio):
        return None
    if _looks_like_extended_graph_line(a) or _looks_like_extended_graph_line(b):
        return None
    if category == "label_shape_overlap_risk" and _looks_like_vertex_label_inside_shape(a, b):
        return None
    if _looks_like_axes_annotation_overlap(a, b):
        return None
    if category == "label_shape_overlap_risk" and _contains_protected_geometry_label(a, b):
        return LayoutIssue(
            code="layout_overlap_risk", severity="low", confidence=0.5,
            scene_name=scene_name,
            evidence=(
                _near_collision_evidence(a, b, metadata)
                if metadata.get("near_collision") else _evidence(a, b, ratio, x_overlap, y_overlap)
            ), overlap_ratio=ratio, x_overlap=x_overlap, y_overlap=y_overlap,
            objects=[a, b], repairable=False, deterministic_repairable=False,
            needs_llm_judge=False,
            suggested_fix="几何边/尺寸标签贴近对应图形是正常标注；只记录，不自动移动锚定标签。",
            metadata={**metadata, "protected_geometry_label": True},
        )
    occlusion_metadata = _strong_text_shape_occlusion_metadata(
        a, b, ratio=ratio, x_overlap=x_overlap, y_overlap=y_overlap, metadata=metadata
    )
    if occlusion_metadata:
        return LayoutIssue(
            code="layout_overlap_error", severity="high",
            confidence=min(0.98, 0.68 + ratio / 2.0), scene_name=scene_name,
            evidence=_evidence(a, b, ratio, x_overlap, y_overlap), overlap_ratio=ratio,
            x_overlap=x_overlap, y_overlap=y_overlap, objects=[a, b], repairable=True,
            deterministic_repairable=False, needs_llm_judge=False,
            suggested_fix=_suggest_fix(a, b), metadata={**metadata, **occlusion_metadata},
        )
    return LayoutIssue(
        code="layout_overlap_risk", severity="low", confidence=0.5,
        scene_name=scene_name,
        evidence=(
            _near_collision_evidence(a, b, metadata)
            if metadata.get("near_collision") else _evidence(a, b, ratio, x_overlap, y_overlap)
        ), overlap_ratio=ratio, x_overlap=x_overlap, y_overlap=y_overlap,
        objects=[a, b], repairable=False, deterministic_repairable=False,
        needs_llm_judge=True, suggested_fix="需要判断这是正常标注还是遮挡；不要直接改数学结构。",
        metadata=metadata,
    )
