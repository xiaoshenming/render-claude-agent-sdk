from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any

def _merge_shared_layout_repair_changes(
    *,
    ctx,
    source_code: str,
    repair_results: list[tuple[int, str, str | None, str | None, str | None]],
) -> str:
    from app.workers.repair import error_fixer

    source_base = error_fixer.extract_scene_code(source_code, "BaseConfigScene") or ""
    if not source_base:
        return source_code

    candidates: list[tuple[str, str]] = []
    for _index, scene_name, repaired_path, _scene_code, repaired_code in repair_results:
        if not repaired_path or not repaired_code:
            continue
        repaired_base = (
            error_fixer.extract_scene_code(repaired_code, "BaseConfigScene") or ""
        )
        if repaired_base and repaired_base != source_base:
            candidates.append((scene_name, repaired_base))
    if not candidates:
        return source_code

    unique_versions: list[str] = []
    for _scene_name, base_code in candidates:
        if base_code not in unique_versions:
            unique_versions.append(base_code)
    if len(unique_versions) > 1:
        conflict = {
            "reason": "layout_shared_helper_conflict",
            "helper": "BaseConfigScene",
            "scenes": [scene_name for scene_name, _base_code in candidates],
            "version_count": len(unique_versions),
        }
        task_data = getattr(ctx, "task_data", None)
        if isinstance(task_data, dict):
            task_data.setdefault("_layout_shared_repair_conflicts", []).append(conflict)
        logger.warning(
            "[LAYOUT-REPAIR] shared BaseConfigScene repair conflict; "
            "skip shared helper merge scenes=%s",
            conflict["scenes"],
        )
        return source_code

    try:
        merged = error_fixer.replace_scene_code(
            source_code,
            "BaseConfigScene",
            unique_versions[0],
        )
        ast.parse(merged)
        task_data = getattr(ctx, "task_data", None)
        candidate_scenes = [scene_name for scene_name, _base_code in candidates]
        touched_scenes = _shared_layout_helper_touched_scenes(
            source_code,
            helper_name="BaseConfigScene",
        ) or candidate_scenes
        if isinstance(task_data, dict):
            task_data.setdefault("_layout_shared_repair_merges", []).append(
                {
                    "helper": "BaseConfigScene",
                    "scenes": candidate_scenes,
                    "scope": "shared",
                    "cross_scene_scope": len(touched_scenes) > 1,
                    "touched_scenes": touched_scenes,
                }
            )
            _mark_shared_layout_repair_event_scope(
                task_data,
                helper_name="BaseConfigScene",
                scenes=candidate_scenes,
                touched_scenes=touched_scenes,
            )
        return merged
    except Exception as exc:
        task_data = getattr(ctx, "task_data", None)
        if isinstance(task_data, dict):
            task_data.setdefault("_layout_shared_repair_conflicts", []).append(
                {
                    "reason": "layout_shared_helper_merge_error",
                    "helper": "BaseConfigScene",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
        logger.warning("[LAYOUT-REPAIR] shared BaseConfigScene merge failed: %s", exc)
        return source_code
