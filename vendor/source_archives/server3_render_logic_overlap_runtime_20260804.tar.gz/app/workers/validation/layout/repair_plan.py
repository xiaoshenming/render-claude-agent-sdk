from __future__ import annotations

import re
from typing import Any

from app.workers.validation.layout import repair_progress


_OVERLAP_RE = re.compile(
    r"(?P<a>.+?)\s+overlaps\s+(?P<b>.+?);"
    r".*?overlap_ratio=(?P<ratio>[-+]?\d*\.?\d+)"
    r".*?x_overlap=(?P<x>[-+]?\d*\.?\d+)"
    r".*?y_overlap=(?P<y>[-+]?\d*\.?\d+)",
    re.I,
)
_FRAME_RE = re.compile(
    r"(?P<object>.+?)\s+exceeds\s+frame\s+bounds;"
    r".*?overflow_x=(?P<x>[-+]?\d*\.?\d+)"
    r".*?overflow_y=(?P<y>[-+]?\d*\.?\d+)",
    re.I,
)


def build_layout_repair_plan(
    *,
    scene_name: str,
    issues: list[dict[str, Any]] | None,
    no_progress: dict[str, Any] | None = None,
) -> dict[str, Any]:
    constraints: list[dict[str, Any]] = []
    actions: list[dict[str, Any]] = []
    for issue in issues or []:
        if not isinstance(issue, dict):
            continue
        parsed = _constraint_from_issue(issue)
        if parsed:
            constraints.append(parsed)
        actions.extend(_actions_from_issue(issue, parsed))
    actions = _dedupe_actions(actions)
    if not actions:
        actions = [
            {
                "action": "recompose_scene_layout",
                "target": scene_name,
                "reason": "layout_issue_without_precise_bbox",
            }
        ]

    repair_strategy = "deterministic_plan_then_llm_patch"
    escalation: dict[str, Any] = {}
    if no_progress and no_progress.get("no_progress"):
        repair_strategy = "scene_regenerate_required"
        escalation = {
            "reason": "same_layout_signature_no_progress",
            "signature": no_progress.get("signature"),
            "hit_count": no_progress.get("hit_count"),
            "threshold": no_progress.get("threshold"),
        }
        actions.insert(
            0,
            {
                "action": "recompose_scene_layout",
                "target": scene_name,
                "reason": "same_bbox_signature_repeated",
            },
        )

    return {
        "schema_version": "layout_repair_plan.v1",
        "scene_name": scene_name,
        "repair_strategy": repair_strategy,
        "constraints": constraints[:10],
        "actions": actions[:12],
        "acceptance_criteria": [
            "bbox probe 不再返回 blocking layout_overlap_error/layout_frame_overflow",
            "文字、公式、标签与主图形之间保留可见安全间距",
            "优先移动/分阶段展示，不通过盲目缩小字体掩盖问题",
        ],
        "escalation": escalation,
    }


def annotate_layout_issues_with_plan(
    issues: list[dict[str, Any]] | None,
    *,
    scene_name: str,
    no_progress: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    plan = build_layout_repair_plan(
        scene_name=scene_name,
        issues=issues,
        no_progress=no_progress,
    )
    annotated: list[dict[str, Any]] = []
    for issue in issues or []:
        if not isinstance(issue, dict):
            annotated.append(issue)
            continue
        item = dict(issue)
        metadata = item.get("metadata")
        metadata = dict(metadata) if isinstance(metadata, dict) else {}
        metadata["layout_repair_plan"] = plan
        if plan["repair_strategy"] == "scene_regenerate_required":
            metadata["preferred_repair_strategy"] = "scene_regenerate_required"
            metadata["repair_strategy"] = "scene_regenerate_required"
            metadata["rebuild_scope"] = "whole_scene_relayout"
        item["metadata"] = metadata
        item["layout_repair_plan"] = plan
        annotated.append(item)
    return annotated
def layout_issue_signature(issues: list[dict[str, Any]] | None) -> str:
    return repair_progress.issue_signature(issues, _constraint_from_issue)
def record_layout_no_progress(
    task_data: dict[str, Any] | None,
    *, scene_name: str, issues: list[dict[str, Any]] | None, threshold: int = 2,
) -> dict[str, Any]:
    return repair_progress.record_no_progress(
        task_data, scene_name=scene_name, signature=layout_issue_signature(issues),
        threshold=threshold,
    )
def _constraint_from_issue(issue: dict[str, Any]) -> dict[str, Any] | None:
    evidence = str(issue.get("evidence") or "")
    overlap = _OVERLAP_RE.search(evidence)
    if overlap:
        return {
            "type": "overlap",
            "a": overlap.group("a").strip(),
            "b": overlap.group("b").strip(),
            "overlap_ratio": _num(overlap.group("ratio")),
            "x_overlap": _num(overlap.group("x")),
            "y_overlap": _num(overlap.group("y")),
        }
    frame = _FRAME_RE.search(evidence)
    if frame:
        return {
            "type": "frame_overflow",
            "object": frame.group("object").strip(),
            "overflow_x": _num(frame.group("x")),
            "overflow_y": _num(frame.group("y")),
        }
    if issue.get("overlap_ratio") not in (None, ""):
        return {
            "type": "overlap",
            "overlap_ratio": _num(issue.get("overlap_ratio")),
            "x_overlap": _num(issue.get("x_overlap")),
            "y_overlap": _num(issue.get("y_overlap")),
        }
    return None


def _actions_from_issue(
    issue: dict[str, Any],
    constraint: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    code = str(issue.get("code") or "")
    evidence = str(issue.get("evidence") or "")
    hints = issue.get("repair_action_hints")
    if isinstance(hints, list) and hints:
        return [
            _executable_action_contract(hint, constraint or {}, issue)
            for hint in hints
            if isinstance(hint, dict)
        ]
    if code in {"layout_frame_overflow", "layout_container_overflow"} or "exceeds frame bounds" in evidence:
        return [
            _executable_action_contract(
                {
                    "action": "scale_group_to_fit",
                    "target": (constraint or {}).get("object") or "overflowing_group",
                },
                constraint or {},
                issue,
            ),
            _executable_action_contract(
                {
                    "action": "shift_to_safe_zone",
                    "target": (constraint or {}).get("object") or "overflowing_group",
                },
                constraint or {},
                issue,
            ),
        ]
    if code.startswith("layout_") or " overlaps " in evidence:
        axis = "x"
        if constraint and abs(float(constraint.get("y_overlap") or 0.0)) > abs(float(constraint.get("x_overlap") or 0.0)):
            axis = "y"
        return [
            _executable_action_contract(
                {
                    "action": "separate_formula_from_diagram",
                    "target": (constraint or {}).get("a") or "text_or_formula",
                    "avoid": (constraint or {}).get("b") or "diagram_object",
                    "axis": axis,
                },
                constraint or {},
                issue,
            ),
            _executable_action_contract(
                {
                    "action": "fade_or_move_old_context_before_new_focus",
                    "target": "stale_explanatory_text",
                    "reason": "avoid_dense_same_zone_overlap",
                },
                constraint or {},
                issue,
            ),
        ]
    return []


def _executable_action_contract(
    action: dict[str, Any],
    constraint: dict[str, Any],
    issue: dict[str, Any],
) -> dict[str, Any]:
    source_action = str(action.get("action") or "")
    executable = _executable_action_name(source_action)
    expected_gap = _expected_gap(constraint)
    code = str(issue.get("code") or "")
    contract = {
        **action,
        "action": executable,
        "source_action": source_action,
        "expected_gap": expected_gap,
        "verification": _verification_contract(
            code=code,
            action=executable,
            expected_gap=expected_gap,
        ),
    }
    if "geometry" not in contract and constraint:
        contract["geometry"] = constraint
    return {
        key: value
        for key, value in contract.items()
        if value not in (None, "", [], {})
    }


def _executable_action_name(action: str) -> str:
    return {
        "separate_formula_from_diagram": "move_label_along_normal",
        "move_label_away": "move_label_along_normal",
        "shift_to_safe_zone": "move_to_safe_zone",
        "scale_group_to_fit": "scale_group_to_frame",
        "wrap_or_shrink_text": "shrink_or_wrap_text",
        "fade_or_move_old_context_before_new_focus": "move_to_safe_zone",
    }.get(action, action)


def _expected_gap(constraint: dict[str, Any]) -> float:
    values = [
        abs(float(constraint.get(key) or 0.0))
        for key in ("x_overlap", "y_overlap", "overflow_x", "overflow_y")
    ]
    return _num(max(values + [0.12]) + 0.08)


def _verification_contract(
    *,
    code: str,
    action: str,
    expected_gap: float,
) -> dict[str, Any]:
    assertion = "no_overlap"
    if code == "layout_frame_overflow" or action == "scale_group_to_frame":
        assertion = "inside_frame"
    elif code == "layout_container_overflow":
        assertion = "no_container_overflow"
    return {
        "probe": "bbox",
        "assertion": assertion,
        "min_gap": expected_gap,
    }


def _dedupe_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for action in actions:
        key = repr(sorted(action.items()))
        if key in seen:
            continue
        seen.add(key)
        result.append(action)
    return result


def _compact(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _num(value: Any) -> float:
    try:
        return round(float(value), 4)
    except (TypeError, ValueError):
        return 0.0
