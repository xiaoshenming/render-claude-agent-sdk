from app.workers.validation.layout import runtime as _runtime
os = _runtime.os
settings = _runtime.settings
LayoutDecision = _runtime.LayoutDecision
Any = _runtime.Any

def _runtime_value(name: str, default: str = "") -> str:
    if name in os.environ:
        return os.environ[name]
    value = getattr(settings, name, None)
    if value not in (None, ""):
        return str(value)
    return os.getenv(name, default)


def _task_flag_true(task_data: dict[str, Any] | None, *names: str) -> bool:
    if not isinstance(task_data, dict):
        return False
    true_values = {"1", "true", "yes", "y", "on", "enabled"}
    for name in names:
        if name not in task_data:
            continue
        raw = task_data.get(name)
        if isinstance(raw, bool):
            return raw
        if isinstance(raw, (int, float)):
            return bool(raw)
        if isinstance(raw, str):
            return raw.strip().lower() in true_values
        return bool(raw)
    return False


def _legacy_slice_fixer_repair_disabled(task_data: dict[str, Any] | None) -> bool:
    if _layout_mvp_0llm_route_enabled(task_data):
        return True
    if _task_flag_true(
        task_data,
        "_agent_disable_legacy_slice_fixer_repair",
        "_disable_legacy_slice_fixer_repair",
    ):
        return True
    if not isinstance(task_data, dict):
        return False
    strategy = str(
        task_data.get("_agent_fast_pre_render_repair_strategy")
        or task_data.get("_fast_pre_render_repair_strategy")
        or ""
    ).strip().lower()
    strict_fast_pre = (
        _task_flag_true(
            task_data,
            "_agent_fast_pre_render_repair_enabled",
            "_agent_pre_render_fast_repair_enabled",
            "_fast_pre_render_repair_enabled",
        )
        and strategy in {"strict", "strict_block_patch", "block_patch_strict"}
    )
    legacy_review_probe_only = (
        _task_flag_true(task_data, "_agent_force_legacy_visual_review")
        and _task_flag_true(task_data, "_agent_disable_new_quality_repair")
        and _task_flag_true(
            task_data,
            "_agent_disable_legacy_pre_render_scan",
            "_agent_disable_pre_render_scan",
        )
    )
    return strict_fast_pre and legacy_review_probe_only


def _layout_mvp_0llm_route_enabled(task_data: dict[str, Any] | None) -> bool:
    if not isinstance(task_data, dict):
        return False
    engine = str(
        task_data.get("_layout_repair_engine")
        or task_data.get("layout_repair_engine")
        or task_data.get("_agent_layout_repair_engine")
        or ""
    ).strip().lower()
    return engine == "layout_mvp_0llm" or _task_flag_true(
        task_data,
        "_agent_layout_mvp_0llm_enabled",
        "_layout_mvp_0llm_enabled",
    )


def _layout_mvp_repair_rounds(task_data: dict[str, Any] | None) -> int:
    if not isinstance(task_data, dict):
        return 3
    for key in (
        "_layout_mvp_max_rounds",
        "_agent_layout_mvp_max_rounds",
        "_agent_fast_pre_render_repair_max_rounds",
        "_fast_pre_render_repair_max_rounds",
    ):
        raw = task_data.get(key)
        if raw in (None, ""):
            continue
        try:
            return max(1, min(int(raw), 3))
        except (TypeError, ValueError):
            continue
    return 3


def _layout_mvp_probe_from_decision(decision: LayoutDecision) -> dict[str, Any]:
    top_overlaps: list[dict[str, Any]] = []
    top_bounds_violations: list[dict[str, Any]] = []
    for issue in decision.issues:
        if _is_protected_record_only_layout_issue(issue):
            continue
        objects = [
            _layout_mvp_probe_object(obj)
            for obj in (issue.objects or [])[:2]
            if isinstance(obj, dict)
        ]
        if issue.code == "layout_overlap_error" and len(objects) >= 2:
            top_overlaps.append(
                {
                    "category": _layout_mvp_overlap_category(objects),
                    "a": objects[0],
                    "b": objects[1],
                    "ratio_of_smaller": float(issue.overlap_ratio or 0.0),
                    "overlap_ratio": float(issue.overlap_ratio or 0.0),
                    "x_overlap": float(issue.x_overlap or 0.0),
                    "y_overlap": float(issue.y_overlap or 0.0),
                    "evidence": issue.evidence,
                    "scene_name": issue.scene_name,
                }
            )
            continue
        if issue.code in {"layout_container_overflow", "layout_container_border_overlap"} and len(objects) >= 2:
            top_overlaps.append(
                {
                    "category": (
                        "text_container_border_overlap"
                        if issue.code == "layout_container_border_overlap"
                        else "text_container_overflow"
                    ),
                    "a": objects[0],
                    "b": objects[1],
                    "ratio_of_smaller": float(issue.overlap_ratio or 0.0),
                    "overlap_ratio": float(issue.overlap_ratio or 0.0),
                    "x_overlap": float(issue.x_overlap or 0.0),
                    "y_overlap": float(issue.y_overlap or 0.0),
                    "evidence": issue.evidence,
                    "scene_name": issue.scene_name,
                }
            )
            continue
        if issue.code in {"layout_frame_overflow", "layout_container_overflow"}:
            obj = objects[0] if objects else {}
            top_bounds_violations.append(
                {
                    "category": "frame_bounds_overflow",
                    "object": obj,
                    "sides": list((issue.metadata or {}).get("sides") or []),
                    "overflow_x": float(
                        (issue.metadata or {}).get("overflow_x") or issue.x_overlap or 0.0
                    ),
                    "overflow_y": float(
                        (issue.metadata or {}).get("overflow_y") or issue.y_overlap or 0.0
                    ),
                    "evidence": issue.evidence,
                    "scene_name": issue.scene_name,
                }
            )
    return {
        "scene_name": decision.scene_name,
        "artifact_path": decision.artifact_path,
        "top_overlaps": top_overlaps,
        "top_bounds_violations": top_bounds_violations,
    }


