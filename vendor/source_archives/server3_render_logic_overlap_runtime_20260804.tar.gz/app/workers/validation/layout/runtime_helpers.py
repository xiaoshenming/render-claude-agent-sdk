from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _backhalf_repair_budget() -> BackhalfRepairBudget:
    return BackhalfRepairBudget(
        enabled=_env_bool("BACKHALF_REPAIR_BUDGET_ENABLED", False),
        per_job_llm_calls=_repair_loop_limit("BACKHALF_REPAIR_MAX_LLM_CALLS", 8),
        per_scene_slice_fix_patch=_repair_loop_limit(
            "BACKHALF_REPAIR_MAX_SLICE_FIX_PATCH_PER_SCENE",
            2,
        ),
        per_scene_slice_fix=_repair_loop_limit(
            "BACKHALF_REPAIR_MAX_SLICE_FIX_PER_SCENE",
            1,
        ),
        per_scene_quality_multimodal_review=_repair_loop_limit(
            "BACKHALF_REPAIR_MAX_MULTIMODAL_PER_SCENE",
            1,
        ),
        per_scene_same_signature=_repair_loop_limit(
            "BACKHALF_REPAIR_MAX_SAME_SIGNATURE_PER_SCENE",
            1,
        ),
    )

def _record_layout_seconds(
    task_data: dict | None,
    *,
    deterministic_sec: float,
    llm_sec: float,
) -> None:
    if not isinstance(task_data, dict):
        return
    task_data["_deterministic_layout_sec"] = round(
        float(task_data.get("_deterministic_layout_sec", 0.0) or 0.0)
        + max(0.0, deterministic_sec),
        3,
    )
    task_data["_llm_layout_sec"] = round(
        float(task_data.get("_llm_layout_sec", 0.0) or 0.0) + max(0.0, llm_sec),
        3,
    )
    task_data["_layout_sec"] = round(
        float(task_data.get("_layout_sec", 0.0) or 0.0)
        + max(0.0, deterministic_sec)
        + max(0.0, llm_sec),
        3,
    )

def _layout_repair_action_hints_for_quality_issues(
    quality_issues: list[dict],
) -> list[dict[str, Any]]:
    seen: set[str] = set()
    hints: list[dict[str, Any]] = []
    for issue in quality_issues[:10]:
        if not isinstance(issue, dict):
            continue
        for hint in _layout_issue_repair_action_hints(issue):
            key = json.dumps(hint, ensure_ascii=False, sort_keys=True)
            if key in seen:
                continue
            seen.add(key)
            hints.append(hint)
            if len(hints) >= 12:
                return hints
    return hints

def _layout_issue_repair_action_hints(
    issue: LayoutIssue | dict[str, Any],
) -> list[dict[str, Any]]:
    code = _layout_issue_get(issue, "code")
    evidence = str(_layout_issue_get(issue, "evidence") or "")
    if code in {"layout_frame_overflow", "layout_visual_edge_overflow"} or (
        "exceeds frame bounds" in evidence
    ):
        return _frame_overflow_action_hints(issue)
    if (
        code
        in {
            "layout_overlap_error",
            "layout_container_overflow",
            "layout_container_border_overlap",
            "layout_overlap_risk",
        }
        or " overlaps " in evidence
    ):
        return _overlap_action_hints(issue)
    return []

def _parse_frame_overflow_evidence(evidence: str) -> dict[str, Any]:
    match = _FRAME_OVERFLOW_EVIDENCE_RE.search(evidence or "")
    if not match:
        return {}
    frame = None
    if match.group("frame"):
        frame_values = [
            _round_layout_float(item)
            for item in str(match.group("frame")).split(",")
        ]
        if len(frame_values) == 4:
            frame = frame_values
    return {
        "object": match.group("object").strip(),
        "overflow_x": _round_layout_float(match.group("overflow_x")),
        "overflow_y": _round_layout_float(match.group("overflow_y")),
        "frame": frame,
    }

def _shared_layout_helper_touched_scenes(
    source_code: str,
    *,
    helper_name: str,
) -> list[str]:
    try:
        tree = ast.parse(source_code)
    except SyntaxError:
        return []

    touched: list[str] = []
    for node in tree.body:
        if not isinstance(node, ast.ClassDef) or node.name == helper_name:
            continue
        base_names = {_ast_base_name(base) for base in node.bases}
        if helper_name in base_names:
            touched.append(node.name)
    return touched

def _check_layout_helper_contract(code: str) -> dict[str, Any] | None:
    try:
        result = check_helper_contract(code)
    except SyntaxError:
        return None
    except Exception as exc:
        return {
            "ok": False,
            "missing_helpers": [],
            "defined_helpers": [],
            "error": f"{type(exc).__name__}: {exc}",
        }
    return {
        "ok": result.ok,
        "missing_helpers": list(result.missing_helpers),
        "defined_helpers": list(result.defined_helpers),
    }

def _mark_layout_issue_signatures(
    *,
    ctx,
    scene_name: str,
    decision: LayoutDecision,
    status: str,
) -> None:
    task_data = getattr(ctx, "task_data", None)
    if not isinstance(task_data, dict):
        return
    history = task_data.setdefault("_layout_issue_signatures", {})
    if not isinstance(history, dict):
        history = {}
        task_data["_layout_issue_signatures"] = history
    for issue in decision.issues:
        if not _should_cross_scene_dedup(issue):
            continue
        sig = _layout_issue_signature(issue)
        history[sig] = {
            "scene_name": scene_name,
            "code": issue.code,
            "status": status,
        }
