from app.workers.validation.layout.runtime_repair_merge import _merge_shared_layout_repair_changes
from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any


def _record_layout_repair_event(
    task_data: dict | None,
    *,
    scene_name: str,
    status: str,
    method: str,
    quality_issues: list[dict],
    actions: list[dict] | None = None,
    output_path: str | None = None,
    error: str | None = None,
    quantified_closure: dict[str, Any] | None = None,
    render_fix_baseline: int | None = None,
    helper_contract: dict[str, Any] | None = None,
    layout_repair_plan: dict[str, Any] | None = None,
) -> None:
    if task_data is None:
        return
    quality_issues = _layout_quality_issue_payloads_with_repair_hints(
        quality_issues,
        layout_repair_plan=layout_repair_plan,
    )
    repair_action_hints = _layout_repair_action_hints_for_quality_issues(
        quality_issues
    )
    collector = task_data.get("_error_collector")
    events = task_data.setdefault("_layout_repair_events", [])
    event = {
        "type": "layout_repair",
        "status": status,
        "scene_name": scene_name,
        "method": method,
        "issue_count": len(quality_issues),
        "issues": quality_issues[:10],
        "actions": actions or [],
        "output_path": output_path,
        "error": error,
    }
    if method == "layout_mvp_0llm_small_patch":
        event["source"] = "deterministic"
    elif method.startswith("layout_mvp_0llm") and (
        "record_only" in method or status in {"record_only", "repair_skipped"}
    ):
        event["source"] = "record_only"
    if layout_repair_plan and layout_repair_plan.get("constraints"):
        event["layout_repair_plan"] = layout_repair_plan
        task_data["_layout_repair_plan"] = layout_repair_plan
        if layout_repair_plan.get("escalation"):
            event["escalation"] = layout_repair_plan.get("escalation")
    if helper_contract:
        event["helper_contract"] = helper_contract
    try:
        event["repair_classification"] = classify_quality_issue(
            quality_issues,
            RepairLane.LAYOUT_REPAIR,
        ).to_dict()
    except Exception as exc:
        event["repair_classification_error"] = (
            f"{type(exc).__name__}: {exc}"
        )[:300]
    if repair_action_hints:
        event["repair_action_hints"] = repair_action_hints
        scene_hints = task_data.setdefault("_layout_repair_action_hints", {})
        if isinstance(scene_hints, dict):
            scene_hints[scene_name] = repair_action_hints
    if quantified_closure:
        event["quantified_closure"] = quantified_closure
        closures = task_data.setdefault("_layout_repair_quantified_closures", {})
        if isinstance(closures, dict):
            closures[scene_name] = quantified_closure
    if status == "repair_failed":
        residual_issue_top3 = _layout_repair_residual_issue_top3(quality_issues)
        task_data["_layout_repair_residual_issue_top3"] = residual_issue_top3
        event["residual_issue_top3"] = residual_issue_top3
    events.append(event)
    if status == "repaired":
        task_data["_layout_repair_count"] = task_data.get("_layout_repair_count", 0) + 1
        _record_layout_render_fix_count(
            task_data,
            render_fix_baseline=render_fix_baseline,
        )
    if status == "repair_degraded":
        task_data["_layout_degraded_success_count"] = (
            task_data.get("_layout_degraded_success_count", 0) + 1
        )
    if status == "repair_failed":
        task_data["_layout_repair_failed_count"] = (
            task_data.get("_layout_repair_failed_count", 0) + 1
        )
        if quantified_closure and quantified_closure.get("outcome") in {
            "unchanged",
            "worse",
        }:
            task_data["_layout_repair_no_quantified_improvement_count"] = (
                task_data.get("_layout_repair_no_quantified_improvement_count", 0) + 1
            )
            task_data["_layout_repair_failure_reason"] = "no_quantified_improvement"
    if collector is None:
        return
    try:
        method_fn = collector.warning if status == "repair_failed" else collector.info
        method_fn(
            "LAYOUT_REVIEW",
            "POST_RENDER_FIX",
            f"布局修复 {scene_name}: {status}/{method}",
            context=event,
        )
    except Exception:
        return

def _apply_cross_scene_dedup(
    *,
    ctx,
    scene_name: str,
    decision: LayoutDecision,
    demote_observed: bool = True,
) -> LayoutDecision:
    """对已经在同一 job 内被处理过的"模板化" issue 降级。

    同一 job 中如果之前 scene 已经修复过同样签名的 issue 但本 scene 仍然报，
    多半是 helper 的产物（如 ``setup_layout`` slot）；继续 nudge 只会让人不停看到字飞、缩字。
    把该 issue 标 repairable=False / record_only，但保留 issue 记录用于审计。
    """
    task_data = getattr(ctx, "task_data", None)
    if not isinstance(task_data, dict):
        return decision
    history = task_data.setdefault("_layout_issue_signatures", {})
    if not isinstance(history, dict):
        history = {}
        task_data["_layout_issue_signatures"] = history

    new_issues: list[LayoutIssue] = []
    deduped = 0
    for issue in decision.issues:
        if not _should_cross_scene_dedup(issue):
            new_issues.append(issue)
            continue
        sig = _layout_issue_signature(issue)
        prior = history.get(sig)
        if (
            prior
            and prior.get("scene_name") != scene_name
            and (
                prior.get("status") == "repaired"
                or (demote_observed and prior.get("status") == "observed")
            )
            and issue.repairable
        ):
            metadata = dict(issue.metadata or {})
            metadata["dedup_origin_scene"] = prior.get("scene_name")
            metadata["dedup_skipped"] = True
            metadata["dedup_origin_status"] = prior.get("status")
            new_issues.append(
                replace(
                    issue,
                    repairable=False,
                    deterministic_repairable=False,
                    needs_llm_judge=False,
                    severity="low",
                    metadata=metadata,
                )
            )
            deduped += 1
            continue
        # 首次出现：登记
        if sig not in history:
            history[sig] = {
                "scene_name": scene_name,
                "code": issue.code,
                "status": "observed",
            }
        new_issues.append(issue)

    if not deduped:
        return decision

    errors = sum(
        1 for i in new_issues
        if i.code in {
            "layout_overlap_error",
            "layout_container_overflow",
            "layout_frame_overflow",
        }
    )
    risks = sum(1 for i in new_issues if i.code in {"layout_overlap_risk", "layout_container_border_overlap"})
    repairable = any(i.repairable for i in new_issues)
    new_action = decision.final_action
    if not repairable and decision.final_action == "repair_candidate":
        new_action = "record_only"
    return replace(
        decision,
        issues=new_issues,
        layout_error_count=errors,
        layout_risk_count=risks,
        needs_repair=new_action == "repair_candidate",
        final_action=new_action,
    )
