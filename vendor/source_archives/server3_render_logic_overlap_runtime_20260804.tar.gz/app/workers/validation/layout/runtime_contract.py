from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _layout_repair_residual_issue_top3(quality_issues: list[dict]) -> list[dict]:
    residual: list[dict[str, Any]] = []
    for issue in quality_issues:
        if not isinstance(issue, dict):
            continue
        item = {
            "code": issue.get("code"),
            "severity": issue.get("severity"),
            "evidence": str(issue.get("evidence") or "")[:300],
            "overlap_ratio": issue.get("overlap_ratio"),
            "x_overlap": issue.get("x_overlap"),
            "y_overlap": issue.get("y_overlap"),
        }
        scene_name = issue.get("scene_name")
        if scene_name:
            item["scene_name"] = scene_name
        objects = [
            compact
            for compact in (
                _compact_layout_object(obj)
                for obj in (issue.get("objects") or [])[:2]
            )
            if compact
        ]
        if objects:
            item["objects"] = objects
        action_hints = _layout_issue_repair_action_hints(issue)
        if action_hints:
            item["repair_action_hints"] = action_hints
        residual.append(item)
        if len(residual) >= 3:
            break
    return residual

def _layout_issue_signature(issue: LayoutIssue) -> str:
    """以 (code, target_text, bbox 圆整) 为 key 标识"模板化"重复 issue。

    同一 helper / template 在多个 scene 渲染出极相似的 overlap 时，
    第一个 scene 触发完整修复后，其余 scene 复用历史结论，避免重复 nudge 引发抖动。
    """
    text_parts: list[str] = []
    for obj in (issue.objects or [])[:2]:
        if not isinstance(obj, dict):
            continue
        text_parts.append(str(obj.get("text") or "")[:40])
    text_key = "|".join(text_parts)

    def _round05(value):
        try:
            return round(float(value) * 2.0) / 2.0
        except (TypeError, ValueError):
            return 0.0

    bbox_key = "0,0,0,0"
    objs = issue.objects or []
    if objs and isinstance(objs[0], dict):
        bbox = objs[0].get("bbox") or {}
        bbox_key = (
            f"{_round05(bbox.get('left'))},{_round05(bbox.get('right'))},"
            f"{_round05(bbox.get('top'))},{_round05(bbox.get('bottom'))}"
        )
    return f"{issue.code}|{text_key}|{bbox_key}"
