from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


Severity = Literal["high", "medium", "low"]
FinalAction = Literal["record_only", "repair_candidate", "block_candidate"]


@dataclass(frozen=True)
class LayoutIssue:
    code: str
    severity: Severity
    confidence: float
    scene_name: str
    evidence: str
    overlap_ratio: float = 0.0
    x_overlap: float = 0.0
    y_overlap: float = 0.0
    objects: list[dict[str, Any]] = field(default_factory=list)
    repairable: bool = False
    deterministic_repairable: bool = False
    needs_llm_judge: bool = False
    suggested_fix: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class LayoutDecision:
    mode: str
    scene_name: str
    final_action: FinalAction
    issues: list[LayoutIssue]
    latency_ms: int = 0
    needs_repair: bool = False
    layout_error_count: int = 0
    layout_risk_count: int = 0
    artifact_path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["issues"] = [issue.to_dict() for issue in self.issues]
        return payload
