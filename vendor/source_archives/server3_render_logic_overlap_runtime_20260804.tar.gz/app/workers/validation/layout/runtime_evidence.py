from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _layout_issue_error_summary(issues: list[LayoutIssue]) -> str:
    rows: list[str] = []
    for issue in issues[:4]:
        parts = [
            issue.code,
            f"scene={issue.scene_name}",
            f"severity={issue.severity}",
        ]
        if issue.overlap_ratio:
            parts.append(f"overlap_ratio={_compact_layout_number(issue.overlap_ratio)}")
        if issue.x_overlap:
            parts.append(f"x_overlap={_compact_layout_number(issue.x_overlap)}")
        if issue.y_overlap:
            parts.append(f"y_overlap={_compact_layout_number(issue.y_overlap)}")
        objects = [
            _layout_issue_object_summary(obj)
            for obj in (issue.objects or [])[:3]
            if isinstance(obj, dict)
        ]
        if objects:
            parts.append("objects=[" + "; ".join(objects) + "]")
        if issue.evidence:
            parts.append(f"evidence={_compact_layout_text(issue.evidence, 360)}")
        if issue.suggested_fix:
            parts.append(
                f"suggested_fix={_compact_layout_text(issue.suggested_fix, 360)}"
            )
        action_hints = _layout_issue_repair_action_hints(issue)
        if action_hints:
            parts.append(
                "action_hints="
                + _layout_action_hints_summary(action_hints, limit=360)
            )
        metadata = _layout_issue_metadata_summary(issue.metadata)
        if metadata:
            parts.append(f"metadata={metadata}")
        rows.append(" | ".join(parts))
    return " || ".join(rows)[:1800]


_OVERLAP_EVIDENCE_RE = re.compile(
    r"(?P<a>.+?)\s+overlaps\s+(?P<b>.+?);\s*"
    r"overlap_ratio=(?P<overlap_ratio>-?\d+(?:\.\d+)?),\s*"
    r"x_overlap=(?P<x_overlap>-?\d+(?:\.\d+)?),\s*"
    r"y_overlap=(?P<y_overlap>-?\d+(?:\.\d+)?)"
)
_FRAME_OVERFLOW_EVIDENCE_RE = re.compile(
    r"(?P<object>.+?)\s+exceeds\s+frame\s+bounds;\s*"
    r"overflow_x=(?P<overflow_x>-?\d+(?:\.\d+)?),\s*"
    r"overflow_y=(?P<overflow_y>-?\d+(?:\.\d+)?)"
    r"(?:,\s*frame=\[(?P<frame>[^\]]+)\])?"
)


def _annotate_layout_decision_repair_action_hints(
    decision: LayoutDecision,
) -> LayoutDecision:
    issues = [_layout_issue_with_repair_action_hints(issue) for issue in decision.issues]
    if issues == decision.issues:
        return decision
    return replace(decision, issues=issues)


def _layout_issue_with_repair_action_hints(issue: LayoutIssue) -> LayoutIssue:
    hints = _layout_issue_repair_action_hints(issue)
    if not hints:
        return issue
    metadata = dict(issue.metadata or {})
    if metadata.get("repair_action_hints") == hints:
        return issue
    metadata["repair_action_hints"] = hints
    return replace(issue, metadata=metadata)


def _layout_issue_payload_with_repair_hints(
    issue: LayoutIssue,
    *,
    layout_repair_plan: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload = issue.to_dict()
    _attach_layout_repair_action_hints(payload)
    _attach_layout_repair_plan(payload, layout_repair_plan)
    return payload


def _layout_issue_payloads_with_repair_hints(
    issues: list[LayoutIssue],
    *,
    layout_repair_plan: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    return [
        _layout_issue_payload_with_repair_hints(
            issue,
            layout_repair_plan=layout_repair_plan,
        )
        for issue in issues
    ]


def _layout_quality_issue_payloads_with_repair_hints(
    quality_issues: list[dict],
    *,
    layout_repair_plan: dict[str, Any] | None = None,
) -> list[dict]:
    result: list[dict] = []
    for issue in quality_issues:
        if not isinstance(issue, dict):
            result.append(issue)
            continue
        payload = dict(issue)
        _attach_layout_repair_action_hints(payload)
        _attach_layout_repair_plan(payload, layout_repair_plan)
        result.append(payload)
    return result


def _layout_issue_payloads_for_repair_context(
    issues: list[LayoutIssue],
    *,
    scene_name: str,
    layout_repair_plan: dict[str, Any] | None = None,
    no_progress: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    payloads = _layout_issue_payloads_with_repair_hints(
        issues,
        layout_repair_plan=layout_repair_plan,
    )
    payloads = annotate_layout_issues_with_plan(
        payloads,
        scene_name=scene_name,
        no_progress=no_progress,
    )
    if layout_repair_plan and layout_repair_plan.get("constraints"):
        for payload in payloads:
            if isinstance(payload, dict):
                _attach_layout_repair_plan(payload, layout_repair_plan)
    return payloads


def _attach_layout_repair_plan(
    issue: dict[str, Any],
    layout_repair_plan: dict[str, Any] | None,
) -> None:
    if not isinstance(layout_repair_plan, dict) or not layout_repair_plan.get(
        "constraints"
    ):
        return
    metadata = issue.get("metadata")
    if isinstance(metadata, dict):
        metadata = dict(metadata)
        issue["metadata"] = metadata
    else:
        metadata = {}
        issue["metadata"] = metadata
    metadata["layout_repair_plan"] = layout_repair_plan
    issue["layout_repair_plan"] = layout_repair_plan


def _attach_layout_repair_action_hints(issue: dict[str, Any]) -> None:
    hints = _layout_issue_repair_action_hints(issue)
    if not hints:
        return
    issue["repair_action_hints"] = hints
    metadata = issue.get("metadata")
    if isinstance(metadata, dict):
        metadata = dict(metadata)
        issue["metadata"] = metadata
    else:
        metadata = {}
        issue["metadata"] = metadata
    metadata["repair_action_hints"] = hints


