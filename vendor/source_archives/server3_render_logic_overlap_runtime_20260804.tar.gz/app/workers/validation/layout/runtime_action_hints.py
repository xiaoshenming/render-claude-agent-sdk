from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _overlap_action_hints(
    issue: LayoutIssue | dict[str, Any],
) -> list[dict[str, Any]]:
    objects = _layout_issue_objects(issue)
    parsed = _parse_overlap_evidence(str(_layout_issue_get(issue, "evidence") or ""))
    labels = _overlap_labels(objects, parsed)
    if not labels:
        return []
    target, avoid = _choose_layout_action_target(objects, labels)
    overlap_ratio = _issue_number_from_fields_or_parsed(
        issue,
        "overlap_ratio",
        parsed,
    )
    x_overlap = _issue_number_from_fields_or_parsed(issue, "x_overlap", parsed)
    y_overlap = _issue_number_from_fields_or_parsed(issue, "y_overlap", parsed)
    geometry = _clean_layout_geometry(
        {
            "overlap_ratio": overlap_ratio,
            "x_overlap": x_overlap,
            "y_overlap": y_overlap,
        }
    )
    hints: list[dict[str, Any]] = []
    if _needs_clear_zone_overlap_repair(labels, overlap_ratio):
        hints.append(
            {
                "action": "move_label_or_formula_to_clear_zone",
                "target": target,
                "avoid": avoid,
                "preserve_anchor": "main_diagram",
                "target_zone": _clear_zone_for_overlap_target(target),
                "forbidden_actions": ["reduce_font_first", "move_both_objects_blindly"],
                "geometry": geometry,
                "reason": "severe_formula_or_label_shape_overlap",
            }
        )
    hints.extend(
        [
            {
                "action": "move_text_or_label",
                "target": target,
                "avoid": avoid,
                "geometry": geometry,
                "reason": "text_or_label_overlap",
            },
            {
                "action": "nudge_apart",
                "target": target,
                "avoid": avoid,
                "axis": "x" if abs(x_overlap) >= abs(y_overlap) else "y",
                "min_distance": _round_layout_float(
                    max(abs(x_overlap), abs(y_overlap), 0.12) + 0.08
                ),
                "geometry": geometry,
            },
        ]
    )
    if _layout_label_is_textual(target) or any(
        _layout_label_is_textual(label) for label in labels
    ):
        hints.append(
            {
                "action": "reduce_font",
                "target": target,
                "scale_hint": _font_scale_hint(overlap_ratio),
                "geometry": geometry,
            }
        )
    if not objects or not _object_has_bbox(objects):
        hints.append(
            {
                "action": "move_to_safe_slot",
                "target": target,
                "avoid": avoid,
                "slot_priority": ["UP", "DOWN", "LEFT", "RIGHT"],
                "geometry": geometry,
            }
        )
    return hints

def _frame_overflow_action_hints(
    issue: LayoutIssue | dict[str, Any],
) -> list[dict[str, Any]]:
    objects = _layout_issue_objects(issue)
    parsed = _parse_frame_overflow_evidence(
        str(_layout_issue_get(issue, "evidence") or "")
    )
    target = _frame_overflow_target(objects, parsed)
    overflow_x = _issue_number_from_fields_or_parsed(
        issue,
        "x_overlap",
        parsed,
        parsed_key="overflow_x",
    )
    overflow_y = _issue_number_from_fields_or_parsed(
        issue,
        "y_overlap",
        parsed,
        parsed_key="overflow_y",
    )
    frame = _frame_from_issue_or_parsed(issue, parsed)
    geometry = _clean_layout_geometry(
        {
            "overflow_x": overflow_x,
            "overflow_y": overflow_y,
            "frame": frame,
        }
    )
    return [
        {
            "action": "scale_to_fit_frame",
            "target": target,
            "scale_hint": _frame_scale_hint(overflow_x, overflow_y),
            "geometry": geometry,
        },
        {
            "action": "shift_inside_frame",
            "target": target,
            "direction": _shift_inside_frame_direction(objects, frame),
            "geometry": geometry,
        },
    ]

def _layout_action_hints_summary(
    hints: list[dict[str, Any]],
    *,
    limit: int,
) -> str:
    action_names = ",".join(
        str(hint.get("action") or "")
        for hint in hints[:6]
        if hint.get("action")
    )
    rows: list[str] = []
    for hint in hints[:6]:
        action = str(hint.get("action") or "")
        parts = [action]
        for key in (
            "target_zone",
            "preserve_anchor",
            "target",
            "avoid",
            "axis",
            "direction",
            "scale_hint",
            "min_distance",
        ):
            if hint.get(key) is not None:
                parts.append(f"{key}={_compact_layout_text(hint[key], 80)}")
        if hint.get("forbidden_actions"):
            parts.append(
                "forbidden_actions="
                + "|".join(str(item) for item in hint["forbidden_actions"][:4])
            )
        geometry = hint.get("geometry")
        if isinstance(geometry, dict):
            geo_parts = [
                f"{key}={_compact_layout_number(value)}"
                for key, value in geometry.items()
                if key != "frame" and value is not None
            ]
            if geometry.get("frame") is not None:
                geo_parts.append(f"frame={geometry.get('frame')}")
            if geo_parts:
                parts.append("geometry(" + ",".join(geo_parts) + ")")
        rows.append("(" + ",".join(parts) + ")")
    summary = ";".join(rows)
    if action_names:
        summary = f"actions={action_names};{summary}"
    return _compact_layout_text(summary, limit)
