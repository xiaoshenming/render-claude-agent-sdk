from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutIssue = _runtime.LayoutIssue

def _record_layout_repair_plan(
    task_data: dict | None,
    *,
    scene_name: str,
    issues: list[LayoutIssue],
) -> dict[str, Any]:
    plan = build_layout_repair_plan(issues)
    if not isinstance(task_data, dict) or not plan.get("constraints"):
        return plan

    signature_counts = task_data.setdefault("_layout_bbox_signature_counts", {})
    if not isinstance(signature_counts, dict):
        signature_counts = {}
        task_data["_layout_bbox_signature_counts"] = signature_counts
    plan = mark_layout_repair_plan_progress(
        plan,
        signature_counts=signature_counts,
    )
    plans = task_data.setdefault("_layout_repair_plans", [])
    if isinstance(plans, list):
        plans.append(plan)
        task_data["_layout_repair_plans"] = plans[-20:]
    by_scene = task_data.setdefault("_layout_repair_plan_by_scene", {})
    if isinstance(by_scene, dict):
        by_scene[scene_name] = plan
    task_data["_layout_repair_plan"] = plan
    if plan.get("escalation"):
        task_data["_layout_repair_escalation"] = plan["escalation"]
    return plan

def _layout_repair_last_error(
    issues: list[LayoutIssue],
    *,
    recheck_failed: bool,
    layout_repair_plan: dict[str, Any] | None = None,
) -> str:
    plan_context = layout_repair_plan_to_prompt_context(layout_repair_plan)
    runtime_issue = next(
        (issue for issue in issues if issue.code == "layout_probe_runtime_error"),
        None,
    )
    if runtime_issue is not None:
        prefix = (
            "layout_probe_runtime_error_recheck_failed"
            if recheck_failed
            else "layout_probe_runtime_error"
        )
        message = f"{prefix}: {runtime_issue.evidence[:500]}"
        return f"{message}\n{plan_context}" if plan_context else message
    prefix = (
        "layout_overlap_review_recheck_failed"
        if recheck_failed
        else "layout_overlap_review"
    )
    summary = _layout_issue_error_summary(issues)
    if summary:
        message = f"{prefix}: {summary}"
        return f"{message}\n{plan_context}" if plan_context else message
    return f"{prefix}\n{plan_context}" if plan_context else prefix

def _layout_issue_object_summary(obj: dict[str, Any]) -> str:
    label = (
        obj.get("name")
        or obj.get("id")
        or obj.get("label")
        or obj.get("class")
        or obj.get("kind")
        or "object"
    )
    parts = [str(label)[:80]]
    if obj.get("text"):
        parts.append(f"text={_compact_layout_text(obj.get('text'), 120)}")
    bbox = obj.get("bbox") if isinstance(obj.get("bbox"), dict) else {}
    bbox_parts = [
        f"{key}={_compact_layout_number(bbox[key])}"
        for key in (
            "x_min",
            "x_max",
            "y_min",
            "y_max",
            "center_x",
            "center_y",
            "width",
            "height",
        )
        if bbox.get(key) is not None
    ]
    if bbox_parts:
        parts.append("bbox(" + ",".join(bbox_parts) + ")")
    return ",".join(parts)

def _mark_shared_layout_repair_event_scope(
    task_data: dict,
    *,
    helper_name: str,
    scenes: list[str],
    touched_scenes: list[str],
) -> None:
    scene_set = set(scenes)
    events = task_data.get("_layout_repair_events")
    if not isinstance(events, list):
        return
    for event in events:
        if not isinstance(event, dict):
            continue
        if (
            event.get("type") != "layout_repair"
            or event.get("status") != "repaired"
        ):
            continue
        if event.get("scene_name") not in scene_set:
            continue
        event["scope"] = "shared"
        event["cross_scene_scope"] = len(touched_scenes) > 1
        event["shared_helper"] = helper_name
        event["touched_scenes"] = touched_scenes
        event["scope_evidence"] = {
            "reason": "shared_helper_merge",
            "helper": helper_name,
            "source_scenes": scenes,
        }
