from app.workers.validation.layout import runtime as _runtime
Any = _runtime.Any
LayoutDecision = _runtime.LayoutDecision
LayoutIssue = _runtime.LayoutIssue

def _layout_overlap_summary(decision: LayoutDecision) -> tuple[int, float]:
    count = 0
    max_ratio = 0.0
    for issue in decision.issues:
        if _is_protected_record_only_layout_issue(issue):
            continue
        ratio = float(issue.overlap_ratio or 0.0)
        if ratio <= 0:
            continue
        count += 1
        max_ratio = max(max_ratio, ratio)
    return count, max_ratio


def _layout_blocking_overlap_summary(decision: LayoutDecision) -> tuple[int, float]:
    """Count only residual findings that should keep a repair loop alive."""
    count = 0
    max_ratio = 0.0
    for issue in decision.issues:
        if _is_protected_record_only_layout_issue(issue):
            continue
        if issue.code not in _LAYOUT_HARD_ERROR_CODES and not issue.repairable:
            continue
        ratio = float(issue.overlap_ratio or 0.0)
        if ratio <= 0:
            continue
        count += 1
        max_ratio = max(max_ratio, ratio)
    return count, max_ratio


def _layout_repair_has_blocking_residual(decision: LayoutDecision) -> bool:
    """Return whether a recheck still has findings worth failing closed on."""
    if decision.needs_repair or decision.layout_error_count > 0:
        return True
    for issue in decision.issues:
        if _is_protected_record_only_layout_issue(issue):
            continue
        if issue.code == "layout_probe_runtime_error":
            return True
        if issue.code in _LAYOUT_HARD_ERROR_CODES:
            return True
        if issue.repairable and float(issue.overlap_ratio or 0.0) > 0:
            return True
    return False


def _layout_repair_quantified_closure(
    before: LayoutDecision,
    after: LayoutDecision,
) -> dict[str, Any]:
    before_count, before_max = _layout_overlap_summary(before)
    after_count, after_max = _layout_overlap_summary(after)
    eps = 1e-9
    if after_count > before_count or after_max > before_max + eps:
        outcome = "worse"
    elif after_count < before_count and after_max < before_max - eps:
        outcome = "improved"
    else:
        outcome = "unchanged"
    return {
        "outcome": outcome,
        "before_overlap_count": before_count,
        "after_overlap_count": after_count,
        "before_max_overlap_ratio": before_max,
        "after_max_overlap_ratio": after_max,
        "overlap_count_delta": before_count - after_count,
        "max_overlap_ratio_delta": round(before_max - after_max, 6),
    }


def _layout_repair_has_quantified_improvement(
    closure: dict[str, Any],
) -> bool:
    return closure.get("outcome") == "improved"


def _layout_repair_requires_quantified_improvement(
    closure: dict[str, Any],
) -> bool:
    return (
        int(closure.get("before_overlap_count") or 0) > 0
        or float(closure.get("before_max_overlap_ratio") or 0.0) > 0.0
    )


def _layout_repair_should_fail_fast(closure: dict[str, Any]) -> bool:
    return (
        _layout_repair_requires_quantified_improvement(closure)
        and not _layout_repair_has_quantified_improvement(closure)
    )


def _layout_repair_fail_fast_reason(
    before: LayoutDecision,
    after: LayoutDecision,
) -> str:
    if not _layout_repair_has_blocking_residual(after):
        return ""
    closure = _layout_repair_quantified_closure(before, after)
    if _layout_repair_should_fail_fast(closure):
        return _layout_repair_no_improvement_error(closure)
    stubborn_reason = _layout_repair_stubborn_semantic_residual_reason(before, after)
    if stubborn_reason:
        return stubborn_reason
    return ""


def _layout_repair_no_improvement_error(closure: dict[str, Any]) -> str:
    return (
        "no_quantified_improvement:"
        f"{closure.get('outcome')}; "
        f"overlap_count={closure.get('before_overlap_count')}"
        f"->{closure.get('after_overlap_count')}; "
        f"max_ratio={closure.get('before_max_overlap_ratio')}"
        f"->{closure.get('after_max_overlap_ratio')}"
    )


def _layout_repair_stubborn_semantic_residual_reason(
    before: LayoutDecision,
    after: LayoutDecision,
) -> str:
    before_signature = _layout_issue_semantic_signature(
        _layout_blocking_signature_issues(before.issues),
    )
    after_issues = _layout_blocking_signature_issues(after.issues)
    after_signature = _layout_issue_semantic_signature(after_issues)
    if not before_signature or before_signature != after_signature:
        return ""
    _, after_max = _layout_blocking_overlap_summary(after)
    min_overlap = _env_float(
        "LAYOUT_REPAIR_STUBBORN_RESIDUAL_MIN_OVERLAP_RATIO",
        0.30,
        minimum=0.0,
    )
    if after_max < min_overlap:
        return ""
    return (
        "no_quantified_improvement:stubborn_semantic_residual; "
        f"overlap_signature={after_signature[:160]}; "
        f"max_ratio={after_max:.3f}"
    )


def _layout_blocking_signature_issues(
    issues: list[LayoutIssue],
) -> list[LayoutIssue]:
    result: list[LayoutIssue] = []
    for issue in issues:
        if _is_protected_record_only_layout_issue(issue):
            continue
        if (
            issue.code in _LAYOUT_HARD_ERROR_CODES
            or issue.code == "layout_probe_runtime_error"
            or issue.repairable
        ):
            result.append(issue)
    return result


def _is_protected_record_only_layout_issue(issue: LayoutIssue) -> bool:
    if issue.code != "layout_overlap_risk":
        return False
    if issue.severity != "low":
        return False
    if issue.repairable or issue.deterministic_repairable:
        return False
    if not bool((issue.metadata or {}).get("protected_geometry_label")):
        return False
    suggested_fix = str(issue.suggested_fix or "")
    return "只记录" in suggested_fix and "正常标注" in suggested_fix


def _clear_protected_record_only_judge_flags(
    issues: list[LayoutIssue],
) -> tuple[list[LayoutIssue], bool]:
    new_issues: list[LayoutIssue] = []
    changed = False
    for issue in issues:
        if _is_protected_record_only_layout_issue(issue) and issue.needs_llm_judge:
            new_issues.append(replace(issue, needs_llm_judge=False))
            changed = True
        else:
            new_issues.append(issue)
    return new_issues, changed


def _layout_recheck_clean_enough(
    before: LayoutDecision,
    after: LayoutDecision,
) -> tuple[bool, str]:
    """Return whether a deterministic layout repair is good enough to accept."""
    fail_fast_reason = _layout_repair_fail_fast_reason(before, after)
    if fail_fast_reason:
        return False, fail_fast_reason
    if after.needs_repair:
        return False, "recheck_still_needs_repair"
    if after.layout_error_count > 0:
        return False, f"recheck_layout_errors={after.layout_error_count}"

    hard_residuals = [
        issue
        for issue in after.issues
        if issue.code in _LAYOUT_HARD_ERROR_CODES
        and issue.severity in {"high", "medium"}
    ]
    if hard_residuals:
        top = hard_residuals[0]
        return False, f"hard_residual_issue={top.code}:{top.severity}"

    before_count, before_max = _layout_overlap_summary(before)
    after_count, after_max = _layout_overlap_summary(after)
    max_allowed = _env_float(
        "LAYOUT_REPAIR_MAX_RESIDUAL_OVERLAP_RATIO",
        0.08,
        minimum=0.0,
    )
    if after_max > max_allowed:
        return False, f"residual_overlap_ratio={after_max:.3f}>{max_allowed:.3f}"

    min_improvement = _env_float(
        "LAYOUT_DETERMINISTIC_MIN_OVERLAP_IMPROVEMENT",
        0.25,
        minimum=0.0,
    )
    if before_count > 0 and before_max > 0 and after_count > 0:
        improvement = (before_max - after_max) / max(before_max, 1e-6)
        if after_count >= before_count and improvement < min_improvement:
            return False, f"low_overlap_improvement={improvement:.3f}"

    return True, "clean"


async def _judge_recheck_if_still_blocking(
    *,
    ctx,
    scene_name: str,
    before: LayoutDecision,
    recheck: LayoutDecision,
) -> tuple[LayoutDecision, bool, str]:
    fail_fast_reason = _layout_repair_fail_fast_reason(before, recheck)
    if fail_fast_reason:
        return recheck, False, fail_fast_reason

    recheck_clean, recheck_reason = _layout_recheck_clean_enough(
        before,
        recheck,
    )
    if recheck_reason.startswith("residual_overlap_ratio="):
        return recheck, False, recheck_reason
    if recheck_clean:
        return recheck, recheck_clean, recheck_reason

    judged = await _apply_llm_judge_if_needed(
        ctx=ctx,
        scene_name=scene_name,
        decision=recheck,
    )
    judged_clean, judged_reason = _layout_recheck_clean_enough(
        before,
        judged,
    )
    return judged, judged_clean, judged_reason


