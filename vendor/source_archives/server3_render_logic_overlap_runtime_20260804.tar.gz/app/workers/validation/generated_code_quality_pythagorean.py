import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _has_pythagorean_three_square_context(source: str) -> bool:
    if not _RIGHT_TRIANGLE_CONTEXT_RE.search(source):
        return False
    return len(_pythagorean_area_symbols(source)) >= 3


def _uses_trusted_pythagorean_square_helper(source: str) -> bool:
    return bool(re.search(r"\b(?:self\.)?pythagorean_squares_visual\s*\(", source))


def _pythagorean_block_mentions_square_visual(source: str) -> bool:
    return bool(
        "Square(" in source
        or "square_on_segment(" in source
        or re.search(r"\bsquare_[abc]\b|\b[abc]_square\b", source, re.I)
        or _uses_trusted_pythagorean_square_helper(source)
    )


def _pythagorean_block_has_valid_three_square_visual(source: str) -> bool:
    if _uses_trusted_pythagorean_square_helper(source):
        return True
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return False
    records = _pythagorean_square_records(tree)
    bound_labels = {
        record["label"]
        for record in records
        if record["label"] in {"a", "b", "c"} and record["edge_bound"]
    }
    if bound_labels != {"a", "b", "c"}:
        return False
    return not _pythagorean_square_label_center_issues(tree, 0, {"a", "b", "c"})


def _pythagorean_area_symbols(source: str) -> set[str]:
    labels: set[str] = set()
    for label in ("a", "b", "c"):
        if re.search(
            rf"{label}\s*(?:\^|\*\*)\s*2|{label}\s*\^\s*\{{\s*2\s*\}}",
            source,
            re.I,
        ):
            labels.add(label)
    return labels


def _pythagorean_square_records(tree: ast.AST) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            continue
        target_name = node.targets[0].id
        square_kind = _pythagorean_square_assignment_kind(node.value)
        if square_kind is None:
            continue
        label = _pythagorean_square_label_from_name(target_name)
        detached_line, detached_evidence = _detached_pythagorean_square_evidence(
            node.value,
            target_name,
        )
        records.append(
            {
                "name": target_name,
                "label": label or "",
                "edge_bound": square_kind == "edge_bound",
                "detached": bool(detached_line),
                "line": detached_line or getattr(node, "lineno", 1),
                "evidence": detached_evidence or f"{target_name}={square_kind}",
            }
        )
    return records


def _pythagorean_square_assignment_kind(node: ast.AST) -> str | None:
    for call in ast.walk(node):
        if not isinstance(call, ast.Call):
            continue
        func_name = _call_name(call.func)
        if func_name == "square_on_segment":
            return "edge_bound"
        if func_name == "Square":
            return "free_square"
    return None


def _pythagorean_square_label_from_name(name: str) -> str | None:
    match = _PYTHAGOREAN_SQUARE_VAR_RE.search(name)
    if not match:
        return None
    label = match.group("label") or match.group("label_alt")
    return label.lower() if label else None


def _detached_pythagorean_square_evidence(
    node: ast.AST,
    target_name: str,
) -> tuple[int, str]:
    if _pythagorean_square_assignment_kind(node) == "edge_bound":
        return (0, "")
    for call in ast.walk(node):
        if not (
            isinstance(call, ast.Call)
            and isinstance(call.func, ast.Attribute)
            and call.func.attr == "move_to"
            and call.args
        ):
            continue
        anchor_expr = _normalize_expr(ast.unparse(call.args[0]))
        if _pythagorean_square_anchor_mentions_edge(anchor_expr):
            continue
        return (
            getattr(call, "lineno", 1),
            f"{target_name}.move_to({anchor_expr}) without triangle edge midpoint/segment",
        )
    return (0, "")


def _pythagorean_square_anchor_mentions_edge(anchor_expr: str) -> bool:
    return bool(
        re.search(r"\b[A-C]\b", anchor_expr)
        or any(marker in anchor_expr for marker in ("Line(", "get_center(", "midpoint"))
    )


def _pythagorean_square_label_center_issues(
    tree: ast.AST,
    line_offset: int,
    square_labels: set[str],
) -> list[GeneratedCodeQualityIssue]:
    issues: list[GeneratedCodeQualityIssue] = []
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            continue
        target_name = node.targets[0].id
        label = _pythagorean_area_label_from_assignment(target_name, node.value)
        if label is None or label not in square_labels:
            continue
        square_var = f"square_{label}"
        if _assignment_moves_label_to_square_center(node.value, square_var):
            continue
        issues.append(
            GeneratedCodeQualityIssue(
                code="pythagorean_square_label_center_binding",
                severity="error",
                message=(
                    f"{label}^2 标签没有绑定到 {square_var} 的中心；"
                    "面积标签必须位于对应正方形中心，不能 next_to 或压到边线上。"
                ),
                line=line_offset + getattr(node, "lineno", 1),
                evidence=(
                    f"{target_name} should use "
                    f"MathTex(\"{label}^2\").move_to({square_var}.get_center())"
                ),
                failure_code="misbound_label",
            )
        )
        break
    return issues


def _pythagorean_area_label_from_assignment(
    target_name: str,
    value: ast.AST,
) -> str | None:
    label_from_name = re.search(r"(?:^|_)label_(?P<label>[abc])(?:_|$)", target_name, re.I)
    for call in ast.walk(value):
        if not isinstance(call, ast.Call):
            continue
        if _call_name(call.func) not in _TEXT_CONSTRUCTOR_NAMES:
            continue
        text = _first_string_arg(call)
        label_from_text = _pythagorean_single_area_label(text or "")
        if label_from_text is None:
            continue
        if label_from_name and label_from_name.group("label").lower() != label_from_text:
            continue
        return label_from_text
    return None


def _pythagorean_single_area_label(text: str) -> str | None:
    normalized = re.sub(r"\s+", "", text.lower()).replace("{", "").replace("}", "")
    for label in ("a", "b", "c"):
        if normalized in {f"{label}^2", f"{label}**2"}:
            return label
    return None


def _assignment_moves_label_to_square_center(node: ast.AST, square_var: str) -> bool:
    expected = f"{square_var}.get_center()"
    for call in ast.walk(node):
        if not (
            isinstance(call, ast.Call)
            and isinstance(call.func, ast.Attribute)
            and call.func.attr == "move_to"
            and call.args
        ):
            continue
        if _normalize_expr(ast.unparse(call.args[0])) == expected:
            return True
    return False


