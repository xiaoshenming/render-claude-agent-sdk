"""Evidence-producing AST and structural checks for generated Manim code."""

import ast
import re
from typing import Optional

_SCENE_ANIMATION_CALL_RE = re.compile(
    r"\bself\.(?:play|play_steps_evenly)\s*\("
)
_SCENE_ANIMATION_METHODS = {"play", "play_steps_evenly"}

def _has_scene_animation_call(code: str, scene_name: str) -> bool:
    """目标 Scene 中是否存在真实动画调用。

    `play_steps_evenly` 是项目模板里的官方动画调度 helper，内部会调用
    `self.play(...)`，因此也应视为有效动画代码。
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return bool(_SCENE_ANIMATION_CALL_RE.search(code or ""))

    for node in tree.body:
        if not isinstance(node, ast.ClassDef) or node.name != scene_name:
            continue
        for child in ast.walk(node):
            if not isinstance(child, ast.Call):
                continue
            func = child.func
            if (
                isinstance(func, ast.Attribute)
                and isinstance(func.value, ast.Name)
                and func.value.id == "self"
                and func.attr in _SCENE_ANIMATION_METHODS
            ):
                return True
    return False


def validate_generated_code_shape(
    code: str,
    expected_scene_name: Optional[str] = None,
) -> tuple[bool, str]:
    """过滤明显不是 Python/Manim 代码的 LLM 输出。"""
    stripped = (code or "").strip()
    if not stripped:
        return False, "LLM输出为空"

    nonempty_lines = [
        line.strip() for line in stripped.splitlines() if line.strip()]
    if not nonempty_lines:
        return False, "LLM输出为空"

    first_line = nonempty_lines[0]
    code_marker_re = (
        r"^\s*(from\s+\w+\s+import|import\s+\w+|class\s+\w+\s*\(|"
        r"def\s+\w+\s*\(|async\s+def\s+\w+\s*\()"
    )
    has_code_marker = bool(re.search(code_marker_re, stripped, re.MULTILINE))
    has_scene_signal = "Scene" in stripped or "self." in stripped
    has_markdown_preamble = bool(
        re.search(
            r"(?m)^(#{1,6}\s|\*\*.+\*\*|- )",
            "\n".join(nonempty_lines[:8]),
        )
    )
    prose_start_re = (
        r"(?i)^(i['']ll|here['']s|let['']s|sure[, ]|first[, ]|"
        r"below is|the following|we need to|math verification)"
    )

    if expected_scene_name:
        scene_pattern = (
            rf"class\s+{re.escape(expected_scene_name)}\s*\([^)]*\)\s*:"
        )
        if not re.search(scene_pattern, stripped):
            return False, f"LLM输出缺少目标 Scene 类: {expected_scene_name}"

    if not has_code_marker and not has_scene_signal:
        return False, "LLM输出为非代码内容"

    if re.match(prose_start_re, first_line) and not re.match(
        code_marker_re, first_line
    ):
        return False, "LLM输出为非代码内容"

    if has_markdown_preamble and not has_code_marker:
        return False, "LLM输出为非代码内容"

    # --- 截断检测 ---
    last_line = nonempty_lines[-1].rstrip()
    truncation_signs = [
        last_line.endswith("\\"),
        last_line.endswith(",") and not last_line.endswith("),"),
        last_line.count("(") > last_line.count(")"),
        last_line.count("[") > last_line.count("]"),
        last_line.count("{") > last_line.count("}"),
    ]

    has_construct = "def construct(self" in stripped
    has_scene_class = bool(re.search(r"class\s+\w+.*Scene", stripped))
    if has_scene_class and not has_construct:
        return False, "LLM输出被截断：有 Scene 类但缺少 construct 方法"

    if last_line.rstrip().endswith("=") or last_line.rstrip().endswith("def"):
        return False, (
            f"LLM输出疑似被截断，末尾不完整: ...{last_line[-40:]}")

    if any(truncation_signs):
        return False, (
            f"LLM输出疑似被截断，末尾不完整: ...{last_line[-40:]}")

    if expected_scene_name:
        scene_body_match = re.search(
            rf"class\s+{re.escape(expected_scene_name)}\s*\([^)]*\)\s*:(.*)",
            stripped,
            re.DOTALL,
        )
        if scene_body_match and not _has_scene_animation_call(
            stripped,
            expected_scene_name,
        ):
            return False, (
                f"LLM输出疑似不完整：目标 Scene {expected_scene_name} "
                f"缺少有效动画代码")

    base_match = re.search(r"class\s+BaseConfigScene\s*(\([^)]*\))?\s*:", stripped)
    if base_match:
        base_decl = base_match.group(0)
        if "(Scene)" not in base_decl and "(VoiceoverScene)" not in base_decl and \
                "(ThreeDScene)" not in base_decl and "(VoiceoverScene, ThreeDScene)" not in base_decl:
            return False, "LLM输出中的 BaseConfigScene 缺少对 Scene 基类的继承"

        base_body_match = re.search(
            r"class\s+BaseConfigScene\s*\([^)]*\)\s*:(.*?)(?=\nclass\s+\w|\Z)",
            stripped,
            re.DOTALL,
        )
        if base_body_match:
            base_body = base_body_match.group(1)
            required_methods = ("def setup_layout",)
            missing = [name for name in required_methods if name not in base_body]
            if missing:
                return False, (
                    "LLM输出中的 BaseConfigScene 不完整，缺少方法: "
                    + ", ".join(missing)
                )

    scene_count = len(
        re.findall(r"class\s+Scene_\d+_\w+\s*\(", stripped))
    if 2 <= scene_count < 4:
        return False, (
            f"LLM输出内容不足：只生成了 {scene_count} 个 Scene 切片"
            f"（最少需要 4 个），可能被截断或内容过于简略"
        )

    if scene_count >= 4 and "# END" not in stripped:
        last_scene_match = list(
            re.finditer(
                r"class\s+Scene_\d+_\w+\s*\([^)]*\)\s*:", stripped))
        if last_scene_match:
            last_scene_code = stripped[last_scene_match[-1].start():]
            if "def construct(self" not in last_scene_code:
                return False, (
                    "LLM输出被截断：最后一个 Scene 缺少 construct 方法")

    return True, ""
