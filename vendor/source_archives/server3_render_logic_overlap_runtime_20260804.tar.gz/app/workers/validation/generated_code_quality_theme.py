import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _durable_panel_manual_coordinate_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()
    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "move_to"
            and node.args
            and isinstance(node.func.value, ast.Name)
            and _DURABLE_PANEL_VAR_RE.search(node.func.value.id)
            and _is_manual_coordinate_arg(node.args[0])
        ):
            continue
        evidence = _call_evidence(source, node)
        line = getattr(node, "lineno", 1)
        key = (evidence, line)
        if key in seen:
            continue
        seen.add(key)
        issues.append(
            GeneratedCodeQualityIssue(
                code="durable_panel_manual_coordinates",
                severity="error",
                message=(
                    "durable panel/proof/formula/card 对象使用手写坐标 move_to；"
                    "应通过 place_panel(..., avoid=visible_objects) 或 layout_canvas 区域合同重写。"
                ),
                line=line,
                evidence=evidence,
                failure_code="durable_panel_manual_coordinates",
            )
        )
    return issues


def _is_manual_coordinate_arg(node: ast.AST) -> bool:
    if _is_numeric_sequence(node):
        return True
    if not isinstance(node, ast.Call) or not node.args:
        return False
    return _call_name(node.func) == "array" and _is_numeric_sequence(node.args[0])


def _is_numeric_sequence(node: ast.AST) -> bool:
    if not isinstance(node, (ast.List, ast.Tuple)):
        return False
    if len(node.elts) not in {2, 3}:
        return False
    return all(_literal_number(item) is not None for item in node.elts)


def _theme_semantic_token_override_issues(source: str) -> list[GeneratedCodeQualityIssue]:
    """Scene-local semantic color token overrides break the routed theme profile."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    issues: list[GeneratedCodeQualityIssue] = []
    seen: set[tuple[str, int]] = set()

    class Visitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.function_depth = 0

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.function_depth += 1
            self.generic_visit(node)
            self.function_depth -= 1

        def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
            self.function_depth += 1
            self.generic_visit(node)
            self.function_depth -= 1

        def visit_Assign(self, node: ast.Assign) -> None:
            self._check_assignment(node.targets, node.value, node)
            self.generic_visit(node)

        def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
            if node.value is not None:
                self._check_assignment([node.target], node.value, node)
            self.generic_visit(node)

        def _check_assignment(
            self,
            targets: list[ast.AST],
            value: ast.AST,
            node: ast.AST,
        ) -> None:
            if self.function_depth <= 0:
                return
            color_constant = _raw_color_constant_name(value)
            if not color_constant:
                return
            for target in targets:
                token_name = _semantic_color_token_name(target)
                if not token_name:
                    continue
                line = getattr(node, "lineno", 1)
                evidence = _line_text(source, line).strip()
                key = (evidence, line)
                if key in seen:
                    continue
                seen.add(key)
                issues.append(
                    GeneratedCodeQualityIssue(
                        code="theme_semantic_token_override",
                        severity="error",
                        message=(
                            f"{token_name} 在函数/Scene 内被覆盖为 {color_constant}；"
                            "首轮生成应使用 router 选择的主题语义 token，不要局部改写主题。"
                        ),
                        line=line,
                        evidence=evidence,
                        failure_code="theme_semantic_token_override",
                    )
                )

    Visitor().visit(tree)
    return issues


def _raw_color_constant_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name) and node.id in _RAW_MANIM_COLOR_CONSTANTS:
        return node.id
    if (
        isinstance(node, ast.Attribute)
        and node.attr in _RAW_MANIM_COLOR_CONSTANTS
    ):
        return node.attr
    return ""


def _semantic_color_token_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name) and node.id in _SEMANTIC_COLOR_TOKEN_NAMES:
        return node.id
    if isinstance(node, ast.Attribute) and node.attr in _SEMANTIC_COLOR_TOKEN_NAMES:
        return node.attr
    return ""


