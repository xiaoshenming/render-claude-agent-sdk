"""公式边界分段辅助。"""
import re

def dollar_formula_boundary_segments(text: str, normalize) -> list[tuple[str, str]]:
    if "$" not in text:
        return []
    parts = str(text or "").split("$")
    if len(parts) < 3 or len(parts) % 2 == 0:
        return []
    segments = []
    for index, part in enumerate(parts):
        value = part.strip()
        if not value:
            continue
        if index % 2:
            math = normalize(value)
            if not math:
                return []
            segments.append(("math", math))
        else:
            segments.append(("text", value))
    return segments

def split_leading_cjk_prose_from_latex_math(value: str, normalize, latex_tokens: tuple[str, ...]) -> list[tuple[str, str]]:
    raw = str(value or "").strip()
    if not raw or not re.search(r"[\u4e00-\u9fff]", raw):
        return []
    match = re.search(r"\\[A-Za-z]+", raw)
    if not match or match.start() <= 0:
        return []
    prefix, math_raw = raw[:match.start()].strip(), raw[match.start():].strip()
    if not prefix or not math_raw or not any(token in math_raw for token in latex_tokens):
        return []
    math = normalize(math_raw)
    return [("text", prefix), ("math", math)] if math else []

def trim_inline_math_span(text: str, start: int, end: int, trailing_re) -> tuple[int, int] | None:
    while start < end and text[start] in {" ", "\t", "\u3000", "(", "["}: start += 1
    while end > start:
        match = trailing_re.search(text, start, end)
        if match is None or match.end() != end: break
        if ")" in match.group(0) and "(" in text[start:match.start()]: break
        end = match.start()
    return (start, end) if end > start else None

def strip_unanchored_cjk(text: str, start: int, end: int, comp_start: int, comp_end: int, symbolic) -> tuple[int, int]:
    if not symbolic(text, start, end): return start, end
    while start < comp_start and "\u4e00" <= text[start] <= "\u9fff":
        start += 1
        while start < comp_start and text[start] == " ": start += 1
    while end > comp_end and "\u4e00" <= text[end - 1] <= "\u9fff":
        end -= 1
        while end > comp_end and text[end - 1] == " ": end -= 1
    return start, end
