"""Shared AST checks for formula-like payloads in plain text helpers."""

from __future__ import annotations

import ast

from app.workers.validation.formula_text_constants import *
from app.workers.validation.formula_text_ast_utils import (
    _parent_map, _call_can_use_self_inline_helper, _module_defines_inline_math_text,
    _node_span, _byte_col_to_char_col, _stringish_constant, _call_name,
)
from app.workers.validation.formula_text_boundary_checks import (
    dollar_formula_boundary_segments,
    split_leading_cjk_prose_from_latex_math, trim_inline_math_span, strip_unanchored_cjk,
)
from app.workers.validation.formula_text_normalization import normalize_formula_text_payload
from app.workers.validation.formula_text_operand_checks import (
    is_ascii_operand, is_symbolic_operand, is_cjk_operand, is_operand_atom,
)
from app.workers.validation.formula_text_operand_constants import (
    _FORMULA_OPERAND_CHARS, _FORMULA_COMPARATOR, _COMPARATOR_RE,
    _OPERAND_INNER_CHARS, _LATEX_COMMAND_RE,
)
from app.workers.validation.formula_text_operand_expansion import (
    expand_left,
    expand_right,
)
from app.workers.validation.formula_text_ast_helpers import safe_unparse, is_str_call, expr_names, payload_is_indexed_value, call_uses_formula_color, dynamic_expression_source, first_text_payload, first_text_payload_node, looks_like_dynamic_formula_payload, first_dynamic_formula_payload
from app.workers.validation.formula_text_cjk_checks import is_cjk_symbolic_formula, is_pure_formula_payload
from app.workers.validation.formula_text_mathtex_helpers import mathtex_call_source, dynamic_mathtex_call_source, inline_vgroup_call_source, inline_math_text_call_source
from app.workers.validation.formula_text_payload_helpers import (
    expression_names as _expr_names,
    first_payload as _first_text_payload,
    first_payload_node as _first_text_payload_node,
    is_indexed_payload as _payload_is_indexed_value,
)
from app.workers.validation.formula_text_latex_spans import collect_latex_command_spans
from app.workers.validation.formula_text_patterns import formula_match_patterns
from dataclasses import dataclass
import re




def _first_dynamic_formula_payload(call: ast.Call, source: str) -> str | None:
    return first_dynamic_formula_payload(
        call, source, _first_text_payload_node, _stringish_constant,
        _safe_unparse, _looks_like_dynamic_formula_payload,
    )

def _looks_like_dynamic_formula_payload(
    call: ast.Call,
    payload_node: ast.AST,
    expr_source: str,
    source: str,
) -> bool:
    return looks_like_dynamic_formula_payload(
        call, payload_node, expr_source, source, _DYNAMIC_FORMULA_SOURCE_RE,
        _DYNAMIC_FORMULA_NAME_RE, _expr_names, _payload_is_indexed_value,
        _call_uses_formula_color,
    )

def _call_uses_formula_color(call: ast.Call, source: str) -> bool:
    return call_uses_formula_color(call, source, _FORMULA_COLOR_SOURCE_RE)

def _safe_unparse(node: ast.AST) -> str:
    return safe_unparse(node)

def _is_pure_formula_payload(text: str) -> bool:
    return is_pure_formula_payload(text, looks_like_formula_text)

def _is_cjk_symbolic_formula(text: str) -> bool:
    return is_cjk_symbolic_formula(text)

def _mathtex_call_source(code: str, call: ast.Call, payload: str) -> str:
    return mathtex_call_source(
        code, call, _normalize_inline_math_segment(_normalize_formula_text_payload(payload)),
        lambda value: value, MATHTEX_SAFE_KEYWORDS,
    )

def _dynamic_mathtex_call_source(
    code: str,
    call: ast.Call,
    parent_map: dict[ast.AST, ast.AST] | None = None,
) -> str:
    return dynamic_mathtex_call_source(code, call, parent_map, {
        "first_payload": _first_text_payload_node,
        "stringish": _stringish_constant,
        "unparse": _safe_unparse,
        "looks_dynamic": _looks_like_dynamic_formula_payload,
        "repairable": _dynamic_formula_payload_is_auto_repairable,
        "enclosing": _enclosing_function_name,
        "expression": _dynamic_formula_expression_source,
    }, MATHTEX_SAFE_KEYWORDS)

def _dynamic_formula_payload_is_auto_repairable(
    call: ast.Call,
    payload_node: ast.AST,
    expr_source: str,
    source: str,
    parent_function_name: str = "",
) -> bool:
    if _DYNAMIC_FORMULA_NAME_RE.search(parent_function_name or ""):
        return True
    if (
        parent_function_name in {"safe_text_box", "inline_math_text"}
        and "str(part)" in expr_source
        and ".replace(" in expr_source
    ):
        return True
    if _payload_is_indexed_value(_strip_cosmetic_text_replace_chain(payload_node)):
        return True
    if _dynamic_text_payload_is_sanitized_math_label(payload_node, expr_source):
        return True
    if (
        '.replace(r"\\text{", "")' in expr_source
        or ".replace(r'\\text{', '')" in expr_source
        or '.replace(r"\\mathrm{", "")' in expr_source
        or ".replace(r'\\mathrm{', '')" in expr_source
    ):
        return False
    if _call_uses_formula_color(call, source):
        return True
    # Do not undo the pre-render fallback that downgrades MathTex(dynamic CJK
    # string) to Text(str(...).replace(r"\text{", "")...). That path is for
    # runtime prose/CJK content that cannot be statically proven LaTeX-safe.
    if (
        _DYNAMIC_FORMULA_SOURCE_RE.search(expr_source)
        and r"\text{" not in expr_source
        and r"\\text{" not in expr_source
        and r"\mathrm{" not in expr_source
        and r"\\mathrm{" not in expr_source
    ):
        return True
    return False

def _enclosing_function_name(
    node: ast.AST,
    parent_map: dict[ast.AST, ast.AST],
) -> str:
    current = node
    while current in parent_map:
        current = parent_map[current]
        if isinstance(current, (ast.FunctionDef, ast.AsyncFunctionDef)):
            return current.name
        if isinstance(current, ast.Module):
            return ""
    return ""

def _dynamic_text_payload_is_sanitized_math_label(
    payload_node: ast.AST,
    expr_source: str,
) -> bool:
    """Allow safe axis/tick labels that convert simple TeX marks to plain glyphs."""

    source = str(expr_source or "")
    if ".replace(" not in source:
        return False
    base = _strip_cosmetic_text_replace_chain(payload_node)
    allowed_names = {"formula", "label", "tex"}
    if not _payload_is_indexed_value(base) and not (
        set(_expr_names(base)) & allowed_names
    ):
        return False
    visible_math_replacements = (
        r"\circ",
        r"\times",
        r"\cdot",
        r"\le",
        r"\ge",
        r"\lt",
        r"\gt",
    )
    return any(marker in source for marker in visible_math_replacements)

def _dynamic_formula_expression_source(code: str, node: ast.AST) -> str:
    return dynamic_expression_source(code, node, _safe_unparse, _is_str_call)

def _strip_cosmetic_text_replace_chain(node: ast.AST) -> ast.AST:
    from app.workers.validation.formula_text_ast_helpers import strip_replace_chain
    return strip_replace_chain(node)

def _is_str_call(node: ast.AST) -> bool:
    return is_str_call(node)

def _inline_math_text_call_source(
    code: str,
    call: ast.Call,
    payload: str,
    *,
    use_inline_helper: bool,
) -> str:
    return inline_math_text_call_source(
        code, call, payload, use_inline_helper,
        _high_confidence_formula_boundary_segments, _inline_vgroup_call_source,
    )

def _inline_vgroup_call_source(
    code: str,
    call: ast.Call,
    segments: list[tuple[str, str]],
) -> str:
    return inline_vgroup_call_source(code, call, segments, INLINE_TEXT_SAFE_KEYWORDS)
