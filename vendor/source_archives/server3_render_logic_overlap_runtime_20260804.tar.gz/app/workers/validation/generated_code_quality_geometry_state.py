import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _stale_geometry_points_after_transform_line_in_block(
    source: str, line_offset: int
) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    visual_sources_by_var: dict[str, set[str]] = {}
    transformed_sources: dict[str, int] = {}
    nodes = sorted(
        ast.walk(tree),
        key=lambda node: (
            getattr(node, "lineno", 10**9),
            getattr(node, "col_offset", 0),
        ),
    )
    for node in nodes:
        if isinstance(node, ast.Assign):
            sources = _visual_geometry_source_names(node.value, visual_sources_by_var)
            for target in node.targets:
                if not isinstance(target, ast.Name):
                    continue
                if sources:
                    visual_sources_by_var[target.id] = set(sources)
                else:
                    visual_sources_by_var.pop(target.id, None)
            if sources and _expr_has_geometry_transform_call(node.value):
                _record_transformed_sources(
                    transformed_sources,
                    sources,
                    line_offset + getattr(node, "lineno", 0),
                )
            continue

        if not isinstance(node, ast.Call):
            continue

        target_var = _geometry_transform_target_var(node)
        if target_var and target_var in visual_sources_by_var:
            _record_transformed_sources(
                transformed_sources,
                visual_sources_by_var[target_var],
                line_offset + getattr(node, "lineno", 0),
            )
            continue

        used_sources = _raw_geometry_point_source_names(node)
        if (
            used_sources
            and used_sources.intersection(transformed_sources)
            and _is_label_or_angle_position_call(node)
        ):
            return line_offset + getattr(node, "lineno", 0)
    return 0


def _record_transformed_sources(
    transformed_sources: dict[str, int], sources: set[str], line_no: int
) -> None:
    for source in sources:
        if source not in transformed_sources:
            transformed_sources[source] = line_no


def _visual_geometry_source_names(
    node: ast.AST,
    visual_sources_by_var: dict[str, set[str]],
) -> set[str]:
    root_name = _call_chain_root_name(node)
    if root_name not in _VISUAL_CONSTRUCTOR_NAMES:
        return set()

    sources = _raw_geometry_point_source_names(node)
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            sources.update(visual_sources_by_var.get(child.id, set()))
    return sources


def _expr_has_geometry_transform_call(node: ast.AST) -> bool:
    return any(
        isinstance(child, ast.Call)
        and isinstance(child.func, ast.Attribute)
        and child.func.attr in _GEOMETRY_TRANSFORM_METHODS
        for child in ast.walk(node)
    )


def _geometry_transform_target_var(node: ast.Call) -> str | None:
    if not (
        isinstance(node.func, ast.Attribute)
        and node.func.attr in _GEOMETRY_TRANSFORM_METHODS
    ):
        return None
    target = node.func.value
    if isinstance(target, ast.Name):
        return target.id
    if (
        isinstance(target, ast.Attribute)
        and target.attr == "animate"
        and isinstance(target.value, ast.Name)
    ):
        return target.value.id
    return None


def _raw_geometry_point_source_names(node: ast.AST) -> set[str]:
    sources: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Subscript):
            base_name = _subscript_base_name(child.value)
            if base_name and _is_raw_geometry_points_name(base_name):
                sources.add(base_name)
        if (
            isinstance(child, ast.Starred)
            and isinstance(child.value, ast.Name)
            and _is_raw_geometry_points_name(child.value.id)
        ):
            sources.add(child.value.id)
    return sources


def _subscript_base_name(node: ast.AST) -> str:
    while isinstance(node, ast.Subscript):
        node = node.value
    if isinstance(node, ast.Name):
        return node.id
    return ""


def _is_raw_geometry_points_name(name: str) -> bool:
    return name in {"points", "vertices"} or name.endswith(("_points", "_vertices"))


def _is_label_or_angle_position_call(node: ast.Call) -> bool:
    return _call_chain_root_name(node) in _LABEL_OR_ANGLE_CONSTRUCTOR_NAMES


