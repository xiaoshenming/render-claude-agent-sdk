import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _clear_screen_flicker_issue(
    source: str,
    *,
    enable_tts: bool | None,
) -> GeneratedCodeQualityIssue | None:
    direct_patterns = [
        (r"\bself\.clear\s*\(", "self.clear()"),
        (r"\bself\.remove\s*\(\s*\*self\.mobjects\s*\)", "self.remove(*self.mobjects)"),
        (r"FadeOut\s*\(\s*\*self\.mobjects\s*\)", "FadeOut(*self.mobjects)"),
        (
            r"FadeOut\s*\(\s*VGroup\s*\(\s*\*self\.mobjects\s*\)\s*\)",
            "FadeOut(VGroup(*self.mobjects))",
        ),
        (
            r"\*\s*\[\s*FadeOut\s*\([^]]+\)\s+for\s+\w+\s+in\s+"
            r"(?:all_items|all_objects|all_mobjects|all_graphs|all_visuals|fade_objects)\s*\]",
            "*[FadeOut(...) for ... in all_items]",
        ),
    ]
    for pattern, evidence in direct_patterns:
        line_no = _line_matching(source, pattern)
        if line_no:
            return GeneratedCodeQualityIssue(
                code="clear_screen_flicker",
                severity="error",
                message="代码清空或遮挡全场，容易在单个切片内产生闪屏；保留主图，用局部 Transform/ReplacementTransform/Indicate 推进。",
                line=line_no,
                evidence=evidence,
            )

    if not (enable_tts or "self.voiceover(" in source):
        return None

    overlay_vars = _full_screen_overlay_vars(source)
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_self_method_call(node, "play"):
            continue
        segment = ast.get_source_segment(source, node) or ""
        fadeout_targets = _fadeout_target_names(segment)
        if any(target in overlay_vars for target in _fadein_target_names(segment)):
            return _clear_screen_issue_at(node, "FadeIn(full-screen overlay)")
        for target in fadeout_targets:
            if target in {"self.mobjects", "*self.mobjects"}:
                return _clear_screen_issue_at(node, "FadeOut(*self.mobjects)")
            if not _is_clear_screen_target(target):
                continue
            if _REVEAL_ANIMATION_RE.search(segment) or _is_definitely_whole_scene_target(target):
                return _clear_screen_issue_at(node, f"FadeOut({target})")
    return None


def _clear_screen_issue_at(node: ast.AST, evidence: str) -> GeneratedCodeQualityIssue:
    return GeneratedCodeQualityIssue(
        code="clear_screen_flicker",
        severity="error",
        message="代码全场淡出后重建，容易在单个切片内产生闪屏；主几何图应持续存在，只替换局部文字、公式或辅助线。",
        line=getattr(node, "lineno", 0) or 1,
        evidence=evidence,
    )


def _is_self_method_call(node: ast.Call, method: str) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == method
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    )


def _fadeout_target_names(segment: str) -> list[str]:
    return _animation_target_names(segment, "FadeOut")


def _fadein_target_names(segment: str) -> list[str]:
    return _animation_target_names(segment, "FadeIn")


def _animation_target_names(segment: str, animation: str) -> list[str]:
    targets: list[str] = []
    for match in re.finditer(
        rf"{animation}\s*\(\s*(?:VGroup\s*\(\s*)?"
        r"(?P<target>\*?self\.mobjects|[A-Za-z_][A-Za-z0-9_]*)\b",
        segment,
    ):
        targets.append(match.group("target").lstrip("*"))
    return targets


def _is_clear_screen_target(target: str) -> bool:
    return bool(_CLEAR_SCREEN_TARGET_RE.search(target))


def _is_definitely_whole_scene_target(target: str) -> bool:
    return bool(
        re.match(
            r"^(?:all|whole|full|screen|scene|canvas|content|diagram|graph|"
            r"visual|geometry|figure|construction)",
            target,
        )
        or target in {"graph", "diagram", "visual", "figure", "blackout"}
    )


def _full_screen_overlay_vars(source: str) -> set[str]:
    overlay_vars: set[str] = set()
    for match in re.finditer(
        r"(?ms)^\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*Rectangle\s*\((?P<body>.*?)\)",
        source,
    ):
        var = match.group("var")
        body = match.group("body")
        if (
            _is_clear_screen_target(var)
            or (
                "config.frame_width" in body
                and "config.frame_height" in body
                and re.search(r"fill_opacity\s*=\s*(?:1(?:\.0+)?|0\.9[5-9])", body)
            )
        ):
            overlay_vars.add(var)
    return overlay_vars


