"""Final grouped checks for generated-code quality inspection."""

from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue
from app.workers.validation.generated_code_quality_helpers import (
    _append_circle_prism_issues,
    _append_geometry_sequence_issues,
    _append_portrait_layout_issues,
    _voiceover_timing_contract_issues,
    _clear_screen_flicker_issue,
    _append_stale_geometry_issue,
    _append_registry_quality_issues,
    _append_dense_and_3d_issues,
)
from app.workers.validation.generated_code_quality_registry import _assigned_text_assignments


def _run_tail_quality_checks(source, issues, *, enable_tts=None, is_3d=None,
                             text_vars=None, registered_3d_text_var_positions=None):
    """Run grouped geometry, voiceover, and final registry checks."""
    _append_circle_prism_issues(source, issues)
    _append_geometry_sequence_issues(source, issues)
    _append_portrait_layout_issues(source, issues)
    if enable_tts or "self.voiceover(" in source:
        issues.extend(_voiceover_timing_contract_issues(source))
    clear_screen_issue = _clear_screen_flicker_issue(source, enable_tts=enable_tts)
    if clear_screen_issue:
        issues.append(clear_screen_issue)
    _append_stale_geometry_issue(source, issues)
    _append_registry_quality_issues(source, issues)
    _append_dense_and_3d_issues(
        source, issues, is_3d=is_3d, text_vars=text_vars,
        registered_3d_text_var_positions=registered_3d_text_var_positions,
        text_assignments=_assigned_text_assignments(source),
    )
    return issues
