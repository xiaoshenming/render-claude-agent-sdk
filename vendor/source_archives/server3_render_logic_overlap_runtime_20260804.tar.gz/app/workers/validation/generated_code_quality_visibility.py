import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _place_non_overlapping_without_others_line(source: str) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    for node in ast.walk(tree):
        if (
            not isinstance(node, ast.Call)
            or _call_name(node.func) != "place_non_overlapping"
        ):
            continue
        others_keyword = next(
            (keyword for keyword in node.keywords if keyword.arg == "others"),
            None,
        )
        if others_keyword is not None:
            if _is_none_or_empty_sequence(others_keyword.value):
                return getattr(node, "lineno", 0)
            continue
        if len(node.args) < 3 or _is_none_or_empty_sequence(node.args[2]):
            return getattr(node, "lineno", 0)
    return 0


def _is_none_or_empty_sequence(node: ast.AST) -> bool:
    if isinstance(node, ast.Constant) and node.value is None:
        return True
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)) and not node.elts:
        return True
    return (
        isinstance(node, ast.Call)
        and _call_name(node.func) in {"list", "tuple", "set"}
        and not node.args
        and not node.keywords
    )


def _text_added_without_visible_registry_line(source: str) -> int:
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    for block, line_offset in blocks:
        if _has_visible_object_registry_lifecycle(block):
            continue
        line = _text_added_without_visible_registry_line_in_block(block, line_offset)
        if line:
            return line
    return 0


def _dense_direct_positioning_without_registry_line(source: str) -> int:
    blocks = _scene_blocks(source) or _construct_blocks(source) or [(source, 0)]
    for block, line_offset in blocks:
        construct_blocks = _construct_blocks(block) or [(block, 0)]
        for construct_block, construct_offset in construct_blocks:
            effective_offset = line_offset + construct_offset
            if _has_visible_object_registry_lifecycle(construct_block):
                continue
            line = _dense_direct_positioning_without_registry_line_in_block(
                construct_block,
                effective_offset,
            )
            if line:
                return line
    return 0


def _dense_direct_positioning_without_registry_line_in_block(
    source: str, line_offset: int
) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    text_object_count = 0
    has_visual_object = False
    positioning_lines: list[int] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        call_name = _call_name(node.func)
        root_name = _call_chain_root_name(node)
        if call_name in _DIRECT_POSITIONING_METHODS:
            positioning_lines.append(line_offset + getattr(node, "lineno", 0))
        if root_name in (_TEXT_CONSTRUCTOR_NAMES | _LABEL_OR_ANGLE_CONSTRUCTOR_NAMES):
            text_object_count += 1
        if root_name in _VISUAL_CONSTRUCTOR_NAMES:
            has_visual_object = True

    if (
        has_visual_object
        and text_object_count >= _DENSE_TEXT_OBJECT_THRESHOLD
        and len(positioning_lines) >= _DENSE_DIRECT_POSITIONING_THRESHOLD
    ):
        positioning_lines.sort()
        return positioning_lines[_DENSE_DIRECT_POSITIONING_THRESHOLD - 1]
    return 0


def _has_visible_object_registry_lifecycle(source: str) -> bool:
    return bool(
        re.search(
            r"\b(?:visible_objects|visible_mobjects|shown_objects|active_objects|"
            r"displayed_objects|current_visible_objects|visible_registry|"
            r"object_registry)\s*\.\s*(?:append|extend|remove|clear|add|discard|pop)\s*\(",
            source,
        )
    )


def _text_added_without_visible_registry_line_in_block(
    source: str, line_offset: int
) -> int:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0

    text_vars = set(_assigned_text_vars(source))
    events: list[tuple[int, set[str], set[str]]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        shown, removed = _text_visibility_delta_for_scene_call(
            node, text_vars, line_offset,
        )
        if shown:
            events.append((line_offset + getattr(node, "lineno", 0), shown, removed))

    events.sort(key=lambda item: item[0])
    active_texts: set[str] = set()
    seen_lines: set[int] = set()
    for line_no, shown, removed in events:
        active_texts.difference_update(removed)
        active_texts.update(shown)
        seen_lines.add(line_no)
        if len(seen_lines) >= 2 and len(active_texts) >= 2:
            return line_no
    return 0


def _text_visibility_delta_for_scene_call(
    node: ast.Call, text_vars: set[str], line_offset: int
) -> tuple[set[str], set[str]]:
    if _is_self_method_call(node, "add"):
        return _text_targets_in_nodes(node.args, text_vars, line_offset), set()

    if not _is_self_method_call(node, "play"):
        return set(), set()

    shown: set[str] = set()
    removed: set[str] = set()
    for animation in node.args:
        if not isinstance(animation, ast.Call):
            continue
        name = _call_name(animation.func)
        if name in _REMOVE_TEXT_ANIMATION_NAMES:
            removed.update(_text_targets_in_nodes(animation.args, text_vars, line_offset))
        elif name in _REPLACE_TEXT_ANIMATION_NAMES and len(animation.args) >= 2:
            removed.update(_text_targets_in_nodes(animation.args[:1], text_vars, line_offset))
            shown.update(_text_targets_in_nodes(animation.args[1:2], text_vars, line_offset))
        elif name == "TransformFromCopy" and len(animation.args) >= 2:
            shown.update(_text_targets_in_nodes(animation.args[1:2], text_vars, line_offset))
        elif name in _REVEAL_TEXT_ANIMATION_NAMES:
            shown.update(_text_targets_in_nodes(animation.args, text_vars, line_offset))
    return shown, removed


def _text_targets_in_nodes(
    nodes: list[ast.AST], text_vars: set[str], line_offset: int
) -> set[str]:
    targets: set[str] = set()
    for node in nodes:
        targets.update(_text_targets_in_node(node, text_vars, line_offset))
    return targets


def _text_targets_in_node(
    node: ast.AST, text_vars: set[str], line_offset: int
) -> set[str]:
    targets: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and child.id in text_vars:
            targets.add(child.id)
        if isinstance(child, ast.Call) and _is_text_constructor_or_safe_text_call(child):
            targets.add(f"<inline:{line_offset + getattr(child, 'lineno', 0)}>")
    return targets


def _is_text_constructor_or_safe_text_call(node: ast.Call) -> bool:
    func_name = _call_name(node.func)
    if func_name in _TEXT_CONSTRUCTOR_NAMES:
        return True
    return (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and node.func.attr in _SAFE_TEXT_METHOD_NAMES
    )


