import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _is_tracker_method_call(node: ast.Call, tracker_name: str, method: str) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == method
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == tracker_name
    )


def _is_full_timeline_helper_call(node: ast.Call, tracker_name: str) -> bool:
    if not (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    ):
        return False

    if node.func.attr == "play_steps_evenly":
        return any(_is_name(arg, tracker_name) for arg in node.args) or any(
            _is_name(keyword.value, tracker_name) for keyword in node.keywords
        )
    if node.func.attr == "play_synced_steps":
        return bool(node.args and _is_name(node.args[0], tracker_name))
    return False


def _is_empty_full_timeline_helper_call(node: ast.Call, tracker_name: str) -> bool:
    if not (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
    ):
        return False

    if node.func.attr == "play_steps_evenly":
        return (
            bool(node.args)
            and _is_empty_sequence_literal(node.args[0])
            and _is_full_timeline_helper_call(node, tracker_name)
        ) or any(
            keyword.arg == "steps" and _is_empty_sequence_literal(keyword.value)
            for keyword in node.keywords
        )
    if node.func.attr == "play_synced_steps":
        return (
            len(node.args) >= 2
            and _is_name(node.args[0], tracker_name)
            and _is_empty_sequence_literal(node.args[1])
        ) or any(
            keyword.arg == "steps" and _is_empty_sequence_literal(keyword.value)
            for keyword in node.keywords
        )
    return False


def _is_empty_sequence_literal(node: ast.AST) -> bool:
    return isinstance(node, (ast.List, ast.Tuple)) and len(node.elts) == 0


def _call_uses_tracker_duration_as_run_time(
    node: ast.Call,
    tracker_name: str,
) -> bool:
    return any(
        keyword.arg == "run_time"
        and _is_tracker_duration_attr(keyword.value, tracker_name)
        for keyword in node.keywords
    )


def _is_self_wait_like_call(node: ast.Call) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and "wait" in node.func.attr
        and node.func.attr != "wait_until_bookmark"
    )


def _is_self_raw_play_call(node: ast.Call) -> bool:
    return (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "self"
        and node.func.attr == "play"
    )


def _numeric_self_wait_seconds(node: ast.Call) -> float | None:
    if not _is_self_wait_like_call(node) or not node.args:
        return None
    value = node.args[0]
    if isinstance(value, ast.Constant) and isinstance(value.value, (int, float)):
        return float(value.value)
    if (
        isinstance(value, ast.UnaryOp)
        and isinstance(value.op, ast.USub)
        and isinstance(value.operand, ast.Constant)
        and isinstance(value.operand.value, (int, float))
    ):
        return -float(value.operand.value)
    return None


def _call_waits_for_tracker_remainder(node: ast.Call, tracker_name: str) -> bool:
    return any(
        _contains_tracker_duration_subtraction(arg, tracker_name)
        for arg in [*node.args, *(keyword.value for keyword in node.keywords)]
    )


def _call_waits_for_full_tracker_duration(node: ast.Call, tracker_name: str) -> bool:
    return any(_is_full_tracker_duration_wait_arg(arg, tracker_name) for arg in node.args)


def _is_full_tracker_duration_wait_arg(node: ast.AST, tracker_name: str) -> bool:
    if _is_tracker_duration_attr(node, tracker_name):
        return True
    if _contains_tracker_duration_subtraction(node, tracker_name):
        return False
    return (
        isinstance(node, ast.Call)
        and _call_name(node.func) == "max"
        and any(_is_tracker_duration_attr(arg, tracker_name) for arg in node.args)
    )


def _contains_tracker_duration_subtraction(node: ast.AST, tracker_name: str) -> bool:
    for child in ast.walk(node):
        if (
            isinstance(child, ast.BinOp)
            and isinstance(child.op, ast.Sub)
            and _contains_tracker_duration(child, tracker_name)
        ):
            return True
    return False


def _contains_tracker_duration(node: ast.AST, tracker_name: str) -> bool:
    return any(
        _is_tracker_duration_attr(child, tracker_name)
        for child in ast.walk(node)
    )


def _is_tracker_duration_attr(node: ast.AST, tracker_name: str) -> bool:
    return (
        isinstance(node, ast.Attribute)
        and node.attr == "duration"
        and isinstance(node.value, ast.Name)
        and node.value.id == tracker_name
    )


