"""Compatibility facade for evidence-only quality repair classification."""
# ruff: noqa: F401  # Preserve historical private helpers and constants.

from .quality_repair_contracts import (
    DEGRADED,
    FAILED,
    LAYOUT_REPAIR,
    MATH_LOGIC_REPAIR,
    NEEDS_REPAIR,
    PASS,
    RENDER_REPAIR,
    _GRADE_RANK,
    _LAYOUT_ERROR_CODES,
    _LAYOUT_RISK_CODES,
    _MATH_HARD_ERROR_CODES,
    _RENDER_FAILURE_CODES,
    QualityRepairClassification,
    RepairGrade,
    RepairLane,
    RepairOutcome,
)
from .quality_repair_decisions import (
    _classify_layout_issue,
    _classify_math_logic_issue,
    _classify_render_issue,
    _classify_single_issue,
    _is_high_severity,
    _is_medium_or_high_severity,
    _is_pass_marker,
    _layout_error_is_severe,
    _repairable,
    classify_quality_issue,
)
from .quality_repair_evidence import (
    _float,
    _is_issue_mapping,
    _issue_to_dict,
    _looks_like_issue_object,
    _normalize_issues,
    _normalize_lane,
    _reason_for_issue,
    _text,
    _truthy,
)

__all__ = [
    "DEGRADED",
    "FAILED",
    "LAYOUT_REPAIR",
    "MATH_LOGIC_REPAIR",
    "NEEDS_REPAIR",
    "PASS",
    "RENDER_REPAIR",
    "QualityRepairClassification",
    "RepairGrade",
    "RepairLane",
    "RepairOutcome",
    "classify_quality_issue",
]
