"""Static quality checks for generated Manim code.

These checks catch prompt-contract violations that are visible in code before
rendering. They are deliberately conservative and complement, not replace, the
frame-based layout validator.
"""
from dataclasses import dataclass
import ast
from collections.abc import Iterable
import math
import re
import textwrap

from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue
from app.workers.validation.generated_code_quality_entry import blocking_static_contract_codes
from app.workers.validation.generated_code_quality_misc import *
from app.workers.validation.generated_code_quality_pythagorean_semantic import (
    _pythagorean_three_square_semantic_issues, _pythagorean_three_square_semantic_issues_in_block,
)
from app.workers.validation.generated_code_quality_right_triangle import (
    _right_triangle_side_label_anchor_line, _right_triangle_side_label_anchor_line_in_block,
    _right_triangle_side_label_anchor_line_regex, _ambiguous_right_angle_helper_line,
    _right_triangle_numeric_side_label_mismatch_issues, _right_triangle_numeric_side_label_mismatch_issues_in_block,
)
from app.workers.validation.generated_code_quality_reveal import (
    _bulk_pre_reveal_add_line, _bulk_pre_reveal_add_line_in_block,
    _pre_reveal_visible_object_line, _pre_reveal_visible_object_line_in_block,
    _is_self_visible_registration_call, _direct_name_args, _reveal_targets_in_play_call,
)
from app.workers.validation.generated_code_quality_layout import (
    _next_to_alignment_misuse_line, _parametric_surface_misuse_line,
    _text_formula_tiny_scale_line, _first_numeric_arg, _is_pure_text_split_layout,
)
from app.workers.validation.generated_code_quality_3d_camera import (
    _fix_in_frame_method_misuse_line, _mathpi_3d_camera_animate_misuse_line,
    _mathpi_3d_camera_frame_misuse_line, _mathpi_3d_camera_set_euler_misuse_line,
    _prism_polygon_extrusion_misuse_line,
)
from app.workers.validation.generated_code_quality_ranges import _class_range, _method_range, _is_front_facing_3d_camera_line
from app.workers.validation.generated_code_quality_3d_contract import (
    _should_check_3d_text, _mathpi_3d_scene_contract_missing_line,
    _mathpi_3d_camera_contract_missing_line, _mathpi_3d_default_camera_oblique_line,
)
from app.workers.validation.generated_code_quality_registry import (
    _assigned_text_assignments, _registered_3d_text_var_positions, _record_earliest_pos,
    _expand_group_members, _vgroup_members,
)
from app.workers.validation.generated_code_quality_config import (
    _undefined_global_config_attribute, _undersized_2d_axes_line, _call_name,
    _literal_number, _global_config_defined_attrs, _global_config_body,
)
from app.workers.validation.generated_code_quality_clear_screen import (
    _clear_screen_flicker_issue, _clear_screen_issue_at, _is_self_method_call,
    _fadeout_target_names, _fadein_target_names, _animation_target_names,
    _is_clear_screen_target, _is_definitely_whole_scene_target, _full_screen_overlay_vars,
)
from app.workers.validation.generated_code_quality_tracker import (
    _is_tracker_method_call, _is_full_timeline_helper_call, _is_empty_full_timeline_helper_call,
    _is_empty_sequence_literal, _call_uses_tracker_duration_as_run_time, _is_self_wait_like_call,
    _is_self_raw_play_call, _numeric_self_wait_seconds, _call_waits_for_tracker_remainder,
    _call_waits_for_full_tracker_duration, _is_full_tracker_duration_wait_arg,
    _contains_tracker_duration_subtraction, _contains_tracker_duration, _is_tracker_duration_attr,
)
from app.workers.validation.generated_code_quality_portrait_helpers import (
    _call_keyword_number, _portrait_header_y_key, _portrait_multi_concept_crowding_line,
    _portrait_concept_tokens, _portrait_multi_concept_terminal_line,
)
from app.workers.validation.generated_code_quality_voice_extract import _voiceover_call_text
from app.workers.validation.generated_code_quality_timing import (
    _formula_passed_to_show_text_line, _legacy_text_slot_api_line,
    _voiceover_timing_contract_issues,
)
from app.workers.validation.generated_code_quality_visibility import (
    _place_non_overlapping_without_others_line, _is_none_or_empty_sequence,
    _text_added_without_visible_registry_line, _dense_direct_positioning_without_registry_line,
    _dense_direct_positioning_without_registry_line_in_block, _has_visible_object_registry_lifecycle,
    _text_added_without_visible_registry_line_in_block, _text_visibility_delta_for_scene_call,
    _text_targets_in_nodes, _text_targets_in_node, _is_text_constructor_or_safe_text_call,
)
from app.workers.validation.generated_code_quality_geometry_state import (
    _stale_geometry_points_after_transform_line_in_block, _record_transformed_sources,
    _visual_geometry_source_names, _expr_has_geometry_transform_call, _geometry_transform_target_var,
    _raw_geometry_point_source_names, _subscript_base_name, _is_raw_geometry_points_name,
    _is_label_or_angle_position_call,
)
from app.workers.validation.generated_code_quality_voice import (
    _python_tuple_text_artifact_issues, _first_arg_is_tuple_text_literal,
    _first_arg_is_str_part, _has_tuple_parts_contract_before, _call_evidence,
    _missing_voiceover_scene_import_line, _missing_required_voiceover_block_line,
    _is_self_short_voiceover_call, _first_scene_construct_line, _class_inherits_voiceover_scene,
    _is_portrait_source, _portrait_header_overlap_line, _portrait_header_overlap_line_in_block,
)
from app.workers.validation.generated_code_quality_actions import (
    raise_for_tts_timing_blockers, try_auto_fix_formula_violations,
    try_auto_fix_icon_text_box_fallbacks, raise_for_blocking_static_contracts,
    raise_for_blocking_static_contracts_with_auto_fix,
)
from app.workers.validation.generated_code_quality_triangle import _literal_triangle_vertices, _eval_vector_expr, _literal_vertices_form_right_triangle, _numeric_midpoint_side_labels
from app.workers.validation.generated_code_quality_pythagorean import (
    _has_pythagorean_three_square_context, _uses_trusted_pythagorean_square_helper,
    _pythagorean_block_mentions_square_visual, _pythagorean_block_has_valid_three_square_visual,
    _pythagorean_area_symbols, _pythagorean_square_records, _pythagorean_square_assignment_kind,
    _pythagorean_square_label_from_name, _detached_pythagorean_square_evidence,
    _pythagorean_square_anchor_mentions_edge, _pythagorean_square_label_center_issues,
    _pythagorean_area_label_from_assignment, _pythagorean_single_area_label,
    _assignment_moves_label_to_square_center,
)
from app.workers.validation.generated_code_quality_circle import (
    _circle_area_base_width_mismatch_line, _circle_area_annularsector_misuse_line,
    _format_float, _is_side_label_var, _is_single_vertex_direction_offset,
)
from app.workers.validation.generated_code_quality_geometry_math import (
    _single_target_assignment_for_value, _numeric_text_value_from_expr,
    _parse_numeric_side_label, _midpoint_vertex_pair, _vertex_sum_pair, _vertex_name,
    _side_label_scale_mismatch, _side_key, _distance, _vector_sub, _vector_dot,
    _vector_length,
)
from app.workers.validation.generated_code_quality_formula_utils import (
    _formula_move_to_assignments, _formula_move_to_assignments_regex,
    _call_chain_root_name, _normalize_expr, _formula_transition_segment,
    _formula_replaced_or_removed, _scene_blocks, _is_reassigned_before_direct_show,
    _direct_show_pos, _first_line, _line_matching, _line_no, _line_text,
)
from app.workers.validation.generated_code_quality_state_utils import (
    _prehidden_text_vars, _assigned_visual_vars, _prehidden_opacity_line,
    _prehidden_opacity_line_in_block, _is_rehydration_add, _construct_blocks,
    _same_center_formula_stack_line, _same_center_formula_stack_line_in_block,
)
from app.workers.validation.generated_code_quality_portrait import (
    _portrait_tiny_font_size_issues, _plain_text_prime_label_issues,
)
from app.workers.validation.generated_code_quality_icons import (
    _core_visual_semantic_icon_fallback_issues, _text_box_icon_fallback_issues,
    _core_text_helper_fallback_icon_issues, _forbidden_visible_fallback_icon_issues,
)
from app.workers.validation.generated_code_quality_theme import (
    _durable_panel_manual_coordinate_issues, _theme_semantic_token_override_issues,
)
from app.workers.validation.generated_code_quality_geometry import _geometry_dict_key_not_local_issues
from app.workers.validation.generated_code_quality_static import (
    _invented_helper_call_issues,
    _module_defined_or_imported_names,
    _helper_abi_mismatch_issues,
)
from app.workers.validation.generated_code_quality_manim_api import _manim_019_api_blacklist_issues, _append_manim_019_issue

from app.workers.validation.formula_text_contract import (
    inspect_formula_text_violations,
)


from app.workers.validation.generated_code_quality_constants import *
from app.workers.validation.generated_code_quality_helpers import *
from app.workers.validation.generated_code_quality_tail import _run_tail_quality_checks
from app.workers.validation.generated_code_quality_layout_checks import _append_layout_api_issues
from app.workers.validation.generated_code_quality_scale_checks import _append_scale_layout_issues
from app.workers.validation.generated_code_quality_reveal_checks import _append_reveal_layout_issues
from app.workers.validation.generated_code_quality_triangle_checks import _append_triangle_quality_issues
from app.workers.validation.generated_code_quality_formula_checks import _append_formula_quality_issues
from app.workers.validation.generated_code_quality_camera_checks import _append_camera_quality_issues
from app.workers.validation.generated_code_quality_contract_checks import _append_legacy_and_config_issues
from app.workers.validation.generated_code_quality_tts_checks import _append_tts_contract_issues

















def inspect_generated_code_quality(
    code: str,
    *,
    is_3d: bool | None = None,
    enable_tts: bool | None = None,
    is_portrait: bool | None = None,
    allowed_runtime_helpers: Iterable[str] | None = None,
) -> list[GeneratedCodeQualityIssue]:
    """Return high-confidence static quality issues in generated Manim code."""
    source = code or ""
    issues, text_vars, registered_3d_text_var_positions = _prepare_generated_code_quality(
        source, allowed_runtime_helpers=allowed_runtime_helpers
    )
    if not source.strip():
        return issues

    _append_icon_quality_issues(source, issues)
    issues.extend(_invented_helper_call_issues(source))
    issues.extend(_helper_abi_mismatch_issues(source))
    issues.extend(_manim_019_api_blacklist_issues(source))
    issues.extend(_geometry_dict_key_not_local_issues(source))
    issues.extend(_durable_panel_manual_coordinate_issues(source))
    issues.extend(_theme_semantic_token_override_issues(source))

    _append_default_color_issue(source, issues)
    _append_formula_show_issue(source, issues)

    _append_formula_quality_issues(source, issues)

    _append_gtts_voice_issue(source, issues)

    _append_tts_contract_issues(source, issues, enable_tts=enable_tts)

    _append_legacy_and_config_issues(source, issues)

    mathpi_3d_scene_line = _mathpi_3d_scene_contract_missing_line(
        source,
        is_3d=is_3d,
    )
    if mathpi_3d_scene_line:
        issues.append(
            GeneratedCodeQualityIssue(
                code="mathpi_3d_scene_contract_missing",
                severity="error",
                message=(
                    "MathPi-3D 任务生成了非 ThreeDScene 运行时，"
                    "等同于静默降级为 2D。"
                ),
                line=mathpi_3d_scene_line,
                evidence="class BaseConfigScene(... ThreeDScene ...)",
            )
        )

    _append_camera_quality_issues(source, issues, is_3d=is_3d)

    _append_layout_api_issues(source, issues)

    _append_scale_layout_issues(
        source, issues, text_vars=text_vars, is_3d=is_3d, is_portrait=is_portrait
    )

    _append_reveal_layout_issues(source, issues)

    _append_triangle_quality_issues(source, issues)

    return _run_tail_quality_checks(
        source, issues, enable_tts=enable_tts, is_3d=is_3d,
        text_vars=text_vars,
        registered_3d_text_var_positions=registered_3d_text_var_positions,
    )
