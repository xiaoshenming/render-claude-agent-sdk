import ast
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _prehidden_text_vars(prefix: str, text_vars: dict[str, int]) -> set[str]:
    hidden: set[str] = set()
    for match in re.finditer(
        r"(?m)^\s*(?P<target>[A-Za-z_][A-Za-z0-9_]*)"
        r"\.set_opacity\s*\(\s*0(?:\.0+)?\s*\)",
        prefix,
    ):
        target = match.group("target")
        if target in text_vars:
            hidden.add(target)
    return hidden


def _assigned_visual_vars(source: str) -> set[str]:
    return {match.group(1) for match in _VISUAL_ASSIGN_RE.finditer(source)}


def _prehidden_opacity_line(source: str) -> int:
    construct_blocks = _construct_blocks(source)
    if construct_blocks:
        for block, line_offset in construct_blocks:
            line = _prehidden_opacity_line_in_block(
                block,
                _assigned_text_vars(block),
                line_offset,
            )
            if line:
                return line
        return 0
    return _prehidden_opacity_line_in_block(source, _assigned_text_vars(source), 0)


def _prehidden_opacity_line_in_block(
    source: str, text_vars: dict[str, int], line_offset: int
) -> int:
    first_play_pos = source.find("self.play(")
    prefix = source if first_play_pos == -1 else source[:first_play_pos]
    for match in re.finditer(
        r"(?m)^\s*(?P<target>[A-Za-z_][A-Za-z0-9_]*(?:\s*\[[^\]]+\])?)"
        r"\.set_opacity\s*\(\s*0(?:\.0+)?\s*\)",
        prefix,
    ):
        target = match.group("target")
        base_name = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)", target).group(1)
        if base_name in text_vars or "label" in base_name.lower():
            return line_offset + _line_no(source, match.start())
    return 0


def _is_rehydration_add(source: str, add_pos: int) -> bool:
    preceding_lines = source[:add_pos].splitlines()[-24:]
    context = "\n".join(preceding_lines)
    if "self.restore_text(" in context or "self.restore_camera(" in context:
        return True
    return any(
        marker in context
        for marker in (
            "重建上一场景",
            "上一场景",
            "状态重构",
            "视觉衔接",
            "restore previous",
            "rehydration",
        )
    )


def _construct_blocks(source: str) -> list[tuple[str, int]]:
    matches = list(re.finditer(r"(?m)^(?P<indent>\s*)def\s+construct\s*\(\s*self\s*\)\s*:", source))
    blocks: list[tuple[str, int]] = []
    for match in matches:
        indent = re.escape(match.group("indent"))
        next_block = re.search(rf"(?m)^(?:{indent}def\s+|class\s+)", source[match.end():])
        end = match.end() + next_block.start() if next_block else len(source)
        blocks.append((
            textwrap.dedent(source[match.start():end]),
            _line_no(source, match.start()) - 1,
        ))
    return blocks


def _same_center_formula_stack_line(source: str) -> int:
    scene_blocks = _scene_blocks(source)
    if scene_blocks:
        for block, line_offset in scene_blocks:
            line = _same_center_formula_stack_line_in_block(block, line_offset)
            if line:
                return line
        return 0
    return _same_center_formula_stack_line_in_block(source, 0)


def _same_center_formula_stack_line_in_block(source: str, line_offset: int) -> int:
    formulas = _formula_move_to_assignments(source, line_offset)

    for index, (var, center, _line) in enumerate(formulas):
        show_pos = _direct_show_pos(source, var)
        if show_pos < 0:
            continue
        for later_var, later_center, later_line in formulas[index + 1:]:
            if later_center != center:
                continue
            later_show_pos = _direct_show_pos(source, later_var)
            if later_show_pos < 0:
                continue
            transition_segment = _formula_transition_segment(source, show_pos, later_show_pos)
            if _formula_replaced_or_removed(transition_segment, var, later_var):
                continue
            return later_line
    return 0


