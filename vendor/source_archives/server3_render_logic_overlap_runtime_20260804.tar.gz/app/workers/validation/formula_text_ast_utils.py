"""Low-level AST helpers for formula text analysis."""
from __future__ import annotations
import ast


def _parent_map(tree: ast.AST) -> dict[ast.AST, ast.AST]:
    return {child: parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}

def _call_can_use_self_inline_helper(node, parent_map):
    current = node
    while current in parent_map:
        current = parent_map[current]
        if isinstance(current, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = current.args.args
            return bool(args and args[0].arg == "self")
        if isinstance(current, ast.Module): return False
    return False

def _module_defines_inline_math_text(tree):
    return any(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "inline_math_text" for node in ast.walk(tree))

def _byte_col_to_char_col(line, byte_col):
    return len(line.encode("utf-8")[:byte_col].decode("utf-8"))

def _node_span(node, lines):
    vals = [getattr(node, x, None) for x in ("lineno", "col_offset", "end_lineno", "end_col_offset")]
    if not all(isinstance(v, int) for v in vals): return None, None
    lineno, col, end_lineno, end_col = vals
    if lineno < 1 or end_lineno < 1 or lineno > len(lines) or end_lineno > len(lines): return None, None
    start = sum(map(len, lines[:lineno - 1])) + _byte_col_to_char_col(lines[lineno - 1], col)
    end = sum(map(len, lines[:end_lineno - 1])) + _byte_col_to_char_col(lines[end_lineno - 1], end_col)
    return start, end

def _stringish_constant(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str): return node.value
    if isinstance(node, ast.JoinedStr):
        return "".join(value.value if isinstance(value, ast.Constant) and isinstance(value.value, str) else "{}" for value in node.values)
    return None

def _call_name(node):
    if isinstance(node, ast.Name): return node.id
    if isinstance(node, ast.Attribute):
        prefix = _call_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""
