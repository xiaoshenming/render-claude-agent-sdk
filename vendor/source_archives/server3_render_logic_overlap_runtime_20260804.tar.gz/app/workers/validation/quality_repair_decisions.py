"""Evidence-only quality classification decision helpers."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from .quality_repair_contracts import (
    _GRADE_RANK,
    _LAYOUT_ERROR_CODES,
    _LAYOUT_RISK_CODES,
    _MATH_HARD_ERROR_CODES,
    _RENDER_FAILURE_CODES,
    QualityRepairClassification,
    RepairGrade,
    RepairLane,
)
from .quality_repair_evidence import (
    _float,
    _normalize_issues,
    _normalize_lane,
    _reason_for_issue,
    _text,
    _truthy,
)

def classify_quality_issue(
    issue_or_issues: Mapping[str, Any] | Iterable[Mapping[str, Any]] | Any,
    lane: RepairLane | str,
) -> QualityRepairClassification:
    normalized_lane = _normalize_lane(lane)
    issues = tuple(_normalize_issues(issue_or_issues))
    if not issues:
        return QualityRepairClassification(
            lane=normalized_lane,
            grade=RepairGrade.PASS,
            issues=issues,
        )

    issue_grades = [
        _classify_single_issue(issue, normalized_lane)
        for issue in issues
    ]
    grade = max(issue_grades, key=lambda item: _GRADE_RANK[item])
    if grade is RepairGrade.PASS:
        reason = ""
    else:
        reason = _reason_for_issue(issues[issue_grades.index(grade)])
    return QualityRepairClassification(
        lane=normalized_lane,
        grade=grade,
        issues=issues,
        reason=reason,
    )

def _classify_single_issue(issue: Mapping[str, Any], lane: RepairLane) -> RepairGrade:
    if _is_pass_marker(issue):
        return RepairGrade.PASS
    if lane is RepairLane.MATH_LOGIC_REPAIR:
        return _classify_math_logic_issue(issue)
    if lane is RepairLane.LAYOUT_REPAIR:
        return _classify_layout_issue(issue)
    return _classify_render_issue(issue)


def _classify_math_logic_issue(issue: Mapping[str, Any]) -> RepairGrade:
    code = _text(issue.get("code"))
    hard_error = _truthy(issue.get("hard_error"))
    hard_bucket = _text(issue.get("policy_bucket")) == "hard_error"
    severe = _is_high_severity(issue) or (hard_error and hard_bucket)
    known_hard_error = code in _MATH_HARD_ERROR_CODES

    if known_hard_error and severe:
        return RepairGrade.NEEDS_REPAIR if _repairable(issue) else RepairGrade.FAILED
    if hard_error and severe:
        return RepairGrade.NEEDS_REPAIR if _repairable(issue) else RepairGrade.FAILED
    if _repairable(issue) and _is_medium_or_high_severity(issue):
        return RepairGrade.NEEDS_REPAIR
    return RepairGrade.DEGRADED


def _classify_layout_issue(issue: Mapping[str, Any]) -> RepairGrade:
    code = _text(issue.get("code"))
    if code in _LAYOUT_RISK_CODES:
        return RepairGrade.DEGRADED
    if code in _LAYOUT_ERROR_CODES:
        if _layout_error_is_severe(issue):
            return RepairGrade.NEEDS_REPAIR if _repairable(issue) else RepairGrade.FAILED
        return RepairGrade.DEGRADED
    if _repairable(issue) and _is_medium_or_high_severity(issue):
        return RepairGrade.NEEDS_REPAIR
    return RepairGrade.DEGRADED


def _classify_render_issue(issue: Mapping[str, Any]) -> RepairGrade:
    code = _text(issue.get("code"))
    if code in _RENDER_FAILURE_CODES or _text(issue.get("status")) in {
        "error",
        "failed",
        "failure",
    }:
        return RepairGrade.NEEDS_REPAIR if _repairable(issue) else RepairGrade.FAILED
    if _repairable(issue) and _is_medium_or_high_severity(issue):
        return RepairGrade.NEEDS_REPAIR
    if _is_high_severity(issue):
        return RepairGrade.FAILED
    return RepairGrade.DEGRADED


def _is_pass_marker(issue: Mapping[str, Any]) -> bool:
    code = _text(issue.get("code"))
    status = _text(issue.get("status") or issue.get("grade") or issue.get("outcome"))
    return (
        not issue
        or code in {"", "ok", "pass", "passed", "clean"}
        and status in {"", "ok", "pass", "passed", "clean"}
    )


def _layout_error_is_severe(issue: Mapping[str, Any]) -> bool:
    return (
        _is_medium_or_high_severity(issue)
        or _float(issue.get("overlap_ratio")) >= 0.15
        or max(_float(issue.get("x_overlap")), _float(issue.get("y_overlap"))) >= 0.12
        or _truthy(issue.get("repairable"))
        or _truthy(issue.get("deterministic_repairable"))
    )


def _repairable(issue: Mapping[str, Any]) -> bool:
    final_action = _text(issue.get("final_action"))
    return (
        _truthy(issue.get("repairable"))
        or _truthy(issue.get("deterministic_repairable"))
        or _truthy(issue.get("needs_repair"))
        or final_action == "repair_candidate"
    )


def _is_high_severity(issue: Mapping[str, Any]) -> bool:
    return _text(issue.get("severity")) in {"critical", "fatal", "high", "severe"}


def _is_medium_or_high_severity(issue: Mapping[str, Any]) -> bool:
    return _text(issue.get("severity")) in {
        "critical",
        "fatal",
        "high",
        "medium",
        "severe",
    }
