"""中日韩字符与数学符号混合表达式检查。"""
import re
_ALLOWED = re.compile(r"^[\sA-Za-z0-9_{}^+\-*/=<>≤≥≈≠×·÷±√∞∑∠△∼≅⊥∥→←\\\u4e00-\u9fff]+$")
_SUBSCRIPT = re.compile(r"^[A-Za-z]+_\{[\u4e00-\u9fffA-Za-z0-9]{1,8}\}$")
def is_cjk_symbolic_formula(text: str) -> bool:
    compact = str(text or "").strip()
    if not compact: return False
    if _SUBSCRIPT.fullmatch(compact): return True
    if not _ALLOWED.fullmatch(compact): return False
    if not any(token in compact for token in ("\\times", "\\cdot", "\\frac", "\\sqrt", "×", "·", "=", "≈", "≤", "≥", "≠")): return False
    if compact.lstrip()[:1] in {"=", "≈", "<", ">", "≤", "≥", "≠", "+", "-", "×", "·", "÷"}: return True
    runs = re.findall(r"[\u4e00-\u9fff]+", compact)
    return bool(runs) and all(len(run) <= 1 for run in runs)

def is_pure_formula_payload(text: str, looks_formula) -> bool:
    compact = str(text or "").strip()
    if not compact: return False
    if re.search(r"[\u4e00-\u9fff]", compact) and not is_cjk_symbolic_formula(compact): return False
    return looks_formula(compact)
