"""Small contract checks kept outside the orchestration function."""

from app.workers.validation.generated_code_quality_models import GeneratedCodeQualityIssue
from app.workers.validation.generated_code_quality_helpers import (
    _legacy_text_slot_api_line,
    _undefined_global_config_attribute,
)


def _append_legacy_and_config_issues(source, issues):
    legacy_line = _legacy_text_slot_api_line(source)
    if legacy_line:
        issues.append(GeneratedCodeQualityIssue(
            code="legacy_text_slot_api", severity="error",
            message="生成代码仍使用旧字符槽或固定分栏锚点，应改用 safe_text_box/layout_canvas 自适应排版。",
            line=legacy_line, evidence="show_text/restore_text/text_center/graph_center",
        ))
    undefined = _undefined_global_config_attribute(source)
    if undefined:
        attr, line_no = undefined
        issues.append(GeneratedCodeQualityIssue(
            code="undefined_global_config_attribute", severity="error",
            message="代码引用了未在 GlobalConfig 中定义的属性，渲染时会触发 AttributeError。",
            line=line_no, evidence=f"GlobalConfig.{attr}",
        ))
    return issues
