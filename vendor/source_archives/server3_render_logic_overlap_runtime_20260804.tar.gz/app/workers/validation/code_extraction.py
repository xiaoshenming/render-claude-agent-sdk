"""LLM code-fence extraction and conservative typo sanitizers."""

import re

# 中文标点 → ASCII 映射表
_CN_PUNCT_MAP = str.maketrans({
    "\uff0c": ",", "\u3002": ".", "\uff1b": ";", "\uff1a": ":",
    "\uff08": "(", "\uff09": ")", "\u3010": "[", "\u3011": "]",
    "\u201c": '"', "\u201d": '"', "\u2018": "'", "\u2019": "'",
})

_SCENE_ANIMATION_CALL_RE = re.compile(
    r"\bself\.(?:play|play_steps_evenly)\s*\("
)
_SCENE_ANIMATION_METHODS = {"play", "play_steps_evenly"}
_NUMBERED_SCENE_CLASS_RE = r"Scene_\d+(?:_\w+)?"


def extract_python_code(text: str) -> str:
    """从 LLM 原始输出中提取 Python 代码块。"""
    # 策略 1: 找所有 ```python ... ``` 代码块，取最长的
    blocks = re.findall(
        r"```(?:python|Python|py)?\s*\n([\s\S]+?)\n```", text, re.IGNORECASE)
    if blocks:
        code = max(blocks, key=len).strip()
        return sanitize_latex_branch_typo(code)
    # 策略 2: 宽松匹配（无换行要求）
    blocks = re.findall(
        r"```(?:python|Python|py)?\s*([\s\S]+?)```", text, re.IGNORECASE)
    if blocks:
        code = max(blocks, key=len).strip()
        return sanitize_latex_branch_typo(code)
    # 策略 3: 文本以 ``` 开头，直接去掉首尾标记
    stripped = text.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:python|Python|py)?\s*\n?", "", stripped)
        stripped = re.sub(r"\n?```\s*$", "", stripped)
        return sanitize_latex_branch_typo(stripped.strip())
    return sanitize_latex_branch_typo(stripped)


def sanitize_chinese_punctuation(code: str) -> str:
    """将中文标点替换为 ASCII 等价物，防止 Manim 渲染报错。"""
    return code.translate(_CN_PUNCT_MAP)


# 已知 LLM 高频笔误：写 `r"\\"` (literal `\\`，匹配两个反斜杠) 来检测 LaTeX 命令，
# 但 LaTeX 命令实际只有一个反斜杠，导致 `\div / \frac / \sqrt` 等被当作纯文本渲染，
# 屏幕上看到 "/div" "/frac" 等现象。统一纠正为 `"\\"`（单反斜杠）。
_LATEX_TYPO_PATTERNS = [
    # if r"\\" in xxx / elif r"\\" in xxx （双引号 if/elif 形式）
    (re.compile(r'(\bif\s+|elif\s+)r"\\\\"\s+in\s+'), r'\1"\\\\" in '),
    # if r'\\' in xxx / elif r'\\' in xxx （单引号 if/elif 形式）
    (re.compile(r"(\bif\s+|elif\s+)r'\\\\'\s+in\s+"), r"\1'\\\\' in "),
    # 兜底：r"\\" in content / r'\\' in content（不带 if 前缀）
    (re.compile(r'r"\\\\"\s+in\s+content\b'), r'"\\\\" in content'),
    (re.compile(r"r'\\\\'\s+in\s+content\b"), r"'\\\\' in content"),
    # any/all 模式：any(c in r"\\" for ...) → any(c in "\\" for ...)
    (re.compile(r'\bin\s+r"\\\\"'), r'in "\\\\"'),
    (re.compile(r"\bin\s+r'\\\\'"), r"in '\\\\'"),
]


def sanitize_latex_branch_typo(code: str) -> str:
    r"""修正 LLM 高频笔误：将 `r"\\"` 检测改为 `"\\"`，避免 `\div` 类 LaTeX 命令
    被错判为纯文本而显示成 "/div"。"""
    if not code or "content" not in code:
        return code
    fixed = code
    for pat, repl in _LATEX_TYPO_PATTERNS:
        fixed = pat.sub(repl, fixed)
    return fixed
