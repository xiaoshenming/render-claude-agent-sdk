import ast
import math
from .generated_code_quality_models import GeneratedCodeQualityIssue

def _single_target_assignment_for_value(tree: ast.AST, value: ast.AST) -> str | None:
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Assign)
            and node.value is value
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            return node.targets[0].id
    return None


def _numeric_text_value_from_expr(
    node: ast.AST,
    text_vars: dict[str, float],
) -> float | None:
    if isinstance(node, ast.Name):
        return text_vars.get(node.id)
    if not isinstance(node, ast.Call):
        return None
    func_name = _call_name(node.func)
    if func_name in {"Text", "Tex", "MathTex", "MarkupText"}:
        label = _first_string_arg(node)
        return _parse_numeric_side_label(label) if label is not None else None
    if func_name in {"DecimalNumber", "Integer"} and node.args:
        value = _literal_number(node.args[0])
        return value if value is not None and value > 0 else None
    if isinstance(node.func, ast.Attribute):
        return _numeric_text_value_from_expr(node.func.value, text_vars)
    return None


def _parse_numeric_side_label(label: str) -> float | None:
    if not re.fullmatch(r"\s*\d+(?:\.\d+)?\s*", label):
        return None
    value = float(label.strip())
    return value if value > 0 else None


def _midpoint_vertex_pair(node: ast.AST) -> tuple[str, str] | None:
    if isinstance(node, ast.BinOp):
        if isinstance(node.op, ast.Div) and _literal_number(node.right) == 2:
            pair = _vertex_sum_pair(node.left)
            if pair is not None:
                return pair
        if isinstance(node.op, ast.Mult):
            if _literal_number(node.left) == 0.5:
                pair = _vertex_sum_pair(node.right)
                if pair is not None:
                    return pair
            if _literal_number(node.right) == 0.5:
                pair = _vertex_sum_pair(node.left)
                if pair is not None:
                    return pair
        if isinstance(node.op, (ast.Add, ast.Sub)):
            return _midpoint_vertex_pair(node.left) or _midpoint_vertex_pair(node.right)
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "get_center"
        and isinstance(node.func.value, ast.Call)
        and _call_name(node.func.value.func) == "Line"
    ):
        line_call = node.func.value
        if len(line_call.args) >= 2:
            left = _vertex_name(line_call.args[0])
            right = _vertex_name(line_call.args[1])
            if left and right:
                return (left, right)
    return None


def _vertex_sum_pair(node: ast.AST) -> tuple[str, str] | None:
    if not isinstance(node, ast.BinOp) or not isinstance(node.op, ast.Add):
        return None
    left = _vertex_name(node.left)
    right = _vertex_name(node.right)
    if left is None or right is None or left == right:
        return None
    return (left, right)


def _vertex_name(node: ast.AST) -> str | None:
    return node.id if isinstance(node, ast.Name) and node.id in {"A", "B", "C"} else None


def _side_label_scale_mismatch(
    left_length: float,
    left_label: float,
    right_length: float,
    right_label: float,
) -> bool:
    if left_label <= 0 or right_label <= 0:
        return False
    left_scale = left_length / left_label
    right_scale = right_length / right_label
    return abs(left_scale - right_scale) > max(left_scale, right_scale) * 0.05


def _side_key(left: str, right: str) -> str:
    return "".join(sorted((left, right)))


def _distance(
    left: tuple[float, float, float],
    right: tuple[float, float, float],
) -> float:
    return _vector_length(_vector_sub(left, right))


def _vector_sub(
    left: tuple[float, float, float],
    right: tuple[float, float, float],
) -> tuple[float, float, float]:
    return (left[0] - right[0], left[1] - right[1], left[2] - right[2])


def _vector_dot(
    left: tuple[float, float, float],
    right: tuple[float, float, float],
) -> float:
    return left[0] * right[0] + left[1] * right[1] + left[2] * right[2]


def _vector_length(vector: tuple[float, float, float]) -> float:
    return math.sqrt(_vector_dot(vector, vector))


