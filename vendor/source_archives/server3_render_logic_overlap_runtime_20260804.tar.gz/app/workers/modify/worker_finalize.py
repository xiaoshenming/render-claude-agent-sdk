"""修改任务上传、时间线和数据库写回步骤。"""
import time
import logging
from app.services import modify_repository
from app.workers.aigc_postprocess import build_aigc_video_variants
from app.workers.validation import code_validator
logger = logging.getLogger("render")
def _ts():
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

async def finalize_modify_task(
    ctx, *, job_id, task_data, source_slices, modified_results,
    local_mp4_path_by_index, concat_output, final_bytes, log_event_fn,
) -> str:
    # Step 5: 上传最终视频
    aigc_clean_video_url: str | None = None
    aigc_watermarked_video_url: str | None = None
    try:
        header = ""
        all_scene_codes = []
        for s in source_slices:
            idx = s["slice_index"]
            scene_name = s.get("scene_name", f"Scene_{idx:02d}")
            if idx in modified_results:
                slice_code = modified_results[idx]["code"]
            else:
                slice_code = s.get("slice_code") or ""

            if not slice_code.strip():
                continue

            if not header:
                header = code_validator.extract_slice_header(slice_code)

            scene_code = code_validator.extract_scene_class_code(
                slice_code, scene_name
            )
            if scene_code:
                all_scene_codes.append(scene_code)

        final_code_parts = []
        if header:
            final_code_parts.append(header)
        if all_scene_codes:
            final_code_parts.append("\n\n".join(all_scene_codes))
        final_code = "\n\n".join(part for part in final_code_parts if part.strip())

        render_canvas_profile_name = str(
            task_data.get("render_canvas_profile_name") or ""
        ).strip() or None
        if (
            aigc_variants.dual_upload_enabled
            and aigc_variants.clean_video_bytes
            and aigc_variants.display_variant != "clean"
        ):
            aigc_clean_video_url = await ctx.upload_video_variant_fn(
                job_id,
                ctx.user_id,
                aigc_variants.clean_video_bytes,
                aspect_ratio=ctx.aspect_ratio,
                render_canvas_profile_name=render_canvas_profile_name,
                variant="aigc_clean",
            )

        video_url, code_url = await ctx.upload_results_fn(
            job_id, ctx.user_id, final_bytes, final_code,
            aspect_ratio=ctx.aspect_ratio,
        )
        if aigc_variants.display_variant == "clean":
            aigc_clean_video_url = video_url
            if (
                aigc_variants.dual_upload_enabled
                and aigc_variants.watermarked_video_bytes
            ):
                aigc_watermarked_video_url = await ctx.upload_video_variant_fn(
                    job_id,
                    ctx.user_id,
                    aigc_variants.watermarked_video_bytes,
                    aspect_ratio=ctx.aspect_ratio,
                    render_canvas_profile_name=render_canvas_profile_name,
                    variant="aigc_watermarked",
                )
        else:
            aigc_watermarked_video_url = video_url

        task_data["aigc_clean_video_url"] = aigc_clean_video_url
        task_data["aigc_watermarked_video_url"] = aigc_watermarked_video_url
        timeline_manifest = None
        try:
            from app.services.timeline_manifest_service import build_timeline_manifest

            timeline_slices = []
            for s in source_slices:
                idx = int(s["slice_index"])
                if idx in modified_results:
                    timeline_slices.append({
                        "slice_index": idx,
                        "scene_name": s.get("scene_name"),
                        "slice_code": modified_results[idx].get("code", ""),
                        "video_url": modified_results[idx].get("url", ""),
                        "duration": modified_results[idx].get("duration", 0),
                        "local_mp4_path": local_mp4_path_by_index.get(idx),
                    })
                else:
                    timeline_slices.append({
                        "slice_index": idx,
                        "scene_name": s.get("scene_name"),
                        "slice_code": s.get("slice_code") or "",
                        "video_url": s.get("video_url") or "",
                        "duration": s.get("duration") or 0,
                        "local_mp4_path": local_mp4_path_by_index.get(idx),
                    })
            timeline_manifest = await build_timeline_manifest(
                video_id=job_id,
                job_id=job_id,
                slices=timeline_slices,
                final_video_path=concat_output,
                final_video_url=video_url,
                source_type="modify",
                parent_manifest=task_data.get("source_timeline_manifest"),
            )
            task_data["_timeline_manifest"] = timeline_manifest
        except Exception as manifest_error:
            logger.warning(
                f"[MODIFY] [{_ts()}] timeline_manifest 构建失败"
                f"（不影响修改视频写回）: {manifest_error}")
            task_data["_timeline_manifest_error"] = str(manifest_error)[:500]
        logger.info(
            f"[MODIFY] [{_ts()}] "
            f"上传完成: video_url={video_url}, "
            f"aigc_clean_video_url={aigc_clean_video_url}, "
            f"aigc_watermarked_video_url={aigc_watermarked_video_url}, "
            f"display={aigc_variants.display_variant}")
    except Exception as e:
        error_msg = f"上传失败: {e}"
        logger.error(f"[MODIFY] [{_ts()}] {error_msg}")
        await ctx.handle_final_failure_fn(
            job_id, error_msg,
            refund_points=task_data.get("refund_points", 0),
            error_type="modify_error",
            error_stage="upload",
            retry_count=0, task_data=task_data,
        )
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        return "failed"

    ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
    total_duration = time.time() - ctx.task_start_time
    logger.info(f"[MODIFY] [{_ts()}] ========== 修改任务完成 ==========")
    logger.info(
        f"[MODIFY] [{_ts()}] job_id={job_id}, "
        f"耗时={total_duration:.2f}s, tokens={ctx.total_tokens}"
    )
    return "success"

    # Step 6: 直写数据库完成修改
    source_video_id = task_data.get("source_video_id", "")
    version = task_data.get("version", 2)
    collector = task_data.get("_error_collector")
    db_writeback_context = {
        "job_id": job_id,
        "video_url": video_url,
        "aigc_clean_video_url": aigc_clean_video_url,
        "aigc_watermarked_video_url": aigc_watermarked_video_url,
        "aigc_display_variant": task_data.get("aigc_display_variant"),
        "code_url": code_url,
        "result_video_id": job_id,
        "source_video_id": source_video_id,
        "version": version,
        "modified_slice_count": len(modified_results),
        "source_slice_count": len(source_slices),
    }
    try:
        ok = await modify_repository.update_modify_success(
            job_id=job_id,
            user_id=ctx.user_id,
            video_url=video_url,
            code_url=code_url,
            parent_video_id=source_video_id,
            version=version,
            total_tokens=ctx.total_tokens,
            llm_fix_count=task_data.get("_llm_fix_count", 0),
            render_fix_count=task_data.get(
                "_render_fix_count", 0),
            input_tokens=task_data.get("_input_tokens", 0),
            output_tokens=task_data.get("_output_tokens", 0),
            cache_read_tokens=task_data.get(
                "_cache_read_tokens", 0),
            cache_creation_tokens=task_data.get(
                "_cache_creation_tokens", 0),
            modified_results=modified_results,
            source_slices=source_slices,
            timeline_manifest=timeline_manifest,
            aigc_clean_video_url=aigc_clean_video_url,
            aigc_watermarked_video_url=aigc_watermarked_video_url,
            aigc_display_variant=task_data.get("aigc_display_variant"),
            aigc_visible_watermark_applied=task_data.get(
                "aigc_visible_watermark_applied"
            ),
            aigc_metadata_injected=task_data.get("aigc_metadata_injected"),
        )
        if ok:
            logger.info(
                f"[MODIFY] [{_ts()}] 直写数据库完成")
            if collector:
                collector.info(
                    "DATABASE",
                    "STATUS_WRITEBACK",
                    "修改任务数据库回写成功",
                    context=db_writeback_context,
                )
            await log_event_fn(
                task_data,
                event_type="db_writeback_succeeded",
                context=db_writeback_context,
                duration_ms=int((time.time() - ctx.task_start_time) * 1000),
            )
        else:
            logger.warning(
                f"[MODIFY] [{_ts()}] 直写被拒（job已终态）")
            if collector:
                collector.warning(
                    "DATABASE",
                    "STATUS_WRITEBACK",
                    "修改任务数据库回写被终态保护跳过",
                    context=db_writeback_context,
                )
            await log_event_fn(
                task_data,
                event_type="db_writeback_skipped",
                context=db_writeback_context,
            )
            if await ctx.is_job_cancelled_fn(job_id):
                ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
                return "skipped"
            task_data["last_error"] = "修改任务数据库回写被拒，任务状态未确认"
            task_data["_error_type"] = "db_writeback_rejected"
            task_data["_error_stage"] = "status_writeback"
            ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
            return "failed"
    except Exception as e:
        logger.error(
            f"[MODIFY] [{_ts()}] "
            f"直写数据库失败（视频已上传，手动处理）: {e}")
        if collector:
            collector.capture_exception(
                e,
                "DATABASE",
                "STATUS_WRITEBACK",
                context=db_writeback_context,
            )
        await log_event_fn(
            task_data,
            event_type="db_writeback_failed",
            context=db_writeback_context,
            exception=e,
        )
        task_data["last_error"] = f"修改任务数据库回写失败: {e}"
        task_data["_error_type"] = "db_error"
        task_data["_error_stage"] = "status_writeback"
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        return "failed"
