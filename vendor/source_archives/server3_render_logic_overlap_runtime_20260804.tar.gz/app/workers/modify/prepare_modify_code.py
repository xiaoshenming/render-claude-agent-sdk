"""二次修改的上下文准备与 patch-first 代码生成。"""

import re
import logging
from typing import Any

from app.services.ai_guardrails import guard_ai_user_input
from app.workers.validation import code_validator
from app.workers.repair.search_replace_patch import apply_modify_patch_or_fallback
from app.workers.repair import error_fixer
from app.workers.modify.context_helpers import _slice_label, _ts
from app.workers.modify.patch_generation import (
    _mark_modify_semantic_rejected,
    _should_refine_modify_patch_failure,
    _format_modify_patch_refinement_section,
    generate_modify_patch,
    _generate_full_modify_code,
)
from app.workers.modify.budget_helpers import _ensure_modify_token_budget
from app.workers.modify.modify_contract_patterns import MODIFY_PATCH_TOKEN_ESTIMATE

logger = logging.getLogger("render")


async def prepare_modified_code(ctx: Any, slice_index: int, instruction: str):
    source = ctx.source_map[slice_index]
    instruction = guard_ai_user_input(instruction, scenario="render_modify_instruction")
    task_data = ctx.task_data
    scene_name = source.get("scene_name", f"Scene_{slice_index:02d}")
    slice_label = _slice_label(slice_index, scene_name)
    original_code = source.get("slice_code") or ""
    if original_code.strip():
        original_code = code_validator.extract_scene_standalone_code(original_code, scene_name)
    if not original_code.strip():
        task_data["_non_retryable"] = True
        raise Exception(f"{slice_label} 的原始代码为空，无法执行修改（原始渲染时可能未完成）")
    context_section = ""
    for offset, title, edge in ((-1, "前一个", "tail"), (1, "后一个", "head")):
        neighbor = ctx.source_map.get(slice_index + offset)
        if not neighbor:
            continue
        neighbor_name = neighbor.get("scene_name", f"Scene_{slice_index + offset:02d}")
        raw = neighbor.get("slice_code") or ""
        if not raw.strip():
            continue
        code = code_validator.extract_scene_standalone_code(raw, neighbor_name)
        snippet = code[-2000:] if edge == "tail" else code[:2000]
        context_section += f"\n## {title} Scene 的代码（只读参考，不要修改）\n```python\n{snippet}\n```\n"
    base_class_match = re.search(r'class\s+\w+\((\w+)\)', original_code)
    base_class_name = base_class_match.group(1) if base_class_match else "Scene"
    if await ctx.should_abort(f"slice_{slice_index}_pre_llm"):
        raise Exception(f"{slice_label}: 任务已终止或超时")
    patch_raw = await generate_modify_patch(
        ctx, original_code=original_code, instruction=instruction,
        context_section=context_section, scene_name=scene_name,
        base_class_name=base_class_name,
    )
    patch_result = apply_modify_patch_or_fallback(original_code, patch_raw, scene_name=scene_name)
    finish_reason = str(task_data.get("_last_modify_patch_finish_reason") or "")
    if finish_reason == "length" or (not patch_result.get("ok") and not patch_result.get("fallback_code")):
        reasons = ["finish_reason_length"] if finish_reason == "length" else []
        if not patch_result.get("ok") and not patch_result.get("fallback_code"):
            reasons.append(f"patch_apply_failed:{patch_result.get('reason') or 'unknown'}")
        await _mark_modify_semantic_rejected(ctx, call_type="modify_slice_patch", reason=";".join(reasons))
    if (not patch_result.get("ok") and not patch_result.get("fallback_code") and
            _should_refine_modify_patch_failure(str(patch_result.get("reason") or ""))):
        _ensure_modify_token_budget(ctx, call_type="modify_slice_patch_refine", estimated_tokens=MODIFY_PATCH_TOKEN_ESTIMATE)
        refined_raw = await generate_modify_patch(
            ctx, original_code=original_code, instruction=instruction,
            context_section=context_section, scene_name=scene_name,
            base_class_name=base_class_name,
            patch_feedback=_format_modify_patch_refinement_section(str(patch_result.get("reason") or "")),
        )
        patch_result = apply_modify_patch_or_fallback(original_code, refined_raw, scene_name=scene_name)
    if patch_result.get("ok"):
        new_code = str(patch_result["code"])
    elif patch_result.get("fallback_code"):
        new_code = str(patch_result["fallback_code"])
    else:
        new_code = await _generate_full_modify_code(
            ctx, original_code=original_code, instruction=instruction,
            context_section=context_section, scene_name=scene_name,
            base_class_name=base_class_name,
            patch_failure_reason=str(patch_result.get("reason") or ""),
        )
    return instruction, scene_name, slice_label, original_code, new_code
