"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")

def _build_modify_prompt(
    original_code: str, instruction: str,
    context_section: str, scene_name: str,
    base_class_name: str,
) -> str:
    """构建修改 prompt"""
    return (
        "你是 Manim 数学动画代码修改助手。\n\n"
        "以下是一段 Manim 动画代码（一个完整的 Scene）：\n\n"
        f"```python\n{original_code}\n```\n\n"
        f"用户的修改要求：\n{instruction}\n\n"
        f"{context_section}\n"
        "请修改代码实现上述改动。要求：\n"
        "1. **最小修改原则**：只修改用户指出的部分，其余代码保持完全不变\n"
        "2. **严禁改坐标布局**：不要移动图形位置（主视觉中心、顶点坐标等），"
        "除非用户明确要求移动图形。用户说'移文字'就只移文字，不要动图形\n"
        "3. **视觉衔接**：此 Scene 是切片视频的一部分，修改后的画面必须与"
        "前后 Scene 视觉衔接（相同的对象在相同的位置），否则拼接后会闪跳\n"
        "4. 保持代码语法正确，可正常运行\n"
        f"5. 保持 Scene 类名不变（{scene_name}）\n"
        f"6. 保持继承 {base_class_name}，不要更改父类\n"
        "7. **保持所有 import 语句、全局变量、基类定义完全不变**，"
        "输出完整的可独立运行的 Python 文件\n"
        "7.1 **保持原片段背景和主题色不变**，除非用户明确要求更换背景、主题或配色\n"
        "8. **保持所有 voiceover/配音代码不变**，"
        "如果原代码有 `with self.voiceover(...)` 或 "
        "`VoiceoverScene`，必须原样保留\n"
        "9. **必须真正落实用户指定修改**：如果用户要求改文字、字号、位置、颜色或布局，"
        "对应代码必须发生可见变化；不要返回与原代码等效的版本\n"
        "10. **必须包含动画调用**：修改后的代码必须包含 self.play() "
        "和/或 self.wait() 调用，绝对不要只用 self.add()，"
        "否则 Manim 只会生成静态图片而非视频\n"
        "11. **禁止引用外部文件**：不要使用 ImageMobject、"
        "SVGMobject 或任何外部文件路径（如 .png/.jpg/.svg），"
        "所有图形必须用 Manim 内置对象纯代码绘制\n"
        "12. **字体修改必须真实生效**：如果用户要求字体/字号变大、"
        "大小一致或和某一行保持一致，不能只改 `font_size`；"
        "还必须同步移除或调整会抵消字号修改的 "
        "`scale_to_fit_width()`、`scale_to_fit_height()`、"
        "`fit_width` 等自动缩小约束。空间不够时用换行、"
        "分组间距或局部布局调整解决\n"
        "13. **数学文本不能原样显示**：不要把 $...$ 或 \\(...\\) 留在 Text/safe_text_box；"
        "遇到 `极径 $\\theta$`、`夹角 $\\alpha$` 这类混排，必须拆成 "
        "Text + MathTex 的 VGroup，或把数学片段改成 MathTex 后再 arrange/fit_to_canvas。\n"
        "14. **文本溢出修复必须重新避让**：处理“字符串/文本/公式溢出、出框、显示不全”时，"
        "不能只换行/缩字/拆 MathTex 后继续 move_to(旧文本.get_center())；必须重新选择清晰区域，"
        "并用 place_non_overlapping(..., others=visible_objects, area=...) 或等价布局避开曲线、切线、点标和公式。\n"
        "15. **布局安全**：修改后所有 Text/MathTex/Axes/Graph 必须按区域组成 VGroup，"
        "在 arrange/next_to/move_to 后执行 fit_to_canvas 或 clamp_to_canvas，禁止越界裁切；"
        "新增或移动 Text/MathTex/点标/角标/边长标签必须维护 visible_objects，"
        "调用 place_non_overlapping(..., others=visible_objects, area=...) 后再 append；"
        "禁止对点标/角标/边长标签使用 next_to(..., buff<=0.2) 或 "
        "raw move_to(center + np.array(...)) 贴边摆放，必须优先用动态 anchor + "
        "place_non_overlapping 避让\n"
        "16. 直接输出修改后的完整 Python 代码，不需要解释"
    )

def _build_modify_patch_prompt(
    *,
    original_code: str,
    instruction: str,
    context_section: str,
    scene_name: str,
    base_class_name: str,
    patch_feedback: str = "",
) -> str:
    """构建 patch-first 修改 prompt。"""
    return (
        "你是 Manim 数学动画代码修改助手。\n\n"
        f"{PATCH_ONLY_REPAIR_INSTRUCTIONS}\n"
        "下面是一段完整的单切片 Scene 代码。请优先用最小 Search/Replace Patch "
        "实现用户修改，不要重写整个文件。\n"
        "SEARCH 片段必须逐字匹配原始代码；如果目标行可能重复，必须包含上下相邻代码、"
        "所在 VGroup/循环/条件等上下文，让 SEARCH 在完整代码中只匹配一次。\n\n"
        f"## 原始代码\n```python\n{original_code}\n```\n\n"
        f"## 用户修改要求\n{instruction}\n\n"
        f"{context_section}\n"
        f"{patch_feedback}"
        "## 合同与证据优先级\n"
        "- 如果用户修改要求中包含 technical_contract 或“唯一技术修改合同”，"
        "technical_contract 是唯一代码执行依据。\n"
        "- Gemini/后台视觉识别结果只能作为视觉证据、定位参考和对象映射候选，"
        "不能新增、改写或覆盖 technical_contract，也不能生成新的修改目标。\n"
        "- 旧 payload 没有 technical_contract 时，保持兼容：按用户修改要求、"
        "精确定位上下文和现有修改约束执行。\n"
        "## 修改约束\n"
        f"- 目标 Scene 类名必须保持 `{scene_name}`。\n"
        f"- 继承必须保持 `{base_class_name}`，不要改父类。\n"
        "- 只修改用户指出的局部内容；其余 import、全局变量、基类、配音/voiceover 代码保持不变。\n"
        "- 除非用户明确要求更换背景/主题/配色，否则必须保持原片段背景和主题色不变。\n"
        "- 如果用户修改要求或上下文包含 timestamp_seconds、local_offset_seconds、"
        "第几秒、window_id、sync_unit_id、bookmark_mark 或 word_range，"
        "必须把它们当作定位目标，只改该时间点附近相关视觉/文本/公式代码。\n"
        "- 修改后必须保留 self.play() 或 self.wait() 动画调用。\n"
        "- 禁止引用 ImageMobject、SVGMobject 或任何外部文件路径。\n"
        "- 字体/字号变大时，必须同步移除或调整会抵消字号的 "
        "scale_to_fit_width()/scale_to_fit_height()/fit_width 约束。\n"
        "- 不要把 $...$ 或 \\(...\\) 留在 Text/safe_text_box；混排中文和数学符号时，"
        "必须用 Text + MathTex 组成 VGroup，或把数学片段改为 MathTex。\n"
        "- 处理字符串/文本/公式溢出时，不能只拆成 VGroup 后继续 "
        "move_to(旧文本.get_center())；必须重新避让曲线、切线、点标和公式，优先使用 "
        "place_non_overlapping(..., others=visible_objects, area=...)。\n"
        "- 布局修改必须继续遵守 visible_objects/place_non_overlapping/清晰避让要求。\n"
        "- 只能输出 Search/Replace Patch；不要解释。\n"
    )

