"""修改任务主流程实现，供兼容 façade 调用。"""

import os
import time
import asyncio
import logging
from typing import Dict

from app.services import job_repository, modify_repository, ffmpeg_service
from app.workers.aigc_postprocess import build_aigc_video_variants
from app.workers.validation import code_validator

logger = logging.getLogger("render")

def _ts():
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

async def process_modify_task(ctx, *, download_fn, log_event_fn) -> str:
    """处理二次修改任务：只重渲受影响的切片，复用未修改切片，最终拼接。

    返回 "success" / "skipped" / "failed"
    """
    from app.workers.modify.helpers import modify_one_slice

    job_id = ctx.job_id
    task_data = ctx.task_data
    retry_count = task_data.get("retry_count", 0)
    modifications = task_data.get("modifications", [])
    source_slices = task_data.get("source_slices", [])

    logger.info(
        f"[MODIFY] [{_ts()}] ========== 开始修改任务 ==========")
    logger.info(
        f"[MODIFY] [{_ts()}] job_id={job_id}, "
        f"修改切片数={len(modifications)}, "
        f"总切片数={len(source_slices)}, retry={retry_count}")

    # Step 1: 更新状态为 PROCESSING（带门禁）
    if retry_count == 0:
        try:
            entered = await job_repository.update_job_status(
                job_id, "PROCESSING")
            if not entered:
                logger.warning(
                    f"[MODIFY] [{_ts()}] job {job_id} "
                    f"not in PENDING, skip (duplicate)")
                return "skipped"
            logger.info(
                f"[MODIFY] [{_ts()}] Step 1: "
                f"状态已更新为 PROCESSING")
        except job_repository.JobStatusWriteError as e:
            logger.exception(
                f"[MODIFY] [{_ts()}] "
                f"PROCESSING 状态写库异常，请求消息重投: {e}")
            raise
        except Exception as e:
            logger.exception(
                f"[MODIFY] [{_ts()}] "
                f"PROCESSING 状态写失败: {e}")
            return "failed"
    else:
        if await ctx.is_job_cancelled_fn(job_id):
            logger.info(
                f"[MODIFY] [{_ts()}] 重试前发现 "
                f"job {job_id} 已终态，skip")
            return "skipped"

    # 构建修改映射
    mod_map = {
        m["slice_index"]: m["instruction"]
        for m in modifications
    }
    mod_by_index = {
        m["slice_index"]: m
        for m in modifications
        if isinstance(m, dict) and m.get("slice_index") is not None
    }

    # 源切片完整性检查
    missing_slices = []
    for s in source_slices:
        idx = s["slice_index"]
        if idx not in mod_map and not s.get("video_url"):
            missing_slices.append(idx)
    if missing_slices:
        error_msg = (
            f"源视频切片不完整，切片 {missing_slices} 缺少视频文件"
            f"（原始渲染时可能失败），无法执行修改任务")
        logger.error(f"[MODIFY] [{_ts()}] {error_msg}")
        task_data["last_error"] = error_msg
        task_data["_error_type"] = "modify_error"
        task_data["_error_stage"] = "pre_check"
        task_data["_non_retryable"] = True
        return "failed"

    # Step 2: 创建工作目录
    os.makedirs(ctx.job_script_dir, exist_ok=True)
    os.makedirs(ctx.job_output_dir, exist_ok=True)

    # >>> 检查点A：LLM 调用前
    if await ctx.should_abort("pre_llm"):
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        if task_data.get("_non_retryable"):
            return "failed"
        return "skipped"

    # Step 3: 并行修改受影响的切片
    modified_results: Dict[int, dict] = {}
    try:
        from app.services.modify_visual_recognition import (
            append_visual_recognition_to_instruction,
            recognize_modify_visual_context,
        )

        async def _recognize(idx: int):
            source = ctx.source_map.get(idx, {})
            slice_state = {
                **dict(mod_by_index.get(idx) or {}),
                "slice_index": idx,
                "instruction": mod_map.get(idx, ""),
            }
            visual = await recognize_modify_visual_context(ctx, slice_state, source)
            if visual:
                mod_map[idx] = append_visual_recognition_to_instruction(
                    mod_map.get(idx, ""),
                    visual,
                )

        await asyncio.gather(*[_recognize(idx) for idx in mod_map.keys()])
    except Exception as exc:
        logger.warning(
            f"[MODIFY] [{_ts()}] 视觉识别上下文注入失败，继续原修改链路: "
            f"{type(exc).__name__}"
        )

    tasks = []
    for idx, instruction in mod_map.items():
        tasks.append(modify_one_slice(ctx, idx, instruction))

    results = await asyncio.gather(
        *tasks, return_exceptions=True)

    # 检查结果（降级策略：失败的切片回退到原始版本）
    failed_slices = []
    mod_indices = list(mod_map.keys())
    for i, r in enumerate(results):
        if isinstance(r, Exception):
            failed_idx = mod_indices[i]
            display_idx = failed_idx + 1
            scene_name = ctx.source_map.get(failed_idx, {}).get("scene_name", "")
            slice_label = (
                f"切片{display_idx}(slice_{failed_idx}, {scene_name})"
                if scene_name else f"切片{display_idx}(slice_{failed_idx})"
            )
            logger.warning(
                f"[MODIFY] [{_ts()}] "
                f"{slice_label} 修改失败，"
                f"降级使用原始版本: {r}")
            failed_slices.append(
                f"{slice_label}: {str(r)[:200]}")
        else:
            idx, mp4_path, new_url, new_code, duration = r
            modified_results[idx] = {
                "mp4_path": mp4_path,
                "url": new_url,
                "code": new_code,
                "duration": duration,
            }

    if failed_slices:
        if len(modified_results) == 0:
            error_msg = (
                f"所有切片修改均失败: "
                f"0/{len(modifications)} 成功")
            logger.error(f"[MODIFY] [{_ts()}] {error_msg}")
            task_data["last_error"] = error_msg
            task_data["_error_type"] = "modify_error"
            task_data["_error_stage"] = "modify"
            ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
            return "failed"
        else:
            logger.warning(
                f"[MODIFY] [{_ts()}] "
                f"降级模式: {len(modified_results)}/"
                f"{len(modifications)} 切片修改成功")

    # >>> 检查点B：渲染完成后、拼接前
    if await ctx.should_abort("post_render"):
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        if task_data.get("_non_retryable"):
            return "failed"
        return "skipped"

    # Step 4: 拼接最终视频
    all_mp4_paths = []
    local_mp4_path_by_index: Dict[int, str] = {}
    source_reuse_paths = set()
    try:
        for i in range(len(source_slices)):
            if i in modified_results:
                mp4_path = modified_results[i]["mp4_path"]
                all_mp4_paths.append(mp4_path)
                local_mp4_path_by_index[i] = mp4_path
            else:
                source_url = ctx.source_map[i].get("video_url")
                if not source_url:
                    raise Exception(f"切片 {i} 无 video_url")
                temp_path = os.path.join(
                    ctx.job_output_dir, f"source_slice_{i}.mp4")
                await download_fn(source_url, temp_path)
                all_mp4_paths.append(temp_path)
                local_mp4_path_by_index[i] = temp_path
                source_reuse_paths.add(temp_path)

        concat_output = os.path.join(
            ctx.job_output_dir, f"video_{job_id}.mp4")
        final_bytes = await ffmpeg_service.concat_slices(
            all_mp4_paths,
            concat_output,
            require_audio=bool(task_data.get("enable_tts")),
            allow_missing_audio_paths=source_reuse_paths,
        )
        logger.info(
            f"[MODIFY] [{_ts()}] "
            f"拼接完成, 大小={len(final_bytes)/1024/1024:.2f}MB")
    except Exception as e:
        error_msg = f"拼接失败: {e}"
        logger.error(f"[MODIFY] [{_ts()}] {error_msg}")
        await ctx.handle_final_failure_fn(
            job_id, error_msg,
            refund_points=task_data.get("refund_points", 0),
            error_type="modify_error",
            error_stage="concat",
            retry_count=0, task_data=task_data,
        )
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        return "failed"

    # >>> 检查点C：上传前
    if await ctx.should_abort("pre_upload"):
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        if task_data.get("_non_retryable"):
            return "failed"
        return "skipped"

    # Step 4.5: AIGC 后处理。无水印归档版与显性水印展示版都从同一拼接产物生成。
    try:
        aigc_variants = await build_aigc_video_variants(
            final_bytes,
            task_data,
            job_id=job_id,
            user_id=ctx.user_id,
            job_output_dir=ctx.job_output_dir,
            log_prefix=f"[MODIFY] [{_ts()}]",
        )
        final_bytes = aigc_variants.display_video_bytes
    except Exception as e:
        error_msg = task_data.get("last_error") or f"AIGC视频后处理失败: {e}"
        logger.error(f"[MODIFY] [{_ts()}] {error_msg}")
        await ctx.handle_final_failure_fn(
            job_id, error_msg,
            refund_points=task_data.get("refund_points", 0),
            error_type=task_data.get("_error_type", "aigc_postprocess_error"),
            error_stage=task_data.get("_error_stage", "aigc_postprocess"),
            retry_count=0, task_data=task_data,
        )
        ctx.cleanup_fn(ctx.job_output_dir, ctx.job_script_dir)
        return "failed"

    return await __import__("app.workers.modify.worker_finalize", fromlist=["finalize_modify_task"]).finalize_modify_task(
        ctx, job_id=job_id, task_data=task_data, source_slices=source_slices,
        modified_results=modified_results, local_mp4_path_by_index=local_mp4_path_by_index,
        concat_output=concat_output, final_bytes=final_bytes, log_event_fn=log_event_fn,
    )
