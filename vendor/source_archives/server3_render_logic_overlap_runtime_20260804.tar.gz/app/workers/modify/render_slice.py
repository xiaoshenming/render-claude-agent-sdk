"""二次修改切片的容器渲染、上传与时长回写。"""

import os
import logging
from typing import Any

from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.context_helpers import _ts
from app.workers.rendering import executor as render_executor
from app.workers.modify.render_fix_flow import _try_render_fix

logger = logging.getLogger("render")


async def render_and_upload_modified_slice(
    ctx: Any,
    *,
    slice_index: int,
    slice_label: str,
    scene_name: str,
    instruction: str,
    new_code: str,
    scan_color_scheme: int,
) -> tuple[int, str, str, str, float]:
    os.makedirs(ctx.job_script_dir, exist_ok=True)
    os.makedirs(ctx.job_output_dir, exist_ok=True)
    script_path = os.path.join(ctx.job_script_dir, f"slice_{slice_index}.py")
    slice_output_dir = os.path.join(ctx.job_output_dir, f"slice_{slice_index}")
    os.makedirs(slice_output_dir, exist_ok=True)

    max_render_retries = 2
    last_render_error = None
    for attempt in range(max_render_retries + 1):
        if attempt > 0 and os.path.exists(slice_output_dir):
            import shutil
            shutil.rmtree(slice_output_dir, ignore_errors=True)
            os.makedirs(slice_output_dir, exist_ok=True)
            logger.info(
                f"[MODIFY] [{_ts()}] {slice_label} 已清理输出目录(retry={attempt})"
            )
        if await ctx.should_abort(f"slice_{slice_index}_render_{attempt}"):
            raise Exception(f"{slice_label}: 任务已终止或超时")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(new_code)
        container = await ctx.container_mgr.select_idle_container(
            max_wait=ctx.remaining_budget(600)
        )
        try:
            mp4_bytes = await render_executor.render_in_container(
                container, ctx.job_id, script_path, scene_name, slice_output_dir,
                aspect_ratio=ctx.aspect_ratio,
                timeout_sec=ctx.remaining_budget(900),
                manim_media_root=ctx.manim_media_root,
                media_root=ctx.media_root,
                task_data=ctx.task_data,
            )
            last_render_error = None
            break
        except Exception as render_err:
            last_render_error = str(render_err)
            logger.warning(
                f"[MODIFY] [{_ts()}] {slice_label} 渲染失败(attempt={attempt + 1}): "
                f"{last_render_error[:200]}"
            )
            if attempt < max_render_retries:
                new_code = await _try_render_fix(
                    ctx, new_code, last_render_error, instruction,
                    slice_index, scene_name, color_scheme=scan_color_scheme,
                )
        finally:
            try:
                ctx.container_mgr.release_lock(container)
            except Exception:
                pass
    if last_render_error:
        raise Exception(
            f"{slice_label} 渲染失败(已重试{max_render_retries}次): "
            f"{last_render_error[:300]}"
        )
    mp4_path = os.path.join(ctx.job_output_dir, f"modified_slice_{slice_index}.mp4")
    with open(mp4_path, "wb") as f:
        f.write(mp4_bytes)
    cos_key = f"slices/{ctx.user_id}/{ctx.job_id}/slice_{slice_index}.mp4"
    new_url = await storage_service.upload_file(
        cos_key, mp4_bytes, content_type="video/mp4", cache_control="public, max-age=31536000"
    )
    duration = await job_repository.get_slice_duration(mp4_path)
    return slice_index, mp4_path, new_url, new_code, duration
