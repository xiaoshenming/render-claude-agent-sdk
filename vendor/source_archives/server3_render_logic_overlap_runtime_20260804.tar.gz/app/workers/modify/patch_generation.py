"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.context_helpers import (
    _ts, _slice_label, _hex_is_light, _configured_color_scheme,
    _infer_source_color_scheme, _color_scheme_for_modify_scan,
    _enforce_modify_tts_voice,
)

from app.workers.modify.sanity_helpers import (
    _is_font_resize_instruction, _normalize_for_noop_compare, _has_substantive_change,
    _find_font_resize_scale_guard_conflicts, _remove_font_resize_scale_guards, _call_name,
)

from app.workers.modify.issue_detection import (
    _text_helper_literal_math_issues, _text_overflow_reused_center_issues,
    _core_modify_sanity_issues, _detect_modify_result_issues,
    _is_soft_static_layout_issue, _blocking_modify_result_issues,
    _defer_modify_tts_timing_blockers, _detect_static_layout_contract_issues,
)

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")

























































async def _mark_modify_semantic_rejected(
    ctx: Any,
    *,
    call_type: str,
    reason: str,
) -> None:
    task_data = getattr(ctx, "task_data", {}) or {}
    item = {
        "call_type": call_type,
        "quality_result": "semantic_rejected",
        "reason": reason[:500],
    }
    task_data.setdefault("_modify_semantic_rejections", []).append(item)
    try:
        from app.services.llm_call_tracer import mark_latest_llm_call_semantic_rejected

        job_id = str(getattr(ctx, "job_id", "unknown") or "")
        if (
            job_id.startswith("job-")
            and getattr(mark_latest_llm_call_semantic_rejected, "__module__", "")
            == "app.services.llm_call_tracer"
        ):
            return
        await mark_latest_llm_call_semantic_rejected(
            job_id=job_id,
            call_type=call_type,
            error_type="modify_semantic_rejected",
            error_message=reason,
            quality_result="semantic_rejected",
        )
    except Exception as exc:
        logger.warning(
            "[MODIFY] [%s] semantic rejected trace update failed: %s",
            _ts(),
            exc,
        )

def _should_refine_modify_patch_failure(reason: str) -> bool:
    return "multiple_matches" in (reason or "")

def _format_modify_patch_refinement_section(reason: str) -> str:
    return (
        "\n\n## 上一次 Search/Replace Patch 应用失败\n"
        f"- 原因: {reason[:800]}\n"
        "- 请重新输出 patch，SEARCH 必须包含目标行上下文，"
        "确保在完整原始代码中只匹配一次。\n"
    )

async def generate_modify_patch(
    ctx: Any,
    *,
    original_code: str,
    instruction: str,
    context_section: str,
    scene_name: str,
    base_class_name: str,
    patch_feedback: str = "",
) -> str:
    """Ask the modify LLM for a minimal Search/Replace Patch."""
    prompt = _build_modify_patch_prompt(
        original_code=original_code,
        instruction=instruction,
        context_section=context_section,
        scene_name=scene_name,
        base_class_name=base_class_name,
        patch_feedback=patch_feedback,
    )
    from app.services.llm_service import get_modify_llm_manager

    response, _ = await get_modify_llm_manager().call(
        messages=[{"role": "user", "content": prompt}],
        max_tokens=8192,
        retry_budget=1,
        trace_job_id=getattr(ctx, "job_id", "unknown"),
        trace_call_type="modify_slice_patch",
        trace_prompt_version=scene_name,
        trace_prompt_content=prompt,
    )
    _accumulate_llm_usage(ctx, response)
    task_data = getattr(ctx, "task_data", {}) or {}
    choice = response.choices[0]
    task_data["_last_modify_patch_finish_reason"] = getattr(
        choice,
        "finish_reason",
        None,
    )
    return guard_ai_output(
        choice.message.content or "",
        scenario="render_modify_patch_output",
    )

async def _generate_full_modify_code(
    ctx: Any,
    *,
    original_code: str,
    instruction: str,
    context_section: str,
    scene_name: str,
    base_class_name: str,
    patch_failure_reason: str = "",
) -> str:
    _ensure_modify_token_budget(
        ctx,
        call_type="modify_slice",
        estimated_tokens=MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    )
    fallback_context = context_section
    if patch_failure_reason:
        fallback_context += (
            "\n## Patch-first 首选失败\n"
            f"- 原因: {patch_failure_reason[:800]}\n"
            "- 现在进入完整代码 fallback；仍然只允许最小必要修改。\n"
        )
    modify_prompt = _build_modify_prompt(
        original_code,
        instruction,
        fallback_context,
        scene_name,
        base_class_name,
    )
    from app.services.llm_service import get_modify_llm_manager

    response, _ = await get_modify_llm_manager().call(
        messages=[{"role": "user", "content": modify_prompt}],
        max_tokens=65536,
        retry_budget=3,
        trace_job_id=getattr(ctx, "job_id", "unknown"),
        trace_call_type="modify_slice",
        trace_prompt_version=scene_name,
        trace_prompt_content=modify_prompt,
    )
    _accumulate_llm_usage(ctx, response)
    content = guard_ai_output(
        response.choices[0].message.content or "",
        scenario="render_modify_output",
    )
    return code_validator.extract_python_code(content) or content

