"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.context_helpers import (
    _ts, _slice_label, _hex_is_light, _configured_color_scheme,
    _infer_source_color_scheme, _color_scheme_for_modify_scan,
    _enforce_modify_tts_voice,
)

from app.workers.modify.issue_detection import (
    _text_helper_literal_math_issues, _text_overflow_reused_center_issues,
    _core_modify_sanity_issues, _detect_modify_result_issues,
    _is_soft_static_layout_issue, _blocking_modify_result_issues,
    _defer_modify_tts_timing_blockers, _detect_static_layout_contract_issues,
)

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")















def _is_font_resize_instruction(instruction: str) -> bool:
    return is_font_resize_instruction(instruction, _FONT_RESIZE_RE)

def _normalize_for_noop_compare(code: str) -> str:
    return normalize_for_noop_compare(code)

def _has_substantive_change(original_code: str, new_code: str) -> bool:
    return (
        _normalize_for_noop_compare(original_code)
        != _normalize_for_noop_compare(new_code)
    )

def _find_font_resize_scale_guard_conflicts(code: str) -> list[str]:
    return find_font_resize_scale_guard_conflicts(code, _TEXT_ASSIGN_WITH_FONT_RE)

def _remove_font_resize_scale_guards(
    code: str,
    instruction: str,
) -> tuple[str, list[str]]:
    """Remove local auto-shrink guards that cancel an explicit font resize."""
    if not _is_font_resize_instruction(instruction):
        return code, []
    targets = set(_find_font_resize_scale_guard_conflicts(code))
    if not targets:
        return code, []

    lines = (code or "").splitlines()
    remove_indexes: set[int] = set()
    target_re = "|".join(re.escape(target) for target in sorted(targets))
    direct_re = re.compile(
        rf"^\s*(?:{target_re})\."
        r"(?:scale_to_fit_width|scale_to_fit_height)\s*\("
    )
    fit_width_re = re.compile(
        rf"^\s*(?:{target_re})\.fit_width\s*="
    )
    inline_if_re = re.compile(
        rf"^\s*if\s+(?:{target_re})\."
        r"(?:width|height)\s*[<>=!].*:\s*"
        rf"(?:{target_re})\."
        r"(?:scale_to_fit_width|scale_to_fit_height)\s*\("
    )
    block_if_re = re.compile(
        rf"^\s*if\s+(?:{target_re})\."
        r"(?:width|height)\s*[<>=!].*:\s*$"
    )

    for idx, line in enumerate(lines):
        if direct_re.match(line) or fit_width_re.match(line) or inline_if_re.match(line):
            remove_indexes.add(idx)
            continue
        if block_if_re.match(line) and idx + 1 < len(lines):
            next_line = lines[idx + 1]
            if direct_re.match(next_line):
                remove_indexes.add(idx)
                remove_indexes.add(idx + 1)

    if not remove_indexes:
        return code, []
    kept = [
        line for idx, line in enumerate(lines)
        if idx not in remove_indexes
    ]
    return "\n".join(kept) + ("\n" if code.endswith("\n") else ""), [
        "removed_font_resize_auto_scale_guards:"
        + ",".join(sorted(targets))
    ]

def _call_name(node: ast.AST) -> str:
    return call_name(node)

