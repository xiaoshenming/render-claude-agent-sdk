"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

def _accumulate_llm_usage(ctx: Any, response: Any) -> None:
    task_data = getattr(ctx, "task_data", {})
    if not hasattr(response, "usage") or not response.usage:
        return
    from app.services.llm_service import extract_usage_details

    usage = extract_usage_details(response)
    total_tokens = int(usage.get("total_tokens", 0) or 0)
    ctx.total_tokens = int(getattr(ctx, "total_tokens", 0) or 0) + total_tokens
    for key in (
        "total_tokens",
        "input_tokens",
        "output_tokens",
        "cache_read_tokens",
        "cache_creation_tokens",
    ):
        task_key = f"_{key}"
        task_data[task_key] = int(task_data.get(task_key, 0) or 0) + int(
            usage.get(key, 0) or 0
        )

def _modify_tokens_used(ctx: Any) -> int:
    return modify_tokens_used(ctx)

def _modify_budget_multiplier(ctx: Any) -> int:
    return modify_budget_multiplier_for_context(ctx)

def _modify_token_budget_default(ctx: Any) -> int:
    return modify_token_budget_default(ctx)

def _modify_token_budget_hard(ctx: Any) -> int:
    return modify_token_budget_hard(ctx)

def _mark_modify_budget_exceeded(
    ctx: Any,
    *,
    call_type: str,
    estimated_tokens: int,
) -> None:
    mark_modify_budget_exceeded(
        ctx,
        call_type=call_type,
        estimated_tokens=estimated_tokens,
    )

def _ensure_modify_token_budget(
    ctx: Any,
    *,
    call_type: str,
    estimated_tokens: int,
) -> None:
    ensure_modify_token_budget(
        ctx,
        call_type=call_type,
        estimated_tokens=estimated_tokens,
    )

