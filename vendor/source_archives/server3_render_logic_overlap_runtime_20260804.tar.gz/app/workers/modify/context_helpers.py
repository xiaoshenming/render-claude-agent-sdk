"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.issue_detection import (
    _text_helper_literal_math_issues, _text_overflow_reused_center_issues,
    _core_modify_sanity_issues, _detect_modify_result_issues,
    _is_soft_static_layout_issue, _blocking_modify_result_issues,
    _defer_modify_tts_timing_blockers, _detect_static_layout_contract_issues,
)

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")

def _ts() -> str:
    return _timestamp()

def _slice_label(slice_index: int, scene_name: str = "") -> str:
    return _slice_label_impl(slice_index, scene_name)

def _hex_is_light(hex_value: str) -> bool | None:
    return _hex_is_light_impl(hex_value)

def _configured_color_scheme(ctx) -> int | None:
    value = (getattr(ctx, "task_data", {}) or {}).get("color_scheme")
    try:
        scheme = int(value)
    except (TypeError, ValueError):
        return None
    return scheme if scheme in (1, 2, 3, 4) else None

def _infer_source_color_scheme(original_code: str) -> int | None:
    for match in _BACKGROUND_ASSIGN_RE.finditer(original_code or ""):
        bg = match.group("hex").upper()
        if len(bg) == 4:
            bg = "#" + "".join(ch * 2 for ch in bg[1:])
        if bg in _COLOR_SCHEME_BY_BACKGROUND:
            return _COLOR_SCHEME_BY_BACKGROUND[bg]
        is_light = _hex_is_light(bg)
        if is_light is not None:
            return 1 if is_light else 3
    return None

def _color_scheme_for_modify_scan(ctx, original_code: str) -> int:
    # 二次修改以原片段主题为准；否则 pre_render_scan 默认浅色会把黑底切片改白。
    return (
        _infer_source_color_scheme(original_code)
        or _configured_color_scheme(ctx)
        or 1
    )

def _enforce_modify_tts_voice(ctx, code: str) -> tuple[str, str | None]:
    from app.workers.repair.tts_voice_contract import enforce_configured_tts_voice

    task_data = getattr(ctx, "task_data", {}) or {}
    return enforce_configured_tts_voice(
        code,
        enable_tts=bool(task_data.get("enable_tts")),
        tts_voice=str(task_data.get("tts_voice") or ""),
        voice_type=str(task_data.get("voice_type") or "system"),
        cosyvoice_id=str(task_data.get("cosyvoice_id") or ""),
        tts_voice_snapshot=task_data.get("tts_voice_snapshot"),
    )

