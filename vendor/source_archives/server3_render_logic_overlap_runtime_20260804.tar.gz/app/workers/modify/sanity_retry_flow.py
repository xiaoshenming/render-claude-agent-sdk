"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.context_helpers import (
    _ts, _slice_label, _hex_is_light, _configured_color_scheme,
    _infer_source_color_scheme, _color_scheme_for_modify_scan,
    _enforce_modify_tts_voice,
)

from app.workers.modify.patch_generation import (
    _mark_modify_semantic_rejected, _should_refine_modify_patch_failure,
    _format_modify_patch_refinement_section, generate_modify_patch, _generate_full_modify_code,
)

from app.workers.modify.sanity_helpers import (
    _is_font_resize_instruction, _normalize_for_noop_compare, _has_substantive_change,
    _find_font_resize_scale_guard_conflicts, _remove_font_resize_scale_guards, _call_name,
)

from app.workers.modify.issue_detection import (
    _text_helper_literal_math_issues, _text_overflow_reused_center_issues,
    _core_modify_sanity_issues, _detect_modify_result_issues,
    _is_soft_static_layout_issue, _blocking_modify_result_issues,
    _defer_modify_tts_timing_blockers, _detect_static_layout_contract_issues,
)

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")


































































async def _sanity_retry(
    ctx,
    sanity_issues: list, scene_name: str,
    original_code: str, instruction: str,
    new_code: str,
    enable_visual_overflow_fixes: bool = True,
) -> str:
    """健全性校验失败时，带反馈重新调 LLM"""
    import ast
    from app.workers.repair.pre_render_fixes import pre_render_scan

    task_data = getattr(ctx, "task_data", {}) or {}
    retry_counts = task_data.setdefault("_modify_sanity_retry_counts", {})
    scene_retry_count = int(retry_counts.get(scene_name, 0) or 0)
    if scene_retry_count >= 1:
        blocking_issues = _blocking_modify_result_issues(sanity_issues)
        if not blocking_issues:
            logger.warning(
                f"[MODIFY] [{_ts()}] {scene_name} "
                "重复 sanity 仅剩静态布局风险，转入渲染/视觉验收继续自动修复: "
                + "；".join(str(item) for item in sanity_issues[:3])
            )
            return new_code
        task_data["_non_retryable"] = True
        task_data["_error_type"] = "modify_sanity_repeated_issue"
        task_data["_error_stage"] = "modify_sanity_gate"
        task_data["last_error"] = (
            f"{scene_name} modify_sanity_repeated_issue: "
            + "；".join(str(item) for item in blocking_issues[:5])
        )
        raise Exception(task_data["last_error"])
    _ensure_modify_token_budget(
        ctx,
        call_type="modify_sanity_retry",
        estimated_tokens=MODIFY_SANITY_RETRY_TOKEN_ESTIMATE,
    )
    retry_counts[scene_name] = scene_retry_count + 1

    feedback = "；".join(sanity_issues)
    logger.warning(
        f"[MODIFY] [{_ts()}] 健全性校验失败: {feedback}")

    retry_prompt = (
        "你上次的修改有严重问题：\n"
        f"**{feedback}**\n\n"
        "请严格遵守以下规则重新修改：\n"
        f"- 类名必须保持为 {scene_name}\n"
        "- 不要删除任何 self.play() 或 self.wait() 调用\n"
        "- 除非用户明确要求更换背景/主题/配色，否则必须保留原代码的背景色和主题色\n"
        "- 不要使用 ImageMobject/SVGMobject\n"
        "- 只修改用户要求的部分\n\n"
        "- 如果反馈包含 visible_objects/place_non_overlapping，必须在 Scene 内维护 "
        "visible_objects 列表；新增或移动 Text/MathTex/点标/角标/边长标签后，"
        "先调用 place_non_overlapping(..., others=visible_objects, area=...)，"
        "再把对象 append 到 visible_objects。不要继续只靠 move_to/next_to/arrange "
        "密集硬摆。\n\n"
        "- 如果用户要求调整字体/字号/大小一致，必须同时处理会抵消字号修改的 "
        "scale_to_fit_width()/scale_to_fit_height()/fit_width 约束；"
        "不要只改 font_size 后保留旧的自动缩小代码。空间不够时，"
        "优先用换行、分组间距或布局区域调整解决。\n\n"
        "原始代码：\n"
        f"```python\n{original_code}\n```\n\n"
        f"用户修改要求：{instruction}\n\n"
        "直接输出修改后的完整 Python 代码"
    )
    try:
        from app.services.llm_service import get_modify_llm_manager
        llm_mgr_retry = get_modify_llm_manager()
        resp_retry, _ = await llm_mgr_retry.call(
            messages=[{
                "role": "user",
                "content": retry_prompt,
            }],
            max_tokens=65536,
            retry_budget=2,
            trace_job_id=getattr(ctx, "job_id", "unknown"),
            trace_call_type="modify_sanity_retry",
            trace_prompt_version=scene_name,
            trace_prompt_content=retry_prompt,
        )
        retry_content = (
            resp_retry.choices[0].message.content or "")
        retry_content = guard_ai_output(
            retry_content,
            scenario="render_modify_retry_output",
        )
        retry_code = code_validator.extract_python_code(
            retry_content)
        if retry_code:
            retry_code, _ = pre_render_scan(
                retry_code,
                color_scheme=_color_scheme_for_modify_scan(ctx, original_code),
                enable_visual_overflow_fixes=enable_visual_overflow_fixes,
            )
            retry_code, _ = _enforce_modify_tts_voice(ctx, retry_code)
            try:
                ast.parse(retry_code)
                new_code = retry_code
                logger.info(
                    f"[MODIFY] [{_ts()}] 健全性重试成功")
            except SyntaxError:
                logger.warning(
                    f"[MODIFY] [{_ts()}] "
                    f"健全性重试代码语法错误")
    except Exception as retry_err:
        logger.warning(
            f"[MODIFY] [{_ts()}] "
            f"健全性重试 LLM 调用失败: {retry_err}")
    return new_code

