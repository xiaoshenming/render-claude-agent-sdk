"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")
def _text_helper_literal_math_issues(code: str) -> list[str]:
    return text_helper_literal_math_issues(code, _TEXT_HELPER_NAMES, _INLINE_MATH_DELIMITER_RE)

def _text_overflow_reused_center_issues(code: str, instruction: str) -> list[str]:
    return text_overflow_reused_center_issues(code, instruction, _TEXT_OVERFLOW_INSTRUCTION_RE, _REUSED_TEXT_CENTER_RE)

def _core_modify_sanity_issues(
    original_code: str,
    new_code: str,
    scene_name: str,
) -> list[str]:
    issues: list[str] = []
    if not re.search(rf'class\s+{re.escape(scene_name)}\s*\(', new_code or ""):
        issues.append(
            f"目标类 {scene_name} 在修改后代码中不存在"
            "（可能被重命名或删除）"
        )

    orig_plays = len(re.findall(r'self\.play\s*\(', original_code or ""))
    new_plays = len(re.findall(r'self\.play\s*\(', new_code or ""))
    orig_waits = len(re.findall(r'self\.wait\s*\(', original_code or ""))
    new_waits = len(re.findall(r'self\.wait\s*\(', new_code or ""))
    if (orig_plays + orig_waits) > 0 and (new_plays + new_waits) == 0:
        issues.append(
            f"所有动画调用被删除: 原始有 {orig_plays} play + "
            f"{orig_waits} wait, 修改后全部消失"
        )

    ext_file_refs = re.findall(
        r'(?:ImageMobject|SVGMobject)\s*\(\s*["\']([^"\']+)["\']',
        new_code or "",
    )
    if ext_file_refs:
        issues.append(f"引用了不存在的外部文件: {ext_file_refs}")
    return issues

def _detect_modify_result_issues(
    original_code: str,
    new_code: str,
    instruction: str,
) -> list[str]:
    """发现 LLM 修改看似成功但视觉上等于无效的情况。"""
    issues: list[str] = []
    if _VISIBLE_CHANGE_RE.search(instruction or "") and not _has_substantive_change(
        original_code, new_code,
    ):
        issues.append("修改结果与原始代码没有实质变化")

    if _is_font_resize_instruction(instruction):
        conflicts = _find_font_resize_scale_guard_conflicts(new_code)
        if conflicts:
            issues.append(
                "字体已改大但仍保留自动缩小约束 "
                f"({', '.join(conflicts)})，渲染后会抵消字号修改"
            )
    issues.extend(_text_helper_literal_math_issues(new_code))
    issues.extend(_text_overflow_reused_center_issues(new_code, instruction))
    issues.extend(_detect_static_layout_contract_issues(new_code))
    return issues

def _is_soft_static_layout_issue(issue: str) -> bool:
    return is_soft_static_layout_issue(issue)

def _blocking_modify_result_issues(issues: list[str]) -> list[str]:
    """Return only issues that should hard-fail after one repair retry.

    Dense direct-positioning warnings are intentionally kept as repair prompts,
    then delegated to render/layout verification. They are risk signals, not a
    final customer-visible failure by themselves.
    """
    return blocking_modify_result_issues(issues)

def _defer_modify_tts_timing_blockers(code: str, slice_label: str) -> str | None:
    """Record TTS sync blockers without turning a modify job into final failure."""
    try:
        from app.workers.validation.generated_code_quality import (
            raise_for_tts_timing_blockers,
        )

        raise_for_tts_timing_blockers(code)
        return None
    except Exception as exc:
        reason = str(exc) or type(exc).__name__
        logger.warning(
            "[MODIFY] [%s] %s TTS静态同步门禁延后处理，不直接失败: %s",
            _ts(),
            slice_label,
            reason,
        )
        return reason

def _detect_static_layout_contract_issues(code: str) -> list[str]:
    try:
        from app.workers.validation.generated_code_quality import (
            inspect_generated_code_quality,
        )
    except Exception:
        return []

    messages: list[str] = []
    for issue in inspect_generated_code_quality(code):
        if issue.code not in _STATIC_LAYOUT_RETRY_CODES:
            continue
        messages.append(
            "布局风险：密集使用 move_to/next_to/arrange 直接定位但未维护 "
            "visible_objects；点标/角标/边长标签必须改用 "
            "place_non_overlapping(..., others=visible_objects, area=...) "
            "并在展示后 append"
        )
    return messages
