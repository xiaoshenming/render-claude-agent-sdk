"""二次修改 LLM token 预算与用量限制。"""

from typing import Any

from app.workers.modify.basic_helpers import (
    modify_budget_multiplier,
    modify_tokens_used,
)

MODIFY_LLM_TOKEN_BUDGET_DEFAULT = 120_000
MODIFY_LLM_TOKEN_BUDGET_HARD = 180_000
MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER = 4


class ModifyTokenBudgetExceeded(Exception):
    """Raised when an expensive modify LLM fallback would exceed the hard cap."""


def modify_budget_multiplier_for_context(ctx: Any) -> int:
    return modify_budget_multiplier(ctx, MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER)


def modify_token_budget_default(ctx: Any) -> int:
    return MODIFY_LLM_TOKEN_BUDGET_DEFAULT * modify_budget_multiplier_for_context(ctx)


def modify_token_budget_hard(ctx: Any) -> int:
    return MODIFY_LLM_TOKEN_BUDGET_HARD * modify_budget_multiplier_for_context(ctx)


def mark_modify_budget_exceeded(
    ctx: Any,
    *,
    call_type: str,
    estimated_tokens: int,
) -> None:
    task_data = getattr(ctx, "task_data", {}) or {}
    used = modify_tokens_used(ctx)
    default_budget = modify_token_budget_default(ctx)
    hard_budget = modify_token_budget_hard(ctx)
    task_data["_non_retryable"] = True
    task_data["_error_type"] = "modify_token_budget_exceeded"
    task_data["_error_stage"] = "modify_llm_budget"
    task_data["last_error"] = (
        "二次修改 LLM token 硬预算即将超限: "
        f"used={used}, estimated_next={estimated_tokens}, "
        f"hard={hard_budget}, call_type={call_type}"
    )
    task_data["_modify_token_budget"] = {
        "default": default_budget,
        "hard": hard_budget,
        "multiplier": modify_budget_multiplier_for_context(ctx),
        "used": used,
        "estimated_next": estimated_tokens,
        "call_type": call_type,
    }


def ensure_modify_token_budget(
    ctx: Any,
    *,
    call_type: str,
    estimated_tokens: int,
) -> None:
    used = modify_tokens_used(ctx)
    hard_budget = modify_token_budget_hard(ctx)
    if used + estimated_tokens <= hard_budget:
        return
    mark_modify_budget_exceeded(
        ctx,
        call_type=call_type,
        estimated_tokens=estimated_tokens,
    )
    raise ModifyTokenBudgetExceeded(
        f"modify_token_budget_exceeded: used={used}, "
        f"estimated_next={estimated_tokens}, "
        f"hard={hard_budget}, call_type={call_type}"
    )
