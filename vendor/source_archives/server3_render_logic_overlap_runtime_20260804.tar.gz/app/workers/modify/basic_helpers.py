"""Modify 流程的基础纯工具。"""
from datetime import datetime
import ast
import re

def timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

def slice_label(slice_index: int, scene_name: str = "") -> str:
    display_index = slice_index + 1
    return f"切片{display_index}(slice_{slice_index}, {scene_name})" if scene_name else f"切片{display_index}(slice_{slice_index})"

def hex_is_light(hex_value: str) -> bool | None:
    value = hex_value.strip().lstrip("#")
    if len(value) == 3: value = "".join(ch * 2 for ch in value)
    if len(value) not in (6, 8): return None
    try: r, g, b = int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)
    except ValueError: return None
    return ((0.299 * r + 0.587 * g + 0.114 * b) / 255.0) > 0.5

def is_font_resize_instruction(instruction: str, pattern) -> bool:
    return bool(pattern.search(instruction or ""))

def normalize_for_noop_compare(code: str) -> str:
    import re
    lines = []
    for raw_line in (code or "").splitlines():
        line = raw_line.strip()
        if not line or line == "# END" or line.startswith("#"): continue
        lines.append(re.sub(r"\s+", " ", line))
    return "\n".join(lines)

def call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name): return node.id
    if isinstance(node, ast.Attribute): return node.attr
    return ""

def text_helper_literal_math_issues(code: str, helper_names: frozenset[str], delimiter_re) -> list[str]:
    try: tree = ast.parse(code or "")
    except SyntaxError: return []
    issues = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or call_name(node.func) not in helper_names: continue
        first_arg = node.args[0] if node.args else None
        if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str) and delimiter_re.search(first_arg.value):
            issues.append("Text/safe_text_box 中仍保留 $...$ 或 \\(...\\) 数学标记，会原样显示成字符串；必须拆成 Text + MathTex 的 VGroup 或改用 MathTex。")
    return issues

def text_overflow_reused_center_issues(code: str, instruction: str, instruction_re, center_re) -> list[str]:
    if not instruction_re.search(instruction or "") or "place_non_overlapping(" in (code or ""): return []
    issues = []
    for match in center_re.finditer(code or ""):
        target, source = match.group("target"), match.group("source")
        if target != source:
            issues.append(f"文本/公式溢出修复后 {target} 仍复用 {source}.get_center() 的旧位置，没有重新做避让布局；必须用 place_non_overlapping 或明确安全区域避开图形/曲线。")
    return issues[:3]

def is_soft_static_layout_issue(issue: str) -> bool:
    text = str(issue or "")
    return "布局风险：密集使用 move_to/next_to/arrange" in text and ("visible_objects" in text or "place_non_overlapping" in text)

def blocking_modify_result_issues(issues: list[str]) -> list[str]:
    return [issue for issue in (issues or []) if not is_soft_static_layout_issue(issue)]

def modify_tokens_used(ctx) -> int:
    data = getattr(ctx, "task_data", {}) or {}
    return max(int(getattr(ctx, "total_tokens", 0) or 0), int(data.get("_total_tokens", 0) or 0))

def modify_budget_multiplier(ctx, maximum: int) -> int:
    data = getattr(ctx, "task_data", {}) or {}
    explicit = data.get("_modify_target_slice_count")
    if explicit is not None:
        try: count = int(explicit)
        except (TypeError, ValueError): count = 1
    else:
        indices = set()
        for item in data.get("modifications") or []:
            if isinstance(item, dict):
                try: indices.add(int(item.get("slice_index")))
                except (TypeError, ValueError): pass
        count = len(indices) or 1
    return max(1, min(count, maximum))

def find_font_resize_scale_guard_conflicts(code: str, text_assign_re) -> list[str]:
    lines, conflicts = (code or "").splitlines(), []
    for idx, line in enumerate(lines):
        match = text_assign_re.match(line)
        if not match: continue
        name, size = match.group("var"), int(match.group("size"))
        following = "\n".join(lines[idx + 1:idx + 7])
        if size >= 40 and (f"{name}.scale_to_fit_width(" in following or f"{name}.scale_to_fit_height(" in following or f"{name}.fit_width" in following): conflicts.append(name)
    return conflicts
