"""modify_worker.py — 二次修改任务主流程编排。

从 video_worker.py 提取的修改任务管线：
- ModifyContext: 修改任务共享上下文
- process_modify_task(): 主流程编排
- download_from_cos(): COS 文件下载
"""

import os
import time
import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Awaitable, Dict, List, Optional

from app.services import job_repository, modify_repository, ffmpeg_service
from app.services.storage_service import storage_service
from app.core.config import settings
from app.workers.aigc_postprocess import build_aigc_video_variants
from app.workers.validation import code_validator

logger = logging.getLogger("render")


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class ModifyContext:
    """修改任务共享上下文，在 process_modify_task 和 modify_one_slice 间传递"""
    job_id: str
    user_id: str
    job_script_dir: str
    job_output_dir: str
    aspect_ratio: str
    source_map: Dict[int, dict]
    task_data: Dict[str, Any]
    container_mgr: Any
    manim_media_root: str
    media_root: str
    job_timeout: int
    task_start_time: float
    # 回调: 检查任务是否被取消
    is_job_cancelled_fn: Callable[..., Awaitable[bool]]
    # 回调: 上传结果
    upload_results_fn: Callable[..., Awaitable]
    # 回调: 上传额外视频变体
    upload_video_variant_fn: Callable[..., Awaitable]
    # 回调: 最终失败处理
    handle_final_failure_fn: Callable[..., Awaitable]
    # 回调: 清理工作目录
    cleanup_fn: Callable
    total_tokens: int = 0

    def remaining_budget(self, default_timeout: int) -> int:
        elapsed = time.time() - self.task_start_time
        remaining = self.job_timeout - elapsed
        if remaining <= 0:
            return 1
        return max(1, min(default_timeout, int(remaining)))

    async def should_abort(self, stage: str) -> bool:
        elapsed = time.time() - self.task_start_time
        if elapsed > self.job_timeout:
            logger.warning(
                f"[MODIFY] [{_ts()}] job {self.job_id} "
                f"超时({elapsed:.0f}s>{self.job_timeout}s)"
                f" at {stage}")
            self.task_data["_non_retryable"] = True
            self.task_data["last_error"] = (
                f"修改任务超时({elapsed:.0f}s)")
            self.task_data["_error_type"] = "timeout"
            self.task_data["_error_stage"] = "task_watchdog"
            return True
        if await self.is_job_cancelled_fn(self.job_id):
            logger.info(
                f"[MODIFY] [{_ts()}] job {self.job_id} "
                f"已被终止 at {stage}")
            return True
        return False


async def download_from_cos(url: str, local_path: str):
    """从 COS URL 下载文件到本地"""
    import httpx
    for attempt in range(3):
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                with open(local_path, "wb") as f:
                    f.write(resp.content)
                return
        except Exception as e:
            if attempt == 2:
                raise Exception(
                    f"下载失败(重试3次): {url}, {e}")
            await asyncio.sleep(2)


async def _log_modify_writeback_quality_event(
    task_data: Dict[str, Any],
    *,
    event_type: str,
    context: Optional[Dict[str, Any]] = None,
    duration_ms: int | None = None,
    exception: Exception | None = None,
) -> None:
    """Record modify DB writeback and internal callback evidence without blocking."""
    context = context or {}
    payload = {
        "generation_mode": task_data.get("generation_mode") or "standard",
        "task_type": task_data.get("task_type") or "modify",
        "pipeline_mode": "SLICE",
        "modified_slice_count": context.get("modified_slice_count"),
        "source_slice_count": context.get("source_slice_count"),
        "result": event_type.replace("db_writeback_", ""),
    }
    evidence = {
        "job_id": context.get("job_id") or task_data.get("job_id"),
        "video_url": context.get("video_url"),
        "code_url": context.get("code_url"),
        "result_video_id": context.get("result_video_id"),
        "source_video_id": context.get("source_video_id"),
        "version": context.get("version"),
        "duration_ms": duration_ms,
    }
    if exception is not None:
        evidence.update({
            "error_type": type(exception).__name__,
            "error_message": str(exception)[:500],
        })
    callback_event_type = {
        "db_writeback_succeeded": "internal_callback_succeeded",
        "db_writeback_failed": "internal_callback_failed",
        "db_writeback_skipped": "internal_callback_skipped",
    }.get(event_type)
    try:
        from app.workers.task_dispatcher import log_render_quality_event

        await log_render_quality_event(
            event_type,
            task_data,
            payload=payload,
            evidence=evidence,
            video_id=context.get("result_video_id"),
        )
        if callback_event_type:
            await log_render_quality_event(
                callback_event_type,
                task_data,
                payload={
                    **payload,
                    "callback_mode": "modify_direct_db_writeback",
                    "source_event_type": event_type,
                },
                evidence=evidence,
                video_id=context.get("result_video_id"),
            )
    except Exception:
        logger.debug("Failed to record modify DB writeback quality event", exc_info=True)


async def process_modify_task(ctx: ModifyContext) -> str:
    """兼容入口：将依赖注入编排实现，便于测试替换下载/写回观测。"""
    from app.workers.modify.worker_pipeline import process_modify_task as run_pipeline
    return await run_pipeline(
        ctx, download_fn=download_from_cos,
        log_event_fn=_log_modify_writeback_quality_event,
    )
