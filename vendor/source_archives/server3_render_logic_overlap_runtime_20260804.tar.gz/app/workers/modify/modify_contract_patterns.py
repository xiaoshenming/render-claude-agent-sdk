"""二次修改流程使用的正则、令牌估算与主题常量。"""

import re

MODIFY_PATCH_TOKEN_ESTIMATE = 8_192
MODIFY_FULL_REWRITE_TOKEN_ESTIMATE = 65_536
MODIFY_SANITY_RETRY_TOKEN_ESTIMATE = 65_536
_FONT_RESIZE_RE = re.compile(r"(字体|字号|font_size|文字|文本).{0,24}(大|放大|加大|更大|一致|一样|同样|相同|保持)", re.IGNORECASE)
_VISIBLE_CHANGE_RE = re.compile(r"(修改|更改|调整|改成|改为|下移|上移|左移|右移|移动|放大|缩小|变大|变小|字体|字号|文字|文本|字符串|溢出|出框|越界|显示不全)", re.IGNORECASE)
_TEXT_ASSIGN_WITH_FONT_RE = re.compile(r"^\s*(?P<var>[A-Za-z_]\w*)\s*=\s*(?P<ctor>Text|MathTex)\([^#\n]*?font_size\s*=\s*(?P<size>\d+)")
_STATIC_LAYOUT_RETRY_CODES = frozenset({"dense_direct_positioning_without_registry"})
_TEXT_HELPER_NAMES = frozenset({"Text", "MarkupText", "safe_text_box", "create_text"})
_INLINE_MATH_DELIMITER_RE = re.compile(r"\$[^$\n]{0,120}\\[A-Za-z][^$\n]{0,120}\$|\\\([^\)\n]{0,120}\\[A-Za-z][^\)\n]{0,120}\\\)")
_TEXT_OVERFLOW_INSTRUCTION_RE = re.compile(r"(字符串|文本|文字|公式).{0,12}(溢出|出框|出界|越界|显示不全|截断)|(溢出|出框|出界|越界|显示不全|截断).{0,12}(字符串|文本|文字|公式)")
_REUSED_TEXT_CENTER_RE = re.compile(r"\b(?P<target>[A-Za-z_][A-Za-z0-9_]*)\.move_to\(\s*(?P<source>[A-Za-z_][A-Za-z0-9_]*)\.get_center\(\)\s*\)")
_BACKGROUND_ASSIGN_RE = re.compile(r"(?:self\.camera\.background_color|(?:GlobalConfig|cls|self)\.BG_COLOR|\bBG_COLOR\b|\bBACKGROUND_COLOR\b|\bBACKGROUND\b|\bBG\b)\s*=\s*(?P<quote>[\"'])(?P<hex>#[0-9A-Fa-f]{3,8})(?P=quote)")
_COLOR_SCHEME_BY_BACKGROUND = {"#F5F5F0": 1, "#FBF9FF": 2, "#000000": 3, "#1E1E2E": 4}
