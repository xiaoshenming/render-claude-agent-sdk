"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.context_helpers import (
    _ts, _slice_label, _hex_is_light, _configured_color_scheme,
    _infer_source_color_scheme, _color_scheme_for_modify_scan,
    _enforce_modify_tts_voice,
)

from app.workers.modify.patch_generation import (
    _mark_modify_semantic_rejected, _should_refine_modify_patch_failure,
    _format_modify_patch_refinement_section, generate_modify_patch, _generate_full_modify_code,
)

from app.workers.modify.sanity_helpers import (
    _is_font_resize_instruction, _normalize_for_noop_compare, _has_substantive_change,
    _find_font_resize_scale_guard_conflicts, _remove_font_resize_scale_guards, _call_name,
)

from app.workers.modify.issue_detection import (
    _text_helper_literal_math_issues, _text_overflow_reused_center_issues,
    _core_modify_sanity_issues, _detect_modify_result_issues,
    _is_soft_static_layout_issue, _blocking_modify_result_issues,
    _defer_modify_tts_timing_blockers, _detect_static_layout_contract_issues,
)

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")


































































async def _try_render_fix(
    ctx, new_code: str, render_error: str,
    instruction: str, slice_index: int,
    expected_scene_name: str,
    color_scheme: int | None = None,
) -> str:
    """渲染失败后尝试模式修复 + LLM 修复"""
    import ast
    task_data = ctx.task_data
    slice_label = _slice_label(slice_index, expected_scene_name)

    # 先尝试模式修复
    from app.workers.repair.error_patterns import try_pattern_fix
    pfixed, pdesc = try_pattern_fix(
        new_code, render_error,
        has_ctex='ctex' in new_code)
    if pfixed and pfixed != new_code:
        if not error_fixer.has_empty_call_after_truncation(
            pfixed
        ):
            try:
                ast.parse(pfixed)
                logger.info(
                    f"[MODIFY] [{_ts()}] "
                    f"{slice_label} 模式修复: {pdesc}")
                return pfixed
            except SyntaxError:
                pass

    # 模式修复失败 → LLM 修复（Search/Replace Patch 优先，完整代码兜底）
    common_repair_context = (
        f"## 渲染错误\n```\n"
        f"{render_error[:1500]}\n```\n\n"
        f"## 代码\n```python\n{new_code}\n```\n\n"
        f"## 用户修改指令\n{instruction}\n\n"
        "## LaTeX 常见错误修复规范\n"
        "- `\\dfrac`/`\\frac` 必须有两个 `{参数}`\n"
        "- `\\text`/`\\textbf` 内不能嵌套 `$...$` 数学模式\n"
        "- 检查所有 `{` `}` 大括号配对\n"
        "- 如果 LaTeX 公式过于复杂，考虑拆成多个简单的 MathTex"
    )
    patch_prompt = (
        f"{PATCH_ONLY_REPAIR_INSTRUCTIONS}\n"
        "以下 Manim 代码渲染时出错，请用最小 Search/Replace Patch 修复。"
        "SEARCH 片段必须逐字匹配原代码，不要改动用户修改指令之外的内容。\n\n"
        f"{common_repair_context}"
    )
    try:
        from app.services.llm_service import (
            get_modify_llm_manager, extract_usage_details)
        llm_mgr2 = get_modify_llm_manager()
        resp2, _ = await llm_mgr2.call(
            messages=[{
                "role": "user", "content": patch_prompt,
            }],
            max_tokens=8192, retry_budget=1,
            trace_job_id=getattr(ctx, "job_id", "unknown"),
            trace_call_type="modify_render_fix_patch",
            trace_prompt_version=expected_scene_name,
            trace_prompt_content=patch_prompt,
        )
        if hasattr(resp2, 'usage') and resp2.usage:
            _u2 = extract_usage_details(resp2)
            ctx.total_tokens += _u2["total_tokens"]
            task_data["_total_tokens"] += _u2["total_tokens"]
            task_data["_input_tokens"] += _u2["input_tokens"]
            task_data["_output_tokens"] += _u2["output_tokens"]
            task_data["_cache_read_tokens"] += _u2[
                "cache_read_tokens"]
            task_data["_cache_creation_tokens"] += _u2[
                "cache_creation_tokens"]
        fix_content = resp2.choices[0].message.content or ""
        fix_content = guard_ai_output(
            fix_content,
            scenario="render_modify_fix_output",
        )
        patch_result = apply_patch_or_fallback(
            new_code,
            fix_content,
            looks_like_fallback=lambda output: bool(
                error_fixer.extract_scene_code(output, expected_scene_name)
                or "class " in output
            ),
        )
        if patch_result.get("ok"):
            fix_content = patch_result["code"]
            logger.info(
                f"[MODIFY] [{_ts()}] {slice_label} Search/Replace Patch "
                f"已应用 {patch_result.get('applied_count', 0)} 个块")
        elif patch_result.get("fallback_raw"):
            fix_content = patch_result["fallback_raw"]
            logger.info(
                f"[MODIFY] [{_ts()}] {slice_label} Patch 请求返回完整代码，"
                f"转兜底校验: {patch_result.get('reason')}")
        else:
            fix_prompt = (
                "以下 Manim 代码渲染时出错，请修复。"
                "只输出修复后的完整 Python 代码。\n\n"
                f"## Search/Replace Patch 首选失败\n"
                f"- 原因: {str(patch_result.get('reason') or '')[:600]}\n\n"
                f"{common_repair_context}"
            )
            resp2, _ = await llm_mgr2.call(
                messages=[{
                    "role": "user", "content": fix_prompt,
                }],
                max_tokens=65536, retry_budget=1,
                trace_job_id=getattr(ctx, "job_id", "unknown"),
                trace_call_type="modify_render_fix",
                trace_prompt_version=expected_scene_name,
                trace_prompt_content=fix_prompt,
            )
            if hasattr(resp2, 'usage') and resp2.usage:
                _u2 = extract_usage_details(resp2)
                ctx.total_tokens += _u2["total_tokens"]
                task_data["_total_tokens"] += _u2["total_tokens"]
                task_data["_input_tokens"] += _u2["input_tokens"]
                task_data["_output_tokens"] += _u2["output_tokens"]
                task_data["_cache_read_tokens"] += _u2[
                    "cache_read_tokens"]
                task_data["_cache_creation_tokens"] += _u2[
                    "cache_creation_tokens"]
            fix_content = guard_ai_output(
                resp2.choices[0].message.content or "",
                scenario="render_modify_fix_output",
            )
        fix_code = code_validator.extract_python_code(fix_content)
        if fix_code:
            fix_code = error_fixer._restore_missing_header(new_code, fix_code)
            from app.workers.repair.pre_render_fixes import pre_render_scan
            fix_code, _ = pre_render_scan(
                fix_code,
                color_scheme=color_scheme or _configured_color_scheme(ctx) or 1,
            )
            fix_code, _ = _enforce_modify_tts_voice(ctx, fix_code)
            is_valid_code, invalid_reason = code_validator.validate_generated_code_shape(
                fix_code, expected_scene_name=expected_scene_name
            )
            if not is_valid_code:
                raise ValueError(invalid_reason)
            ast.parse(fix_code)
            task_data["_llm_fix_count"] += 1
            logger.info(
                f"[MODIFY] [{_ts()}] "
                f"{slice_label} LLM渲染修复成功")
            return fix_code
    except Exception as fix_err:
        logger.warning(
            f"[MODIFY] [{_ts()}] "
            f"{slice_label} LLM修复失败: {fix_err}")

    return new_code

