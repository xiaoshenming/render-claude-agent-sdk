"""modify_helpers.py — 单切片修改逻辑。

从 video_worker.py 提取的 modify_one_slice 嵌套函数，
负责：LLM 调用 → 健全性校验 → 语法修复 → 容器渲染 → COS 上传。
"""

import ast
import os
import re
import logging
from datetime import datetime
from typing import Any, Tuple

from app.workers.modify.context_helpers import (
    _ts, _slice_label, _hex_is_light, _configured_color_scheme,
    _infer_source_color_scheme, _color_scheme_for_modify_scan,
    _enforce_modify_tts_voice,
)

from app.workers.modify.sanity_retry_flow import _sanity_retry
from app.workers.modify.render_fix_flow import _try_render_fix

from app.workers.modify.patch_generation import (
    _mark_modify_semantic_rejected, _should_refine_modify_patch_failure,
    _format_modify_patch_refinement_section, generate_modify_patch, _generate_full_modify_code,
)

from app.workers.modify.sanity_helpers import (
    _is_font_resize_instruction, _normalize_for_noop_compare, _has_substantive_change,
    _find_font_resize_scale_guard_conflicts, _remove_font_resize_scale_guards, _call_name,
)

from app.workers.modify.issue_detection import (
    _text_helper_literal_math_issues, _text_overflow_reused_center_issues,
    _core_modify_sanity_issues, _detect_modify_result_issues,
    _is_soft_static_layout_issue, _blocking_modify_result_issues,
    _defer_modify_tts_timing_blockers, _detect_static_layout_contract_issues,
)

from app.workers.modify.budget_helpers import (
    _accumulate_llm_usage, _modify_tokens_used, _modify_budget_multiplier,
    _modify_token_budget_default, _modify_token_budget_hard,
    _mark_modify_budget_exceeded, _ensure_modify_token_budget,
)

from app.workers.modify.prompt_builders import _build_modify_prompt, _build_modify_patch_prompt
from app.workers.modify.render_slice import render_and_upload_modified_slice
from app.workers.modify.prepare_modify_code import prepare_modified_code

from app.workers.validation import code_validator

from app.workers.repair import error_fixer
from app.workers.repair.search_replace_patch import (
    PATCH_ONLY_REPAIR_INSTRUCTIONS,
    apply_modify_patch_or_fallback,
    apply_patch_or_fallback,
)

from app.workers.rendering import executor as render_executor
from app.services.ai_guardrails import guard_ai_output, guard_ai_user_input
from app.services import job_repository
from app.services.storage_service import storage_service
from app.workers.modify.basic_helpers import timestamp as _timestamp, slice_label as _slice_label_impl, hex_is_light as _hex_is_light_impl, is_font_resize_instruction, normalize_for_noop_compare, call_name, text_helper_literal_math_issues, text_overflow_reused_center_issues, is_soft_static_layout_issue, blocking_modify_result_issues, modify_tokens_used, modify_budget_multiplier, find_font_resize_scale_guard_conflicts
from app.workers.modify.modify_budget import (
    MODIFY_LLM_TOKEN_BUDGET_DEFAULT,
    MODIFY_LLM_TOKEN_BUDGET_HARD,
    MODIFY_LLM_TOKEN_BUDGET_MAX_MULTIPLIER,
    ModifyTokenBudgetExceeded,
    ensure_modify_token_budget,
    mark_modify_budget_exceeded,
    modify_budget_multiplier_for_context,
    modify_token_budget_default,
    modify_token_budget_hard,
)
from app.workers.modify.modify_contract_patterns import (
    MODIFY_PATCH_TOKEN_ESTIMATE, MODIFY_FULL_REWRITE_TOKEN_ESTIMATE,
    MODIFY_SANITY_RETRY_TOKEN_ESTIMATE, _FONT_RESIZE_RE, _VISIBLE_CHANGE_RE,
    _TEXT_ASSIGN_WITH_FONT_RE, _STATIC_LAYOUT_RETRY_CODES, _TEXT_HELPER_NAMES,
    _INLINE_MATH_DELIMITER_RE, _TEXT_OVERFLOW_INSTRUCTION_RE,
    _REUSED_TEXT_CENTER_RE, _BACKGROUND_ASSIGN_RE, _COLOR_SCHEME_BY_BACKGROUND,
)

logger = logging.getLogger("render")


































































async def modify_one_slice(
    ctx, slice_index: int, instruction: str
) -> Tuple[int, str, str, str, float]:
    """修改单个切片：LLM 生成 → 校验 → 渲染 → 上传。

    Args:
        ctx: ModifyContext 上下文
        slice_index: 切片索引
        instruction: 用户修改指令

    Returns:
        (slice_index, mp4_path, new_url, new_code, duration)
    """
    instruction, scene_name, slice_label, original_code, new_code = await prepare_modified_code(
        ctx, slice_index, instruction
    )
    task_data = ctx.task_data

    new_code = error_fixer._restore_missing_header(original_code, new_code)

    # 渲染前扫描（零成本修复中文标点、unicode escape 等）
    from app.workers.repair.pre_render_fixes import pre_render_scan
    enable_visual_overflow_fixes = not _is_font_resize_instruction(instruction)
    scan_color_scheme = _color_scheme_for_modify_scan(ctx, original_code)
    new_code, scan_fixes = pre_render_scan(
        new_code,
        color_scheme=scan_color_scheme,
        enable_visual_overflow_fixes=enable_visual_overflow_fixes,
    )
    new_code, resize_cleanup_fixes = _remove_font_resize_scale_guards(
        new_code,
        instruction,
    )
    scan_fixes.extend(resize_cleanup_fixes)
    new_code, tts_fix = _enforce_modify_tts_voice(ctx, new_code)
    if tts_fix:
        scan_fixes.append(tts_fix)
    guard_ai_output(new_code, scenario="render_modify_code_output")
    if scan_fixes:
        logger.info(
            f"[MODIFY] [{_ts()}] {slice_label} "
            f"渲染前扫描: {', '.join(scan_fixes)}")
    if ctx.task_data.get("enable_tts"):
        _defer_modify_tts_timing_blockers(new_code, slice_label)

    # ====== 健全性校验：对比原始代码，拒绝破坏性修改 ======
    sanity_issues = _core_modify_sanity_issues(
        original_code,
        new_code,
        scene_name,
    )
    sanity_issues.extend(
        _detect_modify_result_issues(
            original_code, new_code, instruction,
        )
    )

    # 如果有问题，带反馈重新调 LLM（最多重试 1 次）
    if sanity_issues:
        new_code = await _sanity_retry(
            ctx, sanity_issues, scene_name, original_code,
            instruction, new_code,
            enable_visual_overflow_fixes=enable_visual_overflow_fixes,
        )
        new_code, retry_scan_fixes = pre_render_scan(
            new_code,
            color_scheme=scan_color_scheme,
            enable_visual_overflow_fixes=enable_visual_overflow_fixes,
        )
        new_code, retry_resize_cleanup_fixes = _remove_font_resize_scale_guards(
            new_code,
            instruction,
        )
        retry_scan_fixes.extend(retry_resize_cleanup_fixes)
        new_code, retry_tts_fix = _enforce_modify_tts_voice(ctx, new_code)
        if retry_tts_fix:
            retry_scan_fixes.append(retry_tts_fix)
        if retry_scan_fixes:
            logger.info(
                f"[MODIFY] [{_ts()}] {slice_label} "
                f"健全性重试后扫描: {', '.join(retry_scan_fixes)}")
        if ctx.task_data.get("enable_tts"):
            _defer_modify_tts_timing_blockers(new_code, slice_label)
        remaining_issues = _core_modify_sanity_issues(
            original_code,
            new_code,
            scene_name,
        )
        remaining_issues.extend(_detect_modify_result_issues(
            original_code, new_code, instruction,
        ))
        blocking_issues = _blocking_modify_result_issues(remaining_issues)
        if blocking_issues:
            task_data["_non_retryable"] = True
            task_data["_error_type"] = "modify_sanity_repeated_issue"
            task_data["_error_stage"] = "modify_sanity_gate"
            task_data["_modify_sanity_repeated_issues"] = blocking_issues[:5]
            task_data["last_error"] = (
                f"{slice_label} modify_sanity_repeated_issue: "
                + "；".join(blocking_issues)
            )
            raise Exception(
                f"{slice_label} modify_sanity_repeated_issue: "
                + "；".join(blocking_issues)
            )
        if remaining_issues:
            logger.warning(
                f"[MODIFY] [{_ts()}] {slice_label} "
                "仍有静态布局风险，转入渲染/视觉验收继续自动修复: "
                + "；".join(remaining_issues[:3])
            )

    # 语法校验（带自动修复）
    try:
        ast.parse(new_code)
    except SyntaxError as syn_err:
        logger.warning(
            f"[MODIFY] [{_ts()}] {slice_label} "
            f"语法错误，尝试自动修复: {syn_err}")
        fixed = error_fixer.auto_fix_truncation(
            new_code, str(syn_err))
        if fixed:
            try:
                ast.parse(fixed)
                new_code = fixed
                logger.info(
                    f"[MODIFY] [{_ts()}] {slice_label}"
                    f" 截断补全修复成功")
            except SyntaxError:
                fixed = None
        if not fixed or new_code != fixed:
            full_fixed = await error_fixer.fix_syntax_error(
                new_code, str(syn_err), ctx.job_id,
                expected_scene_name=scene_name)
            if full_fixed:
                new_code = full_fixed
                logger.info(
                    f"[MODIFY] [{_ts()}] {slice_label}"
                    f" LLM语法修复成功")
            else:
                raise syn_err

    return await render_and_upload_modified_slice(
        ctx,
        slice_index=slice_index,
        slice_label=slice_label,
        scene_name=scene_name,
        instruction=instruction,
        new_code=new_code,
        scan_color_scheme=scan_color_scheme,
    )
