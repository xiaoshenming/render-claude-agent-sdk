"""Filesystem cleanup helpers for completed render jobs."""

import errno
import logging
import os
import shutil
import time
from datetime import datetime

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


class WorkerCleanupMixin:
    def _remove_tree_with_retries(
        self, path: str, label: str, max_attempts: int = 3,
        retry_delay: float = 0.2,
    ) -> None:
        if not path or not os.path.exists(path):
            return
        for attempt in range(1, max_attempts + 1):
            try:
                shutil.rmtree(path)
                logger.info("[CLEANUP] [%s] 已清理%s: %s", _ts(), label, path)
                return
            except OSError as exc:
                retryable = exc.errno == errno.ENOTEMPTY and attempt < max_attempts
                if retryable:
                    logger.warning(
                        "[CLEANUP] [%s] 清理%s遇到目录残留，第%s/%s次重试: %s",
                        _ts(), label, attempt, max_attempts, path,
                    )
                    time.sleep(retry_delay * attempt)
                    continue
                logger.exception("[CLEANUP] [%s] 清理%s失败: %s", _ts(), label, path)
                return
            except Exception:
                logger.exception("[CLEANUP] [%s] 清理%s失败: %s", _ts(), label, path)
                return

    def _cleanup_job_folder(self, job_media_dir: str, job_script_dir: str = None) -> None:
        self._remove_tree_with_retries(job_media_dir, "输出文件夹")
        if job_script_dir:
            self._remove_tree_with_retries(job_script_dir, "脚本文件夹")
