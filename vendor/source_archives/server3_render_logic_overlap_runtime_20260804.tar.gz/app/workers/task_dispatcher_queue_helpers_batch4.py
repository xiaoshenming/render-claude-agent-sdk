"""task_dispatcher.py — 消息队列任务调度与失败处理。

从 video_worker.py 提取的 RabbitMQ 消息处理逻辑：
- publish_to_retry_queue(): 发布到重试队列
- handle_final_failure(): 最终失败处理（写库 + 退积分）
- handle_task_failure(): 任务失败重试决策
- handle_task_exception(): 未捕获异常处理
- handle_message(): 消息消费主循环
"""

import json
import time
import asyncio
import hashlib
import logging
import re
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Optional

import aio_pika
from sqlalchemy import text

from app.services import job_repository
from app.core.config import settings
from app.workers.quality_rejection import mark_quality_rejected
try:
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )
except ModuleNotFoundError:
    repo_root = Path(__file__).resolve().parents[4]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from libs.contracts.video_task_message import (
        build_video_task_message,
        payload_from_task_data,
    )

logger = logging.getLogger("render")

MAX_FINAL_FAILURE_PERSIST_REDROPS = 3
_FINAL_FAILURE_PERSIST_FAILURE_COUNTS: dict[str, int] = {}
_ACTIVE_JOB_STATUSES = {"PLANNING", "PENDING", "PROCESSING"}


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


@dataclass
class DispatchContext:
    """消息调度所需的共享依赖"""
    channel: Any                 # aio_pika channel
    retry_queue_name: str
    max_retries: int
    manim_media_root: str
async def handle_final_failure_persist_failed(
    message: Any,
    task_data: Optional[Dict[str, Any]],
    *,
    queue_type: str,
    job_id: str,
    retry_count: int,
    error_msg: str | None,
    error_type: str | None,
    error_stage: str | None,
    persist_failure_reason: str = "handle_final_failure_returned_failed",
    nack_detail: str = "Final failure persist failed, message nacked for requeue",
    flush: bool = True,
) -> None:
    from app.workers.task_dispatcher import log_render_quality_event
    count, signature = _record_final_failure_persist_failure(
        task_data,
        job_id=job_id,
        error_type=error_type,
        error_stage=error_stage,
        error_msg=error_msg,
    )
    if count < MAX_FINAL_FAILURE_PERSIST_REDROPS:
        logger.error(
            "[QUEUE] [%s] [%s] 写库失败，nack重投: job_id=%s "
            "persist_failures=%s/%s",
            _ts(),
            queue_type,
            job_id,
            count,
            MAX_FINAL_FAILURE_PERSIST_REDROPS,
        )
        await nack_with_queue_evidence(
            message,
            task_data,
            stage="QUEUE_NACK",
            detail=nack_detail,
            queue_type=queue_type,
            job_id=job_id,
            retry_count=retry_count,
            requeue=True,
            flush=flush,
        )
        return

    logger.error(
        "[QUEUE] [%s] [%s] final failure persist poison guard triggered: "
        "job_id=%s error_type=%s error_stage=%s persist_failures=%s",
        _ts(),
        queue_type,
        job_id,
        error_type,
        error_stage,
        count,
        extra={
            "error_code": "final_failure_persist_failed",
            "error_stage": error_stage,
        },
    )
    event_task_data = dict(task_data or {})
    event_task_data.setdefault("job_id", job_id)
    event_task_data.setdefault("retry_count", retry_count)
    await log_render_quality_event(
        "final_failure_persist_failed",
        event_task_data,
        payload={
            "severity": "high",
            "queue_type": queue_type,
            "retry_count": retry_count,
            "max_retries": None,
            "persist_failure_count": count,
            "persist_failure_limit": MAX_FINAL_FAILURE_PERSIST_REDROPS,
            "failure_class": (task_data or {}).get("_failure_class"),
            "error_type": error_type,
            "error_stage": error_stage,
            "action": "ack_stop_redelivery",
        },
        evidence={
            "original_failure_message": error_msg,
            "persist_failure_reason": persist_failure_reason,
            "terminal_failure_signature": signature,
        },
    )
    await ack_with_queue_evidence(
        message,
        task_data,
        stage="QUEUE_ACK_FINAL_FAILURE_PERSIST_POISONED",
        detail=(
            "Final failure persist failed repeatedly; "
            "message acked to stop poison redelivery"
        ),
        queue_type=queue_type,
        job_id=job_id,
        retry_count=retry_count,
        flush=flush,
    )
async def _ensure_queue_ready(ctx: DispatchContext, queue_name: str) -> None:
    """Passive queue existence check before publishing a follow-up message.

    RabbitMQ accepts durable messages even when consumers are briefly at zero
    during worker restart/rebalance.  Treating consumer_count=0 as a publish
    failure turns a recoverable retry into a final job failure.
    """
    queue = await ctx.channel.declare_queue(queue_name, passive=True)
    declaration = getattr(queue, "declaration_result", None)
    consumer_count = getattr(declaration, "consumer_count", None)
    if consumer_count is not None and consumer_count <= 0:
        logger.warning(
            "[RETRY] [%s] RabbitMQ queue %s 当前 consumer_count=%s，"
            "仍发布持久化重试消息等待消费者恢复",
            _ts(),
            queue_name,
            consumer_count,
        )
async def log_mq_quality_event(
    event_type: str,
    task_data: Optional[Dict[str, Any]],
    *,
    queue_type: str | None = None,
    queue_name: str | None = None,
    routing_key: str | None = None,
    task_type: str | None = None,
    retry_count: int | None = None,
    max_retries: int | None = None,
    message_bytes: int | None = None,
    duration_ms: int | None = None,
    redelivered: bool | None = None,
    requeue: bool | None = None,
    result: str | None = None,
    detail: str | None = None,
    exception: Exception | None = None,
) -> None:
    """Best-effort insert into API-owned quality_events from render worker."""
    task_data = task_data or {}
    job_id = task_data.get("job_id")
    effective_retry_count = (
        retry_count
        if retry_count is not None
        else task_data.get("retry_count")
    )
    if effective_retry_count is None:
        effective_retry_count = 0
    effective_retry_count = _safe_int(effective_retry_count)

    payload = _without_none({
        "queue_type": queue_type,
        "queue_name": queue_name,
        "routing_key": routing_key,
        "task_type": task_type or task_data.get("task_type") or "normal",
        "retry_count": effective_retry_count,
        "max_retries": max_retries,
        "redelivered": redelivered,
        "requeue": requeue,
        "result": result,
    })
    evidence = _without_none({
        "detail": detail,
        "message_bytes": message_bytes,
        "duration_ms": duration_ms,
    })
    if exception is not None:
        evidence.update({
            "exception_type": type(exception).__name__,
            "exception_message": str(exception)[:500],
        })

    try:
        from app.database.database import AsyncSessionLocal, DATABASE_URL, engine

        session = AsyncSessionLocal()
        try:
            await session.execute(text("""
                INSERT INTO quality_events (
                    id, event_type, source, job_id, video_id, user_id,
                    request_id, trace_id, attempt_id,
                    payload, evidence, created_at
                ) VALUES (
                    :id, :event_type, :source, :job_id, :video_id, :user_id,
                    :request_id, :trace_id, :attempt_id,
                    :payload, :evidence, CURRENT_TIMESTAMP
                )
            """), {
                "id": str(uuid.uuid4()).replace("-", "")[:26],
                "event_type": event_type,
                "source": "render",
                "job_id": job_id,
                "video_id": task_data.get("video_id"),
                "user_id": task_data.get("user_id"),
                "request_id": task_data.get("request_id"),
                "trace_id": task_data.get("trace_id"),
                "attempt_id": _mq_attempt_id(
                    task_data,
                    job_id=job_id,
                    retry_count=effective_retry_count,
                ),
                "payload": json.dumps(payload, ensure_ascii=False, default=str),
                "evidence": json.dumps(evidence, ensure_ascii=False, default=str),
            })
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
            if str(DATABASE_URL).startswith("sqlite"):
                await engine.dispose()
    except Exception as event_error:
        logger.warning(
            "[MQ] [%s] 记录 MQ 生命周期质量事件失败: event=%s job_id=%s error=%s",
            _ts(), event_type, job_id, event_error,
        )
