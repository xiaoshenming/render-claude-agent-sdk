"""Startup recovery and duplicate delivery handling for active jobs."""

from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path
from app.workers.active_job_markers import ACTIVE_JOB_MARKER_GRACE_SECONDS
from app.workers.active_job_recovery_loader import (
    STALE_ACTIVE_JOB_MARKER_CLEANUP_ONLY,
    ActiveJobRecoveryLoaderMixin,
)

logger = logging.getLogger(__name__)


def _ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


class ActiveJobRecoveryMixin(ActiveJobRecoveryLoaderMixin):
    async def _recover_stale_active_job_markers_on_startup(self) -> int:
        """Requeue PROCESSING jobs whose active marker pid died during restart."""
        root = Path(self.locks_dir) / "active_jobs"
        if not root.exists():
            return 0
        recovered = 0
        for path in sorted(root.glob("*.json")):
            marker = None
            try:
                marker = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                try:
                    marker = {
                        "job_id": path.stem,
                        "pid": None,
                        "created_at": path.stat().st_mtime,
                        "corrupt": True,
                    }
                except OSError:
                    continue
            job_id = str((marker or {}).get("job_id") or path.stem)
            dead_pid = self._active_job_marker_dead_pid(marker)
            marker_age = self._active_marker_age_seconds(path, marker)
            live_marker_terminal_probe = (
                dead_pid is None
                and not (marker or {}).get("corrupt")
                and marker_age >= ACTIVE_JOB_MARKER_GRACE_SECONDS
            )
            if (
                dead_pid is None
                and not (marker or {}).get("corrupt")
                and not live_marker_terminal_probe
            ):
                continue

            recovery_claim_path = path.with_name(f"{path.name}.recovering")
            try:
                fd = os.open(
                    recovery_claim_path,
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                    0o644,
                )
                with os.fdopen(fd, "w", encoding="utf-8") as fh:
                    json.dump(
                        {
                            "job_id": job_id,
                            "pid": os.getpid(),
                            "created_at": time.time(),
                        },
                        fh,
                        ensure_ascii=False,
                    )
            except FileExistsError:
                continue
            except OSError:
                logger.warning(
                    "[QUEUE] [%s] stale active marker recovery claim failed: "
                    "job_id=%s marker=%s",
                    _ts(),
                    job_id,
                    path,
                )
                continue

            task_data = await self._load_recoverable_active_job_task_data(
                job_id,
                marker or {},
            )
            if task_data and task_data.get(STALE_ACTIVE_JOB_MARKER_CLEANUP_ONLY):
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
                except OSError:
                    logger.warning(
                        "[QUEUE] [%s] stale active terminal marker cleanup failed: "
                        "job_id=%s marker=%s reason=%s",
                        _ts(),
                        job_id,
                        path,
                        task_data.get("reason"),
                    )
                try:
                    recovery_claim_path.unlink()
                except FileNotFoundError:
                    pass
                except OSError:
                    logger.warning(
                        "[QUEUE] [%s] stale active marker recovery claim cleanup "
                        "failed after cleanup-only: job_id=%s claim=%s",
                        _ts(),
                        job_id,
                        recovery_claim_path,
                    )
                logger.info(
                    "[QUEUE] [%s] stale active marker cleaned without retry: "
                    "job_id=%s dead_pid=%s reason=%s marker=%s",
                    _ts(),
                    job_id,
                    dead_pid,
                    task_data.get("reason"),
                    path,
                )
                continue
            if live_marker_terminal_probe:
                try:
                    recovery_claim_path.unlink()
                except FileNotFoundError:
                    pass
                except OSError:
                    logger.warning(
                        "[QUEUE] [%s] live active marker recovery claim cleanup "
                        "failed after non-terminal probe: job_id=%s claim=%s",
                        _ts(),
                        job_id,
                        recovery_claim_path,
                    )
                logger.info(
                    "[QUEUE] [%s] live active marker kept after DB probe: "
                    "job_id=%s age=%.1fs marker=%s",
                    _ts(),
                    job_id,
                    marker_age,
                    path,
                )
                continue
            if not task_data:
                try:
                    recovery_claim_path.unlink()
                except FileNotFoundError:
                    pass
                except OSError:
                    logger.warning(
                        "[QUEUE] [%s] stale active marker recovery claim cleanup "
                        "failed: job_id=%s claim=%s",
                        _ts(),
                        job_id,
                        recovery_claim_path,
                    )
                continue
            try:
                await self._publish_to_retry_queue(task_data)
            except Exception as exc:
                failed_marker_path = path.with_name(
                    f"{path.name}.recovery_failed_{int(time.time())}"
                )
                try:
                    path.replace(failed_marker_path)
                except FileNotFoundError:
                    pass
                except OSError:
                    logger.warning(
                        "[QUEUE] [%s] stale active marker quarantine failed "
                        "after publish error: job_id=%s marker=%s",
                        _ts(),
                        job_id,
                        path,
                    )
                try:
                    recovery_claim_path.unlink()
                except FileNotFoundError:
                    pass
                except OSError:
                    logger.warning(
                        "[QUEUE] [%s] stale active marker recovery claim cleanup "
                        "failed after publish error: job_id=%s claim=%s",
                        _ts(),
                        job_id,
                        recovery_claim_path,
                    )
                logger.exception(
                    "[QUEUE] [%s] stale active marker recovery publish failed; "
                    "marker quarantined and consumer startup will continue: "
                    "job_id=%s dead_pid=%s error=%s quarantined=%s",
                    _ts(),
                    job_id,
                    dead_pid,
                    exc,
                    failed_marker_path,
                )
                continue
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                logger.warning(
                    "[QUEUE] [%s] stale active marker cleanup after recovery "
                    "failed: job_id=%s marker=%s",
                    _ts(),
                    job_id,
                    path,
                )
            try:
                recovery_claim_path.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                logger.warning(
                    "[QUEUE] [%s] stale active marker recovery claim cleanup "
                    "failed after publish: job_id=%s claim=%s",
                    _ts(),
                    job_id,
                    recovery_claim_path,
                )
            recovered += 1
            logger.warning(
                "[QUEUE] [%s] stale active job recovered to retry queue: "
                "job_id=%s dead_pid=%s retry=%s marker=%s",
                _ts(),
                job_id,
                dead_pid,
                task_data.get("retry_count"),
                path,
            )
        return recovered
