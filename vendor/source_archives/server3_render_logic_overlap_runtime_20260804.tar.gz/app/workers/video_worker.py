import asyncio
import logging
import subprocess
from datetime import datetime
from typing import Dict, Any, List, Optional

from app.services import job_repository, ffmpeg_service
from app.workers.rendering.container import (
    bind_container_lock_job,
    reset_container_lock_job,
)
from app.workers.task_dispatcher import DispatchContext
from app.workers import task_dispatcher
from app.workers import video_task_processor
from app.workers import worker_runtime_status
from app.workers.active_job_markers import ActiveJobMarkerMixin
from app.workers.active_job_recovery import ActiveJobRecoveryMixin
from app.workers.active_job_duplicate import ActiveJobDuplicateMixin
from app.workers.worker_task_policy import hard_timeout_for_task as _hard_timeout_for_task
from app.workers import worker_message_handler
from app.workers.worker_message_execution import MessageDependencies
from app.workers.worker_consumer import WorkerConsumerMixin
from app.workers.worker_admission import WorkerAdmissionMixin
from app.workers.worker_render_compat import WorkerRenderCompatMixin
from app.workers.worker_persistence_compat import WorkerPersistenceCompatMixin
from app.workers.worker_cleanup import WorkerCleanupMixin
from app.workers.worker_initialization import WorkerInitializationMixin
from app.workers.worker_modify_task import WorkerModifyTaskMixin
from app.core.structured_logging import (
    bind_log_context,
    configure_structured_logging,
    reset_log_context,
)

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
configure_structured_logging()


def _ts():
    """返回当前时间戳字符串，用于日志"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def _message_redelivered(message) -> bool:
    """Return True only when RabbitMQ explicitly marks the delivery as redelivered."""
    if getattr(message, "redelivered", None) is True:
        return True
    delivery = getattr(message, "delivery", None)
    if getattr(delivery, "redelivered", None) is True:
        return True
    return False


def _normalize_incoming_task_data(task_data: Dict[str, Any]) -> Dict[str, Any]:
    nested_payload = task_data.get("payload")
    if isinstance(nested_payload, dict):
        for key, value in nested_payload.items():
            task_data.setdefault(key, value)
    return task_data


def _merge_message_trace_context(task_data: Dict[str, Any], message) -> Dict[str, Any]:
    headers = getattr(message, "headers", None) or {}
    if not isinstance(headers, dict):
        headers = {}
    for key in ("request_id", "trace_id", "attempt_id"):
        if not task_data.get(key) and headers.get(key):
            task_data[key] = headers[key]
    return task_data


def _bind_message_log_context(task_data: Dict[str, Any]):
    return bind_log_context(
        request_id=task_data.get("request_id"),
        trace_id=task_data.get("trace_id"),
        job_id=task_data.get("job_id"),
        attempt_id=task_data.get("attempt_id"),
    )


def _accumulate_tokens(task_data: Dict[str, Any], response) -> int:
    """从 LLM response 提取详细 token 并累加到 task_data。返回 total_tokens。"""
    from app.services.llm_service import extract_usage_details
    u = extract_usage_details(response)
    task_data["_total_tokens"] = task_data.get("_total_tokens", 0) + u["total_tokens"]
    task_data["_input_tokens"] = task_data.get("_input_tokens", 0) + u["input_tokens"]
    task_data["_output_tokens"] = task_data.get("_output_tokens", 0) + u["output_tokens"]
    task_data["_cache_read_tokens"] = task_data.get("_cache_read_tokens", 0) + u["cache_read_tokens"]
    task_data["_cache_creation_tokens"] = task_data.get("_cache_creation_tokens", 0) + u["cache_creation_tokens"]
    return u["total_tokens"]


def _accumulate_tokens_from_dict(task_data: Dict[str, Any], usage_dict: dict) -> None:
    """从 dict（如流式 usage_collector）累加 token 到 task_data。"""
    for key in ("total_tokens", "input_tokens", "output_tokens",
                "cache_read_tokens", "cache_creation_tokens"):
        task_data[f"_{key}"] = task_data.get(f"_{key}", 0) + usage_dict.get(key, 0)


class VideoWorker(
    ActiveJobMarkerMixin,
    ActiveJobRecoveryMixin,
    ActiveJobDuplicateMixin,
    WorkerConsumerMixin,
    WorkerAdmissionMixin,
    WorkerRenderCompatMixin,
    WorkerPersistenceCompatMixin,
    WorkerCleanupMixin,
    WorkerInitializationMixin,
    WorkerModifyTaskMixin,
):
    """
    Host-side worker: produces manim scripts and delegates rendering to dedicated containers
    via `docker exec`. Contains detailed logs to help debug why a render/upload
    did not complete.
    """

    @property
    def _dispatch_ctx(self) -> DispatchContext:
        if self._dispatch_ctx_cache is None or self._dispatch_ctx_cache.channel is not self.channel:
            self._dispatch_ctx_cache = DispatchContext(
                channel=self.channel,
                retry_queue_name=self.retry_queue_name,
                max_retries=self.max_retries,
                manim_media_root=self.manim_media_root,
            )
        return self._dispatch_ctx_cache

    # ── 容器管理方法 — 委托给 container_mgr ──────────────
    def _cleanup_stale_locks_on_startup(self):
        self.container_mgr._cleanup_stale_locks_on_startup()

    async def get_container_status_summary(self) -> Dict[str, Any]:
        return await worker_runtime_status.get_container_status_summary(self)

    def _unavailable_queue_payload(self, error: str = "") -> Dict[str, Any]:
        return worker_runtime_status.unavailable_queue_payload(self, error)

    @staticmethod
    def _decl_int(declaration: Any, *names: str) -> int | str:
        return worker_runtime_status.declaration_int(declaration, *names)

    async def _queue_depth_for(self, queue_name: str) -> Dict[str, Any]:
        return await worker_runtime_status.queue_depth_for(self, queue_name)

    def _rabbitmq_management_queue_url(self, queue_name: str) -> tuple[str, tuple[str, str]] | None:
        return worker_runtime_status.rabbitmq_management_queue_url(queue_name)

    async def _queue_depth_for_management(self, queue_name: str) -> Dict[str, Any] | None:
        return await worker_runtime_status.queue_depth_for_management(self, queue_name)

    async def _get_queue_depth_summary(self) -> Dict[str, Any]:
        return await worker_runtime_status.get_queue_depth_summary(self)

    def get_queue_runtime_status(self) -> Dict[str, Any]:
        return worker_runtime_status.get_queue_runtime_status(self)
    async def _run_cmd_async(self, cmd: List[str], timeout: Optional[int] = None) -> subprocess.CompletedProcess:
        return await ffmpeg_service.run_cmd_async(cmd, timeout)

    def _run_cmd(self, cmd: List[str], timeout: Optional[int] = None) -> subprocess.CompletedProcess:
        return ffmpeg_service.run_cmd(cmd, timeout)







    async def _publish_to_retry_queue(self, task_data: Dict[str, Any]):
        await task_dispatcher.publish_to_retry_queue(self._dispatch_ctx, task_data)

    async def _handle_final_failure(self, job_id: str, error_msg: str, refund_points: int = 0, error_type: str = None, error_stage: str = None, retry_count: int = 0, task_data: dict = None) -> bool:
        return await task_dispatcher.handle_final_failure(
            self._dispatch_ctx, job_id, error_msg,
            refund_points=refund_points, error_type=error_type,
            error_stage=error_stage, retry_count=retry_count,
            task_data=task_data,
            update_job_status_fn=self._update_job_status)

    async def _upload_failed_code(self, job_id: str, task_data: dict):
        await job_repository.upload_failed_code(
            job_id, self.manim_media_root, persist_job_url=False)

    async def _handle_message(self, message, is_retry_queue: bool):
        deps = MessageDependencies(
            asyncio=asyncio,
            job_repository=job_repository,
            task_dispatcher=task_dispatcher,
            video_task_processor=video_task_processor,
            hard_timeout_for_task=_hard_timeout_for_task,
            bind_container_lock_job=bind_container_lock_job,
            reset_container_lock_job=reset_container_lock_job,
        )
        return await worker_message_handler.handle_message(
            self,
            message,
            is_retry_queue,
            deps=deps,
            normalize_task_data=_normalize_incoming_task_data,
            merge_trace_context=_merge_message_trace_context,
            message_redelivered=_message_redelivered,
            bind_log_context=_bind_message_log_context,
            reset_log_context=reset_log_context,
        )

    async def _handle_task_failure(self, message, task_data, job_id, retry_count, queue_type):
        await task_dispatcher.handle_task_failure(
            self._dispatch_ctx, message, task_data,
            job_id, retry_count, queue_type,
            update_job_status_fn=self._update_job_status)

    async def _handle_task_exception(self, message, task_data, job_id, retry_count, queue_type, exc):
        await task_dispatcher.handle_task_exception(
            self._dispatch_ctx, message, task_data,
            job_id, retry_count, queue_type, exc,
            update_job_status_fn=self._update_job_status)
# global instance
video_worker = VideoWorker()
