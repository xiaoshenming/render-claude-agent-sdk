"""Helpers for expected quality-gate rejections.

These failures are terminal for the job, but they are not infrastructure
errors.  Keep the original error_type for diagnosis while adding a stable
failure_class so logs and dashboards can separate them from runtime crashes.
"""

from __future__ import annotations

from typing import Any


QUALITY_REJECTION_ERROR_TYPES = {
    "content_safety",
    "core_visual_semantic_icon_fallback",
    "final_frame_visual_sufficiency_failed",
    "layout_repair_failed",
    "math_logic_repair_failed",
    "modify_post_quality_gate_failed",
    "post_modify_quality_gate_failed",
}

QUALITY_REJECTION_STAGES = {
    "final_visual_contract",
    "output_content_safety",
    "post_modify_quality_gate",
}

_CANONICAL_ERROR_TYPES = {
    "output_content_safety": "content_safety",
    "final_visual_contract": "final_frame_visual_sufficiency_failed",
    "post_modify_quality_gate": "modify_post_quality_gate_failed",
    "post_modify_quality_gate_failed": "modify_post_quality_gate_failed",
}

_DEFAULT_STAGE_BY_ERROR_TYPE = {
    "content_safety": "output_content_safety",
    "core_visual_semantic_icon_fallback": "final_visual_contract",
    "final_frame_visual_sufficiency_failed": "final_visual_contract",
    "modify_post_quality_gate_failed": "post_modify_quality_gate",
    "post_modify_quality_gate_failed": "post_modify_quality_gate",
}


def quality_rejection_code(
    *,
    error_type: Any = None,
    error_stage: Any = None,
    message: Any = None,
) -> str | None:
    """Return the original rejection code if this is a quality gate rejection."""
    error_type_value = str(error_type or "").strip()
    error_stage_value = str(error_stage or "").strip()
    text = f"{error_type_value} {error_stage_value} {message or ''}".lower()

    for code in QUALITY_REJECTION_ERROR_TYPES:
        if code in text:
            return code
    if error_stage_value in QUALITY_REJECTION_STAGES:
        return error_type_value or error_stage_value
    return None


def mark_quality_rejected(
    task_data: dict[str, Any] | None,
    *,
    error_type: Any = None,
    error_stage: Any = None,
    message: Any = None,
) -> bool:
    """Annotate task_data when a terminal failure is an expected quality rejection."""
    code = quality_rejection_code(
        error_type=error_type,
        error_stage=error_stage,
        message=message,
    )
    if not code:
        return False
    if task_data is not None:
        error_type_value = str(error_type or "").strip()
        error_stage_value = str(error_stage or "").strip()
        canonical_error_type = _CANONICAL_ERROR_TYPES.get(
            error_type_value or code,
            error_type_value or code,
        )
        canonical_stage = (
            error_stage_value
            or _DEFAULT_STAGE_BY_ERROR_TYPE.get(canonical_error_type)
            or _DEFAULT_STAGE_BY_ERROR_TYPE.get(code)
        )
        task_data["_non_retryable"] = True
        task_data["_failure_class"] = "quality_rejected"
        task_data["_quality_rejected"] = True
        task_data["_quality_rejection_code"] = code
        task_data["_quality_rejection_stage"] = canonical_stage or None
        task_data["_error_type"] = canonical_error_type
        if canonical_stage:
            task_data["_error_stage"] = canonical_stage
    return True
