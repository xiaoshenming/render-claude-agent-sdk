import asyncio
import os
import json
import uuid
import logging
from datetime import datetime, timezone

from contextlib import asynccontextmanager
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from typing import Optional
import aio_pika

from app.workers.video_worker import video_worker
from app.core.config import settings
from app.core.runtime_preflight import collect_static_preflight
from app.core.structured_logging import configure_structured_logging
from app.services.backend_health import backend_health_registry

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
configure_structured_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动时初始化渲染工作器
    logger.info("Starting video render worker...")
    from app.core.runtime_config.client import refresh_runtime_config_once

    await refresh_runtime_config_once(include_restart=True)

    async def runtime_config_refresh_loop():
        while True:
            await asyncio.sleep(5)
            await refresh_runtime_config_once()

    runtime_config_task = asyncio.create_task(runtime_config_refresh_loop())
    await video_worker.connect()

    # 在后台启动消费者
    consumer_task = asyncio.create_task(video_worker.start_consuming())

    yield

    # 关闭时清理资源
    logger.info("Shutting down video render worker...")
    runtime_config_task.cancel()
    try:
        await runtime_config_task
    except asyncio.CancelledError:
        pass
    await video_worker.stop_consuming()
    consumer_task.cancel()
    try:
        await consumer_task
    except asyncio.CancelledError:
        pass
    await video_worker.close()


app = FastAPI(
    title="Shuxuepai欧拉引擎",
    description="为教育保驾护航",
    version="5.1.8",
    lifespan=lifespan
)


@app.get("/health")
async def health_check():
    """健康检查端点"""
    queue_status = video_worker.get_queue_runtime_status()
    runtime_preflight = collect_static_preflight(settings)
    healthy = bool(queue_status["healthy"]) and bool(runtime_preflight["ready"])
    return {
        "status": "healthy" if healthy else "degraded",
        "node": os.getenv("NODE_NAME", "unknown"),
        "timestamp": datetime.utcnow().isoformat(),
        "rabbitmq": queue_status,
        "runtime_preflight": runtime_preflight,
    }


@app.get("/stats")
async def get_stats():
    """获取渲染服务统计信息"""
    return {
        "status": "running",
        "processed_jobs": video_worker.processed_jobs,
        "active_workers": 1,
        "rabbitmq": video_worker.get_queue_runtime_status(),
    }


def _authorize_internal_token(
    *,
    x_internal_token: str | None,
    authorization: str | None,
) -> None:
    expected = str(settings.WEBAPI_INTERNAL_TOKEN or "").strip()
    if not expected:
        return
    bearer_prefix = "Bearer "
    bearer_token = ""
    if authorization and authorization.startswith(bearer_prefix):
        bearer_token = authorization[len(bearer_prefix):].strip()
    provided = str(x_internal_token or bearer_token or "").strip()
    if provided != expected:
        raise HTTPException(status_code=403, detail="Invalid internal token")


def _cooldown_remaining_sec(cooldown_until: str | None) -> int:
    if not cooldown_until:
        return 0
    try:
        until = datetime.fromisoformat(str(cooldown_until))
    except ValueError:
        return 0
    if until.tzinfo is None:
        until = until.replace(tzinfo=timezone.utc)
    return max(0, int((until - datetime.now(timezone.utc)).total_seconds()))


def _backend_health_payload() -> dict:
    records = []
    for row in backend_health_registry.snapshot():
        remaining = _cooldown_remaining_sec(row.get("cooldown_until"))
        records.append({
            **row,
            "cooldown_remaining_sec": remaining,
            "cooling_down": remaining > 0,
        })
    return {
        "status": "ok",
        "record_count": len(records),
        "cooldown_count": sum(1 for row in records if row["cooling_down"]),
        "records": records,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/api/backend-health/status")
async def get_backend_health_status(
    x_internal_token: str | None = Header(default=None, alias="X-Internal-Token"),
    authorization: str | None = Header(default=None),
):
    """Return Render-side LLM backend cooldown state for admin operations."""
    _authorize_internal_token(
        x_internal_token=x_internal_token,
        authorization=authorization,
    )
    return _backend_health_payload()


@app.post("/api/backend-health/reset")
async def reset_backend_health(
    x_internal_token: str | None = Header(default=None, alias="X-Internal-Token"),
    authorization: str | None = Header(default=None),
):
    """Clear Render-side LLM backend cooldown state."""
    _authorize_internal_token(
        x_internal_token=x_internal_token,
        authorization=authorization,
    )
    before = _backend_health_payload()
    backend_health_registry.clear()
    return {
        "status": "ok",
        "cleared_count": before["record_count"],
        "cleared_cooldown_count": before["cooldown_count"],
        "records": before["records"],
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# 任务请求模型
class VideoGenerateRequest(BaseModel):
    prompt: str
    user_id: Optional[str] = "test_user"
    ai_model: Optional[str] = "qwen"
    color_scheme: Optional[int] = 1
    enable_tts: Optional[bool] = False
    # 系统 TTS 默认音色：阿里 CosyVoice 龙小夏
    tts_voice: Optional[str] = "longxiaoxia_v3"


@app.post("/api/generate")
async def generate_video(request: VideoGenerateRequest):
    """发送视频生成任务到队列"""
    job_id = str(uuid.uuid4())
    
    task_data = {
        "job_id": job_id,
        "user_id": request.user_id,
        "prompt": request.prompt,
        "ai_model": request.ai_model,
        "color_scheme": request.color_scheme,
        "enable_tts": request.enable_tts,
        "tts_voice": request.tts_voice,
        "retry_count": 0
    }
    
    try:
        message = aio_pika.Message(
            body=json.dumps(task_data).encode(),
            delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
            priority=5
        )
        await video_worker.channel.default_exchange.publish(
            message, 
            routing_key="video_generate_queue"
        )
        logger.info(f"任务已发送到队列: job_id={job_id}")
        return {"job_id": job_id, "status": "queued", "message": "任务已提交"}
    except Exception as e:
        logger.exception(f"发送任务失败: {e}")
        raise HTTPException(status_code=500, detail=f"发送任务失败: {str(e)}")


@app.get("/api/container-status")
async def get_container_status():
    """获取容器状态摘要"""
    try:
        summary = await video_worker.get_container_status_summary()
        return summary
    except Exception as e:
        logger.exception(f"获取容器状态失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
