from __future__ import annotations

import json
import re
from collections import Counter
from collections.abc import Iterable, Mapping
from datetime import date, datetime
from pathlib import Path
from typing import Any


Row = Mapping[str, Any]
Case = dict[str, Any]

SCHEMA_VERSION = 1
DEFAULT_LINE = "A"

_SECRET_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"sk-[A-Za-z0-9][A-Za-z0-9_-]*"), "[REDACTED]"),
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._-]+"), "Bearer [REDACTED]"),
    (
        re.compile(
            r"(?i)\b(api[_-]?key|secret|token|password|authorization)\b\s*[:=]\s*['\"]?[^,\s'\";)]+"
        ),
        r"\1=[REDACTED]",
    ),
)

_PRODUCTION_PATH_MARKERS = (
    "/opt/mathpi",
    "/var/lib/mathpi",
    "/home/ming/data/Project/NodeProject/chap5/shuxuepai",
)

_LANE_DIRS = {
    "slice_patch_pre_render": "slice",
    "layout_post_review": "layout",
    "math_logic_post_review": "math_logic",
}


def load_jsonl_rows(path: str | Path, *, limit: int | None = None) -> list[dict[str, Any]]:
    """Load pre-exported rows from JSONL. This function has no DB side effects."""

    rows: list[dict[str, Any]] = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
            if limit is not None and len(rows) >= limit:
                break
    return rows


def export_cases_from_jsonl(
    source_jsonl: str | Path,
    out_dir: str | Path,
    *,
    limit: int | None = None,
    today: date | None = None,
) -> dict[str, Any]:
    rows = load_jsonl_rows(source_jsonl, limit=limit)
    return export_cases_from_rows(rows, out_dir, today=today, limit=limit)


def export_cases_from_rows(
    rows: Iterable[Row],
    out_dir: str | Path,
    *,
    today: date | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    """Normalize already-read rows into repair-lab case artifacts.

    The exporter deliberately accepts only in-memory rows or JSONL input; it
    does not import SQLAlchemy, open DB connections, publish MQ messages, or
    write back production job state.
    """

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    export_date = today or date.today()

    case_entries: list[dict[str, Any]] = []
    lane_counts: Counter[str] = Counter()

    for index, row in enumerate(rows, start=1):
        if limit is not None and index > limit:
            break

        case = normalize_row_to_case(row, ordinal=index)
        lane = str(case["lane"])
        lane_counts[lane] += 1

        lane_dir = _LANE_DIRS.get(lane, _LANE_DIRS["slice_patch_pre_render"])
        case_dir = out_path / lane_dir / str(case["case_id"])
        case_dir.mkdir(parents=True, exist_ok=True)
        case_path = case_dir / "case.json"
        case_path.write_text(
            json.dumps(case, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        case_entries.append(
            {
                "case_id": case["case_id"],
                "lane": lane,
                "failure_code": case["failure"]["failure_code"],
                "selected_repair_skill": case["repair_spec"]["selected_repair_skill"],
                "path": str(case_path.relative_to(out_path)),
            }
        )

    daily_path = out_path / f"daily-{export_date.isoformat()}.md"
    daily_path.write_text(
        _render_daily_report(export_date, case_entries, lane_counts),
        encoding="utf-8",
    )

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "line": DEFAULT_LINE,
        "case_count": len(case_entries),
        "cases": case_entries,
        "daily_report_path": daily_path.name,
        "db_read_count": 0,
        "mq_publish_count": 0,
        "writeback_count": 0,
    }
    (out_path / "export_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


def normalize_row_to_case(row: Row, *, ordinal: int) -> Case:
    classification = _classify_row(row)
    lane = classification["lane"]
    failure_code = classification["failure_code"]
    selected_skill = classification["selected_repair_skill"]

    job_id = _clean_text(row.get("job_id") or row.get("jobId") or row.get("video_job_id") or f"row-{ordinal}")
    scene_name = _clean_text(row.get("scene_name") or row.get("scene") or row.get("target_scene") or "Scene_Unknown")
    case_id = _build_case_id(lane, job_id, scene_name, ordinal)

    prompt_summary = _clean_text(row.get("prompt") or row.get("prompt_summary") or "")
    code_summary = _clean_text(row.get("code_summary") or row.get("error_message") or row.get("traceback") or "")

    repair_spec = _build_repair_spec(scene_name, selected_skill, failure_code)

    return {
        "schema_version": SCHEMA_VERSION,
        "case_id": case_id,
        "source": {
            "env": _clean_text(row.get("env") or row.get("source_env") or "production"),
            "job_id": job_id,
            "scene_name": scene_name,
            "source_table": _clean_text(row.get("source_table") or row.get("table") or "jsonl_rows"),
            "source_id": _clean_text(row.get("source_id") or row.get("id") or f"row-{ordinal}"),
            "created_at": _clean_text(row.get("created_at") or row.get("updated_at") or ""),
        },
        "lane": lane,
        "failure": {
            "failure_code": failure_code,
            "stage": _clean_text(row.get("stage") or classification["stage"]),
            "signature": f"{lane}/{failure_code}",
            "attempt": _int_or_zero(row.get("attempt") or row.get("repair_attempt")),
            "terminal_status": _clean_text(row.get("terminal_status") or row.get("status") or "UNKNOWN"),
        },
        "input_artifacts": _build_input_artifacts(row, lane),
        "context": {
            "prompt_summary": prompt_summary,
            "code_summary": code_summary,
        },
        "repair_spec": repair_spec,
        "acceptance": dict(repair_spec["acceptance"]),
    }


def _classify_row(row: Row) -> dict[str, str]:
    raw = " ".join(
        str(row.get(key) or "")
        for key in (
            "failure_code",
            "signature",
            "stage",
            "error_message",
            "traceback",
            "code_summary",
        )
    ).lower()

    if "layout" in raw or "overlap" in raw or "frame_overflow" in raw:
        failure_code = "layout_frame_overflow" if "frame_overflow" in raw else "layout_overlap_error"
        return {
            "lane": "layout_post_review",
            "failure_code": failure_code,
            "stage": "POST_RENDER_FIX",
            "selected_repair_skill": "repair.layout_overlap_reflow",
        }

    if "math_logic" in raw or "hard issue" in raw or "latex" in raw or "mathtex" in raw or "formula" in raw:
        failure_code = "formula_text_boundary_error" if "latex" in raw or "mathtex" in raw or "formula" in raw else "math_logic_repair_failed"
        return {
            "lane": "math_logic_post_review",
            "failure_code": failure_code,
            "stage": "MATH_LOGIC_REVIEW",
            "selected_repair_skill": "repair.formula_text_boundary",
        }

    if "invalid_shape" in raw or "truncated" in raw or "截断" in raw:
        return {
            "lane": "slice_patch_pre_render",
            "failure_code": "truncated_or_invalid_shape",
            "stage": "PRE_RENDER_FIX",
            "selected_repair_skill": "repair.slice_full_regenerate_guard",
        }

    if "undefined" in raw or "nameerror" in raw:
        return {
            "lane": "slice_patch_pre_render",
            "failure_code": "undefined_name_fix",
            "stage": "PRE_RENDER_FIX",
            "selected_repair_skill": "repair.slice_patch_localization",
        }

    if "signature" in raw or "api" in raw:
        return {
            "lane": "slice_patch_pre_render",
            "failure_code": "manim_api_signature_fix",
            "stage": "PRE_RENDER_FIX",
            "selected_repair_skill": "repair.slice_patch_localization",
        }

    if "helper" in raw or "contract" in raw or "scope" in raw:
        return {
            "lane": "slice_patch_pre_render",
            "failure_code": "helper_contract_fix",
            "stage": "PRE_RENDER_FIX",
            "selected_repair_skill": "repair.slice_full_regenerate_guard",
        }

    return {
        "lane": "slice_patch_pre_render",
        "failure_code": "unknown_render_failure",
        "stage": "PRE_RENDER_FIX",
        "selected_repair_skill": "repair.slice_full_regenerate_guard",
    }


def _build_repair_spec(scene_name: str, selected_skill: str, failure_code: str) -> dict[str, Any]:
    if selected_skill == "repair.layout_overlap_reflow":
        preferred_actions = [
            "partition terminal objects into title/body/formula zones",
            "fade out stale intermediate geometry before final answer",
        ]
        forbidden_actions = [
            "do not reduce font size below readability threshold",
            "do not delete key formula or answer",
        ]
        acceptance = {
            "hard_issue_must_disappear": True,
            "overlap_count_must_not_increase": True,
            "max_overlap_ratio_lte": 0.08,
        }
    elif selected_skill == "repair.formula_text_boundary":
        preferred_actions = [
            "keep explanatory text and MathTex formulas in separate objects",
            "preserve mathematical meaning while fixing review hard issues",
        ]
        forbidden_actions = [
            "do not replace formulas with vague prose",
            "do not delete the target derivation step",
        ]
        acceptance = {
            "hard_issue_must_disappear": True,
            "new_hard_issue_count_must_be_zero": True,
        }
    else:
        preferred_actions = [
            "patch the smallest failing slice that explains the failure",
            "preserve scene structure outside the target slice",
        ]
        forbidden_actions = [
            "do not run the full user generation chain",
            "do not create or update production jobs",
        ]
        acceptance = {
            "hard_issue_must_disappear": True,
            "target_failure_code": failure_code,
        }

    return {
        "target_scene": scene_name,
        "selected_repair_skill": selected_skill,
        "preferred_actions": preferred_actions,
        "forbidden_actions": forbidden_actions,
        "acceptance": acceptance,
    }


def _build_input_artifacts(row: Row, lane: str) -> dict[str, str]:
    artifacts = {
        "script_path": _artifact_path(row.get("script_path") or row.get("code_path"), "script.py"),
        "baseline_video_path": _artifact_path(row.get("baseline_video_path") or row.get("video_path"), "baseline.mp4"),
    }

    if lane == "layout_post_review":
        artifacts.update(
            {
                "layout_decision_path": _artifact_path(row.get("layout_decision_path"), "layout_decision_before.json"),
                "bbox_path": _artifact_path(row.get("bbox_path"), "bbox_before.json"),
                "frame_path": _artifact_path(row.get("frame_path"), "frame_before.png"),
                "crop_path": _artifact_path(row.get("crop_path"), "problem_crop.png"),
            }
        )
    return artifacts


def _artifact_path(raw_path: Any, fallback_name: str) -> str:
    if isinstance(raw_path, str) and raw_path.strip():
        name = Path(raw_path).name or fallback_name
    else:
        name = fallback_name
    return f"input/{_slug(name, keep_dot=True)}"


def _build_case_id(lane: str, job_id: str, scene_name: str, ordinal: int) -> str:
    prefix = _LANE_DIRS.get(lane, "slice")
    return f"{prefix}-{_slug(job_id)[:32]}-{_slug(scene_name)[:32]}-{ordinal:03d}"


def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        text = value.isoformat()
    else:
        text = str(value)
    text = _redact_secrets(text)
    for marker in _PRODUCTION_PATH_MARKERS:
        text = text.replace(marker, "[PROD_PATH]")
    return text


def _redact_secrets(text: str) -> str:
    redacted = text
    for pattern, replacement in _SECRET_PATTERNS:
        redacted = pattern.sub(replacement, redacted)
    return redacted


def _slug(value: str, *, keep_dot: bool = False) -> str:
    safe = _redact_secrets(str(value))
    pattern = r"[^A-Za-z0-9_.-]+" if keep_dot else r"[^A-Za-z0-9_-]+"
    safe = re.sub(pattern, "-", safe).strip("-._")
    return safe or "unknown"


def _int_or_zero(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _render_daily_report(
    export_date: date,
    case_entries: list[dict[str, Any]],
    lane_counts: Counter[str],
) -> str:
    lines = [
        f"# Repair Lab A Daily Export {export_date.isoformat()}",
        "",
        f"- case_count: {len(case_entries)}",
        "- db_read_count: 0",
        "- mq_publish_count: 0",
        "- writeback_count: 0",
        "",
        "## Lanes",
        "",
    ]
    for lane in sorted(_LANE_DIRS):
        lines.append(f"- {lane}: {lane_counts.get(lane, 0)}")

    lines.extend(["", "## Cases", ""])
    for entry in case_entries:
        lines.append(
            "- {case_id} | {lane} | {failure_code} | {selected_repair_skill}".format(
                **entry
            )
        )
    lines.append("")
    return "\n".join(lines)
