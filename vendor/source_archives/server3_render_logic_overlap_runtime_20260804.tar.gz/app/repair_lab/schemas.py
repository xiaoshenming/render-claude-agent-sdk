"""repair_lab.schemas — validated local replay case structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import PureWindowsPath
from typing import Any, Literal, Mapping


schema_version = 1
SCHEMA_VERSION = schema_version

RepairLane = Literal[
    "slice_patch_pre_render",
    "layout_post_review",
    "math_logic_post_review",
]

REPAIR_LANES: set[str] = {
    "slice_patch_pre_render",
    "layout_post_review",
    "math_logic_post_review",
}

_REQUIRED_CASE_FIELDS = {
    "case_id",
    "source",
    "lane",
    "failure",
    "input_artifacts",
    "repair_spec",
    "acceptance",
}

_SENSITIVE_PATH_PREFIXES = (
    "/opt/mathpi",
    "/var/log",
    "/home",
    "/mnt/cos",
)

_SENSITIVE_URI_PREFIXES = (
    "s3://",
    "cos://",
)


@dataclass(kw_only=True)
class RepairLabCase:
    """Single repair-lab replay case.

    The model intentionally stays pure Python so unit tests and offline replay do
    not pull in Manim, DB, MQ, or FastAPI runtime dependencies.
    """

    case_id: str
    source: dict[str, Any]
    lane: RepairLane
    failure: dict[str, Any]
    input_artifacts: dict[str, str]
    repair_spec: dict[str, Any]
    acceptance: dict[str, Any]
    selected_repair_skill: str
    schema_version: int = SCHEMA_VERSION
    notes: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "RepairLabCase":
        data = dict(payload)
        missing = sorted(_REQUIRED_CASE_FIELDS - data.keys())
        if missing:
            raise ValueError(f"repair_lab case missing required fields: {missing}")

        version = int(data.get("schema_version", SCHEMA_VERSION))
        if version != SCHEMA_VERSION:
            raise ValueError(f"unsupported repair_lab schema_version: {version}")

        source = _require_mapping(data["source"], "source")
        failure = _require_mapping(data["failure"], "failure")
        repair_spec = _require_mapping(data["repair_spec"], "repair_spec")
        acceptance = _require_mapping(data["acceptance"], "acceptance")

        selected_repair_skill = data.get(
            "selected_repair_skill",
            repair_spec.get("selected_repair_skill"),
        )
        selected_repair_skill = _require_text(
            selected_repair_skill,
            "selected_repair_skill",
        )
        repair_spec.setdefault("selected_repair_skill", selected_repair_skill)

        lane = _require_text(data["lane"], "lane")
        if lane not in REPAIR_LANES:
            raise ValueError(f"unsupported repair_lab lane: {lane}")

        return cls(
            schema_version=version,
            case_id=_require_text(data["case_id"], "case_id"),
            source=source,
            lane=lane,  # type: ignore[arg-type]
            failure=failure,
            input_artifacts=_validate_input_artifacts(data["input_artifacts"]),
            repair_spec=repair_spec,
            acceptance=acceptance,
            selected_repair_skill=selected_repair_skill,
            notes=list(data.get("notes", []) or []),
        )

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "case_id": self.case_id,
            "source": dict(self.source),
            "lane": self.lane,
            "failure": dict(self.failure),
            "input_artifacts": dict(self.input_artifacts),
            "repair_spec": dict(self.repair_spec),
            "acceptance": dict(self.acceptance),
            "selected_repair_skill": self.selected_repair_skill,
        }
        if self.notes:
            payload["notes"] = list(self.notes)
        return payload


def validate_input_artifact_path(path: str) -> str:
    """Return a safe relative artifact path or raise ValueError."""

    if not isinstance(path, str):
        raise ValueError("input_artifacts paths must be strings")
    value = path.strip()
    if not value:
        raise ValueError("input_artifacts paths must not be empty")

    normalized = value.replace("\\", "/")
    lowered = normalized.lower()

    if lowered.startswith(_SENSITIVE_URI_PREFIXES):
        raise ValueError(f"input_artifacts path uses forbidden URI: {path}")
    if normalized.startswith("/") or PureWindowsPath(value).is_absolute():
        raise ValueError(f"input_artifacts path must be relative: {path}")
    if normalized.startswith("~"):
        raise ValueError(f"input_artifacts path must not use home expansion: {path}")
    for prefix in _SENSITIVE_PATH_PREFIXES:
        if lowered == prefix or lowered.startswith(f"{prefix}/"):
            raise ValueError(f"input_artifacts path is production-sensitive: {path}")

    parts = [part for part in normalized.split("/") if part and part != "."]
    if ".." in parts:
        raise ValueError(f"input_artifacts path must not contain '..': {path}")

    return value


def _validate_input_artifacts(value: Any) -> dict[str, str]:
    artifacts = _require_mapping(value, "input_artifacts")
    if not artifacts:
        raise ValueError("input_artifacts must not be empty")
    return {
        _require_text(name, "input_artifacts key"): validate_input_artifact_path(path)
        for name, path in artifacts.items()
    }


def _require_mapping(value: Any, field_name: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name} must be an object")
    return dict(value)


def _require_text(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    return value.strip()
