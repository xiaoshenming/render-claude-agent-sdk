"""A-line repair-lab Manim Docker video verification."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Mapping
from app.repair_lab.docker_tts_env import docker_tts_env_args, docker_tts_lock_mount_args
from app.repair_lab.scene_discovery import (
    base_name as _base_name,
    default_custom_services_dir as _default_custom_services_dir,
    default_render_assets_dir as _default_render_assets_dir,
    docker_container_name as _docker_container_name,
    find_rendered_mp4 as _find_rendered_mp4,
    force_remove_docker_container as _force_remove_docker_container,
    is_renderable_scene_class as _is_renderable_scene_class,
    resolve_scene_name_for_script as _resolve_scene_name_for_script,
    scene_class_names as _scene_class_names,
    scene_class_names_by_regex as _scene_class_names_by_regex,
    scene_name_from_score as _scene_name_from_score,
)
from app.repair_lab.render_output_helpers import render_summary_markdown, write_json


def run_manim_docker_render(
    *,
    script_path: str | Path,
    scene_name: str,
    output_dir: str | Path,
    image: str | None = None,
    network: str | None = None,
    timeout_sec: int | None = None,
    custom_services_dir: str | Path | None = None,
    render_assets_dir: str | Path | None = None,
    isolated_runtime_compat: bool = True,
    enable_tts: bool = False,
    runner: Runner = subprocess.run,
) -> dict[str, Any]:
    """Render one repaired Manim scene in Docker and write check evidence."""

    source_script = Path(script_path)
    out_dir = Path(output_dir)
    work_dir = out_dir / "work"
    media_dir = out_dir / "media"
    out_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)
    media_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(media_dir, 0o777)
    except OSError:
        pass

    resolved_image = (
        image
        or os.environ.get("REPAIR_LAB_A_MANIM_IMAGE")
        or os.environ.get("VIDEO_QUALITY_REPAIR_LAB_MANIM_IMAGE")
        or "mathpi-manim-worker:test"
    )
    resolved_network = (
        network
        or os.environ.get("REPAIR_LAB_A_DOCKER_NETWORK")
        or os.environ.get("VIDEO_QUALITY_REPAIR_LAB_DOCKER_NETWORK")
        or "none"
    )
    resolved_timeout = int(
        timeout_sec
        or os.environ.get("REPAIR_LAB_A_DOCKER_TIMEOUT_SEC")
        or os.environ.get("VIDEO_QUALITY_REPAIR_LAB_DOCKER_TIMEOUT_SEC")
        or "240",
    )
    resolved_custom_services = Path(
        custom_services_dir
        or os.environ.get("REPAIR_LAB_A_CUSTOM_SERVICES_DIR")
        or os.environ.get("VIDEO_QUALITY_REPAIR_LAB_CUSTOM_SERVICES_DIR")
        or _default_custom_services_dir(),
    )
    resolved_render_assets = Path(
        render_assets_dir
        or os.environ.get("REPAIR_LAB_A_RENDER_ASSETS_DIR")
        or os.environ.get("VIDEO_QUALITY_REPAIR_LAB_RENDER_ASSETS_DIR")
        or _default_render_assets_dir(),
    )

    log_path = out_dir / "render.log"
    candidate_path = work_dir / "candidate.py"
    check_path = out_dir / "docker_render_check.json"
    expected_mp4_path = media_dir / "videos" / "candidate" / "480p15" / f"{scene_name}.mp4"
    container_name = _docker_container_name(out_dir, scene_name)

    if not _SCENE_NAME_RE.match(scene_name):
        payload = _render_payload(
            render_ok=False,
            scene_name=scene_name,
            image=resolved_image,
            network=resolved_network,
            returncode=None,
            mp4_path=expected_mp4_path,
            log_path=log_path,
            check_path=check_path,
            custom_services_mounted=False,
            assets_mounted=False,
            assets_dir=resolved_render_assets,
            enable_tts=enable_tts,
            errors=["invalid_scene_name_for_docker_render"],
        )
        _write_json(check_path, payload)
        return payload

    candidate_path.write_text(
        prepare_candidate_script_for_manim(
            source_script.read_text(encoding="utf-8"),
            isolated_runtime_compat=isolated_runtime_compat,
            enable_tts=enable_tts,
        ),
        encoding="utf-8",
    )

    cmd = [
        "docker",
        "run",
        "--rm",
        "--name",
        container_name,
        "--network",
        resolved_network,
        "--entrypoint",
        "bash",
        "-v",
        f"{work_dir.resolve()}:/work:ro",
        "-v",
        f"{media_dir.resolve()}:/media:rw",
    ]
    if enable_tts:
        cmd.extend(_docker_tts_lock_mount_args())
    custom_services_mounted = resolved_custom_services.exists()
    if custom_services_mounted:
        cmd.extend(
            [
                "-v",
                f"{resolved_custom_services.resolve()}:/manim_media/custom_services:ro",
                "-e",
                "PYTHONPATH=/manim_media",
            ],
        )
    assets_mounted = resolved_render_assets.exists()
    if assets_mounted:
        cmd.extend(
            [
                "-v",
                f"{resolved_render_assets.resolve()}:/manim_media/assets:ro",
                "-e",
                "MATHPI_RENDER_ASSETS_DIR=/manim_media/assets",
            ],
        )
    cmd.extend(_docker_tts_env_args(enable_tts=enable_tts))
    cmd.extend(
        [
            resolved_image,
            "-lc",
            f"cd /work && manim candidate.py {scene_name} -ql --media_dir /media --disable_caching",
        ],
    )

    returncode: int | None = None
    errors: list[str] = []
    try:
        with log_path.open("w", encoding="utf-8") as log:
            completed = runner(
                cmd,
                stdout=log,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=resolved_timeout,
                check=False,
            )
        returncode = completed.returncode
    except subprocess.TimeoutExpired:
        errors.append(f"docker_render_timeout:{resolved_timeout}s")
        _force_remove_docker_container(container_name, runner=runner)
    except FileNotFoundError as exc:
        errors.append(f"docker_not_available:{exc}")

    mp4_path = _find_rendered_mp4(media_dir, scene_name, expected_mp4_path)
    mp4_bytes = mp4_path.stat().st_size if mp4_path.exists() else 0
    render_ok = returncode == 0 and mp4_bytes > 0
    if returncode not in (0, None):
        errors.append(f"docker_render_returncode:{returncode}")
    if returncode == 0 and mp4_bytes <= 0:
        errors.append("docker_render_missing_mp4")

    payload = _render_payload(
        render_ok=render_ok,
        scene_name=scene_name,
        image=resolved_image,
        network=resolved_network,
        returncode=returncode,
        mp4_path=mp4_path,
        log_path=log_path,
        check_path=check_path,
        custom_services_mounted=custom_services_mounted,
        assets_mounted=assets_mounted,
        assets_dir=resolved_render_assets,
        enable_tts=enable_tts,
        errors=errors,
    )
    _write_json(check_path, payload)
    return payload

