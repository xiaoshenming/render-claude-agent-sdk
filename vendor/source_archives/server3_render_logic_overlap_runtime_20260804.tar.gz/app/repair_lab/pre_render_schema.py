"""Pure-Python schema for pre-render repair-lab cases."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import PureWindowsPath
from typing import Any, Mapping


PRE_RENDER_REPAIR_CASE_SCHEMA_VERSION = "pre_render_repair_case.v1"

_REQUIRED_FIELDS = {
    "schema_version",
    "case_id",
    "scene_name",
    "candidate_path",
    "source",
    "failure",
    "repair_contract",
    "acceptance",
}

_FORBIDDEN_URI_PREFIXES = ("cos://", "s3://")
_CASE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]*$")


@dataclass(kw_only=True)
class PreRenderRepairCase:
    """Single pre-render point-repair case.

    The model intentionally has no pydantic/runtime dependencies so tests and
    local lab runs stay offline.
    """

    case_id: str
    scene_name: str
    candidate_path: str
    source: dict[str, Any]
    failure: dict[str, Any]
    repair_contract: dict[str, Any]
    acceptance: dict[str, Any]
    schema_version: str = PRE_RENDER_REPAIR_CASE_SCHEMA_VERSION

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "PreRenderRepairCase":
        data = dict(payload)
        missing = sorted(_REQUIRED_FIELDS - data.keys())
        if missing:
            raise ValueError(
                "pre_render repair case missing required fields: "
                + ", ".join(missing)
            )

        schema_version = _require_text(data["schema_version"], "schema_version")
        if schema_version != PRE_RENDER_REPAIR_CASE_SCHEMA_VERSION:
            raise ValueError(f"unsupported pre_render schema_version: {schema_version}")

        case_id = _validate_case_id(data["case_id"])
        scene_name = _require_text(data["scene_name"], "scene_name")
        candidate_path = validate_candidate_path(data["candidate_path"])

        return cls(
            schema_version=schema_version,
            case_id=case_id,
            scene_name=scene_name,
            candidate_path=candidate_path,
            source=_require_mapping(data["source"], "source"),
            failure=_require_mapping(data["failure"], "failure"),
            repair_contract=_require_mapping(
                data["repair_contract"],
                "repair_contract",
            ),
            acceptance=_require_mapping(data["acceptance"], "acceptance"),
        )

    @property
    def max_rounds(self) -> int:
        value = self.repair_contract.get("max_rounds", 1)
        try:
            rounds = int(value)
        except (TypeError, ValueError):
            return 1
        return max(1, rounds)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "case_id": self.case_id,
            "scene_name": self.scene_name,
            "candidate_path": self.candidate_path,
            "source": dict(self.source),
            "failure": dict(self.failure),
            "repair_contract": dict(self.repair_contract),
            "acceptance": dict(self.acceptance),
        }


def validate_candidate_path(path: Any) -> str:
    if not isinstance(path, str):
        raise ValueError("candidate_path must be a string")
    value = path.strip()
    if not value:
        raise ValueError("candidate_path must not be empty")

    normalized = value.replace("\\", "/")
    lowered = normalized.lower()
    if lowered.startswith(_FORBIDDEN_URI_PREFIXES):
        raise ValueError(f"candidate_path uses forbidden URI: {path}")
    if normalized.startswith("/") or PureWindowsPath(value).is_absolute():
        raise ValueError(f"candidate_path must be relative: {path}")
    if normalized.startswith("~"):
        raise ValueError(f"candidate_path must not use home expansion: {path}")

    parts = [part for part in normalized.split("/") if part and part != "."]
    if ".." in parts:
        raise ValueError(f"candidate_path must not contain '..': {path}")

    return normalized


def _validate_case_id(value: Any) -> str:
    case_id = _require_text(value, "case_id")
    if not _CASE_ID_RE.fullmatch(case_id):
        raise ValueError(f"case_id contains unsupported characters: {case_id}")
    return case_id


def _require_mapping(value: Any, field_name: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name} must be an object")
    return dict(value)


def _require_text(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    return value.strip()


__all__ = [
    "PRE_RENDER_REPAIR_CASE_SCHEMA_VERSION",
    "PreRenderRepairCase",
    "validate_candidate_path",
]
