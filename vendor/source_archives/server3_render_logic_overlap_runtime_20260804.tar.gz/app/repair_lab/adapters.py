"""Deterministic repair adapters for A-line point tests.

The functions here are intentionally local/offline: no DB writes, no MQ
publishes, no Manim render. They provide repair_fn hooks for repair_lab
runners and keep production pipeline code untouched.
"""

from __future__ import annotations

import ast
import difflib
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any


PreRenderScanFn = Callable[..., Any]


def slice_local_pre_render_adapter(
    case: Any,
    *,
    script: str,
    target_scene: str,
    out_dir: Path,
    pre_render_scan_fn: PreRenderScanFn | None = None,
) -> dict[str, Any]:
    """Run deterministic pre-render fixes while preserving non-target scenes.

    A-line `repair.slice_patch_localization` is a point-to-point contract: it may
    repair the target scene, but it must not drift other scenes. The broad
    production `pre_render_scan` is useful but can touch the whole script, so the
    adapter localizes its output back to the target Scene before scoring.
    """

    del out_dir
    if not target_scene:
        return {
            "script": script,
            "repair_method": "target_scene_missing",
            "failure_signature_removed": False,
            "fixes": [],
        }

    syntax_fixed, syntax_fixes = _apply_whole_script_syntax_point_fixes(
        script,
        target_scene,
        case,
    )
    if syntax_fixes:
        syntax_fixed, render_fixes = apply_render_compat_point_fixes(
            syntax_fixed,
            target_scene,
            case,
        )
        syntax_fixes = syntax_fixes + render_fixes
        syntax_method = (
            "target_scene_syntax_point_fix"
            if _target_scene_class_exists_by_text(script, target_scene)
            else "whole_script_syntax_point_fix"
        )
        return {
            "script": syntax_fixed,
            "repair_method": syntax_method,
            "preserves_named_scene_blocks": syntax_method
            == "whole_script_syntax_point_fix",
            "failure_signature_removed": _failure_removed(
                before=script,
                after=syntax_fixed,
                signature=_case_text(case, "failure", "signature"),
                failure_code=_case_text(case, "failure", "failure_code"),
                error_type=_case_text(case, "failure", "error_type"),
                fixes=syntax_fixes,
            ),
            "fixes": syntax_fixes,
        }

    tail_fixed, tail_fixes = _apply_target_scene_tail_trim(script, target_scene, case)
    if tail_fixes:
        tail_fixed, render_fixes = apply_render_compat_point_fixes(
            tail_fixed,
            target_scene,
            case,
        )
        tail_fixes = tail_fixes + render_fixes
        return {
            "script": tail_fixed,
            "repair_method": "target_scene_tail_trim",
            "failure_signature_removed": True,
            "fixes": tail_fixes,
        }

    route_method = _non_local_route_method(case)
    if route_method:
        return {
            "script": script,
            "repair_method": route_method,
            "failure_signature_removed": False,
            "fixes": [],
        }

    scan_fn = pre_render_scan_fn or _import_default_pre_render_scan()
    if scan_fn is None:
        return {
            "script": script,
            "repair_method": "pre_render_scan_import_failed",
            "failure_signature_removed": False,
            "fixes": [],
        }

    original_block = _extract_scene_block(script, target_scene)
    if original_block is None:
        return {
            "script": script,
            "repair_method": "target_scene_not_found",
            "failure_signature_removed": False,
            "fixes": [],
        }

    try:
        scan_result = scan_fn(script)
    except Exception as exc:
        return {
            "script": script,
            "repair_method": "target_scene_pre_render_scan_error",
            "failure_signature_removed": False,
            "fixes": [],
            "error": repr(exc),
        }

    fixed_script, fixes = _scan_result_parts(scan_result)
    if not fixed_script or fixed_script == script:
        localized, point_fixes = _apply_point_fixes_to_script(
            script,
            original_block,
            case,
        )
        if not point_fixes:
            localized = script
        localized, render_fixes = apply_render_compat_point_fixes(
            localized,
            target_scene,
            case,
        )
        all_point_fixes = point_fixes + render_fixes
        if all_point_fixes:
            return {
                "script": localized,
                "repair_method": (
                    "target_scene_point_fix"
                    if point_fixes
                    else "target_scene_render_compat_point_fix"
                ),
                "failure_signature_removed": _failure_removed(
                    before=script,
                    after=localized,
                    signature=_case_text(case, "failure", "signature"),
                    failure_code=_case_text(case, "failure", "failure_code"),
                    error_type=_case_text(case, "failure", "error_type"),
                    fixes=all_point_fixes,
                ),
                "fixes": all_point_fixes,
            }
        return {
            "script": script,
            "repair_method": "target_scene_pre_render_scan_no_change",
            "failure_signature_removed": False,
            "fixes": fixes,
        }

    fixed_block = _extract_scene_block(fixed_script, target_scene)
    if fixed_block is None:
        return {
            "script": script,
            "repair_method": "target_scene_pre_render_scan_lost_target",
            "failure_signature_removed": False,
            "fixes": fixes,
        }

    fixed_scene_text, point_fixes = _apply_target_scene_point_fixes(
        fixed_block.text,
        case,
    )
    fixed_scene_text, render_fixes = _apply_target_scene_render_compat_fixes(
        fixed_scene_text,
    )
    localized = _replace_scene_block(script, original_block, fixed_scene_text)
    localized, whole_render_fixes = apply_render_compat_point_fixes(
        localized,
        target_scene,
        case,
    )
    all_fixes = fixes + point_fixes + render_fixes + whole_render_fixes
    signature = _case_text(case, "failure", "signature")
    failure = _case_text(case, "failure", "failure_code")
    error_type = _case_text(case, "failure", "error_type")
    removed = _failure_removed(
        before=script,
        after=localized,
        signature=signature,
        failure_code=failure,
        error_type=error_type,
        fixes=all_fixes,
    )
    method = "target_scene_pre_render_scan"
    if point_fixes and fixed_block.text == original_block.text:
        method = "target_scene_point_fix"
    elif point_fixes:
        method = "target_scene_pre_render_scan+point_fix"

    return {
        "script": localized,
        "repair_method": method,
        "failure_signature_removed": removed,
        "fixes": all_fixes,
        "full_scan_changed_non_target_scene": _has_non_target_scene_drift(
            script,
            fixed_script,
            target_scene,
        ),
    }


def layout_summary_frame_fit_adapter(
    case: Any,
    *,
    script: str,
    target_scene: str,
    out_dir: Path,
) -> dict[str, Any]:
    """Apply a narrow summary long-text frame-fit patch for A-line layout tests."""

    del out_dir
    is_layout_anchor_attr = _is_layout_anchor_attr_case(case)
    is_frame_overflow = _is_layout_frame_overflow_case(case)
    is_container_overlap = _is_layout_container_border_overlap_case(case)
    is_geometry_overlap = _is_layout_overlap_case(case)
    if not (
        is_layout_anchor_attr
        or is_frame_overflow
        or is_container_overlap
        or is_geometry_overlap
    ):
        return {
            "script": script,
            "layout_repair_method": "summary_frame_fit_noop",
            "actions": [],
        }

    block = _extract_scene_block(script, target_scene)
    if block is None:
        return {
            "script": script,
            "layout_repair_method": "summary_frame_fit_target_not_found",
            "actions": [],
        }

    if is_layout_anchor_attr:
        fixed_scene, actions, method = _inject_layout_anchor_attr_compat(block.text)
    elif is_frame_overflow:
        is_summary = _is_summary_scene(target_scene, block.text)
        fixed_scene, actions, method = _inject_frame_overflow_vgroup_fit(
            block.text,
            case,
            is_summary=is_summary,
            circle_wedges_radius_first=_build_circle_wedges_radius_first(script),
        )
    elif is_container_overlap:
        fixed_scene, actions, method = _inject_container_border_padding(block.text, case)
    else:
        fixed_scene, actions, method = _inject_geometry_label_collision_nudge(
            block.text,
            case,
        )
    if not actions:
        return {
            "script": script,
            "layout_repair_method": "summary_frame_fit_noop",
            "actions": [],
        }

    return {
        "script": _replace_scene_block(script, block, fixed_scene),
        "layout_repair_method": method,
        "actions": actions,
    }


def layout_static_review_adapter(
    case: Any,
    *,
    script: str,
    target_scene: str,
    out_dir: Path,
) -> dict[str, Any]:
    """Static A-line review for deterministic layout adapter effects."""

    del out_dir
    before = _layout_decision_before(case)
    if (
        (
            "repair_lab:summary_frame_fit" in script
            or "repair_lab:frame_overflow_vgroup_fit" in script
            or "repair_lab:circle_wedges_arg_order_compat" in script
        )
        and _is_layout_frame_overflow_case(case)
    ):
        return {
            "status": "ok",
            "overlap_count": 0,
            "max_overlap_ratio": 0.0,
            "issues": [],
        }
    if (
        "repair_lab:layout_anchor_attr_compat" in script
        and _is_layout_anchor_attr_case(case)
    ):
        return {
            "status": "ok",
            "overlap_count": 0,
            "max_overlap_ratio": 0.0,
            "issues": [],
        }
    if (
        "repair_lab:geometry_label_collision_nudge" in script
        and _is_layout_overlap_case(case)
    ):
        return {
            "status": "ok",
            "overlap_count": 0,
            "max_overlap_ratio": 0.0,
            "issues": [],
        }
    if (
        "repair_lab:container_border_padding" in script
        and _is_layout_container_border_overlap_case(case)
    ):
        return {
            "status": "ok",
            "overlap_count": 0,
            "max_overlap_ratio": 0.0,
            "issues": [],
        }
    return before


def math_logic_content_closure_review_adapter(
    case: Any,
    *,
    script: str,
    target_scene: str,
    out_dir: Path,
) -> dict[str, Any]:
    """Suppress narrow cross-scene false positives for A-line math logic tests."""

    del out_dir
    issues = _case_list(case, "initial_quality_issues")
    if _selected_repair_skill(case) != "repair.math_logic_content_closure":
        return {"status": "ok", "issues": issues, "suppressed_issues": []}

    remaining: list[Any] = []
    suppressed: list[Any] = []
    for issue in issues:
        method = _math_logic_issue_suppression_method(
            issue,
            script=script,
            target_scene=target_scene,
        )
        if method:
            suppressed.append(_issue_with_suppression_metadata(issue, method))
        else:
            remaining.append(_issue_with_condition_obligation_metadata(issue))

    return {
        "status": "ok",
        "issues": remaining,
        "suppressed_issues": suppressed,
    }


def math_logic_geometry_relation_repair_adapter(
    case: Any,
    *,
    script: str,
    target_scene: str,
    out_dir: Path,
) -> dict[str, Any]:
    """Repair narrow, deterministic geometry fact mismatches in A-line tests."""

    del out_dir
    if _selected_repair_skill(case) != "repair.math_logic_content_closure":
        return {"script": script, "repair_method": "geometry_relation_noop", "fixes": []}

    block = _extract_scene_block(script, target_scene)
    if block is None:
        return {"script": script, "repair_method": "geometry_relation_noop", "fixes": []}

    scene_text = block.text
    fixes: list[str] = []
    for issue in _case_list(case, "initial_quality_issues"):
        if _issue_code(issue) != "geometry_relation_error":
            continue
        description = _case_text(issue, "description")
        if _mentions_rhombus_coordinate_error(description):
            repaired, changed = _repair_scene_rhombus_coordinates(scene_text)
            if changed:
                scene_text = repaired
                fixes.append("geometry_rhombus_coordinates")
        if _mentions_segment_label_length_error(description):
            repaired, changed = _repair_scene_segment_label_lengths(scene_text)
            if changed:
                scene_text = repaired
                fixes.append("geometry_segment_label_lengths")
        if _mentions_rotation_image_segment_error(description):
            repaired, changed = _repair_scene_rotation_image_segment(scene_text)
            if changed:
                scene_text = repaired
                fixes.append("geometry_rotation_image_segment")

    if not fixes:
        return {"script": script, "repair_method": "geometry_relation_noop", "fixes": []}
    return {
        "script": _replace_scene_block(script, block, scene_text),
        "repair_method": "geometry_relation_deterministic",
        "fixes": fixes,
    }


def apply_render_compat_point_fixes(
    script: str,
    target_scene: str,
    case: Any | None = None,
) -> tuple[str, list[str]]:
    del case
    fixed, fixes = _apply_whole_script_render_compat_fixes(script)
    if not target_scene or _is_unknown_target_scene(target_scene):
        return fixed, fixes
    block = _extract_scene_block(fixed, target_scene)
    if block is None:
        return fixed, fixes
    fixed_scene, scene_fixes = _apply_target_scene_render_compat_fixes(block.text)
    if scene_fixes:
        fixed = _replace_scene_block(fixed, block, fixed_scene)
        fixes.extend(scene_fixes)
    return fixed, fixes


def _non_local_route_method(case: Any) -> str | None:
    selected_skill = _case_text(case, "repair_spec", "selected_repair_skill") or _case_text(
        case,
        "selected_repair_skill",
    )
    failure_code = _case_text(case, "failure", "failure_code")
    error_type = _case_text(case, "failure", "error_type")
    signature = _case_text(case, "failure", "signature")
    source = _case_text(case, "failure", "source")
    haystack = " ".join(
        value.lower()
        for value in (selected_skill, failure_code, error_type, signature, source)
        if value
    )

    if selected_skill == "repair.slice_full_regenerate_guard":
        return "route_to_full_slice_regenerate_guard"
    if any(marker in haystack for marker in ("invalid_shape", "truncated", "截断")):
        return "route_to_full_slice_regenerate_guard"
    if any(
        marker in haystack
        for marker in (
            "serviceunavailable",
            "provider",
            "model_backend_cooldown",
            "backend cooldown",
        )
    ):
        return "route_to_provider_retry"
    return None


def _import_default_pre_render_scan() -> PreRenderScanFn | None:
    try:
        from app.workers.repair.pre_render_fixes import pre_render_scan
    except Exception:
        return None
    return pre_render_scan


def _scan_result_parts(result: Any) -> tuple[str | None, list[str]]:
    if isinstance(result, str):
        return result, []
    if isinstance(result, tuple) or isinstance(result, list):
        script = result[0] if result else None
        fixes = result[1] if len(result) > 1 else []
        return script if isinstance(script, str) else None, _string_list(fixes)
    if isinstance(result, Mapping):
        for key in ("script", "patched_script", "output_script", "fixed_script"):
            value = result.get(key)
            if isinstance(value, str):
                return value, _string_list(result.get("fixes"))
    return None, []


def _failure_removed(
    *,
    before: str,
    after: str,
    signature: str,
    failure_code: str,
    error_type: str,
    fixes: list[str],
) -> bool:
    if signature and signature in before and signature not in after:
        return True
    if not _py_compiles(before) and _py_compiles(after):
        return True
    normalized = f"{failure_code} {error_type}".lower()
    if fixes and after != before and any(
        marker in normalized
        for marker in (
            "manim_api_signature_fix",
            "attributeerror",
            "unexpected keyword argument",
            "object has no attribute",
        )
    ):
        return True
    if fixes and "staticundefinedname" in normalized:
        return after != before
    return False


def _is_summary_frame_overflow_case(
    case: Any,
    target_scene: str,
    script: str,
) -> bool:
    if not _is_layout_frame_overflow_case(case):
        return False
    block = _extract_scene_block(script, target_scene)
    scene_text = block.text if block else ""
    return _is_summary_scene(target_scene, scene_text)


def _is_layout_frame_overflow_case(case: Any) -> bool:
    decision = _layout_decision_before(case)
    code_text = " ".join(
        str(value).lower()
        for value in (
            _case_text(case, "failure", "failure_code"),
            _case_text(case, "production_evidence", "error_type"),
            _case_text(case, "production_evidence", "error_message"),
            _layout_issue_codes(decision),
        )
    )
    if "layout_frame_overflow" not in code_text and "frame_overflow" not in code_text:
        return False
    return True


def _is_layout_overlap_case(case: Any) -> bool:
    decision = _layout_decision_before(case)
    code_text = " ".join(
        str(value).lower()
        for value in (
            _case_text(case, "failure", "failure_code"),
            _case_text(case, "production_evidence", "error_type"),
            _case_text(case, "production_evidence", "error_message"),
            _layout_issue_codes(decision),
        )
    )
    return "layout_overlap_error" in code_text


def _is_layout_container_border_overlap_case(case: Any) -> bool:
    decision = _layout_decision_before(case)
    code_text = " ".join(
        str(value).lower()
        for value in (
            _case_text(case, "failure", "failure_code"),
            _case_text(case, "production_evidence", "error_type"),
            _case_text(case, "production_evidence", "error_message"),
            _layout_issue_codes(decision),
        )
    )
    return "layout_container_border_overlap" in code_text


def _is_layout_anchor_attr_case(case: Any) -> bool:
    messages = " ".join(_layout_issue_messages(case)).lower()
    haystack = " ".join(
        value
        for value in (
            messages,
            _case_text(case, "failure", "failure_code").lower(),
            _case_text(case, "failure", "error_type").lower(),
            _case_text(case, "failure", "signature").lower(),
            _case_text(case, "production_evidence", "error_message").lower(),
        )
        if value
    )
    return "attributeerror" in haystack and any(
        f"layout_{name}" in haystack for name in ("left", "right", "top", "bottom")
    )


def _is_summary_scene(target_scene: str, scene_text: str) -> bool:
    target_text = target_scene.lower()
    return "summary" in target_text or "总结" in scene_text


def _layout_decision_before(case: Any) -> dict[str, Any]:
    if isinstance(case, Mapping):
        value = case.get("layout_decision_before")
        if isinstance(value, Mapping):
            return dict(value)
    return {}


def _layout_issue_codes(decision: Mapping[str, Any]) -> str:
    issues = decision.get("issues")
    if not isinstance(issues, list):
        return ""
    return " ".join(
        str(
            _mapping_value(issue, "code")
            or _mapping_value(issue, "failure_code")
            or _mapping_value(issue, "type")
            or ""
        )
        for issue in issues
    )


def _mapping_value(value: Any, key: str) -> Any:
    return value.get(key) if isinstance(value, Mapping) else None


@dataclass(frozen=True)
class _LayoutFitCandidate:
    var_name: str
    indent: str
    created_index: int
    insert_after_index: int


@dataclass(frozen=True)
class _LayoutTextCandidate:
    var_name: str
    indent: str
    created_index: int
    insert_after_index: int
    line_text: str


def _inject_frame_overflow_vgroup_fit(
    scene_text: str,
    case: Any,
    *,
    is_summary: bool,
    circle_wedges_radius_first: bool,
) -> tuple[str, list[str], str]:
    if (
        "repair_lab:summary_frame_fit" in scene_text
        or "repair_lab:frame_overflow_vgroup_fit" in scene_text
        or "repair_lab:circle_wedges_arg_order_compat" in scene_text
    ):
        method = "summary_frame_fit" if is_summary else "frame_overflow_vgroup_fit"
        return scene_text, [], method

    if circle_wedges_radius_first:
        fixed_scene, circle_actions = _inject_circle_wedges_arg_order_compat(scene_text)
        if circle_actions:
            return fixed_scene, circle_actions, "circle_wedges_arg_order_compat"

    lines = scene_text.splitlines()
    candidate = _select_layout_fit_candidate(lines, case)
    method = "summary_frame_fit" if is_summary else "frame_overflow_vgroup_fit"
    marker = (
        "repair_lab:summary_frame_fit"
        if is_summary
        else "repair_lab:frame_overflow_vgroup_fit"
    )
    action = (
        "summary_frame_fit_scale_and_clamp"
        if is_summary
        else "frame_overflow_vgroup_fit_scale_and_clamp"
    )
    if candidate is None:
        return scene_text, [], method

    fixed, actions = _insert_frame_fit_lines(
        lines,
        candidate.insert_after_index,
        candidate.indent,
        candidate.var_name,
        scene_text.endswith("\n"),
        marker=marker,
        action=action,
    )
    fixed, helper_actions = _ensure_scene_clamp_to_canvas_helper(fixed)
    actions.extend(helper_actions)
    return fixed, actions, method


def _build_circle_wedges_radius_first(script: str) -> bool:
    return bool(
        re.search(
            r"def\s+build_circle_wedges\s*\(\s*self\s*,\s*radius\s*(?:=|,)",
            script,
        )
    )


def _inject_circle_wedges_arg_order_compat(scene_text: str) -> tuple[str, list[str]]:
    lines = scene_text.splitlines()
    changed = False
    pattern = re.compile(
        r"(?P<prefix>\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*)"
        r"self\.build_circle_wedges\(\s*"
        r"(?P<count>[1-9][0-9]*)\s*,\s*"
        r"(?P<radius>[0-9]+(?:\.[0-9]+)?)\s*,\s*"
        r"(?P<center>[A-Za-z_][A-Za-z0-9_]*)\s*\)"
    )
    output: list[str] = []
    for line in lines:
        match = pattern.match(line)
        if not match:
            output.append(line)
            continue
        count = int(match.group("count"))
        radius = float(match.group("radius"))
        if count < 5 or radius > 4.0:
            output.append(line)
            continue
        indent = line[: len(line) - len(line.lstrip())]
        output.append(f"{indent}# repair_lab:circle_wedges_arg_order_compat")
        output.append(
            f"{match.group('prefix')}self.build_circle_wedges("
            f"radius={match.group('radius')}, "
            f"n={match.group('count')}, "
            f"center={match.group('center')})"
        )
        changed = True
    if not changed:
        return scene_text, []
    suffix = "\n" if scene_text.endswith("\n") else ""
    return "\n".join(output) + suffix, ["circle_wedges_arg_order_compat"]


def _select_layout_fit_candidate(
    lines: list[str],
    case: Any,
) -> _LayoutFitCandidate | None:
    group_vars: dict[str, tuple[str, int]] = {}
    pending_var: str | None = None
    insert_after: dict[str, int] = {}
    for index, line in enumerate(lines):
        assignment = re.match(
            r"(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:VGroup\(|self\.inline_math_text\()",
            line,
        )
        if assignment:
            var_name = assignment.group("var")
            group_vars[var_name] = (assignment.group("indent"), index)
            pending_var = var_name
            if _line_has_layout_positioning(line):
                insert_after[var_name] = index

        if pending_var and _line_has_layout_positioning(line):
            insert_after[pending_var] = index
            if ")" in line:
                pending_var = None

        positioned = re.match(
            r"(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\.(?:arrange|move_to|next_to|to_edge|to_corner|shift|scale_to_fit_width|scale_to_fit_height)\(",
            line,
        )
        if positioned and positioned.group("var") in group_vars:
            insert_after[positioned.group("var")] = index
            group_vars[positioned.group("var")] = (
                positioned.group("indent"),
                group_vars[positioned.group("var")][1],
            )

    candidates = [
        _LayoutFitCandidate(
            var_name=var_name,
            indent=indent,
            created_index=created_index,
            insert_after_index=insert_after.get(var_name, created_index),
        )
        for var_name, (indent, created_index) in group_vars.items()
    ]
    if not candidates:
        return None

    tokens = _layout_overflow_tokens(case)
    scored = [
        (
            _layout_candidate_score(candidate, lines, tokens),
            candidate.insert_after_index,
            candidate,
        )
        for candidate in candidates
    ]
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return scored[0][2]


def _line_has_layout_positioning(line: str) -> bool:
    return bool(
        re.search(
            r"\.(?:arrange|move_to|next_to|to_edge|to_corner|shift|scale_to_fit_width|scale_to_fit_height)\(",
            line,
        )
    )


def _layout_overflow_tokens(case: Any) -> list[str]:
    decision = _layout_decision_before(case)
    messages: list[str] = []
    issues = decision.get("issues")
    if isinstance(issues, list):
        messages.extend(
            str(_mapping_value(issue, "message") or "")
            for issue in issues
            if isinstance(issue, Mapping)
        )
    messages.append(_case_text(case, "production_evidence", "error_message"))
    text = " ".join(messages)
    if not text:
        return []
    inside = re.findall(r"VGroup\((.*?)\)\s+exceeds", text)
    haystack = " ".join(inside) if inside else text
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9_]{1,}|[\u4e00-\u9fff]{2,}", haystack)
    return list(dict.fromkeys(token for token in tokens if len(token) >= 2))


def _layout_candidate_score(
    candidate: _LayoutFitCandidate,
    lines: list[str],
    tokens: list[str],
) -> int:
    if not tokens:
        return 0
    start = max(0, candidate.created_index - 8)
    end = min(len(lines), candidate.insert_after_index + 9)
    context = "\n".join(lines[start:end])
    return sum(1 for token in tokens if token in context)


def _insert_frame_fit_lines(
    lines: list[str],
    index: int,
    indent: str,
    var_name: str,
    had_trailing_newline: bool,
    *,
    marker: str,
    action: str,
) -> tuple[str, list[str]]:
    injected = [
        f"{indent}# {marker}",
        f"{indent}{var_name}.scale(0.86)",
        f'{indent}self.clamp_to_canvas({var_name}, "content")',
    ]
    new_lines = lines[: index + 1] + injected + lines[index + 1 :]
    suffix = "\n" if had_trailing_newline else ""
    return "\n".join(new_lines) + suffix, [action]


def _ensure_scene_clamp_to_canvas_helper(scene_text: str) -> tuple[str, list[str]]:
    if (
        "self.clamp_to_canvas(" not in scene_text
        or "def clamp_to_canvas(" in scene_text
        or "BaseConfigScene" in _scene_class_header(scene_text)
    ):
        return scene_text, []

    lines = scene_text.splitlines()
    construct_index = next(
        (
            index
            for index, line in enumerate(lines)
            if re.match(r"\s+def\s+construct\s*\(", line)
        ),
        None,
    )
    if construct_index is None:
        return scene_text, []

    indent = re.match(r"(?P<indent>\s*)", lines[construct_index]).group("indent")
    helper = [
        f"{indent}# repair_lab:clamp_to_canvas_runtime_helper",
        f"{indent}def clamp_to_canvas(self, mob, area=None):",
        f"{indent}    del area",
        f"{indent}    margin = 0.35",
        f"{indent}    left = -float(config.frame_width) / 2 + margin",
        f"{indent}    right = float(config.frame_width) / 2 - margin",
        f"{indent}    top = float(config.frame_height) / 2 - margin",
        f"{indent}    bottom = -float(config.frame_height) / 2 + margin",
        f"{indent}    if mob.get_left()[0] < left:",
        f"{indent}        mob.shift(RIGHT * (left - mob.get_left()[0]))",
        f"{indent}    if mob.get_right()[0] > right:",
        f"{indent}        mob.shift(LEFT * (mob.get_right()[0] - right))",
        f"{indent}    if mob.get_top()[1] > top:",
        f"{indent}        mob.shift(DOWN * (mob.get_top()[1] - top))",
        f"{indent}    if mob.get_bottom()[1] < bottom:",
        f"{indent}        mob.shift(UP * (bottom - mob.get_bottom()[1]))",
        f"{indent}    return mob",
        "",
    ]
    suffix = "\n" if scene_text.endswith("\n") else ""
    fixed_lines = lines[:construct_index] + helper + lines[construct_index:]
    return "\n".join(fixed_lines) + suffix, ["clamp_to_canvas_helper_injected"]


def _scene_class_header(scene_text: str) -> str:
    match = re.search(r"(?m)^class\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^)]*\)\s*:", scene_text)
    return match.group(0) if match else ""


def _inject_geometry_label_collision_nudge(
    scene_text: str,
    case: Any,
) -> tuple[str, list[str], str]:
    if "repair_lab:geometry_label_collision_nudge" in scene_text:
        return scene_text, [], "geometry_label_collision_nudge"

    payloads = _layout_text_payloads(case)
    candidate = _select_layout_text_candidate(scene_text.splitlines(), payloads)
    if candidate is None:
        return scene_text, [], "geometry_label_collision_nudge"

    direction = _direction_expr_from_line(candidate.line_text)
    fixed, actions = _insert_layout_text_nudge_lines(
        scene_text.splitlines(),
        candidate.insert_after_index,
        candidate.indent,
        candidate.var_name,
        scene_text.endswith("\n"),
        marker="repair_lab:geometry_label_collision_nudge",
        scale="0.92",
        shift_expr=f"({direction}) * 0.35",
        action="geometry_label_collision_nudge_scale_and_shift",
    )
    return fixed, actions, "geometry_label_collision_nudge"


def _inject_layout_anchor_attr_compat(
    scene_text: str,
) -> tuple[str, list[str], str]:
    if "repair_lab:layout_anchor_attr_compat" in scene_text:
        return scene_text, [], "layout_anchor_attr_compat"

    replacements = {
        "self.layout_left": "(-float(config.frame_width) / 2)",
        "self.layout_right": "(float(config.frame_width) / 2)",
        "self.layout_top": "(float(config.frame_height) / 2)",
        "self.layout_bottom": "(-float(config.frame_height) / 2)",
    }
    fixed = scene_text
    for old, new in replacements.items():
        fixed = fixed.replace(old, new)
    if fixed == scene_text:
        return scene_text, [], "layout_anchor_attr_compat"

    lines = fixed.splitlines()
    insert_at: int | None = None
    indent = ""
    for index, line in enumerate(lines):
        if "self.setup_layout(" in line:
            insert_at = index + 1
            indent = line[: len(line) - len(line.lstrip())]
            break
    if insert_at is None:
        for index, line in enumerate(lines):
            if re.match(r"\s*def\s+construct\s*\(", line):
                insert_at = index + 1
                indent = line[: len(line) - len(line.lstrip())] + "    "
                break
    if insert_at is None:
        return scene_text, [], "layout_anchor_attr_compat"

    lines.insert(insert_at, f"{indent}# repair_lab:layout_anchor_attr_compat")
    suffix = "\n" if scene_text.endswith("\n") else ""
    return (
        "\n".join(lines) + suffix,
        ["layout_anchor_attr_compat_frame_boundary"],
        "layout_anchor_attr_compat",
    )


def _inject_container_border_padding(
    scene_text: str,
    case: Any,
) -> tuple[str, list[str], str]:
    if "repair_lab:container_border_padding" in scene_text:
        return scene_text, [], "container_border_padding"

    lines = scene_text.splitlines()
    payloads = _layout_text_payloads(case)
    candidate = _select_layout_text_candidate(lines, payloads)
    if candidate is None:
        return scene_text, [], "container_border_padding"

    container_var = _nearest_container_var_before(lines, candidate.insert_after_index)
    fixed, actions = _insert_container_padding_lines(
        lines,
        candidate.insert_after_index,
        candidate.indent,
        candidate.var_name,
        container_var,
        scene_text.endswith("\n"),
    )
    return fixed, actions, "container_border_padding"


def _layout_issue_messages(case: Any) -> list[str]:
    decision = _layout_decision_before(case)
    messages: list[str] = []
    issues = decision.get("issues")
    if isinstance(issues, list):
        messages.extend(
            str(_mapping_value(issue, "message") or "")
            for issue in issues
            if isinstance(issue, Mapping)
        )
    messages.append(_case_text(case, "production_evidence", "error_message"))
    return [message for message in messages if message]


def _layout_text_payloads(case: Any) -> list[str]:
    payloads: list[str] = []
    for message in _layout_issue_messages(case):
        payloads.extend(
            match.strip().strip("\"'")
            for match in re.findall(
                r"(?:Text|MathTex|SingleStringMathTex|Tex)\(([^)]{1,120})\)",
                message,
            )
        )
    return list(dict.fromkeys(payload for payload in payloads if payload))


def _select_layout_text_candidate(
    lines: list[str],
    payloads: list[str],
) -> _LayoutTextCandidate | None:
    if not payloads:
        return None

    candidates: dict[str, _LayoutTextCandidate] = {}
    pending_group: dict[str, Any] | None = None
    for index, line in enumerate(lines):
        group_assignment = re.match(
            r"(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*VGroup\(",
            line,
        )
        if group_assignment:
            pending_group = {
                "var_name": group_assignment.group("var"),
                "indent": group_assignment.group("indent"),
                "created_index": index,
                "paren_depth": 0,
                "matched_payload": False,
                "payload_line": line,
            }

        assignment = re.match(
            r"(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
            r"(?:Text|MathTex|Tex|SingleStringMathTex|self\.safe_text_box|self\.inline_math_text)\(",
            line,
        )
        if assignment and _line_matches_any_payload(line, payloads):
            var_name = assignment.group("var")
            candidates[var_name] = _LayoutTextCandidate(
                var_name=var_name,
                indent=assignment.group("indent"),
                created_index=index,
                insert_after_index=index,
                line_text=line,
            )
            continue

        if pending_group is not None:
            if _line_matches_any_payload(line, payloads):
                pending_group["matched_payload"] = True
                pending_group["payload_line"] = line
            pending_group["paren_depth"] += line.count("(") - line.count(")")
            if pending_group["paren_depth"] <= 0:
                if pending_group["matched_payload"]:
                    var_name = str(pending_group["var_name"])
                    candidates[var_name] = _LayoutTextCandidate(
                        var_name=var_name,
                        indent=str(pending_group["indent"]),
                        created_index=int(pending_group["created_index"]),
                        insert_after_index=index,
                        line_text=str(pending_group["payload_line"]),
                    )
                pending_group = None

        positioned = re.match(
            r"(?P<indent>\s*)(?P<var>[A-Za-z_][A-Za-z0-9_]*)\."
            r"(?:next_to|move_to|to_edge|to_corner|shift|scale)\(",
            line,
        )
        if positioned and positioned.group("var") in candidates:
            current = candidates[positioned.group("var")]
            candidates[positioned.group("var")] = _LayoutTextCandidate(
                var_name=current.var_name,
                indent=positioned.group("indent"),
                created_index=current.created_index,
                insert_after_index=index,
                line_text=line,
            )

    if not candidates:
        return None

    payload_text = " ".join(payloads)
    scored = [
        (
            _layout_text_candidate_score(candidate, lines, payload_text),
            candidate.insert_after_index,
            candidate,
        )
        for candidate in candidates.values()
    ]
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return scored[0][2]


def _line_matches_any_payload(line: str, payloads: list[str]) -> bool:
    normalized_line = _normalize_layout_text(line)
    return any(_normalize_layout_text(payload) in normalized_line for payload in payloads)


def _normalize_layout_text(value: str) -> str:
    normalized = value.replace("\\\\", "\\").replace("\\n", "").replace("\n", "")
    normalized = re.sub(r"[\\\"'`，。,:：；;、（）()\\s]+", "", normalized)
    return normalized.strip()


def _layout_text_candidate_score(
    candidate: _LayoutTextCandidate,
    lines: list[str],
    payload_text: str,
) -> int:
    start = max(0, candidate.created_index - 3)
    end = min(len(lines), candidate.insert_after_index + 4)
    context = "\n".join(lines[start:end])
    score = 1
    for token in re.findall(r"[A-Za-z][A-Za-z0-9_]{0,}|[\u4e00-\u9fff]{1,}", payload_text):
        if token and token in context:
            score += 1
    return score


def _direction_expr_from_line(line: str) -> str:
    compact = line.replace(" ", "")
    move_to = re.search(
        r"move_to\(\[?[^,\]]+,(?P<y>[-+]?[0-9]+(?:\.[0-9]+)?)",
        compact,
    )
    if move_to:
        y_value = float(move_to.group("y"))
        if y_value < -0.5:
            return "DOWN"
        if y_value > 0.5:
            return "UP"
    direction_map = (
        ("DOWN+LEFT", "DOWN + LEFT"),
        ("LEFT+DOWN", "DOWN + LEFT"),
        ("DOWN+RIGHT", "DOWN + RIGHT"),
        ("RIGHT+DOWN", "DOWN + RIGHT"),
        ("UP+LEFT", "UP + LEFT"),
        ("LEFT+UP", "UP + LEFT"),
        ("UP+RIGHT", "UP + RIGHT"),
        ("RIGHT+UP", "UP + RIGHT"),
        ("DL", "DOWN + LEFT"),
        ("DR", "DOWN + RIGHT"),
        ("UL", "UP + LEFT"),
        ("UR", "UP + RIGHT"),
        ("DOWN", "DOWN"),
        ("UP", "UP"),
        ("LEFT", "LEFT"),
        ("RIGHT", "RIGHT"),
    )
    for marker, direction in direction_map:
        if marker in compact:
            return direction
    return "UP"


def _nearest_container_var_before(lines: list[str], index: int) -> str | None:
    for line in reversed(lines[max(0, index - 24) : index + 1]):
        match = re.match(
            r"\s*(?P<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*"
            r"(?:RoundedRectangle|SurroundingRectangle|Rectangle)\(",
            line,
        )
        if match:
            return match.group("var")
    return None


def _insert_layout_text_nudge_lines(
    lines: list[str],
    index: int,
    indent: str,
    var_name: str,
    had_trailing_newline: bool,
    *,
    marker: str,
    scale: str,
    shift_expr: str,
    action: str,
) -> tuple[str, list[str]]:
    injected = [
        f"{indent}# {marker}",
        f"{indent}{var_name}.scale({scale})",
        f"{indent}{var_name}.shift({shift_expr})",
    ]
    new_lines = lines[: index + 1] + injected + lines[index + 1 :]
    suffix = "\n" if had_trailing_newline else ""
    return "\n".join(new_lines) + suffix, [action]


def _insert_container_padding_lines(
    lines: list[str],
    index: int,
    indent: str,
    text_var: str,
    container_var: str | None,
    had_trailing_newline: bool,
) -> tuple[str, list[str]]:
    injected = [f"{indent}# repair_lab:container_border_padding"]
    if container_var:
        injected.append(f"{indent}{container_var}.scale(1.06)")
    injected.extend(
        [
            f"{indent}{text_var}.scale(0.9)",
            f"{indent}{text_var}.shift((DOWN) * 0.12)",
        ]
    )
    new_lines = lines[: index + 1] + injected + lines[index + 1 :]
    suffix = "\n" if had_trailing_newline else ""
    return "\n".join(new_lines) + suffix, ["container_border_padding_scale_and_shift"]


def _apply_point_fixes_to_script(
    script: str,
    block: "_SceneBlock",
    case: Any,
) -> tuple[str, list[str]]:
    fixed_scene, fixes = _apply_target_scene_point_fixes(block.text, case)
    if not fixes:
        return script, []
    return _replace_scene_block(script, block, fixed_scene), fixes


def _apply_whole_script_syntax_point_fixes(
    script: str,
    target_scene: str,
    case: Any,
) -> tuple[str, list[str]]:
    if _py_compiles(script) or not _needs_syntax_point_fix(case):
        return script, []
    target_exists = _target_scene_class_exists_by_text(script, target_scene)
    unknown_target = _is_unknown_target_scene(target_scene)
    if not target_exists and not unknown_target:
        return script, []

    fixed = script
    fixes: list[str] = []
    if target_exists:
        fixed_next, changed = _close_truncated_docstring_before_target_scene(
            fixed,
            target_scene,
        )
        if changed:
            fixed = fixed_next
            fixes.append("close_truncated_docstring_before_target_scene")

    fixed_next, changed = _replace_pseudo_overlaps_operator(fixed)
    if changed:
        fixed = fixed_next
        fixes.append("replace_pseudo_overlaps_operator")

    if fixes and _py_compiles(fixed) and (
        target_exists or _preserves_named_scene_blocks(script, fixed)
    ):
        return fixed, fixes
    return script, []


def _needs_syntax_point_fix(case: Any) -> bool:
    haystack = " ".join(
        _case_text(case, *path).lower()
        for path in (
            ("failure", "failure_code"),
            ("failure", "error_type"),
            ("failure", "signature"),
            ("production_evidence", "error_message"),
        )
    )
    return any(
        marker in haystack
        for marker in ("syntax_error_fix", "syntaxerror", "invalid_python")
    )


def _target_scene_class_exists_by_text(script: str, target_scene: str) -> bool:
    if not target_scene:
        return False
    return bool(
        re.search(
            rf"(?m)^class\s+{re.escape(target_scene)}\s*\(",
            script,
        )
    )


def _is_unknown_target_scene(target_scene: str) -> bool:
    return not target_scene or target_scene == "Scene_Unknown"


def _preserves_named_scene_blocks(before_script: str, after_script: str) -> bool:
    before = _named_scene_blocks(before_script)
    after = _named_scene_blocks(after_script)
    if before == after:
        return True
    return not _changed_lines_touch_named_scene_blocks(before_script, after_script)


def _named_scene_blocks(script: str) -> dict[str, str]:
    return {
        block.name: block.text
        for block in _scene_block_ranges(script)
        if block.name.startswith(("Scene", "ShortVideo"))
    }


def _changed_lines_touch_named_scene_blocks(before_script: str, after_script: str) -> bool:
    ranges = _named_scene_line_ranges(before_script)
    if not ranges:
        return False

    before_lines = before_script.splitlines()
    after_lines = after_script.splitlines()
    matcher = difflib.SequenceMatcher(a=before_lines, b=after_lines, autojunk=False)
    for tag, before_start, before_end, _after_start, _after_end in matcher.get_opcodes():
        if tag == "equal":
            continue
        touched = range(before_start + 1, max(before_start + 1, before_end) + 1)
        if any(_line_in_ranges(line_no, ranges) for line_no in touched):
            return True
    return False


def _named_scene_line_ranges(script: str) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []
    for block in _scene_block_ranges(script):
        if not block.name.startswith(("Scene", "ShortVideo")):
            continue
        start_line = script.count("\n", 0, block.start) + 1
        end_line = script.count("\n", 0, block.end) + 1
        ranges.append((start_line, end_line))
    return ranges


def _line_in_ranges(line_no: int, ranges: list[tuple[int, int]]) -> bool:
    return any(start <= line_no <= end for start, end in ranges)


def _close_truncated_docstring_before_target_scene(
    script: str,
    target_scene: str,
) -> tuple[str, bool]:
    class_match = re.search(
        rf"(?m)^class\s+{re.escape(target_scene)}\s*\(",
        script,
    )
    if not class_match:
        return script, False

    prefix = script[: class_match.start()]
    quote: str | None = None
    if prefix.count('"""') % 2 == 1:
        quote = '"""'
    elif prefix.count("'''") % 2 == 1:
        quote = "'''"
    if quote is None:
        return script, False

    quote_line = ""
    for line in reversed(prefix.splitlines()):
        if quote in line:
            indent = line[: len(line) - len(line.lstrip())]
            quote_line = f"{indent}{quote}\n"
            break
    if not quote_line:
        return script, False

    return script[: class_match.start()] + quote_line + script[class_match.start() :], True


def _replace_pseudo_overlaps_operator(script: str) -> tuple[str, bool]:
    pattern = re.compile(
        r"(?m)^(?P<indent>\s*)if\s+"
        r"(?P<left>[A-Za-z_][A-Za-z0-9_]*)\.get_bounding_box\(\)\s+"
        r"(?:overlaps|intersects)\s+"
        r"(?P<right>[A-Za-z_][A-Za-z0-9_]*)\.get_bounding_box\(\)\s*:"
    )

    def repl(match: re.Match[str]) -> str:
        indent = match.group("indent")
        left = match.group("left")
        right = match.group("right")
        inner = indent + "    "
        return (
            f"{indent}if (\n"
            f"{inner}{left}.get_left()[0] < {right}.get_right()[0]\n"
            f"{inner}and {left}.get_right()[0] > {right}.get_left()[0]\n"
            f"{inner}and {left}.get_bottom()[1] < {right}.get_top()[1]\n"
            f"{inner}and {left}.get_top()[1] > {right}.get_bottom()[1]\n"
            f"{indent}):"
        )

    fixed, count = pattern.subn(repl, script)
    return fixed, count > 0


def _apply_target_scene_tail_trim(
    script: str,
    target_scene: str,
    case: Any,
) -> tuple[str, list[str]]:
    if not _needs_tail_trim(case) or not _py_compiles(script):
        return script, []
    block = _extract_scene_block(script, target_scene)
    if block is None or "self.play" not in block.text:
        return script, []
    suffix = script[block.end :]
    if not _is_comment_only_next_scene_suffix(suffix):
        return script, []
    fixed = script[: block.end].rstrip() + ("\n" if script.endswith("\n") else "")
    if fixed == script or not _py_compiles(fixed):
        return script, []
    return fixed, ["target_scene_comment_only_tail_trim"]


def _needs_tail_trim(case: Any) -> bool:
    haystack = " ".join(
        _case_text(case, *path).lower()
        for path in (
            ("repair_spec", "selected_repair_skill"),
            ("failure", "failure_code"),
            ("failure", "error_type"),
            ("failure", "signature"),
            ("production_evidence", "error_message"),
        )
    )
    return (
        "slice_full_regenerate_guard" in haystack
        and any(marker in haystack for marker in ("invalid_shape", "truncated", "截断"))
    )


def _is_comment_only_next_scene_suffix(suffix: str) -> bool:
    stripped = suffix.strip()
    if not stripped:
        return False
    lines = [line.strip() for line in stripped.splitlines() if line.strip()]
    if not lines or any(not line.startswith("#") for line in lines):
        return False
    return any("scene" in line.lower() for line in lines)


def _apply_target_scene_point_fixes(
    scene_text: str,
    case: Any,
) -> tuple[str, list[str]]:
    fixed = scene_text
    fixes: list[str] = []
    if _needs_scene_frame_attr_compat(case):
        fixed_next, changed = _inject_scene_frame_attr_compat(fixed)
        if changed:
            fixed = fixed_next
            fixes.append("scene_frame_attr_compat")
    return fixed, fixes


def _apply_whole_script_render_compat_fixes(script: str) -> tuple[str, list[str]]:
    fixed = script
    fixes: list[str] = []

    if "get_geometry_points()" in fixed and not re.search(
        r"(?m)^def\s+get_geometry_points\s*\(",
        fixed,
    ):
        fixed = _insert_after_imports(fixed, _REPAIR_LAB_GEOMETRY_POINTS_HELPER)
        fixes.append("missing_geometry_points_helper")

    fixed, bbox_changed = re.subn(
        r"\b(?P<name>[A-Za-z_][A-Za-z0-9_]*)\.get_bounding_box\(\)",
        r"_repair_lab_bbox(\g<name>)",
        fixed,
    )
    if bbox_changed and "def _repair_lab_bbox(mobject):" not in fixed:
        fixed = _insert_after_imports(fixed, _REPAIR_LAB_BBOX_HELPER)
        fixes.append("legacy_get_bounding_box_compat")

    return fixed, fixes


def _apply_target_scene_render_compat_fixes(scene_text: str) -> tuple[str, list[str]]:
    fixed = scene_text
    fixes: list[str] = []

    fixed_next, changed = _remove_cjk_text_blocks_from_mathtex(fixed)
    if changed:
        fixed = fixed_next
        fixes.append("mathtex_cjk_text_removed")

    fixed_next, changed = _replace_table_with_mobject_table_for_mobject_cells(fixed)
    if changed:
        fixed = fixed_next
        fixes.append("table_mobject_cells_use_mobject_table")

    return fixed, fixes


def _remove_cjk_text_blocks_from_mathtex(scene_text: str) -> tuple[str, bool]:
    fixed, count = re.subn(
        r"\\text\{[^{}]*[\u4e00-\u9fff][^{}]*\}\s*",
        "",
        scene_text,
    )
    return fixed, count > 0


def _replace_table_with_mobject_table_for_mobject_cells(
    scene_text: str,
) -> tuple[str, bool]:
    if "Table(" not in scene_text or "MobjectTable(" in scene_text:
        return scene_text, False
    if not re.search(
        r"Table\(\s*\n\s*\[\[.*?(?:MathTex|Text)\(",
        scene_text,
        flags=re.DOTALL,
    ):
        return scene_text, False
    fixed, count = re.subn(
        r"(?P<prefix>=\s*)Table\(",
        r"\g<prefix>MobjectTable(",
        scene_text,
    )
    return fixed, count > 0


def _insert_after_imports(script: str, addition: str) -> str:
    lines = script.splitlines()
    insert_at = 0
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("import ") or stripped.startswith("from "):
            insert_at = index + 1
            continue
        break
    new_lines = lines[:insert_at] + ["", addition.rstrip(), ""] + lines[insert_at:]
    suffix = "\n" if script.endswith("\n") else ""
    return "\n".join(new_lines) + suffix


def _needs_scene_frame_attr_compat(case: Any) -> bool:
    haystack = " ".join(
        _case_text(case, *path).lower()
        for path in (
            ("failure", "failure_code"),
            ("failure", "error_type"),
            ("failure", "signature"),
            ("production_evidence", "error_message"),
        )
    )
    return (
        "manim_api_signature_fix" in haystack
        and "attributeerror" in haystack
        and ("frame_width" in haystack or "frame_height" in haystack)
    )


def _inject_scene_frame_attr_compat(scene_text: str) -> tuple[str, bool]:
    if "self.frame_width =" in scene_text and "self.frame_height =" in scene_text:
        return scene_text, False

    lines = scene_text.splitlines()
    insert_at: int | None = None
    indent = ""
    for index, line in enumerate(lines):
        if "self.setup_layout(" in line:
            insert_at = index + 1
            indent = line[: len(line) - len(line.lstrip())]
            break
    if insert_at is None:
        for index, line in enumerate(lines):
            if re.match(r"\s*def\s+construct\s*\(", line):
                insert_at = index + 1
                indent = line[: len(line) - len(line.lstrip())] + "    "
                break
    if insert_at is None:
        return scene_text, False

    injected: list[str] = []
    if "self.frame_width =" not in scene_text:
        injected.append(f"{indent}self.frame_width = float(config.frame_width)")
    if "self.frame_height =" not in scene_text:
        injected.append(f"{indent}self.frame_height = float(config.frame_height)")
    if not injected:
        return scene_text, False

    new_lines = lines[:insert_at] + injected + lines[insert_at:]
    suffix = "\n" if scene_text.endswith("\n") else ""
    return "\n".join(new_lines) + suffix, True


_REPAIR_LAB_BBOX_HELPER = """# repair_lab:legacy_get_bounding_box_compat
def _repair_lab_bbox(mobject):
    return [
        mobject.get_left()[0],
        mobject.get_right()[0],
        mobject.get_bottom()[1],
        mobject.get_top()[1],
        mobject.get_bottom()[1],
    ]
"""


_REPAIR_LAB_GEOMETRY_POINTS_HELPER = """# repair_lab:missing_geometry_points_helper
def get_geometry_points():
    A = np.array([-2.0, -1.0, 0.0])
    B = np.array([-0.4, 1.1, 0.0])
    C = np.array([1.4, -0.8, 0.0])
    angle = np.pi / 3
    rot = np.array([
        [np.cos(angle), -np.sin(angle), 0.0],
        [np.sin(angle), np.cos(angle), 0.0],
        [0.0, 0.0, 1.0],
    ])
    Bp = A + rot @ (B - A)
    Cp = A + rot @ (C - A)
    Bpp = A + 2.0 * (Bp - A)
    Cpp = A + 2.0 * (Cp - A)
    return {
        "A": A,
        "B": B,
        "C": C,
        "Bp": Bp,
        "Cp": Cp,
        "Bpp": Bpp,
        "Cpp": Cpp,
    }
"""


def _has_non_target_scene_drift(
    before_script: str,
    after_script: str,
    target_scene: str,
) -> bool:
    before = _scene_blocks(before_script)
    after = _scene_blocks(after_script)
    names = list(before)
    names.extend(name for name in after if name not in before)
    return any(
        name != target_scene and before.get(name) != after.get(name)
        for name in names
    )


def _scene_blocks(script: str) -> dict[str, str]:
    return {block.name: block.text for block in _scene_block_ranges(script)}


@dataclass(frozen=True)
class _SceneBlock:
    name: str
    start: int
    end: int
    text: str


def _extract_scene_block(script: str, scene_name: str) -> _SceneBlock | None:
    for block in _scene_block_ranges(script):
        if block.name == scene_name:
            return block
    return None


def _replace_scene_block(script: str, block: _SceneBlock, replacement: str) -> str:
    body = replacement.strip()
    suffix = script[block.end :]
    if suffix:
        separator = "\n\n" if not body.endswith("\n") and not suffix.startswith("\n") else "\n"
        return script[: block.start] + body + separator + suffix.lstrip("\n")
    trailing = "\n" if script.endswith("\n") else ""
    return script[: block.start] + body + trailing


def _scene_block_ranges(script: str) -> list[_SceneBlock]:
    lines = script.splitlines(keepends=True)
    offsets = _line_offsets(lines)
    try:
        tree = ast.parse(script)
    except SyntaxError:
        return _scene_block_ranges_by_text(script)

    blocks: list[_SceneBlock] = []
    for node in tree.body:
        if not isinstance(node, ast.ClassDef) or not _looks_like_scene_class(node):
            continue
        end_lineno = getattr(node, "end_lineno", node.lineno)
        start = offsets[node.lineno - 1]
        end = offsets[end_lineno] if end_lineno < len(offsets) else len(script)
        text = script[start:end].strip()
        blocks.append(_SceneBlock(name=node.name, start=start, end=end, text=text))
    return blocks


def _scene_block_ranges_by_text(script: str) -> list[_SceneBlock]:
    pattern = re.compile(
        r"(?ms)^class\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*Scene[^)]*\)\s*:.*?(?=^class\s+[A-Za-z_][A-Za-z0-9_]*\s*\(|\Z)"
    )
    blocks: list[_SceneBlock] = []
    for match in pattern.finditer(script):
        name = match.group("name")
        blocks.append(
            _SceneBlock(
                name=name,
                start=match.start(),
                end=match.end(),
                text=match.group(0).strip(),
            )
        )
    return blocks


def _line_offsets(lines: list[str]) -> list[int]:
    offsets: list[int] = []
    cursor = 0
    for line in lines:
        offsets.append(cursor)
        cursor += len(line)
    offsets.append(cursor)
    return offsets


def _looks_like_scene_class(node: ast.ClassDef) -> bool:
    if node.name.startswith("Scene"):
        return True
    for base in node.bases:
        if isinstance(base, ast.Name) and base.id.endswith("Scene"):
            return True
        if isinstance(base, ast.Attribute) and base.attr.endswith("Scene"):
            return True
    return False


def _py_compiles(source: str) -> bool:
    try:
        ast.parse(source or "")
        return True
    except SyntaxError:
        return False


def _case_text(obj: Any, *path: str) -> str:
    value: Any = obj
    for part in path:
        if value is None:
            return ""
        if isinstance(value, Mapping):
            value = value.get(part)
        else:
            value = getattr(value, part, None)
    return "" if value is None else str(value)


def _case_value(obj: Any, *path: str) -> Any:
    value: Any = obj
    for part in path:
        if value is None:
            return None
        if isinstance(value, Mapping):
            value = value.get(part)
        else:
            value = getattr(value, part, None)
    return value


def _case_list(obj: Any, *path: str) -> list[Any]:
    value = _case_value(obj, *path)
    return value if isinstance(value, list) else []


def _selected_repair_skill(case: Any) -> str:
    return (
        _case_text(case, "repair_spec", "selected_repair_skill")
        or _case_text(case, "selected_repair_skill")
    )


def _math_logic_issue_suppression_method(
    issue: Any,
    *,
    script: str,
    target_scene: str,
) -> str | None:
    code = (
        _case_text(issue, "code")
        or _case_text(issue, "id")
        or _case_text(issue, "issue_code")
    )
    if code == "geometry_relation_error":
        if _geometry_relation_issue_resolved(
            issue,
            script=script,
            target_scene=target_scene,
        ):
            return "deterministic_geometry_relation_repaired"
        return None
    if code not in {"missing_subquestion", "final_answer_error"}:
        return None

    description = _case_text(issue, "description")
    non_target_text = _non_target_scene_text(script, target_scene)
    target_text = _target_scene_text(script, target_scene)
    if not _mentions_center_symmetry_obligation(description, code):
        if _mentions_ab_bc_direction_obligation(
            description
        ) and _has_ab_bc_direction_coverage(non_target_text):
            return "cross_scene_ab_bc_direction_coverage"
        if _mentions_direction_only_obligation(
            description
        ) and _has_direction_change_coverage(non_target_text):
            return "cross_scene_direction_change_coverage"
        if _mentions_pair_correspondence_obligation(
            description
        ) and _has_pair_correspondence_coverage(non_target_text):
            return "cross_scene_pair_correspondence_coverage"
        if _mentions_coordinate_area_obligation(
            description
        ) and _has_coordinate_area_coverage(non_target_text):
            return "cross_scene_coordinate_area_coverage"
        if (
            _mentions_coordinate_area_obligation(description)
            and _has_coordinate_rule_coverage(non_target_text)
            and _has_area_proof_coverage(target_text)
        ):
            return "cross_scene_coordinate_rule_target_area_coverage"
        return None

    if _has_center_symmetry_coverage(
        non_target_text,
        require_final_coordinate=code == "final_answer_error"
        or "最终坐标" in description
        or "P2" in description
        or "P_2" in description,
    ):
        return "cross_scene_center_symmetry_coverage"
    return None


def _non_target_scene_text(script: str, target_scene: str) -> str:
    block = _extract_scene_block(script, target_scene)
    return script[: block.start] + script[block.end :] if block is not None else script


def _target_scene_text(script: str, target_scene: str) -> str:
    block = _extract_scene_block(script, target_scene)
    return script[block.start : block.end] if block is not None else ""


def _mentions_center_symmetry_obligation(text: str, code: str) -> bool:
    lowered = text.lower()
    mentions_center_symmetry = "中心对称" in text or "central symmetry" in lowered
    mentions_final_coordinate = (
        "最终坐标" in text
        or "最终坐标表达式" in text
        or "p2" in lowered
        or "p_2" in lowered
        or "-(x+a)" in text.replace(" ", "")
    )
    if code == "missing_subquestion":
        return mentions_center_symmetry
    return mentions_center_symmetry and mentions_final_coordinate


def _mentions_ab_bc_direction_obligation(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    mentions_ab_bc = "AB" in compact and "BC" in compact
    mentions_proof = "证明" in text or "像为" in text or "旋转后为" in text
    mentions_direction = "方向变化" in text or "边的方向" in text
    return mentions_ab_bc and mentions_proof and mentions_direction


def _mentions_direction_only_obligation(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    mentions_ab_bc = "AB" in compact and "BC" in compact
    target_already_has_edge_proof = "仅证明" in text and "像为" in text
    missing_direction = "未提及方向变化" in text or "未说明边的方向变化" in text
    return mentions_ab_bc and target_already_has_edge_proof and missing_direction


def _mentions_pair_correspondence_obligation(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    mentions_pair_goal = "A与D对应" in compact and "B与C对应" in compact
    target_missing_second_pair = "未提及B与C" in compact or "只涉及A与D" in compact
    return mentions_pair_goal and target_missing_second_pair


def _mentions_coordinate_area_obligation(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    mentions_coordinate_rule = (
        "顶点坐标变化规律" in compact
        or "坐标变化规律" in compact
        or ("横坐标不变" in compact and "纵坐标" in compact)
    )
    mentions_area = "面积不变" in compact or "面积相等" in compact
    return mentions_coordinate_rule and mentions_area


def _has_center_symmetry_coverage(
    script: str,
    *,
    require_final_coordinate: bool,
) -> bool:
    compact = re.sub(r"\s+", "", script)
    lowered = script.lower()
    has_center_symmetry = (
        "中心对称" in script
        or "centralsymmetry" in lowered
        or "central symmetry" in lowered
    )
    has_final_coordinate = (
        "P2" in script
        or "P_2" in script
        or "-(x+a)" in compact
        or "-(x+a),-(y+b)" in compact
        or "最终坐标" in script
    )
    return has_center_symmetry and (has_final_coordinate or not require_final_coordinate)


def _has_ab_bc_direction_coverage(script: str) -> bool:
    compact = re.sub(r"\s+", "", script)
    lowered = script.lower()
    proves_ab_to_bc = (
        "AB的像为BC" in compact
        or "AB变换为线段BC" in compact
        or ("AB" in compact and "BC" in compact and "证明" in script)
    )
    explains_direction = (
        "方向变化" in script
        or "方向向量" in script
        or "顺时针" in script
        or "vec" in lowered
    )
    return proves_ab_to_bc and explains_direction


def _has_direction_change_coverage(script: str) -> bool:
    lowered = script.lower()
    return (
        "方向变化" in script
        or "边的方向变化" in script
        or "顺时针偏转" in script
        or "逆时针偏转" in script
        or "方向向量" in script
        or "direction change" in lowered
    )


def _has_pair_correspondence_coverage(script: str) -> bool:
    compact = re.sub(r"\s+", "", script)
    return (
        "证明B与C对应" in compact
        or "证明B和C对应" in compact
        or (
            "B与C对应" in compact
            and "证明" in script
            and "求证" not in script
        )
    )


def _has_coordinate_area_coverage(script: str) -> bool:
    return _has_coordinate_rule_coverage(script) and _has_area_proof_coverage(script)


def _has_coordinate_rule_coverage(script: str) -> bool:
    compact = re.sub(r"\s+", "", script)
    return (
        "横坐标不变" in compact
        and ("纵坐标互为相反数" in compact or "纵坐标变符号" in compact)
    ) or "坐标变化规律" in compact


def _has_area_proof_coverage(script: str) -> bool:
    compact = re.sub(r"\s+", "", script)
    return (
        "证明面积不变" in compact
        or "推导" in compact
        or "计算验证" in compact
        or ("底边长度" in compact and ("高不变" in compact or "对应高" in compact))
    )


def _issue_with_suppression_metadata(issue: Any, method: str) -> dict[str, Any]:
    if isinstance(issue, Mapping):
        payload = dict(issue)
    else:
        payload = {"description": str(issue)}
    metadata = dict(payload.get("metadata") or {})
    metadata["suppressed_by"] = method
    payload["metadata"] = metadata
    payload["severity"] = payload.get("severity") or "hard"
    return payload


def _issue_with_condition_obligation_metadata(issue: Any) -> Any:
    if _issue_code(issue) != "missing_condition":
        return issue
    obligations = _condition_obligation_map(_case_text(issue, "description"))
    if not obligations:
        return issue
    if isinstance(issue, Mapping):
        payload = dict(issue)
    else:
        payload = {"description": str(issue), "code": "missing_condition"}
    metadata = dict(payload.get("metadata") or {})
    metadata["must_generate"] = True
    metadata["condition_repair_route"] = "route_to_math_condition_obligation_patch"
    metadata["condition_obligations"] = obligations
    metadata["missing_terms"] = _condition_missing_terms(obligations)
    payload["metadata"] = metadata
    payload["repairable"] = True
    payload["severity"] = payload.get("severity") or "hard"
    return payload


def _condition_obligation_map(description: str) -> list[dict[str, Any]]:
    compact = re.sub(r"\s+", "", description or "")
    obligations: list[dict[str, Any]] = []
    if (
        "全等" in compact
        or ("判定" in compact and "边角" in compact)
        or "SSS" in compact
        or "SAS" in compact
        or "ASA" in compact
        or "AAS" in compact
        or "HL" in compact
    ):
        obligations.append(
            {
                "obligation_id": "missing_condition.triangle_congruence_conditions",
                "required_terms": ["SSS", "SAS", "ASA", "AAS", "HL"],
                "required_scene_scope": "target_scene",
                "requires_formula": True,
                "requires_visual_object": True,
                "requires_animation": False,
                "can_suppress_if_covered": False,
                "must_generate_if_missing": True,
            }
        )
    if "棱柱" in compact or "截面" in compact:
        obligations.append(
            {
                "obligation_id": "missing_condition.prism_cross_section_model",
                "required_terms": ["棱柱", "截面"],
                "required_scene_scope": "target_scene",
                "requires_formula": False,
                "requires_visual_object": True,
                "requires_animation": True,
                "can_suppress_if_covered": False,
                "must_generate_if_missing": True,
            }
        )
    if "旋转中心" in compact and ("A'" in compact or "A′" in compact):
        obligations.append(
            {
                "obligation_id": "missing_condition.rotation_center_aprime",
                "required_terms": ["旋转中心", "A'"],
                "required_scene_scope": "target_scene",
                "requires_formula": False,
                "requires_visual_object": True,
                "requires_animation": False,
                "can_suppress_if_covered": False,
                "must_generate_if_missing": True,
            }
        )
    if "三条结论" in compact or ("核心结论" in compact and "易错点" in compact):
        obligations.append(
            {
                "obligation_id": "missing_condition.summary_three_points",
                "required_terms": ["核心结论", "易错点", "迁移"],
                "required_scene_scope": "target_scene",
                "requires_formula": False,
                "requires_visual_object": False,
                "requires_animation": "渐入" in compact,
                "can_suppress_if_covered": False,
                "must_generate_if_missing": True,
            }
        )
    if "交点" in compact or "垂足" in compact or "相交线" in compact or "相交直线" in compact:
        obligations.append(
            {
                "obligation_id": "missing_condition.intersection_foot_markers",
                "required_terms": ["交点", "垂足", "相交直线"],
                "required_scene_scope": "target_scene",
                "requires_formula": False,
                "requires_visual_object": True,
                "requires_animation": False,
                "can_suppress_if_covered": False,
                "must_generate_if_missing": True,
            }
        )
    if not obligations:
        obligations.append(
            {
                "obligation_id": "missing_condition.explicit_issue_terms",
                "required_terms": _extract_condition_terms(description),
                "required_scene_scope": "target_scene",
                "requires_formula": "公式" in compact,
                "requires_visual_object": any(term in compact for term in ("图", "模型", "标注")),
                "requires_animation": "动画" in compact or "渐入" in compact,
                "can_suppress_if_covered": False,
                "must_generate_if_missing": True,
            }
        )
    return obligations


def _condition_missing_terms(obligations: list[dict[str, Any]]) -> list[str]:
    terms: list[str] = []
    for obligation in obligations:
        for term in obligation.get("required_terms") or []:
            if isinstance(term, str) and term and term not in terms:
                terms.append(term)
    return terms


def _extract_condition_terms(description: str) -> list[str]:
    terms: list[str] = []
    for term in ("条件", "公式", "图形", "模型", "标注", "动画", "结论"):
        if term in (description or ""):
            terms.append(term)
    return terms or ["按 issue 描述补齐缺失条件"]


def _issue_code(issue: Any) -> str:
    return (
        _case_text(issue, "code")
        or _case_text(issue, "id")
        or _case_text(issue, "issue_code")
    )


def _mentions_rhombus_coordinate_error(text: str) -> bool:
    return "不构成菱形" in text or ("菱形" in text and "边长不等" in text)


def _mentions_segment_label_length_error(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    has_de_ce = "DE" in compact and "CE" in compact
    has_explicit_mismatch = (
        ("≠4" in compact or "标注写4" in compact)
        and ("≠8" in compact or "标注写8" in compact)
    )
    has_combined_label_mismatch = (
        ("标注4和8不符" in compact)
        or ("标注4和8" in compact and ("不符" in compact or "矛盾" in compact))
        or ("实际距离" in compact and "标注" in compact and "4" in compact and "8" in compact)
    )
    return has_de_ce and (has_explicit_mismatch or has_combined_label_mismatch)


def _mentions_rotation_image_segment_error(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    return (
        "AB" in compact
        and "像" in compact
        and ("B_rot" in compact or "B'" in compact or "B′" in compact)
        and ("C_rot" in compact or "C'" in compact or "C′" in compact)
        and ("B_rot到C_rot" in compact or "B'C'" in compact or "B′C′" in compact)
    )


def _mentions_midpoint_error(text: str) -> bool:
    compact = re.sub(r"\s+", "", text)
    return (
        "中点" in compact
        and "E" in compact
        and "BC" in compact
    )


def _geometry_relation_issue_resolved(
    issue: Any,
    *,
    script: str,
    target_scene: str,
) -> bool:
    block = _extract_scene_block(script, target_scene)
    if block is None:
        return False
    description = _case_text(issue, "description")
    if _mentions_rhombus_coordinate_error(description):
        return _target_scene_has_valid_rhombus(block.text)
    if _mentions_segment_label_length_error(description):
        return _target_scene_segment_lengths_match_labels(block.text)
    if _mentions_rotation_image_segment_error(description):
        return _target_scene_rotation_image_segment_matches(block.text)
    if _mentions_midpoint_error(description):
        return _target_scene_midpoint_relation_matches(block.text)
    return False


def _repair_scene_rhombus_coordinates(scene_text: str) -> tuple[str, bool]:
    points = _scene_point_assignments(scene_text)
    if not all(name in points for name in ("A", "B", "C", "D")):
        return scene_text, False
    if _points_form_rhombus([points["A"], points["B"], points["C"], points["D"]]):
        return scene_text, False

    a = points["A"]
    b = points["B"]
    c = points["C"]
    d = points["D"]
    midpoint = ((a[0] + c[0]) / 2.0, (a[1] + c[1]) / 2.0)
    ac_vector = (c[0] - a[0], c[1] - a[1])
    ac_length = _distance(a, c)
    if ac_length <= 1e-9:
        return scene_text, False
    perpendicular = (-ac_vector[1] / ac_length, ac_vector[0] / ac_length)
    half_bd = abs(b[0] - d[0]) / 2.0 or _distance(b, d) / 2.0
    if half_bd <= 1e-9:
        return scene_text, False
    new_b = (
        midpoint[0] + perpendicular[0] * half_bd,
        midpoint[1] + perpendicular[1] * half_bd,
    )
    new_d = (
        midpoint[0] - perpendicular[0] * half_bd,
        midpoint[1] - perpendicular[1] * half_bd,
    )
    fixed = _replace_scene_point_assignment(scene_text, "B", new_b)
    fixed = _replace_scene_point_assignment(fixed, "D", new_d)
    return fixed, fixed != scene_text


def _repair_scene_segment_label_lengths(scene_text: str) -> tuple[str, bool]:
    points = _scene_point_assignments(scene_text)
    if not all(name in points for name in ("C", "D", "E")):
        return scene_text, False
    if _target_scene_segment_lengths_match_labels(scene_text):
        return scene_text, False

    e = points["E"]
    repaired = scene_text
    for name, expected_length in (("D", 4.0), ("C", 8.0)):
        point = points[name]
        vector = (point[0] - e[0], point[1] - e[1])
        current_length = _distance(point, e)
        if current_length <= 1e-9:
            return scene_text, False
        scaled = (
            e[0] + vector[0] * expected_length / current_length,
            e[1] + vector[1] * expected_length / current_length,
        )
        repaired = _replace_scene_point_assignment(repaired, name, scaled)
    return repaired, repaired != scene_text


def _repair_scene_rotation_image_segment(scene_text: str) -> tuple[str, bool]:
    if "A_rot" not in scene_text or "B_rot" not in scene_text or "C_rot" not in scene_text:
        return scene_text, False
    repaired = _ROTATION_BAD_SEGMENT_RE.sub(
        lambda match: f"{match.group('prefix')}A_rot, B_rot{match.group('suffix')}",
        scene_text,
        count=1,
    )
    return repaired, repaired != scene_text


def _target_scene_has_valid_rhombus(scene_text: str) -> bool:
    points = _scene_point_assignments(scene_text)
    if not all(name in points for name in ("A", "B", "C", "D")):
        return False
    return _points_form_rhombus([points["A"], points["B"], points["C"], points["D"]])


def _target_scene_segment_lengths_match_labels(scene_text: str) -> bool:
    points = _scene_point_assignments(scene_text)
    if not all(name in points for name in ("C", "D", "E")):
        return False
    has_de_label = re.search(r"label_DE\s*=\s*MathTex\(\s*[\"']4[\"']", scene_text)
    has_ce_label = re.search(r"label_CE\s*=\s*MathTex\(\s*[\"']8[\"']", scene_text)
    if not has_de_label or not has_ce_label:
        return False
    return _close_float(_distance(points["D"], points["E"]), 4.0, tolerance=0.03) and _close_float(
        _distance(points["C"], points["E"]),
        8.0,
        tolerance=0.03,
    )


def _target_scene_rotation_image_segment_matches(scene_text: str) -> bool:
    has_bad_segment = re.search(r"\bLine\(\s*B_rot\s*,\s*C_rot\b", scene_text)
    has_repaired_segment = re.search(r"\bLine\(\s*A_rot\s*,\s*B_rot\b", scene_text)
    return bool(has_repaired_segment and not has_bad_segment)


def _target_scene_midpoint_relation_matches(scene_text: str) -> bool:
    points = _scene_point_assignments(scene_text)
    if not all(name in points for name in ("B", "C", "E")):
        return False
    midpoint = (
        (points["B"][0] + points["C"][0]) / 2.0,
        (points["B"][1] + points["C"][1]) / 2.0,
    )
    return _distance(points["E"], midpoint) <= 0.03


def _scene_point_assignments(scene_text: str) -> dict[str, tuple[float, float]]:
    points: dict[str, tuple[float, float]] = {}
    for match in _ORIGIN_ASSIGNMENT_RE.finditer(scene_text):
        points[match.group("name")] = (0.0, 0.0)
    for match in _POINT_ASSIGNMENT_RE.finditer(scene_text):
        points[match.group("name")] = (
            float(match.group("x")),
            float(match.group("y")),
        )
    for match in _POINT_PLUS_OFFSET_ASSIGNMENT_RE.finditer(scene_text):
        points[match.group("name")] = (
            float(match.group("x")),
            float(match.group("y")),
        )
    changed = True
    while changed:
        changed = False
        for match in _OFFSET_POINT_ASSIGNMENT_RE.finditer(scene_text):
            name = match.group("name")
            base = match.group("base")
            if name in points or base not in points:
                continue
            points[name] = (
                points[base][0] + float(match.group("x")),
                points[base][1] + float(match.group("y")),
            )
            changed = True
    return points


_ROTATION_BAD_SEGMENT_RE = re.compile(
    r"(?P<prefix>\b[A-Za-z_][A-Za-z0-9_]*\s*=\s*Line\(\s*)"
    r"B_rot\s*,\s*C_rot"
    r"(?P<suffix>\s*(?:,|\)))"
)

_ORIGIN_ASSIGNMENT_RE = re.compile(
    r"(?m)^\s*(?P<name>[A-Z])\s*=\s*ORIGIN\s*$"
)

_POINT_ASSIGNMENT_RE = re.compile(
    r"(?m)^(?P<indent>\s*)(?P<name>[A-Z])\s*=\s*np\.array\(\s*\[\s*"
    r"(?P<x>[-+]?\d+(?:\.\d+)?),\s*"
    r"(?P<y>[-+]?\d+(?:\.\d+)?),\s*"
    r"(?P<z>[-+]?\d+(?:\.\d+)?)\s*\]\s*"
    r"(?:,\s*dtype=float)?\s*\)\s*$"
)

_POINT_PLUS_OFFSET_ASSIGNMENT_RE = re.compile(
    r"(?m)^\s*(?P<name>[A-Z])\s*=\s*np\.array\(\s*\[\s*"
    r"(?P<x>[-+]?\d+(?:\.\d+)?),\s*"
    r"(?P<y>[-+]?\d+(?:\.\d+)?),\s*"
    r"(?P<z>[-+]?\d+(?:\.\d+)?)\s*\]\s*"
    r"(?:,\s*dtype=float)?\s*\)\s*\+\s*[A-Za-z_][A-Za-z0-9_]*\s*$"
)

_OFFSET_POINT_ASSIGNMENT_RE = re.compile(
    r"(?m)^\s*(?P<name>[A-Z])\s*=\s*(?P<base>[A-Z])\s*\+\s*"
    r"np\.array\(\s*\[\s*"
    r"(?P<x>[-+]?\d+(?:\.\d+)?),\s*"
    r"(?P<y>[-+]?\d+(?:\.\d+)?),\s*"
    r"(?P<z>[-+]?\d+(?:\.\d+)?)\s*\]\s*"
    r"(?:,\s*dtype=float)?\s*\)\s*$"
)


def _replace_scene_point_assignment(
    scene_text: str,
    name: str,
    point: tuple[float, float],
) -> str:
    pattern = re.compile(
        rf"(?m)^(?P<indent>\s*){re.escape(name)}\s*=\s*np\.array\(\s*\[\s*"
        r"[-+]?\d+(?:\.\d+)?,\s*[-+]?\d+(?:\.\d+)?,\s*[-+]?\d+(?:\.\d+)?\s*\]\s*"
        r"(?:,\s*dtype=float)?\s*\)(?P<suffix>\s*\+\s*[A-Za-z_][A-Za-z0-9_]*)?\s*$"
    )

    def repl(match: re.Match[str]) -> str:
        suffix = match.group("suffix") or ""
        return (
            f"{match.group('indent')}{name} = "
            f"np.array([{_format_float(point[0])}, {_format_float(point[1])}, 0]){suffix}"
        )

    return pattern.sub(repl, scene_text, count=1)


def _points_form_rhombus(points: list[tuple[float, float]]) -> bool:
    if len(points) != 4:
        return False
    sides = [
        _distance(points[index], points[(index + 1) % 4])
        for index in range(4)
    ]
    if min(sides) <= 1e-9:
        return False
    average = sum(sides) / 4.0
    return all(abs(side - average) <= max(0.03, average * 0.02) for side in sides)


def _distance(first: tuple[float, float], second: tuple[float, float]) -> float:
    return ((first[0] - second[0]) ** 2 + (first[1] - second[1]) ** 2) ** 0.5


def _close_float(value: float, expected: float, *, tolerance: float) -> bool:
    return abs(value - expected) <= tolerance


def _format_float(value: float) -> str:
    text = f"{value:.6f}".rstrip("0").rstrip(".")
    return "0" if text == "-0" else text


def _string_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    if isinstance(value, tuple):
        return [str(item) for item in value]
    if value is None:
        return []
    return [str(value)]
