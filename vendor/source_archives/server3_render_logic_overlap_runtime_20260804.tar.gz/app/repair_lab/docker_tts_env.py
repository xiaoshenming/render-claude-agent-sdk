"""Repair lab Docker TTS 环境参数。"""
from __future__ import annotations

import os
from pathlib import Path


def docker_tts_lock_mount_args() -> list[str]:
    host_lock_dir = Path(os.environ.get("MATHPI_TTS_LOCK_HOST_DIR") or "/tmp/mathpi-tts-locks")
    container_lock_dir = os.environ.get("MATHPI_TTS_LOCK_DIR") or "/tmp/mathpi-tts-locks"
    host_lock_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(host_lock_dir, 0o777)
    except OSError:
        pass
    return ["-v", f"{host_lock_dir.resolve()}:{container_lock_dir}:rw", "-e", f"MATHPI_TTS_LOCK_DIR={container_lock_dir}"]


def docker_tts_env_args(*, enable_tts: bool) -> list[str]:
    if not enable_tts:
        return [
            "-e", "XIAOMI_MIMO_API_KEY=dummy", "-e", "XIAOMI_MIMO_API_BASE=http://127.0.0.1:9/v1",
            "-e", "MIMO_TTS_ALLOW_FALLBACK=1", "-e", "MIMO_TTS_SYNTHESIS_RETRIES=1", "-e", "MIMO_TTS_TIMEOUT=10",
            "-e", "DASHSCOPE_API_KEY=dummy", "-e", "DASHSCOPE_API_BASE=http://127.0.0.1:9",
            "-e", "COSYVOICE_ALLOW_TTS_FALLBACK=1", "-e", "COSYVOICE_SYNTHESIS_RETRIES=1",
            "-e", "COSYVOICE_SYNTHESIS_RETRY_BASE_SEC=0", "-e", "DOUBAO_API_KEY=dummy", "-e", "DOUBAO_TTS_TIMEOUT=10",
        ]
    names = [
        "MATHPI_SYSTEM_TTS_PROVIDER", "COSYVOICE_DEFAULT_VOICE", "COSYVOICE_MODEL", "COSYVOICE_ALLOW_TTS_FALLBACK",
        "COSYVOICE_SYNTHESIS_RETRIES", "COSYVOICE_SYNTHESIS_RETRY_BASE_SEC", "COSYVOICE_TIMEOUT", "DOUBAO_API_KEY",
        "DOUBAO_TTS_RESOURCE_ID", "DOUBAO_TTS_DEFAULT_VOICE", "DOUBAO_TTS_EMOTION", "DOUBAO_TTS_EMOTION_SCALE",
        "DOUBAO_TTS_LOUDNESS_RATE", "DOUBAO_TTS_PITCH", "DOUBAO_TTS_SILENCE_MS", "DOUBAO_TTS_SPEECH_RATE",
        "DOUBAO_TTS_TIMEOUT", "DASHSCOPE_API_KEY", "DASHSCOPE_API_BASE", "XIAOMI_MIMO_API_KEY", "XIAOMI_MIMO_API_BASE",
        "MIMO_TTS_ALLOW_FALLBACK", "MIMO_TTS_SYNTHESIS_RETRIES", "MIMO_TTS_TIMEOUT", "MIMO_TTS_RATE_LIMIT_COOLDOWN_SEC",
        "MATHPI_TTS_PROVIDER_CONCURRENCY", "MATHPI_TTS_PROVIDER_RPM_LIMIT", "MATHPI_TTS_PROVIDER_MIN_INTERVAL_SEC",
        "MATHPI_TTS_SLOT_TIMEOUT_SEC", "MATHPI_TTS_LOCK_POLL_SEC",
    ]
    defaults = {
        "MATHPI_SYSTEM_TTS_PROVIDER": "cosyvoice", "COSYVOICE_DEFAULT_VOICE": "longxiaoxia_v3", "COSYVOICE_MODEL": "cosyvoice-v3-flash",
        "COSYVOICE_ALLOW_TTS_FALLBACK": "0", "COSYVOICE_SYNTHESIS_RETRIES": "2", "COSYVOICE_SYNTHESIS_RETRY_BASE_SEC": "0.8",
        "DOUBAO_TTS_RESOURCE_ID": "seed-tts-2.0", "DOUBAO_TTS_DEFAULT_VOICE": "zh_male_jieshuoxiaoming_uranus_bigtts", "DOUBAO_TTS_TIMEOUT": "60",
        "MATHPI_TTS_PROVIDER_CONCURRENCY": "1", "MATHPI_TTS_PROVIDER_RPM_LIMIT": "100", "MATHPI_TTS_PROVIDER_MIN_INTERVAL_SEC": "0",
        "MATHPI_TTS_SLOT_TIMEOUT_SEC": "600", "MATHPI_TTS_LOCK_POLL_SEC": "0.05",
    }
    args: list[str] = []
    for name in names:
        value = os.environ.get(name, defaults.get(name, ""))
        if value:
            args.extend(["-e", f"{name}={value}"])
    return args
