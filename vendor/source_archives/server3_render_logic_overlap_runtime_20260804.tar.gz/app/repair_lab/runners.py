"""Pure-Python point-to-point runners for render repair-lab.

These runners deliberately avoid Manim, RabbitMQ, DB repositories, and the
normal render job pipeline. Real repair/review behavior must be injected with
adapter callables by tests, CLI, or server3 point runs.
"""

from __future__ import annotations

import ast
import difflib
import json
from pathlib import Path
from typing import Any, Callable, Mapping


RepairFn = Callable[..., Any]
ReviewFn = Callable[..., Any]


def run_slice_patch_pre_render(
    case: Any,
    out_dir: str | Path,
    repair_fn: RepairFn | None = None,
) -> dict[str, Any]:
    """Run a single-scene slice repair check with an injected repair adapter."""

    runner_name = "slice_patch_pre_render"
    out_path = _ensure_out_dir(out_dir)
    base = _base_result(case, runner_name)

    script = _load_case_script(case)
    target_scene = _target_scene(case)
    signature = _str_or_empty(_get(case, "failure", "signature"))

    if repair_fn is None:
        return _failed_result(
            base,
            "REPAIR_FAILED",
            "slice repair_fn adapter is required for repair-lab runner",
            metrics={
                "target_scene": target_scene,
                "failure_signature_removed": False,
            },
        )

    try:
        repair_result = repair_fn(
            case,
            script=script,
            target_scene=target_scene,
            out_dir=out_path,
        )
    except Exception as exc:  # pragma: no cover - defensive adapter boundary
        return _failed_result(
            base,
            "REPAIR_FAILED",
            str(exc),
            metrics={
                "target_scene": target_scene,
                "repair_error_type": type(exc).__name__,
                "failure_signature_removed": False,
            },
        )

    patched_script = _extract_script(repair_result)
    if not patched_script:
        return _failed_result(
            base,
            "REPAIR_FAILED",
            "slice repair_fn did not return a patched script",
            metrics={
                "target_scene": target_scene,
                "failure_signature_removed": False,
            },
        )

    changed_scene_names = _changed_scene_names(script, patched_script)
    if _get(repair_result, "preserves_named_scene_blocks"):
        changed_scene_names = []
    signature_removed = _failure_signature_removed(
        repair_result,
        before_script=script,
        after_script=patched_script,
        signature=signature,
    )
    non_target_changes = [
        scene for scene in changed_scene_names if scene != target_scene
    ]

    script_changed = patched_script != script
    if non_target_changes:
        status = "REPAIR_WORSE"
    elif signature_removed and (changed_scene_names or script_changed):
        status = "SUCCESS_CLEAN"
    else:
        status = "REPAIR_UNCHANGED"

    _write_script_artifacts(out_path, script, patched_script)
    base.update(
        {
            "status": status,
            "changed_scene_names": changed_scene_names,
            "metrics": {
                "target_scene": target_scene,
                "repair_method": _repair_method(repair_result),
                "failure_signature_removed": signature_removed,
                "non_target_scene_changes": non_target_changes,
            },
        }
    )
    return base


def run_layout_post_review(
    case: Any,
    out_dir: str | Path,
    review_fn: ReviewFn | None = None,
    repair_fn: RepairFn | None = None,
) -> dict[str, Any]:
    """Run target-scene layout repair and score before/after review decisions."""

    runner_name = "layout_post_review"
    out_path = _ensure_out_dir(out_dir)
    base = _base_result(case, runner_name)

    script = _load_case_script(case)
    target_scene = _target_scene(case)
    before_decision = _load_layout_decision_before(case)

    before_count = _overlap_count(before_decision)
    before_ratio = _max_overlap_ratio(before_decision)

    if repair_fn is None:
        return _failed_result(
            base,
            "REPAIR_FAILED",
            "layout repair_fn adapter is required for repair-lab runner",
            metrics={
                "target_scene": target_scene,
                "before_overlap_count": before_count,
                "before_max_overlap_ratio": before_ratio,
            },
        )
    if review_fn is None:
        return _failed_result(
            base,
            "REVIEW_ERROR",
            "layout review_fn adapter is required for repair-lab runner",
            metrics={
                "target_scene": target_scene,
                "before_overlap_count": before_count,
                "before_max_overlap_ratio": before_ratio,
            },
        )

    try:
        repair_result = repair_fn(
            case,
            script=script,
            target_scene=target_scene,
            out_dir=out_path,
        )
        patched_script = _extract_script(repair_result) or script
        after_decision = review_fn(
            case,
            script=patched_script,
            target_scene=target_scene,
            out_dir=out_path,
        )
    except Exception as exc:  # pragma: no cover - defensive adapter boundary
        return _failed_result(
            base,
            "REVIEW_ERROR",
            str(exc),
            metrics={
                "target_scene": target_scene,
                "review_error_type": type(exc).__name__,
                "before_overlap_count": before_count,
                "before_max_overlap_ratio": before_ratio,
            },
        )

    after_count = _overlap_count(after_decision)
    after_ratio = _max_overlap_ratio(after_decision)
    changed_scene_names = _changed_scene_names(script, patched_script)
    non_target_changes = [
        scene for scene in changed_scene_names if scene != target_scene
    ]

    outcome, status = _score_layout(
        before_count=before_count,
        before_ratio=before_ratio,
        after_count=after_count,
        after_ratio=after_ratio,
    )
    if non_target_changes:
        outcome = "worse"
        status = "REPAIR_WORSE"

    _write_script_artifacts(out_path, script, patched_script)
    _write_json(out_path / "layout_decision_before.json", before_decision)
    _write_json(out_path / "layout_decision_after.json", after_decision)

    base.update(
        {
            "status": status,
            "outcome": outcome,
            "changed_scene_names": changed_scene_names,
            "metrics": {
                "target_scene": target_scene,
                "layout_repair_method": _layout_repair_method(repair_result),
                "before_overlap_count": before_count,
                "after_overlap_count": after_count,
                "before_max_overlap_ratio": before_ratio,
                "after_max_overlap_ratio": after_ratio,
                "max_residual_overlap_ratio": after_ratio,
                "non_target_scene_changes": non_target_changes,
            },
        }
    )
    return base


def run_math_logic_post_review(
    case: Any,
    out_dir: str | Path,
    review_fn: ReviewFn | None = None,
    repair_fn: RepairFn | None = None,
) -> dict[str, Any]:
    """Run math-logic repair and re-review with injected adapters only."""

    runner_name = "math_logic_post_review"
    out_path = _ensure_out_dir(out_dir)
    base = _base_result(case, runner_name)

    script = _load_case_script(case)
    target_scene = _target_scene(case)
    before_issues = _list_or_empty(_get(case, "initial_quality_issues"))
    before_hard = _hard_issues(before_issues)
    before_hard_ids = {_issue_key(issue) for issue in before_hard}

    if repair_fn is None:
        return _failed_result(
            base,
            "REPAIR_FAILED",
            "math repair_fn adapter is required for repair-lab runner",
            metrics={
                "target_scene": target_scene,
                "before_hard_issue_count": len(before_hard),
            },
        )
    if review_fn is None:
        return _failed_result(
            base,
            "REVIEW_ERROR",
            "math review_fn adapter is required for repair-lab runner",
            metrics={
                "target_scene": target_scene,
                "before_hard_issue_count": len(before_hard),
            },
        )

    try:
        repair_result = repair_fn(
            case,
            script=script,
            target_scene=target_scene,
            out_dir=out_path,
        )
        patched_script = _extract_script(repair_result) or script
        review_result = review_fn(
            case,
            script=patched_script,
            target_scene=target_scene,
            out_dir=out_path,
        )
    except Exception as exc:
        base.update(
            {
                "status": "REVIEW_ERROR",
                "changed_scene_names": [],
                "metrics": {
                    "target_scene": target_scene,
                    "before_hard_issue_count": len(before_hard),
                    "review_error_type": type(exc).__name__,
                },
                "failure_if_any": str(exc),
            }
        )
        return base

    review_status = _str_or_empty(_get(review_result, "status")).lower()
    if review_status in {"error", "failed", "timeout", "json_error", "provider_error"}:
        base.update(
            {
                "status": "REVIEW_ERROR",
                "changed_scene_names": _changed_scene_names(script, patched_script),
                "metrics": {
                    "target_scene": target_scene,
                    "before_hard_issue_count": len(before_hard),
                    "review_status": review_status,
                },
                "failure_if_any": "math review returned an error status",
            }
        )
        return base

    after_issues = _review_issues(review_result)
    after_hard = _hard_issues(after_issues)
    suppressed_issues = _review_suppressed_issues(review_result)
    suppressed_hard = _hard_issues(suppressed_issues)
    after_hard_ids = {_issue_key(issue) for issue in after_hard}
    original_remaining = before_hard_ids & after_hard_ids
    new_hard = after_hard_ids - before_hard_ids
    repair_method = _repair_method(repair_result)
    route_reason = _get(repair_result, "route_reason")

    if repair_method and repair_method.startswith("route_to_"):
        status = "REPAIR_UNCHANGED"
    elif not original_remaining and not new_hard:
        status = "SUCCESS_CLEAN"
    elif len(original_remaining) < len(before_hard_ids) and not new_hard:
        status = "SUCCESS_DEGRADED"
    else:
        status = "REPAIR_FAILED"

    changed_scene_names = _changed_scene_names(script, patched_script)
    _write_script_artifacts(out_path, script, patched_script)
    _write_json(out_path / "math_review_after.json", review_result)

    base.update(
        {
            "status": status,
            "changed_scene_names": changed_scene_names,
            "metrics": {
                "target_scene": target_scene,
                "repair_method": repair_method,
                "route_reason": str(route_reason) if route_reason else None,
                "before_hard_issue_count": len(before_hard),
                "after_hard_issue_count": len(after_hard),
                "original_remaining_hard_issue_count": len(original_remaining),
                "new_hard_issue_count": len(new_hard),
                "original_hard_issues_cleared": not original_remaining,
                "suppressed_hard_issue_count": len(suppressed_hard),
                "suppression_methods": _suppression_methods(suppressed_issues),
            },
        }
    )
    return base


def run_repair_lab_case(
    case: Any,
    out_dir: str | Path,
    runner: str | Callable[..., dict[str, Any]] | None = None,
    hooks: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Dispatch a repair-lab case to one point-to-point runner."""

    selected_runner = runner or _get(case, "lane")
    hook_map = dict(hooks or {})

    if callable(selected_runner):
        return selected_runner(case, out_dir, **hook_map)

    if selected_runner == "slice_patch_pre_render":
        return run_slice_patch_pre_render(
            case,
            out_dir,
            repair_fn=hook_map.get("repair_fn"),
        )
    if selected_runner == "layout_post_review":
        return run_layout_post_review(
            case,
            out_dir,
            review_fn=hook_map.get("review_fn"),
            repair_fn=hook_map.get("repair_fn"),
        )
    if selected_runner == "math_logic_post_review":
        return run_math_logic_post_review(
            case,
            out_dir,
            review_fn=hook_map.get("review_fn"),
            repair_fn=hook_map.get("repair_fn"),
        )

    raise ValueError(f"unknown repair-lab runner: {selected_runner!r}")


def _base_result(case: Any, runner_name: str) -> dict[str, Any]:
    return {
        "case_id": _get(case, "case_id"),
        "runner": runner_name,
        "selected_repair_skill": _selected_repair_skill(case),
        "status": "REPAIR_FAILED",
        "changed_scene_names": [],
        "metrics": {},
        "db_write_count": 0,
        "mq_publish_count": 0,
        "failure_if_any": None,
    }


def _failed_result(
    base: dict[str, Any],
    status: str,
    message: str,
    *,
    metrics: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    base.update(
        {
            "status": status,
            "changed_scene_names": [],
            "metrics": dict(metrics or {}),
            "failure_if_any": message,
        }
    )
    return base


def _ensure_out_dir(out_dir: str | Path) -> Path:
    path = Path(out_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _load_case_script(case: Any) -> str:
    inline_script = _get(case, "script")
    if isinstance(inline_script, str):
        return inline_script

    script_path = _get(case, "input_artifacts", "script_path") or _get(
        case,
        "input_artifacts",
        "script",
    )
    if not script_path:
        raise ValueError("repair-lab case is missing input_artifacts.script_path")
    return _resolve_case_path(case, str(script_path)).read_text(encoding="utf-8")


def _load_layout_decision_before(case: Any) -> dict[str, Any]:
    inline_decision = _get(case, "layout_decision_before")
    if isinstance(inline_decision, Mapping):
        return dict(inline_decision)

    decision_path = _get(case, "input_artifacts", "layout_decision_path")
    if decision_path:
        with _resolve_case_path(case, str(decision_path)).open("r", encoding="utf-8") as fp:
            loaded = json.load(fp)
        if isinstance(loaded, Mapping):
            return dict(loaded)

    return {}


def _target_scene(case: Any) -> str:
    return _str_or_empty(
        _get(case, "repair_spec", "target_scene")
        or _get(case, "scene_name")
        or _get(case, "source", "scene_name")
    )


def _selected_repair_skill(case: Any) -> str | None:
    value = _get(case, "repair_spec", "selected_repair_skill") or _get(
        case,
        "selected_repair_skill",
    )
    return str(value) if value is not None else None


def _extract_script(repair_result: Any) -> str | None:
    if isinstance(repair_result, str):
        return repair_result
    if isinstance(repair_result, Mapping):
        for key in ("script", "patched_script", "output_script"):
            value = repair_result.get(key)
            if isinstance(value, str):
                return value
    value = _get(repair_result, "script")
    return value if isinstance(value, str) else None


def _repair_method(repair_result: Any) -> str | None:
    for key in ("repair_method", "method"):
        value = _get(repair_result, key)
        if value:
            return str(value)
    return None


def _layout_repair_method(repair_result: Any) -> str | None:
    value = _get(repair_result, "layout_repair_method")
    if value:
        return str(value)
    return _repair_method(repair_result)


def _failure_signature_removed(
    repair_result: Any,
    *,
    before_script: str,
    after_script: str,
    signature: str,
) -> bool:
    explicit = _get(repair_result, "failure_signature_removed")
    if explicit is not None:
        return bool(explicit)
    return bool(signature) and signature in before_script and signature not in after_script


def _changed_scene_names(before_script: str, after_script: str) -> list[str]:
    before_blocks = _scene_blocks(before_script)
    after_blocks = _scene_blocks(after_script)
    ordered_names = list(before_blocks)
    ordered_names.extend(name for name in after_blocks if name not in before_blocks)

    return [
        name
        for name in ordered_names
        if before_blocks.get(name) != after_blocks.get(name)
    ]


def _scene_blocks(script: str) -> dict[str, str]:
    lines = script.splitlines()
    try:
        tree = ast.parse(script)
    except SyntaxError:
        return _scene_blocks_by_text(lines)

    blocks: dict[str, str] = {}
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        if not _looks_like_scene_class(node):
            continue
        end_lineno = getattr(node, "end_lineno", node.lineno)
        blocks[node.name] = "\n".join(lines[node.lineno - 1 : end_lineno])
    return blocks


def _scene_blocks_by_text(lines: list[str]) -> dict[str, str]:
    blocks: dict[str, str] = {}
    current_name: str | None = None
    current_lines: list[str] = []

    for line in lines:
        if (
            line.startswith("class Scene")
            or line.startswith("class ShortVideo")
        ) and "(" in line:
            if current_name is not None:
                blocks[current_name] = "\n".join(current_lines)
            current_name = line.split("class ", 1)[1].split("(", 1)[0].strip()
            current_lines = [line]
        elif current_name is not None:
            current_lines.append(line)

    if current_name is not None:
        blocks[current_name] = "\n".join(current_lines)
    return blocks


def _looks_like_scene_class(node: ast.ClassDef) -> bool:
    return node.name.startswith(("Scene", "ShortVideo"))


def _score_layout(
    *,
    before_count: int,
    before_ratio: float,
    after_count: int,
    after_ratio: float,
) -> tuple[str, str]:
    if after_count > before_count or after_ratio > before_ratio:
        return "worse", "REPAIR_WORSE"

    unchanged_ratio_floor = before_ratio * 0.95
    if after_count == before_count and after_ratio >= unchanged_ratio_floor:
        return "unchanged", "REPAIR_UNCHANGED"

    if after_count == 0 and after_ratio <= min(before_ratio, 0.08):
        return "improved", "SUCCESS_CLEAN"

    return "improved", "SUCCESS_DEGRADED"


def _overlap_count(decision: Any) -> int:
    direct = _get(decision, "overlap_count")
    if direct is not None:
        return _safe_int(direct)

    issues = _list_or_empty(_get(decision, "issues"))
    if issues:
        return sum(1 for issue in issues if _is_overlap_issue(issue))

    layout_errors = _get(decision, "layout_error_count")
    if layout_errors is not None:
        return _safe_int(layout_errors)

    return 0


def _max_overlap_ratio(decision: Any) -> float:
    for key in (
        "max_overlap_ratio",
        "max_residual_overlap_ratio",
        "after_max_overlap_ratio",
    ):
        value = _get(decision, key)
        if value is not None:
            return _safe_float(value)

    issues = _list_or_empty(_get(decision, "issues"))
    ratios = [
        _safe_float(
            _get(issue, "overlap_ratio")
            or _get(issue, "max_overlap_ratio")
            or _get(issue, "ratio")
        )
        for issue in issues
        if _is_overlap_issue(issue)
    ]
    return max(ratios, default=0.0)


def _is_overlap_issue(issue: Any) -> bool:
    code = _str_or_empty(
        _get(issue, "code")
        or _get(issue, "type")
        or _get(issue, "failure_code")
        or _get(issue, "issue_code")
    ).lower()
    return "overlap" in code


def _review_issues(review_result: Any) -> list[Any]:
    if isinstance(review_result, list):
        return review_result
    for key in ("issues", "quality_issues", "hard_issues"):
        value = _get(review_result, key)
        if isinstance(value, list):
            return value
    return []


def _review_suppressed_issues(review_result: Any) -> list[Any]:
    value = _get(review_result, "suppressed_issues")
    return value if isinstance(value, list) else []


def _suppression_methods(issues: list[Any]) -> list[str]:
    methods = {
        str(method)
        for issue in issues
        for method in (
            _get(issue, "metadata", "suppressed_by"),
            _get(issue, "suppressed_by"),
        )
        if method
    }
    return sorted(methods)


def _hard_issues(issues: list[Any]) -> list[Any]:
    return [issue for issue in issues if _is_hard_issue(issue)]


def _is_hard_issue(issue: Any) -> bool:
    severity = _str_or_empty(_get(issue, "severity")).lower()
    if severity == "hard":
        return True
    level = _str_or_empty(_get(issue, "level")).lower()
    return level == "hard"


def _issue_key(issue: Any) -> str:
    for key in ("id", "code", "issue_code", "signature", "title", "description"):
        value = _get(issue, key)
        if value:
            return str(value)
    return json.dumps(issue, sort_keys=True, ensure_ascii=True, default=str)


def _write_script_artifacts(out_dir: Path, before_script: str, after_script: str) -> None:
    (out_dir / "output.py").write_text(after_script, encoding="utf-8")
    diff = difflib.unified_diff(
        before_script.splitlines(),
        after_script.splitlines(),
        fromfile="before.py",
        tofile="after.py",
        lineterm="",
    )
    (out_dir / "patch.diff").write_text("\n".join(diff), encoding="utf-8")


def _write_json(path: Path, data: Any) -> None:
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def _resolve_case_path(case: Any, path: str) -> Path:
    candidate = Path(path)
    if candidate.is_absolute():
        return candidate

    case_dir = _get(case, "__case_dir")
    if case_dir:
        return Path(str(case_dir)) / candidate
    return candidate


def _get(obj: Any, *path: str) -> Any:
    current = obj
    for part in path:
        if current is None:
            return None
        if isinstance(current, Mapping):
            current = current.get(part)
            continue
        current = getattr(current, part, None)
    return current


def _list_or_empty(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _str_or_empty(value: Any) -> str:
    return "" if value is None else str(value)


def _safe_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _safe_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0
