"""A-line repair-lab Manim Docker video verification."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Mapping
from app.repair_lab.docker_tts_env import docker_tts_env_args, docker_tts_lock_mount_args
from app.repair_lab.scene_discovery import (
    base_name as _base_name,
    default_custom_services_dir as _default_custom_services_dir,
    default_render_assets_dir as _default_render_assets_dir,
    docker_container_name as _docker_container_name,
    find_rendered_mp4 as _find_rendered_mp4,
    force_remove_docker_container as _force_remove_docker_container,
    is_renderable_scene_class as _is_renderable_scene_class,
    resolve_scene_name_for_script as _resolve_scene_name_for_script,
    scene_class_names as _scene_class_names,
    scene_class_names_by_regex as _scene_class_names_by_regex,
    scene_name_from_score as _scene_name_from_score,
)
from app.repair_lab.render_output_helpers import render_summary_markdown, write_json


def render_clean_scores_for_run(
    *,
    run_root: str | Path,
    profile: str = "rules-v2-local-slice",
    status: str = "SUCCESS_CLEAN",
    lanes: set[str] | None = None,
    limit: int | None = None,
    image: str | None = None,
    timeout_sec: int | None = None,
    runner: Runner = subprocess.run,
) -> dict[str, Any]:
    """Render repaired outputs for clean score rows in an existing A-line run."""

    root = Path(run_root)
    scores = json.loads((root / "scores.json").read_text(encoding="utf-8"))
    if not isinstance(scores, list):
        raise ValueError("scores.json must contain a list")

    selected = [
        row
        for row in scores
        if str(row.get("profile")) == profile
        and str(row.get("status")) == status
        and (lanes is None or str(row.get("runner")) in lanes)
    ]
    if limit is not None:
        selected = selected[:limit]

    checks: list[dict[str, Any]] = []
    checks_root = root / "video_checks" / profile
    for row in selected:
        case_id = str(row.get("case_id") or "")
        scene_name = _scene_name_from_score(row)
        script_path = root / "runs" / profile / "cases" / case_id / "output.py"
        check_dir = checks_root / case_id
        if not script_path.exists():
            check = {
                "render_ok": False,
                "case_id": case_id,
                "scene_name": scene_name,
                "source_script": str(script_path),
                "errors": ["repaired_output_missing"],
            }
            check_dir.mkdir(parents=True, exist_ok=True)
            _write_json(check_dir / "docker_render_check.json", check)
        else:
            scene_name = _resolve_scene_name_for_script(scene_name, script_path)
            check = run_manim_docker_render(
                script_path=script_path,
                scene_name=scene_name,
                output_dir=check_dir,
                image=image,
                timeout_sec=timeout_sec,
                runner=runner,
            )
            check["case_id"] = case_id
            check["runner"] = row.get("runner")
            check["failure_code"] = row.get("failure_code")
            check["selected_repair_skill"] = row.get("selected_repair_skill")
            check["source_script"] = str(script_path)
            _write_json(Path(check["check_json"]), check)
        checks.append(check)

    summary = {
        "profile": profile,
        "status": status,
        "candidate_count": len(selected),
        "render_ok_count": sum(1 for item in checks if item.get("render_ok")),
        "render_fail_count": sum(1 for item in checks if not item.get("render_ok")),
        "db_write_count": 0,
        "mq_publish_count": 0,
        "checks": checks,
    }
    checks_root.mkdir(parents=True, exist_ok=True)
    _write_json(checks_root / "video-render-summary.json", summary)
    (checks_root / "video-render-summary.md").write_text(
        _render_summary_markdown(summary),
        encoding="utf-8",
    )
    return summary

