"""A-line repair-lab Manim Docker video verification."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Mapping
from app.repair_lab.docker_tts_env import docker_tts_env_args, docker_tts_lock_mount_args
from app.repair_lab.scene_discovery import (
    base_name as _base_name,
    default_custom_services_dir as _default_custom_services_dir,
    default_render_assets_dir as _default_render_assets_dir,
    docker_container_name as _docker_container_name,
    find_rendered_mp4 as _find_rendered_mp4,
    force_remove_docker_container as _force_remove_docker_container,
    is_renderable_scene_class as _is_renderable_scene_class,
    resolve_scene_name_for_script as _resolve_scene_name_for_script,
    scene_class_names as _scene_class_names,
    scene_class_names_by_regex as _scene_class_names_by_regex,
    scene_name_from_score as _scene_name_from_score,
)
from app.repair_lab.render_output_helpers import render_summary_markdown, write_json


def prepare_candidate_script_for_manim(
    source: str,
    *,
    isolated_runtime_compat: bool = True,
    enable_tts: bool = False,
) -> str:
    """Return a renderable candidate script for isolated Manim scene checks."""

    source = _normalize_isolated_scene_source(source, enable_tts=enable_tts)
    if not enable_tts:
        source = re.sub(
            r"(?m)^(?P<indent>\s*)ENABLE_VOICEOVER\s*=\s*True\s*(?P<comment>#.*)?$",
            r"\g<indent>ENABLE_VOICEOVER = False\g<comment>",
            source,
        )
    needs_imports = "from manim import" not in source and "import manim" not in source
    uses_base_config = "BaseConfigScene" in source
    defines_base_config = bool(re.search(r"(?m)^class\s+BaseConfigScene\b", source))
    needs_base_config = uses_base_config and not defines_base_config
    needs_numpy = ("np." in source or needs_base_config) and "import numpy as np" not in source
    additions: list[str] = []
    if needs_imports or needs_base_config:
        additions.append("from manim import *")
    if needs_numpy:
        additions.append("import numpy as np")
    if needs_base_config:
        additions.append(_BASE_CONFIG_SCENE_FALLBACK)
    if additions:
        source = "\n\n".join(additions + [source.lstrip()]) + (
            "\n" if not source.endswith("\n") else ""
        )
    if isolated_runtime_compat and "_mathpi_install_isolated_runtime_compat()" not in source:
        source = (
            source.rstrip()
            + f"\n\nMATHPI_ENABLE_REAL_TTS = {bool(enable_tts)!r}\n\n"
            + _ISOLATED_RUNTIME_COMPAT_PATCH
            + "\n"
        )
    return source
def _normalize_isolated_scene_source(source: str, *, enable_tts: bool = False) -> str:
    """Apply cheap text normalizations before isolated Manim import."""

    source = re.sub(
        r"class\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*"
        r"\(\s*VoiceoverScene\s*,\s*BaseConfigScene\s*\)\s*:",
        r"class \g<name>(BaseConfigScene):",
        source,
    )
    source = re.sub(
        r"(?m)^(?P<indent>\s*)from\s+base_scene\s+import\s+BaseConfigScene\s*$",
        r"\g<indent>pass  # isolated render supplies BaseConfigScene",
        source,
    )
    source = re.sub(r",\s*num_arcs\s*=\s*[^,)]+", "", source)
    source = re.sub(r",\s*arrow_size\s*=\s*[^,)]+", "", source)
    source = re.sub(
        r"self\.camera(?:\.frame)?\.animate\.set_euler_angles\s*\([^)]*\)",
        "Wait(0.1)",
        source,
    )
    if not enable_tts:
        source = re.sub(
            r"self\.set_speech_service\([^\n]*\)",
            "self.set_speech_service(None)",
            source,
        )
    source = re.sub(r"\bGrowArrow\s*\(", "Create(", source)
    return source
def _docker_tts_lock_mount_args() -> list[str]:
    return docker_tts_lock_mount_args()
def _docker_tts_env_args(*, enable_tts: bool) -> list[str]:
    return docker_tts_env_args(enable_tts=enable_tts)
def _render_payload(
    *,
    render_ok: bool,
    scene_name: str,
    image: str,
    network: str,
    returncode: int | None,
    mp4_path: Path,
    log_path: Path,
    check_path: Path,
    custom_services_mounted: bool,
    assets_mounted: bool,
    assets_dir: Path,
    enable_tts: bool,
    errors: list[str],
) -> dict[str, Any]:
    mp4_bytes = mp4_path.stat().st_size if mp4_path.exists() else 0
    return {
        "render_ok": render_ok,
        "scene_name": scene_name,
        "image": image,
        "network": network,
        "returncode": returncode,
        "mp4": str(mp4_path),
        "mp4_bytes": mp4_bytes,
        "log": str(log_path),
        "check_json": str(check_path),
        "custom_services_mounted": custom_services_mounted,
        "assets_mounted": assets_mounted,
        "assets_dir": str(assets_dir),
        "enable_tts": enable_tts,
        "requires_visual_probe": True,
        "errors": errors,
    }

