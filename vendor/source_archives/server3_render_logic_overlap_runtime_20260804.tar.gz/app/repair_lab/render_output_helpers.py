from __future__ import annotations

import json
from pathlib import Path
from collections.abc import Mapping
from typing import Any


def render_summary_markdown(summary: Mapping[str, Any]) -> str:
    lines = ["# A-line Manim Docker Video Verification", "", f"- Profile: {summary.get('profile')}", f"- Candidate clean cases: {summary.get('candidate_count')}", f"- Render OK: {summary.get('render_ok_count')}", f"- Render failed: {summary.get('render_fail_count')}", "- DB write count: 0", "- MQ publish count: 0", "", "| case_id | render_ok | scene | mp4_bytes | errors |", "|---|---:|---|---:|---|"]
    for item in summary.get("checks", []):
        errors = ",".join(str(error) for error in item.get("errors", []))
        lines.append("| {case_id} | {render_ok} | {scene_name} | {mp4_bytes} | {errors} |".format(case_id=item.get("case_id", ""), render_ok=item.get("render_ok"), scene_name=item.get("scene_name", ""), mp4_bytes=item.get("mp4_bytes", 0), errors=errors))
    lines.append("")
    return "\n".join(lines)


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fp:
        json.dump(payload, fp, ensure_ascii=False, indent=2, sort_keys=True)
        fp.write("\n")
