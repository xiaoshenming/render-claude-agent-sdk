"""A-line repair-lab Manim Docker video verification."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Mapping
from app.repair_lab.docker_render import run_manim_docker_render
from app.repair_lab.score_render import render_clean_scores_for_run
from app.repair_lab.runtime_compat_parts import runtime_compat_patch
from app.repair_lab.base_config_fallback import base_config_scene_fallback
from app.repair_lab.candidate_script import (
    prepare_candidate_script_for_manim, _normalize_isolated_scene_source,
    _docker_tts_lock_mount_args, _docker_tts_env_args, _render_payload,
)

from app.repair_lab.docker_tts_env import docker_tts_env_args, docker_tts_lock_mount_args
from app.repair_lab.scene_discovery import (
    base_name as _base_name,
    default_custom_services_dir as _default_custom_services_dir,
    default_render_assets_dir as _default_render_assets_dir,
    docker_container_name as _docker_container_name,
    find_rendered_mp4 as _find_rendered_mp4,
    force_remove_docker_container as _force_remove_docker_container,
    is_renderable_scene_class as _is_renderable_scene_class,
    resolve_scene_name_for_script as _resolve_scene_name_for_script,
    scene_class_names as _scene_class_names,
    scene_class_names_by_regex as _scene_class_names_by_regex,
    scene_name_from_score as _scene_name_from_score,
)
from app.repair_lab.render_output_helpers import render_summary_markdown, write_json


Runner = Callable[..., subprocess.CompletedProcess]

_SCENE_NAME_RE = re.compile(r"^[A-Za-z_]\w*$")














_render_summary_markdown = render_summary_markdown
_write_json = write_json


_ISOLATED_RUNTIME_COMPAT_PATCH = runtime_compat_patch()

_BASE_CONFIG_SCENE_FALLBACK = base_config_scene_fallback()
