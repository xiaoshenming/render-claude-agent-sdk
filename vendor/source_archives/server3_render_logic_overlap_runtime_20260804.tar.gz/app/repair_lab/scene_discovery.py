"""Scene discovery and Docker path helpers for repair-lab renders."""

from __future__ import annotations

import ast
import hashlib
import re
import subprocess
from pathlib import Path
from typing import Any, Callable, Mapping

Runner = Callable[..., subprocess.CompletedProcess]


def scene_name_from_score(row: Mapping[str, Any]) -> str:
    metrics = row.get("metrics")
    if isinstance(metrics, Mapping) and metrics.get("target_scene"):
        return str(metrics["target_scene"])
    return str(row.get("scene_name") or row.get("target_scene") or "Scene_Unknown")


def resolve_scene_name_for_script(scene_name: str, script_path: Path) -> str:
    source = script_path.read_text(encoding="utf-8", errors="ignore")
    scene_names = scene_class_names(source)
    if scene_name in scene_names:
        return scene_name
    if scene_name in {"", "None", "Scene_Unknown", "Unknown"} and scene_names:
        return scene_names[0]
    return scene_name


def scene_class_names(source: str) -> list[str]:
    try:
        module = ast.parse(source)
    except SyntaxError:
        return scene_class_names_by_regex(source)

    names: list[str] = []
    for node in module.body:
        if not isinstance(node, ast.ClassDef):
            continue
        if is_renderable_scene_class(node.name, [base_name(base) for base in node.bases]):
            names.append(node.name)
    return names or scene_class_names_by_regex(source)


def scene_class_names_by_regex(source: str) -> list[str]:
    names: list[str] = []
    for match in re.finditer(
        r"(?m)^class\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\((?P<bases>[^)]*)\)\s*:",
        source,
    ):
        base_names = [
            base.rsplit(".", 1)[-1].strip()
            for base in match.group("bases").split(",")
            if base.strip()
        ]
        if is_renderable_scene_class(match.group("name"), base_names):
            names.append(match.group("name"))
    return names


def base_name(base: ast.expr) -> str:
    if isinstance(base, ast.Name):
        return base.id
    if isinstance(base, ast.Attribute):
        return base.attr
    if isinstance(base, ast.Subscript):
        return base_name(base.value)
    return ""


def is_renderable_scene_class(name: str, base_names: list[str]) -> bool:
    if name == "BaseConfigScene" or name.startswith("_"):
        return False
    if name.startswith("Scene_") or name.endswith("Scene"):
        return True
    return any(base.endswith("Scene") for base in base_names)


def find_rendered_mp4(media_dir: Path, scene_name: str, expected_path: Path) -> Path:
    if expected_path.exists():
        return expected_path
    candidates = [
        path
        for path in (media_dir / "videos" / "candidate").glob(f"**/{scene_name}.mp4")
        if "partial_movie_files" not in path.parts and path.exists()
    ]
    if not candidates:
        return expected_path
    candidates.sort(key=lambda path: (path.stat().st_size, path.stat().st_mtime), reverse=True)
    return candidates[0]


def docker_container_name(out_dir: Path, scene_name: str) -> str:
    digest = hashlib.sha1(f"{out_dir.resolve()}:{scene_name}".encode("utf-8")).hexdigest()
    return f"mathpi-prerender-{digest[:16]}"


def force_remove_docker_container(container_name: str, *, runner: Runner) -> None:
    try:
        runner(
            ["docker", "rm", "-f", container_name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass


def default_custom_services_dir() -> Path:
    repo_local = Path(__file__).resolve().parents[1] / "custom_services"
    deploy_default = Path("/opt/mathpi/apps/render/app/custom_services")
    return repo_local if repo_local.exists() else deploy_default


def default_render_assets_dir() -> Path:
    repo_local = Path(__file__).resolve().parents[2] / "assets"
    deploy_default = Path("/opt/mathpi/apps/render/assets")
    return repo_local if repo_local.exists() else deploy_default
