"""repair_lab.artifacts — local run artifact writers."""

from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Mapping

from .schemas import SCHEMA_VERSION


def write_repair_lab_artifacts(
    out_dir: str | Path,
    *,
    manifest: Mapping[str, Any],
    score: Any,
) -> dict[str, Path]:
    """Write run_manifest.json, score.json, and summary.md under out_dir."""

    target_dir = Path(out_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    manifest_payload = _to_jsonable(manifest)
    if not isinstance(manifest_payload, dict):
        raise ValueError("manifest must be a JSON object")
    manifest_payload.setdefault("schema_version", SCHEMA_VERSION)
    manifest_payload["db_writebacks"] = int(manifest_payload.get("db_writebacks", 0) or 0)
    manifest_payload["mq_publishes"] = int(manifest_payload.get("mq_publishes", 0) or 0)
    if manifest_payload["db_writebacks"] != 0:
        raise ValueError("repair_lab artifacts must not record DB writebacks")
    if manifest_payload["mq_publishes"] != 0:
        raise ValueError("repair_lab artifacts must not record MQ publishes")

    score_payload = _to_jsonable(score)
    if not isinstance(score_payload, dict):
        raise ValueError("score must be a JSON object or expose to_dict()")

    run_manifest_path = target_dir / "run_manifest.json"
    score_path = target_dir / "score.json"
    summary_path = target_dir / "summary.md"

    _write_json(run_manifest_path, manifest_payload)
    _write_json(score_path, score_payload)
    summary_path.write_text(
        _build_summary(manifest_payload, score_payload),
        encoding="utf-8",
    )

    return {
        "run_manifest": run_manifest_path,
        "score": score_path,
        "summary": summary_path,
    }


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")


def _build_summary(
    manifest_payload: Mapping[str, Any],
    score_payload: Mapping[str, Any],
) -> str:
    run_id = manifest_payload.get("run_id", "unknown")
    case_id = manifest_payload.get("case_id", score_payload.get("case_id", "unknown"))
    runner = manifest_payload.get("runner", score_payload.get("lane", "unknown"))
    status = score_payload.get("status", "unknown")
    clean_success = score_payload.get("clean_success", False)

    return "\n".join(
        [
            "# Repair Lab Run Summary",
            "",
            f"- Run ID: {run_id}",
            f"- Case ID: {case_id}",
            f"- Runner: {runner}",
            f"- Status: {status}",
            f"- Clean Success: {clean_success}",
            "- DB 写回数=0",
            "- MQ 入队数=0",
            "",
        ],
    )


def _to_jsonable(value: Any) -> Any:
    if hasattr(value, "to_dict"):
        return _to_jsonable(value.to_dict())
    if is_dataclass(value):
        return _to_jsonable(asdict(value))
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(item) for item in value]
    return value
