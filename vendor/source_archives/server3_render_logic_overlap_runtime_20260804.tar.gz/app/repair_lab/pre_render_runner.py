"""Offline runner and gate for pre-render repair-lab cases."""

from __future__ import annotations

import ast
import difflib
import inspect
import json
import re
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from app.repair_lab.pre_render_schema import PreRenderRepairCase


RepairFn = Callable[..., Any]
RenderFn = Callable[..., Any]

_DEFAULT_FORBIDDEN_FALLBACKS = (
    "_mathpi_fallback_icon",
    "Card placeholder",
    "placeholder for content helper",
)

_SIGNATURE_STOPWORDS = {
    "AttributeError",
    "Exception",
    "NameError",
    "RuntimeError",
    "TypeError",
    "ValueError",
    "argument",
    "keyword",
    "object",
    "unexpected",
}


def run_pre_render_case(
    case_input: str | Path | Mapping[str, Any] | PreRenderRepairCase,
    output_dir: str | Path,
    *,
    mode: str = "static",
    max_rounds: int | None = None,
    deterministic_repair_fn: RepairFn | None = None,
    render_fn: RenderFn | None = None,
) -> dict[str, Any]:
    """Run one pre-render lab case into ``output_dir``.

    ``case_input`` may be a case.json path, a mapping, or a validated case. The
    candidate path is resolved relative to the case.json directory for file
    inputs, keeping the runner offline and self-contained.
    """

    case, case_root = _load_case_input(case_input)
    candidate_path = _resolve_candidate_path(case_root, case.candidate_path)
    return _run_case(
        case=case,
        before_path=candidate_path,
        case_dir=Path(output_dir),
        mode=mode,
        max_rounds=max_rounds,
        deterministic_repair_fn=deterministic_repair_fn,
        render_fn=render_fn,
    )


def run_pre_render_repair_case(
    case_input: Mapping[str, Any] | PreRenderRepairCase,
    *,
    case_root: str | Path,
    run_dir: str | Path,
    max_rounds: int | None = None,
    deterministic_repair_fn: RepairFn | None = None,
    render_fn: RenderFn | None = None,
    render_mode: str = "static_only",
) -> dict[str, Any]:
    """Run one case under ``runs/<run_id>/cases/<case_id>/`` style output."""

    case = (
        case_input
        if isinstance(case_input, PreRenderRepairCase)
        else PreRenderRepairCase.from_dict(case_input)
    )
    candidate_path = _resolve_candidate_path(Path(case_root), case.candidate_path)
    mode = "static" if render_mode in {"static", "static_only"} else render_mode
    return _run_case(
        case=case,
        before_path=candidate_path,
        case_dir=Path(run_dir) / "cases" / case.case_id,
        mode=mode,
        max_rounds=max_rounds,
        deterministic_repair_fn=deterministic_repair_fn,
        render_fn=render_fn,
    )


def _run_case(
    *,
    case: PreRenderRepairCase,
    before_path: Path,
    case_dir: Path,
    mode: str,
    max_rounds: int | None,
    deterministic_repair_fn: RepairFn | None,
    render_fn: RenderFn | None,
) -> dict[str, Any]:
    before_code = before_path.read_text(encoding="utf-8")
    case_dir.mkdir(parents=True, exist_ok=True)

    input_dir = case_dir / "input"
    input_dir.mkdir(parents=True, exist_ok=True)
    _write_json(input_dir / "case.json", case.to_dict())
    (input_dir / "before.py").write_text(before_code, encoding="utf-8")
    _write_json(
        input_dir / "initial_static_check.json",
        _static_check(before_code, case.scene_name),
    )
    _write_json(
        input_dir / "initial_render_check.json",
        {"status": "not_run", "render_ok": False, "render_mode": "not_run"},
    )

    current_code = before_code
    summary: dict[str, Any] | None = None
    resolved_max_rounds = max(1, int(max_rounds or case.max_rounds))

    for round_index in range(1, resolved_max_rounds + 1):
        round_dir = case_dir / f"round_{round_index:02d}"
        round_dir.mkdir(parents=True, exist_ok=True)

        repair_response = _run_repair(
            case=case,
            code=current_code,
            round_index=round_index,
            round_dir=round_dir,
            deterministic_repair_fn=deterministic_repair_fn,
        )
        after_code = _extract_repaired_code(repair_response, current_code)
        repair_method = _repair_method(repair_response)

        (round_dir / "after.py").write_text(after_code, encoding="utf-8")
        patch_text = _unified_diff(current_code, after_code)
        (round_dir / "patch.diff").write_text(patch_text, encoding="utf-8")
        _write_json(
            round_dir / "diagnosis.json",
            {
                "case_id": case.case_id,
                "failure_code": case.failure.get("failure_code"),
                "first_error": case.failure.get("first_error"),
                "round": round_index,
            },
        )
        _write_json(
            round_dir / "repair_request.json",
            {
                "case_id": case.case_id,
                "scene_name": case.scene_name,
                "repair_contract": case.repair_contract,
                "round": round_index,
            },
        )
        _write_json(round_dir / "repair_response.json", _jsonable(repair_response))

        static_check = _static_check(after_code, case.scene_name)
        render_check = _render_check(
            case=case,
            code=after_code,
            script_path=round_dir / "after.py",
            round_dir=round_dir,
            mode=mode,
            render_fn=render_fn,
        )
        gate = _gate(
            case=case,
            before_code=before_code,
            after_code=after_code,
            static_check=static_check,
            render_check=render_check,
            repair_response=repair_response,
        )

        _write_json(round_dir / "static_check.json", static_check)
        _write_json(round_dir / "render_check.json", render_check)
        _write_json(round_dir / "gate.json", gate)

        summary = _summary(
            case=case,
            gate=gate,
            render_check=render_check,
            repair_method=repair_method,
            rounds_used=round_index,
            changed_lines=_changed_line_count(patch_text),
        )
        if gate["final_status"].startswith("pass_"):
            break
        if gate["final_status"] in {
            "fail_syntax",
            "fail_contract_drift",
            "fail_core_visual_placeholder",
            "fail_signature_not_removed",
        }:
            break
        if after_code == current_code:
            break
        current_code = after_code

    if summary is None:  # pragma: no cover - max_rounds is clamped to >= 1
        summary = {
            "case_id": case.case_id,
            "final_status": "fail_no_rounds",
            "rounds_used": 0,
            "render_ok": False,
            "mp4": "",
            "failure_code": _text(case.failure.get("failure_code")),
            "repair_method": "",
            "changed_lines": 0,
            "non_target_scene_changes": 0,
            "blocked_by": ["rounds"],
            "warnings": [],
        }

    _write_json(case_dir / "summary.json", summary)
    (case_dir / "summary.md").write_text(_summary_markdown(summary), encoding="utf-8")
    return summary


def _load_case_input(
    case_input: str | Path | Mapping[str, Any] | PreRenderRepairCase,
) -> tuple[PreRenderRepairCase, Path]:
    if isinstance(case_input, PreRenderRepairCase):
        return case_input, Path.cwd()
    if isinstance(case_input, Mapping):
        return PreRenderRepairCase.from_dict(case_input), Path.cwd()

    case_path = Path(case_input)
    payload = json.loads(case_path.read_text(encoding="utf-8"))
    return PreRenderRepairCase.from_dict(payload), case_path.parent


def _resolve_candidate_path(case_root: Path, candidate_path: str) -> Path:
    root = case_root.resolve()
    relative = Path(candidate_path)
    candidates = [root / relative]
    candidates.extend(parent / relative for parent in root.parents[:4])
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    return candidates[0].resolve()


def _run_repair(
    *,
    case: PreRenderRepairCase,
    code: str,
    round_index: int,
    round_dir: Path,
    deterministic_repair_fn: RepairFn | None,
) -> Any:
    repair_fn = deterministic_repair_fn or _default_pre_render_scan_repair
    return _call_adapter(
        repair_fn,
        {
            "code": code,
            "case": case,
            "round_index": round_index,
            "out_dir": round_dir,
        },
        positional=(code, case),
    )


def _default_pre_render_scan_repair(code: str, case: PreRenderRepairCase) -> dict[str, Any]:
    del case
    try:
        from app.workers.repair.pre_render_fixes import pre_render_scan
    except Exception as exc:
        return {
            "code": code,
            "repair_method": "deterministic_pre_render_scan_unavailable",
            "fixes": [],
            "error": repr(exc),
        }

    result = pre_render_scan(code)
    if isinstance(result, str):
        return {
            "code": result,
            "repair_method": "deterministic_pre_render_scan",
            "fixes": [],
        }
    if isinstance(result, (tuple, list)):
        fixed_code = result[0] if result else code
        fixes = result[1] if len(result) > 1 else []
        return {
            "code": fixed_code if isinstance(fixed_code, str) else code,
            "repair_method": "deterministic_pre_render_scan",
            "fixes": _string_list(fixes),
        }
    if isinstance(result, Mapping):
        payload = dict(result)
        payload.setdefault("repair_method", "deterministic_pre_render_scan")
        return payload
    return {
        "code": code,
        "repair_method": "deterministic_pre_render_scan_unknown_result",
        "fixes": [],
    }


def _render_check(
    *,
    case: PreRenderRepairCase,
    code: str,
    script_path: Path,
    round_dir: Path,
    mode: str,
    render_fn: RenderFn | None,
) -> dict[str, Any]:
    if mode in {"static", "static_only"}:
        return {
            "status": "static_only",
            "render_mode": "static_only",
            "render_ok": False,
            "mp4_bytes": 0,
            "mp4": "",
            "reason": "docker_not_requested",
        }

    output_dir = round_dir / "render"
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        if render_fn is None:
            from app.repair_lab.video_render import run_manim_docker_render

            result = run_manim_docker_render(
                script_path=script_path,
                scene_name=case.scene_name,
                output_dir=output_dir,
            )
        else:
            result = _call_adapter(
                render_fn,
                {
                    "case": case,
                    "code": code,
                    "script_path": script_path,
                    "scene_name": case.scene_name,
                    "output_dir": output_dir,
                    "out_dir": output_dir,
                },
            )
    except Exception as exc:  # pragma: no cover - adapter boundary
        return {
            "status": "static_only",
            "render_mode": "static_only",
            "render_ok": False,
            "mp4_bytes": 0,
            "mp4": "",
            "errors": [f"docker_unavailable:{exc}"],
            "reason": "docker_unavailable",
        }

    payload = dict(result) if isinstance(result, Mapping) else {}
    errors = _string_list(payload.get("errors"))
    if _docker_unavailable(payload, errors):
        return {
            "status": "static_only",
            "render_mode": "static_only",
            "render_ok": False,
            "mp4_bytes": 0,
            "mp4": "",
            "errors": errors,
            "reason": "docker_unavailable",
        }
    mp4_bytes = _mp4_byte_count(payload.get("mp4_bytes"))
    mp4_path = _text(payload.get("mp4") or payload.get("mp4_path"))
    render_ok = bool(payload.get("render_ok")) and mp4_bytes > 0
    return {
        "status": "render_ok" if render_ok else "render_failed",
        "render_mode": mode,
        "render_ok": render_ok,
        "mp4_bytes": mp4_bytes,
        "mp4": mp4_path,
        "returncode": payload.get("returncode"),
        "errors": errors,
    }


def _docker_unavailable(payload: Mapping[str, Any], errors: list[str]) -> bool:
    if payload.get("returncode") == 125:
        return True
    return any(
        item.startswith(("docker_not_available", "docker_unavailable"))
        or item == "docker_render_returncode:125"
        for item in errors
    )


def _gate(
    *,
    case: PreRenderRepairCase,
    before_code: str,
    after_code: str,
    static_check: dict[str, Any],
    render_check: dict[str, Any],
    repair_response: Any,
) -> dict[str, Any]:
    non_target_changes = _non_target_scene_changes(
        before_code,
        after_code,
        case.scene_name,
    )
    failure_removed = _failure_signature_removed(
        case=case,
        before_code=before_code,
        after_code=after_code,
        render_check=render_check,
        repair_response=repair_response,
    )
    forbidden_found = _forbidden_fallbacks_found(case, after_code)
    forbidden_absent = not forbidden_found
    static_only = render_check.get("status") == "static_only"
    render_ok = bool(render_check.get("render_ok"))

    final_status = "pass_static_only"
    blocked_by: list[str] = []
    if not static_check["syntax_ok"]:
        final_status = "fail_syntax"
        blocked_by = ["syntax_ok"]
    elif not static_check["scene_exists"]:
        final_status = "fail_contract_drift"
        blocked_by = ["scene_exists"]
    elif non_target_changes:
        final_status = "fail_contract_drift"
        blocked_by = ["non_target_scene_changes"]
    elif not forbidden_absent:
        final_status = "fail_core_visual_placeholder"
        blocked_by = ["forbidden_fallback_absent"]
    elif not failure_removed:
        final_status = "fail_signature_not_removed"
        blocked_by = ["failure_signature_removed"]
    elif render_ok:
        final_status = "pass_render_ok"
    elif static_only:
        final_status = "pass_static_only"
    else:
        final_status = "fail_render"
        blocked_by = ["render_ok"]

    return {
        "final_status": final_status,
        "syntax_ok": bool(static_check["syntax_ok"]),
        "scene_exists": bool(static_check["scene_exists"]),
        "non_target_scene_changes": non_target_changes,
        "target_changed_only": not non_target_changes,
        "render_ok": render_ok,
        "static_only": static_only,
        "failure_signature_removed": failure_removed,
        "forbidden_fallback_absent": forbidden_absent,
        "forbidden_fallbacks_found": forbidden_found,
        "blocked_by": blocked_by,
    }


def _summary(
    *,
    case: PreRenderRepairCase,
    gate: dict[str, Any],
    render_check: dict[str, Any],
    repair_method: str,
    rounds_used: int,
    changed_lines: int,
) -> dict[str, Any]:
    warnings: list[str] = []
    if render_check.get("render_mode") == "static_only":
        reason = _text(render_check.get("reason"))
        warnings.append(reason or "static_only")
    return {
        "case_id": case.case_id,
        "final_status": gate["final_status"],
        "rounds_used": rounds_used,
        "render_ok": bool(render_check.get("render_ok")),
        "render_mode": render_check.get("render_mode", ""),
        "mp4": render_check.get("mp4", ""),
        "failure_code": _text(case.failure.get("failure_code")),
        "repair_method": repair_method,
        "changed_lines": changed_lines,
        "non_target_scene_changes": len(gate["non_target_scene_changes"]),
        "blocked_by": list(gate["blocked_by"]),
        "warnings": warnings,
        "failure_signature_removed": gate["failure_signature_removed"],
        "forbidden_fallback_absent": gate["forbidden_fallback_absent"],
    }


def _static_check(code: str, scene_name: str) -> dict[str, Any]:
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return {
            "syntax_ok": False,
            "scene_exists": f"class {scene_name}" in code,
            "scene_names": [],
            "error": f"{exc.__class__.__name__}: {exc}",
        }

    scene_blocks = _scene_class_blocks(code, tree)
    return {
        "syntax_ok": True,
        "scene_exists": scene_name in scene_blocks,
        "scene_names": sorted(scene_blocks),
        "error": "",
    }


def _scene_class_blocks(code: str, tree: ast.AST | None = None) -> dict[str, str]:
    parsed = tree or ast.parse(code)
    lines = code.splitlines()
    blocks: dict[str, str] = {}
    for node in ast.walk(parsed):
        if not isinstance(node, ast.ClassDef) or not _inherits_scene(node):
            continue
        end_lineno = node.end_lineno or node.lineno
        blocks[node.name] = "\n".join(lines[node.lineno - 1 : end_lineno])
    return blocks


def _inherits_scene(node: ast.ClassDef) -> bool:
    for base in node.bases:
        name = _base_name(base)
        if name == "Scene" or name.endswith("Scene"):
            return True
    return False


def _base_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Subscript):
        return _base_name(node.value)
    if isinstance(node, ast.Call):
        return _base_name(node.func)
    return ""


def _non_target_scene_changes(
    before_code: str,
    after_code: str,
    target_scene: str,
) -> list[str]:
    try:
        before_blocks = _scene_class_blocks(before_code)
        after_blocks = _scene_class_blocks(after_code)
    except SyntaxError:
        return []

    changed: list[str] = []
    for scene_name in sorted(set(before_blocks) | set(after_blocks)):
        if scene_name == target_scene:
            continue
        if before_blocks.get(scene_name) != after_blocks.get(scene_name):
            changed.append(scene_name)
    return changed


def _failure_signature_removed(
    *,
    case: PreRenderRepairCase,
    before_code: str,
    after_code: str,
    render_check: Mapping[str, Any],
    repair_response: Any,
) -> bool:
    if isinstance(repair_response, Mapping) and isinstance(
        repair_response.get("failure_signature_removed"),
        bool,
    ):
        return bool(repair_response["failure_signature_removed"])

    candidates = _failure_signature_candidates(case.failure)
    observed = [candidate for candidate in candidates if candidate in before_code]
    if observed:
        return all(candidate not in after_code for candidate in observed)
    return True


def _failure_signature_candidates(failure: Mapping[str, Any]) -> list[str]:
    candidates: list[str] = []
    for key in ("signature", "first_error", "failure_code"):
        value = _text(failure.get(key))
        if not value:
            continue
        candidates.append(value)
        candidates.extend(
            match
            for match in re.findall(r"[\"']([^\"']{3,})[\"']", value)
            if match.strip()
        )
    return _dedupe(candidates)


def _forbidden_fallbacks_found(case: PreRenderRepairCase, code: str) -> list[str]:
    configured = case.acceptance.get("forbidden_fallbacks", [])
    markers = _dedupe([*_string_list(configured), *_DEFAULT_FORBIDDEN_FALLBACKS])
    return [marker for marker in markers if marker and marker in code]


def _extract_repaired_code(repair_response: Any, fallback: str) -> str:
    if isinstance(repair_response, str):
        return repair_response
    if isinstance(repair_response, Mapping):
        for key in ("code", "script", "patched_script", "fixed_code"):
            value = repair_response.get(key)
            if isinstance(value, str):
                return value
    return fallback


def _repair_method(repair_response: Any) -> str:
    if isinstance(repair_response, Mapping):
        return _text(
            repair_response.get("repair_method")
            or repair_response.get("method")
            or repair_response.get("mode")
        )
    return "deterministic_repair_fn"


def _call_adapter(
    fn: Callable[..., Any],
    kwargs: dict[str, Any],
    positional: tuple[Any, ...] = (),
) -> Any:
    signature = inspect.signature(fn)
    parameters = signature.parameters
    if any(param.kind == inspect.Parameter.VAR_KEYWORD for param in parameters.values()):
        return fn(**kwargs)

    accepted_kwargs = {
        name: value
        for name, value in kwargs.items()
        if name in parameters
        and parameters[name].kind
        in {
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        }
    }
    if accepted_kwargs:
        return fn(**accepted_kwargs)
    return fn(*positional)


def _unified_diff(before: str, after: str) -> str:
    return "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile="before.py",
            tofile="after.py",
        )
    )


def _changed_line_count(patch_text: str) -> int:
    changed = 0
    for line in patch_text.splitlines():
        if line.startswith(("+++", "---")):
            continue
        if line.startswith(("+", "-")):
            changed += 1
    return changed


def _mp4_byte_count(value: Any) -> int:
    if isinstance(value, bytes):
        return len(value)
    if isinstance(value, bytearray):
        return len(value)
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _write_json(path: Path, payload: Any) -> None:
    path.write_text(
        json.dumps(_jsonable(payload), ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def _jsonable(value: Any) -> Any:
    if isinstance(value, bytes):
        return len(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return repr(value)


def _summary_markdown(summary: Mapping[str, Any]) -> str:
    lines = [
        f"# {summary.get('case_id', '')}",
        "",
        f"- final_status: {summary.get('final_status', '')}",
        f"- rounds_used: {summary.get('rounds_used', 0)}",
        f"- render_ok: {str(summary.get('render_ok', False)).lower()}",
        f"- repair_method: {summary.get('repair_method', '')}",
        f"- blocked_by: {', '.join(_string_list(summary.get('blocked_by'))) or '[]'}",
        "",
    ]
    return "\n".join(lines)


def _string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple, set)):
        return [_text(item) for item in value if _text(item)]
    return [_text(value)] if _text(value) else []


def _text(value: Any) -> str:
    return value.strip() if isinstance(value, str) else ""


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        item = value.strip()
        if not item or item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


__all__ = [
    "run_pre_render_case",
    "run_pre_render_repair_case",
]
