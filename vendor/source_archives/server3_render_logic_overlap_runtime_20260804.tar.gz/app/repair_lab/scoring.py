"""repair_lab.scoring — result status and scoring helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Mapping

from .schemas import SCHEMA_VERSION


SUCCESS_CLEAN = "SUCCESS_CLEAN"
SUCCESS_DEGRADED = "SUCCESS_DEGRADED"
REPAIR_FAILED = "REPAIR_FAILED"
REPAIR_WORSE = "REPAIR_WORSE"
REPAIR_UNCHANGED = "REPAIR_UNCHANGED"
REVIEW_ERROR = "REVIEW_ERROR"

RepairStatus = Literal[
    "SUCCESS_CLEAN",
    "SUCCESS_DEGRADED",
    "REPAIR_FAILED",
    "REPAIR_WORSE",
    "REPAIR_UNCHANGED",
    "REVIEW_ERROR",
]

_REVIEW_ERROR_STATUSES = {
    "artifact_missing",
    "json_error",
    "missing",
    "provider_error",
    "review_artifact_missing",
    "review_error",
    "timeout",
    "timeout_error",
}

_FAILED_REVIEW_STATUSES = {
    "failed",
    "failure",
    "patch_failed",
    "render_failed",
}


@dataclass(kw_only=True)
class RepairScore:
    """Machine-readable repair-lab score."""

    case_id: str
    lane: str
    status: RepairStatus
    outcome: str
    metrics: dict[str, Any] = field(default_factory=dict)
    reasons: list[str] = field(default_factory=list)
    run_id: str | None = None
    selected_repair_skill: str | None = None
    artifacts: dict[str, str] = field(default_factory=dict)
    failure_if_any: str | None = None
    schema_version: int = SCHEMA_VERSION

    @property
    def clean_success(self) -> bool:
        return is_clean_success(self.status)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "case_id": self.case_id,
            "lane": self.lane,
            "status": self.status,
            "outcome": self.outcome,
            "clean_success": self.clean_success,
            "metrics": dict(self.metrics),
            "reasons": list(self.reasons),
            "artifacts": dict(self.artifacts),
            "failure_if_any": self.failure_if_any,
        }
        if self.run_id:
            payload["run_id"] = self.run_id
        if self.selected_repair_skill:
            payload["selected_repair_skill"] = self.selected_repair_skill
        return payload


def is_clean_success(status: str) -> bool:
    """Only SUCCESS_CLEAN counts as a clean repair success."""

    return status == SUCCESS_CLEAN


def score_repair_result(
    *,
    case_id: str,
    lane: str,
    status: RepairStatus,
    outcome: str | None = None,
    metrics: Mapping[str, Any] | None = None,
    reasons: list[str] | None = None,
    run_id: str | None = None,
    selected_repair_skill: str | None = None,
    artifacts: Mapping[str, str] | None = None,
    failure_if_any: str | None = None,
) -> RepairScore:
    """Build a normalized score from an explicit status."""

    return RepairScore(
        case_id=case_id,
        run_id=run_id,
        lane=lane,
        selected_repair_skill=selected_repair_skill,
        status=status,
        outcome=outcome or _default_outcome(status),
        metrics=dict(metrics or {}),
        reasons=list(reasons or []),
        artifacts=dict(artifacts or {}),
        failure_if_any=failure_if_any,
    )


def score_layout_repair(
    *,
    case_id: str,
    metrics: Mapping[str, Any],
    run_id: str | None = None,
    selected_repair_skill: str | None = None,
    artifacts: Mapping[str, str] | None = None,
) -> RepairScore:
    """Score a layout post-review repair attempt.

    Clean requires an actual overlap reduction plus no remaining high-risk
    layout issue. Worse/unchanged/review error are explicitly non-clean states.
    """

    metric_payload = dict(metrics)
    review_status = str(metric_payload.get("review_status", "")).strip().lower()
    if metric_payload.get("review_error") or review_status in _REVIEW_ERROR_STATUSES:
        return score_repair_result(
            case_id=case_id,
            run_id=run_id,
            lane="layout_post_review",
            selected_repair_skill=selected_repair_skill,
            status=REVIEW_ERROR,
            outcome="review_error",
            metrics=metric_payload,
            reasons=["layout review failed or artifact was missing"],
            artifacts=artifacts,
            failure_if_any="review_error",
        )

    if metric_payload.get("repair_failed") or review_status in _FAILED_REVIEW_STATUSES:
        return score_repair_result(
            case_id=case_id,
            run_id=run_id,
            lane="layout_post_review",
            selected_repair_skill=selected_repair_skill,
            status=REPAIR_FAILED,
            outcome="failed",
            metrics=metric_payload,
            reasons=["layout repair did not produce a valid recheck"],
            artifacts=artifacts,
            failure_if_any="repair_failed",
        )

    required = (
        "before_overlap_count",
        "after_overlap_count",
        "before_max_overlap_ratio",
        "after_max_overlap_ratio",
    )
    missing = [name for name in required if metric_payload.get(name) is None]
    if missing:
        return score_repair_result(
            case_id=case_id,
            run_id=run_id,
            lane="layout_post_review",
            selected_repair_skill=selected_repair_skill,
            status=REPAIR_FAILED,
            outcome="failed",
            metrics=metric_payload,
            reasons=[f"missing layout metrics: {', '.join(missing)}"],
            artifacts=artifacts,
            failure_if_any="missing_metrics",
        )

    before_count = _as_int(metric_payload["before_overlap_count"])
    after_count = _as_int(metric_payload["after_overlap_count"])
    before_ratio = _as_float(metric_payload["before_max_overlap_ratio"])
    after_ratio = _as_float(metric_payload["after_max_overlap_ratio"])
    after_layout_error_count = _as_int(
        metric_payload.get("after_layout_error_count", after_count),
    )
    residual_high_risk = bool(metric_payload.get("residual_high_risk", False))
    key_objects_missing = bool(
        metric_payload.get("key_objects_missing")
        or metric_payload.get("key_formula_deleted")
        or metric_payload.get("key_text_deleted")
        or metric_payload.get("key_answer_deleted"),
    )

    reasons: list[str] = []
    if key_objects_missing:
        reasons.append("key object/formula/text/answer was removed")
    if after_count > before_count:
        reasons.append("overlap count increased")
    if after_ratio > before_ratio:
        reasons.append("max overlap ratio increased")
    if reasons:
        return score_repair_result(
            case_id=case_id,
            run_id=run_id,
            lane="layout_post_review",
            selected_repair_skill=selected_repair_skill,
            status=REPAIR_WORSE,
            outcome="worse",
            metrics=metric_payload,
            reasons=reasons,
            artifacts=artifacts,
            failure_if_any="layout_worse",
        )

    if after_count >= before_count:
        return score_repair_result(
            case_id=case_id,
            run_id=run_id,
            lane="layout_post_review",
            selected_repair_skill=selected_repair_skill,
            status=REPAIR_UNCHANGED,
            outcome="unchanged",
            metrics=metric_payload,
            reasons=["overlap count did not decrease"],
            artifacts=artifacts,
            failure_if_any="layout_unchanged",
        )

    clean_ratio_limit = min(before_ratio, _as_float(metric_payload.get("max_clean_overlap_ratio", 0.08)))
    if (
        after_layout_error_count == 0
        and after_ratio <= clean_ratio_limit
        and not residual_high_risk
    ):
        return score_repair_result(
            case_id=case_id,
            run_id=run_id,
            lane="layout_post_review",
            selected_repair_skill=selected_repair_skill,
            status=SUCCESS_CLEAN,
            outcome="clean",
            metrics=metric_payload,
            artifacts=artifacts,
        )

    return score_repair_result(
        case_id=case_id,
        run_id=run_id,
        lane="layout_post_review",
        selected_repair_skill=selected_repair_skill,
        status=SUCCESS_DEGRADED,
        outcome="improved_with_residual",
        metrics=metric_payload,
        reasons=["overlap improved but residual layout risk remains"],
        artifacts=artifacts,
    )


def _default_outcome(status: str) -> str:
    return {
        SUCCESS_CLEAN: "clean",
        SUCCESS_DEGRADED: "improved_with_residual",
        REPAIR_FAILED: "failed",
        REPAIR_WORSE: "worse",
        REPAIR_UNCHANGED: "unchanged",
        REVIEW_ERROR: "review_error",
    }.get(status, "unknown")


def _as_int(value: Any) -> int:
    return int(value)


def _as_float(value: Any) -> float:
    return float(value)
